These nine files are byte-for-byte copies of the `GraphicFunctions` directory
in the protected `/Users/nanyoujiayu/Documents/GitHub/SLIP_Quadruped` reference.
The `.m.txt` suffix preserves the original source without introducing legacy
function names or the packed legacy parameter contract onto the MATLAB path.
`source_manifest.json` records the original paths, SHA-256 hashes, and live v3
counterparts for every file.

`ComputeBodyGraphics_v3`, `ComputeLegGraphics_v3`, and the part renderer in
`SLIP_Animation_Quad_v3` now preserve the original body silhouette, shaded
links, orange springs, telescoping lower links, ground hatching, and depth
order (left legs, torso, right legs). The decorative torso outline is 1.2
units long, as in v2; the physical hip separation remains one unit.

The existing v3 counterparts of the remaining functions retain the native
trajectory/orbit interface. `ComputeJointLegGeometry_v3` uses the fourteen
states in schema order `[BL BR FL FR]`, ten physical parameters, and recorded
binary contact modes. `ComputePhaseDiagram_v3` uses recorded autonomous
events. The trajectory, periodic-orbit, and ground-reaction-force plots use
the same schema. They do not reintroduce v2's packed event/parameter vector
or scheduled-event contact reconstruction.

The GRF plot retains the v2 left/right colors, back/front line styles, and
LH/LF/RF/RH legend order while its stored force columns and line handles
remain in native schema order. Back/front trajectory axes share limits.
The periodic-orbit plot retains the v2 labels, section annotations, marker
size, and padding.

`DrawQuadrupedOscillators_v3` and `UpdateQuadrupedOscillators_v3` reproduce the
v2 GUI phase-circle quadrants and contact rays/sectors from native recorded
events. The circles represent cycle time, rather than mechanical leg
angles. Every stance interval and contact event of a multi-contact cycle
is included. The time marker supports nonzero trajectory start time and
successive strides.

`Audits_v3/AuditV2GraphicsPort_v3.m` compares the live body and leg vertices
and faces directly with the protected original functions, checks renderer
depth order, and checks contact geometry and event-frame modes from the
saved `C1_PK_10_20_2.mat` trajectory. This graphics audit creates no new
integration, root solve, scientific acceptance, or dataset changes.
It also exercises the GRF/trajectory/orbit conventions, oscillator contact
intervals on saved PK/P2 records and a synthetic phase fixture, and closing
a figure during standalone playback.
