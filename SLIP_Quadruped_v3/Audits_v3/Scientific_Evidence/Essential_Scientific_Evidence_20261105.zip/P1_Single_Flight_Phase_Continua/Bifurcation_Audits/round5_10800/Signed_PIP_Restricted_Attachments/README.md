# round5_10800 signed PIP evidence

This study publication recognizes **1 conditional restricted PIP2 attachment**: **1 already represented**, **0 newly represented**, **7 inherited sample edges** preserved and **0 new sample edges**. Continuing the same attachment creates no new family. Samples do not join the signed continuation components.

The scope is the exact-baseline synchronized fixed-parameter pronk restriction, using inherited fixed-energy 3D parent derivatives. Full-system bifurcation, C2 regularity, stability, rigorous/global ancestry and completeness remain unestablished. PIP3 retains its strict candidate-only diagnostic and receives no attachment edge.

- [Final scientific report](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Docs_v3/round5_10800_Scientific_Results_v3.md)
- [Stopped signed PIP corrections, strict gates and actual ordered components](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P1_Single_Flight_Phase_Continua/Bifurcation_Audits/round5_10800/Signed_PIP_Restricted_Attachments/Signed_PIP_Forensics_v3.md)
- [Exact copied evidence, SHA lineage, parent identity and typed-edge contract](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P1_Single_Flight_Phase_Continua/Bifurcation_Audits/round5_10800/Signed_PIP_Restricted_Attachments/attachment_publication.json)
- [Final typed research graph](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/round5/experiments/round5_10800/graph/index.json)
- [Current GUI branch catalog](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P1_Single_Flight_Phase_Continua/Branch_Catalog_v3.json)

- [C1_PK_10_20_2.mat](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P1_Single_Flight_Phase_Continua/C1_PK_10_20_2.mat): native source group `P1/signed_PIP_2` retains its signed samples and separate ordered-component metadata.
- [C1_PK_10_20_2.mat](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P1_Single_Flight_Phase_Continua/C1_PK_10_20_2.mat): native source group `P1/signed_PIP_3` retains its signed samples and separate ordered-component metadata.
