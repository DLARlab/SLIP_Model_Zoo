# Ongoing native admission checkpoint

Generated 2026-10-11 15:15:18 UTC. Principal requested gaits admitted: 0 of 8.

Every listed point passed original BL1 admission, all nine gates, and both independent plain fine replays. These are numerical points found so far; they do not establish a complete branch or a bifurcation connection.

| Actual gait | Highest common torsional stiffness with all other parameters fixed | Signed speed | Native closure |
|---|---:|---:|---:|
| BG | 18.7036132812 | 4.22828867 | 2.96e-11 |
| BE | 18.6420583725 | 4.2655034 | 5.04e-13 |
| FG | 18.59375 | -3.87324916 | 3.32e-13 |
| FE | 17.5 | 3.82686153 | 6.01e-11 |
| HG | 17.5 | 3.72593501 | 5.95e-11 |
| HE | 18.59375 | -4.00146049 | 7.33e-12 |
| GG | None | — | — |
| GE | None | — | — |

Negative signed speed denotes reversed heading. Changed-linear-stiffness diagnostic points are retained separately in the JSON/MAT records and do not raise this table.
