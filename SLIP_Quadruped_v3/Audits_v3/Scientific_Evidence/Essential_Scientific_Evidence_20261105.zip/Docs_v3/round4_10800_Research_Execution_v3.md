# Continuation tranche round4_10800 executed research

Starting commit `3e4d3115340a765808c5a3092f84905aa11037ae`; MATLAB 25.2.0.3177638 (R2025b) Update 5, MACA64. New experiment `round4_10800`.

Status: **total_budget_exhausted**. 10821.163 / 10800 seconds charged across 9 invocations. Function evaluations: 3175 (exact: 0). New distinct continuation points: 18. Executed research rounds: B, A, C.

The earlier exhausted checkpoint, registration, source fixtures and scientific artifacts are read-only references. Execution completion is separate from a bifurcation or ancestry claim. The requested network remains unresolved until independently gated typed edges cover it.

| Task | Round | Attempts | State | Scientific evidence | Wall seconds | New points |
|---|---|---:|---|---|---:|---:|
| solver_validation | gate | 0 | accepted | exact_source_bound_predecessor_gates_reused_no_new_maps | 0.000 | 0 |
| signed_PIP_2 | A | 2 | partial_checkpoint | numerically_supported_restricted_attachment | 1293.403 | 8 |
| signed_PIP_3 | A | 3 | partial_checkpoint | restricted_spectral_candidate_with_executed_daughter_attempts | 1534.287 | 7 |
| PK_continuation_m1 | B | 3 | partial_checkpoint | continued_branch_attachment_unresolved | 2135.711 | 10 |
| PK_continuation_p1 | B | 3 | partial_checkpoint | continued_branch_attachment_unresolved | 2115.781 | 8 |
| front_coupled | C | 1 | partial_checkpoint | full_front_coupled_center_trials_qualified_numerical_research | 1801.540 | 0 |
| source17_B2 | B | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| opposed_spectral_scan | A | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| measured_BL2 | B | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| source_evidence_labels | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| exact_source_B2_30 | A | 1 | retryable_failure | exact_source30_actual_autonomous_B2_hypothesis | 20.394 | 0 |
| opposed_capped_metric | A | 1 | partial_checkpoint | actual_full13_capped_left_metric_candidate_correction | 1512.204 | 0 |
| exact_source_B2_35 | A | 1 | retryable_failure | exact_source35_alternate_apex_actual_autonomous_B2_hypothesis | 407.844 | 0 |

Full coverage, causal repair records, and task artifacts: `Research_v3/round4/experiments/round4_10800/task_queue_full.json`. Typed graph: `Research_v3/round4/experiments/round4_10800/graph/index.json`. Historical backlog remains explicitly retained.
