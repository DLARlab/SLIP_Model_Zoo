# Strict-contact search: recovery and executed-work audit

The campaign has **not admitted BG, BE, FG, FE, HG, HE, GG or GE** at the principal parameters `[10;10;20;20;1;1;0;0;2;.5]`. Four additional PK parent points passed the unchanged original nine admission gates. They are parent evidence, not the requested daughter branches or proved connecting arcs. No invalid legacy cycle was published under a requested C1 gait name.

This report distinguishes actual execution from prepared methods, finite off-shell map trials from periodic orbits, and implementation/resource failures from physical contact rejection. Unsuccessful searches do not prove that these gaits do not exist.

## Allocation and interruption

The immutable twelve-hour wall-clock allocation began **9 October 2026, 13:18:34 UTC** and ended **10 October, 01:18:34 UTC** (9:18:34 p.m. EDT on 9 October), with twenty minutes originally reserved for a final audit. The conversation resumed at approximately **10 October, 06:51 UTC**, after the deadline and a service interruption. Existing MATLAB jobs completed independently under their registered slices. The last recovered root-stream numerical summary was written at **9 October, 19:19:10 UTC**; that file timestamp is not an independently observed OS exit timestamp.

The allocation elapsed without twelve uninterrupted hours of adaptive orchestration. Several planned successors were never launched. Recovery has not reset the original clock or silently granted another research allocation. Post-campaign saved-data audits and narrowly bounded implementation controls are labeled separately. A choice of additional numerical-search allocation was requested while this audit continued.

Native numerical work used MATLAB **R2025b Update 5**, version **25.2.0.3177638**, with the Optimization Toolbox. Parallel task slices shared the same original wall-clock deadline.

## Executed approaches

| Approach | Actual coverage | Outcome and limiting evidence |
|---|---|---|
| Native scheduled replay of legacy sources | All 2,552 retained v2 columns | Ranked actual contact/path violations. Agreement with scheduled native flows does not establish autonomous first-contact validity. |
| Coupled timed feasibility | Two initial cases, then eight gait cases | Genuine signed path and contact-direction inequalities retained; no native admission. |
| Diverse state/time initial guesses | 55 completed cases | Some closure errors decreased; path violations or small asymmetry remained. |
| Alternative contact words | 60 adjacent/repeated-word cases | No admitted principal-model gait. |
| Square fixed-amplitude timed roots | 12 cases | All had nonzero periods, approximately 1.28–1.99. One BE timed word closed near `1.5e-11` but failed autonomous replay and its contact-direction check. These cases must not be confused with separate collapsed-period SQP trials. |
| Explicit nonzero-period contact-word searches | 32 completed cases | Excluded the observed zero-period optimizer limit within a declared search domain. No strict gait. |
| Native velocity/phase basins | 384 F/H/G and 144 B guesses | Produced finite native starts for independent correction; finite starts were not labeled periodic solutions. |
| Measured PK front/hind sector basins | 216 guesses | Used measured physical sector directions. Larger perturbations frequently left the compressive-contact domain. |
| Contacting-leg apex guesses | 480 guesses, 164 map attempts | 148 tensile-stance failures; 16 outside the BL chart. Rephasing those 16 through actual first returns still yielded 16 subsequent tensile-stance failures under original BL1. |
| Root-owned coupled native corrections | 38 completed cases in five streams | Zero native admissions. Central-only and explicitly one-sided search epochs are separate. The original derivative qualification was preserved. |
| Paired path-constrained B corrections | Repeated geometry/model repairs, including 20 accepted original-BL1 steps in the endpoint-capable run | Original-BL1 full closure reached `0.3393683485`. A changed first-return predictor reached `0.3125121890`, then stopped on a reporting-field bug after one accepted step. No final BL1 admission ran on that point. |
| Native SQP and lifted/paired multiple shooting | Original, adjacent-word, lifted and hard-equation paired experiments | Physical slack stayed negative. Independent composed replay exposed continuity defects or retained actual negative swing-foot clearance. Two 3,000-second paired runs ended on their registered deadlines. |
| Native PK parent recovery and physical derivatives | Four new admitted PK points; full physical and energy-quotient spectra; five standing-component F/H screens | No measured +1 daughter attachment was established. Several near −1 observations require separate BL2 analysis and are not evidence for a one-flight P1 daughter. |

Source-bound summaries and the native saved-only census are retained in [completion audit](../Research_v3/strict_contact_12h_20261009/completion_audits/20261010T065636933/audit.json). Root process exits are recorded in [process receipts](../Research_v3/strict_contact_12h_20261009/root_process_receipts.json); agent-owned receipts accompany their experiments.

## Closest observed native returns

These values are full physical closure defects of finite **off-shell** native returns. They are not periodic solutions, branch assignments, or classified gaits. The required original acceptance tolerance is `1e-8`, together with all eight other gates.

| Input hypothesis | Smallest observed native full13 defect in the root streams | Qualification |
|---|---:|---|
| BG | `1.870076219e-2` | Not closed |
| BE | `3.547729004e-3` | Not closed |
| FG | `2.196304474e-5` | Not closed |
| FE | `9.300096293e-3` | Best observed objective trial was not an accepted optimizer iterate |
| HG | `2.195837885e-5` | Not closed |
| HE | `1.025958597e-3` | Best observed objective trial was not an accepted optimizer iterate |
| Combined F/H (`G`) | `1.567121777e-5` | Not closed; cannot be assigned GG or GE |

Some runs stopped because a complete new derivative could not fit within their remaining slice. Others could not form a converged topology-compatible search model near physical boundaries. Those are distinct stopping conditions; neither is a physical nonexistence result. The trust searches accepted only actual finite native map evaluations with decreasing merit, while undefined trials retained their causes and received no finite penalty.

## Timed predictors and physical rejection

The following are the saved timed nominees selected by a combined closure/path/direction/asymmetry/period ranking. They are **not** the minimum closure over all timed trials. Their negative physical path margins independently prevent admission.

| Source hypothesis | Timed full13 defect | Minimum physical path margin |
|---|---:|---:|
| BG | `6.002e-4` | `-1.027e-3` |
| BE | `6.490e-5` | `-3.216e-6` |
| FG | `6.059e-4` | `-1.517e-4` |
| FE | `1.943e-3` | `-9.255e-5` |
| HG | `1.855e-3` | `-2.240e-4` |
| HE | `3.257e-4` | `-5.628e-5` |
| GG | `2.497e-3` | `-1.012e-5` |
| GE | `6.464e-4` | `-2.614e-4` |

The GE nominee also had actual asymmetry approximately `4.113e-5`, below its registered `1e-4` search floor. The BE margin near `-3.216e-6` belongs to a liftoff endpoint violation; it must not be described as an interior flight grazing minimum.

A separate exact rejected BE timed root had closure around `1.55e-11` but body-apex height approximately `0.9862473294`, paired leg angles approximately `±0.0013708864`, and unit rest lengths. Its all-flight initial state therefore has negative foot clearance, approximately `-0.013751731`. Improving scheduled periodicity cannot repair that geometric violation.

The other paired run retained an accepted callback with composed full13 defect `1.756615e-9`, but its path minimum was still `-0.013746323509`. The recovered last accepted exact-BE paired SQP callback had period `1.36464023174`, actual asymmetry `0.00495294387`, and energy `10.81305331984`. Its independently composed full13 defect was `1.03714e-8`, while its physical path minimum remained `-0.013736904916`. It is not admissible. Returned-final fields were empty/NaN because the optimizer did not return normally; actual saved callback points are identified separately.

## Contact resolution and physical mechanisms

One B trial exposed two early front-foot guard roots at approximately `0.046894026` and `0.048039175`, before the previously scheduled touchdown near `0.594`. Their separation was approximately `0.001145149`; a coarse `.005` step cap could miss the first crossing. Native `.0005` and `.0001` runs resolved the same early contact.

This behavior matches the documented possibility of missing an even number of zero crossings inside a solver step. [MathWorks, ODE Event Location](https://www.mathworks.com/help/matlab/math/ode-event-location.html). The online documentation identifies R2026b; the campaign's controls independently exercised installed R2025b.

`ResolvedODE45_v3` repeats the identical native smooth problem at a smaller step cap only after returned samples expose an earlier directed bracket. It never fabricates an event or changes contact eligibility. It retains an earlier witness across retries. The tested PK reference was unchanged; the B early event times agreed with a fine native reference within approximately `3.1e-13`. The same B trial still failed downstream. Its literal exception was an integration failure caused by a singular stance acceleration at a later unsaved ODE trial stage; the saved post-reset state itself had a safely nonsingular denominator. A strongly outward front radial velocity was also observed, but it is not a recorded accepted-state TensileStance exception.

The retry wrapper detects witnessed brackets, not every possible unsampled excursion. Its current hook uses terminal event channels. Final candidate validation consequently retains independent plain native fine-step replays.

## Newly validated parent evidence

| Actual PK apex horizontal velocity | Actual energy | Period |
|---:|---:|---:|
| `-0.0698232900` | `1.55744640078` | `2.65103487906` |
| `-0.2698232900` | `1.58925452004` | `2.64775923756` |
| `-0.6698232900` | `1.76598617152` | `2.63104040700` |
| `-1.0698232900` | `2.09582537038` | `2.60508640582` |

Each is an original nine-gate admitted PK point. These observable corrections do not by themselves prove an intervening continuation arc or daughter attachment. A further target at horizontal velocity `-1.86982329003` failed integration and was not admitted.

The completed high-energy canonical F/H sector audit found a material multiplier near `+0.969223515` at energy `8.849915`; its distance from +1 substantially exceeded the observed h/h2 discrepancy. Five other standing-component screens showed no +1 approach. Two near −1 observations remained unresolved within empirical refinement error. The new travelling parent at energy `1.76598617152` had F/H multipliers approximately `-1.164253405`. These observations cover the measured points only and establish no global absence of attachments.

## Repairs and limits

- Preserved fixed-size NaN rejection for undefined native optimizer trials, verified in installed MATLAB. No fabricated finite residual or path slack was introduced.
- Repaired numerical trust damping and separated converged one-sided **search** columns from original central-only derivative qualification. No Floquet certificate was inferred from those search matrices.
- Added endpoint-capable path minima and hard linearized nonzero B-amplitude constraints. Every accepted original-map or first-return predictor step was explicitly labeled.
- Fixed the recovered first-return B reporting-field mismatch, preserving its executed source and actual failure. Native saved-checkpoint serialization and static checks passed; no search was rerun during recovery.
- Repaired top-level PSS `Integration` arguments in research wrappers. `ODEOptions` and `ODESolver` belong to the delegated map's settings; plain top-level fields must pass the option parser. Native parser controls passed without ODE evaluation. Historical snapshots and numerical outcomes remain intact.
- `MaxWallSeconds` alone is not a hard whole-service ODE deadline. Delegated research maps retain explicit deadline callbacks for initial evaluation and replay. This prospective limit must be handled before resuming any nondelegated checker with plain integration settings.
- The shared admission adapter passed a known-PK positive control through all nine original gates and two independent plain ode45 replays at MaxStep `.0005` and `.00025`. An FG input hypothesis still produced actual PK classification, never an FG publication.

The main unexecuted experiments are larger same-word BE amplitude continuation, torsional-stiffness predictor homotopy followed by return to the exact principal parameters, extension of the distinct canonical153 oscillator, and further correction of the preserved first-return B point. Opposite relative F/H sector phases and disconnected/contact-word basins remain incompletely explored. Prepared code or setup audits are not counted as execution.

## Preservation and reproducibility

The recovery audit matched **534 protected files, 98 core source files and ten retained canonical/master artifacts** against the immutable campaign baseline. Six retained artifacts are canonical datasets; four are old campaign masters. The protected `SLIP_Quadruped` tree and principal physical rules were unchanged during this campaign.

A fresh repository working-path size audit found **zero files at or above 100,000,000 bytes**, excluding `.git`. The largest working-path file was 88,398,547 bytes. Executed attempts, primary traces, exact parameters, source snapshots, failures, and actual process receipts remain in the research tree. Source repairs preserve original bytes and record a new source epoch. No commit or push was made.

Principal evidence:

- [Native completion and preservation audit](../Research_v3/strict_contact_12h_20261009/completion_audits/20261010T065636933/audit.json)
- [B contact and correction findings](../Research_v3/strict_contact_12h_20261009/grazing_contact/Grazing_Contact_Findings_v3.md)
- [Preserved accepted first-return B resume point](../Research_v3/strict_contact_12h_20261009/grazing_contact/post_campaign_audits/20261010T065543407/immutable_resume_candidate.mat)
- [Native PK parent and spectrum recovery audit](../Research_v3/strict_contact_12h_20261009/native_branch_search/postcampaign_audit_20261010T065910515524/audit.json)
- [Paired SQP recovery report](../Research_v3/strict_contact_12h_20261009/sqp_feasibility/Paired_SQP_Recovery_Audit_v3.md)
- [Root process completion receipts](../Research_v3/strict_contact_12h_20261009/root_process_receipts.json)
- [Native option-parser repair controls](../Research_v3/strict_contact_12h_20261009/post_campaign_API_controls/20261010T065842423/audit.json)
- [Working-path size audit](../Research_v3/strict_contact_12h_20261009/preservation_progress/20261010_file_size_audit.json)
- [Primary-source methodology notes](../Research_v3/strict_contact_12h_20261009/literature/Primary_Source_Strict_Contact_Recovery_Methods_v3.md)
