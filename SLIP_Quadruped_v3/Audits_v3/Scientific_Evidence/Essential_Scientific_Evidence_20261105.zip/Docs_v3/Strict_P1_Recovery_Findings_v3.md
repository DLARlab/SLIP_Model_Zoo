# Strict v3 P1 recovery, 9 October 2026

The requested target is the unchanged **strict autonomous v3 contact model**, following the user's final policy selection. This follow-up produced six freshly admitted PK samples and no accepted BG, BE, FG, FE, HG, HE, GG or GE daughter. The missing daughter network remains unresolved. These results neither establish nonexistence nor certify a new bifurcation connection.

The six PK samples are retained in their source-bound research epochs. They are additional interior samples, not an extension beyond the previously stored PK energy maximum, and have not been merged into the canonical GUI dataset. Existing P1/P2 branch datasets, old experiment masters and source fixtures retain their bytes. No compatibility-model dataset was published.

## What the diagnosis established

Native MATLAB comparisons of nine representative complete cycles across all eight legacy families showed that the continuous equations and touchdown/liftoff resets agree with v2 under the explicit coordinate conversion. Every checked scheduled stance interval was compressive. Every representative also had virtual swing-foot penetration before its scheduled touchdown; two had upward-pointing swing legs. Strict v3 instead takes the earlier enabled downward contact crossing, whose correctly reset stance leg may immediately extend. This explains the retained tensile-stance failures without changing a force/reset sign or admitting tensile contact.

The derivation and observations are in [Contact_Viability_Derivation_v3.md](../Research_v3/legacy_adaptation_fix/dynamics_diagnosis/Contact_Viability_Derivation_v3.md). The [contact-policy explanation](V2_and_V3_Contact_Policies_v3.md) distinguishes model assumptions, shooting equalities and path constraints.

## Completed search results

| Method | Observed result | Interpretation |
|---|---|---|
| Eight converted legacy seeds with a bounded first-root diagnostic extension | Zero finite initial return residuals; geometry or integration failures before a useful return | The extension did not provide a Newton starting point. It was diagnostic only; strict final admission was mandatory. |
| Native restricted PK continuation with qualified warm matrix | Five PK points at energies 8.8524363–8.8542484 passed all nine unchanged service gates; independent full closure 6.46e-12–1.77e-11 | Additional strict PK samples; no daughter or attachment. |
| Coupled common-pronk state/time shooting and independent strict return | Energy 8.86 passed all nine gates; full closure 4.70e-13 | One additional strict PK sample. |
| The same coupled shooting at energies 8.88, 8.90, 8.95 and 9.00 | Scheduled residuals below 5e-15, but each nominee failed strict initial swing-clearance admission | Tiny shooting residual alone is insufficient for the strict model. This rejects these nominees, not every possible orbit at those energies. |
| Common-pronk zero-clearance solve | Scheduled grazing candidate at energy 8.87565664895851, residual 4.44e-15; strict BL return rejected `ChartOccurrenceLost` | A mathematical scheduled-cycle grazing candidate, not an admitted orbit, certified physical endpoint or regular Floquet bifurcation. |
| Low-energy asymmetric native correction | A retained finite closure norm decreased from 0.04012774 to best recorded 0.01353105; last recorded base 0.01397171 | Nine Jacobian epochs, eight classically reliable; root did not converge. Final correction/admission also failed. |
| Four asymmetric coupled state/time trials, signed pitch ±0.04 at two PK sources | Final shooting norms 0.0263–0.0301 after 603 calls each | No converged predictor and no strict daughter admission. |
| Four qualified native fore/hind quotient spectra on distinct recorded PK components | Selected real multipliers nearest +1: approximately 0, 0.175795, 0.799496 and 0.972714 | No sampled +1 crossing bracket. Comparing distinct stored components does not establish connectivity. |
| A traveling PK from the distinct `P1/PIP_n0` source | Fore/hind quotient mode −1.0000116332 | A period-doubling candidate to investigate; one sample is not a crossing or bifurcation certificate. |

The additional `P1/signed_PIP_2` point passed a fresh strict return, closure 1.19e-12. Its derivative audit stopped at the registered deadline with an incomplete fine matrix; no reliable spectrum is claimed from it. The asymmetric root's original final derivative lost three columns with wrapped integration failures near its deadline. Its retained causes do not prove a physical boundary or a wall-only cause. The separate final service also recorded an explicit wall-budget exception.

## Evidence and reproducibility

- [First-root extension registration, outcomes and actual process completion](../Research_v3/legacy_adaptation_fix/extended_first_root/20261009T122501367/summary.json): eight registered trials completed in about 15.27 seconds; native session 90544, exit 0. The 1,200-second cap was not exhausted.
- [PK continuation and quotient findings](../Research_v3/legacy_adaptation_fix/strict_native_search_bifurcation/Strict_PK_Fore_Hind_Quotient_Findings_v3.md): approximately 895.7 seconds charged to its original fresh 900-second experiment. Sources, failed preparation, partial matrices and actual process receipts are retained.
- [Coupled common-pronk shooting](../Research_v3/legacy_adaptation_fix/native_coupled_shooting/20261009T123803431/summary.json): native session 79374, exit 0; 60.2805 seconds. Individual MAT files retain nominees, optimizer results, strict service results and exact source hashes.
- [Grazing solve](../Research_v3/legacy_adaptation_fix/native_grazing/20261009T124145231/summary.json): native session 57290, exit 0. The driver reports 13.6382 seconds before final packaging; the invocation measured about 15.959 seconds. The MAT artifact retains the strict rejection.
- [Asymmetric coupled shooting](../Research_v3/legacy_adaptation_fix/native_LR_shooting/20261009T125031318/summary.json): native session 96013, exit 0; 164.8500 seconds. Together with the preceding shooting and grazing invocations, this used about 241.1 seconds of the registered 600-second shooting allocation. All registered cases completed; the allocation was not exhausted.
- The [native asymmetric correction report](../Research_v3/legacy_adaptation_fix/strict_native_search/Strict_Native_Shape_Recovery_Result_v3.md) links the initial pilot, source-bound qualified low-damping root, retained Jacobians, final service and saved-data diagnosis. The conservative planned bound was 876.82 seconds of a fresh 900-second allocation; exact total actual elapsed was not retained. The initial public-finalization call failed because it supplied an unsupported `ODEOptions` field; the follow-up used the existing delegated-map interface. That API error is separate from the unsuccessful numerical correction.

Only the predictor evaluator uses explicitly prescribed contact times. Its native equations and resets were independently compared against v2, and its identity explicitly excludes principal-model admission. Every potentially successful candidate must pass a fresh strict autonomous return and the unchanged nine service gates. Invalid evaluations are not replaced with invented residuals. No physical gate was weakened to publish a missing family.

The full compatibility conversion was interrupted when the user selected strict recovery. Its [cancellation record](../Research_v3/legacy_adaptation_fix/complete_branch_validation/20261009T121943195/CANCELLED.md) preserves the exact earlier source and process receipt. The unused public compatibility adapter was removed.

## Implementation and checks

`ContinuousDynamics_v3.evaluate` now returns immediately after producing the vector field when its second diagnostic output is not requested. The equations and physical checks are unchanged. Nine independently checked initial states produced bitwise-identical one-output/two-output vector fields. The [periodic-solver validation](../Research_v3/legacy_adaptation_fix/native_solver_gates/20261009T121451916/solver_validation_summary.json), native session 28020, exit 0, passed all six grouped cases: known solutions, meaningful correction, fixed-energy/augmented systems, failed imported seed, tolerance/finalization behavior, and marked-occurrence/multiple-cover controls.

A separate saved-data correction fixes swapped front/hind left/right mode labels in `SummarizePKSpectrumGeometry_v3`. The corrected native support follows `[BL BR FL FR]`; no matrix, multiplier, eigenvector or acceptance threshold changes. Historical numerical summaries remain intact. The [new versioned audit](../Research_v3/legacy_adaptation_fix/pattern_label_correction/Pattern_Label_Correction_Findings_v3.md) verifies the change with zero integrations or derivative probes.

The next scientific step remains a source-connected strict daughter solve or a qualified crossing/grazing analysis with independent admission. The measured −1 mode warrants a separate period-doubling investigation; it cannot substitute for the requested P1 BG/BE attachment.
