# Four-tranche completion and working-path verification

Verified 2026-10-09 08:13:26 UTC with native MATLAB R2025b.

All four independent 10,800-second numerical allocations are exhausted. Final publications, actual GUI callbacks and the post-cleanup native audit passed. **The full requested gait network remains unestablished.** Budget exhaustion does not prove that unresolved branches do not exist.

| Tranche | Experiment | Actual charged seconds | Objective-evaluation lower bound | Scientific report |
|---|---|---:|---:|---|
| A | `round4_10800` | 10821.163100 | 3175 | [Results](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Docs_v3/round4_10800_Scientific_Results_v3.md) |
| B | `round5_10800` | 10835.828322 | 3210 | [Results](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Docs_v3/round5_10800_Scientific_Results_v3.md) |
| C | `round6_10800` | 10808.814331 | 1252 | [Results](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Docs_v3/round6_10800_Scientific_Results_v3.md) |
| D | `round7_10800` | 10803.901651 | 1559 | [Results](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Docs_v3/round7_10800_Scientific_Results_v3.md) |

The allocations remain separate. Cooperative numerical-call overshoot is recorded; startup, analysis, GUI and publication time were not added to the numerical ledgers. A retains an unknown original process exit, B retains its original failed finalizer and observed successful report-only recovery, and C/D retain their observed successful finalizer exits. The actual all-four GUI and post-cleanup processes exited 0.

## Loadable study datasets

Open `SLIP_Quadruped_GUI_v3`, select the P1 or P2 folder, then load a named MAT file. Native verification exercised file-open callbacks, both folder-selection callbacks, tail-record selection, rendering, scatter/component mapping and preservation of the full stored orbit.

| Study | Dataset | Stored records | Components |
|---|---|---:|---:|
| P1 | [C1_PK_10_20_2.mat](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P1_Single_Flight_Phase_Continua/C1_PK_10_20_2.mat) | 177 | 39 |
| P1 | [C1_USBL1_10_20_2.mat](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P1_Single_Flight_Phase_Continua/C1_USBL1_10_20_2.mat) | 1 | 1 |
| P1 | [C1_PIP_10_20_2.mat](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P1_Single_Flight_Phase_Continua/C1_PIP_10_20_2.mat) | 18 | 6 |
| P2 | [C2_OSBL2_10_20_2.mat](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P2_Double_Flight_Phase_Continua/C2_OSBL2_10_20_2.mat) | 29 | 8 |
| P2 | [C2_UBL2_10_20_2.mat](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P2_Double_Flight_Phase_Continua/C2_UBL2_10_20_2.mat) | 3 | 3 |
| P2 | [C2_PIP_10_20_2.mat](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/P2_Double_Flight_Phase_Continua/C2_PIP_10_20_2.mat) | 18 | 6 |

The total 246 counts records per file, including repeated seeds/source records and the exact 18-record shared one-flight `C2_PIP` copy. It is not a count of distinct cycles or gait families. All dataset names use C1 for P1 and C2 for P2 with parameters 10/20/2.

P1 has PIP and PK evidence; BG/BE/FG/FE/HG/HE/GG/GE branches and their requested attachments remain unresolved. P2 has the shared PIP reference and qualified unclassified two-flight samples; these are not relabeled B2. B2 → F2_L/F2_H → G2 ancestry remains unresolved, and no unsupported canonical aliases were created.

D recorded one separately registered, qualified ordered PK continuation increment and three fresh source records: two ordinary PIP parent references and one unclassified standing two-flight sample. The early legacy PK-only section of the frozen D report counts a narrower continuation service; its later typed roadmap section records the separate PK increment. Frozen scientific reports were preserved.

## Cleanup and retention

Exactly 374 reviewed test/control and duplicate-storage files were removed, totaling 800,619,145 bytes. Core modules, native numerical results, actual audits, failed scientific attempts and source epochs were retained. The protected 534 outside files, including 528 legacy files and eight legacy `.DS_Store` files, remain exact. The external legacy roadmap was read-only.

The 27 original raw MAT files were archived byte-for-byte under their corresponding study `Bifurcation_Audits/Raw_Dataset_Archive` folders. The active SHA-bound read index resolves their original logical paths. P1/P2 roots now contain exactly the six named catalog datasets. Migration completed once; the subsequent GUI recovery reused it and invoked no migration, readiness scan, physics or continuation.

All working-path files excluding `.git` are strictly below 100,000,000 bytes. No modifiable cache files remain; the eight protected legacy `.DS_Store` files and a zero-byte archived actual interrupted-write artifact were intentionally retained. No commit or push was performed.

## Actual verification receipts

- [All-four rendered GUI audit](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/round7/gates/actual_final_raw_GUI_recovery/20261009T080346223_5c5e55fc-d7d6-49ed-9bb4-41932b920fa3/all_four_GUI/all_four_GUI_receipt.json)
- [Post-cleanup native counts and retention audit](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/round7/gates/actual_postcleanup_size_and_publication/20261009T081129312_e3b9045b-2dd2-4663-bb73-929bd81a61db/audit.json)
- [Observed native post-cleanup exit](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/round7/gates/actual_postcleanup_size_and_publication/20261009T081129312_e3b9045b-2dd2-4663-bb73-929bd81a61db/actual_root_native_process_completion.json)
- [Exact cleanup disposition](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/round7/gates/final_exact_cleanup/20261009T080744397681/cleanup_disposition.json)
- [Raw relocation map](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Audits_v3/Raw_Dataset_Locations/migrations/20261009T074910391_f9805acd-a2f4-453d-87ee-3e9523658531/Raw_Dataset_Relocation_v3.md)
- [D detailed findings](/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Docs_v3/round7_10800_Progress_Findings_v3.md)
