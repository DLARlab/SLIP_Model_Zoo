# Continuation tranche round5_10800 executed research

Starting commit `3e4d3115340a765808c5a3092f84905aa11037ae`; MATLAB 25.2.0.3177638 (R2025b) Update 5, MACA64. New experiment `round5_10800`.

Status: **total_budget_exhausted**. 10835.828 / 10800 seconds charged across 18 invocations. Function evaluations: 3210 (exact: 0). New distinct continuation points: 6. Executed research rounds: C, B, A.

The earlier exhausted checkpoint, registration, source fixtures and scientific artifacts are read-only references. Execution completion is separate from a bifurcation or ancestry claim. The requested network remains unresolved until independently gated typed edges cover it.

| Task | Round | Attempts | State | Scientific evidence | Wall seconds | New points |
|---|---|---:|---|---|---:|---:|
| solver_validation | gate | 0 | accepted | exact_source_bound_predecessor_gates_reused_no_new_maps | 0.000 | 0 |
| signed_PIP_2 | A | 1 | partial_checkpoint | numerically_supported_restricted_attachment | 917.351 | 2 |
| signed_PIP_3 | A | 1 | partial_checkpoint | restricted_spectral_candidate_with_executed_daughter_attempts | 885.168 | 2 |
| PK_continuation_m1 | B | 2 | partial_checkpoint | saved_PK_endpoint_full_spectrum_requested | 902.786 | 3 |
| PK_continuation_p1 | B | 2 | partial_checkpoint | saved_PK_endpoint_full_spectrum_requested | 886.829 | 3 |
| front_coupled | C | 1 | partial_checkpoint | full_front_coupled_center_trials_qualified_numerical_research | 2399.145 | 0 |
| source17_B2 | B | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| opposed_spectral_scan | A | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| measured_BL2 | B | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| source_evidence_labels | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| exact_source_B2_30 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| exact_source_B2_35 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| opposed_capped_metric | C | 3 | accepted | actual_full13_capped_left_metric_candidate_correction | 2455.925 | 1 |
| source35_BL2_common_C1 | A | 0 | pending | source35_col67_BL2_recorded_common_C1_actual_autonomous_B2_hypothesis | 0.000 | 0 |
| roadmap_C2_B2 | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 9.700 | 0 |
| roadmap_C2_F2_L | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 3.880 | 0 |
| roadmap_C2_F2_H | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 2.985 | 0 |
| analytic_PIP_parent_samples | A | 1 | accepted | actual_analytic_PIP_parent_samples | 163.975 | 13 |
| roadmap_C1_BG | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 4.982 | 0 |
| roadmap_C1_FG | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 2.444 | 0 |
| roadmap_C1_HG | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 2.568 | 0 |
| roadmap_C1_GG | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 1.853 | 0 |
| roadmap_C1_FE | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 2.567 | 0 |
| roadmap_C1_HE | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 1.820 | 0 |
| roadmap_C1_GE | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 1.798 | 0 |
| roadmap_off_apex_C1_BE | A | 1 | retryable_failure | exact_source_phase_ingestion_without_connectivity_certificate | 3.152 | 0 |
| constructed_PK_E10p83_v4p2 | A | 1 | retryable_failure | actual_constructed_pronk_correction_without_component_attachment_certificate | 6.255 | 0 |
| constructed_PK_E10p83_v4p4 | A | 1 | retryable_failure | actual_constructed_pronk_correction_without_component_attachment_certificate | 4.916 | 0 |
| event_time_PK_BE_col1_two_hypotheses | A | 1 | retryable_failure | scheduled_predictor_then_autonomous_physical_admission | 31.989 | 0 |
| general_BL2_PAL_p1 | A | 1 | explicit_unresolved_obstruction | actual_full_physical_BL2_PAL_segment_no_restricted_family_or_attachment_certificate | 317.471 | 0 |
| PK_growth_m1_arc015 | A | 1 | partial_checkpoint | actual_PK_arcs_recovered_after_summary_initialization_failure | 1826.269 | 6 |

Full coverage, causal repair records, and task artifacts: `Research_v3/round5/experiments/round5_10800/task_queue_full.json`. Typed graph: `Research_v3/round5/experiments/round5_10800/graph/index.json`. Historical backlog remains explicitly retained.
