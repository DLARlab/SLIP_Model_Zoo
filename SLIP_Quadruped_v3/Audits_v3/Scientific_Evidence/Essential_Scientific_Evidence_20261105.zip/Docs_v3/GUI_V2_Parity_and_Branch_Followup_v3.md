# GUI v2 parity and branch follow-up

The GUI interaction and animation defects are repaired and verified in native MATLAB R2025b. The requested missing P1 gait branches remain unrecovered; this is a scientific result gap, not a dataset-discovery defect. All changes are under `SLIP_Quadruped_v3`. Legacy sources and the four completed 10,800-second research studies are preserved.

## Restored GUI behavior

- **Select Folder** lists the direct MAT datasets automatically; **Plot**, **Plot All**, dataset deletion and parameter filters follow the v2 workflow. Choose the P1 or P2 folder, then a dataset in the dropdown and click Plot.
- State-based gait identification or consistent saved per-record gait metadata supplies the colors. PK uses the exact v2 blue `[0, 0.447, 0.741]`; filenames never supply scientific classifications. Click a stored point or ordered branch component to select its solution without a synchronous numerical replay. Component boundaries remain separate.
- Info has six independent axis-limit inputs, aspect-ratio controls, camera angles and presets. Numeric fields track toolbar changes; manual bounds survive redraws.
- Solve retains Entry/Current/Tune tables, numerical settings, noise and prediction. Editing Tune updates the prediction and distance display. Predicted and solved candidates have independent Plot/Remove controls. Removing one preserves unrelated plots; removing the solved marker retains its accepted numerical result for Save and Solver-source selection. Source-point selection preserves candidate snapshots; deleting their source clears them.
- The 1D, Para and 2D tabs use a validated seed pair. 1D continues at the existing parameters; Para transports and reconditions the pair at a target; 2D does this for each target in its list. Each family is continued in both directions. Three-dimensional previews show `(dx,dphi,y)` with gait colors. Checkpoints retain separate components and a frozen numerical policy; resumed transport cannot silently adopt later editor settings or overwrite the editor's solved result.
- Oscillator playback advances the branch index and updates selection graphics without rebuilding the stored branch. Animation, trajectories, GRF, oscillator plots, GIF/MP4/keyframes and playback settings use the selected orbit. Selecting or scrubbing another orbit invalidates stale frames.
- Close/delete cleanup is idempotent. Idle timers remain stopped, active integration yields for cancellation, and close requests cancel numerical work before deleting owned timers and figures. Close does no checkpoint I/O. Pause/Stop requests bypass the numerical busy guard, take effect at the current step boundary and remain visible after status refresh.

The initial reproducer established the folder-button, color, branch-click and axis-field defects. Idle close itself took 0.1761 seconds; difficult idle quitting was not reproduced. Active cancellation and timer cleanup were nevertheless missing and are now directly checked.

## Graphics adaptation

All nine legacy GraphicFunctions are copied byte-for-byte with SHA-256 provenance in `2_Graphic_ToolBox/Graphics_v3/V2_Source_Provenance`. Their native v3 adaptations restore torso geometry/stripes, six-part spring/piston legs, layering, ground hatching, paired trajectory limits and v2 GRF styles. Actual v3 state, parameter, event and contact histories determine geometry and stance; oscillator plots include every stance interval, including multiple P2 intervals.

The [graphics audit](../2_Graphic_ToolBox/Graphics_v3/Audits_v3/20261009_v2_port_after/audit.json) passed in actual native process **61112, exit 0**: zero reference torso/leg vertex discrepancy, correct parts/layers, zero stance-foot ground error and preserved event frames. Standalone animation closed in 0.1941 seconds.

## Final native GUI verification

Actual native process **96895 exited 0** after all three final GUI audits completed with unchanged bound sources:

| Executed check | Result |
|---|---|
| [Control delivery](../Research_v3/gui_parity_followup/control_audits/20261009T103342568_4b1be014-5ff7-4d58-98c8-60b1c373034e/audit.json) | Actual Pause/Stop buttons deliver requests during a busy numerical map and retain visible status after refresh; Tune edits/redraws, hidden damping cleanup and oscillator branch-handle reuse pass. |
| [Six canonical datasets](../Research_v3/gui_parity_followup/gui_audits/20261009T103409088_a76fbd44-c436-48bd-bcf6-2f4b70867f3d/audit.json) | Folder listing, PK blue, scatter/component clicks, separate limits, stored animation and all three tabs' validated-pair requirement pass. Playback close 0.2208 seconds; actual integration close 0.1358 seconds; no leaked timers. |
| [Visual interaction/media](../Research_v3/gui_parity_followup/visual_audits/20261009T103442185_eb33efec-6998-4d2a-9227-0da643430f2d/audit.json) | Named panel captures, three GIF frames, three decoded MP4 frames, three oscillator GIF frames, stale-frame prevention, candidate controls, toolbar sync and active-playback resize pass. Direct deletion 0.2739 seconds; no leaked timers. |

The OS folder picker was not automated; its visible button and actual shared post-selection callback were verified. Earlier visual audits stalled specifically at MATLAB `exportapp` while oscillator playback was active. Stage markers confirmed that axis updates and resize had returned. The final audit resizes during playback, pauses through the real oscillator button, then captures the stable window. Interrupted audit epochs retain their actual exit-130 receipts and are not represented as passes; the user's interactive MATLAB session was untouched.

The [independent candidate audit](../Research_v3/gui_parity_followup/candidate_audits/20261009T103013028_cec0b3b7-2861-450d-adb7-aa5beb1e52ba/audit.json) passed in **97100, exit 0**, including a freshly corrected PK residual of 6.9066e-10, independent ownership, source-selection behavior and Save ignoring an active prediction.

The [final family replay/resume audit](../Research_v3/gui_parity_followup/family_resume_audits/20261009T103154910_9da342de-34df-47be-a8af-b0e481f84528/audit.json) passed in **3887, exit 0**. All six retained baseline/transported records passed fresh replay under final sources, with maximum residual 8.1454e-10. Copied-checkpoint resume, separate bidirectional components, frozen solver policy, editor-candidate preservation and a fresh both-seed parameter transport step passed; close during transport took 0.0370 seconds and preserved the checkpoint hash. This final refresh computed zero new PAL points and published zero canonical branches. Earlier native PAL/transport execution and its mixed-source hash failure are retained separately, rather than relabeled as a source-bound pass. Pitch-inertia variation of this zero-pitch PK control validates the interface; it does not establish a new gait or a nontrivial two-dimensional manifold. See [controller audit details](../Research_v3/gui_parity_followup/GUI_Controller_Parity_Audit_v3.md).

Final GUI/controller/layout source hashes are recorded in these audits. The native 14-state/10-parameter editor and detected read-only timing table replace v2 scheduled-contact timing unknowns. Native damped Newton remains the default; explicit fsolve LM/dogleg and LM-only Jacobian scaling are available. Parallel finite differences are omitted because client-side cancellation state cannot be honored by worker copies. These are explicit v3 differences, not claims of identical legacy numerical semantics.

## Actual branch availability

| Study | Direct dataset | Stored records | Components |
|---|---|---:|---:|
| P1 | `C1_PK_10_20_2.mat` | 177 | 39 |
| P1 | `C1_USBL1_10_20_2.mat` | 1 | 1 |
| P1 | `C1_PIP_10_20_2.mat` | 18 | 6 |
| P2 | `C2_OSBL2_10_20_2.mat` | 29 | 8 |
| P2 | `C2_UBL2_10_20_2.mat` | 3 | 3 |
| P2 | `C2_PIP_10_20_2.mat` | 18 | 6 |

These are 246 stored records, not 246 distinct cycles. C2 PIP is the exact shared one-flight C1 parent copy. USBL1, OSBL2 and UBL2 remain descriptive unclassified standing motions. **BG/BE, FG/FE, HG/HE, GG/GE and B2/F2/G2 have not been established as admitted native branches.** They are not hidden by the GUI, and failed or unclassified results were not renamed to fill the requested network.

The four prior 10,800-second allocations are exhausted and frozen; their [scientific results](Four_Tranche_Completion_and_Working_Path_Verification_v3.md) remain unchanged. Additional finite follow-ups retain separate method/source hashes and exact failures:

| Native experiment | Observed result |
|---|---|
| Two-sign finite-amplitude correction, **49057, exit 0** | Negative: physical inadmissibility after 391.6181 service seconds, full closure 3.82215e-4, 77 known evaluations. Positive: wall limit during derivative refresh after 1200.6197 seconds, closure 3.81806e-4, 226 known evaluations. Zero admitted daughters. |
| Explicit LM/scaling/damping correction, **86991, exit 0** | 1200.3315 service seconds, 225 known evaluations/222 recorded maps. Valid objective-base closure improved from 3.82215e-4 to 1.88539e-4, but the amplitude constraint still had residual 8.24447e-6 and the outgoing derivative was incomplete. Zero admitted daughters. |

These experiments retain the coupled state/free-energy correction, full thirteen-component closure and all original nine admission gates. The sampled PK fore/hind multiplier is 0.9726409944, with no qualified critical +1 kernel, so finite-amplitude correction is not an attachment certificate. The best moved objective base is preserved exactly; it is neither an accepted optimizer iterate nor an admitted periodic orbit.

The [independent diagnosis](../Research_v3/gui_parity_followup/branch_recovery/independent_diagnosis.md) distinguishes the narrow native flight chart, absent qualified critical direction, specific incompatible legacy scheduled states and unresolved later derivative obstruction. Legacy BG column 11, for example, has all four native swing guards approximately -0.01220998. This rules out that particular seed under the principal compressive/first-eligible-contact model; it does not prove that no other native BG orbit exists. [Recovery evidence and retained partials](../Research_v3/gui_parity_followup/branch_recovery/BD1_Recovery_Status_v3.md) give exact states, provenance and remaining requirements.

## Shared solver repairs and preservation

RootSolver's optional `FsolveAlgorithm`, `FsolveInitialDamping` and `FsolveScaleProblem` preserve the old numerical policy when empty. Explicit LM is required for damping/scaling. Invalid objective coordinates, original stacks and derivative probes remain distinct. The incomplete-Jacobian handoff found during LM recovery is repaired: nonfinite, wrongly sized or explicitly unreliable derivatives are refused before MATLAB can form an all-NaN trial. Explicit Jacobians without reliability metadata retain the existing trust convention.

Focused native process **27427 exited 0**, reproducing and rejecting the later incomplete derivative while preserving the finite base/report. Default/LM regression also passed, with the original default root, exit and 17 evaluation count. These algebraic checks made no physical admissions. Final RootSolver SHA is `4a70f1ebff190c9ef42bc9cf1238da95cee037cef4b413e7833a253b1c0c847e`.

The [final canonical solver validation](../Research_v3/gui_parity_followup/solver_gates/20261009T102852364995Z/solver_validation_summary.json) passed all seven gates in native process **87233, exit 0**. The checks include known PIP/PK closure, meaningful nonlinear correction, fixed-energy/augmented constraints, failed-seed preservation, tolerance/finalization behavior, marked-occurrence/repeated-cycle rejection and failure-diagnostic preservation. The [actual completion receipt](../Research_v3/gui_parity_followup/solver_gates/20261009T102852364995Z/actual_process_completion.json) confirms all 47 bound source snapshots, five historical inputs, four frozen masters and both routing files remained unchanged. Passing these checks establishes the exercised solver behavior, not the existence of the missing branches.

The [final working-path audit](../Research_v3/gui_parity_followup/working_path_audits/20261009T104019775888/audit.json) passed after all numerical writers stopped. It checked 36,618 files outside Git metadata: no file was at or above 100,000,000 bytes, and the largest was 88,398,547 bytes. No modifiable cache candidates remained. All 534 protected files, six canonical datasets and four original research masters matched their recorded hashes; no new files appeared outside v3. Eight pre-existing Finder cache files inside the protected legacy folder were retained in accordance with the user's exclusion. The audit performs no scientific calculations or deletions.
