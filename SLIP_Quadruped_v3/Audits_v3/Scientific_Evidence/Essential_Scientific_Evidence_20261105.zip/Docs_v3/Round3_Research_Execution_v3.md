# Round 3 executed research

Starting commit `3e4d3115340a765808c5a3092f84905aa11037ae`; MATLAB 25.2.0.3177638 (R2025b) Update 5, MACA64. New experiment `post_3e4d311_research`.

Status: **total_budget_exhausted**. 10805.138 / 10800 seconds charged across 13 invocations. Function evaluations: 2601 (exact: 0). New distinct continuation points: 6. Executed research rounds: A, B, C.

The earlier exhausted checkpoint, registration, source fixtures and scientific artifacts are read-only references. Execution completion is separate from a bifurcation or ancestry claim. The requested network remains unresolved until independently gated typed edges cover it.

| Task | Round | Attempts | State | Scientific evidence | Wall seconds | New points |
|---|---|---:|---|---|---:|---:|
| solver_validation | gate | 2 | accepted | solver_gates_passed | 474.749 | 0 |
| measured_BL2 | B | 2 | accepted | measured_constraints_admit_known_standing_BL2_family_attachment_unresolved | 2383.576 | 8 |
| front_coupled | C | 3 | partial_checkpoint | full_front_coupled_center_trials_qualified_numerical_research | 3651.226 | 0 |
| PK_continuation_m1 | B | 2 | partial_checkpoint | continued_branch_attachment_unresolved | 659.324 | 1 |
| PK_continuation_p1 | B | 2 | partial_checkpoint | continued_branch_attachment_unresolved | 280.501 | 1 |
| opposed_spectral_scan | A | 1 | partial_checkpoint | full_physical_opposed_BL2_energy_leaf_scan | 1503.096 | 0 |
| source17_B2 | B | 2 | partial_checkpoint | source17_PK_seed_to_two_flight_B2_hypothesis_accepted_orbits_attachment_unresolved | 1526.796 | 1 |
| signed_PIP_2 | A | 2 | partial_checkpoint | independently_closed_restricted_daughter_records | 182.664 | 2 |
| signed_PIP_3 | A | 1 | partial_checkpoint | independently_closed_restricted_daughter_records | 143.062 | 2 |
| source_evidence_labels | A | 1 | accepted | versioned_source_evidence_labels_reconciled | 0.145 | 0 |

Full coverage, causal repair records, and task artifacts: `Research_v3/round3/experiments/post_3e4d311_research/task_queue_full.json`. Typed graph: `Research_v3/round3/experiments/post_3e4d311_research/graph/index.json`. Historical backlog remains explicitly retained.
