# Continuation tranche round7_10800 executed research

Starting commit `3e4d3115340a765808c5a3092f84905aa11037ae`; MATLAB 25.2.0.3177638 (R2025b) Update 5, MACA64. New experiment `round7_10800`.

Status: **total_budget_exhausted**. 10803.902 / 10800 seconds charged across 18 invocations. Function evaluations: 1559 (exact: 0). New distinct continuation points: 0. Executed research rounds: A.

The earlier exhausted checkpoint, registration, source fixtures and scientific artifacts are read-only references. Execution completion is separate from a bifurcation or ancestry claim. The requested network remains unresolved until independently gated typed edges cover it.

| Task | Round | Attempts | State | Scientific evidence | Wall seconds | New points |
|---|---|---:|---|---|---:|---:|
| solver_validation | gate | 0 | accepted | exact_source_bound_predecessor_gates_reused_no_new_maps | 0.000 | 0 |
| signed_PIP_2 | A | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| signed_PIP_3 | A | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| PK_continuation_m1 | B | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| PK_continuation_p1 | B | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| front_coupled | C | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| source17_B2 | B | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| opposed_spectral_scan | A | 0 | partial_checkpoint | predecessor_working_state_retained_fresh_execution_pending | 0.000 | 0 |
| measured_BL2 | B | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| source_evidence_labels | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| exact_source_B2_30 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| exact_source_B2_35 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| opposed_capped_metric | C | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| roadmap_C2_B2 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_C2_F2_L | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_C2_F2_H | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| analytic_PIP_parent_samples | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| roadmap_C1_BG | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_C1_FG | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_C1_HG | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_C1_GG | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_C1_FE | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_C1_HE | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_C1_GE | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_off_apex_C1_BE | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| constructed_PK_E10p83_v4p2 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| constructed_PK_E10p83_v4p4 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| event_time_PK_BE_col1_two_hypotheses | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| general_BL2_PAL_p1 | A | 0 | explicit_unresolved_obstruction | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_growth_m1_arc015 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| PK_endpoint_spectrum_C_B_final_80cbd2a08f50 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| PK_endpoint_spectrum_C_B_final_retry_h1e4_step00125_80cbd2a08f50 | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_growth_round6_10800_m1_point_000007_80cbd2a0 | A | 0 | explicit_unresolved_obstruction | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_endpoint_spectrum_C_intermediate_point_000003_60d48bdc71f3 | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_endpoint_spectrum_C_highest_point_000005_60d48bdc71f3 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| PK_endpoint_spectrum_C_highest_retry_h3e5_step00125_60d48bdc71f3 | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_failed_probe_trace_C_highest_y_354d1bc03440 | A | 0 | explicit_unresolved_obstruction | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_growth_round6_10800_m1_point_000005_60d48bdc_resolution_72bd1282 | A | 0 | explicit_unresolved_obstruction | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_endpoint_spectrum_C_resolved_highest_point_000002_916bbc6b2bb4 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| PK_endpoint_spectrum_C_resolved_highest_retry_h1e5_step00125_916bbc6b2bb4 | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_growth_round6_10800_m1_point_000002_916bbc6b_resolution_1cd1c93a | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| PK_all_stance_C_shallow_predictor3_native_BL1 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| PK_endpoint_spectrum_C_h1e5_highest_point_000003_11a36ae7e308 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| PK_endpoint_spectrum_C_h1e5_highest_retry_h3e6_step00125_11a36ae7e308 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_03 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_05 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_07 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_06 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_08 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_04 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_02 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_01 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_off_apex_round6_10800_fresh_pool_15 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_10 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_09 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| roadmap_round6_10800_fresh_pool_13 | A | 0 | retryable_failure | predecessor_best_state_retained_successor_method_registration_required | 0.000 | 0 |
| analytic_PIP_parent_tail_C_E1p06168502751 | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| analytic_PIP_parent_tail_C_E1p55516525164 | A | 0 | accepted | completed_predecessor_evidence_retained_no_fresh_execution | 0.000 | 0 |
| PK_growth_round7_10800_m1_point_000003_11a36ae7_inheritance_e1803696 | A | 1 | explicit_unresolved_obstruction | fresh_orientation_unresolved_diagnostic_only | 250.524 | 0 |
| PK_endpoint_spectrum_D_adaptive_h1e5_h3e6_step00125_11a36ae7e308 | A | 1 | accepted | fresh_full_PK_endpoint_energy_leaf_spectrum_complete | 682.683 | 0 |
| PIP_full_spectrum_D_C_tail_n0_2ff696528d19 | A | 1 | accepted | fresh_full_PIP_parent_energy_leaf_spectrum_complete | 179.413 | 0 |
| PIP_full_spectrum_D_C_tail_n1_838d3c044c95 | A | 1 | accepted | fresh_full_PIP_parent_energy_leaf_spectrum_complete | 289.437 | 0 |
| PK_growth_round7_10800_m1_point_000003_11a36ae7_inheritance_e1803696_D_stencil_revision_a2df1db1 | A | 1 | explicit_unresolved_obstruction | actual_ordered_PK_growth_with_unresolved_far_component_attachment | 1864.885 | 1 |
| PIP_flip_daughter_D_C_n0_bound_m1_6bf2e59ad2ca | A | 1 | retryable_failure | numerical_or_driver_failure | 2.261 | 0 |
| PIP_flip_daughter_D_C_n0_bound_m1_6bf2e59ad2ca_path_r1 | A | 1 | accepted | qualified_full_physical_daughter_samples_attachment_unresolved | 37.563 | 1 |
| roadmap_round7_10800_fresh_pool_13 | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 68.859 | 0 |
| PIP_flip_daughter_D_C_n0_full_front_m1_6bf2e59ad2ca | A | 1 | partial_checkpoint | actual_PIP_flip_signed_fsolve_target_unresolved | 1208.629 | 0 |
| PIP_flip_daughter_D_C_n0_full_front_p1_6bf2e59ad2ca | A | 1 | partial_checkpoint | actual_PIP_flip_signed_fsolve_target_unresolved | 1212.806 | 0 |
| PK_endpoint_spectrum_D_new_point_000002_eab240410a6e | A | 1 | retryable_failure | fresh_full_PK_endpoint_spectrum_unresolved_distinct_causal_restart_required | 516.164 | 0 |
| PK_endpoint_spectrum_D_new_point_000002_retry_h3e6_h1e6_eab240410a6e | A | 1 | retryable_failure | fresh_full_PK_endpoint_spectrum_unresolved_distinct_causal_restart_required | 653.149 | 0 |
| PIP_flip_daughter_D_C_n0_full_front_m1_a1e2_h1e5_6bf2e59ad2ca | A | 1 | partial_checkpoint | actual_PIP_flip_signed_fsolve_target_unresolved | 2408.347 | 0 |
| roadmap_round7_10800_fresh_pool_14 | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 643.594 | 0 |
| roadmap_round7_10800_fresh_pool_12 | A | 1 | retryable_failure | source_informed_autonomous_replication_without_connectivity_certificate | 182.202 | 0 |
| roadmap_round7_10800_fresh_pool_11 | A | 1 | partial_checkpoint | source_informed_autonomous_replication_without_connectivity_certificate | 581.166 | 0 |
| analytic_PIP_parent_tail_D_E1p075 | A | 1 | accepted | actual_analytic_PIP_parent_samples | 10.994 | 1 |
| analytic_PIP_parent_tail_D_E1p076 | A | 1 | accepted | actual_analytic_PIP_parent_samples | 11.225 | 1 |

Full coverage, causal repair records, and task artifacts: `Research_v3/round7/experiments/round7_10800/task_queue_full.json`. Typed graph: `Research_v3/round7/experiments/round7_10800/graph/index.json`. Historical backlog remains explicitly retained.
