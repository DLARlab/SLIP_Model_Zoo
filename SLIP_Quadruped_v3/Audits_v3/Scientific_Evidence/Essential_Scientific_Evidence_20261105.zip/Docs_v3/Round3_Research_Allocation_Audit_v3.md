# Round3 research allocation audit

The allocation change separates actual continuation, one full physical endpoint spectrum, and a derived correction attempt within the existing global campaign budget. The numerical equations, physical acceptance gates, derivative reliability rules, and critical-sector selection remain unchanged. This audit executes no dynamics.

The captured dispatcher epoch is `edbc7207a52ca4c779e0b0bfad4e5495df4b944d92806559c1fc5224bc3b10ce`. Its [saved source](../Research_v3/round3/audits/allocation_policy_20261008T063209592/ExecuteRound3Target_v3.m.txt), [native zero-map check](../Research_v3/round3/audits/allocation_policy_20261008T063209592/native_zero_map.json), [allocation audit](../Research_v3/round3/audits/allocation_policy_20261008T063209592/allocation_audit.json), and [current core hash check](../Research_v3/round3/audits/allocation_policy_20261008T063209592/current_core_hash_check.json) are versioned independently of the running experiment. Native MATLAB found the same three pre-existing static notices, with no new findings. All ten canonical gated numerical source hashes match the current relocated sources.

| Task slice | Continuation cap | Spectrum allocation | Nominal time after spectrum |
| --- | ---: | ---: | ---: |
| PK, 1,000 s | 240 s | 410 s, latest endpoint only | 350 s |
| Opposed BL2, 1,500 s | — | 800 s, one actual BL2 point | 700 s |
| PK, 300 s | 240 s | Deferred below its 350 s launch reserve | Actual remainder |

These are prospective allocation caps. Startup, branch snapshots, diagnostic export, and actual map completion consume time. A daughter attempt starts only with at least 350 actual seconds left and qualified reliable saved full physical energy-leaf diagnostics. The existing 720-second threshold for two signed corrections is unchanged; the opposed task's nominal 700-second remainder therefore permits one sign unless the spectrum completes early. A qualified spectrum does not establish a bifurcation crossing, attachment, or new gait family.

A precise boundary issue was identified in this captured epoch: PK remainders between 350 and 700 seconds allocate exactly 350 seconds to the scan. The scan's own registration has already consumed positive time when it checks its 350-second launch reserve, so that allocation skips the numerical scan. A small prospective margin such as 360 seconds addresses the launch boundary at the next dispatcher epoch. The limitation is recorded here; no completed spectrum is inferred.

Empty scan records remain incomplete. The saved-data critical-sector auditor handles an empty record array, and the daughter selector returns an explicit unresolved result with `executed=false`. The opposed task explicitly reports a pending resource reservation when no spectrum record completes. Continuation progress remains whatever the actual branch checkpoint proves.
