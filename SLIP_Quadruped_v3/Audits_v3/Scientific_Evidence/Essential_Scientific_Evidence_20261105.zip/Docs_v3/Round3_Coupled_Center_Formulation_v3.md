# Round3 coupled-center front-twisted formulation

The new experiment keeps every remaining physical direction at prescribed front amplitude. It uses twelve unknowns and twelve equations, with separate right domain and left residual bases. The thirteen original unscaled equations remain available to the shared physical acceptance service. This is a numerical reformulation of the actual BL1 front-twisted shooting problem, followed by actual BL2 finalization and fresh replay; it is not a smooth normal-form or center-manifold claim.

The native MATLAB saved-data preparation and affine contract audit passed. No new return-map simulations were used in those audits. Large nonlinear trials are dispatched by the newly registered Round3 research runner, and their actual reports determine success or failure; these algebraic audits alone do not establish a daughter or an attachment.

## Bound evidence and dimensions

The preparation uses the admitted full physical common-C1 n0 derivative, the exact saved front retry and its forensics, and the previously qualified common-pronk critical predictor. Their immutable source paths and SHA256 values are recorded in [`coupled_center_geometry.json`](../Research_v3/round3/theory/coupled_center_geometry.json), with the matrices and original candidate in its MAT companion. `V3Path_v3` resolves historical paths to their organized locations.

The previous thirteen-column experiment remains unaccepted: its smallest singular value is `4.42745952e-9`, empirical matrix refinement discrepancy is `2.13357771e-5`, and actual BL2 closure is `5.49199832e-8` against `1e-8`. All columns passed their individual common-C1 tests. The weak right vector aligns with the common-pronk critical direction, almost all residual lies in the weak left direction, and the formal undamped correction has norm approximately `3.8366`. These observations are preserved in [Front_Twisted_Retry_Forensics_v3.md](Front_Twisted_Retry_Forensics_v3.md); a smaller stopping tolerance alone does not resolve that inverse direction.

On the flight apex section, horizontal translation is gauged and vertical velocity is zero. The remaining state coordinates are

```
u = x([2,3,5,6,7,8,9,10,11,12,13,14])    (12 entries)
w = (u,E)                                (13 entries)
```

Let `P1` be the actual one-BL return and `S` exchange the FL/FR angle-rate pairs. The original [`TwistedReturnFamilyResidual_v3`](../4_Solution_Management/TwistedReturnFamilyResidual_v3.m) solves

\[
F(w;a)=\begin{bmatrix}
 R\,[P_1(x(u))-Sx(u)]\\
 H(x(u))-E\\
 n^T(w-w_0)-a
\end{bmatrix}=0.
\]

`R` selects eleven independent state closure components, omitting the regular energy-pivot height component. In flight, the actual [energy implementation](../1_Dynamic_Frameworks/Dynamics_v3/QuadrupedEnergy_v3.m) has `H=y+(dx²+dy²+j_pitch*dphi²)/2` and `∂H/∂y=1`. Energy preservation and closure of the other components therefore imply the omitted height closure in the exact map. In finite numerics, omitted height, all full twisted components, and actual BL2 closure are separately checked; the energy identity never excuses a finite closure error. The front swap preserves this energy and the marked BL identity.

| Formulation | Unknowns | Equations |
| --- | ---: | ---: |
| Original full `(u,E)` shooting at signed amplitude | 13 | 11 twisted closure + 1 energy + 1 amplitude |
| New exact affine amplitude domain | 12 | 11 twisted closure + 1 energy |
| Independent physical acceptance data | — | All 13 original unscaled equations, plus full twisted/BL2 closure and fresh physical checks |

The amplitude equation is prescribed exactly in the domain rather than discarded from a general thirteen-dimensional trial. No other direction is fixed or removed.

## Domain and codomain construction

Let `D=diag(max(1,abs(w0)))` and let `Q` have orthonormal columns spanning `ker(nᵀD)`, so `Q` is 13×12. The saved actual parent derivative supplies

\[
J_0=\begin{bmatrix}R(M-S_u)&0\\D_uH&-1\end{bmatrix},
\qquad A_0=J_0DQ=U\Sigma V^T.
\]

Here `M` is the unrestricted physical twelve-coordinate BL1 derivative at the admitted parent, `S_u` is the corresponding front permutation, `V` acts on the state-coordinate domain, and `U` acts on the residual codomain. They are different spaces. The experiment rearranges the unresolved singular directions first, with the same index permutation applied to corresponding left and right vectors, and uses

\[
w(z;a)=w_0+a\frac{n}{n^Tn}+Bz,\quad B=DQV_{\mathrm{ordered}},\quad z\in\mathbb R^{12}.
\]

All twelve columns of `B` remain. Two are numerically unresolved center coordinates and ten are resolved complementary coordinates at the measured threshold. `E` remains an unknown through this lift; no common-pronk coordinate is set to zero. [`CoupledCenterFrontResidual_v3`](../Research_v3/round3/theory/CoupledCenterFrontResidual_v3.m) solves

\[
\widehat F(z;a)=G\,U_{\mathrm{ordered}}^T F_0(w(z;a))=0,
\]

where `F0` consists of the eleven original twisted closure equations and original energy equation. The first two projected equations are the corresponding numerical cokernel equations; the other ten are range equations. Every row is retained. `G` is diagonal with finite positive gains, so the zero set is unchanged. No assertion identifies a kernel complement with `range(J0)`.

MATLAB's [SVD documentation](https://www.mathworks.com/help/matlab/ref/double.svd.html) defines the independent left/right factors; [null documentation](https://www.mathworks.com/help/matlab/ref/null.html) describes numerical orthonormal null bases. Here the amplitude normal is an exact declared linear functional, whereas small singular values of the physical derivative are uncertain numerical observations.

## Rank uncertainty and the full two-return center

[`PrepareCoupledCenterFront_v3`](../Research_v3/round3/theory/PrepareCoupledCenterFront_v3.m) compares the saved fine and coarse actual physical derivatives in the new scaled amplitude-tangent domain. It obtained:

| Native saved-data result | Value |
| --- | ---: |
| Two smallest amplitude-domain singular values | `3.96268256e-10`, computed zero |
| Smallest resolved amplitude-domain singular value | `0.845231452` |
| Fine/coarse amplitude-domain spectral-norm discrepancy | `2.36660612e-6` |
| Numerical unresolved threshold | `2.36660612e-5` |
| Number of unresolved directions retained | 2 of 12 |
| Amplitude-normal orthogonality error `‖nᵀB‖∞` | `5.55111512e-17` |
| Left-basis orthogonality error | `2.54147315e-15` |
| Common-pronk vector distance from numerical center span | `5.93418769e-9` |
| Parent front-swap commutator norm | `6.28080420e-12` |

The numerical zero is not an exact-nullity certificate. The threshold uses ten times an empirical refinement discrepancy, not an interval enclosure. For matrices whose actual perturbation is bounded, singular-value perturbations are bounded by its spectral norm; the [primary numerical linear algebra account by Higham](https://nhigham.com/2021/05/04/singular-value-inequalities/) states this inequality. The measured refinement difference here does not establish a rigorous derivative-error bound, and neither small singular value resolves an invertible denominator below that difference.

The same saved actual derivative, restricted through the full physical energy tangent basis, gives numerical small-singular-direction counts of one for `M_leaf-I`, four for `M_leaf+I`, and five for `M_leaf²-I`. Its empirical fine/coarse discrepancy is `2.36660612e-6`; it has no exact multiplicity certificate. For an **exact** real matrix, the identity

\[
\ker(M^2-I)=\ker(M-I)\oplus\ker(M+I)
\]

follows directly: if `(M²-I)v=0`, then `v+=(v+Mv)/2` and `v-=(v-Mv)/2` satisfy `Mv+=v+`, `Mv-=-v-`, and `v=v++v-`; the two kernels intersect only at zero. This identity does not turn a finite near-unit cluster into an exact kernel. The actual front-twisted amplitude problem is independently assembled above, rather than borrowing the entire five-dimensional two-return center or a restricted principal block.

## Conditioning and predictors

The positive row denominators are the maximum of the projected saved failed-Jacobian row norm, projected parent refinement discrepancy, and global empirical error floor. The latter is `2.13357771e-5`, inherited from the thirteen-column forensic estimate. The weakest row gain is consequently capped at approximately `46869.6311`; it never divides by `4.43e-9`. This balances the coupled numerical equations for the existing damped Newton method. Invertible row scaling cannot improve physical derivative accuracy or prove rank, and all acceptance tolerances remain unscaled.

The initial registered experiment nevertheless has demanding **weighted root stopping** thresholds, `FunctionTolerance=1e-12` and `ResidualAcceptanceTolerance=1e-11`. With the largest gain, the latter requires the corresponding left-projected unscaled equation below `2.13358e-16`. This is a stopping requirement in addition to the independently declared physical gates, and must be compared against actual integration residual noise before choosing the next experiment. Pure saved-geometry analysis gives `K=norm(U*diag(1./g),inf)=9.6120373705`; thus `norm(weightedResidual,inf)<=1.04036e-9` is already sufficient to bound every original twelve-component unscaled equation by `1e-8`. A prospective `5e-10` threshold would imply an unscaled bound `4.80602e-9`, provided its transformed empirical residual noise is appreciably smaller. A derivative refinement discrepancy alone does not measure that residual noise. If this condition fails, changing row gains or integration settings requires a new recorded experiment rather than a claimed converged root. The initial adapter also omits a `ClosureTolerance` property, so current shared-root finalization falls back to its stricter weighted acceptance threshold for BL2 closure; that extra restriction must be recorded and corrected in a subsequent source epoch, without relaxing independent physical gates.

The derivative engine remains the established [`EventOrderChartJacobian_v3`](../3_Numerical_Continuation/1_Root_Solving/EventOrderChartJacobian_v3.m), applied to all twelve new domain directions. The analytically prescribed amplitude removes one finite-difference coordinate; no weak remaining column is skipped and no zero derivative is fabricated. Relative steps are `1e-4` and `5e-5`, with the existing common-C1 chart and refinement checks. This avoids introducing an additional unvalidated derivative engine. New per-trial FD reports, map counts, and final weighted SVD diagnostics are retained. There is no claimed derivative-accuracy or speed improvement before the measured experiments.

The initial predictor comes from the exact original saved best iterate. Its offset from the parent is split into front-swap even and odd parts. At new signed amplitude `a` relative to old `a0`, it uses `(abs(a/a0))²*even+(a/a0)*odd`, then restores the declared amplitude to roundoff. This is a prospectively registered predictor ansatz, not a proved asymptotic expansion. An optional coefficient multiplies `abs(a)` times the previously justified common-pronk predictor direction. It changes the initial guess only; both numerical center coordinates remain unknown. Local state-coordinate and energy search distances are `.05` and `.02`; leaving those registered bounds yields a real failed trial, never an invented residual.

## Executable interface and physical gates

The existing Round3 dispatcher calls

```matlab
result = RunCoupledCenterFront_v3(task,cfg,outputDirectory,maxWallSeconds);
```

`task.front_amplitudes` defaults to `[1e-3,-1e-3]`; `task.pronk_coefficient` defaults to zero. Later registered experiments can select signed `5e-4` / `2.5e-4` amplitudes or nonzero common-pronk predictors after inspecting actual failures. A 1800-second task slice allocates approximately 880 seconds per sign after overhead. This is based on the previous approximately 469-second thirteen-coordinate trial and is a budget allocation, not a convergence guarantee.

The driver freezes original coordinates, source hashes, current code hashes, affine geometry, integration settings, predictor and campaign domain before simulation. It calls the same [`PeriodicSolutionSolver_v3`](../3_Numerical_Continuation/1_Root_Solving/PeriodicSolutionSolver_v3.m) as correction, continuation, and GUI workflows. Its adapter exposes:

```
info.physical_residual  = every original unscaled 13-component equation
info.requested_energy   = actual reconstructed unknown E
info.constraint_residual = original signed-amplitude equation
residual.Map             = actual physical BL2 map
```

The shared service independently requires every finite unscaled family component and amplitude within `1e-8`, fresh requested-energy error within `1e-8`, full closure within `1e-8`, energy variation, stance and admissibility checks, primitive labeled identity within the checked bound, and repeat-replay consistency. The correction uses the validated full-angle derivative settings `RelTol=1e-13`, `AbsTol=1e-15`, `MaxStep=.0025`, and `ArmingTolerance=1e-12`. This follows an actual negative derivative control in which coarse default arming produced inadmissible swing-foot penetration; the reliability gates remain unchanged. Fresh replay is independently tighter at `5e-14`, `5e-16`, `.00125`, and arming `1e-13`. Ordinary BL1 closure is never substituted for the front-twisted equation or actual BL2 orbit.

Each sign has its own input, actual shared-service report, original full residual, finite-difference and rank evidence, JSON trial, and checkpoint. Compatible partial checkpoints resume the best twelve-coordinate iterate with a fresh derivative. Code, source, geometry, predictor, domain or tolerance changes require a new registration; the old thirteen-coordinate Jacobian is never reused as a twelve-coordinate matrix. Result counters report fresh-call RootSolver objective/residual-map/Newton deltas and distinguish previously admitted records from newly admitted points. Service prechecks, independent replays and partial-trajectory diagnostics are additional physical simulations, so the root map count is explicitly labeled a lower bound on all physical simulation calls. An accepted point still has unresolved ancestry until shrinking-amplitude attachment and trajectory comparisons establish it. Phase-equivalent signs must not be counted as distinct cycle classes without those comparisons.

The native [`affine_contract_audit/audit.json`](../Research_v3/round3/theory/affine_contract_audit/audit.json) confirms both sign adapters construct, both transformations have rank twelve, and their linear amplitude/orthogonality errors are at roundoff. It records zero new simulations and makes no nonlinear-success claim. Actual trials and all later failures remain in the new experiment output tree; the original failed front retry is unchanged.

## Executed front A and the subsequent B method

The actual A campaign completed both signed `±.001` trials, each with zero accepted Newton steps and two Jacobian evaluations. The positive trial used 161 objective calls / 117 residual-map calls; the negative used 161 / 116. Both rejected all twelve backtracks of a `.02` trust-clipped step, then rebuilt the derivative at unchanged coordinates and reached the wall budget. The positive weighted residual stayed `7.9614580973e-4`, original equation norm `1.6061389414e-8`, and actual BL2 closure `5.4919981476e-8`; the negative values agree within the recorded numerical discrepancies. The initial finite full Jacobian necessarily existed because those backtracks were attempted. Its full matrix and reliability report were not retained by the original last-report-only solver, so the final partial Jacobian does not establish that the first derivative was incomplete.

The saved final FD report additionally contains an accuracy problem before the budget failure. Domain column 3 has relative refinement errors `.00677964525` at `h=1e-4` and `.00169483453` at `h=5e-5`, both above the unchanged `.001` gate. Column 4 has `.00320460391` and `.000801205216`. Their almost fourfold decrease is consistent with the observed central-stencil truncation trend. It is not a measured absolute ODE residual-noise bound. The full diagnostics and frozen A source bytes are in [`front_A_forensics`](../Research_v3/round3/theory/front_A_forensics).

B is separately registered with one `h=2.5e-5` candidate and its internal `h/2=1.25e-5` comparison. This keeps all twelve columns and the `.001` reliability criterion. Every returned or failed derivative epoch is saved by [`RecordedEventOrderChartJacobian_v3`](../Research_v3/round3/theory/RecordedEventOrderChartJacobian_v3.m), which forwards the numerical callback unchanged and adds no evaluations. Each sign takes its own actual A coordinates as the frozen predictor source, applies the already declared even/odd amplitude scaling, and adds the requested `−abs(a)` common-pronk displacement. No center coordinate is constrained or omitted. Later repairs take the actual preceding sign's saved iterate as their source; this is explicit in their registration and source hashes.

The B adapter exposes the base physical `ClosureTolerance=1e-8`, avoiding the initial shared-root fallback to weighted `1e-11`. B's complete stopping settings use `FunctionTolerance=ResidualAcceptanceTolerance=5e-10` and optimality `1e-18`. With the unchanged positive row gains and inverse-transform norm `9.6120373705`, this weighted threshold implies an original twelve-equation bound `4.8060186852e-9`; amplitude and every independent physical gate remain separately `1e-8`. The measured front-swap coordinate consistency error is `3.3087e-24`, transformed residual consistency discrepancy `2.3173440866e-13`, and floating-point output-scale proxy `1.5461446831e-11`. The new threshold exceeds these recorded indicators. Neither indicator controls a common systematic integration bias, and identical cached/baseline residuals do not certify zero noise. The registration expressly records that no independent absolute residual-noise bound is available. Fresh physical acceptance is required; these preparation calculations do not establish a B daughter.

## Complete trajectory equivalence before counting new cycle classes

[`CompareRound3OrbitEquivalence_v3`](../Research_v3/round3/theory/CompareRound3OrbitEquivalence_v3.m) compares a corrected orbit against explicitly supplied full reference orbits. Wrappers can carry `orbit`, `evidence_ids`, `source_path`, and `source_sha256`; every matched reference and merged provenance ID remains in the report. The helper performs no integration. It independently computes primitive period within the existing integer-cover bound, preserves signed primitive drift, compares each leg's complete TD/LO multiplicity and cyclic phase, and audits every recorded guard's mode eligibility, directed crossing, value and actual reset projection. It compares all fourteen interpolated state coordinates and four mode coordinates, including actual left/right event states. Atomic independent-leg batch resets are checked using their own rate projection and full aggregate one-sided trajectories, rather than treating a scalar serialization order as a distinct physical event order.

The permitted group is time phase and horizontal translation, together with BL/BR and FL/FR pair permutations. Within each physical pair the parameter and hip-offset assignments are identical. Inspection of the actual flow, force sums, guards, reset projections and mode transition therefore establishes those pair permutations as symmetries of these components. No spatial reflection is used as a merge action, and opposite PK drift remains distinct. Event-aligned phase candidates are enumerated rather than chosen from an apex distance or descriptive label.

Equivalence is numerical within explicit comparison tolerances: scaled full-state interpolation `1e-6`, primitive period relative to `max(1,T)` and signed drift `1e-7`, event phase `1e-7`, guard/reset `1e-7`. These are comparison tolerances, not relaxed orbit-acceptance tolerances. A clear invariant or full contact-history difference yields `not_equivalent`; unavailable or incomplete full trajectory/guard/reset evidence yields `unresolved`. A match remains a sampled full-cycle statement, not a proof of exact equality.

Native saved-data controls in [`orbit_equivalence_audit`](../Research_v3/round3/theory/orbit_equivalence_audit) match a complete accepted BL2 orbit to itself and the known n0 opposed-spread positive/negative phases under a half-period shift. The latter has scaled trajectory difference `2.65244679e-8` and one-sided event-state difference `6.50868248e-13`; its same-phase comparison fails, as expected. The n1 opposed-spread resonance is distinct by primitive-period difference approximately `2.6366`. The opposite signed n0 PK daughters remain distinct by signed primitive drift difference approximately `.0015`, despite matching periods; their opposite-drift relation is recorded without merging them. Missing full trajectory data remains unresolved. All controls use saved full data and make no new return-map calls.

## Full physical critical-sector diagnostics along accepted branches

[`AuditRound3CriticalSectors_v3`](../Research_v3/round3/theory/AuditRound3CriticalSectors_v3.m) consumes a native branch and the actual `spectral_scan.json` path (or a scan structure with an explicit `source_directory`). It requires reliable unrestricted periodic-orbit Floquet eligibility, the complete energy-leaf basis/matrix, and every actual reliable selected FD column. Each result binds the point index, state/mode/parameters/period, spectral source hash, and code source hashes. Missing or unreliable matrices remain unresolved and supply no candidate directions.

The helper excludes the conservative energy normal by the existing physical `ker(DH)` construction; it never deletes the multiplier closest to `+1`. It transports the energy-leaf derivative to coordinates scaled by the full physical base values and retains both original and scaled matrices. Selected FD refinement estimates are converted back to empirical column magnitudes, including the Richardson correction, then propagated through the basis transport. Ten times the resulting empirical matrix floor defines a numerical near-kernel threshold. This is not an interval bound or an exact nullity certificate.

For each of `M_leaf-I` and `M_leaf+I`, the complete SVD retains all geometric near-kernel right vectors and independent left cokernel vectors. Right vectors are lifted to fourteen physical components. Left vectors are extended as minimum-norm covectors from the physical energy tangent; they are not identified with the right domain vectors. The actual equation residual on every proposed direction is saved.

A common-pronk invariant interpretation additionally requires the base on the separately proved synchronous, zero-pitch, matched-parameter, centered-COM manifold and small actual subspace leakage. The helper intersects the full near-kernel candidate span with this physical tangent and retains the remaining full directions that have a transverse component. It does not assume the orthogonal complement is itself invariant. At standing opposed-spread bases, mere common-pronk-pattern overlap remains a diagnostic and cannot justify a restricted return-map label.

The native [`critical_sector_control/audit`](../Research_v3/round3/theory/critical_sector_control/audit) uses the freshly qualified full Floquet gate at `E=1.1`. Its empirical scaled matrix floor is approximately `2.84153e-7`; threshold `2.84153e-6`. It finds zero near-kernel directions for both signs and returns no candidate. All analysis uses saved matrices and zero new simulations. No critical parameter, nondegeneracy, new daughter, stability change, or graph attachment is established by this helper alone.

## Actual signed correction from scanned physical candidates

[`RunRound3SpectralDaughters_v3`](../Research_v3/round3/theory/RunRound3SpectralDaughters_v3.m) accepts `(record,cfg,out,maxWallSeconds)`. The record explicitly selects an immutable branch MAT artifact, aggregate `critical_sectors.mat`, point index, multiplier sign and geometric direction index. The critical-sector audit must have been generated from the branch **file path**, so its SHA binds the actual branch bytes. Signed amplitudes, target gait/flight hypotheses and optional numerical bracket evidence are frozen before a solve; a bracket is not presented as a refined critical parameter.

At a proved common-pronk parent it selects the full near-kernel directions with transverse components. At other independently admitted parents, including opposed-spread BL2, it selects the full fourteen-component physical near-kernel vectors and leaves pattern overlap diagnostic. It imposes no invariant restriction, deletes no unresolved center and retains every state-and-energy family equation. No near-kernel direction is available when the actual scan is unreliable or has no qualified candidate; that case receives no fabricated direction or solve.

Each sign calls the existing `RunFamilySectorCorrections_v3` in its own directory with a fair share of the remaining budget, tight physical correction/replay settings, and a fresh validated derivative. A `+1` candidate uses the actual parent BL occurrence. A `-1` candidate doubles that occurrence: the original primitive parent remains independently admitted evidence, while its doubled trial-policy representation is correctly labeled a multiple-cover predictor. The daughter must independently pass primitive physical acceptance. The currently validated derivative chart supports flight-to-flight BL1/BL2; BL4 or a nonairborne base requires a further chart rather than an altered occurrence.

Current-source hashes, full geometric vectors, empirical error floors, parent data, physical settings and signed constraints are prospectively registered. Compatible partial runs resume their physical iterate and rebuild the derivative. Counters are fresh-call deltas; completed failed trials remain separate from accepted records. Accepted children receive full saved-cycle comparisons against the primitive parent and supplied reference orbits. The driver leaves distinct gait-class counts and ancestry unclaimed. Native MATLAB syntax analysis passed with zero simulations; actual signed trials belong to the shared campaign, not to this saved-data preparation.
