function audit=ReportC1BranchStorage20261026()
% Read-only stored-record census; no map, integration, solving or classification.
timer=tic;v='/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3';addpath(v);V3AddPaths_v3(v);n=fullfile(v,'Research_v3','C1');out=fullfile(n,'Audits','C1_Branch_Storage_Report_20261026');assert(~isfile([out '.mat'])&&~isfile([out '.json']));
audit=struct('schema','C1-read-only-stored-branch-report-v1','started_utc',stamp(),'completed',false,'new_integrations',0,'new_root_solves',0,'new_classifications',0,'scope','Saved records and explicit edges only. Shared exact numerical record identity plus complete equal stored return configurations joins storage graphs; this is not new continuation, replay qualification or a bifurcation proof. Graph vertices are stored occurrences including duplicates; native identity is exact numerical initial/period/policy record identity, not whole-trajectory equality or uniqueness of physical cycles.','published',{{}},'files',{{}},'points',{{}},'failures',{{}},'excluded',{{}},'connections',{{}},'summary',struct());
pts={};edges=zeros(0,2);fileRows={};sources={};
folder=fullfile(v,'P1_Single_Flight_Phase_Continua');d=dir(fullfile(folder,'*.mat'));
for f=1:numel(d)
 check();file=fullfile(d(f).folder,d(f).name);S=load(file);names=fieldnames(S);b=[];if isfield(S,'solutions')&&isfield(S,'components'),b=S;end;if isfield(S,'solutions')&&isfield(S,'branch')&&isstruct(S.branch)&&isfield(S.branch,'components'),b=S.branch;b.solutions=S.solutions;end;
 for j=1:numel(names),q=S.(names{j});if isstruct(q)&&isscalar(q)&&isfield(q,'solutions')&&isfield(q,'components'),b=q;break;end;end
 assert(~isempty(b),'Report:Bundle','Expected named dataset bundle');row=struct('file',file,'sha256',RoundSHA256_v3(file),'stored_records',numel(b.solutions),'components',numel(b.components),'component_summary',{{}},'top_level_variables',{names});
 for j=1:numel(b.components),cc=b.components(j);ind=cc.record_indices;rr=struct('component',j,'kind',get(cc,'record_kind',''),'records',numel(ind),'indices',ind,'E',[],'meanU',[],'period',[]);E=[];U=[];T=[];for a=ind(:).',o=b.solutions{a};if isstruct(o)&&isfield(o,'orbit'),o=o.orbit;end;T(end+1)=o.period;U(end+1)=o.stride_displacement(1)/o.period;E(end+1)=QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter);end;rr.E=bd(E);rr.meanU=bd(U);rr.period=bd(T);row.component_summary{end+1}=rr;end
 audit.published{end+1}=row;fprintf('PUBLISHED %s records=%d components=%d\n',d(f).name,row.stored_records,row.components);clear S b
end
entries=dir(fullfile(n,'Results','*.mat'));[~,order]=sort({entries.name});entries=entries(order);
for f=1:numel(entries)
 check();name=entries(f).name;file=fullfile(entries(f).folder,name);
 if contains(lower(name),'checkpoint')||contains(lower(name),'.pending')||contains(lower(name),'index'),audit.excluded{end+1}=struct('file',file,'reason','checkpoint/pending/index; not a branch store');continue;end
 offset=numel(pts);edgeOffset=size(edges,1);
 try
 head=whos('-file',file);if ~any(strcmp({head.name},'branch_index')),audit.excluded{end+1}=struct('file',file,'reason','no branch_index; not part of compact-store graph');continue;end
 before=dir(file);sourceSHA=RoundSHA256_v3(file);ix=BranchSolutionFile_v3.index(file);S=load(file);assert(isequaln(ix,S.branch_index));assert(strcmp(ix.storage_version,'BranchSolutionFile_v3:2'));assert(iscell(ix.points)&&iscell(ix.edges));offset=numel(pts);row=struct('file',file,'stored_points',numel(ix.points),'stored_edges',numel(ix.edges),'owned_components',0,'graph_components',0,'labels',struct(),'E',[],'meanU',[],'components',{{}},'metadata',ix.metadata,'source_stable',false);
 ids={};labels={};E=[];U=[];
 for k=1:numel(ix.points)
 check();p=ix.points{k};assert(p.index==k);o=S.(p.solution_variable);r=S.(p.report_variable);assert(isa(o,'HybridOrbit_v3'));
 c=get(r,'classification',struct());label=txt(get(c,'canonical_point_label',''));if isempty(label),label=txt(p.classification);end;fam=family(label);rp=struct();complete=false;try,[~,ev]=RecordedReturnPolicy_v3(r);rp=ev.configuration;complete=ev.complete;catch,end;try,compatibility=MatchingReturnSection_v3(o,o,{r,r});complete=complete&&compatibility.compatible;catch,complete=false;end
 x=o.initial_state(:);x(1)=0;key='';if complete,key=jsonencode(struct('chart',o.section_chart,'configuration',rp,'parameter',o.parameter(:),'initial_mode',o.initial_mode(:)));end
 point=struct('file',file,'local_index',k,'owner',txt(p.component_identity),'stored_label',label,'family',fam,'native_ID',OrbitContentIdentity_v3(o),'policy_complete',complete,'policy_key',key,'E',p.nativeE,'meanU',p.signedmeanU,'period',o.period,'apex_dx',o.initial_state(2),'initial_state',x.','initial_mode',o.initial_mode(:).','parameter',o.parameter(:).','provenance',p.provenance,'saved_accepted',isequal(get(r,'accepted',false),true),'saved_all_nine',nine(get(r,'acceptance_gates',struct())));
 pts{end+1,1}=point;ids{end+1}=p.component_identity;labels{end+1}=label;E(end+1)=p.nativeE;U(end+1)=p.signedmeanU;
 end
 le=zeros(numel(ix.edges),2);for k=1:numel(ix.edges),e=ix.edges{k};assert(e.from>=1&&e.to<=numel(ix.points)&&e.from<e.to);le(k,:)=[e.from,e.to];end;edges=[edges;le+offset];
 if ~isempty(ix.points)
 G=graph(le(:,1),le(:,2),[],numel(ix.points));bins=conncomp(G);row.graph_components=max(bins);row.owned_components=numel(unique(ids));
 for k=1:max(bins),sel=find(bins==k);rr=struct('indices',sel,'points',numel(sel),'edges',sum(ismember(le(:,1),sel)&ismember(le(:,2),sel)),'labels',{unique(labels(sel))},'E',bd(E(sel)),'meanU',bd(U(sel)));row.components{end+1}=rr;end
 end
 ul=unique(labels);for k=1:numel(ul),field=matlab.lang.makeValidName(ul{k});if isempty(field),field='EMPTY';end;row.labels.(field)=sum(strcmp(labels,ul{k}));end
 row.E=bd(E);row.meanU=bd(U);after=dir(file);row.source_stable=isequal(before.bytes,after.bytes)&&isequal(before.datenum,after.datenum)&&strcmp(sourceSHA,RoundSHA256_v3(file));row.source_sha256=sourceSHA;assert(row.source_stable);fileRows{end+1}=row;sources{end+1}=file;fprintf('STORE %s points=%d edges=%d graph_components=%d\n',name,row.stored_points,row.stored_edges,row.graph_components);clear S
 catch problem,pts=pts(1:offset);edges=edges(1:edgeOffset,:);audit.failures{end+1}=struct('file',file,'identifier',problem.identifier,'message',problem.message);fprintf('FAILED %s %s\n',name,problem.message);end
end
check();audit.files=fileRows;audit.points=pts;joinEdges=zeros(0,2);
if ~isempty(pts)
 allIDs=cellfun(@(p)p.native_ID,pts,'UniformOutput',false);[uniqueIDs,~,groups]=unique(allIDs);
 for k=1:numel(uniqueIDs)
 members=find(groups==k);if numel(members)<2,continue;end
 used=false(size(members));
 for a=1:numel(members)
 if used(a),continue;end;one=pts{members(a)};same=[];
 for b=a:numel(members),two=pts{members(b)};if one.policy_complete&&two.policy_complete&&strcmp(one.policy_key,two.policy_key)&&isequaln(one.initial_state,two.initial_state)&&isequaln(one.parameter,two.parameter)&&isequaln(one.initial_mode,two.initial_mode)&&isequaln(one.period,two.period),same(end+1)=members(b);used(b)=true;end;end
 if numel(same)>1&&numel(unique(cellfun(@(p)p.file,pts(same),'UniformOutput',false)))>1
 refs=cellfun(@(p)struct('file',p.file,'point',p.local_index,'family',p.family,'stored_label',p.stored_label,'owner',p.owner,'E',p.E),pts(same),'UniformOutput',false);audit.connections{end+1}=struct('native_ID',uniqueIDs{k},'points',{refs},'exact_initial_parameter_mode_period_and_complete_return_configuration',true,'new_physical_edge_created',false);joinEdges=[joinEdges;[repmat(same(1),numel(same)-1,1),same(2:end).']];
 end
 end
 end
 allE=[edges;joinEdges];families={'PK','BG','BE','FG','FE','HG','HE','GG','GE','OTHER'};summaries={};
 for k=1:numel(families)
 mask=cellfun(@(p)strcmp(p.family,families{k}),pts);sel=find(mask);z=struct('family',families{k},'stored_occurrences',numel(sel),'files',0,'stored_edges',0,'storage_components_before_shared_record_join',0,'storage_components_after_shared_record_join',0,'largest_joined_component',0,'E',[],'meanU',[],'joined_components',{{}});
 if ~isempty(sel)
 z.files=numel(unique(cellfun(@(p)p.file,pts(sel),'UniformOutput',false)));e=edges(all(mask(edges),2),:);ae=allE(all(mask(allE),2),:);z.stored_edges=size(e,1);[~,ee]=ismember(e,sel);[~,aa]=ismember(ae,sel);b=conncomp(graph(ee(:,1),ee(:,2),[],numel(sel)));c=conncomp(graph(aa(:,1),aa(:,2),[],numel(sel)));z.storage_components_before_shared_record_join=max(b);z.storage_components_after_shared_record_join=max(c);z.largest_joined_component=max(accumarray(c(:),1));z.E=bd(cellfun(@(p)p.E,pts(sel)));z.meanU=bd(cellfun(@(p)p.meanU,pts(sel)));
 for q=1:max(c),ss=sel(c==q);row=struct('points',numel(ss),'unique_native_records',numel(unique(allIDs(ss))),'files',{unique(cellfun(@(p)p.file,pts(ss),'UniformOutput',false))},'E',bd(cellfun(@(p)p.E,pts(ss))),'meanU',bd(cellfun(@(p)p.meanU,pts(ss))));if numel(ss)>1,z.joined_components{end+1}=row;end;end
 end
 summaries{end+1}=z;
 end
 audit.summary=struct('branch_files',numel(fileRows),'stored_occurrences',numel(pts),'stored_edges',size(edges,1),'cross_file_exact_shared_record_groups',numel(audit.connections),'families',{summaries});
end
audit.completed=isempty(audit.failures);audit.completed_utc=stamp();audit.wall_seconds=toc(timer);save([out '.mat'],'audit','-v7');s=jsonencode(audit);fid=fopen([out '.json'],'w');assert(fid>=0);fwrite(fid,unicode2native(s,'UTF-8'),'uint8');fclose(fid);back=load([out '.mat'],'audit');assert(isequaln(back.audit,audit));assert(isequaln(jsondecode(fileread([out '.json'])),jsondecode(s)));fprintf('REPORT_SUMMARY %s\n',jsonencode(audit.summary));for k=1:numel(fileRows),r=fileRows{k};if r.stored_edges>=10||contains(r.file,'PK'),fprintf('REPORT_FILE %s\n',jsonencode(rmfield(r,'metadata')));end;end;fprintf('C1_STORAGE_REPORT_ACTUAL_RETURN completed=%d files=%d failures=%d wall=%.3f\n',audit.completed,numel(fileRows),numel(audit.failures),toc(timer));
 function check(),assert(toc(timer)<1500,'Report:Budget','Read-only report wall cap');end
end
function x=get(s,k,d),x=d;if isstruct(s)&&isscalar(s)&&isfield(s,k),x=s.(k);end,end
function t=txt(x),t='';if (ischar(x)&&(isrow(x)||isempty(x)))||(isstring(x)&&isscalar(x)),t=char(x);end,end
function f=family(label),a=regexp(label,'^(PK|BG|BE|FG|FE|HG|HE|GG|GE)([0-9]*)$','tokens','once');f='OTHER';if ~isempty(a),f=a{1};end,end
function b=bd(x),x=x(isfinite(x));b=[];if ~isempty(x),b=[min(x),max(x)];end,end
function y=nine(s),keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};y=isstruct(s)&&isscalar(s)&&all(isfield(s,keys));if y,for k=1:numel(keys),y=y&&isequal(s.(keys{k}),true);end;end,end
function s=stamp(),s=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end
