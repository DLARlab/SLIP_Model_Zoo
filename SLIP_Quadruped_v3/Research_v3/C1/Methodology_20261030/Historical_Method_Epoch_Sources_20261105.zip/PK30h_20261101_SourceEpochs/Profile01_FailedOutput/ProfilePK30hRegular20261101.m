function receipt=ProfilePK30hRegular20261101()
%PROFILEPK30HREGULAR20261101 Profile the already admitted regular case only.
% No correction, source append, new admission or historical-clock renewal.
    clock=tic;root=V3Root_v3();base=fullfile(root,'Research_v3','C1');
    source=fullfile(base,'Audits','PK30h_20261101_Campaign.mat');
    output=fullfile(base,'Audits','PK30h_20261101_Regular_Profile.mat');
    stage=[output,'.pending.mat'];
    assert(~isfile(output)&&~isfile(stage),'PK30hProfile:Fresh','Profile output and stage must be fresh.');
    sourceReference=reference(source);codes=codeReferences();
    loaded=load(source,'state');state=loaded.state;
    assert(strcmp(state.schema,'C1-PK-resident-campaign-v1')&&~state.active_run, ...
        'PK30hProfile:Closed','Profile only the closed retained campaign.');
    held=state.runs{1}.cases{1};
    assert(strcmp(held.spec.name,'regular_0062')&&isequal(held.spec.pair,[63 64]) ...
        &&held.native_all_nine&&held.root_api_returned&&held.timely, ...
        'PK30hProfile:Held','Use the retained admitted regular case without reacquisition.');
    old=state.original_budget;
    config=struct('grant_id',old.grant_id,'start_utc',old.start_utc, ...
        'research_deadline_utc',old.research_deadline_utc,'deadline_utc',old.deadline_utc);
    budget=AbsoluteRunBudget_v3(config,old);
    assert(left(budget)>730,'PK30hProfile:WholeFit','Full 600-second diagnostic plus 120-second save margin must fit.');
    audit=struct('schema','C1-PK-held-regular-profile-v1','budget',budget, ...
        'source_reference',sourceReference,'source_code',{codes}, ...
        'held_source_reference',state.runs{1}.source_references{held.spec.source_number}, ...
        'source_pair',held.spec.pair,'source_seed_native_ids',{held.seed_native_ids}, ...
        'held_native_id',OrbitContentIdentity_v3(held.orbit),'completed',false, ...
        'root_calls',0,'source_posthash',false,'fresh_admission_claimed',false, ...
        'profile',struct(),'failure',struct(),'stored_publication_return_observed',false);
    schema=QuadrupedSchema_v3.shared();x=held.orbit.initial_state;
    audit.held_summary=struct('dx',x(schema.State.dx),'marked_height',x(schema.State.y), ...
        'energy',QuadrupedEnergy_v3.evaluate(x,held.orbit.initial_mode,held.orbit.parameter), ...
        'period',held.orbit.period,'mean_U',held.orbit.stride_displacement(schema.TranslationIndex)/held.orbit.period, ...
        'main_trajectory_steps',stepSummary(held.orbit.trajectory.time));
    clear loaded state
    fprintf('C1_PK_REGULAR_PROFILE_BEGIN native_id=%s\n',audit.held_native_id);
    try
        audit.profile=ProfilePeriodicOrbit_v3(held.orbit,held.report, ...
            struct('Budget',budget,'MaxWallSeconds',600));
        audit.completed=audit.profile.completed&&audit.profile.source_unchanged;
        for pass=1:numel(audit.profile.map)
            row=audit.profile.map{pass};
            audit.profile.map{pass}.main_trajectory_steps=stepSummary(row.output.info.trajectory.properties.time);
        end
        for kind={'map','classification'}
            rows=audit.profile.(kind{1});
            if isempty(rows),continue;end
            functions=rows{1}.profile.FunctionTable;
            assert(~any(contains(string({functions.FunctionName}),{'RootSolver_v3','PeriodicSolutionSolver_v3'})), ...
                'PK30hProfile:NoRoot','Diagnostic profiler unexpectedly contains a root/admission service.');
        end
    catch problem
        audit.completed=false;audit.failure=failure(problem);
    end
    verify([codes;{sourceReference}]);audit.source_posthash=true;
    assert(left(budget)>0,'PK30hProfile:Late','Diagnostic must finish before the original science cutoff.');
    audit.elapsed_before_save_seconds=toc(clock);
    sizeInfo=whos('audit');assert(sizeInfo.bytes<1750000000,'PK30hProfile:Headroom','Observed audit size exceeds the conservative stage headroom.');
    audit_digest=C1ScientificDigest_v3(audit);
    save(stage,'audit','audit_digest','-v7');
    check=load(stage,'audit','audit_digest');
    assert(strcmp(check.audit_digest,audit_digest)&&strcmp(C1ScientificDigest_v3(check.audit),audit_digest), ...
        'PK30hProfile:Readback','Complete native profile audit typed readback differs.');
    clear check
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    publicationReturned=true;delete(stage);
    verify([codes;{sourceReference}]);
    receipt=struct('completed',audit.completed,'source_posthash',true,'root_calls',0, ...
        'publication_returned',publicationReturned,'output_reference',reference(output), ...
        'audit_typed_digest',audit_digest,'held_summary',audit.held_summary, ...
        'elapsed_seconds',toc(clock),'failure',audit.failure, ...
        'scope','Profiled pass1 then unprofiled pass2; timings also include warm-up/order effects. Full profiler info and scientific outputs are in the native audit.');
    if isfield(audit.profile,'failure'),receipt.profile_failure=audit.profile.failure;end
    receipt.map=summary(audit.profile,'map');receipt.classification=summary(audit.profile,'classification');
    encoded=jsonencode(receipt);assert(numel(unicode2native(encoded,'UTF-8'))<=30000, ...
        'PK30hProfile:Summary','Bounded profile summary exceeds 30 kB.');
    fprintf('C1_PK_REGULAR_PROFILE_ACTUAL_RETURN %s\n',encoded);
    assert(audit.completed,'PK30hProfile:Incomplete','Profile audit was retained, but the diagnostic did not complete.');
end
function rows=summary(profile,kind)
    rows={};if ~isfield(profile,kind),return;end
    for k=1:numel(profile.(kind))
        item=profile.(kind){k};row=struct('pass',k,'profiled',item.profiled,'seconds',item.seconds);
        if isfield(item,'full13_inf'),row.full13_inf=item.full13_inf;row.main_trajectory_steps=item.main_trajectory_steps;end
        if isfield(item,'stored_output_typed_equal'),row.stored_output_typed_equal=item.stored_output_typed_equal;end
        if item.profiled
            table=item.profile.FunctionTable;[~,order]=sort([table.TotalTime],'descend');heads=cell(min(20,numel(order)),1);
            for j=1:numel(heads)
                f=table(order(j));name=char(f.FunctionName);
                heads{j}=struct('function_name_prefix',name(1:min(160,numel(name))), ...
                    'function_name_characters',numel(name),'calls',f.NumCalls,'reported_total_seconds',f.TotalTime);
            end
            row.top20=heads;row.total_function_rows=numel(table);
        end
        rows{k,1}=row;
    end
end
function out=stepSummary(t)
    dt=diff(t(:));positive=dt(dt>0);n=numel(positive);values=sort(positive);
    tolerance=64*eps(max([1;abs(t(:))]));
    out=struct('scope','Saved main-trajectory positive dt only; excludes BL lookahead.', ...
        'sample_count',numel(t),'positive_dt_count',n,'zero_dt_count',nnz(dt==0), ...
        'negative_dt_count',nnz(dt<0),'reference_step',.001,'near_step_absolute_tolerance',tolerance, ...
        'near_step_count',nnz(abs(positive-.001)<=tolerance),'near_step_fraction',NaN, ...
        'minimum',NaN,'maximum',NaN,'order_quantile_probabilities',[.1 .5 .9 .99],'order_quantiles',NaN(1,4));
    if n>0
        out.near_step_fraction=out.near_step_count/n;out.minimum=values(1);out.maximum=values(end);
        out.order_quantiles=values(max(1,ceil([.1 .5 .9 .99]*n))).';
    end
end
function refs=codeReferences()
    names={'ProfilePK30hRegular20261101','AbsoluteRunBudget_v3','ProfilePeriodicOrbit_v3', ...
        'C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3','OrbitContentIdentity_v3', ...
        'RecordedReturnPolicy_v3','PoincareMap_v3','PoincareSection_v3','HybridSimulator_v3', ...
        'Quadrupedal_Dynamics_v3','ContinuousDynamics_v3','GuardFunctions_v3','ResetMap_v3', ...
        'ModeTransition_v3','QuadrupedSchema_v3','QuadrupedPhysicalChart_v3', ...
        'QuadrupedAdmissibility_v3','QuadrupedEnergy_v3','GaitIdentification_v3', ...
        'PrimitiveCycleCheck_v3','HybridCycleData_v3','GaitSemanticTable_v3','CircularPhase_v3', ...
        'BLMarkedApexReturnPolicy_v3','HybridOrbit_v3','Trajectory_v3'};
    refs=cell(numel(names),1);
    for k=1:numel(names),file=which(names{k});assert(~isempty(file),'PK30hProfile:Provider','Missing %s.',names{k});refs{k}=reference(file);end
    refs{end+1,1}=reference(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function verify(refs)
    for k=1:numel(refs),assert(strcmp(RoundSHA256_v3(refs{k}.file),refs{k}.sha256), ...
            'PK30hProfile:SourceChanged','Consumed source changed: %s',refs{k}.file);end
end
function out=reference(file)
    file=char(java.io.File(char(file)).getCanonicalPath());
    assert(strcmp(char(java.io.File(V3Path_v3(file)).getCanonicalPath()),file), ...
        'PK30hProfile:LiteralPath','Hash and native paths must agree.');
    out=struct('file',file,'sha256',RoundSHA256_v3(file));
end
function out=failure(problem),out=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);end
function value=left(b),value=min(b.research_deadline_unix_seconds-posixtime(datetime('now','TimeZone','UTC')), ...
        (b.research_deadline_monotonic_ns-double(java.lang.System.nanoTime()))/1e9);end
