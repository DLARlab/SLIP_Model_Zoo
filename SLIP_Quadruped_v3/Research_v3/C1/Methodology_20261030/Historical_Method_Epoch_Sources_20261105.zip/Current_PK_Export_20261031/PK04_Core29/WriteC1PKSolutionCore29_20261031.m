function receipt=WriteC1PKSolutionCore29_20261031(snapshotReference,readerAuditReference,readerClosure,outputFile,ProtectedReferences)
%WRITEC1PKSOLUTIONCORE29_20261031 Additive standalone29-by-N component core.
% TWO independent publicK60 ALL loads, independent writer projection oracle,
% complete literal policy/section/owner/four typed graphs and historical
% saved decisions. No Root, ODE, replay, classification or admission call.
% Whole core MAT bytes, including all load-required metadata, must fit5*v2.
% Essential audit/snapshot dependency bytes are separately reported, not
% excluded to claim an aggregate storage reduction. No public API is edited.
    entered=clockPair();budget=C1RunBudget_v3();fence=struct('utc',budget.deadline_unix_seconds,'mono',budget.deadline_monotonic_ns);
    assert(left(fence)>1802,'C1Core29:WholeFit','The full1800s cap must fit both unchanged original FINAL clocks.');
    finish=minimum(shift(entered,1800),fence);work=shift(finish,-120);
    snapshotReference=checked(snapshotReference);readerAuditReference=checked(readerAuditReference);
    validateReferences(ProtectedReferences);outputFile=canonical(outputFile);stage=[outputFile,'.pending.mat'];
    [~,~,extension]=fileparts(outputFile);assert(strcmp(extension,'.mat')&&isfolder(fileparts(outputFile)),'C1Core29:Output','Use an explicit fresh MAT path in an existing directory.');fresh({outputFile;stage});
    a=load(readerAuditReference.file,'audit');b=load(readerAuditReference.file,'audit');same(a.audit,b.audit,'reader native read2');q=a.audit;clear a b
    readerBinding=validateReader(q,readerClosure,snapshotReference,readerAuditReference);writerReference=checked(q.write_audit_reference);
    a=load(writerReference.file,'audit');b=load(writerReference.file,'audit');same(a.audit,b.audit,'writer native read2');w=a.audit;clear a b
    N=q.source_point_count;validateattributes(N,{'double'},{'real','scalar','finite','integer','positive'});
    assert(isequaln(q.budget,budget)&&isequaln(w.budget,budget),'C1Core29:Grant','The literal native grant value/clocks are unchanged.');
    assert(strcmp(w.schema,'C1-current-PK-thin-snapshot-write-v1')&&isequal(w.complete,true)&&isequal(w.source_posthash,true) ...
        &&isequal(w.source_projection_read2_verified,true)&&isequal(w.kernel_call_returned,true)&&isequal(w.kernel_return_timely,true) ...
        &&isequal(w.source_point_count,N)&&sameReference(w.candidate_reference,snapshotReference) ...
        &&iscell(w.record_digests)&&isequal(size(w.record_digests),[N,1])&&iscell(w.record_bindings)&&isequal(size(w.record_bindings),[N,1]), ...
        'C1Core29:WriterOracle','Use the independent complete/timely source writer oracle, never a LateWrite exception.');
    graph=q.literal_essential_graph_metadata;
    assert(strcmp(C1ScientificDigest_v3(graph),q.typed_graph_digest)&&strcmp(q.typed_graph_digest,w.typed_graph_digest), ...
        'C1Core29:GraphOracle','The whole qualified graph must bind the independent writer graph digest.');
    for name={'physical_edges','record_equalities','qualified_aliases','numerical_seams'}
        assert(isequal(numel(graph.(name{1})),q.typed_graph_counts.(name{1})) ...
            &&isequal(q.typed_graph_counts.(name{1}),w.typed_graph_counts.(name{1})),'C1Core29:GraphCounts','Every typed graph count must bind independently.');
    end
    originalV2=checked(q.original_v2_reference);v2=dir(originalV2.file);
    assert(isscalar(v2)&&~v2.isdir&&v2.bytes>0&&v2.bytes<=flintmax/5&&isequal(q.original_v2_bytes,v2.bytes), ...
        'C1Core29:OriginalV2','Bind the exact full original v2 component file bytes.');maximumBytes=5*v2.bytes;
    names={'WriteC1PKSolutionCore29_20261031','LoadC1SolutionCore29_v3','C1RunBudget_v3','EssentialBranchSolutionFile_v3', ...
        'RoundSHA256_v3','V3Path_v3','V3Root_v3','C1ScientificDigest_v3','HybridOrbit_v3','OrbitContentIdentity_v3','QuadrupedSchema_v3', ...
        'QuadrupedEnergy_v3','RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3','Trajectory_v3'};
    code=guardedMethods(names,ProtectedReferences);environment=runtimeEnvironment(ProtectedReferences);
    literalPath(outputFile);literalPath(stage);
    hit=find(cellfun(@(r)strcmp(r.name,'EssentialBranchSolutionFile_v3'),code));
    assert(isscalar(hit)&&strcmp(code{hit}.sha256,'60a9ff5336ac094be2254d863511139c3488f32fc39b17837b18935d851fd792'), ...
        'C1Core29:K60','Use unchanged publicK60.');
    hit=find(cellfun(@(r)strcmp(r.name,'C1ScientificDigest_v3'),code));
    assert(isscalar(hit)&&strcmp(code{hit}.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'), ...
        'C1Core29:DigestMethod','Use unchanged typed scientific digest.');
    refs=[ProtectedReferences(:);{snapshotReference;readerAuditReference;writerReference;originalV2; ...
        checked(readerClosure.source_reference);checked(readerClosure.closure_reference)}];
    paths=cellfun(@(r)canonical(r.file),refs,'UniformOutput',false);
    assert(~ismember(outputFile,paths)&&~ismember(stage,paths),'C1Core29:Additive','No input/reference may be an output or stage.');
    runtimeNames={'LoadC1SolutionCore29_v3','RoundSHA256_v3','V3Path_v3','V3Root_v3','C1ScientificDigest_v3','HybridOrbit_v3','OrbitContentIdentity_v3', ...
        'QuadrupedSchema_v3','RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3'};
    runtime=code(cellfun(@(r)ismember(r.name,runtimeNames),code));
    runtime=cellfun(@(r)struct('name',r.name,'sha256',r.sha256),runtime,'UniformOutput',false);
    producer=struct('file',canonical([mfilename('fullpath'),'.m']),'sha256',RoundSHA256_v3([mfilename('fullpath'),'.m']));
    receipt=struct('schema','C1-standalone-core29-write-receipt-v1','source_reference',snapshotReference, ...
        'qualification_reference',readerAuditReference,'qualification_closure',readerClosure,'qualified_reader_binding',readerBinding,'writer_audit_reference',writerReference, ...
        'output_file',outputFile,'stage_file',stage,'point_count',N,'whole_core_limit_bytes',maximumBytes, ...
        'original_v2_reference',originalV2,'original_v2_bytes',v2.bytes,'core_bytes',[],'core_sha256','', ...
        'all_bulk_reads',0,'source_projection_read2_verified',false,'cross_pass_handle_independence_verified',false,'core_native_read2_verified',false, ...
        'stage_save_returned',false,'exclusive_publication_returned',false,'owned_stage_removed',false, ...
        'owned_stage_file_key','','published_file_key_verified',false, ...
        'installed_native_read2_verified',false,'source_posthash',false,'completed',false,'failure',struct(), ...
        'elapsed_seconds',[],'bulk_payload_whos_bytes',zeros(2,1),'pre_save_core_whos_bytes',[], ...
        'external_RSS_measured',false,'declared_wall_seconds',1800,'save_reserve_seconds',120, ...
        'own_process_exit_observed',false,'new_admission_claimed',false,'aggregate_storage_reduction_claimed',false);
    receipt.size_scope='5x applies to this entire standalone component core MAT, including every load-required field. Retained essential snapshot/audit/code bytes are separately listed; no aggregate5x claim.';
    receipt.retained_essential_dependency_bytes=dependencyBytes({snapshotReference;readerAuditReference;writerReference;readerClosure.closure_reference});
    try
        solution_core29=[];kept=[];keptReport=[];keptMetadata=[];keptContext=[];
        for pass=1:2
            guard(work);fprintf('C1_CORE29_BEFORE_ALL_LOAD pass=%d\n',pass);
            [orbits,reports,metadata]=EssentialBranchSolutionFile_v3.loadSolutions(snapshotReference.file,(1:N).');
            receipt.all_bulk_reads=pass;fprintf('C1_CORE29_AFTER_ALL_LOAD_RETURN pass=%d\n',pass);
            check(work);assert(isequal(size(orbits),[N,1])&&isequal(size(reports),[N,1])&&isequal(size(metadata),[N,1]),'C1Core29:Count','Both independent bulk payloads must preserve Nx1.');
            if pass==2,assert(~(kept==orbits{1}),'C1Core29:HandleIndependence','Separate ALL calls must reconstruct independent native handles.');end
            observed=whos('orbits','reports','metadata');receipt.bulk_payload_whos_bytes(pass)=sum([observed.bytes]);
            if pass==1
                solution_core29=emptyCore(N,graph,snapshotReference,readerAuditReference,readerClosure,writerReference, ...
                    originalV2,v2.bytes,maximumBytes,runtime,producer,environment);
            end
            for k=1:N
                check(work);o=orbits{k};r=reports{k};m=metadata{k};mark=o.schema_metadata.essential_storage;
                same(mark,r.essential_storage,'actual thin markers');
                binding=struct('source_index',k,'native_id',mark.native_id,'occurrence_id',mark.context.occurrence_id, ...
                    'component_identity',m.component_identity,'order',m.order,'context',mark.context);
                same(binding,w.record_bindings{k},'independent source binding');
                projected=EssentialBranchSolutionFile_v3.project(o,r,m,mark.context);digest=C1ScientificDigest_v3(projected);
                assert(strcmp(digest,w.record_digests{k})&&strcmp(OrbitContentIdentity_v3(o),mark.native_id), ...
                    'C1Core29:ProjectionOracle','Actual-context projection/NativeID must match the independent source oracle.');
                entry=coreEntry(o,r,m,mark,digest);
                if pass==1,solution_core29=putEntry(solution_core29,k,entry);else,same(entry,getEntry(solution_core29,k),'independent ALL core values');end
                clear projected entry o r m mark binding
            end
            if pass==1
                kept=orbits{1};keptReport=reports{1};keptMetadata=metadata{1};keptContext=kept.schema_metadata.essential_storage.context;
            else
                original=EssentialBranchSolutionFile_v3.project(kept,keptReport,keptMetadata,keptContext);
                assert(strcmp(C1ScientificDigest_v3(original),w.record_digests{1}),'C1Core29:RetainedHandle','The bounded first-pass handle remains unchanged after pass2.');
                receipt.cross_pass_handle_independence_verified=true;clear original kept keptReport keptMetadata keptContext
            end
            clear orbits reports metadata observed
            guard(work);
        end
        receipt.source_projection_read2_verified=true;core_digest=C1ScientificDigest_v3(solution_core29);
        observed=whos('solution_core29');receipt.pre_save_core_whos_bytes=observed.bytes;
        assert(observed.bytes<1750000000,'C1Core29:Headroom','Observed logical core size requires conservative native-v7 headroom; this is not a format-capacity guarantee.');
        guard(work);fresh({outputFile;stage});fprintf('C1_CORE29_BEFORE_STAGE_SAVE\n');
        save(stage,'solution_core29','core_digest','-v7');receipt.stage_save_returned=true;fprintf('C1_CORE29_AFTER_STAGE_SAVE_RETURN\n');
        check(finish);stageIdentity=fileIdentity(stage);receipt.owned_stage_file_key=stageIdentity.key;
        sourceIdentity=fileIdentity(snapshotReference.file);
        assert(~strcmp(stageIdentity.key,sourceIdentity.key),'C1Core29:IndependentStage','The new core stage must not share the input snapshot file identity.');
        receipt.core_bytes=stageIdentity.bytes;receipt.core_sha256=RoundSHA256_v3(stage);
        assert(stageIdentity.bytes<=maximumBytes,'C1Core29:FiveTimes','Retain an oversized standalone candidate without publication; do not omit required metadata to fit.');
        a=load(stage,'solution_core29','core_digest');b=load(stage,'solution_core29','core_digest');
        same(solution_core29,a.solution_core29,'whole stage core first read');same(solution_core29,b.solution_core29,'whole stage core second read');
        assert(strcmp(a.core_digest,core_digest)&&strcmp(b.core_digest,core_digest),'C1Core29:StageDigest','Both complete native reads must bind the typed digest.');clear a b
        receipt.core_native_read2_verified=true;
        [test,~,point]=LoadC1SolutionCore29_v3(stage,1,receipt.core_sha256);assert(strcmp(OrbitContentIdentity_v3(test),point.native_id),'C1Core29:LoaderSmoke','Use the actual standalone loader on the staged core.');clear test point
        guard(finish);assert(isequaln(fileIdentity(stage),stageIdentity)&&strcmp(RoundSHA256_v3(stage),receipt.core_sha256),'C1Core29:StageChanged','The qualified stage identity/bytes changed.');fresh({outputFile});
        fprintf('C1_CORE29_BEFORE_EXCLUSIVE_PUBLICATION\n');
        javaMethod('createLink','java.nio.file.Files',java.io.File(outputFile).toPath(),java.io.File(stage).toPath());
        receipt.exclusive_publication_returned=true;fprintf('C1_CORE29_AFTER_EXCLUSIVE_PUBLICATION_RETURN\n');
        assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(outputFile).toPath(),java.io.File(stage).toPath()), ...
            'C1Core29:PublicationIdentity','Published name must identify the owned stage.');
        finalIdentity=fileIdentity(outputFile);assert(strcmp(finalIdentity.key,stageIdentity.key),'C1Core29:PublishedKey','The exclusive final name must have the original owned stage key.');receipt.published_file_key_verified=true;
        assert(isequaln(fileIdentity(stage),stageIdentity),'C1Core29:OwnedUnlink','Remove only the unchanged owned stage.');
        javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());receipt.owned_stage_removed=true;
        a=load(outputFile,'solution_core29','core_digest');b=load(outputFile,'solution_core29','core_digest');
        same(solution_core29,a.solution_core29,'whole installed core first read');same(solution_core29,b.solution_core29,'whole installed core second read');
        assert(strcmp(a.core_digest,core_digest)&&strcmp(b.core_digest,core_digest)&&strcmp(RoundSHA256_v3(outputFile),receipt.core_sha256), ...
            'C1Core29:InstalledDigest','Installed bytes and both native values must preserve the standalone core.');clear a b
        receipt.installed_native_read2_verified=true;guard(finish);receipt.source_posthash=true;
        receipt.completed=true;returned=clockPair();receipt.elapsed_seconds=(returned.mono-entered.mono)/1e9;
        fprintf('C1_CORE29_ACTUAL_RETURN %s\n',jsonencode(receipt));check(finish);
    catch problem
        receipt.completed=false;receipt.failure=struct('identifier',problem.identifier,'message',problem.message);
        returned=clockPair();receipt.elapsed_seconds=(returned.mono-entered.mono)/1e9;
        fprintf('C1_CORE29_PARTIAL %s\n',jsonencode(receipt));rethrow(problem)
    end
    function guard(limit)
        check(limit);verify(refs);verifyCode(code);literalPath(outputFile);literalPath(stage);assert(isequaln(C1RunBudget_v3(),budget),'C1Core29:Budget','No recapture/clock renewal.');
        if receipt.exclusive_publication_returned
            current=fileIdentity(outputFile);
            assert(strcmp(current.key,receipt.owned_stage_file_key)&&current.bytes==receipt.core_bytes&&strcmp(RoundSHA256_v3(outputFile),receipt.core_sha256),'C1Core29:PublishedChanged','Retain the final file if later checks fail.');
        end
        check(limit);
    end
end

function c=emptyCore(N,graph,snapshot,qualification,closure,writer,v2,v2bytes,cap,runtime,producer,environment)
    rows=cell(N,1);c=struct('schema','C1-self-contained-solution-core29-v1', ...
        'layout','rows1:14=initial_state;15:28=full_stride;29=period; columns=stored occurrences', ...
        'point_count',N,'solution_matrix',zeros(29,N),'parameters',{rows},'modes',{rows},'native_ids',{rows}, ...
        'point_metadata',{rows},'contexts',{rows},'policies',{rows},'section_charts',{rows},'orbit_evidence',{rows}, ...
        'saved_reports',{rows},'native_energy',zeros(1,N),'signed_mean_U',zeros(1,N),'graph',graph, ...
        'source_projection_digests',{rows},'source_reference',snapshot,'qualification_reference',qualification, ...
        'qualification_closure',closure,'writer_audit_reference',writer,'original_v2_reference',v2, ...
        'original_v2_bytes',v2bytes,'maximum_core_bytes',cap,'runtime_methods',{runtime},'runtime_environment',environment,'producer_reference',producer, ...
        'historical_audit_scope','Saved retained gates/classification/primitive and graph evidence are literal historical decisions from the qualified thin snapshot. Full historical decision audits are external provenance and are not required to load this core.', ...
        'replay_scope','Trajectory-free seed/policy/section only. Fresh declared integration, acceptance and deadlines are required for replay; no historical callback is executed or old acquisition reproduced.');
end

function e=coreEntry(o,r,m,mark,digest)
    assert(isa(o.initial_state,'double')&&isreal(o.initial_state)&&~issparse(o.initial_state)&&isequal(size(o.initial_state),[14,1]) ...
        &&all(isfinite(o.initial_state))&&isa(o.stride_displacement,'double')&&isreal(o.stride_displacement)&&~issparse(o.stride_displacement) ...
        &&isequal(size(o.stride_displacement),[14,1])&&all(isfinite(o.stride_displacement)) ...
        &&isa(o.period,'double')&&isreal(o.period)&&~issparse(o.period)&&isscalar(o.period)&&isfinite(o.period)&&o.period>0, ...
        'C1Core29:SourceShape','The29matrix supports literal real-double column state/stride and scalar positive period only; refuse any conversion.');
    policy=mark.recorded_policy_evidence;assert(isequal(policy.complete,true)&&strcmp(policy.configuration.source_class,'BLMarkedApexReturnPolicy_v3'), ...
        'C1Core29:CompletePolicy','Every declared load/replay seed needs its complete known recorded BL policy.');
    descriptor=struct('diagnostic_kind','runtime-object-descriptor','source_class',policy.configuration.source_class,'settings',policy.configuration.settings);
    [~,restored]=RecordedReturnPolicy_v3(struct('correction_return_policy',descriptor));
    assert(isequal(restored.complete,true)&&strcmp(C1ScientificDigest_v3(restored.configuration),C1ScientificDigest_v3(policy.configuration)), ...
        'C1Core29:PolicyRoundtrip','The known policy constructor must preserve every recorded setting.');
    chart=o.section_chart;assert(isstruct(chart)&&isscalar(chart)&&all(isfield(chart, ...
        {'id','geometry','crossing_orientation','boundary_ownership','translational_gauge','BL_touchdowns_per_return'})), ...
        'C1Core29:CompleteSection','Every core occurrence needs its complete recorded section.');
    saved=select(r,{'schema_version','status','native_status','accepted','full_closure','full_closure_residual', ...
        'acceptance_gates','classification','primitive','family_conditions','physical_inequalities','independent_replay'});
    evidence=struct();for name={'return_policy','return_policy_name','return_multiplicity','candidate_section_count','candidate_apex_count', ...
            'accepted_crossing_index','accepted_apex_index','section_relative_event_signature','cyclic_event_signature','primitive_cycle','gait_identification'}
        evidence.(name{1})=o.(name{1});
    end
    fresh=HybridOrbit_v3(struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter, ...
        'stride_displacement',o.stride_displacement,'period',o.period,'return_policy_name',o.return_policy_name));
    assert(strcmp(OrbitContentIdentity_v3(fresh),mark.native_id),'C1Core29:FreshNativeID','Fresh minimal native construction must preserve actual identity for every occurrence.');clear fresh
    energy=QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter);schema=QuadrupedSchema_v3.shared();U=o.stride_displacement(schema.TranslationIndex)/o.period;
    assert(isa(energy,'double')&&isreal(energy)&&isscalar(energy)&&isfinite(energy)&&isfinite(U),'C1Core29:PlotScalars','Finite native energy/signed stride rate are required.');
    e=struct('matrix',[o.initial_state;o.stride_displacement;o.period],'parameter',o.parameter,'mode',o.initial_mode, ...
        'native_id',mark.native_id,'metadata',m,'context',mark.context,'policy',policy,'chart',chart,'orbit_evidence',evidence, ...
        'saved_report',saved,'energy',energy,'mean_U',U,'source_digest',digest);
end

function c=putEntry(c,k,e)
    c.solution_matrix(:,k)=e.matrix;c.parameters{k}=e.parameter;c.modes{k}=e.mode;c.native_ids{k}=e.native_id;
    c.point_metadata{k}=e.metadata;c.contexts{k}=e.context;c.policies{k}=e.policy;c.section_charts{k}=e.chart;
    c.orbit_evidence{k}=e.orbit_evidence;c.saved_reports{k}=e.saved_report;c.native_energy(k)=e.energy;
    c.signed_mean_U(k)=e.mean_U;c.source_projection_digests{k}=e.source_digest;
end

function e=getEntry(c,k)
    e=struct('matrix',c.solution_matrix(:,k),'parameter',c.parameters{k},'mode',c.modes{k},'native_id',c.native_ids{k}, ...
        'metadata',c.point_metadata{k},'context',c.contexts{k},'policy',c.policies{k},'chart',c.section_charts{k}, ...
        'orbit_evidence',c.orbit_evidence{k},'saved_report',c.saved_reports{k},'energy',c.native_energy(k), ...
        'mean_U',c.signed_mean_U(k),'source_digest',c.source_projection_digests{k});
end

function binding=validateReader(q,c,snapshot,readerAudit)
    required={'schema','completed','source_posthash','candidate_reference','source_point_count','write_audit_reference','source_code', ...
        'all_ordered_canonical_digests_verified','all_identity_owner_context_bindings_verified','cross_pass_handle_independence_verified', ...
        'typed_graph_verified','public_index_reads','all_bulk_thin_reads','storage_statistics_reads','literal_essential_graph_metadata', ...
        'typed_graph_digest','typed_graph_counts','original_v2_reference','original_v2_bytes','source_reference','budget'};
    assert(isstruct(q)&&isscalar(q)&&all(isfield(q,required))&&strcmp(q.schema,'C1-PK-thin-snapshot-fresh-reader-P1-audit-v1') ...
        &&isequal(q.completed,true)&&isequal(q.source_posthash,true)&&sameReference(q.candidate_reference,snapshot) ...
        &&isequal(q.all_ordered_canonical_digests_verified,true)&&isequal(q.all_identity_owner_context_bindings_verified,true) ...
        &&isequal(q.cross_pass_handle_independence_verified,true)&&isequal(q.typed_graph_verified,true) ...
        &&isequal(q.public_index_reads,1)&&isequal(q.all_bulk_thin_reads,2)&&isequal(q.storage_statistics_reads,1), ...
        'C1Core29:QualifiedReader','A completed actual fresh reader and exact qualified snapshot are required.');
    keys={'schema','actual_process_exit_observed','all_owned_native_workers_exit_observed','process_session_id','exit_code', ...
        'source_reference','source_sha256','custody_complete','pending_boundary_reviewed','closure_reference'};
    assert(isstruct(c)&&isscalar(c)&&isequal(sort(fieldnames(c)),sort(keys(:)))&&strcmp(c.schema,'C1-closed-owned-native-worker-v1') ...
        &&isequal(c.actual_process_exit_observed,true)&&isequal(c.all_owned_native_workers_exit_observed,true)&&isequal(c.exit_code,0) ...
        &&isequal(c.custody_complete,true)&&isequal(c.pending_boundary_reviewed,true),'C1Core29:ReaderClosure','Actual external reader exit0/custody is separate from native completion.');
    validateattributes(c.process_session_id,{'double'},{'real','scalar','finite','integer','positive'});
    source=checked(c.source_reference);checked(c.closure_reference);
    [~,producerName]=fileparts(source.file);
    assert(strcmp(producerName,'QualifyC1PKThinSnapshot20261031')&&strcmp(source.sha256,c.source_sha256)&&iscell(q.source_code) ...
        &&sum(cellfun(@(r)sameReference(r,source),q.source_code))==1,'C1Core29:ReaderSource','The actual closed reader implementation must occur exactly once in its native method receipt.');
    binding=readerClosedBinding(q,c,snapshot,readerAudit);
end

function rows=guardedMethods(names,refs)
    rows=cell(numel(names),1);
    for k=1:numel(names)
        file=literalPath(which(names{k}));hit=find(cellfun(@(r)strcmp(canonical(r.file),file),refs));
        assert(isscalar(hit),'C1Core29:MethodPin','Supply one exact protected current resolver/SHA pin for %s.',names{k});
        r=checked(refs{hit});rows{k}=struct('name',names{k},'file',r.file,'sha256',r.sha256);
    end
end

function verifyCode(rows),for k=1:numel(rows),r=rows{k};assert(strcmp(literalPath(which(r.name)),r.file)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Core29:Resolver','A declared current implementation changed.');end,end
function out=select(s,names),out=struct();for k=1:numel(names),if isfield(s,names{k}),out.(names{k})=s.(names{k});end,end,end
function same(a,b,label),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'C1Core29:TypedEquality','Literal class/shape/rawbits/fields changed: %s.',label);end
function yes=sameReference(a,b),yes=isstruct(a)&&isscalar(a)&&all(isfield(a,{'file','sha256'}))&&isstruct(b)&&isscalar(b)&&all(isfield(b,{'file','sha256'}))&&strcmp(canonical(a.file),canonical(b.file))&&strcmp(a.sha256,b.sha256);end
function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'}))&&ischar(r.sha256)&&isrow(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once')),'C1Core29:Reference','Use one exact file/SHA reference.');r=struct('file',literalPath(r.file),'sha256',r.sha256);verify({r});end
function validateReferences(rows),assert(iscell(rows)&&iscolumn(rows),'C1Core29:References','Supply a column cell of actual current protected references.');for k=1:numel(rows),checked(rows{k});end,end
function verify(rows),for k=1:numel(rows),r=rows{k};assert(isfile(r.file)&&strcmp(literalPath(r.file),canonical(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Core29:Changed','A consumed/protected file changed: %s.',r.file);end,end
function rows=dependencyBytes(refs),rows=cell(numel(refs),1);for k=1:numel(refs),r=checked(refs{k});d=dir(r.file);rows{k}=struct('reference',r,'bytes',d.bytes);end,end
function identity=fileIdentity(file)
    p=java.io.File(file).toPath();no=javaArray('java.nio.file.LinkOption',1);no(1)=javaMethod('valueOf','java.nio.file.LinkOption','NOFOLLOW_LINKS');
    assert(~java.nio.file.Files.isSymbolicLink(p)&&java.nio.file.Files.isRegularFile(p,no),'C1Core29:Regular','Own stage/final must be a regular nonsymlink file.');
    attrs=javaMethod('readAttributes','java.nio.file.Files',p,'basic:fileKey',no);key=attrs.get('fileKey');assert(~isempty(key),'C1Core29:FileKey','A stable owned file key is required.');
    identity=struct('file',canonical(file),'key',char(javaMethod('toString','java.util.Objects',key)),'bytes',double(java.nio.file.Files.size(p)));
end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1Core29:Fresh','Retain existing output/uncertain stage: %s.',paths{k});end,end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function t=clockPair(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end
function t=shift(t,s),t.utc=t.utc+s;t.mono=t.mono+1e9*s;end
function t=minimum(a,b),t=struct('utc',min(a.utc,b.utc),'mono',min(a.mono,b.mono));end
function n=left(t),n=min(t.utc-posixtime(datetime('now','TimeZone','UTC')),(t.mono-double(java.lang.System.nanoTime))/1e9);end
function check(t),assert(left(t)>0,'C1Core29:Clock','The unchanged original/local FINAL clock expired.');end
function environment=runtimeEnvironment(refs)
    root=V3Root_v3(which('V3Path_v3'));relative=fullfile('Audits_v3','Folder_Organization','locations.json');file=literalPath(fullfile(root,relative));
    hit=find(cellfun(@(r)strcmp(canonical(r.file),file),refs));assert(isscalar(hit),'C1Core29:LocationMapPin','Supply one exact current runtime location-map reference.');r=checked(refs{hit});
    environment=struct('locations_map_relative_path',relative,'locations_map_sha256',r.sha256, ...
        'scope','Current model runtime path-resolution configuration, separate from historical scientific audits. All directly hashed/loaded/published paths must map identically.');
end

function p=literalPath(p)
    p=canonical(p);resolved=canonical(V3Path_v3(p));
    assert(strcmp(p,resolved),'C1Core29:LiteralPath','Hash, native load and publication must address the same literal canonical path; a legacy alias refuses.');
end

function binding=readerClosedBinding(q,c,snapshot,readerAudit)
    root=canonical(fileparts(which('C1RunBudget_v3')));
    expectedAudit=struct('file',fullfile(root,'Audits','PK36h_20261101_Connected04_Thin_FreshReader_Qualification.mat'),'sha256','2092e94d74220ec44c057a243682f23745648d9c96da545210058b0ad59568b6');
    expectedWriter=struct('file',fullfile(root,'Audits','PK36h_20261101_Connected04_Thin_Write_Audit.mat'),'sha256','da4a3b2c471d3988a804cb430ad052b919acb765118f9cc85177462412dcaead');
    expectedSnapshot=struct('file',fullfile(root,'Compact_Exports_20261030','C1_PK_Connected04_Thin_20261101.mat'),'sha256','1251fec8a2b18bd0bf611d15e9911eec5abab3d9d1376fa296162a7a0ab3657f');
    expectedSource=struct('file',fullfile(root,'Methodology_20261030','Current_PK_Export_20261031','PK04_ReaderPlot_LabelReviewed','QualifyC1PKThinSnapshot20261031.m'),'sha256','e52abf31193d0dbb3091b59ef7dd2b5ed420759462763f7e5cea733460eef375');
    witnessRef=struct('file','/private/tmp/c1_pk36h_20261031_candidates/PK36h_0079_ActualConnectedThinReader_Closure.json','sha256','cbe128babd5e786a6671bb5f0321026cb6f1c6feac67d9d72f452f820633e97b');
    assert(sameReference(readerAudit,expectedAudit)&&sameReference(q.write_audit_reference,expectedWriter)&&sameReference(snapshot,expectedSnapshot) ...
        &&sameReference(c.source_reference,expectedSource)&&sameReference(c.closure_reference,witnessRef)&&c.process_session_id==82973, ...
        'C1Core29:ReaderInvocation','Bind this exact successful0079 audit/oracle/snapshot/e52 source and immutable actual0 witness, not another same-code invocation.');
    checked(witnessRef);z=jsondecode(fileread(witnessRef.file));exactFields(z,{'schema','invocation_id','argv_utf8_sha256','exec_session_id','child_pid','actual_child_exit_code','actual_process_exit_observed','tool_prefix_reference','process_prefix_reference'});
    assert(strcmp(z.schema,'C1-ordinary-initializer-evidence-closure-v1')&&strcmp(z.invocation_id,'PK36h20261031-0079-final-connected-thin-fresh-reader') ...
        &&z.exec_session_id==82973&&z.child_pid==29704&&isequal(z.actual_child_exit_code,0)&&isequal(z.actual_process_exit_observed,true) ...
        &&strcmp(z.argv_utf8_sha256,'0b8ebbde36dbccd02fb88b60fd05a4e47b278e68914492ef4401c01504edb5b5'),'C1Core29:ActualReader0','Require exact actually observed0079 process closure.');
    exactFields(z.tool_prefix_reference,{'file','prefix_bytes','prefix_sha256'});exactFields(z.process_prefix_reference,{'file','prefix_bytes','prefix_sha256'});
    assert(strcmp(z.tool_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Tool_Observations.jsonl'))&&z.tool_prefix_reference.prefix_bytes==1855518 ...
        &&strcmp(z.tool_prefix_reference.prefix_sha256,'0f29e72ebb8475cb3f24e1232f8c323d910d600de6f65694399f48de9b4cd39c') ...
        &&strcmp(z.process_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Process_Observations.jsonl'))&&z.process_prefix_reference.prefix_bytes==4371376 ...
        &&strcmp(z.process_prefix_reference.prefix_sha256,'11b0a53fd4a5bb1a5283fb626998a57aad57ce04971c5289d5b9e7affd90eb4e'), ...
        'C1Core29:ReaderPrefixes','Use exact immutable prefixes; do not hash growing whole logs.');
    tool=prefixRows(z.tool_prefix_reference);process=prefixRows(z.process_prefix_reference);
    rows=tool(cellfun(@(r)isfield(r,'invocation_id')&&strcmp(r.invocation_id,z.invocation_id),tool));assert(numel(rows)==10,'C1Core29:ToolRows','Require actual ten ordered0079 Tool rows.');
    starts={};exits={};summaries={};startPosition=[];exitPosition=[];summaryPosition=[];terminal=0;
    for k=1:10
        r=rows{k};assert(strcmp(r.schema,'C1-native-exec-tool-observation-v1')&&r.tool_record_ordinal==k,'C1Core29:ToolOrder','Keep actual ordinals1..10.');
        if k<10
            assert(isfield(r,'session_id')&&r.session_id==z.exec_session_id&&isfield(r.record,'session_id')&&r.record.session_id==z.exec_session_id,'C1Core29:ToolSession','Both actual running session fields must match.');
        else
            assert(~isfield(r,'session_id')&&~isfield(r.record,'session_id'),'C1Core29:TerminalAbsence','Actual terminal10 has neither session field.');
        end
        if isfield(r.record,'exit_code'),assert(k==10&&r.record.exit_code==0,'C1Core29:ToolExit','Require sole terminal0.');terminal=terminal+1;end
        if isfield(r.record,'output')
            lines=strsplit(r.record.output,newline,'CollapseDelimiters',false);
            for j=1:numel(lines)
                line=lines{j};
                if startsWith(line,'C1_NATIVE_PROCESS_STARTED '),starts{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_STARTED ')+1:end));startPosition=[k j];end
                if startsWith(line,'C1_NATIVE_PROCESS_EXIT '),exits{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_EXIT ')+1:end));exitPosition=[k j];end
                if startsWith(line,'C1_FINAL_THIN_READER_ACTUAL_RETURN '),summaries{end+1}=jsondecode(line(numel('C1_FINAL_THIN_READER_ACTUAL_RETURN ')+1:end));summaryPosition=[k j];end
            end
        end
    end
    selected=process(cellfun(@(r)isfield(r,'invocation_id')&&strcmp(r.invocation_id,z.invocation_id),process));spec={};observed={};dispatch={};
    for k=1:numel(selected),r=selected{k};if strcmp(r.schema,'C1-native-launch-specification-v1'),spec{end+1}=r;elseif strcmp(r.schema,'C1-native-process-observation-v1'),observed{end+1}=r;elseif strcmp(r.schema,'C1-native-reviewed-specification-dispatch-confirmation-v1'),dispatch{end+1}=r;end,end
    assert(terminal==1&&numel(starts)==1&&numel(exits)==1&&numel(summaries)==1&&isequal(startPosition,[2 1])&&isequal(summaryPosition,[10 1])&&isequal(exitPosition,[10 2]) ...
        &&numel(spec)==1&&numel(observed)==1&&numel(dispatch)==1,'C1Core29:UniqueReaderClosure','Join exact START2:1, SUMMARY10:1 before EXIT10:2 and unique reviewed process rows.');
    a=starts{1};b=observed{1};sp=spec{1};di=dispatch{1};
    assert(strcmp(a.invocation_id,z.invocation_id)&&a.child_pid==z.child_pid&&strcmp(a.argv_utf8_sha256,z.argv_utf8_sha256) ...
        &&strcmp(b.invocation_id,z.invocation_id)&&b.child_pid==z.child_pid&&isequal(b.actual_child_exit_code,0)&&isequal(b.actual_process_exit_observed,true)&&strcmp(b.argv_utf8_sha256,z.argv_utf8_sha256) ...
        &&strcmp(sp.argv_utf8_sha256,z.argv_utf8_sha256)&&strcmp(di.argv_utf8_sha256,z.argv_utf8_sha256)&&isequaln(exits{1},b),'C1Core29:ProcessJoin','Actual START/EXIT/spec/dispatch share the same observed child/argv.');
    assert(strcmp(sp.expected_execution_tool_options.sandbox_permissions,'require_escalated')&&isequaln(rows{1}.actual_execution_tool_options,sp.expected_execution_tool_options) ...
        &&isequaln(di.expected_execution_tool_options,sp.expected_execution_tool_options)&&isequaln(b.expected_execution_tool_options,sp.expected_execution_tool_options),'C1Core29:Profile','Retain actual reviewed execution profile.');
    assert(sameReference(sp.source_reference,expectedSource),'C1Core29:ReaderMethod','Actual Processspec binds the exact successful e52 implementation.');
    guards=asCells(sp.operative_guard_references);hit=find(cellfun(@(r)sameReference(r,expectedWriter),guards));assert(isscalar(hit),'C1Core29:WriterOracleBinding','Actual reader consumed exactly this writer oracle.');
    h=summaries{1};assert(strcmp(h.schema,'C1-final-four-source-thin-fresh-reader-observation-v1')&&isequal(h.completed,true)&&isequal(h.helper_returned,true)&&isequal(h.helper_return_timely,true) ...
        &&isequal(h.own_process_exit_observed,false)&&sameReference(h.reader_audit_reference,readerAudit)&&sameReference(h.candidate_reference,snapshot)&&sameReference(h.source_reference,q.source_reference), ...
        'C1Core29:ReaderAuditBinding','Actual returned summary binds these exact QA bytes/snapshot/source; own exitfalse remains literal.');
    keys={'source_point_count','public_index_reads','all_bulk_thin_reads','storage_statistics_reads','all_ordered_canonical_digests_verified', ...
        'all_identity_owner_context_bindings_verified','cross_pass_handle_independence_verified','typed_graph_verified','source_posthash'};
    for k=1:numel(keys),assert(isequal(h.(keys{k}),q.(keys{k})),'C1Core29:ReaderFacts','The actual closed returned qualification flags/counts must match the native audit.');end
    binding=struct('reader_audit_reference',readerAudit,'writer_audit_reference',q.write_audit_reference,'snapshot_reference',snapshot,'reader_source_reference',c.source_reference, ...
        'actual_closed_witness_reference',witnessRef,'process_session_id',z.exec_session_id,'child_pid',z.child_pid,'actual_exit_code',z.actual_child_exit_code, ...
        'tool_prefix_reference',z.tool_prefix_reference,'process_prefix_reference',z.process_prefix_reference,'verified',true, ...
        'scope','Exact actual0079 metadata/prefix/summary/source/oracle bindings; no same-code-other-invocation substitution.');
end

function rows=prefixRows(r)
    validSHA(r.prefix_sha256);assert(ischar(r.file)&&isrow(r.file)&&isa(r.prefix_bytes,'double')&&isscalar(r.prefix_bytes)&&isfinite(r.prefix_bytes)&&r.prefix_bytes>0&&r.prefix_bytes<=16*1024*1024&&r.prefix_bytes==fix(r.prefix_bytes),'C1PKFork:Prefix','Require an exact bounded prefix.');
    f=fopen(r.file,'rb');assert(f>=0,'C1PKFork:PrefixOpen','Cannot read prefix.');closer=onCleanup(@()fclose(f));b=fread(f,r.prefix_bytes,'*uint8');assert(numel(b)==r.prefix_bytes&&b(end)==10,'C1PKFork:PrefixLength','Exact prefix must end atLF.');clear closer
    d=java.security.MessageDigest.getInstance('SHA-256');d.update(b);h=lower(reshape(dec2hex(typecast(d.digest(),'uint8'),2).',1,[]));assert(strcmp(h,r.prefix_sha256),'C1PKFork:PrefixSHA','Immutable prefix changed.');
    lines=strsplit(native2unicode(b.','UTF-8'),newline,'CollapseDelimiters',false);lines(end)=[];rows=cellfun(@jsondecode,lines,'UniformOutput',false);
end

function c=asCells(x),if iscell(x),c=x(:);elseif isstruct(x),c=num2cell(x(:));else,error('C1PKFork:Cells','Require actual JSON object-array rows.');end,end

function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end

function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end

