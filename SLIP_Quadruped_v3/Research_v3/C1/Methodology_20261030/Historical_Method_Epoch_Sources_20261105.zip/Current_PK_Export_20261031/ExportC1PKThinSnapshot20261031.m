function audit=ExportC1PKThinSnapshot20261031(closedSource,options)
%EXPORTC1PKTHINSNAPSHOT20261031 ONE closed current raw PK scientific snapshot.
% SOURCE CANDIDATE ONLY. No root/map/replay/classification/admission is run.
% Raw storage remains resume authority. This writer does not qualify its own
% output: a separate fresh MATLAB process must index and bulk-thin-read twice.
% The selected-native loader copies BranchSolutionFile_v3 validation semantics;
% its two independent loads are NOT two public loadSolutions/index rewalks.
    entered=pairClock();root=canonical(fileparts(which('C1RunBudget_v3')));
    keys={'SourceReference','ExpectedPointCount','OutputFile','AuditFile', ...
        'LegacySnapshotReference','LegacyIdentityMap','KernelReference','DigestReference', ...
        'SourceReferences','ProtectedReferences','ExternalFiniteEvidenceReferences', ...
        'MaxWallSeconds','OperationalMaximumBytes'};
    exactFields(options,keys,'PK snapshot options');o=options;
    validateattributes(o.ExpectedPointCount,{'double'},{'real','scalar','finite','integer','positive'});
    validateattributes(o.MaxWallSeconds,{'double'},{'real','scalar','finite','integer','>',120});
    validateattributes(o.OperationalMaximumBytes,{'double'},{'real','scalar','finite','integer','positive'});
    o.SourceReference=checked(o.SourceReference);source=o.SourceReference;
    sourcePath=canonical(fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'));
    assert(strcmp(source.file,sourcePath),'C1PKThin:Source','Only the declared current merged raw PK authority is supported.');
    validateClosedSource(closedSource,source,o.ExpectedPointCount);
    o.KernelReference=checked(o.KernelReference);o.DigestReference=checked(o.DigestReference);
    assert(strcmp(o.KernelReference.sha256,'60a9ff5336ac094be2254d863511139c3488f32fc39b17837b18935d851fd792') ...
        &&strcmp(o.DigestReference.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'), ...
        'C1PKThin:Methods','Use the unchanged qualified public kernel/digest. Leaf interning is a separate experiment.');
    assert(iscell(o.SourceReferences)&&isvector(o.SourceReferences)&&numel(o.SourceReferences)==30,'C1PKThin:Sources','Preserve the actual ordered current source30 and its literal shape, without editing its epoch.');
    validateReferenceCells(o.ProtectedReferences,'current protected authorities');
    validateReferenceCells(o.ExternalFiniteEvidenceReferences,'external finite evidence');
    assert(~isempty(o.ExternalFiniteEvidenceReferences),'C1PKThin:ExternalEvidence','Retain the separately supplied current Round/coverage evidence; it cannot create a graph relation.');
    o.LegacySnapshotReference=checked(o.LegacySnapshotReference);
    output=canonical(o.OutputFile);auditFile=canonical(o.AuditFile);
    assertMat(output);assertMat(auditFile);assert(~strcmp(output,auditFile),'C1PKThin:Outputs','The candidate and concise audit are separate files.');
    assert(isfolder(fileparts(output))&&isfolder(fileparts(auditFile)),'C1PKThin:OutputParent','The caller supplies existing declared output directories.');
    assert(~ismember(fileparts(output),{fileparts(source.file),fullfile(root,'Components'),fullfile(root,'Results')}), ...
        'C1PKThin:Additive','Additive exports cannot change the raw/component/Results rosters.');
    assert(~ismember(fileparts(auditFile),{fileparts(source.file),fullfile(root,'Components'),fullfile(root,'Results')}),'C1PKThin:Additive','The audit cannot change raw/component/Results rosters.');
    fresh({output,auditFile,[auditFile,'.pending.mat']});o.OutputFile=output;o.AuditFile=auditFile;
    budget=C1RunBudget_v3();fence=finalStorageLimit(budget);
    assert(left(fence)>o.MaxWallSeconds+2,'C1PKThin:WholeFit','The whole declared storage cap must fit BOTH original FINAL clocks.');
    finish=minLimit(shift(entered,o.MaxWallSeconds),fence);work=shift(finish,-120);
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));
    lease=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
    absent={[ledger,'.pending.mat'],[ledger(1:end-4),'_active_checkpoint.mat'],[ledger(1:end-4),'_active_checkpoint.mat.pending.mat'],[source.file,'.pending.mat']};
    fresh(absent);beforeCore=coreRoster(root,source.file);beforeResults=allResultsRoster(root);
    refs=uniqueReferences([o.ProtectedReferences(:);o.ExternalFiniteEvidenceReferences(:); ...
        {source;o.LegacySnapshotReference;closedSource.closure_reference}]);
    protectedPaths=cellfun(@(r)canonical(r.file),refs,'UniformOutput',false);
    assert(all(ismember([beforeCore;beforeResults;{ledger}],protectedPaths)), ...
        'C1PKThin:ProtectedUnion','Protect every actual current core/Results entry and current journal, including any experimental catalogue or retained pending payload.');
    assert(~ismember(output,protectedPaths)&&~ismember(auditFile,protectedPaths),'C1PKThin:FreshAuthority','Outputs cannot replace a protected input.');
    code=uniqueReferences([o.SourceReferences(:);{o.KernelReference;o.DigestReference;reference([mfilename('fullpath'),'.m']);reference(which('C1RunBudget_v3'))}]);
    sourcePaths=cellfun(@(r)canonical(r.file),o.SourceReferences(:),'UniformOutput',false);
    assert(numel(unique(sourcePaths))==30,'C1PKThin:Sources','The declared source30 cannot repeat a source path.');
    codePaths=cellfun(@(r)canonical(r.file),code,'UniformOutput',false);
    for name={'BranchSolutionFile_v3','HybridOrbit_v3','Trajectory_v3','QuadrupedSchema_v3','OrbitContentIdentity_v3','RecordedReturnPolicy_v3','RoundSHA256_v3'}
        path=canonical(which(name{1}));
        if ~ismember(path,codePaths)
            hit=find(strcmp(protectedPaths,path));assert(isscalar(hit),'C1PKThin:MethodClosure','Supply an exact protected source pin for %s.',name{1});
            code{end+1,1}=refs{hit};codePaths{end+1,1}=path;
        end
    end
    verifyCode(code);verify(refs);sourceStat=dir(source.file);assert(isscalar(sourceStat)&&~sourceStat.isdir,'C1PKThin:SourceStat');
    beforeStages=stageNames(fileparts(output));
    audit=struct('schema','C1-current-PK-thin-snapshot-write-v1','source_reference',source, ...
        'closed_source_boundary',closedSource,'options',o,'budget',budget,'storage_final_deadline',fence, ...
        'source_code',{code},'input_references',{refs},'started_utc',stamp(),'finished_utc','', ...
        'phase','prepared','complete',false,'source_posthash',false,'failure',struct(), ...
        'raw_index_read_count',0,'source_index_digest','','source_point_count',0, ...
        'source_projection_read2_verified',false,'record_digests',{cell(0,1)},'record_bindings',{cell(0,1)}, ...
        'legacy_identity_proof',struct(),'runtime_descriptor_dispositions',{cell(0,1)}, ...
        'callback_descriptor_conversion_count',0,'unavailable_jacobian_omission_count',0, ...
        'frozen_creation_graph',struct(),'typed_graph_digest','','typed_graph_counts',struct(), ...
        'external_finite_evidence_references',{o.ExternalFiniteEvidenceReferences(:)}, ...
        'external_evidence_scope','Separate finite Round/meeting coverage evidence only. No new canonical equality, alias, numerical seam or physical edge is inferred.', ...
        'kernel_call_prepared',false,'kernel_call_returned',false,'kernel_return_timely',false, ...
        'candidate_reference',struct(),'actual_candidate_bytes',NaN,'operational_maximum_bytes',o.OperationalMaximumBytes, ...
        'new_uncertain_stage_paths',{cell(0,1)},'fresh_process_qualification_required',true, ...
        'fresh_process_qualification_earned',false,'published_additive_export',false, ...
        'writer_no_map_root_replay_classification_or_new_admission',true,'raw_resume_authority_preserved',true, ...
        'whole_original_runtime_equality_claimed',false,'whole_original_method_settings_equality_claimed',false, ...
        'full_branch_completion_claimed',false,'own_process_exit_observed',false);
    audit.source_reference_scope='Declared current resolver pins in the source30 order, through the reviewed source/budget bridge; historical journal source entries and their epochs are not rewritten.';
    publishAudit(auditFile,audit,finish);
    try
        guard();first=BranchSolutionFile_v3.index(source.file);audit.raw_index_read_count=1;
        sourceUnchanged(source,sourceStat);ix=BranchSolutionFile_v3.index(source.file);audit.raw_index_read_count=2;
        rawEqual3(first,ix,ix,'two independent public raw indices and complete variable directories');clear first
        assert(strcmp(ix.storage_version,'BranchSolutionFile_v3:2')&&numel(ix.points)==o.ExpectedPointCount, ...
            'C1PKThin:RuntimeCount','Use all actual current schema2 points, not the historical465 count.');
        N=numel(ix.points);audit.source_point_count=N;audit.source_index_digest=C1ScientificDigest_v3(ix);
        [legacy,audit.legacy_identity_proof]=validateLegacyMap(o.LegacySnapshotReference,o.LegacyIdentityMap,ix,work);
        [points,contexts,physical]=wholePoints(ix,source);records=cell(N,1);runtime=cell(0,1);bindings=cell(N,1);digests=cell(N,1);
        for startIndex=1:32:N
            guard();indices=(startIndex:min(startIndex+31,N)).';
            [one,oneRuntime]=sourceProjectionBlock(source,sourceStat,indices,points,contexts,ix,legacy);
            [two,twoRuntime]=sourceProjectionBlock(source,sourceStat,indices,points,contexts,ix,legacy);
            rawEqual3(one,two,two,'independent selected-native block projections');
            rawEqual3(oneRuntime,twoRuntime,twoRuntime,'independent saved descriptor dispositions');
            runtime=mergeRuntimeDispositions(runtime,oneRuntime);
            for j=1:numel(indices)
                k=indices(j);r=one{j};records{k}=r;digests{k}=C1ScientificDigest_v3(r);
                bindings{k}=struct('source_index',k,'native_id',r.native_id,'occurrence_id',r.context.occurrence_id, ...
                    'component_identity',r.metadata.component_identity,'order',r.metadata.order,'context',r.context);
            end
            clear one two oneRuntime twoRuntime
        end
        [audit.callback_descriptor_conversion_count,audit.unavailable_jacobian_omission_count]=validateRuntimeDispositions(runtime,legacy,N);
        audit.legacy_identity_proof.current_raw_ids_verified_during_each_independent_projection=true;
        [branch,counts]=wholeGraph(ix,source,records,physical,code,'PK');
        audit.frozen_creation_graph=creationGraphReceipt(ix,source);
        audit.source_projection_read2_verified=true;audit.record_digests=digests;audit.record_bindings=bindings;
        audit.runtime_descriptor_dispositions=runtime;audit.typed_graph_digest=C1ScientificDigest_v3(branch);audit.typed_graph_counts=counts;
        audit.source_selected_native_load_count=2*ceil(N/32);audit.role_counts=countRoles(cellfun(@(r)r.context.role,records,'UniformOutput',false));
        audit.read2_scope='Two public raw index/directory validations; then TWO independent selected-variable native loads per block32 with exact public native orbit/report validation. Not two public loadSolutions calls.';
        audit.normalization_scope='Six original465 NativeIDs plus exact known descriptors only;24 copied callback names and6 Jacobian leaves with settings ABSENT. No defaults, closure reconstruction or raw mutation.';
        audit.phase='source_projection_receipt_ready';guard();publishAudit(auditFile,audit,finish);
        audit.kernel_call_prepared=true;audit.phase='kernel_call_prepared';publishAudit(auditFile,audit,finish);guard();
        returned=EssentialBranchSolutionFile_v3.writeProjections(output,branch,records,o.OperationalMaximumBytes);
        audit.kernel_call_returned=true; % Actual return is recorded before any fallible postguard.
        audit.kernel_return_timely=left(work)>0;audit.phase='kernel_call_returned';
        audit.candidate_reference=reference(output);info=dir(output);audit.actual_candidate_bytes=info.bytes;
        assert(audit.kernel_return_timely,'C1PKThin:LateWrite','Retain a late candidate without promoting qualification.');
        checkReturnedIndex(returned,records,branch,digests);clear records returned points contexts physical ix legacy bindings runtime digests branch
        guard(finish);audit.source_posthash=true;audit.complete=true;audit.phase='write_returned_fresh_qualification_pending';
        audit.finished_utc=stamp();ended=pairClock();audit.elapsed_seconds=(ended.mono-entered.mono)/1e9;
        audit.statistics_scope='Compressed file bytes above are actual. storageStatistics native-whos memory, worker wall time and external process RSS must be reported separately; no5x, speed or memory-gain claim.';
        publishAudit(auditFile,audit,finish);guard(finish);check(finish);
        fprintf('C1_PK_THIN_SNAPSHOT_WRITE_RETURN points=%d complete=1 freshQualified=0 bytes=%d\n',N,audit.actual_candidate_bytes);check(finish);
    catch problem
        audit.complete=false;audit.failure=exceptionData(problem);audit.phase='failed_or_unqualified';audit.finished_utc=stamp();
        audit.new_uncertain_stage_paths=setdiff(stageNames(fileparts(output)),beforeStages,'stable');
        if isfile(output),audit.candidate_path_exists=true;else,audit.candidate_path_exists=false;end
        try,publishAudit(auditFile,audit,finish);catch custody,warning('C1PKThin:Custody','Retain prepared receipt and all uncertain products: %s',custody.message);end
        rethrow(problem)
    end
    function guard(limit)
        if nargin<1,limit=work;end
        check(limit);verifyCode(code);verify(refs);sourceUnchanged(source,sourceStat);fresh(absent);
        assert(isequaln(C1RunBudget_v3(),budget),'C1PKThin:Budget','Reading the provider cannot renew original clocks.');
        assert(isequal(coreRoster(root,source.file),beforeCore)&&isequal(allResultsRoster(root),beforeResults),'C1PKThin:Rosters','Actual current raw/core/Results roster must remain fixed.');
        check(limit);
    end
end

function [points,contexts,physical]=wholePoints(ix,source)
    N=numel(ix.points);points=cell(N,1);contexts=points;physical=cell(numel(ix.edges),1);
    for k=1:N
        p=ix.points{k};m=struct('component_identity',p.component_identity,'order',p.order);
        for key={'classification','nativeE','signedmeanU'},if isfield(p,key{1}),m.(key{1})=p.(key{1});end,end
        m.edge_enabled=false;m.edge_from=[];points{k}=m;
        contexts{k}=struct('role','historical-unknown','occurrence_id',sprintf('source-sha256:%s:index:%d',source.sha256,k), ...
            'source_reference',source,'source_index',k,'expected_index',k);
    end
    for j=1:numel(ix.edges)
        e=ix.edges{j};a=e.from;b=e.to;assert(a>=1&&b<=N&&a<b&&strcmp(ix.points{a}.component_identity,ix.points{b}.component_identity)&&strcmp(e.component_identity,ix.points{b}.component_identity), ...
            'C1EssentialComplete:PhysicalEdge','Use only actual ordered same-owner public physical edges.');
        assert(~points{b}.edge_enabled,'C1EssentialComplete:Incoming','Every occurrence has at most one actual physical predecessor.');
        p=struct('kind','historical_physical_edge','source_reference',source,'source_from',a,'source_to',b, ...
            'receipt_reference',source,'receipt_availability','historical_locator');
        points{b}.edge_enabled=true;points{b}.edge_from=a;contexts{b}.physical_edge_provenance=p;
        physical{j}=struct('from',a,'to',b,'component_identity',e.component_identity,'provenance',p);
    end
end

function [records,runtimeEvidence]=sourceProjectionBlock(source,sourceStat,indices,points,contexts,ix,legacy)
    % No raw object/report escapes this separate function workspace.
    sourceUnchanged(source,sourceStat);variables=cell(2*numel(indices),1);
    for j=1:numel(indices),p=ix.points{indices(j)};variables{2*j-1}=p.solution_variable;variables{2*j}=p.report_variable;end
    saved=load(source.file,variables{:});records=cell(numel(indices),1);runtimeEvidence=cell(0,1);
    for j=1:numel(indices)
        k=indices(j);p=ix.points{k};orbit=saved.(p.solution_variable);report=saved.(p.report_variable);metadata=p.metadata;
        assert(strcmp(class(orbit),'HybridOrbit_v3')&&isscalar(orbit),'C1EssentialComplete:SourceOrbit','Each selected source solution must be one exact native HybridOrbit_v3.');
        sourceValidateValue(orbit,true,0);sourceValidateValue(report,false,0);
        context=contexts{k};context.role=sourceRole(report,metadata);
        if any(strcmp(context.role,{'nonedge-control','isolated','rejected'})),assert(~points{k}.edge_enabled,'C1EssentialComplete:RoleEdge','An explicit NONEDGE/control/isolation/rejection disposition contradicts an incoming physical edge.');end
        [report,localRuntime]=observedRuntimeDisposition(report,source,k,orbit,legacy);runtimeEvidence=[runtimeEvidence;localRuntime]; %#ok<AGROW>
        records{j}=EssentialBranchSolutionFile_v3.project(orbit,report,points{k},context);
    end
    sourceUnchanged(source,sourceStat);
end

function [report,evidence]=observedRuntimeDisposition(report,source,index,orbit,legacy)
    % Pure copied-report adaptation, applied independently after EACH native load.
    % The raw source is immutable; no callback/object is reconstructed or invoked.
    evidence=cell(0,1);
    if ~ismember(index,(289:294).'),refuseExtraLegacyDescriptors(report);return;end
    row=legacy{index-288};assert(row.source_index==index&&strcmp(OrbitContentIdentity_v3(orbit),row.native_id), ...
        'C1PKThin:LegacyCurrentID','Current native identity must match the actual historical465 identity BEFORE any descriptor conversion.');
    if index==289,outputSignature='@(~,~,~)budgetOutput(trial.limit)';else,outputSignature='@(~,~,~)budgetOutput(limit)';end
    for envelope={'integration','replay_integration'}
        name=envelope{1};in=report.(name);solver=in.ODESolver;callback=in.ODEOptions.OutputFcn;
        exactFields(solver,{'runtime_class','reconstruction_required','signature'},'observed saved ODE descriptor');
        exactFields(callback,{'runtime_class','reconstruction_required','signature'},'observed saved output descriptor');
        assert(strcmp(solver.runtime_class,'function_handle')&&isequal(solver.reconstruction_required,true)&&strcmp(solver.signature,'ode45') ...
            &&strcmp(callback.runtime_class,'function_handle')&&isequal(callback.reconstruction_required,true)&&strcmp(callback.signature,outputSignature), ...
            'C1EssentialComplete:ObservedCallback','Accept only the literal observed six-row class/flag/signature forms; unknown producers or shapes remain refused.');
        in.ODESolver=struct('source_class','function_handle','name',solver.signature,'closure_available',false);
        in.ODEOptions.OutputFcn=struct('source_class','function_handle','name',callback.signature,'closure_available',false);report.(name)=in;
        evidence{end+1,1}=struct('path',[name,'.ODESolver'],'original_descriptor',solver,'source_indices',index,'disposition','saved_name_retained_without_runtime_closure','scope','Observed saved descriptor; producer provenance unknown. Original signature/class/reconstruction flag retained here; no captured workspace was saved or reconstructed.'); %#ok<AGROW>
        evidence{end+1,1}=struct('path',[name,'.ODEOptions.OutputFcn'],'original_descriptor',callback,'source_indices',index,'disposition','saved_name_retained_without_runtime_closure','scope','Observed saved descriptor; producer provenance unknown. Original signature/class/reconstruction flag retained here; no captured workspace was saved or reconstructed.'); %#ok<AGROW>
    end
    derivative=report.options.SolverOptions.Jacobian;
    exactFields(derivative,{'runtime_class','reconstruction_required'},'observed settings-unavailable Jacobian descriptor');
    assert(strcmp(derivative.runtime_class,'FiniteDifferenceJacobian_v3')&&isequal(derivative.reconstruction_required,true), ...
        'C1EssentialComplete:ObservedDerivative','Only the exact observed descriptor with ABSENT settings may be omitted as unavailable historical runtime evidence.');
    report.options.SolverOptions=rmfield(report.options.SolverOptions,'Jacobian'); % ONLY this leaf; every other solver option remains literal.
    evidence{end+1,1}=struct('path','options.SolverOptions.Jacobian','original_descriptor',derivative,'source_indices',index, ...
        'disposition','omitted_runtime_leaf_settings_not_saved','scope','Observed saved descriptor; producer provenance unknown. Settings are ABSENT, not empty/default/complete. This unsupported runtime leaf is omitted from the normalized retained projection and preserved verbatim here; no lossless original-method-settings claim.');
end

function groups=mergeRuntimeDispositions(groups,items)
    for k=1:numel(items)
        item=items{k};found=[];
        for j=1:numel(groups)
            if strcmp(groups{j}.path,item.path)&&isequaln(groups{j}.original_descriptor,item.original_descriptor)&&strcmp(groups{j}.disposition,item.disposition)&&strcmp(groups{j}.scope,item.scope),found=j;break;end
        end
        if isempty(found),groups{end+1,1}=item;else
            assert(~any(groups{found}.source_indices==item.source_indices),'C1EssentialComplete:RuntimeDuplicate','Each original descriptor occurrence is retained once after independent read2 equality.');
            groups{found}.source_indices(end+1,1)=item.source_indices;
        end
    end
end

function [callbacks,derivatives]=validateRuntimeDispositions(groups,legacy,N)
    callbacks=0;derivatives=0;seen=cell(0,1);
    for k=1:numel(groups)
        g=groups{k};
        for index=g.source_indices.'
            key=sprintf('%s:%d',g.path,index);assert(~ismember(key,seen),'C1EssentialComplete:RuntimeDuplicate','No repeated normalized runtime occurrence.');seen{end+1,1}=key; %#ok<AGROW>
        end
        if strcmp(g.disposition,'saved_name_retained_without_runtime_closure'),callbacks=callbacks+numel(g.source_indices);
        elseif strcmp(g.disposition,'omitted_runtime_leaf_settings_not_saved'),derivatives=derivatives+numel(g.source_indices);
        else,error('C1EssentialComplete:RuntimeDisposition','Unknown runtime evidence disposition.');end
    end
    assert(N>=294&&iscell(legacy)&&isequal(size(legacy),[6,1])&&numel(groups)==7&&callbacks==24&&derivatives==6&&numel(seen)==30, ...
        'C1PKThin:RuntimeCount','Conserve exactly24 callback conversions and6 absent-settings omissions for the six proven original identities.');
    paths={'integration.ODESolver';'integration.ODEOptions.OutputFcn';'replay_integration.ODESolver';'replay_integration.ODEOptions.OutputFcn';'options.SolverOptions.Jacobian'};
    for j=1:numel(paths),for index=289:294,assert(ismember(sprintf('%s:%d',paths{j},index),seen),'C1PKThin:RuntimeCoverage','Every known descriptor path/index is retained exactly once.');end,end
end

function sourceUnchanged(source,before)
    after=dir(source.file);assert(isscalar(after)&&~after.isdir&&isequal(after.bytes,before.bytes)&&isequal(after.datenum,before.datenum), ...
        'C1EssentialComplete:SourceStat','The pinned source metadata changed between index and selected-variable reads.');verify({source});
end

function role=sourceRole(report,metadata)
    role='';m=metadata;
    for depth=1:16
        assert(isstruct(m)&&isscalar(m),'C1EssentialComplete:RoleMetadata','Known role metadata envelopes must be scalar structures.');
        if isfield(m,'independent_NONEDGE_control')
            assert(isequal(m.independent_NONEDGE_control,true),'C1EssentialComplete:RoleMarker','Do not reinterpret a false/unknown declared independent-control marker.');role='nonedge-control';break
        end
        if ~isfield(m,'provenance'),break;end;p=m.provenance;if ~isstruct(p)||~isscalar(p),break;end
        if isfield(p,'kind')&&strcmp(p.kind,'imported nonedge initial pair'),role='nonedge-control';break;end
        if isfield(p,'kind')&&strcmp(p.kind,'native all-nine return rejected by continuation wrapper')
            assert(isequal(p.wrapper_accepted,false)&&isequal(p.edge_claimed,false),'C1EssentialComplete:RoleMarker','Known isolated-native disposition must retain literal wrapper/edge falseflags.');role='isolated';break
        end
        if isfield(p,'historical_predictor')&&isequal(p.historical_predictor,true)&&isfield(p,'edge_claimed')&&isequal(p.edge_claimed,false),role='nonedge-control';break;end
        if isfield(p,'original_point_metadata')
            fields={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
            exactFields(p,fields,'Consolidate direct provenance');assert(isequal(p.qualification_flags_changed,false),'C1EssentialComplete:RoleMarker','A historical wrapper cannot claim upgraded flags.');m=p.original_point_metadata;
        else,break;end
        assert(depth<16,'C1EssentialComplete:RoleDepth','Known source metadata wrappers exceed the explicit bound; do not infer a role.');
    end
    if isempty(role)
        if literalAccepted(report),role='accepted';
        elseif isfield(report,'accepted')&&isequal(report.accepted,false)&&isfield(report,'status')&&strcmp(report.status,'rejected'),role='rejected';
        else,role='historical-unknown';end
    end
    if strcmp(role,'rejected'),assert(~isfield(report,'accepted')||~isequal(report.accepted,true),'C1EssentialComplete:RoleConflict','A rejected claim cannot relabel a saved accepted return.');end
    if isfield(metadata,'role'),assert(strcmp(metadata.role,role),'C1EssentialComplete:RoleConflict','An explicit unknown/contradictory source role is not silently discarded.');end
end

function yes=literalAccepted(r)
    names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    yes=isstruct(r)&&isscalar(r)&&isfield(r,'accepted')&&isequal(r.accepted,true)&&isfield(r,'status')&&strcmp(r.status,'accepted') ...
        &&isfield(r,'acceptance_gates')&&isstruct(r.acceptance_gates)&&isscalar(r.acceptance_gates)&&isequal(sort(fieldnames(r.acceptance_gates)),sort(names(:)));
    if yes,yes=all(cellfun(@(k)isequal(r.acceptance_gates.(k),true),names));end
end

function [branch,counts]=wholeGraph(ix,source,records,physical,code,label)
    names={'record_equalities','qualified_aliases','numerical_seams'};oldNames={'exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};
    evidenceNames={'equality_evidence','qualified_alias_evidence','numerical_overlap_evidence'};relations=struct('record_equalities',{cell(0,1)},'qualified_aliases',{cell(0,1)},'numerical_seams',{cell(0,1)});
    if isfield(ix.metadata,'component_graph')
        g=ix.metadata.component_graph;
        legacyFields={'schema','nodes','original_explicit_edges','exact_record_equalities','qualified_record_aliases','qualified_alias_evidence','effective_edges','equality_evidence','connected','isolated_record_catalogue','equality_links_are_continuation_edges','qualified_aliases_are_exact_record_equalities','qualified_aliases_are_continuation_edges'};
        numericalFields={'qualified_numerical_overlaps','numerical_overlap_evidence','strict_trace_scope','numerical_storage_scope','numerical_adjacencies_are_identity_quotients','numerical_adjacencies_are_physical_edges'};
        assert(isstruct(g)&&isscalar(g),'C1EssentialComplete:GraphSource','Use a scalar literal Consolidate graph snapshot.');
        if isequal(sort(fieldnames(g)),sort(legacyFields(:)))
            relationCount=2; % The exact legacy producer has no numerical relation table or numerical flags.
        elseif isequal(sort(fieldnames(g)),sort([legacyFields(:);numericalFields(:)]))
            relationCount=3;
            assert(isequal(g.numerical_adjacencies_are_identity_quotients,false)&&isequal(g.numerical_adjacencies_are_physical_edges,false), ...
                'C1EssentialComplete:GraphSource','Retain the distinct modern numerical-adjacency semantics, without identity or physical-edge claims.');
        else
            error('C1EssentialComplete:GraphSource','Unknown or mixed Consolidate graph fields; require exactly the known legacy13 or modern19 producer.');
        end
        assert(strcmp(g.schema,'C1-connected-component-graph-v1')&&isequal(g.equality_links_are_continuation_edges,false) ...
            &&isequal(g.qualified_aliases_are_exact_record_equalities,false)&&isequal(g.qualified_aliases_are_continuation_edges,false), ...
            'C1EssentialComplete:GraphSource','Preserve the three literal nonphysical relation flags from either known producer.');
        assert(isnumeric(g.nodes)&&isreal(g.nodes)&&isscalar(g.nodes)&&isfinite(g.nodes)&&g.nodes==fix(g.nodes)&&g.nodes>=1&&g.nodes<=numel(records), ...
            'C1EssentialComplete:GraphSnapshot','The literal consolidation snapshot is bounded by the current store; later physical appends remain authoritative in the current index.');
        snapshot=g.original_explicit_edges;
        assert(isnumeric(snapshot)&&isreal(snapshot)&&ismatrix(snapshot)&&size(snapshot,2)==2&&all(isfinite(snapshot(:))) ...
            &&all(snapshot(:)==fix(snapshot(:)))&&all(snapshot(:)>=1)&&all(snapshot(:)<=g.nodes)&&all(snapshot(:,1)~=snapshot(:,2)), ...
            'C1EssentialComplete:GraphSnapshot','Preserve bounded literal physical snapshot edges without replacing the current public index edges.');
        for kind=1:relationCount,snapshot=[snapshot;g.(oldNames{kind})];end %#ok<AGROW>
        assert(isequal(g.effective_edges,snapshot),'C1EssentialComplete:GraphSnapshot','The exact producer effective snapshot is the ordered physical/equality/alias and, only for modern19, numerical concatenation.');
        for kind=1:relationCount
            assert(isfield(g,oldNames{kind})&&isfield(g,evidenceNames{kind}),'C1EssentialComplete:GraphEvidence','Every known relation table needs its literal complete evidence table.');
            pairs=g.(oldNames{kind});evidence=g.(evidenceNames{kind});assert(isnumeric(pairs)&&isreal(pairs)&&size(pairs,2)==2&&iscell(evidence)&&numel(evidence)==size(pairs,1), ...
                'C1EssentialComplete:GraphEvidence','All actual pair/evidence rows must correspond in exact source order.');rows=cell(size(pairs,1),1);
            for j=1:size(pairs,1)
                a=pairs(j,1);b=pairs(j,2);assert(all(isfinite([a,b]))&&all([a,b]==fix([a,b]))&&all([a,b]>=1)&&all([a,b]<=g.nodes)&&all([a,b]<=numel(records))&&a~=b, ...
                    'C1EssentialComplete:RelationBounds','Every relation endpoint must be an actual distinct occurrence.');
                [scalars,fines,schema]=relationEvidence(kind,evidence{j},records{a},records{b},a,ix,records);
                rows{j}=struct('from',a,'to',b,'from_native_id',records{a}.native_id,'to_native_id',records{b}.native_id, ...
                    'receipt_reference',source,'evidence',struct('schema',schema,'scalars',scalars,'original_fines',{fines}));
            end
            relations.(names{kind})=rows;
        end
    end
    branch=struct('schema','C1-essential-branch-graph-v1','role','unpublished-complete-store-measurement','displayname',[label,' complete literal source store'], ...
        'physical_edges',{physical},'record_equalities',{relations.record_equalities},'qualified_aliases',{relations.qualified_aliases}, ...
        'numerical_seams',{relations.numerical_seams},'source_versions',{cellfun(@ref2,code(:),'UniformOutput',false)});
    counts=struct('physical_edges',numel(physical),'record_equalities',numel(relations.record_equalities),'qualified_aliases',numel(relations.qualified_aliases),'numerical_seams',numel(relations.numerical_seams));
end

function [s,fines,schema]=relationEvidence(kind,e,left,right,leftIndex,ix,records)
    fines=cell(0,1);assert(~isempty(left.native_id)&&~isempty(right.native_id),'C1EssentialComplete:RelationID','Nonphysical relations require literal complete endpoint IDs.');
    if kind==1
        exactFields(e,{'native_ID','exact_state_mode_parameter_period_stride','translation_gauge_normalized','matching_return_section','new_continuation_edge_created'},'exact equality evidence');
        assert(isequal(e.exact_state_mode_parameter_period_stride,true)&&isequal(e.translation_gauge_normalized,true)&&isequal(e.new_continuation_edge_created,false) ...
            &&strcmp(e.native_ID,left.native_id)&&strcmp(e.native_ID,right.native_id),'C1EssentialComplete:Equality','Literal original exact-identity evidence must bind both actual NativeIDs.');
        a=identityRecord(left);b=identityRecord(right);a.initial_state(1)=0;b.initial_state(1)=0;rawEqual3(a,b,b,'actual normalized exact equality');checkMatching(e.matching_return_section,left,right);
        s=struct('exact_state_mode_parameter_period_stride',e.exact_state_mode_parameter_period_stride,'translation_gauge_normalized',e.translation_gauge_normalized,'new_continuation_edge_created',e.new_continuation_edge_created);
        s=mergeScalars(s,matchingScalars(e.matching_return_section));schema='ConsolidateC1ConnectedComponents_v3:exact-record-equality-v1';
    elseif kind==2
        fields={'schema','qualified','scope','left_native_ID','right_native_ID','exact_full_initial_state_mode_parameter','physical_parameters_schema_valid','canonical_point_label','left_admission','right_admission','matching_return_section','relative_absolute_tolerance','scale_formula','period_difference','period_scale','scaled_period_difference','stride_difference','stride_scale','scaled_stride_difference_inf','exact_record_equality_claimed','new_continuation_edge_created','original_orbits_reports_and_native_IDs_must_be_retained','request','qualification_source'};
        exactFields(e,fields,'qualified alias evidence');assert(strcmp(e.schema,'C1-qualified-record-alias-v1')&&isequal(e.qualified,true)&&isequal(e.exact_full_initial_state_mode_parameter,true)&&isequal(e.new_continuation_edge_created,false) ...
            &&e.relative_absolute_tolerance==1e-10&&e.scaled_period_difference<=1e-10&&e.scaled_stride_difference_inf<=1e-10, ...
            'C1EssentialComplete:Alias','Copy only the known original qualified-alias contract and fixed stored tolerances.');
        bindIDs(e,left,right);for key={'initial_state','initial_mode','parameter'},rawEqual3(left.orbit.(key{1}),right.orbit.(key{1}),right.orbit.(key{1}),'literal alias raw identity');end
        checkMatching(e.matching_return_section,left,right);checkAdmission(e.left_admission,left,false);checkAdmission(e.right_admission,right,false);
        s=pickScalars(e,{'qualified','exact_full_initial_state_mode_parameter','physical_parameters_schema_valid','canonical_point_label','relative_absolute_tolerance','period_difference','period_scale','scaled_period_difference','stride_difference','stride_scale','scaled_stride_difference_inf','exact_record_equality_claimed','new_continuation_edge_created'});
        s.original_full_runtime_required_at_qualification=e.original_orbits_reports_and_native_IDs_must_be_retained;s=mergeScalars(s,matchingScalars(e.matching_return_section));s=mergeScalars(s,aliasTransport(e));schema=e.schema;
    else
        fields={'schema','qualified','full_native_proof_validated','audit_reference','proof_identity','execution_witness','raw_reference','trial_reference','checkpoint_reference','literal_control_reference','literal_control_raw_reference','left_selector','right_selector','left_native_ID','right_native_ID','left_record','right_record','left_admission','right_admission','comparison','left_original_fines','right_original_fines','earned_physical_edge','validation_source_references','all_source_references_posthash_verified','identity_claimed','quotient_identification','new_continuation_edge_created','classification_or_admission_flags_changed','original_orbits_reports_and_native_IDs_retained','scope','cohort_scope','energy_scope','runtime_comparison_scope'};
        exactFields(e,fields,'qualified numerical evidence');assert(strcmp(e.schema,'C1-qualified-PK-numerical-overlap-v1')&&isequal(e.qualified,true)&&isequal(e.full_native_proof_validated,true) ...
            &&isequal(e.all_source_references_posthash_verified,true)&&isequal(e.identity_claimed,false)&&isequal(e.quotient_identification,false)&&isequal(e.new_continuation_edge_created,false)&&isequal(e.classification_or_admission_flags_changed,false) ...
            &&strcmp(e.proof_identity,'43b7037ec366d628018b40205545194a17f5291c45c3775ef4ddec290900d43c') ...
            &&strcmp(e.proof_identity,e.audit_reference.sha256)&&isequal(e.original_orbits_reports_and_native_IDs_retained,true),'C1EssentialComplete:Seam','Only the distinct complete original numerical-qualification schema is projected.');
        bindIDs(e,left,right);rawEqual3(e.left_record,identityRecord(left),identityRecord(left),'numerical left original raw record');rawEqual3(e.right_record,identityRecord(right),identityRecord(right),'numerical right original raw record');
        checkAdmission(e.left_admission,left,true);checkAdmission(e.right_admission,right,true);c=e.comparison;assert(isequal(c.conditions_met,true),'C1EssentialComplete:Seam','Do not promote an originally false finite comparison.');checkMatching(c.matching_section,left,right);
        incoming=find(cellfun(@(edge)edge.to==leftIndex,ix.edges));assert(isscalar(incoming),'C1EssentialComplete:SeamParent','The earned seam endpoint must have one actual incoming physical edge.');edge=ix.edges{incoming};parent=records{edge.from};
        rawEqual3(e.earned_physical_edge.from_record,identityRecord(parent),identityRecord(parent),'literal earned-parent raw record');
        assert(strcmp(e.earned_physical_edge.from_native_ID,parent.native_id)&&e.earned_physical_edge.from==2&&e.earned_physical_edge.to==3 ...
            &&isequal(e.earned_physical_edge.actual_new_points,1)&&isequal(e.earned_physical_edge.actual_new_edges,1) ...
            &&strcmp(parent.metadata.component_identity,left.metadata.component_identity)&&strcmp(edge.component_identity,left.metadata.component_identity), ...
            'C1EssentialComplete:SeamParent','Only after raw parent identity/actual same-owner edge binding may its NativeID be retained.');
        ownerRows=ix.metadata.source_owner_map;owners=find(cellfun(@(r)strcmp(r.output_component_identity,left.metadata.component_identity),ownerRows));
        assert(isscalar(owners)&&strcmp(ownerRows{owners}.source_component_identity,e.earned_physical_edge.owner),'C1EssentialComplete:SeamOwner','The explicit Consolidate owner map must preserve original earned ownership.');
        s=pickScalars(e,{'qualified','full_native_proof_validated','all_source_references_posthash_verified','identity_claimed','quotient_identification','new_continuation_edge_created','classification_or_admission_flags_changed'});
        s.original_full_runtime_retained_at_qualification=e.original_orbits_reports_and_native_IDs_retained;
        s=mergeScalars(s,pickScalars(c,{'raw_full13_delta','raw_full13_scaled_inf','period_delta','period_tolerance','full_stride_delta','full_stride_tolerance','native_energy_delta','exact_state_equal','exact_p_q_equal','exact_complete_policy_equal','same_section_event_signature','conditions_met'}));
        s=mergeScalars(s,matchingScalars(c.matching_section));s.earned_parent_native_id=parent.native_id;s.actual_new_points=e.earned_physical_edge.actual_new_points;s.actual_new_edges=e.earned_physical_edge.actual_new_edges;
        w=e.execution_witness;assert(strcmp(w.schema,'C1-external-GateB-process-exit-witness-v1')&&w.process_session_id==39141&&isequal(w.actual_process_exit_observed,true)&&w.exit_code==0 ...
            &&strcmp(w.run_name,'GateBOwned01')&&strcmp(w.audit_reference.sha256,e.proof_identity),'C1EssentialComplete:SeamExecution','Retain the original separately observed native process closure.');
        s.execution_witness_schema=w.schema;s.execution_session_id=w.process_session_id;s.execution_exit_observed=w.actual_process_exit_observed;s.execution_exit_code=w.exit_code;s.execution_run_name=w.run_name;
        s=mergeScalars(s,fineScalars(e.left_original_fines,'left'));s=mergeScalars(s,fineScalars(e.right_original_fines,'right'));
        fines=[fineProjection(e.left_original_fines,e.audit_reference);fineProjection(e.right_original_fines,e.audit_reference)];schema=e.schema;
    end
end

function out=fineProjection(rows,source)
    assert(iscell(rows)&&numel(rows)==2,'C1EssentialComplete:Fines','Each original endpoint retains exactly two ordered original-state fine observations.');out=cell(2,1);steps=[.0005,.00025];
    for k=1:2
        f=rows{k};requiredFields(f,{'observation','raw_custody','passed','MaxStep','full13_norm','initial_trajectory_row_exact','matching_saved_section','primitive','saved_period_scaled_error','saved_stride_scaled_error'},'original fine');
        assert(f.MaxStep==steps(k)&&isequal(f.passed,true)&&isequal(f.initial_trajectory_row_exact,true)&&isequal(f.matching_saved_section.compatible,true) ...
            &&f.primitive.cover_count==1&&strcmp(f.primitive.status,'primitive_within_checked_bound')&&f.full13_norm<=1e-8&&f.saved_period_scaled_error<=1e-8&&f.saved_stride_scaled_error<=1e-8 ...
            &&f.observation.invoked&&f.observation.returned&&f.observation.return_timely ...
            &&f.raw_custody.storage_completed&&f.raw_custody.storage_timely&&f.raw_custody.readback_completed&&f.raw_custody.readback_timely, ...
            'C1EssentialComplete:Fines','Preserve actual fine/primitive/original-state/timing/custody flags; no absent gate is manufactured.');
        out{k}=struct('source_reference',ref2(source),'MaxStep',f.MaxStep,'full_closure',f.full13_norm, ...
            'period_scaled_error',f.saved_period_scaled_error,'stride_scaled_error',f.saved_stride_scaled_error, ...
            'primitive',{{f.primitive.status;f.primitive.cover_count}},'invoked',f.observation.invoked,'returned',f.observation.returned,'return_timely',f.observation.return_timely, ...
            'storage_completed',f.raw_custody.storage_completed,'storage_timely',f.raw_custody.storage_timely,'readback_completed',f.raw_custody.readback_completed,'readback_timely',f.raw_custody.readback_timely,'passed',f.passed);
    end
end

function out=fineScalars(rows,side)
    out=struct();for k=1:2
        out.(sprintf('%s_fine%d_initial_trajectory_row_exact',side,k))=rows{k}.initial_trajectory_row_exact;
        out.(sprintf('%s_fine%d_matching_section_compatible',side,k))=rows{k}.matching_saved_section.compatible;
    end
end

function out=aliasTransport(e)
    historicalReference(e.qualification_source);r=e.request;exactFields(r,{'left_node','right_node','kind','input_request'},'Consolidate alias request');
    validateattributes(r.left_node,{'numeric'},{'real','scalar','finite','integer','positive'});validateattributes(r.right_node,{'numeric'},{'real','scalar','finite','integer','positive'});
    out=struct('alias_qualification_source_file',e.qualification_source.file,'alias_qualification_source_sha256',e.qualification_source.sha256, ...
        'alias_request_kind',r.kind,'alias_historical_left_node',r.left_node,'alias_historical_right_node',r.right_node);
    if strcmp(r.kind,'explicit_requested_numeric_alias')
        exactFields(r.input_request,{'left_file','left_index','right_file','right_index'},'explicit alias selector');
        for key={'left_file','right_file'},path=r.input_request.(key{1});assert((ischar(path)&&isrow(path)&&~isempty(path))||(isstring(path)&&isscalar(path)&&~ismissing(path)&&strlength(path)>0), ...
                'C1EssentialComplete:AliasLocator','Retain literal historical selector paths without reopening retired inputs.');end
        for key={'left_index','right_index'},validateattributes(r.input_request.(key{1}),{'numeric'},{'real','scalar','finite','integer','positive'});end
        out.alias_request_left_file=r.input_request.left_file;out.alias_request_left_index=r.input_request.left_index;out.alias_request_right_file=r.input_request.right_file;out.alias_request_right_index=r.input_request.right_index;
    else
        assert(strcmp(r.kind,'inherited_qualified_record_alias'),'C1EssentialComplete:AliasTransport','Unknown claimed alias-transport kinds require review.');
        exactFields(r.input_request,{'source_file','source_sha256','source_alias_row'},'inherited alias locator');
        historicalReference(struct('file',r.input_request.source_file,'sha256',r.input_request.source_sha256));validateattributes(r.input_request.source_alias_row,{'numeric'},{'real','scalar','finite','integer','positive'});
        out.alias_request_source_file=r.input_request.source_file;out.alias_request_source_sha256=r.input_request.source_sha256;out.alias_request_source_row=r.input_request.source_alias_row;
    end
end

function historicalReference(r)
    exactFields(r,{'file','sha256'},'historical file/SHA locator');
    assert(((ischar(r.file)&&isrow(r.file)&&~isempty(r.file))||(isstring(r.file)&&isscalar(r.file)&&~ismissing(r.file)&&strlength(r.file)>0)) ...
        &&ischar(r.sha256)&&isrow(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once')), ...
        'C1EssentialComplete:HistoricalReference','A historical locator requires literal scalar path text and lowercase SHA256; availability is not inferred.');
end

function classifierProjectionEqual(historical,retained)
    % Exact9f classifier contract: compare selected presence/order/leaves only.
    % Unselected original contact/display/sample trees are never copied.
    names={'contract_version','synchrony_predicate_version','label','alias','abbreviation','status','reason','validated_gait_type','canonical_point_label','canonical_label_qualified','suspension_reference_posture','primitive_flight_count','flight_count_certain','descriptive_only','isotropy_proved','period_used','flight_count','raw_positive_flight_count','flight_count_over_recorded_period','hind_pair_asymmetry','fore_pair_asymmetry','hind_pair_synchronized','front_pair_synchronized','fore_pair_synchronized','legacy_original_suffix_verified_flight_count','v3_abbreviation_suffix2_measured','displaylabel'};
    assert(isstruct(historical)&&isscalar(historical)&&isstruct(retained)&&isscalar(retained),'C1EssentialComplete:HistoricalClassifier','Both classifier projections must preserve scalar structure.');
    keys=fieldnames(historical);expected=keys(ismember(keys,names));
    for key={'contact_reconstruction','tolerances','borderline'},if isfield(historical,key{1}),expected{end+1,1}=key{1};end,end
    assert(isequal(fieldnames(retained),expected),'C1EssentialComplete:HistoricalClassifier','Retained classifier field presence and projection order must match the historical contract.');
    for k=1:numel(expected)
        key=expected{k};
        if strcmp(key,'contact_reconstruction')
            retainedSubsetEqual(historical.(key),retained.(key),{'complete','reason','initial_mode','final_mode','cohorts','event_time_tolerance','atomic_cohorts'},{},'historical contact projection');
        elseif strcmp(key,'tolerances')
            retainedSubsetEqual(historical.(key),retained.(key),{'ContactTolerance','MotionTolerance','AngleTolerance','RateTolerance','StanceRateTolerance','SyncFlowTolerance','ParameterTolerance','ApexTolerance','EventTimeTolerance','FlightDurationTolerance','ObservationRelTol','ObservationAbsTol','ObservationMaxStep','ObservationSafetyFactor','GeometryTolerance','SampleCount'},{'PrimitiveOptions'},'historical tolerance projection');
        else,rawEqual3(historical.(key),retained.(key),retained.(key),'historical retained classifier value');end
    end
end

function retainedSubsetEqual(historical,retained,names,tail,label)
    assert(isstruct(historical)&&isscalar(historical)&&isstruct(retained)&&isscalar(retained),'C1EssentialComplete:HistoricalClassifier','The %s must preserve scalar structure.',label);
    keys=fieldnames(historical);expected=keys(ismember(keys,names));for k=1:numel(tail),if isfield(historical,tail{k}),expected{end+1,1}=tail{k};end,end
    assert(isequal(fieldnames(retained),expected),'C1EssentialComplete:HistoricalClassifier','The %s must preserve every retained field and its literal missingness/order.',label);
    for k=1:numel(expected),key=expected{k};rawEqual3(historical.(key),retained.(key),retained.(key),label);end
end

function bindIDs(e,left,right)
    assert(strcmp(e.left_native_ID,left.native_id)&&strcmp(e.right_native_ID,right.native_id),'C1EssentialComplete:HistoricalID','Original qualifier IDs must match both literal actual endpoints.');
end

function out=identityRecord(r)
    o=r.orbit;out=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement,'return_policy_name',o.return_policy_name);
end

function checkAdmission(a,r,numerical)
    assert(isequal(a.all_nine_literal_true,true)&&isequal(a.accepted,true),'C1EssentialComplete:HistoricalAdmission','Original historical all-nine/accepted flags must remain true.');
    names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    assert(isfield(r.report,'acceptance_gates')&&all(cellfun(@(n)isfield(r.report.acceptance_gates,n)&&isequal(r.report.acceptance_gates.(n),true),names)), ...
        'C1EssentialComplete:HistoricalAdmission','Every literal retained root gate must agree with the existing historical qualification.');
    status='';if isfield(r.report,'status'),status=r.report.status;elseif isfield(r.report,'native_status'),status=r.report.native_status;end
    assert(isequaln(a.stored_status,status),'C1EssentialComplete:HistoricalAdmission','Original stored admission status must bind the actual retained report.');
    if numerical
        assert(r.policy.complete,'C1EssentialComplete:HistoricalPolicy','Numerical qualification requires the actual complete retained policy.');rawEqual3(a.policy_configuration,r.policy.configuration,r.policy.configuration,'numerical admission policy');
        classifierProjectionEqual(a.classification,r.report.classification);
    else
        g=r.report.classification;assert(strcmp(a.classification_contract,g.contract_version)&&strcmp(a.canonical_point_label,g.canonical_point_label)&&strcmp(a.validated_gait_type,g.validated_gait_type) ...
            &&isequaln(a.flight_count_certain,g.flight_count_certain)&&isequaln(a.flight_count,g.flight_count),'C1EssentialComplete:HistoricalClassifier','Alias scalar admission/classification facts must bind the actual retained classifier.');
    end
end

function checkMatching(m,left,right)
    assert(isequal(m.compatible,true)&&isequal(m.actual_policy_configuration_checked,true)&&isequal(m.policy_configuration_matches_declared_identity,true)&&isequal(m.rephase_or_chart_transition_inferred,false) ...
        &&isempty(m.left_missing_fields)&&isempty(m.right_missing_fields),'C1EssentialComplete:HistoricalSection','The known original MatchingReturnSection evidence must be complete and unchanged.');
    rawEqual3(m.left_identity,sectionIdentity(left),sectionIdentity(left),'historical left section');rawEqual3(m.right_identity,sectionIdentity(right),sectionIdentity(right),'historical right section');
    assert(left.policy.complete&&right.policy.complete,'C1EssentialComplete:HistoricalPolicy','Both actual retained policies must remain complete.');
    rawEqual3(m.left_policy_configuration,left.policy.configuration,left.policy.configuration,'historical left policy');rawEqual3(m.right_policy_configuration,right.policy.configuration,right.policy.configuration,'historical right policy');
end

function out=sectionIdentity(r)
    o=r.orbit;name=char(o.return_policy_name);assert(~isempty(name),'C1EssentialComplete:SectionName','A qualified known section cannot acquire a missing/fallback policy name.');
    out=struct('return_policy_name',name,'initial_mode',logical(o.initial_mode(:)),'section',struct(),'return_occurrence',1);
    keys={'id','geometry','crossing_orientation','boundary_ownership','translational_gauge'};
    for k=1:numel(keys),assert(isfield(o.section_chart,keys{k}),'C1EssentialComplete:Section','A known qualified section field is missing.');out.section.(keys{k})=o.section_chart.(keys{k});end
    if ismember(name,{'BL-marked-apex-return','BLMarkedApexReturnPolicy_v3'}),out.return_occurrence=o.section_chart.BL_touchdowns_per_return;
    elseif ismember(name,{'iterated-section-return','IteratedReturnPolicy_v3'}),out.return_occurrence=o.return_multiplicity;end
end

function out=matchingScalars(m)
    out=struct('matching_section_compatible',m.compatible,'actual_policy_configuration_checked',m.actual_policy_configuration_checked, ...
        'policy_configuration_matches_declared_identity',m.policy_configuration_matches_declared_identity,'rephase_or_chart_transition_inferred',m.rephase_or_chart_transition_inferred);
end

function out=pickScalars(value,names)
    requiredFields(value,names,'known scalar evidence');out=struct();for k=1:numel(names),out.(names{k})=value.(names{k});end
end

function out=mergeScalars(out,extra)
    for key=fieldnames(extra).',assert(~isfield(out,key{1}),'C1EssentialComplete:EvidenceCollision','Essential scalar evidence fields must be distinct.');out.(key{1})=extra.(key{1});end
end

function exactFields(value,names,label)
    assert(isstruct(value)&&isscalar(value)&&isequal(sort(fieldnames(value)),sort(names(:))),'C1EssentialComplete:KnownSchema','Use the exact source-backed %s fieldset; unknown qualifications refuse.',label);
end

function requiredFields(value,names,label)
    assert(isstruct(value)&&isscalar(value)&&all(isfield(value,names)),'C1EssentialComplete:RequiredEvidence','The known %s is missing required actual fields.',label);
end

function counts=countRoles(roles)
    names=EssentialBranchSolutionFile_v3.contract();names=names.roles;counts=struct();for k=1:numel(names),counts.(strrep(names{k},'-','_'))=sum(strcmp(roles,names{k}));end
end

function out=stageNames(folder)
    d=dir(fullfile(folder,'*.essential_stage.mat'));out=sort(cellfun(@(n)canonical(fullfile(folder,n)),{d.name}.','UniformOutput',false));
end

function out=ref2(r),out=struct('file',canonical(r.file),'sha256',r.sha256);end

function rawEqual3(expected,a,b,where)
    assert(strcmp(class(expected),class(a))&&strcmp(class(expected),class(b))&&isequal(size(expected),size(a),size(b)),'C1PackedPilot:ExactType','Type/shape changed at %s.',where);
    if isnumeric(expected)
        assert(isequal(isreal(expected),isreal(a),isreal(b)),'C1PackedPilot:ExactRealness','Numeric realness changed at %s.',where);
        assert(isequal(typecast(real(expected(:)),'uint8'),typecast(real(a(:)),'uint8'),typecast(real(b(:)),'uint8')),'C1PackedPilot:ExactBytes','Real numeric raw bytes changed at %s.',where);
        if ~isreal(expected),assert(isequal(typecast(imag(expected(:)),'uint8'),typecast(imag(a(:)),'uint8'),typecast(imag(b(:)),'uint8')),'C1PackedPilot:ExactBytes','Imaginary raw bytes changed at %s.',where);end
    elseif islogical(expected)||ischar(expected)
        assert(isequal(expected,a,b),'C1PackedPilot:ExactValue','Literal values changed at %s.',where);
    elseif isstring(expected)
        assert(isequaln(expected,a,b),'C1PackedPilot:ExactString','Literal strings/missingness changed at %s.',where);
    elseif iscell(expected)
        for k=1:numel(expected),rawEqual3(expected{k},a{k},b{k},sprintf('%s{%d}',where,k));end
    elseif isstruct(expected)
        f=fieldnames(expected);assert(isequal(f,fieldnames(a),fieldnames(b)),'C1PackedPilot:ExactFields','Field names/order changed at %s.',where);
        for k=1:numel(expected),for j=1:numel(f),rawEqual3(expected(k).(f{j}),a(k).(f{j}),b(k).(f{j}),[where,'.',f{j}]);end,end
    else
        error('C1PackedPilot:ExactClass','Unsupported projection class %s at %s.',class(expected),where);
    end
end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function paths=coreRoster(root,merged)
    d=dir(fullfile(root,'Components'));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==43&&~any([d.isdir])&&all(endsWith(lower(string({d.name})),'.mat'))&&~any(contains(lower(string({d.name})),'pending')),'C1MergedB:OriginalCores','Keep exact43 untouched core MATs and no unknown stage.');paths=cellfun(@(n)canonical(fullfile(root,'Components',n)),{d.name}.','UniformOutput',false);
    d=dir(fileparts(merged));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==1&&~d.isdir&&strcmp(canonical(fullfile(d.folder,d.name)),merged),'C1MergedB:MergedDirectory','The permanent merged directory contains exactly its current one MAT with no random/stage file.');paths=sort([paths;{merged}]);
end

function l=finalStorageLimit(b),l=struct('utc',b.deadline_unix_seconds,'mono',b.deadline_monotonic_ns);end

function l=minLimit(a,b),l=struct('utc',min(a.utc,b.utc),'mono',min(a.mono,b.mono));end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1Pilot:Resolver','A guarded implementation resolves elsewhere.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Pilot:Changed','A guarded authority/source/core changed.');end,end

function r=reference(f),assert(isfile(f),'C1Pilot:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function move(a,b,replace),if replace,v=javaArray('java.nio.file.CopyOption',2);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');v(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');else,fresh({b});v=javaArray('java.nio.file.CopyOption',1);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');end;javaMethod('move','java.nio.file.Files',java.io.File(a).toPath(),java.io.File(b).toPath(),v);end

function fresh(files),for k=1:numel(files),assert(~isfile(files{k})&&~isfolder(files{k}),'C1Pilot:Fresh','Retain an existing authority or uncertain stage.');end,end

function e=exceptionData(x),causes=cell(size(x.cause));for k=1:numel(causes),causes{k}=exceptionData(x.cause{k});end;e=struct('identifier',x.identifier,'message',x.message,'stack',x.stack,'causes',{causes});end

function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end

function t=pairClock(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function t=shift(t,s),t.utc=t.utc+s;t.mono=t.mono+s*1e9;end

function v=left(t),v=min(t.utc-posixtime(datetime('now','TimeZone','UTC')),(t.mono-double(java.lang.System.nanoTime))/1e9);end

function check(t),assert(left(t)>0,'C1Pilot:Clock','The fixed whole/local/science clock expired.');end

function s=stamp(),s=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

function sourceValidateValue(value, allowNative, depth)
    assert(depth <= 128, 'BranchSolutionFile_v3:Depth', ...
        'Cyclic or excessively nested data is unsupported.');
    if isnumeric(value) || islogical(value) || ischar(value) || isstring(value)
        return
    elseif iscell(value)
        for k = 1:numel(value)
            sourceValidateValue(value{k}, allowNative, depth + 1);
        end
    elseif isstruct(value)
        names = fieldnames(value);
        for k = 1:numel(value)
            for j = 1:numel(names)
                sourceValidateValue(value(k).(names{j}), allowNative, depth + 1);
            end
        end
    elseif allowNative && any(strcmp(class(value), {'HybridOrbit_v3', 'Trajectory_v3'}))
        names = properties(value);
        for k = 1:numel(value)
            for j = 1:numel(names)
                sourceValidateValue(value(k).(names{j}), true, depth + 1);
            end
        end
    else
        error('BranchSolutionFile_v3:ValueClass', ...
            'Unsupported data class %s; reports and metadata must contain plain data.', class(value));
    end
end

function validateClosedSource(w,source,N)
    keys={'schema','process_session_id','exit_code','actual_process_exit_observed','custody_complete','closure_reference','source_reference','source_point_count'};
    assert(isstruct(w)&&isscalar(w)&&all(isfield(w,keys))&&all(ismember(fieldnames(w),[keys,{'scope'}].')),'C1PKThin:Boundary','Use the existing closed-native-source-boundary fields only.');
    assert(strcmp(w.schema,'C1-closed-native-source-boundary-v1')&&isequal(w.exit_code,0)&&isequal(w.actual_process_exit_observed,true)&&isequal(w.custody_complete,true), ...
        'C1PKThin:Boundary','A separately observed closed/custodied raw-source snapshot is required.');
    validateattributes(w.process_session_id,{'double'},{'real','scalar','finite','integer','positive'});
    assert(isequaln(ref2(w.source_reference),ref2(source))&&isequal(w.source_point_count,N),'C1PKThin:BoundarySource','Bind this exact current raw source SHA/count.');checked(w.closure_reference);
    if isfield(w,'scope'),assert(ischar(w.scope)&&isrow(w.scope)&&~isempty(w.scope),'C1PKThin:BoundaryScope');end
end

function [rows,proof]=validateLegacyMap(snapshot,map,ix,limit)
    assert(iscell(map)&&(isequal(size(map),[6,1])||isequal(size(map),[0,1])), ...
        'C1PKThin:LegacyMap','Supply six declared rows or an explicit empty column cell to derive them during this native intake.');
    check(limit);before=reference(snapshot.file);old=EssentialBranchSolutionFile_v3.index(snapshot.file);verify({snapshot});
    assert(strcmp(before.sha256,snapshot.sha256)&&numel(old.points)==465&&numel(ix.points)>=numel(old.points),'C1PKThin:LegacySnapshot','The reference is the historical465 snapshot; current count is read independently and may have grown.');
    [thin,reports,metadata]=EssentialBranchSolutionFile_v3.loadSolutions(snapshot.file,(289:294).');
    rows=cell(6,1);declared=~isempty(map);
    for j=1:6
        k=288+j;marker=thin{j}.schema_metadata.essential_storage;
        rawEqual3(marker,reports{j}.essential_storage,reports{j}.essential_storage,'actual historical snapshot complete marker');
        assert(marker.context.source_index==k&&marker.context.expected_index==k,'C1PKThin:LegacyContext','Use the actual original occurrence context.');
        projected=EssentialBranchSolutionFile_v3.project(thin{j},reports{j},metadata{j},marker.context);
        originalDigest=lower(reshape(dec2hex(old.record_projection_digests(:,k),2).',1,[]));
        assert(strcmp(C1ScientificDigest_v3(projected),originalDigest)&&isequaln(projected.native_id,old.record_native_ids{k}) ...
            &&isequaln(OrbitContentIdentity_v3(thin{j}),old.record_native_ids{k}), ...
            'C1PKThin:LegacyRead2','Independent historical index and selected-thin read must reconstruct the same canonical digest and actual native identity.');
        if declared
            exactFields(map{j},{'source_index','native_id'},'declared legacy identity row');
            assert(isequal(map{j}.source_index,k)&&ischar(map{j}.native_id)&&isrow(map{j}.native_id)&&~isempty(map{j}.native_id) ...
                &&isequaln(map{j}.native_id,old.record_native_ids{k}),'C1PKThin:LegacyID','Declared identities must equal actual historical snapshot index IDs.');
            rows{j}=map{j};
        else
            rows{j}=struct('source_index',k,'native_id',old.record_native_ids{k});
        end
        assert(isequaln(ix.points{k}.component_identity,old.points{k}.component_identity)&&isequaln(ix.points{k}.order,old.points{k}.order), ...
            'C1PKThin:LegacyOwner','The six source indices retain original owner/order, not a merely nearby or relabeled record.');
    end
    proof=struct('historical_snapshot_reference',ref2(snapshot),'historical_point_count',numel(old.points), ...
        'identity_rows',{rows},'caller_map_supplied',declared,'actual_public_index_reads',1,'actual_public_selected_thin_reads',1, ...
        'historical_read2_canonical_identity_verified',true,'historical_ids_verified',true,'current_raw_ids_verified_during_each_independent_projection',false, ...
        'scope','Original465 snapshot is an identity-selector authority only; it does not prove current raw projection equality or branch completion.');
    clear old thin reports metadata projected;verify({snapshot});check(limit);
end

function refuseExtraLegacyDescriptors(report)
    for envelope={'integration','replay_integration'}
        if ~isfield(report,envelope{1}),continue;end;in=report.(envelope{1});
        if ~isstruct(in)||~isscalar(in),continue;end
        if isfield(in,'ODESolver'),refuseMarker(in.ODESolver);end
        if isfield(in,'ODEOptions')&&isstruct(in.ODEOptions)&&isscalar(in.ODEOptions)&&isfield(in.ODEOptions,'OutputFcn'),refuseMarker(in.ODEOptions.OutputFcn);end
    end
    if isfield(report,'options')&&isstruct(report.options)&&isscalar(report.options)&&isfield(report.options,'SolverOptions')
        so=report.options.SolverOptions;if isstruct(so)&&isscalar(so)&&isfield(so,'Jacobian'),refuseMarker(so.Jacobian);end
    end
    function refuseMarker(value)
        assert(~(isstruct(value)&&isscalar(value)&&(isfield(value,'runtime_class')||isfield(value,'reconstruction_required'))), ...
            'C1PKThin:ExtraLegacyDescriptor','Observed saved runtime markers outside the six proven identities require separate source/data review.');
    end
end

function receipt=creationGraphReceipt(ix,source)
    assert(isfield(ix.metadata,'component_graph'),'C1PKThin:CreationGraph','Retain the original frozen creation graph separately from current physical edges.');g=ix.metadata.component_graph;
    current=zeros(numel(ix.edges),2);
    for k=1:numel(ix.edges),current(k,:)=[ix.edges{k}.from,ix.edges{k}.to];end
    for k=1:size(g.original_explicit_edges,1)
        pair=g.original_explicit_edges(k,:);hits=find(all(current==pair,2));
        assert(isscalar(hits),'C1PKThin:CreationPhysicalPrefix','Each original physical snapshot pair must remain an actual current physical edge, once.');
    end
    receipt=struct('source_reference',ref2(source),'original_graph_digest',C1ScientificDigest_v3(g),'schema',g.schema,'snapshot_nodes',g.nodes, ...
        'original_explicit_edges',g.original_explicit_edges,'effective_edges',g.effective_edges,'exact_record_equalities',g.exact_record_equalities, ...
        'qualified_record_aliases',g.qualified_record_aliases,'known_numerical_table_present',isfield(g,'qualified_numerical_overlaps'), ...
        'current_point_count',numel(ix.points),'current_physical_edge_count',numel(ix.edges),'scope','Frozen creation snapshot only; current ix.edges is the physical authority. External Round/meeting coverage is not a canonical graph relation.');
    if isfield(g,'qualified_numerical_overlaps'),receipt.qualified_numerical_overlaps=g.qualified_numerical_overlaps;end
end

function checkReturnedIndex(ix,records,branch,digests)
    N=numel(records);assert(numel(ix.points)==N&&isa(ix.record_projection_digests,'uint8')&&isequal(size(ix.record_projection_digests),[32,N]),'C1PKThin:ReturnedIndex');
    assert(strcmp(C1ScientificDigest_v3(ix.metadata),C1ScientificDigest_v3(branch)),'C1PKThin:ReturnedGraph','All typed graph metadata must remain literal.');
    for k=1:N
        actual=lower(reshape(dec2hex(ix.record_projection_digests(:,k),2).',1,[]));r=records{k};
        assert(strcmp(actual,digests{k})&&isequaln(ix.record_native_ids{k},r.native_id)&&isequaln(ix.occurrence_ids{k},r.context.occurrence_id) ...
            &&isequaln(ix.points{k}.component_identity,r.metadata.component_identity)&&isequaln(ix.points{k}.order,r.metadata.order), ...
            'C1PKThin:ReturnedRecord','Returned public index must preserve every ordered canonical digest/ID/owner/context.');
    end
end

function publishAudit(file,audit,limit)
    check(limit);stage=[file,'.pending.mat'];fresh({stage});save(stage,'audit','-v7');
    a=load(stage,'audit');b=load(stage,'audit');rawEqual3(audit,a.audit,b.audit,'concise native audit stage read2');check(limit);
    move(stage,file,isfile(file)); % Same-directory atomic publication; retain uncertain stage on refusal.
    a=load(file,'audit');b=load(file,'audit');rawEqual3(audit,a.audit,b.audit,'concise native audit installed read2');check(limit);
end

function refs=uniqueReferences(rows)
    validateReferenceCells(rows,'reference union');refs=cell(0,1);paths=cell(0,1);
    for k=1:numel(rows)
        r=checked(rows{k});hit=find(strcmp(paths,r.file));
        if isempty(hit),refs{end+1,1}=r;paths{end+1,1}=r.file;else,assert(isequaln(refs{hit},r),'C1PKThin:ReferenceConflict','Duplicate paths must have identical full declared references.');end
    end
end

function validateReferenceCells(rows,label)
    assert(iscell(rows)&&(isvector(rows)||isempty(rows)),'C1PKThin:References','Use explicit cell-vector %s; column views do not rewrite caller shape.',label);
    for k=1:numel(rows)
        r=rows{k};assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})) ...
            &&((ischar(r.file)&&isrow(r.file)&&~isempty(r.file))||(isstring(r.file)&&isscalar(r.file)&&~ismissing(r.file)&&strlength(r.file)>0)) ...
            &&ischar(r.sha256)&&isrow(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once')), ...
            'C1PKThin:ReferenceShape','Every %s entry needs one exact file/lowercaseSHA reference.',label);
    end
end

function names=allResultsRoster(root)
    folder=fullfile(root,'Results');rows=dir(folder);rows=rows(~[rows.isdir]);rows=rows(~startsWith({rows.name},'.'));
    names=sort(arrayfun(@(r)canonical(fullfile(r.folder,r.name)),rows(:),'UniformOutput',false));
end

function assertMat(file)
    [~,~,extension]=fileparts(file);assert(strcmp(extension,'.mat'),'C1PKThin:MAT','Use an explicit fresh MAT output path.');
end

