function audit=QualifyC1PKThinSnapshot20261031(writerClosure,writeAuditReference,P1AuditReference,options)
%QUALIFYC1PKTHINSNAPSHOT20261031 Fresh-process saved-value/P1 scalar audit.
% ONE strict public index + TWO ALL bulk thin passes, plus a separately
% counted strict storageStatistics read. No raw orbit load, Root, integration,
% replay, classification, new admission, graph edit or manifest publication.
% The supplied closed-source capsule and NEW complete67e receipt bind runtime
% counts. Later native growth requires a new declared frozen boundary.
    entered=pairClock();root=canonical(fileparts(which('C1RunBudget_v3')));
    exactFields(options,{'ClosedSourceReference','OutputAuditFile','KernelReference','DigestReference','ProtectedReferences'},'thin-reader options');o=options;
    writeAuditReference=checked(writeAuditReference);P1AuditReference=checked(P1AuditReference);
    o.ClosedSourceReference=checked(o.ClosedSourceReference);o.KernelReference=checked(o.KernelReference);o.DigestReference=checked(o.DigestReference);
    assert(strcmp(o.KernelReference.sha256,'60a9ff5336ac094be2254d863511139c3488f32fc39b17837b18935d851fd792') ...
        &&strcmp(o.DigestReference.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'), ...
        'C1PKThinRead:Methods','Use unchanged public K60/Digest0027; leaf interning is a separate experiment.');
    validateReferenceCells(o.ProtectedReferences,'current protected authorities');
    budget=C1RunBudget_v3();fence=finalStorageLimit(budget);
    assert(left(fence)>2402,'C1PKThinRead:WholeFit','The full2400s cap must fit BOTH original FINAL clocks.');
    finish=minLimit(shift(entered,2400),fence);work=shift(finish,-120);
    file=canonical(o.OutputAuditFile);assertMat(file);assert(isfolder(fileparts(file)),'C1PKThinRead:OutputParent');
    fresh({file,[file,'.pending.mat']});o.OutputAuditFile=file;
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));
    lease=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
    a=load(writeAuditReference.file,'audit');b=load(writeAuditReference.file,'audit');w=a.audit;
    rawEqual3(w,a.audit,b.audit,'independent writer receipt reads');clear a b
    [N,graphCounts]=validateWriter(w,writerClosure,o.ClosedSourceReference);
    candidate=checked(w.candidate_reference);source=checked(w.source_reference);
    assert(isequaln(w.budget,budget),'C1PKThinRead:Budget','Fresh qualification retains the same literal original grant value.');
    boundary=w.closed_source_boundary;validateClosedSource(boundary,source,N);
    assert(isequaln(ref2(boundary.closure_reference),ref2(o.ClosedSourceReference)),'C1PKThinRead:CapsuleBinding');
    absent={[ledger,'.pending.mat'],[ledger(1:end-4),'_active_checkpoint.mat'],[ledger(1:end-4),'_active_checkpoint.mat.pending.mat'],[source.file,'.pending.mat']};
    fresh(absent);beforeCore=coreRoster(root,source.file);beforeResults=allResultsRoster(root);
    assert(~ismember(file,[beforeCore;beforeResults;{ledger}])&&~strcmp(file,candidate.file), ...
        'C1PKThinRead:Additive','Only one fresh audit is written; no scientific authority is replaced.');
    a=load(P1AuditReference.file,'audit');b=load(P1AuditReference.file,'audit');p1=a.audit;
    rawEqual3(p1,a.audit,b.audit,'original P1 audit native read2');clear a b
    [p1Scalars,geometryCode,p1Source]=referenceScalars(p1);clear p1
    validateReferenceCells(w.input_references,'writer protected inputs');validateReferenceCells(w.source_code,'writer method closure');
    refs=normalReferences([o.ProtectedReferences(:);w.input_references(:);{writeAuditReference;P1AuditReference;candidate;source; ...
        o.ClosedSourceReference;writerClosure.closure_reference;writerClosure.source_reference;p1Source}]);
    code=normalReferences([w.source_code(:);geometryCode(:);{o.KernelReference;o.DigestReference; ...
        reference([mfilename('fullpath'),'.m']);reference(which('C1RunBudget_v3'))}]);
    paths=cellfun(@(r)canonical(r.file),refs,'UniformOutput',false);
    assert(all(ismember([beforeCore;beforeResults;{ledger}],paths)),'C1PKThinRead:ProtectedUnion','Protect actual current44 cores, complete Results roster and journal.');
    assert(~ismember(file,paths),'C1PKThinRead:FreshAudit');
    methodPaths=cellfun(@(r)canonical(r.file),code,'UniformOutput',false);
    for name={'EssentialBranchSolutionFile_v3','C1ScientificDigest_v3','RoundSHA256_v3','HybridOrbit_v3','Trajectory_v3', ...
            'OrbitContentIdentity_v3','RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3','QuadrupedEnergy_v3','QuadrupedSchema_v3'}
        resolved=canonical(which(name{1}));
        if ~ismember(resolved,methodPaths)
            hit=find(strcmp(paths,resolved));assert(isscalar(hit),'C1PKThinRead:MethodClosure','Supply current protected source pin for %s.',name{1});
            code{end+1,1}=refs{hit};methodPaths{end+1,1}=resolved;
        end
    end
    assert(strcmp(canonical(which('EssentialBranchSolutionFile_v3')),o.KernelReference.file) ...
        &&strcmp(canonical(which('C1ScientificDigest_v3')),o.DigestReference.file),'C1PKThinRead:Resolver');
    d=dir(candidate.file);v2=dir(p1Source.file);assert(isscalar(d)&&~d.isdir&&isscalar(v2)&&~v2.isdir,'C1PKThinRead:Bytes');
    assert(d.bytes==w.actual_candidate_bytes&&d.bytes<=w.operational_maximum_bytes,'C1PKThinRead:OperationalCap');
    if isfield(p1Source,'bytes'),assert(v2.bytes==p1Source.bytes,'C1PKThinRead:OriginalV2Bytes');end
    assert(v2.bytes>0&&v2.bytes<=flintmax/5,'C1PKThinRead:OriginalV2Bytes');
    audit=struct('schema','C1-PK-thin-snapshot-fresh-reader-P1-audit-v1','options',o,'budget',budget, ...
        'started_utc',stamp(),'finished_utc','','writer_closure',writerClosure,'write_audit_reference',writeAuditReference, ...
        'P1_audit_reference',P1AuditReference,'closed_source_reference',o.ClosedSourceReference, ...
        'source_reference',source,'candidate_reference',candidate,'source_point_count',N, ...
        'source_physical_edge_count',graphCounts.physical_edges,'typed_graph_counts',graphCounts,'closed_source_boundary',boundary,'source_code',{code},'input_references',{refs}, ...
        'wrapper',struct('declared_seconds',2400,'save_post_reserve_seconds',120,'original_final_deadline',fence), ...
        'phase','prepared','completed',false,'failure',struct(),'own_process_exit_observed',false, ...
        'public_index_reads',0,'all_bulk_thin_reads',0,'storage_statistics_reads',0, ...
        'all_ordered_canonical_digests_verified',false,'all_identity_owner_context_bindings_verified',false, ...
        'cross_pass_handle_independence_verified',false,'typed_graph_verified',false,'source_posthash',false, ...
        'typed_graph',struct(),'literal_essential_graph_metadata',struct(),'typed_graph_digest','','frozen_creation_graph',w.frozen_creation_graph, ...
        'external_finite_evidence_references',{w.external_finite_evidence_references}, ...
        'P1',p1Scalars,'native_scalars',struct(),'groups',struct(),'storage_statistics',struct(), ...
        'actual_export_bytes',d.bytes,'operational_maximum_bytes',w.operational_maximum_bytes, ...
        'original_v2_reference',p1Source,'original_v2_bytes',v2.bytes,'original_v2_point_count',numel(p1Scalars.source_columns), ...
        'final_target_bytes',5*v2.bytes,'final_target_passed',d.bytes<=5*v2.bytes, ...
        'pass_elapsed_seconds',zeros(2,1),'returned_payload_whos_bytes',zeros(2,1), ...
        'external_peak_RSS_measured',false,'external_peak_RSS_bytes',[], ...
        'source_currentness_claimed',false,'current_journal_semantic_read_claimed',false, ...
        'P1_native_admission_claimed',false,'P1_identity_or_attachment_claimed',false, ...
        'physical_endpoint_claimed',false,'exact_grazing_claimed',false,'full_branch_completion_claimed',false, ...
        'new_integration_root_replay_classification_admission_calls',0,'published_additive_export',false);
    audit.snapshot_scope='Exact caller-supplied closed-source capsule plus independently complete NEW67e writer receipt. Runtime N and all typed graph counts bind that frozen snapshot only; later growth requires a new declared boundary, not a rebased old receipt. No family completion is inferred.';
    audit.readback_scope='One strict public index and TWO ALL public bulk thin loads; every actual marker context is independently reprojected against the67e writer receipt. storageStatistics is an additional strict decoded read.';
    audit.graph_scope='Literal current physical edges, exact equalities, qualified aliases and numerical seams stay distinct. Frozen creation graph remains separate. External471/115 and unit evidence insert no canonical relation.';
    audit.range_scope='Paired P1 columns/masks and per-group coordinate envelopes only. Envelope containment is not continuous-curve coverage, P1 attachment, exact identity, endpoint or completed direction.';
    audit.statistics_scope='Actual compressed bytes and worker elapsed times are separate from decoded/native-whos bytes and external process peak RSS. 5x is observational, not an admission gate.';
    guard(work);publishAudit(file,audit,finish);
    try
        started=pairClock();fprintf('C1_PK_THIN_READER_BEFORE_INDEX\n');ix=EssentialBranchSolutionFile_v3.index(candidate.file);audit.public_index_reads=1;fprintf('C1_PK_THIN_READER_AFTER_INDEX_RETURN\n');
        check(work);validateIndex(ix,w,N,graphCounts);audit.typed_graph=compactGraph(ix);audit.literal_essential_graph_metadata=ix.metadata;
        audit.typed_graph_digest=C1ScientificDigest_v3(ix.metadata);
        audit.typed_graph_verified=true;audit.index_elapsed_seconds=(pairClockMono()-started.mono)/1e9;
        kept=[];keptReport=[];keptMetadata=[];keptContext=[];
        for pass=1:2
            guard(work);started=pairClock();fprintf('C1_PK_THIN_READER_BEFORE_ALL_LOAD pass=%d\n',pass);[orbits,reports,metadata]=EssentialBranchSolutionFile_v3.loadSolutions(candidate.file,(1:N).');audit.all_bulk_thin_reads=pass;fprintf('C1_PK_THIN_READER_AFTER_ALL_LOAD_RETURN pass=%d\n',pass); % Return fact precedes the literal marker and all fallible postchecks.
            check(work);assert(iscell(orbits)&&iscell(reports)&&iscell(metadata)&&isequal(size(orbits),[N,1]) ...
                &&isequal(size(reports),[N,1])&&isequal(size(metadata),[N,1]),'C1PKThinRead:BulkCount','BOTH independently returned ALL payloads must match the writer-bound positive runtime N.');
            entries=whos('orbits','reports','metadata');audit.returned_payload_whos_bytes(pass)=sum([entries.bytes]);
            if pass==2,assert(~(kept==orbits{1}),'C1PKThinRead:HandleIndependence','Separate bulk calls must create independent native handles.');end
            fprintf('C1_PK_THIN_READER_BEFORE_OUTER_PROJECTION_PASS pass=%d\n',pass);
            for k=1:N
                check(work);marker=orbits{k}.schema_metadata.essential_storage;
                rawEqual3(marker,reports{k}.essential_storage,reports{k}.essential_storage,'actual orbit/report complete marker');
                binding=struct('source_index',k,'native_id',marker.native_id,'occurrence_id',marker.context.occurrence_id, ...
                    'component_identity',metadata{k}.component_identity,'order',metadata{k}.order,'context',marker.context);
                rawEqual3(w.record_bindings{k},binding,binding,'independent writer occurrence/owner/context binding');
                assert(isequaln(metadata{k},ix.points{k}.metadata)&&isequaln(marker.context,ix.points{k}.provenance) ...
                    &&isequaln(marker.native_id,ix.record_native_ids{k}),'C1PKThinRead:IndexBinding');
                actual=EssentialBranchSolutionFile_v3.project(orbits{k},reports{k},metadata{k},marker.context);
                assert(strcmp(C1ScientificDigest_v3(actual),w.record_digests{k}) ...
                    &&isequaln(actual.native_id,w.record_bindings{k}.native_id),'C1PKThinRead:IndependentDigest','Recompute each ordered digest from returned values and ACTUAL context, never the stored digest field alone.');
                clear actual marker binding
            end
            fprintf('C1_PK_THIN_READER_AFTER_OUTER_PROJECTION_PASS pass=%d\n',pass);
            scalars=nativeScalars(orbits,reports,metadata,work);
            if pass==1
                audit.native_scalars=scalars;kept=orbits{1};keptReport=reports{1};keptMetadata=metadata{1};keptContext=kept.schema_metadata.essential_storage.context;
            else
                rawEqual3(audit.native_scalars,scalars,scalars,'both passes scalar/predicate observations');
                retained=EssentialBranchSolutionFile_v3.project(kept,keptReport,keptMetadata,keptContext);
                assert(strcmp(C1ScientificDigest_v3(retained),w.record_digests{1}),'C1PKThinRead:RetainedHandle','The bounded first-pass handle remains unchanged after pass2.');clear retained
                audit.cross_pass_handle_independence_verified=true;
            end
            clear orbits reports metadata scalars entries
            audit.pass_elapsed_seconds(pass)=(pairClockMono()-started.mono)/1e9;guard(work);
        end
        clear kept keptReport keptMetadata keptContext
        audit.all_ordered_canonical_digests_verified=true;audit.all_identity_owner_context_bindings_verified=true;
        audit.groups=groupEnvelopes(audit.typed_graph,audit.native_scalars,audit.P1,N);
        guard(work);started=pairClock();fprintf('C1_PK_THIN_READER_BEFORE_STORAGE_STATISTICS\n');audit.storage_statistics=EssentialBranchSolutionFile_v3.storageStatistics(candidate.file);audit.storage_statistics_reads=1;fprintf('C1_PK_THIN_READER_AFTER_STORAGE_STATISTICS_RETURN\n');
        assert(isequal(audit.storage_statistics.point_count,N)&&isequaln(audit.storage_statistics.graph_rows,graphCounts),'C1PKThinRead:StatisticsCount','The extra strict decoded statistics read must preserve runtime N and all four independent writer graph counts.');
        audit.storage_statistics_elapsed_seconds=(pairClockMono()-started.mono)/1e9;check(work);
        clear ix w
        guard(finish);audit.source_posthash=true;audit.completed=true;audit.phase='fresh_reader_and_finite_P1_scalar_audit_complete';
        audit.finished_utc=stamp();audit.elapsed_seconds=(pairClockMono()-entered.mono)/1e9;fprintf('C1_PK_THIN_READER_BEFORE_FINAL_AUDIT_PUBLICATION\n');publishAudit(file,audit,finish);fprintf('C1_PK_THIN_READER_AFTER_FINAL_AUDIT_PUBLICATION_RETURN\n');guard(finish);
        fprintf('C1_PK_THIN_SNAPSHOT_QUALIFICATION_RETURN points=%d complete=1 indexReads=1 allBulkReads=2 statisticsReads=1 bytes=%d targetPassed=%d\n',N,audit.actual_export_bytes,audit.final_target_passed);check(finish);
    catch problem
        audit.completed=false;audit.failure=exceptionData(problem);audit.phase='failed_or_unqualified';audit.finished_utc=stamp();
        try,publishAudit(file,audit,finish);catch custody,warning('C1PKThinRead:Custody','Retain existing audit/stage and candidate unchanged: %s',custody.message);end
        rethrow(problem)
    end
    function guard(limit)
        check(limit);verifyCode(code);verify(refs);fresh(absent);
        assert(isequaln(C1RunBudget_v3(),budget),'C1PKThinRead:Budget','No recapture or clock renewal.');
        assert(isequal(coreRoster(root,source.file),beforeCore)&&isequal(allResultsRoster(root),beforeResults),'C1PKThinRead:Rosters','Current actual raw/core/Results roster stays fixed.');check(limit);
    end
end

function [N,counts]=validateWriter(w,c,capsule)
    requiredFields(w,{'schema','source_reference','closed_source_boundary','source_point_count','record_digests','record_bindings', ...
        'source_projection_read2_verified','complete','source_posthash','kernel_call_returned','kernel_return_timely','candidate_reference', ...
        'typed_graph_digest','typed_graph_counts','frozen_creation_graph','source_code','input_references','external_finite_evidence_references', ...
        'budget','options','actual_candidate_bytes','operational_maximum_bytes','fresh_process_qualification_required','fresh_process_qualification_earned', ...
        'published_additive_export','full_branch_completion_claimed','own_process_exit_observed'},'known67e writer receipt');
    N=w.source_point_count;validateattributes(N,{'double'},{'real','scalar','finite','integer','positive','<=',flintmax});
    names={'physical_edges','record_equalities','qualified_aliases','numerical_seams'};counts=w.typed_graph_counts;exactFields(counts,names,'writer typed graph counts');
    for k=1:numel(names),validateattributes(counts.(names{k}),{'double'},{'real','scalar','finite','integer','nonnegative','<=',flintmax});end
    assert(isstruct(w.options)&&isscalar(w.options)&&isequal(w.options.ExpectedPointCount,N) ...
        &&isequaln(ref2(w.options.SourceReference),ref2(w.source_reference)),'C1PKThinRead:WriterDeclaredSource','The complete writer actual N/source must match its own declared intake.');
    assert(strcmp(w.schema,'C1-current-PK-thin-snapshot-write-v1') ...
        &&isequal(w.complete,true)&&isequal(w.source_posthash,true)&&isequal(w.source_projection_read2_verified,true) ...
        &&isequal(w.kernel_call_returned,true)&&isequal(w.kernel_return_timely,true) ...
        &&isequal(w.fresh_process_qualification_required,true)&&isequal(w.fresh_process_qualification_earned,false) ...
        &&isequal(w.published_additive_export,false)&&isequal(w.full_branch_completion_claimed,false)&&isequal(w.own_process_exit_observed,false), ...
        'C1PKThinRead:Writer','An actual returned, timely, complete but not self-qualified writer receipt is required.');
    assert(iscell(w.record_digests)&&isequal(size(w.record_digests),[N,1])&&iscell(w.record_bindings)&&isequal(size(w.record_bindings),[N,1]),'C1PKThinRead:WriterRows');
    for k=1:N
        assert(ischar(w.record_digests{k})&&isrow(w.record_digests{k})&&~isempty(regexp(w.record_digests{k},'^[0-9a-f]{64}$','once')),'C1PKThinRead:WriterDigest');
        exactFields(w.record_bindings{k},{'source_index','native_id','occurrence_id','component_identity','order','context'},'writer binding');
        assert(isequal(w.record_bindings{k}.source_index,k)&&isequaln(w.record_bindings{k}.context.source_reference,w.source_reference) ...
            &&isequal(w.record_bindings{k}.context.source_index,k)&&isequal(w.record_bindings{k}.context.expected_index,k),'C1PKThinRead:WriterBinding');
    end
    exactFields(c,{'schema','actual_process_exit_observed','all_owned_native_workers_exit_observed','process_session_id','exit_code', ...
        'source_reference','source_sha256','custody_complete','pending_boundary_reviewed','closure_reference'},'existing closed worker');
    assert(strcmp(c.schema,'C1-closed-owned-native-worker-v1')&&isequal(c.actual_process_exit_observed,true) ...
        &&isequal(c.all_owned_native_workers_exit_observed,true)&&isequal(c.exit_code,0)&&isequal(c.custody_complete,true) ...
        &&isequal(c.pending_boundary_reviewed,true),'C1PKThinRead:WriterClosure');
    validateattributes(c.process_session_id,{'double'},{'real','scalar','finite','integer','positive'});
    r=checked(c.source_reference);closedReceipt=checked(c.closure_reference);
    assert(~strcmp(closedReceipt.file,canonical(capsule.file)),'C1PKThinRead:DistinctClosure','The actual writer exit/custody receipt is distinct from the earlier raw-source capsule.');
    assert(strcmp(c.source_sha256,r.sha256)&&strcmp(r.sha256,'67e0622b1a11d52d3a640747a7b636ff30bf207747e404d63f67106856d3747f') ...
        &&strcmp(canonical(which('ExportC1PKThinSnapshot20261031')),r.file),'C1PKThinRead:WriterSource','Actual writer source/path and external exit0 custody stay distinct.');
    validateClosedSource(w.closed_source_boundary,w.source_reference,N);
    assert(isequaln(ref2(w.closed_source_boundary.closure_reference),ref2(capsule)),'C1PKThinRead:ClosedSourceCapsule','The provided exact live capsule must be the writer boundary capsule for this source SHA and runtime N.');
end

function validateIndex(ix,w,N,counts)
    assert(strcmp(ix.storage_version,'BranchSolutionFile_v3:4')&&strcmp(ix.scientific_projection_contract,'C1-essential-native-scientific-projection-v1') ...
        &&numel(ix.points)==N&&numel(ix.edges)==counts.physical_edges&&isa(ix.record_projection_digests,'uint8') ...
        &&isequal(size(ix.record_projection_digests),[32,N]),'C1PKThinRead:Index');
    assert(strcmp(C1ScientificDigest_v3(ix.metadata),w.typed_graph_digest),'C1PKThinRead:IndependentGraph','Graph digest must equal independent raw-projection writer receipt.');
    graph=compactGraph(ix);names={'physical_edges','record_equalities','qualified_aliases','numerical_seams'};
    for j=1:numel(names),assert(numel(graph.(names{j}))==counts.(names{j}),'C1PKThinRead:GraphCount','All actual typed graph table lengths must match the independent writer receipt.');end
    for k=1:N
        expected=w.record_bindings{k};p=ix.points{k};actual=lower(reshape(dec2hex(ix.record_projection_digests(:,k),2).',1,[]));
        assert(strcmp(actual,w.record_digests{k})&&isequaln(ix.record_native_ids{k},expected.native_id) ...
            &&isequaln(ix.occurrence_ids{k},expected.occurrence_id)&&isequaln(p.component_identity,expected.component_identity) ...
            &&isequaln(p.order,expected.order)&&isequaln(p.provenance,expected.context),'C1PKThinRead:IndependentIndex');
    end
    for j=1:numel(ix.edges)
        e=ix.edges{j};assert(strcmp(e.component_identity,ix.points{e.from}.component_identity)&&strcmp(e.component_identity,ix.points{e.to}.component_identity),'C1PKThinRead:PhysicalOwner');
    end
    original=w.frozen_creation_graph;
    validateattributes(original.snapshot_nodes,{'double'},{'real','scalar','finite','integer','positive','<=',N});
    assert(isequal(original.current_point_count,N)&&isequal(original.current_physical_edge_count,counts.physical_edges),'C1PKThinRead:CreationSnapshot','The frozen creation-node bound stays separate from current source/physical-edge counts.');
    pairs=relationPairs(graph.physical_edges,N);
    for j=1:size(original.original_explicit_edges,1),assert(sum(all(pairs==original.original_explicit_edges(j,:),2))==1,'C1PKThinRead:CreationPhysicalPrefix');end
end

function [out,geometryCode,source]=referenceScalars(p1)
    assert(isstruct(p1)&&isscalar(p1)&&strcmp(p1.schema,'C1-original-P1-v2-native-reference-audit-v1') ...
        &&isequal(p1.complete,true)&&isequal(p1.source_files_posthash,true)&&isequal(p1.source_code_posthash,true),'C1PKThinRead:P1');
    assert(iscell(p1.branches),'C1PKThinRead:P1');hit=find(cellfun(@(r)strcmp(r.label,'PK'),p1.branches));assert(isscalar(hit),'C1PKThinRead:P1');r=p1.branches{hit};
    X=r.stored_initial_dx(:);E=r.mechanical_energy(:);T=r.stored_period(:);geometry=r.native_initial_geometry_valid(:);N=numel(E);
    principal=[10;10;20;20;1;1;0;0;2;.5];
    assert(N>0&&numel(X)==N&&numel(T)==N&&islogical(geometry)&&numel(geometry)==N&&all(isfinite(X))&&all(isfinite(E))&&all(isfinite(T)) ...
        &&isequal(r.scalar_complete,true)&&all(r.energy_available(:))&&iscell(r.scalar_failure)&&numel(r.scalar_failure)==N ...
        &&all(cellfun(@isempty,r.scalar_failure))&&isequaln(r.native_physical_parameter,repmat(principal,1,N)),'C1PKThinRead:P1Scalars');
    source=checked(r.source);names={'LegacyStateAdapter_v3','LegacyParameterAdapter_v3','LegacyEventAdapter_v3','QuadrupedSchema_v3', ...
        'QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3','ContinuousDynamics_v3','QuadrupedAdmissibility_v3','EventTimingRegulation','ResetMap_v3'};
    geometryCode=cell(numel(names),1);
    for k=1:numel(names),assert(isfield(p1.source_code,names{k}),'C1PKThinRead:P1Geometry');geometryCode{k}=checked(p1.source_code.(names{k}));end
    scheduled=r.scheduled_signed_mean_U(:);available=r.scheduled_mean_available(:);timely=r.scheduled_timely(:);attempted=r.scheduled_attempted(:);
    assert(numel(scheduled)==N&&islogical(available)&&numel(available)==N&&islogical(timely)&&numel(timely)==N&&islogical(attempted)&&numel(attempted)==N, ...
        'C1PKThinRead:P1ScheduledShape');qualified=available&timely&attempted;
    assert(all(isfinite(scheduled(qualified))),'C1PKThinRead:P1ScheduledFinite');
    assert(islogical(r.initial_downward_apex)&&numel(r.initial_downward_apex)==N,'C1PKThinRead:P1ApexMask');
    out=struct('source_reference',source,'source_columns',(1:N).','signed_initial_dx',X,'mechanical_energy',E,'stored_period',T, ...
        'passes_initial_geometry_check',geometry,'initial_downward_apex',r.initial_downward_apex(:), ...
        'scheduled_signed_mean_U',scheduled,'scheduled_mean_available',available,'scheduled_timely',timely,'scheduled_attempted',attempted, ...
        'scheduled_qualified_mask',qualified,'all_envelope',scalarEnvelope(X,E,T,scheduled,qualified,true(N,1)), ...
        'geometry_pass_envelope',scalarEnvelope(X,E,T,scheduled,qualified,geometry), ...
        'geometry_fail_envelope',scalarEnvelope(X,E,T,scheduled,qualified,~geometry), ...
        'scope','Literal paired original P1 columns/masks. Initial geometry is not native autonomous admission. Scheduled mean U is optional historical/timely evidence; no new ODE or interpolation.');
end

function out=nativeScalars(orbits,reports,metadata,limit)
    N=numel(orbits);eligible=false(N,1);x=nan(N,1);energy=x;T=x;U=x;reasons=cell(N,1);principal=[10;10;20;20;1;1;0;0;2;.5];schema=QuadrupedSchema_v3.shared();
    for k=1:N
        check(limit);
        try
            strictPK(orbits{k},reports{k},principal);g=member(reports{k},'classification',struct());
            assert(isequal(member(g,'canonical_label_qualified',false),true)&&strcmp(member(g,'canonical_point_label',''),'PK1'),'C1PKThinRead:SavedPK1');
            E=QuadrupedEnergy_v3.evaluate(orbits{k}.initial_state,orbits{k}.initial_mode,orbits{k}.parameter);
            dx=orbits{k}.initial_state(schema.State.dx);period=orbits{k}.period;stride=orbits{k}.stride_displacement;
            assert(isnumeric(E)&&isreal(E)&&isscalar(E)&&isfinite(E)&&isnumeric(dx)&&isreal(dx)&&isscalar(dx)&&isfinite(dx) ...
                &&isnumeric(period)&&isreal(period)&&isscalar(period)&&isfinite(period)&&period>0 ...
                &&isnumeric(stride)&&isreal(stride)&&numel(stride)==14&&all(isfinite(stride(:))),'C1PKThinRead:NativeScalars');
            energy(k)=E;x(k)=dx;T(k)=period;U(k)=stride(1)/period;assert(isfinite(U(k)),'C1PKThinRead:MeanU');eligible(k)=true;
        catch problem,reasons{k}=struct('identifier',problem.identifier,'message',problem.message);end
    end
    assert(any(eligible),'C1PKThinRead:NoEligible');
    out=struct('eligible_saved_PK1_BL1_all9',eligible,'excluded_reasons',{reasons},'signed_initial_dx',x,'mechanical_energy',energy,'period',T, ...
        'signed_mean_U',U,'owner',{cellfun(@(m)m.component_identity,metadata,'UniformOutput',false)}, ...
        'order',{cellfun(@(m)m.order,metadata,'UniformOutput',false)}, ...
        'scope','Saved literal PK1/all9/principal/complete BL1 qualification only; exact scalar formulas on retained initial state/period/stride. No fresh admission or map.');
end

function out=groupEnvelopes(graph,s,p1,N)
    physical=relationPairs(graph.physical_edges,N);exact=relationPairs(graph.record_equalities,N);aliases=relationPairs(graph.qualified_aliases,N);numerical=relationPairs(graph.numerical_seams,N);
    kinds={'physical_only','physical_plus_exact_and_qualified_alias','including_numerical_storage_adjacency'};
    pairsets={physical,[physical;exact;aliases],[physical;exact;aliases;numerical]};out=struct();eligible=s.eligible_saved_PK1_BL1_all9;
    for kind=1:numel(kinds)
        groups=connectedGroups(N,pairsets{kind},eligible);rows=cell(numel(groups),1);
        for k=1:numel(groups)
            nodes=groups{k};mask=false(N,1);mask(nodes)=true;
            envelope=scalarEnvelope(s.signed_initial_dx,s.mechanical_energy,s.period,s.signed_mean_U,eligible,mask);
            rows{k}=struct('point_indices',nodes,'owner',{s.owner(nodes)},'order',{s.order(nodes)},'coordinate_envelope',envelope, ...
                'all_P1_columns_envelope',envelopeComparison(envelope,p1,p1.source_columns>0), ...
                'initial_geometry_pass_P1_envelope',envelopeComparison(envelope,p1,p1.passes_initial_geometry_check));
        end
        out.(kinds{kind})=rows;
    end
    out.scope='Undirected storage-connectivity groups of eligible saved points. Exact equalities and qualified aliases remain distinct literal tables; aliases are not exact identity, numerical seams are not physical edges. Envelopes do not prove paired-curve coverage or attachment.';
end

function pairs=relationPairs(rows,N)
    assert(iscell(rows),'C1PKThinRead:Relations');pairs=zeros(numel(rows),2);
    for k=1:numel(rows)
        e=rows{k};a=e.from;b=e.to;assert(isnumeric(a)&&isreal(a)&&isscalar(a)&&isfinite(a)&&a==fix(a)&&a>=1&&a<=N ...
            &&isnumeric(b)&&isreal(b)&&isscalar(b)&&isfinite(b)&&b==fix(b)&&b>=1&&b<=N&&a~=b,'C1PKThinRead:RelationBounds');pairs(k,:)=[a,b];
    end
end

function groups=connectedGroups(N,pairs,eligible)
    eligible=eligible(:);assert(islogical(eligible)&&numel(eligible)==N,'C1PKThinRead:Eligible');groups=cell(0,1);seen=false(N,1);
    for seed=1:N
        if ~eligible(seed)||seen(seed),continue;end
        queue=seed;seen(seed)=true;nodes=zeros(0,1);
        while ~isempty(queue)
            node=queue(1);queue(1)=[];nodes(end+1,1)=node;
            adjacent=unique([pairs(pairs(:,1)==node,2);pairs(pairs(:,2)==node,1)]);
            freshNodes=adjacent(eligible(adjacent)&~seen(adjacent));seen(freshNodes)=true;queue=[queue;freshNodes]; %#ok<AGROW>
        end
        groups{end+1,1}=sort(nodes);
    end
end

function out=scalarEnvelope(x,E,T,U,meanAvailable,mask)
    mask=logical(mask(:));out=struct('point_count',sum(mask),'signed_initial_dx',bounds(x(mask)), ...
        'mechanical_energy',bounds(E(mask)),'period',bounds(T(mask)), ...
        'signed_mean_U',bounds(U(mask&meanAvailable(:))),'mean_point_count',sum(mask&meanAvailable(:)));
end

function out=envelopeComparison(envelope,p1,mask)
    target=scalarEnvelope(p1.signed_initial_dx,p1.mechanical_energy,p1.stored_period,p1.scheduled_signed_mean_U,p1.scheduled_qualified_mask,mask);
    fields={'signed_initial_dx','mechanical_energy','period','signed_mean_U'};contained=struct();available=struct();
    for k=1:numel(fields)
        key=fields{k};a=envelope.(key);b=target.(key);ok=numel(a)==2&&numel(b)==2;available.(key)=ok;
        contained.(key)=ok&&a(1)<=b(1)&&a(2)>=b(2);
    end
    out=struct('target_source_columns',p1.source_columns(mask),'target_coordinate_envelope',target, ...
        'coordinate_comparison_available',available,'coordinate_envelope_contained',contained, ...
        'paired_curve_coverage_claimed',false,'attachment_claimed',false);
end

function refs=normalReferences(rows)
    validateReferenceCells(rows,'explicit protected/method union');refs=cell(size(rows));
    for k=1:numel(rows),refs{k}=ref2(checked(rows{k}));end
    refs=uniqueReferences(refs(:));
end

function value=pairClockMono(),t=pairClock();value=t.mono;end

function exactFields(value,names,label)
    assert(isstruct(value)&&isscalar(value)&&isequal(sort(fieldnames(value)),sort(names(:))),'C1EssentialComplete:KnownSchema','Use the exact source-backed %s fieldset; unknown qualifications refuse.',label);
end

function requiredFields(value,names,label)
    assert(isstruct(value)&&isscalar(value)&&all(isfield(value,names)),'C1EssentialComplete:RequiredEvidence','The known %s is missing required actual fields.',label);
end

function out=ref2(r),out=struct('file',canonical(r.file),'sha256',r.sha256);end

function rawEqual3(expected,a,b,where)
    assert(strcmp(class(expected),class(a))&&strcmp(class(expected),class(b))&&isequal(size(expected),size(a),size(b)),'C1PackedPilot:ExactType','Type/shape changed at %s.',where);
    if isnumeric(expected)
        assert(isequal(isreal(expected),isreal(a),isreal(b)),'C1PackedPilot:ExactRealness','Numeric realness changed at %s.',where);
        assert(isequal(typecast(real(expected(:)),'uint8'),typecast(real(a(:)),'uint8'),typecast(real(b(:)),'uint8')),'C1PackedPilot:ExactBytes','Real numeric raw bytes changed at %s.',where);
        if ~isreal(expected),assert(isequal(typecast(imag(expected(:)),'uint8'),typecast(imag(a(:)),'uint8'),typecast(imag(b(:)),'uint8')),'C1PackedPilot:ExactBytes','Imaginary raw bytes changed at %s.',where);end
    elseif islogical(expected)||ischar(expected)
        assert(isequal(expected,a,b),'C1PackedPilot:ExactValue','Literal values changed at %s.',where);
    elseif isstring(expected)
        assert(isequaln(expected,a,b),'C1PackedPilot:ExactString','Literal strings/missingness changed at %s.',where);
    elseif iscell(expected)
        for k=1:numel(expected),rawEqual3(expected{k},a{k},b{k},sprintf('%s{%d}',where,k));end
    elseif isstruct(expected)
        f=fieldnames(expected);assert(isequal(f,fieldnames(a),fieldnames(b)),'C1PackedPilot:ExactFields','Field names/order changed at %s.',where);
        for k=1:numel(expected),for j=1:numel(f),rawEqual3(expected(k).(f{j}),a(k).(f{j}),b(k).(f{j}),[where,'.',f{j}]);end,end
    else
        error('C1PackedPilot:ExactClass','Unsupported projection class %s at %s.',class(expected),where);
    end
end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function paths=coreRoster(root,merged)
    d=dir(fullfile(root,'Components'));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==43&&~any([d.isdir])&&all(endsWith(lower(string({d.name})),'.mat'))&&~any(contains(lower(string({d.name})),'pending')),'C1MergedB:OriginalCores','Keep exact43 untouched core MATs and no unknown stage.');paths=cellfun(@(n)canonical(fullfile(root,'Components',n)),{d.name}.','UniformOutput',false);
    d=dir(fileparts(merged));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==1&&~d.isdir&&strcmp(canonical(fullfile(d.folder,d.name)),merged),'C1MergedB:MergedDirectory','The permanent merged directory contains exactly its current one MAT with no random/stage file.');paths=sort([paths;{merged}]);
end

function l=finalStorageLimit(b),l=struct('utc',b.deadline_unix_seconds,'mono',b.deadline_monotonic_ns);end

function l=minLimit(a,b),l=struct('utc',min(a.utc,b.utc),'mono',min(a.mono,b.mono));end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1Pilot:Resolver','A guarded implementation resolves elsewhere.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Pilot:Changed','A guarded authority/source/core changed.');end,end

function r=reference(f),assert(isfile(f),'C1Pilot:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function move(a,b,replace),if replace,v=javaArray('java.nio.file.CopyOption',2);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');v(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');else,fresh({b});v=javaArray('java.nio.file.CopyOption',1);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');end;javaMethod('move','java.nio.file.Files',java.io.File(a).toPath(),java.io.File(b).toPath(),v);end

function fresh(files),for k=1:numel(files),assert(~isfile(files{k})&&~isfolder(files{k}),'C1Pilot:Fresh','Retain an existing authority or uncertain stage.');end,end

function e=exceptionData(x),causes=cell(size(x.cause));for k=1:numel(causes),causes{k}=exceptionData(x.cause{k});end;e=struct('identifier',x.identifier,'message',x.message,'stack',x.stack,'causes',{causes});end

function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end

function t=pairClock(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function t=shift(t,s),t.utc=t.utc+s;t.mono=t.mono+s*1e9;end

function v=left(t),v=min(t.utc-posixtime(datetime('now','TimeZone','UTC')),(t.mono-double(java.lang.System.nanoTime))/1e9);end

function check(t),assert(left(t)>0,'C1Pilot:Clock','The fixed whole/local/science clock expired.');end

function s=stamp(),s=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

function validateClosedSource(w,source,N)
    keys={'schema','process_session_id','exit_code','actual_process_exit_observed','custody_complete','closure_reference','source_reference','source_point_count'};
    assert(isstruct(w)&&isscalar(w)&&all(isfield(w,keys))&&all(ismember(fieldnames(w),[keys,{'scope'}].')),'C1PKThin:Boundary','Use the existing closed-native-source-boundary fields only.');
    assert(strcmp(w.schema,'C1-closed-native-source-boundary-v1')&&isequal(w.exit_code,0)&&isequal(w.actual_process_exit_observed,true)&&isequal(w.custody_complete,true), ...
        'C1PKThin:Boundary','A separately observed closed/custodied raw-source snapshot is required.');
    validateattributes(w.process_session_id,{'double'},{'real','scalar','finite','integer','positive'});
    assert(isequaln(ref2(w.source_reference),ref2(source))&&isequal(w.source_point_count,N),'C1PKThin:BoundarySource','Bind this exact current raw source SHA/count.');checked(w.closure_reference);
    if isfield(w,'scope'),assert(ischar(w.scope)&&isrow(w.scope)&&~isempty(w.scope),'C1PKThin:BoundaryScope');end
end

function publishAudit(file,audit,limit)
    check(limit);stage=[file,'.pending.mat'];fresh({stage});save(stage,'audit','-v7');
    a=load(stage,'audit');b=load(stage,'audit');rawEqual3(audit,a.audit,b.audit,'concise native audit stage read2');check(limit);
    move(stage,file,isfile(file)); % Same-directory atomic publication; retain uncertain stage on refusal.
    a=load(file,'audit');b=load(file,'audit');rawEqual3(audit,a.audit,b.audit,'concise native audit installed read2');check(limit);
end

function refs=uniqueReferences(rows)
    validateReferenceCells(rows,'reference union');refs=cell(0,1);paths=cell(0,1);
    for k=1:numel(rows)
        r=checked(rows{k});hit=find(strcmp(paths,r.file));
        if isempty(hit),refs{end+1,1}=r;paths{end+1,1}=r.file;else,assert(isequaln(refs{hit},r),'C1PKThin:ReferenceConflict','Duplicate paths must have identical full declared references.');end
    end
end

function validateReferenceCells(rows,label)
    assert(iscell(rows)&&(isvector(rows)||isempty(rows)),'C1PKThin:References','Use explicit cell-vector %s; column views do not rewrite caller shape.',label);
    for k=1:numel(rows)
        r=rows{k};assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})) ...
            &&((ischar(r.file)&&isrow(r.file)&&~isempty(r.file))||(isstring(r.file)&&isscalar(r.file)&&~ismissing(r.file)&&strlength(r.file)>0)) ...
            &&ischar(r.sha256)&&isrow(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once')), ...
            'C1PKThin:ReferenceShape','Every %s entry needs one exact file/lowercaseSHA reference.',label);
    end
end

function names=allResultsRoster(root)
    folder=fullfile(root,'Results');rows=dir(folder);rows=rows(~[rows.isdir]);rows=rows(~startsWith({rows.name},'.'));
    names=sort(arrayfun(@(r)canonical(fullfile(r.folder,r.name)),rows(:),'UniformOutput',false));
end

function assertMat(file)
    [~,~,extension]=fileparts(file);assert(strcmp(extension,'.mat'),'C1PKThin:MAT','Use an explicit fresh MAT output path.');
end

function strictPK(orbit,report,p)
    gates={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations', ...
        'family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    status=member(report,'status',member(report,'native_status',''));
    assert(strcmp(class(orbit),'HybridOrbit_v3')&&isscalar(orbit)&&isequal(member(report,'accepted',strcmp(status,'accepted')),true), ...
        'C1PKPlot:Admission','Require an actual native orbit and the documented saved acceptance boolean or accepted native status.');
    for k=1:numel(gates),assert(isequal(member(member(report,'acceptance_gates',struct()),gates{k},false),true), ...
        'C1PKPlot:Admission','Require all nine literal saved native gates.');end
    g=member(report,'classification',struct());assert(strcmp(member(g,'contract_version',''),'quadruped-gait-v3.5') ...
        &&strcmp(member(g,'validated_gait_type',''),'PK')&&isequal(member(g,'flight_count_certain',false),true) ...
        &&isequal(member(g,'flight_count',NaN),1)&&isequaln(orbit.parameter(:),p(:)), ...
        'C1PKPlot:PK','Require current certain one-flight PK with unchanged principal parameters.');
    [policy,evidence]=RecordedReturnPolicy_v3(report);assert(evidence.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3') ...
        &&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKPlot:Policy','Require the actual complete BL1 mode-closed return policy.');
end
function out=member(s,key,fallback),out=fallback;if isstruct(s)&&isscalar(s)&&isfield(s,key),out=s.(key);end,end
function out=bounds(x),x=x(isfinite(x));out=[];if ~isempty(x),out=[min(x),max(x)];end,end
function out=compactGraph(ix)
    out=struct('physical_edges',{ix.edges},'record_equalities',{ix.metadata.record_equalities}, ...
        'qualified_aliases',{ix.metadata.qualified_aliases},'numerical_seams',{ix.metadata.numerical_seams}, ...
        'scope','Physical edges, exact equalities, qualified aliases and numerical seams remain distinct literal tables; no quotient or new physical path is inferred.');
end
