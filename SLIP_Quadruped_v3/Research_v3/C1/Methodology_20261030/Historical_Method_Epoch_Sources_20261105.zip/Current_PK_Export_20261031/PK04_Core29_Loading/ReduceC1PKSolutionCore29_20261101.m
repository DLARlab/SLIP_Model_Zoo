function receipt=ReduceC1PKSolutionCore29_20261101(sourceStageReference,failedWriterWitnessReference,outputFile,ProtectedReferences)
%REDUCEC1PKSOLUTIONCORE29_20261101 Explicit saved-header core projection.
% Two independent reads of the retained oversized0086 stage; no K60 reread,
% Root, map, integration, classification, admission or historical callback.
% Original full source digests remain historical provenance only.
    entered=clockPair();budget=C1RunBudget_v3();fence=struct('utc',budget.deadline_unix_seconds,'mono',budget.deadline_monotonic_ns);
    assert(left(fence)>1802,'C1CoreReduce:WholeFit','Full1800/120 must fit both unchanged original FINAL clocks.');
    finish=minimum(shift(entered,1800),fence);work=shift(finish,-120);
    sourceStageReference=checked(sourceStageReference);failedWriterWitnessReference=checked(failedWriterWitnessReference);validateReferences(ProtectedReferences);
    root=canonical(fileparts(which('C1RunBudget_v3')));
    assert(strcmp(sourceStageReference.file,fullfile(root,'Compact_Exports_20261030','C1_PK_Connected04_Core29_Reduced_20261101.mat.pending.mat')) ...
        &&strcmp(sourceStageReference.sha256,'d205554f4ea659b09882f8b0020d018ff1007ebcb1d9922b0860e2ac50cf2baf'), ...
        'C1CoreReduce:SourceStage','Use only the actually retained oversized0086 stage.');
    d=dir(sourceStageReference.file);assert(isscalar(d)&&d.bytes==704514,'C1CoreReduce:StageBytes','The exact source-stage bytes changed.');
    outputFile=literalPath(outputFile);stage=[outputFile,'.pending.mat'];literalPath(stage);
    [~,~,extension]=fileparts(outputFile);assert(strcmp(extension,'.mat')&&isfolder(fileparts(outputFile)),'C1CoreReduce:Output','Use one fresh MAT in an existing directory.');fresh({outputFile;stage});
    names={'ReduceC1PKSolutionCore29_20261101','LoadC1SolutionCore29_v3','C1RunBudget_v3','RoundSHA256_v3','V3Path_v3','V3Root_v3', ...
        'C1ScientificDigest_v3','HybridOrbit_v3','OrbitContentIdentity_v3','QuadrupedSchema_v3','RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3'};
    code=guardedMethods(names,ProtectedReferences);hit=find(cellfun(@(r)strcmp(r.name,'LoadC1SolutionCore29_v3'),code));
    assert(isscalar(hit)&&strcmp(code{hit}.sha256,'79e879e565c1a6d6dd6112f327635f85efb5f3a2329cbec7588adf6a197a81a6'),'C1CoreReduce:Loader','Public79e remains unchanged.');
    hit=find(cellfun(@(r)strcmp(r.name,'C1ScientificDigest_v3'),code));assert(isscalar(hit)&&strcmp(code{hit}.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'),'C1CoreReduce:Digest','Use unchanged scientific typed digest.');
    [closed,oldReceipt]=failedStageClosure(failedWriterWitnessReference,sourceStageReference,root);
    refs=[ProtectedReferences(:);{sourceStageReference;failedWriterWitnessReference;checked(closed.source_reference)}];
    paths=cellfun(@(r)canonical(r.file),refs,'UniformOutput',false);
    assert(~ismember(outputFile,paths)&&~ismember(stage,paths)&&~strcmp(outputFile,oldReceipt.output_file)&&~strcmp(stage,oldReceipt.output_file), ...
        'C1CoreReduce:Additive','Keep source-stage, original attempted final and all consumed authorities unchanged.');
    producer=struct('file',literalPath([mfilename('fullpath'),'.m']),'sha256',RoundSHA256_v3([mfilename('fullpath'),'.m']));
    receipt=struct('schema','C1-reduced-core29-write-receipt-v1','source_stage_reference',sourceStageReference,'failed_writer_witness_reference',failedWriterWitnessReference, ...
        'source_failed_writer_closure',closed,'original_failed_writer_receipt',oldReceipt,'producer_reference',producer, ...
        'output_file',outputFile,'stage_file',stage,'point_count',0,'whole_core_limit_bytes',[],'original_v2_reference',struct(),'original_v2_bytes',[], ...
        'core_bytes',[],'core_sha256','','source_stage_loads',0,'source_stage_native_read2_verified',false,'retained_projection_read2_verified',false, ...
        'all_native_ids_and_policies_verified',false,'native_reconstructions',0,'core_native_read2_verified',false,'installed_native_read2_verified',false, ...
        'stage_save_returned',false,'exclusive_publication_returned',false,'owned_stage_removed',false,'owned_stage_file_key','','published_file_key_verified',false, ...
        'loader_smoke_returned',false,'source_posthash',false,'completed',false,'failure',struct(),'omission_summary',{{}}, ...
        'pre_save_core_whos_bytes',[],'elapsed_seconds',[],'declared_wall_seconds',1800,'save_reserve_seconds',120, ...
        'own_process_exit_observed',false,'new_admission_claimed',false,'aggregate_storage_reduction_claimed',false);
    receipt.scope='Only saved_reports.classification and saved_reports.primitive are omitted from the exact failed86 stage. Whole core cap includes every load-required field. Saved all-nine gate decisions remain literal historical booleans; classification/primitive reports are absent, and original orbit headers are empty rather than alternate evidence. Full historical decisions remain in retained stages/K60/QA/oracle; no failed publication flag is upgraded.';
    try
        solution_core29=[];omission=[];
        for pass=1:2
            guard(work);fprintf('C1_CORE29_REDUCED_BEFORE_SOURCE_LOAD pass=%d\n',pass);
            data=load(sourceStageReference.file,'solution_core29','core_digest');receipt.source_stage_loads=pass;fprintf('C1_CORE29_REDUCED_AFTER_SOURCE_LOAD_RETURN pass=%d\n',pass);
            check(work);validateCore(data.solution_core29,data.core_digest);verifyMethods(data.solution_core29.runtime_methods,data.solution_core29.runtime_environment);
            c=data.solution_core29;validateSource(c,oldReceipt,closed);clear data
            if pass==1
                receipt.point_count=c.point_count;receipt.whole_core_limit_bytes=c.maximum_core_bytes;receipt.original_v2_reference=checked(c.original_v2_reference);v2=dir(c.original_v2_reference.file);
                assert(isscalar(v2)&&v2.bytes==c.original_v2_bytes&&v2.bytes==110861&&c.maximum_core_bytes==554305,'C1CoreReduce:Cap','Keep exact5x WHOLE originalv2 bytes, including every core field.');
                receipt.original_v2_bytes=v2.bytes;
                refs=[refs;{checked(c.source_reference);checked(c.qualification_reference);checked(c.writer_audit_reference);receipt.original_v2_reference;checked(c.qualification_closure.closure_reference)}];
                paths=cellfun(@(r)canonical(r.file),refs,'UniformOutput',false);assert(~ismember(outputFile,paths)&&~ismember(stage,paths),'C1CoreReduce:Additive','No newly bound source reference may be an output.');
            end
            [reduced,observedOmission]=projectCore(c,producer);verifyRetainedProjection(c,reduced);verifyRetainedInverse(c,reduced);clear c
            if pass==1,solution_core29=reduced;omission=observedOmission;else,same(reduced,solution_core29,'retained projection from independent source read2');same(observedOmission,omission,'omission dictionaries and aggregate digests');end
            clear reduced observedOmission;guard(work);
        end
        receipt.source_stage_native_read2_verified=true;receipt.retained_projection_read2_verified=true;receipt.omission_summary=omission;
        for k=1:solution_core29.point_count
            check(work);[o,r]=reconstruct(solution_core29,k);receipt.native_reconstructions=k;clear o r
        end
        receipt.all_native_ids_and_policies_verified=true;guard(work);core_digest=C1ScientificDigest_v3(solution_core29);
        observed=whos('solution_core29');receipt.pre_save_core_whos_bytes=observed.bytes;
        assert(observed.bytes<1750000000,'C1CoreReduce:Headroom','Actual logical bytes must have conservative v7 headroom; no general format-capacity guarantee.');
        fresh({outputFile;stage});fprintf('C1_CORE29_REDUCED_BEFORE_STAGE_SAVE\n');save(stage,'solution_core29','core_digest','-v7');receipt.stage_save_returned=true;fprintf('C1_CORE29_REDUCED_AFTER_STAGE_SAVE_RETURN\n');
        check(finish);stageIdentity=fileIdentity(stage);receipt.owned_stage_file_key=stageIdentity.key;sourceIdentity=fileIdentity(sourceStageReference.file);
        assert(~strcmp(stageIdentity.key,sourceIdentity.key),'C1CoreReduce:IndependentStage','The new saved stage must be independent of the retained full source.');
        receipt.core_bytes=stageIdentity.bytes;receipt.core_sha256=RoundSHA256_v3(stage);
        assert(receipt.core_bytes<=receipt.whole_core_limit_bytes,'C1CoreReduce:FiveTimes','Retain an oversized result without publication; no further silent pruning.');
        a=load(stage,'solution_core29','core_digest');b=load(stage,'solution_core29','core_digest');same(solution_core29,a.solution_core29,'whole new stage read1');same(solution_core29,b.solution_core29,'whole new stage read2');
        assert(strcmp(a.core_digest,core_digest)&&strcmp(b.core_digest,core_digest),'C1CoreReduce:StageDigest','Both new-stage typed digests must agree.');clear a b
        receipt.core_native_read2_verified=true;[o,~,point]=LoadC1SolutionCore29_v3(stage,1,receipt.core_sha256);receipt.loader_smoke_returned=true;
        assert(strcmp(OrbitContentIdentity_v3(o),point.native_id),'C1CoreReduce:LoaderSmoke','Use unchanged public79e on the reduced stage.');clear o point
        guard(finish);assert(isequaln(fileIdentity(stage),stageIdentity)&&strcmp(RoundSHA256_v3(stage),receipt.core_sha256),'C1CoreReduce:StageChanged','The new qualified stage changed.');fresh({outputFile});
        fprintf('C1_CORE29_REDUCED_BEFORE_EXCLUSIVE_PUBLICATION\n');javaMethod('createLink','java.nio.file.Files',java.io.File(outputFile).toPath(),java.io.File(stage).toPath());
        receipt.exclusive_publication_returned=true;fprintf('C1_CORE29_REDUCED_AFTER_EXCLUSIVE_PUBLICATION_RETURN\n');
        assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(outputFile).toPath(),java.io.File(stage).toPath()),'C1CoreReduce:PublicationIdentity','Published name must identify the owned stage.');
        finalIdentity=fileIdentity(outputFile);assert(strcmp(finalIdentity.key,stageIdentity.key),'C1CoreReduce:PublishedKey','The final key must remain the owned stage key.');receipt.published_file_key_verified=true;
        assert(isequaln(fileIdentity(stage),stageIdentity),'C1CoreReduce:OwnedUnlink','Remove only the unchanged owned new stage.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());receipt.owned_stage_removed=true;
        a=load(outputFile,'solution_core29','core_digest');b=load(outputFile,'solution_core29','core_digest');same(solution_core29,a.solution_core29,'whole installed read1');same(solution_core29,b.solution_core29,'whole installed read2');
        assert(strcmp(a.core_digest,core_digest)&&strcmp(b.core_digest,core_digest)&&strcmp(RoundSHA256_v3(outputFile),receipt.core_sha256),'C1CoreReduce:InstalledDigest','Installed read2 and bytes must match.');clear a b
        receipt.installed_native_read2_verified=true;guard(finish);receipt.source_posthash=true;receipt.completed=true;returned=clockPair();receipt.elapsed_seconds=(returned.mono-entered.mono)/1e9;
        emit(receipt,'C1_CORE29_REDUCED_ACTUAL_RETURN',50000);check(finish);
    catch problem
        receipt.completed=false;receipt.failure=struct('identifier',problem.identifier,'message',problem.message);returned=clockPair();receipt.elapsed_seconds=(returned.mono-entered.mono)/1e9;
        emit(receipt,'C1_CORE29_REDUCED_PARTIAL',15000);rethrow(problem)
    end
    function guard(limit)
        check(limit);verify(refs);verifyCode(code);literalPath(outputFile);literalPath(stage);assert(isequaln(C1RunBudget_v3(),budget),'C1CoreReduce:Budget','No grant/clock renewal.');
        assert(~isfile(oldReceipt.output_file),'C1CoreReduce:OldFinal','The original failed86 attempted final remains absent.');
        if receipt.exclusive_publication_returned
            current=fileIdentity(outputFile);assert(strcmp(current.key,receipt.owned_stage_file_key)&&current.bytes==receipt.core_bytes&&strcmp(RoundSHA256_v3(outputFile),receipt.core_sha256),'C1CoreReduce:PublishedChanged','Retain final if a later check fails.');
        end
        check(limit);
    end
end

function validateSource(c,q,closed)
    assert(c.point_count==494&&c.maximum_core_bytes==554305&&sameReference(c.producer_reference,closed.source_reference) ...
        &&sameReference(c.producer_reference,q.producer_reference)&&sameReference(c.original_v2_reference,q.original_v2_reference) ...
        &&c.original_v2_bytes==q.original_v2_bytes&&c.point_count==q.point_count&&c.maximum_core_bytes==q.whole_core_limit_bytes, ...
        'C1CoreReduce:SourceProfile','Bind actual494 current failed86 stage, its417 producer and actual emitted source/count/cap fields only.');
end

function [out,summary]=projectCore(c,producer)
    keep={'schema_version','status','native_status','accepted','full_closure','full_closure_residual','acceptance_gates'};
    evidence={'return_policy','return_policy_name','return_multiplicity','candidate_section_count','candidate_apex_count','accepted_crossing_index','accepted_apex_index','section_relative_event_signature','cyclic_event_signature','primitive_cycle','gait_identification'};
    scopes={'point_metadata','contexts','saved_reports','orbit_evidence'};out=c;summary=cell(4,1);N=c.point_count;
    for j=1:4
        scope=scopes{j};omitted=cell(N,1);paths=cell(N,1);
        for k=1:N
            omitted{k}=struct();paths{k}=cell(0,1);
            if j==3
                source=c.saved_reports{k};assert(isfield(source,'classification')&&isfield(source,'primitive'),'C1CoreReduce:ObservedHeaders','Both actually observed report headers must be present before explicit omission.');
                [out.saved_reports{k},omitted{k},paths{k}]=projectRecord(source,keep,{}, {},'');
                assert(isequal(sort(fieldnames(omitted{k})),{'classification';'primitive'}),'C1CoreReduce:OnlyTwoFields','Remove only the two declared saved-report fields, never another available report value.');
            elseif j==4
                source=c.orbit_evidence{k};assert(isequal(sort(fieldnames(source)),sort(evidence(:))) ...
                    &&isstruct(source.primitive_cycle)&&isscalar(source.primitive_cycle)&&isempty(fieldnames(source.primitive_cycle)) ...
                    &&isstruct(source.gait_identification)&&isscalar(source.gait_identification)&&isempty(fieldnames(source.gait_identification)), ...
                    'C1CoreReduce:ObservedEmptyOrbitHeads','Preserve all11 orbit properties; their actually empty heads are not substitute classification/primitive evidence.');
            end
        end
        dictionary=unique(vertcat(paths{:}),'stable');indices=cell(numel(dictionary),1);
        for n=1:numel(dictionary),indices{n}=find(cellfun(@(p)ismember(dictionary{n},p),paths));end
        summary{j}=struct('scope',scope,'occurrence_count',N,'omitted_value_typed_digest',C1ScientificDigest_v3(omitted), ...
            'dropped_field_paths',{dictionary},'occurrence_indices',{indices},'omitted_field_occurrence_count',sum(cellfun(@numel,paths)), ...
            'scope_note','Only saved_reports.classification and saved_reports.primitive are omitted at all494 occurrences. Other scopes are unchanged. Exact omitted values remain in the immutable failed86 stage/full historical authorities.');
    end
    out.producer_reference=producer;
    out.historical_audit_scope='Saved report classification and primitive fields are ABSENT from this core. All11 original orbit properties remain exact; primitive_cycle and gait_identification are actually empty, not alternate decision evidence. Literal accepted/status/full-closure/residual and all-nine gate booleans remain historical values. Full historical classification/primitive headers stay in prior stages/K60/QA/oracle. Original source_projection_digests describe full historical K60 projections, NOT this core. No fresh classification, admission or primitivity claim.';
end

function [out,removed,paths]=projectRecord(source,keep,primitive,classifier,prefix)
    assert(isstruct(source)&&isscalar(source),'C1CoreReduce:HeaderShape','Project only original scalar structs, never substitute defaults.');out=struct();removed=struct();paths=cell(0,1);
    for name=fieldnames(source).'
        key=name{1};path=[prefix,key];value=source.(key);
        if ~ismember(key,keep),removed.(key)=value;paths{end+1,1}=path;continue;end
        if any(strcmp(key,{'primitive','primitive_cycle'}))
            [out.(key),rest,p]=projectRecord(value,primitive,{}, {},[path,'.']);
        elseif any(strcmp(key,{'classification','gait_identification'}))
            [out.(key),rest,p]=projectRecord(value,classifier,{}, {},[path,'.']);
        else,out.(key)=value;continue
        end
        if ~isempty(fieldnames(rest)),removed.(key)=rest;paths=[paths;p];end
    end
end

function verifyRetainedProjection(source,reduced)
    % Independent contract check, separate from the projection algorithm and
    % from the inverse that deliberately restores all four projected arrays.
    primitive={'status','reason','recorded_period','primitive_period','cover_count','drift','primitive_drift','closure_error','mode_closed','checked_cover_bound','state_tolerance','event_phase_tolerance','evidence_level','global_primitivity_proved','event_history_complete','proper_apex_count'};
    classifier={'contract_version','synchrony_predicate_version','label','alias','abbreviation','status','validated_gait_type','canonical_point_label','canonical_label_qualified','flight_count','flight_count_certain','primitive_flight_count','period_used','descriptive_only','isotropy_proved'};
    scopes={'point_metadata','contexts','saved_reports','orbit_evidence'};
    allowed={{'component_identity','order','edge_enabled','edge_from'},{'role','occurrence_id','source_reference','source_index','expected_index'}, ...
        {'schema_version','status','native_status','accepted','full_closure','full_closure_residual','acceptance_gates'}, ...
        {'return_policy','return_policy_name','return_multiplicity','candidate_section_count','candidate_apex_count','accepted_crossing_index','accepted_apex_index','section_relative_event_signature','cyclic_event_signature','primitive_cycle','gait_identification'}};
    for j=1:numel(scopes)
        scope=scopes{j};sourceRows=source.(scope);reducedRows=reduced.(scope);
        assert(strcmp(class(sourceRows),class(reducedRows))&&isequal(size(sourceRows),size(reducedRows)),'C1CoreReduce:RetainedArrayShape','Every projected occurrence array must preserve its class/shape.');
        for k=1:numel(sourceRows),verifyHeader(sourceRows{k},reducedRows{k},allowed{j},scope,k);end
    end
    function verifyHeader(before,after,keep,path,index)
        assert(isstruct(before)&&isscalar(before)&&isstruct(after)&&isscalar(after)&&strcmp(class(before),class(after))&&isequal(size(before),size(after)), ...
            'C1CoreReduce:RetainedHeaderShape','Every retained header must preserve scalar struct class/shape: %s occurrence%d.',path,index);
        names=fieldnames(before);expected=names(ismember(names,keep));
        assert(isequal(fieldnames(after),expected),'C1CoreReduce:RetainedFieldOrder','Present retained fieldnames and original field order differ: %s occurrence%d.',path,index);
        for n=1:numel(expected)
            key=expected{n};child=[path,'.',key];leftValue=before.(key);rightValue=after.(key);
            if any(strcmp(child,{'saved_reports.primitive','orbit_evidence.primitive_cycle'}))
                verifyHeader(leftValue,rightValue,primitive,child,index);
            elseif any(strcmp(child,{'saved_reports.classification','orbit_evidence.gait_identification'}))
                verifyHeader(leftValue,rightValue,classifier,child,index);
            else
                assert(strcmp(class(leftValue),class(rightValue))&&isequal(size(leftValue),size(rightValue)), ...
                    'C1CoreReduce:RetainedLeafShape','Retained leaf class/shape differs: %s occurrence%d.',child,index);
                same(leftValue,rightValue,sprintf('retained raw leaf %s occurrence%d',child,index));
            end
        end
    end
end

function verifyRetainedInverse(source,reduced)
    inverse=reduced;for key={'saved_reports','producer_reference','historical_audit_scope'},inverse.(key{1})=source.(key{1});end
    same(inverse,source,'whole source inverse outside explicitly declared projection/producer/scope fields');
    assert(isequaln(reduced.source_projection_digests,source.source_projection_digests),'C1CoreReduce:HistoricalDigests','Original full scientific projection digests remain unchanged historical provenance.');
end

function emit(receipt,tag,maximum)
    keys={'schema','source_stage_reference','failed_writer_witness_reference','producer_reference','output_file','stage_file','point_count','whole_core_limit_bytes','original_v2_reference','original_v2_bytes', ...
        'core_bytes','core_sha256','source_stage_loads','source_stage_native_read2_verified','retained_projection_read2_verified','all_native_ids_and_policies_verified','native_reconstructions', ...
        'core_native_read2_verified','installed_native_read2_verified','stage_save_returned','exclusive_publication_returned','owned_stage_removed','published_file_key_verified','loader_smoke_returned', ...
        'source_posthash','completed','pre_save_core_whos_bytes','elapsed_seconds','declared_wall_seconds','save_reserve_seconds','own_process_exit_observed','new_admission_claimed','aggregate_storage_reduction_claimed'};
    v=select(receipt,keys);v.full_receipt_typed_digest=C1ScientificDigest_v3(receipt);v.full_receipt_scope='Full receipt returned in MATLAB only; no repeated original86 receipt or occurrence-index vectors emitted.';
    v.omission_summary=cell(numel(receipt.omission_summary),1);
    for k=1:numel(v.omission_summary),v.omission_summary{k}=select(receipt.omission_summary{k},{'scope','occurrence_count','omitted_value_typed_digest','dropped_field_paths','omitted_field_occurrence_count'});end
    if ~isempty(fieldnames(receipt.failure))
        v.failure=receipt.failure;message=v.failure.message;v.failure.message=message(1:min(1000,numel(message)));v.failure.original_message_length=numel(message);v.failure.message_truncated=numel(message)>1000;
    end
    encoded=jsonencode(v);
    if numel(unicode2native(encoded,'UTF-8'))>maximum
        v=select(v,{'schema','output_file','stage_file','point_count','core_bytes','core_sha256','whole_core_limit_bytes','source_stage_loads','source_stage_native_read2_verified','retained_projection_read2_verified', ...
            'all_native_ids_and_policies_verified','native_reconstructions','core_native_read2_verified','installed_native_read2_verified','stage_save_returned','exclusive_publication_returned','owned_stage_removed', ...
            'published_file_key_verified','loader_smoke_returned','source_posthash','completed','elapsed_seconds','own_process_exit_observed','failure','full_receipt_typed_digest'});
        v.projection_scope='Bounded essential flags only; omitted authority references and omission dictionary remain in full MATLAB receipt, bound by its typed digest.';encoded=jsonencode(v);
    end
    assert(numel(unicode2native(encoded,'UTF-8'))<=maximum,'C1CoreReduce:StdoutBound','The bounded actual receipt exceeded its declared cap.');fprintf('%s %s\n',tag,encoded);
end

function [binding,q]=failedStageClosure(witnessRef,sourceStage,root)
    assert(strcmp(witnessRef.file,'/private/tmp/c1_pk36h_20261031_candidates/PK36h_0086_ActualOversizeReducedCoreStage_Closure.json') ...
        &&strcmp(witnessRef.sha256,'e5259742edb97258350db4c23c865d0158bca83cb9ba4d5dc95d503bd28a4964'),'C1CoreReduce:Witness','Use exact closed failed86 witness.');
    z=jsondecode(fileread(witnessRef.file));exactFields(z,{'schema','invocation_id','argv_utf8_sha256','exec_session_id','child_pid','actual_child_exit_code','actual_process_exit_observed','tool_prefix_reference','process_prefix_reference'});
    assert(strcmp(z.schema,'C1-ordinary-initializer-evidence-closure-v1')&&strcmp(z.invocation_id,'PK36h20261031-0086-final-connected-Core29-reduced-projection') ...
        &&z.exec_session_id==83503&&z.child_pid==37783&&isequal(z.actual_child_exit_code,1)&&isequal(z.actual_process_exit_observed,true) ...
        &&strcmp(z.argv_utf8_sha256,'837d1f7353b3b0e3dd96f76d12cab7c5bf03fbcafdf2ea7e36a731b4017cf370'),'C1CoreReduce:Failed86','Never turn original86 exit1 into success.');
    exactFields(z.tool_prefix_reference,{'file','prefix_bytes','prefix_sha256'});exactFields(z.process_prefix_reference,{'file','prefix_bytes','prefix_sha256'});
    assert(strcmp(z.tool_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Tool_Observations.jsonl'))&&z.tool_prefix_reference.prefix_bytes==1929922 ...
        &&strcmp(z.tool_prefix_reference.prefix_sha256,'c1fad08d31f35eab1989ba72aefcd7380d4ad32c28af07679cc958127a7bde2f') ...
        &&strcmp(z.process_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Process_Observations.jsonl'))&&z.process_prefix_reference.prefix_bytes==6490278 ...
        &&strcmp(z.process_prefix_reference.prefix_sha256,'c41ba81d42e7eaf5464a2af1857da10ee2e717ea905f822f3a6e0dd455f023a7'),'C1CoreReduce:Prefixes','Use only immutable actual prefixes.');
    tool=prefixRows(z.tool_prefix_reference);process=prefixRows(z.process_prefix_reference);
    rows=tool(cellfun(@(r)isfield(r,'invocation_id')&&strcmp(r.invocation_id,z.invocation_id),tool));assert(numel(rows)==4,'C1CoreReduce:ToolRows','Exactly four actual Tool rows.');
    starts={};exits={};partials={};callers={};positions=cell(11,1);terminal=0;
    tags={'C1_NATIVE_PROCESS_STARTED ','C1_FINAL_CORE29_REDUCED_BEFORE_HELPER','C1_CORE29_REDUCED_BEFORE_SOURCE_LOAD pass=1','C1_CORE29_REDUCED_AFTER_SOURCE_LOAD_RETURN pass=1', ...
        'C1_CORE29_REDUCED_BEFORE_SOURCE_LOAD pass=2','C1_CORE29_REDUCED_AFTER_SOURCE_LOAD_RETURN pass=2','C1_CORE29_REDUCED_BEFORE_STAGE_SAVE','C1_CORE29_REDUCED_AFTER_STAGE_SAVE_RETURN', ...
        'C1_CORE29_REDUCED_PARTIAL ','C1_FINAL_CORE29_BRIDGE_PARTIAL ','C1_NATIVE_PROCESS_EXIT '};
    for k=1:4
        r=rows{k};assert(strcmp(r.schema,'C1-native-exec-tool-observation-v1')&&r.tool_record_ordinal==k,'C1CoreReduce:ToolOrder','Actual Tool ordinal order.');
        if k<4,assert(isfield(r,'session_id')&&r.session_id==z.exec_session_id&&isfield(r.record,'session_id')&&r.record.session_id==z.exec_session_id,'C1CoreReduce:Session','Both actual running session fields.');
        else,assert(~isfield(r,'session_id')&&~isfield(r.record,'session_id'),'C1CoreReduce:TerminalAbsence','Actual terminal4 has neither session field.');end
        if isfield(r.record,'exit_code'),assert(k==4&&r.record.exit_code==1,'C1CoreReduce:ToolExit','Keep actual terminal1.');terminal=terminal+1;end
        if ~isfield(r.record,'output'),continue;end
        lines=strsplit(r.record.output,newline,'CollapseDelimiters',false);
        for j=1:numel(lines)
            line=lines{j};
            for t=1:numel(tags)
                if ~startsWith(line,tags{t}),continue;end
                if ismember(t,[2 3 4 5 6 7 8]),assert(strcmp(line,tags{t}),'C1CoreReduce:MarkerLiteral','Keep exact original marker.');end
                assert(isempty(positions{t}),'C1CoreReduce:MarkerUnique','Every expected original stage marker is unique.');positions{t}=[k j];
                if t==1,starts{end+1}=jsondecode(line(numel(tags{t})+1:end));elseif t==9,partials{end+1}=jsondecode(line(numel(tags{t})+1:end));elseif t==10,callers{end+1}=jsondecode(line(numel(tags{t})+1:end));elseif t==11,exits{end+1}=jsondecode(line(numel(tags{t})+1:end));end
            end
        end
    end
    expected={[2 1];[3 1];[3 2];[3 3];[4 1];[4 2];[4 3];[4 4];[4 5];[4 6];[4 14]};
    assert(terminal==1&&isequal(positions,expected)&&numel(starts)==1&&numel(partials)==1&&numel(callers)==1&&numel(exits)==1,'C1CoreReduce:UniqueClosure','Exact failed86 START/ALL2/save/partial/EXIT joins.');
    selected=process(cellfun(@(r)isfield(r,'invocation_id')&&strcmp(r.invocation_id,z.invocation_id),process));spec={};observed={};dispatch={};
    for k=1:numel(selected),r=selected{k};if strcmp(r.schema,'C1-native-launch-specification-v1'),spec{end+1}=r;elseif strcmp(r.schema,'C1-native-process-observation-v1'),observed{end+1}=r;elseif strcmp(r.schema,'C1-native-reviewed-specification-dispatch-confirmation-v1'),dispatch{end+1}=r;end,end
    assert(numel(spec)==1&&numel(observed)==1&&numel(dispatch)==1,'C1CoreReduce:ProcessRows','Unique actual process rows.');a=starts{1};b=observed{1};sp=spec{1};di=dispatch{1};
    assert(strcmp(a.invocation_id,z.invocation_id)&&a.child_pid==z.child_pid&&strcmp(a.argv_utf8_sha256,z.argv_utf8_sha256) ...
        &&b.child_pid==z.child_pid&&isequal(b.actual_child_exit_code,1)&&isequal(b.actual_process_exit_observed,true)&&strcmp(b.argv_utf8_sha256,z.argv_utf8_sha256) ...
        &&strcmp(sp.argv_utf8_sha256,z.argv_utf8_sha256)&&strcmp(di.argv_utf8_sha256,z.argv_utf8_sha256)&&isequaln(exits{1},b),'C1CoreReduce:ProcessJoin','Actual child1/argv/spec/dispatch/exit all agree.');
    assert(strcmp(sp.expected_execution_tool_options.sandbox_permissions,'require_escalated')&&isequaln(rows{1}.actual_execution_tool_options,sp.expected_execution_tool_options) ...
        &&isequaln(di.expected_execution_tool_options,sp.expected_execution_tool_options)&&isequaln(b.expected_execution_tool_options,sp.expected_execution_tool_options),'C1CoreReduce:Profile','Preserve actual execution profile.');
    expectedSource=struct('file',fullfile(root,'Methodology_20261030','Current_PK_Export_20261031','PK04_Core29_Reduced','ReduceC1PKSolutionCore29_20261101.m'),'sha256','417cb23b67127f7b551a37df639c5c0d09c149acfc30a3f2febf6ee04282f02b');
    assert(sameReference(sp.source_reference,expectedSource),'C1CoreReduce:OriginalMethod','Actual86 used original 417 reducer.');checked(expectedSource);
    q=partials{1};assert(strcmp(q.schema,'C1-reduced-core29-write-receipt-v1')&&q.point_count==494&&q.source_stage_loads==2 ...
        &&isequal(q.source_stage_native_read2_verified,true)&&isequal(q.retained_projection_read2_verified,true)&&isequal(q.all_native_ids_and_policies_verified,true) ...
        &&q.native_reconstructions==494&&isequal(q.stage_save_returned,true)&&isequal(q.completed,false)&&isequal(q.source_posthash,false) ...
        &&isequal(q.core_native_read2_verified,false)&&isequal(q.installed_native_read2_verified,false)&&isequal(q.exclusive_publication_returned,false) ...
        &&isequal(q.loader_smoke_returned,false)&&isequal(q.owned_stage_removed,false)&&isequal(q.published_file_key_verified,false) ...
        &&q.core_bytes==704514&&q.whole_core_limit_bytes==554305&&strcmp(q.core_sha256,sourceStage.sha256)&&strcmp(q.stage_file,sourceStage.file) ...
        &&strcmp(q.failure.identifier,'C1CoreReduce:FiveTimes')&&sameReference(q.producer_reference,expectedSource), ...
        'C1CoreReduce:OriginalFlags','Keep exact original86 read2/retained/494-ID/save facts and all original failed/incomplete flags.');
    oldStage=struct('file',fullfile(root,'Compact_Exports_20261030','C1_PK_Connected04_Core29_20261101.mat.pending.mat'),'sha256','2808068fae99574b00079ab8f6ec28d6481625e9f37f1c9077bef2101d46db28');
    oldWitness=struct('file','/private/tmp/c1_pk36h_20261031_candidates/PK36h_0085_ActualOversizeCoreStage_Closure.json','sha256','530c9a2dcc1505c3bd8f71e2b98bc9be44d93ea85696e68836b0e4dbcc6eb76c');
    assert(sameReference(q.source_stage_reference,oldStage)&&sameReference(q.failed_writer_witness_reference,oldWitness),'C1CoreReduce:PriorInput','Actual86 read the declared failed86 source; no original86 success promotion.');
    guards=sp.operative_guard_references;if isstruct(guards),guards=num2cell(guards(:));else,assert(iscell(guards),'C1CoreReduce:GuardRows','Actual guard object-array shape is required.');guards=guards(:);end
    assert(sum(cellfun(@(r)sameReference(r,oldStage),guards))==1 ...
        &&sum(cellfun(@(r)sameReference(r,oldWitness),guards))==1,'C1CoreReduce:ProcessInputs','Actual86 Processspec binds both original input authorities.');
    caller=callers{1};assert(strcmp(caller.schema,'C1-reduced-core29-bridge-caller-partial-v1')&&isequal(caller.completed,false)&&isequal(caller.helper_attempted,true) ...
        &&isequal(caller.helper_returned,false)&&isequal(caller.own_process_exit_observed,false)&&strcmp(caller.failure_identifier,'C1CoreReduce:FiveTimes') ...
        &&strcmp(caller.stage_file,sourceStage.file)&&strcmp(caller.output_file,q.output_file)&&sameReference(caller.failed_stage_reference,oldStage) ...
        &&sameReference(caller.failed_stage_closure_reference,oldWitness),'C1CoreReduce:CallerFailed','Original86 caller did not return success.');
    assert(~isfile(q.output_file),'C1CoreReduce:OriginalAbsent','Retain the original absent-final boundary.');
    binding=struct('source_reference',expectedSource,'witness_reference',witnessRef,'tool_prefix_reference',z.tool_prefix_reference,'process_prefix_reference',z.process_prefix_reference, ...
        'process_session_id',z.exec_session_id,'child_pid',z.child_pid,'actual_exit_code',z.actual_child_exit_code,'actual_process_exit_observed',z.actual_process_exit_observed, ...
        'source_stage_reference',sourceStage,'literal_marker_positions',{positions},'verified',true,'scope','Original86 failed after source-stage native2, retained checks,494 IDs/policies and save; no new-stage read2/publication/sourcepost success claimed.');
end

function rows=guardedMethods(names,refs)
    rows=cell(numel(names),1);
    for k=1:numel(names)
        file=literalPath(which(names{k}));hit=find(cellfun(@(r)strcmp(canonical(r.file),file),refs));
        assert(isscalar(hit),'C1Core29:MethodPin','Supply one exact protected current resolver/SHA pin for %s.',names{k});
        r=checked(refs{hit});rows{k}=struct('name',names{k},'file',r.file,'sha256',r.sha256);
    end
end

function verifyCode(rows),for k=1:numel(rows),r=rows{k};assert(strcmp(literalPath(which(r.name)),r.file)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Core29:Resolver','A declared current implementation changed.');end,end
function out=select(s,names),out=struct();for k=1:numel(names),if isfield(s,names{k}),out.(names{k})=s.(names{k});end,end,end
function same(a,b,label),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'C1Core29:TypedEquality','Literal class/shape/rawbits/fields changed: %s.',label);end
function yes=sameReference(a,b),yes=isstruct(a)&&isscalar(a)&&all(isfield(a,{'file','sha256'}))&&isstruct(b)&&isscalar(b)&&all(isfield(b,{'file','sha256'}))&&strcmp(canonical(a.file),canonical(b.file))&&strcmp(a.sha256,b.sha256);end
function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'}))&&ischar(r.sha256)&&isrow(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once')),'C1Core29:Reference','Use one exact file/SHA reference.');r=struct('file',literalPath(r.file),'sha256',r.sha256);verify({r});end
function validateReferences(rows),assert(iscell(rows)&&iscolumn(rows),'C1Core29:References','Supply a column cell of actual current protected references.');for k=1:numel(rows),checked(rows{k});end,end
function verify(rows),for k=1:numel(rows),r=rows{k};assert(isfile(r.file)&&strcmp(literalPath(r.file),canonical(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Core29:Changed','A consumed/protected file changed: %s.',r.file);end,end
function identity=fileIdentity(file)
    p=java.io.File(file).toPath();no=javaArray('java.nio.file.LinkOption',1);no(1)=javaMethod('valueOf','java.nio.file.LinkOption','NOFOLLOW_LINKS');
    assert(~java.nio.file.Files.isSymbolicLink(p)&&java.nio.file.Files.isRegularFile(p,no),'C1Core29:Regular','Own stage/final must be a regular nonsymlink file.');
    attrs=javaMethod('readAttributes','java.nio.file.Files',p,'basic:fileKey',no);key=attrs.get('fileKey');assert(~isempty(key),'C1Core29:FileKey','A stable owned file key is required.');
    identity=struct('file',canonical(file),'key',char(javaMethod('toString','java.util.Objects',key)),'bytes',double(java.nio.file.Files.size(p)));
end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1Core29:Fresh','Retain existing output/uncertain stage: %s.',paths{k});end,end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function t=clockPair(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end
function t=shift(t,s),t.utc=t.utc+s;t.mono=t.mono+1e9*s;end
function t=minimum(a,b),t=struct('utc',min(a.utc,b.utc),'mono',min(a.mono,b.mono));end
function n=left(t),n=min(t.utc-posixtime(datetime('now','TimeZone','UTC')),(t.mono-double(java.lang.System.nanoTime))/1e9);end
function check(t),assert(left(t)>0,'C1Core29:Clock','The unchanged original/local FINAL clock expired.');end
function p=literalPath(p)
    p=canonical(p);resolved=canonical(V3Path_v3(p));
    assert(strcmp(p,resolved),'C1Core29:LiteralPath','Hash, native load and publication must address the same literal canonical path; a legacy alias refuses.');
end

function rows=prefixRows(r)
    validSHA(r.prefix_sha256);assert(ischar(r.file)&&isrow(r.file)&&isa(r.prefix_bytes,'double')&&isscalar(r.prefix_bytes)&&isfinite(r.prefix_bytes)&&r.prefix_bytes>0&&r.prefix_bytes<=16*1024*1024&&r.prefix_bytes==fix(r.prefix_bytes),'C1PKFork:Prefix','Require an exact bounded prefix.');
    f=fopen(r.file,'rb');assert(f>=0,'C1PKFork:PrefixOpen','Cannot read prefix.');closer=onCleanup(@()fclose(f));b=fread(f,r.prefix_bytes,'*uint8');assert(numel(b)==r.prefix_bytes&&b(end)==10,'C1PKFork:PrefixLength','Exact prefix must end atLF.');clear closer
    d=java.security.MessageDigest.getInstance('SHA-256');d.update(b);h=lower(reshape(dec2hex(typecast(d.digest(),'uint8'),2).',1,[]));assert(strcmp(h,r.prefix_sha256),'C1PKFork:PrefixSHA','Immutable prefix changed.');
    lines=strsplit(native2unicode(b.','UTF-8'),newline,'CollapseDelimiters',false);lines(end)=[];rows=cellfun(@jsondecode,lines,'UniformOutput',false);
end

function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end

function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end

function validateCore(c,digest)
    keys={'schema','layout','point_count','solution_matrix','parameters','modes','native_ids','point_metadata','contexts', ...
        'policies','section_charts','orbit_evidence','saved_reports','native_energy','signed_mean_U','graph', ...
        'source_projection_digests','source_reference','qualification_reference','qualification_closure', ...
        'writer_audit_reference','original_v2_reference','original_v2_bytes','maximum_core_bytes','runtime_methods','runtime_environment', ...
        'producer_reference','historical_audit_scope','replay_scope'};
    assert(isstruct(c)&&isscalar(c)&&isequal(sort(fieldnames(c)),sort(keys(:))) ...
        &&strcmp(c.schema,'C1-self-contained-solution-core29-v1') ...
        &&strcmp(c.layout,'rows1:14=initial_state;15:28=full_stride;29=period; columns=stored occurrences'), ...
        'C1Core29:Schema','Unknown core schema/fields refuse.');
    validSHA(digest);assert(strcmp(C1ScientificDigest_v3(c),digest),'C1Core29:Digest','The complete plain core typed digest changed.');
    N=c.point_count;validateattributes(N,{'double'},{'real','scalar','finite','integer','positive'});
    assert(isa(c.solution_matrix,'double')&&isreal(c.solution_matrix)&&~issparse(c.solution_matrix)&&isequal(size(c.solution_matrix),[29,N]) ...
        &&all(isfinite(c.solution_matrix(:)))&&all(c.solution_matrix(29,:)>0),'C1Core29:Matrix','The declared29-by-N finite real double layout is required.');
    for name={'parameters','modes','native_ids','point_metadata','contexts','policies','section_charts','orbit_evidence','saved_reports','source_projection_digests'}
        assert(iscell(c.(name{1}))&&isequal(size(c.(name{1})),[N,1]),'C1Core29:Rows','All occurrence arrays are Nx1 cells.');
    end
    assert(isa(c.native_energy,'double')&&isreal(c.native_energy)&&isequal(size(c.native_energy),[1,N])&&all(isfinite(c.native_energy)) ...
        &&isa(c.signed_mean_U,'double')&&isreal(c.signed_mean_U)&&isequal(size(c.signed_mean_U),[1,N])&&all(isfinite(c.signed_mean_U)), ...
        'C1Core29:Scalars','Stored plot scalars must be finite literal doubles.');
    ids=cell(N,1);owners=ids;orders=zeros(N,1);
    for k=1:N
        p=c.parameters{k};q=c.modes{k};assert(isnumeric(p)&&isreal(p)&&numel(p)==10&&all(isfinite(p(:))) ...
            &&(isnumeric(q)||islogical(q))&&isreal(q)&&numel(q)==4&&all(isfinite(q(:))),'C1Core29:PQ','Literal p10/q4 are required, without class/shape coercion.');
        nativeID(c.native_ids{k});validSHA(c.source_projection_digests{k});
        m=c.point_metadata{k};x=c.contexts{k};
        assert(isstruct(m)&&isscalar(m)&&all(isfield(m,{'component_identity','order'})) ...
            &&isstruct(x)&&isscalar(x)&&all(isfield(x,{'role','occurrence_id','expected_index','source_reference','source_index'})) ...
            &&isequal(x.expected_index,k),'C1Core29:Occurrence','Each literal source occurrence must retain its owner/context/order.');
        text(m.component_identity);text(x.occurrence_id);validateattributes(m.order,{'double'},{'real','scalar','finite','integer','positive'});
        if isfield(x,'native_id'),assert(isequaln(x.native_id,c.native_ids{k}),'C1Core29:ContextID','Context NativeID differs.');end
        owners{k}=m.component_identity;orders(k)=m.order;ids{k}=x.occurrence_id;
        prior=find(strcmp(owners(1:k-1),owners{k}),1,'last');
        assert(isempty(prior)||orders(k)>orders(prior),'C1Core29:OwnerOrder','Within-owner order must strictly increase.');
        policy=c.policies{k};assert(isstruct(policy)&&isscalar(policy)&&isequal(policy.complete,true) ...
            &&isstruct(policy.configuration)&&isscalar(policy.configuration) ...
            &&strcmp(policy.configuration.source_class,'BLMarkedApexReturnPolicy_v3'),'C1Core29:Policy','Only complete recorded BL policy configurations are supported.');
        chart=c.section_charts{k};assert(isstruct(chart)&&isscalar(chart)&&all(isfield(chart, ...
            {'id','geometry','crossing_orientation','boundary_ownership','translational_gauge','BL_touchdowns_per_return'})), ...
            'C1Core29:Section','A complete recorded section chart is load-required.');
        assert(isstruct(c.orbit_evidence{k})&&isscalar(c.orbit_evidence{k})&&isstruct(c.saved_reports{k})&&isscalar(c.saved_reports{k}), ...
            'C1Core29:HistoricalEvidence','Historical evidence remains plain and explicit.');
    end
    assert(numel(unique(ids))==N,'C1Core29:OccurrenceIDs','Occurrence IDs must be unique; NativeIDs may repeat.');
    validateGraph(c.graph,c.point_metadata,c.native_ids);
    assert(isnumeric(c.original_v2_bytes)&&isscalar(c.original_v2_bytes)&&isfinite(c.original_v2_bytes)&&c.original_v2_bytes>0 ...
        &&c.original_v2_bytes<=flintmax/5&&isequal(c.maximum_core_bytes,5*c.original_v2_bytes),'C1Core29:Cap','The whole component payload cap is exactly5 times the original fullv2 file bytes.');
end

function validateGraph(g,metadata,ids)
    keys={'schema','role','displayname','physical_edges','record_equalities','qualified_aliases','numerical_seams','source_versions'};
    assert(isstruct(g)&&isscalar(g)&&isequal(sort(fieldnames(g)),sort(keys(:)))&&strcmp(g.schema,'C1-essential-branch-graph-v1'), ...
        'C1Core29:Graph','Retain the whole qualified literal graph metadata.');
    N=numel(ids);incoming=zeros(N,1);
    for name={'physical_edges','record_equalities','qualified_aliases','numerical_seams'}
        rows=g.(name{1});assert(iscell(rows)&&iscolumn(rows),'C1Core29:GraphRows','Each typed graph remains a separate column cell table.');
        for j=1:numel(rows)
            e=rows{j};assert(isstruct(e)&&isscalar(e)&&all(isfield(e,{'from','to'})),'C1Core29:Relation','Unknown relation row.');
            validateattributes(e.from,{'double'},{'real','scalar','finite','integer','>=',1,'<=',N});
            validateattributes(e.to,{'double'},{'real','scalar','finite','integer','>=',1,'<=',N});
            assert(e.from~=e.to,'C1Core29:SelfEdge','Stored relation endpoints differ.');
            if strcmp(name{1},'physical_edges')
                assert(e.from<e.to&&strcmp(e.component_identity,metadata{e.from}.component_identity) ...
                    &&strcmp(e.component_identity,metadata{e.to}.component_identity),'C1Core29:PhysicalOwner','Physical edges require the original orientation and same owner.');
                incoming(e.to)=incoming(e.to)+1;
                assert(incoming(e.to)==1&&isequal(metadata{e.to}.edge_enabled,true)&&isequal(metadata{e.to}.edge_from,e.from), ...
                    'C1Core29:PhysicalPredecessor','Actual saved point/physical-edge predecessors must agree.');
            else
                assert(strcmp(e.from_native_id,ids{e.from})&&strcmp(e.to_native_id,ids{e.to}) ...
                    &&all(isfield(e,{'receipt_reference','evidence'})),'C1Core29:RelationID','Typed nonphysical links retain both actual endpoint IDs and evidence.');
            end
        end
    end
    for k=1:N
        enabled=isfield(metadata{k},'edge_enabled')&&isequal(metadata{k}.edge_enabled,true);
        assert(enabled==(incoming(k)==1),'C1Core29:Incoming','No enabled physical point edge may be omitted.');
    end
end

function [o,r]=reconstruct(c,k)
    v=struct('initial_state',c.solution_matrix(1:14,k),'initial_mode',c.modes{k},'parameter',c.parameters{k}, ...
        'stride_displacement',c.solution_matrix(15:28,k),'period',c.solution_matrix(29,k));
    o=HybridOrbit_v3(v);for name=properties(o).',o.(name{1})=[];end
    for name=fieldnames(v).',o.(name{1})=v.(name{1});end
    evidence=c.orbit_evidence{k};for name=fieldnames(evidence).',assert(isprop(o,name{1}),'C1Core29:OrbitProperty','Unknown retained orbit property.');o.(name{1})=evidence.(name{1});end
    o.section_chart=c.section_charts{k};o.validate();
    assert(strcmp(OrbitContentIdentity_v3(o),c.native_ids{k}),'C1Core29:NativeID','Fresh native reconstruction changed actual identity-bearing values.');
    configuration=c.policies{k}.configuration;r=c.saved_reports{k};
    r.correction_return_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',configuration.source_class,'settings',configuration.settings);
    [~,restored]=RecordedReturnPolicy_v3(r);
    assert(isequal(restored.complete,true)&&strcmp(C1ScientificDigest_v3(restored.configuration),C1ScientificDigest_v3(configuration)), ...
        'C1Core29:PolicyRoundtrip','The actual known policy constructor must preserve every recorded setting.');
    r.core29_view=struct('schema',c.schema,'requires_fresh_replay',true,'saved_decisions_are_historical',true, ...
        'fresh_all_nine_admission_claimed',false,'dense_trajectory_available',false);
end

function verifyMethods(rows,environment)
    assert(iscell(rows)&&iscolumn(rows),'C1Core29:Methods','Use a declared runtime method tuple.');
    required={'LoadC1SolutionCore29_v3','RoundSHA256_v3','V3Path_v3','V3Root_v3','C1ScientificDigest_v3','HybridOrbit_v3','OrbitContentIdentity_v3', ...
        'QuadrupedSchema_v3','RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3'};names=cell(numel(rows),1);
    for k=1:numel(rows)
        r=rows{k};assert(isstruct(r)&&isscalar(r)&&isequal(sort(fieldnames(r)),{'name';'sha256'}),'C1Core29:Method','Unknown runtime method row.');
        text(r.name);validSHA(r.sha256);file=which(r.name);assert(~isempty(file)&&strcmp(literalPath(file),canonical(file))&&strcmp(RoundSHA256_v3(file),r.sha256),'C1Core29:MethodSHA','The declared runtime implementation changed: %s.',r.name);names{k}=r.name;
    end
    assert(numel(unique(names))==numel(names)&&all(ismember(required,names)),'C1Core29:MethodTuple','The complete declared loader/constructor tuple is required; it is not a transitive execution trace.');
    assert(isstruct(environment)&&isscalar(environment)&&isequal(sort(fieldnames(environment)),sort({'locations_map_relative_path';'locations_map_sha256';'scope'})) ...
        &&strcmp(environment.locations_map_relative_path,fullfile('Audits_v3','Folder_Organization','locations.json')),'C1Core29:RuntimeEnvironment','Use the declared current-model runtime location map, not a historical scientific sidecar.');
    validSHA(environment.locations_map_sha256);root=V3Root_v3(which('V3Path_v3'));map=literalPath(fullfile(root,environment.locations_map_relative_path));
    assert(strcmp(RoundSHA256_v3(map),environment.locations_map_sha256),'C1Core29:LocationMap','The current runtime location map changed.');
end

function nativeID(v),text(v);assert(~isempty(regexp(v,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1Core29:ID','Use actual OrbitContentIdentity output.');end
function text(v),assert(ischar(v)&&isrow(v)&&~isempty(v),'C1Core29:Text','Use a nonempty character row.');end
