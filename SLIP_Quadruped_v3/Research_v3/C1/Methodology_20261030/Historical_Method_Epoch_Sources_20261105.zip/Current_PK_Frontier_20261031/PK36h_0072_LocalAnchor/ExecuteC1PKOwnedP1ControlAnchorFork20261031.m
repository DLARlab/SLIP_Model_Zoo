function facts=ExecuteC1PKOwnedP1ControlAnchorFork20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,options)
% One declared owned-anchor PAL pilot. No central reset, merge or target seed.
    entry=clockPair();validSHA(expectedLedgerSHA);validSHA(expectedRawSHA);validSHA(expectedRoundSHA);
    exactFields(options,{'Saved179Reference','RemainingReference','Saved179RawReference','RemainingRawReference', ...
        'ComparisonClosureReference','TargetOriginalColumn','PrimaryAnchorIndex','OutputFile','CheckpointFile','ComponentIdentity','ProtectedReferences'});o=options;
    for key={'Saved179Reference','RemainingReference','Saved179RawReference','RemainingRawReference','ComparisonClosureReference'},o.(key{1})=checked(o.(key{1}));end
    assert(ismember(o.TargetOriginalColumn,[152 179]),'C1PKAnchor:Column','Declare only the established original152 or179 control.');
    validateattributes(o.PrimaryAnchorIndex,{'double'},{'real','scalar','finite','integer','positive'});
    assert(strcmp(o.Saved179Reference.sha256,'1fd2ec2572f35423ad94f524df8c95a92c3adf474f97ccf719e94c2e82fa45fd') ...
        &&strcmp(o.RemainingReference.sha256,'da6ec1687ebc62a8c21c651e3d5a2daf84f169cae7e249b6ba23baca809c5d58') ...
        &&strcmp(o.Saved179RawReference.sha256,'9f51c9b35a258e97d8734548773cec3ddf6449302286e2f809266a6e420e923e') ...
        &&strcmp(o.RemainingRawReference.sha256,'a15b6a659bb1d0ff8e2ee73324a7e3e5bb7de29584d8af3f8ecb683015c824a9') ...
        &&strcmp(o.ComparisonClosureReference.sha256,'81b2b06aa214ecc5681c689f454288448bcc05371c713437b8fd6f09b1ac69c1'), ...
        'C1PKAnchor:Authorities','Use the actual direct controls and closed0071 comparison.');
    root=canonical(fileparts(which('C1RunBudget_v3')));budget=C1RunBudget_v3();finish=shift(entry,900);work=shift(finish,-120);
    assert(finish.utc<budget.research_deadline_unix_seconds&&finish.mono<budget.research_deadline_monotonic_ns,'C1PKAnchor:WholeFit','All900 including120 reserve must fit BOTH original SCIENCE clocks.');check(work);
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));raw=canonical(fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'));
    roundFile=canonical(fullfile(root,'Audits','PK36h_20261031_Round.mat'));o.OutputFile=canonical(o.OutputFile);o.CheckpointFile=canonical(o.CheckpointFile);
    assert(ischar(o.ComponentIdentity)&&isrow(o.ComponentIdentity)&&~isempty(regexp(o.ComponentIdentity,'^[A-Za-z][A-Za-z0-9_-]{0,95}$','once')),'C1PKAnchor:Owner','Declare an explicit fresh unique owner.');
    assert(strcmp(fileparts(o.OutputFile),canonical(fullfile(root,'Results')))&&strcmp(fileparts(o.CheckpointFile),canonical(fullfile(root,'Audits'))) ...
        &&endsWith(o.OutputFile,'.mat')&&endsWith(o.CheckpointFile,'.mat'),'C1PKAnchor:Paths','Use fresh Results output and separate Audits checkpoint.');
    isolated=canonical(fullfile(root,'Results',['C1_Isolated_Native_Admissions',budget.result_suffix,'.mat']));
    live={struct('file',ledger,'sha256',expectedLedgerSHA);struct('file',raw,'sha256',expectedRawSHA);struct('file',roundFile,'sha256',expectedRoundSHA)};
    protected=references(o.ProtectedReferences);self=reference(which(mfilename));code=forkCode(self,protected);
    refs=[live;{o.Saved179Reference;o.RemainingReference;o.Saved179RawReference;o.RemainingRawReference;o.ComparisonClosureReference};protected];
    writes={o.OutputFile;o.CheckpointFile;[o.CheckpointFile,'.pending.mat'];[o.OutputFile,'.pending.mat'];isolated;[isolated,'.pending.mat']};freshPaths(writes);
    assert(numel(unique(writes))==numel(writes),'C1PKAnchor:DistinctWrites','All declared write paths must differ.');
    for k=1:numel(refs),assert(~any(strcmp(refs{k}.file,writes)),'C1PKAnchor:ProtectedWrite','No output may alias an input.');end
    beforeResults=directoryNames(fileparts(o.OutputFile));beforeAudits=directoryNames(fileparts(o.CheckpointFile));
    facts=struct('schema','C1-owned-PK-P1-control-anchor-single-fork-v1','source_reference',self,'budget',budget,'wrapper_entry',entry,'wrapper_finish',finish,'wrapper_work',work, ...
        'wrapper_seconds',900,'outer_post_reserve_seconds',120,'Run_save_margin_seconds',120,'original_trial_seconds',240,'expected_current_references',{live}, ...
        'actual_method_references',{code},'target_original_column',o.TargetOriginalColumn,'primary_anchor_index',o.PrimaryAnchorIndex,'source_pair',[], ...
        'source_pair_read2_verified',false,'source_index_read2_verified',false,'source_index_calls_returned',0,'source_selected_loads_returned',0, ...
        'target_audit_loads_returned',0,'target_native_read2_verified',false,'comparison_closed_verified',false,'target_intake_headers',{{}}, ...
        'candidate_geometry',{{}},'selected_candidate_ordinal',0,'native_geometry',struct(),'output_file',o.OutputFile,'checkpoint_file',o.CheckpointFile, ...
        'component_identity',o.ComponentIdentity,'global_isolated_file',isolated,'declared_fixed_write_paths',{writes},'Run_calls_attempted',0,'Run_calls_returned',0, ...
        'Run_return_observed_before_outer_work',false,'Run_actual_limits_within_original_work',false,'Run_options',struct(),'Run_observation',struct(), ...
        'actual_attempt_rows',0,'native_pending_present',false,'owned_fork_commit_verified',false,'fork_native_read2_verified',false, ...
        'cloned_seed_native_ids_preserved',false,'cheap_target_comparison',struct(),'file_observations',struct(),'directory_changes',struct(), ...
        'source_posthash',false,'completed',false,'failure',struct(),'status','prepared','journal_mutated',false,'round_mutated',false, ...
        'primary_raw_mutated',false,'central_frontier_reset',false,'primary_canonical_edge_registered',false,'target_used_as_seed',false, ...
        'target_projection_as_admission',false,'fresh_fines_performed',false,'all_four_target_cohorts_claimed',false, ...
        'P1_original_state_admission_claimed',false,'scheduled_v2_trajectory_equivalence_claimed',false,'physical_attachment_claimed',false, ...
        'endpoint_claimed',false,'global_completion_claimed',false,'own_process_exit_observed',false);
    normalReturned=false;
    try
        guard(work);assert(isfile([ledger,'.writer.lock']),'C1PKAnchor:ExistingLock','Use the stable existing writer-lock inode.');lock=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
        [targets,points,historical]=storedControls(o,work,@observedTwice,@emitTargetHeader);facts.target_native_read2_verified=true;facts.historical_qualification=historical;
        columns=[152;179];tidx=find(columns==o.TargetOriginalColumn);target=targets{tidx};targetPoint=points{tidx};
        assert(isequal(target.current_PK1_all9_evidence_complete,true),'C1PKAnchor:TargetEvidence','This pilot requires the actually available complete retained PK1/all9 target evidence.');
        [witness,policyReport,signature]=storedSection(target,targetPoint,work);targetShapes(target,witness);
        [closed,q,spec]=comparisonClosure(o.ComparisonClosureReference,root,work);facts.comparison_closed_verified=true;facts.actual_comparison_closure=closed;
        refs{end+1,1}=checked(spec.source_reference);anchorWitness=bindComparison(q,spec,o,raw,expectedRawSHA,target);clear q
        fprintf('C1_PK_ANCHOR_FORK_BEFORE_INDEX1\n');ix=BranchSolutionFile_v3.index(raw);facts.source_index_calls_returned=1;fprintf('C1_PK_ANCHOR_FORK_AFTER_INDEX1_RETURN\n');check(work);
        fprintf('C1_PK_ANCHOR_FORK_BEFORE_INDEX2\n');ix2=BranchSolutionFile_v3.index(raw);facts.source_index_calls_returned=2;fprintf('C1_PK_ANCHOR_FORK_AFTER_INDEX2_RETURN\n');check(work);
        assert(isequaln(ix,ix2),'C1PKAnchor:IndexRead2','Two complete current indices differ.');clear ix2;facts.source_index_read2_verified=true;
        [nodes,pairs,edges]=incomingChain(ix,o.PrimaryAnchorIndex);facts.source_chain_indices=nodes;facts.candidate_source_pairs=pairs;facts.source_chain_edges=edges;
        assert(~any(cellfun(@(p)strcmp(p.component_identity,o.ComponentIdentity),ix.points)),'C1PKAnchor:FreshOwner','The declared new owner must not be an existing primary owner.');
        guard(work);fprintf('C1_PK_ANCHOR_FORK_BEFORE_SELECTED1\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(raw,nodes);facts.source_selected_loads_returned=1;fprintf('C1_PK_ANCHOR_FORK_AFTER_SELECTED1_RETURN\n');check(work);
        first=cell(numel(nodes),1);principal=[10;10;20;20;1;1;0;0;2;.5];
        for k=1:numel(nodes),strictPK(O{k},R{k},principal);first{k}=pointHeader(O{k},R{k},M{k},ix.points{nodes(k)},nodes(k));end;clear O R M
        guard(work);fprintf('C1_PK_ANCHOR_FORK_BEFORE_SELECTED2\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(raw,nodes);facts.source_selected_loads_returned=2;fprintf('C1_PK_ANCHOR_FORK_AFTER_SELECTED2_RETURN\n');check(work);
        for k=1:numel(nodes),strictPK(O{k},R{k},principal);h=pointHeader(O{k},R{k},M{k},ix.points{nodes(k)},nodes(k));assert(isequaln(h,first{k}),'C1PKAnchor:NativeRead2','Actual compact source values differ.');end
        anchor=first{end};assert(anchor.index==o.PrimaryAnchorIndex&&strcmp(anchor.native_id,anchorWitness.native_id) ...
            &&strcmp(C1ScientificDigest_v3(anchor.owner),anchorWitness.owner_digest),'C1PKAnchor:AnchorID','Fresh actual anchor ID/full-owner digest must join the closed comparison; owner_prefix is not a full owner.');
        facts.source_pair_read2_verified=true;facts.source_chain_headers=first;
        facts.target=struct('original_column',o.TargetOriginalColumn,'native_id',target.native_id,'state',target.state,'mode',target.mode, ...
            'parameter',target.parameter,'period',target.period,'full_stride',target.full_stride,'native_energy',target.native_energy, ...
            'current_PK1_all9_evidence_complete',target.current_PK1_all9_evidence_complete,'policy_configuration',target.policy_configuration,'section_chart',targetPoint.section_chart);
        for k=1:size(pairs,1)
            ai=find(nodes==pairs(k,1));bi=find(nodes==pairs(k,2));
            facts.candidate_geometry{k,1}=nativeGeometry(O{ai},O{bi},R{ai},R{bi},target,witness,policyReport,pairs(k,:),work);
        end
        eligible=cellfun(@(g)isequal(g.eligible,true),facts.candidate_geometry);chosen=find(eligible,1,'first');
        if isempty(chosen),chosen=0;facts.selected_candidate_ordinal=0;facts.status='no_declared_geometry_pair_eligible';
        else,facts.selected_candidate_ordinal=chosen;facts.source_pair=pairs(chosen,:);facts.native_geometry=facts.candidate_geometry{chosen};end
        intake=preRunHeader(facts);encoded=jsonencode(intake);assert(numel(unicode2native(encoded,'UTF-8'))<=6000,'C1PKAnchor:IntakeBytes','Bound the actionable pre-Run header to6000UTF8.');
        fprintf('C1_PK_CONTROL_ANCHOR_PRE_RUN %s\n',encoded);facts.pre_Run_header=intake;clear O R M h ix points targets targetPoint spec anchorWitness anchor
        clean=true;
        if chosen>0
            geometry=facts.native_geometry;constraint=geometry.constraint;original=first(ismember(nodes,facts.source_pair));
            guard(work);freshPaths(writes);assert(left(work)-2>240+120+10,'C1PKAnchor:RunSlot','Full240 trial+Run120 save+10 fit must remain inside ORIGINAL wrapperWORK.');
            cap=left(work)-2;ro=struct('Budget',budget,'MaxWallSeconds',cap,'TrialSeconds',240,'SaveMarginSeconds',120,'MaxAccepted',1,'MaxAttempts',1, ...
                'InitialStep',geometry.sigma,'MinimumStep',1e-7,'MaximumStep',.1,'StepGrowth',1.3,'StepShrink',.5,'CaptureRadius',.02,'MaxSavedFailures',2, ...
                'DerivativeMethod','valid-sided','FiniteDifferenceSteps',1e-8,'ReusePreviousJacobian',false,'Algorithm','root-newton','AllowedClasses',{{'PK'}}, ...
                'ComponentIdentity',o.ComponentIdentity,'IntegrationMaxStep',.001,'CorrectorInitializer','base','InPlace',false,'CheckpointFile',o.CheckpointFile,'InitialDerivativeIndex',1,'MinimumApexHeightRatio',.5);
            facts.Run_options=rmfield(ro,'Budget');facts.derived_inner_cap_from_original_work=cap;facts.handoff_margin_seconds=2;
            fprintf('C1_PK_ANCHOR_FORK_BEFORE_RUN\n');facts.Run_calls_attempted=1;s=RunC1Continuation_v3(o.OutputFile,raw,facts.source_pair,'pronk',ro);facts.Run_calls_returned=1;fprintf('C1_PK_ANCHOR_FORK_AFTER_RUN_RETURN\n');
            facts.Run_return_observed_before_outer_work=left(work)>0;facts.Run_actual_limits_within_original_work=s.run_limit.deadline_unix_seconds<=work.utc&&s.run_limit.deadline_monotonic_ns<=work.mono ...
                &&s.work_limit.deadline_unix_seconds<=work.utc-120&&s.work_limit.deadline_monotonic_ns<=work.mono-120e9;
            assert(isequaln(s.original_budget,budget),'C1PKAnchor:RunBudget','Returned grant remains literal.');facts.Run_observation=runHeader(s);facts.actual_attempt_rows=numel(s.attempts);facts.native_pending_present=~isempty(fieldnames(s.pending_admission));
            assert(numel(s.attempts)<=1&&s.new_points<=1&&s.new_edges<=1,'C1PKAnchor:OneAttempt','No pair retry or second correction is allowed.');
            if ~isempty(s.attempts),checkAttempt(s.attempts{1},geometry,constraint,original{2});end
            clean=facts.Run_return_observed_before_outer_work&&facts.Run_actual_limits_within_original_work&&isequal(s.persistence_completion_confirmed,true)&&~facts.native_pending_present ...
                &&isempty(fieldnames(s.failure))&&~ismember(s.status,{'committed_data_but_storage_late','isolated_native_storage_late','native_all_nine_pending_after_clock','child_or_work_budget_exhausted'});
            facts.status='clean_return_no_owned_commit';
            if facts.native_pending_present,facts.status='native_pending_requires_reconciliation';
            elseif ~facts.Run_return_observed_before_outer_work||~facts.Run_actual_limits_within_original_work,facts.status='original_clock_requires_review';
            elseif clean
                if s.new_points==1,a=s.attempts{1};assert(a.all_nine&&a.timely&&a.edge_committed&&isequal(a.storage_timely,true),'C1PKAnchor:ActualCommit','Only the actual timely all9/captured/stored row earns local2->3.');end
                [facts.fork_records,facts.cheap_target_comparison,facts.fork_output_reference]=forkRead2(o.OutputFile,original,target,witness,policyReport,signature,finish,s.new_points,o.ComponentIdentity);
                facts.fork_native_read2_verified=true;facts.cloned_seed_native_ids_preserved=true;
                if s.new_points==1,facts.owned_fork_commit_verified=true;facts.status='finite_owned_fork_stored_comparison_only';end
            end
        end
        guard(finish);[facts.directory_changes,dirsClean]=outputChanges(beforeResults,beforeAudits,o,isolated);facts.file_observations=outputFiles(writes,finish);
        if ~dirsClean,facts.status='retained_stage_requires_reconciliation';clean=false;end
        facts.source_posthash=true;facts.completed=clean&&dirsClean;encoded=jsonencode(pilotView(facts));
        assert(numel(unicode2native(encoded,'UTF-8'))<=50000,'C1PKAnchor:SummaryBytes','The explicit bounded pilot view must fit50000UTF8.');
        fprintf('C1_PK_OWNED_ANCHOR_FORK_ACTUAL_RETURN %s\n',encoded);normalReturned=true;guard(finish);
    catch problem
        facts.completed=false;facts.failure=exceptionData(problem);facts.status='partial_or_refused';
        try,[facts.directory_changes,~]=outputChanges(beforeResults,beforeAudits,o,isolated);facts.file_observations=outputFiles(writes,finish);catch custody,facts.output_capture_failure=struct('identifier',custody.identifier,'message',custody.message);end
        p=forkPartial(facts,problem,normalReturned);p.schema='C1-owned-PK-P1-control-anchor-fork-partial-v1';p.target_original_column=o.TargetOriginalColumn;p.primary_anchor_index=o.PrimaryAnchorIndex;
        if isfield(facts,'pre_Run_header'),p.pre_Run_header_digest=C1ScientificDigest_v3(facts.pre_Run_header);end
        encoded=jsonencode(p);assert(numel(unicode2native(encoded,'UTF-8'))<=7000,'C1PKAnchor:PartialBytes','Bound partial output to7000UTF8.');fprintf('C1_PK_OWNED_ANCHOR_FORK_PARTIAL %s\n',encoded);rethrow(problem)
    end
    function a=observedTwice(file,key,label,limit)
        check(limit);fprintf('C1_PK_ANCHOR_BEFORE_TARGET1 %s\n',label);x=load(file,'-mat',key);facts.target_audit_loads_returned=facts.target_audit_loads_returned+1;fprintf('C1_PK_ANCHOR_AFTER_TARGET1_RETURN %s\n',label);check(limit);
        fprintf('C1_PK_ANCHOR_BEFORE_TARGET2 %s\n',label);y=load(file,'-mat',key);facts.target_audit_loads_returned=facts.target_audit_loads_returned+1;fprintf('C1_PK_ANCHOR_AFTER_TARGET2_RETURN %s\n',label);check(limit);
        assert(isequaln(x.(key),y.(key)),'C1PKAnchor:TargetRead2','Whole actual direct audit values differ.');a=x.(key);
    end
    function emitTargetHeader(h)
        facts.target_intake_headers{end+1,1}=h;encodedHeader=jsonencode(h);assert(numel(unicode2native(encodedHeader,'UTF-8'))<=1000,'C1PKAnchor:TargetHeaderBytes','Each actual target header remains bounded.');fprintf('C1_PK_ANCHOR_TARGET_HEADER %s\n',encodedHeader);
    end
    function guard(limit)
        check(limit);quiet(ledger,raw,roundFile);verify(refs);verifyCode(code);if isfield(facts,'fork_output_reference'),verify({facts.fork_output_reference});end
        assert(isequaln(C1RunBudget_v3(),budget),'C1PKAnchor:Budget','The original grant VALUE/clocks remain unchanged.');check(limit);
    end
end

function [nodes,pairs,edges]=incomingChain(ix,anchor)
    assert(anchor<=numel(ix.points),'C1PKAnchor:AnchorBounds','The declared anchor must exist.');nodes=anchor;edges=cell(0,1);owner=ix.points{anchor}.component_identity;
    for hop=1:2
        hit=find(cellfun(@(e)e.to==nodes(1),ix.edges));if isempty(hit),break;end
        assert(isscalar(hit),'C1PKAnchor:Incoming','An owned occurrence must have a unique incoming physical edge.');e=ix.edges{hit};
        assert(e.from<e.to&&strcmp(e.component_identity,owner)&&strcmp(ix.points{e.from}.component_identity,owner) ...
            &&strcmp(ix.points{e.to}.component_identity,owner),'C1PKAnchor:ChainOwner','Preserve actual direction and same literal owner.');
        nodes=[e.from;nodes(:)];edges=[{e};edges]; %#ok<AGROW>
    end
    nodes=nodes(:);pairs=zeros(max(0,numel(nodes)-1),2);
    for k=1:size(pairs,1),pairs(k,:)=[nodes(k),nodes(k+1)];end
end

function g=nativeGeometry(a,b,ra,rb,t,witness,policyReport,pair,limit)
    g=struct('source_pair',pair,'source_native_ids',{{OrbitContentIdentity_v3(a);OrbitContentIdentity_v3(b)}}, ...
        'eligible',false,'eligibility_reason','unassessed','geometry_failure',struct(),'sigma',NaN,'chord_distance',NaN, ...
        'base_roundtrip_exact',false,'target_roundtrip_exact',false,'predicted_full13_separation',NaN, ...
        'predicted_coordinate_separation',NaN,'target_base_full13_scaled_inf',NaN,'map_evaluate_calls',0,'target_used_as_seed',false);
    try
        match=MatchingReturnSection_v3(a,b,{ra,rb});g.source_pair_matching_section=match;
        if ~match.compatible||~isequaln(a.parameter,b.parameter),g.eligibility_reason='source_pair_policy_section_or_parameter_incompatible';return;end
        [policy,evidence]=RecordedReturnPolicy_v3(rb);assert(evidence.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3'),'C1PKAnchor:Policy','Use the actual complete admitted base policy.');
        targetMatch=MatchingReturnSection_v3(b,witness,{rb,policyReport});g.base_target_matching_section=targetMatch;
        g.target_exact_p_q=isequaln(b.parameter,t.parameter)&&isequaln(b.initial_mode,t.mode);
        g.target_exact_complete_policy=evidence.complete&&isequaln(evidence.configuration,t.policy_configuration);
        if ~targetMatch.compatible||~g.target_exact_p_q||~g.target_exact_complete_policy
            g.eligibility_reason='base_target_policy_mode_parameter_or_markedsection_incompatible';return
        end
        s=QuadrupedSchema_v3.shared();integration=struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001,'ODEOptions',odeset('OutputFcn',@(~,~,~)geometryClock(limit)));
        map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(integration),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));
        f=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,b.initial_state),b.initial_state,b.initial_mode,b.parameter,struct('Symmetry','pronk'));
        ua=f.packState(a.initial_state);ub=f.packState(b.initial_state);ut=f.packState(t.state);scale=max([ones(numel(ub),1),abs(ua),abs(ub)],[],2);
        delta=(ub-ua)./scale;distance=norm(delta);g.chord_distance=distance;
        g.coordinate_indices=f.CoordinateIndices;g.closure_indices=f.ClosureIndices;g.energy_pivot=f.EnergyPivot;g.ua=ua;g.ub=ub;g.target_coordinates=ut;g.scale=scale;
        g.base_roundtrip_exact=isequal(f.fullState(ub),b.initial_state(:));
        g.source_A_lift_minus_raw=f.fullState(ua)-a.initial_state(:);xt=f.fullState(ut);g.target_lift_minus_raw=xt-t.state(:);g.target_roundtrip_exact=isequal(xt,t.state(:));
        g.target_base_full13_scaled_inf=norm((t.state(2:14)-b.initial_state(2:14))./max([ones(13,1),abs(t.state(2:14)),abs(b.initial_state(2:14))],[],2),Inf);
        if ~(isfinite(distance)&&distance>1e-10),g.eligibility_reason='unresolved_actual_source_chord';return;end
        tangent=delta/distance;sigma=dot(tangent,(ut-ub)./scale);g.tangent=tangent;g.sigma=sigma;
        if ~(isa(sigma,'double')&&isreal(sigma)&&isscalar(sigma)&&isfinite(sigma)),g.eligibility_reason='nonfinite_signed_native_projection';return;end
        up=ub+scale.*(sigma*tangent);xp=f.fullState(up);E=QuadrupedEnergy_v3.evaluate(b.initial_state,b.initial_mode,b.parameter);
        g.constraint=struct('reference',[ub;E],'normal',[tangent./scale;0],'target',sigma);g.base_energy=E;
        g.capture_predictor_state=xp;g.base_root_start=b.initial_state(:);g.base_initial_coordinates=[ub;E];
        g.predicted_full13_separation=norm((xp(2:14)-b.initial_state(2:14))./max(ones(13,1),abs(b.initial_state(2:14))),Inf);
        g.predicted_coordinate_separation=norm((up-ub)./scale,Inf);
        g.predicted_target_full13_scaled_inf=norm((xp(2:14)-t.state(2:14))./max([ones(13,1),abs(xp(2:14)),abs(t.state(2:14))],[],2),Inf);
        if ~g.base_roundtrip_exact,g.eligibility_reason='actual_admitted_base_does_not_roundtrip';
        elseif sigma<1e-7||sigma>.1,g.eligibility_reason='signed_progress_outside_literal_Run_bounds';
        elseif ~(isfinite(g.predicted_coordinate_separation)&&g.predicted_coordinate_separation>1e-8),g.eligibility_reason='predicted_coordinate_separation_not_above_capture_floor';
        else,g.eligible=true;g.eligibility_reason='declared_positive_native_geometry';end
        % A target lift mismatch is recorded and NEVER vetoes or repairs a target.
        g.scope='Constructor/pack/lift only; no map/Root search. Oldest pair first is declared order, not best-predictor selection. Target only defines the PAL plane; actual base is the Root seed.';
    catch problem
        g.eligible=false;g.eligibility_reason='native_geometry_refused';g.geometry_failure=failureHeader(problem);
    end
    check(limit);
end

function anchor=bindComparison(q,sp,o,raw,rawSHA,t)
    assert(strcmp(q.schema,'C1-owned-PK-existing-P1-controls-observation-v1')&&strcmp(q.source_sha256,'91e89ce7217ce8bbcc7e4d3211497145de7d6a16a3aee7b753eac9c65ad0dbc2') ...
        &&strcmp(q.projection_mode,'bounded_scientific_scalar_fallback')&&isequal(q.completed,true)&&isequal(q.source_posthash,true) ...
        &&isequal(q.target_native_read2_verified,true)&&isequal(q.index_read2_verified,true)&&isequal(q.selected_compact_read2_verified,true) ...
        &&q.target_audit_load_calls_returned==4&&q.index_calls_returned==4&&q.selected_load_calls_returned==4 ...
        &&q.root_calls==0&&q.map_evaluate_calls==0&&q.fine_calls==0&&isequal(q.own_process_exit_observed,false), ...
        'C1PKAnchor:Comparison','Use the actual complete0071 stored observation and literal fallback scope.');
    assert(strcmp(sp.source_reference.sha256,q.source_sha256)&&strcmp(canonical(sp.source_reference.file), ...
        canonical(fullfile('/private/tmp/c1_pk36h_20261031_candidates','PK36h_0071_P1ControlsBoundedOutput','ObserveC1PKOwnedP1Controls20261031.m'))), ...
        'C1PKAnchor:ComparisonSource','Actual Processspec binds the exact proper91e source, not a caller-only assumption.');
    guardRefs=asCells(sp.operative_guard_references);hit=find(cellfun(@(r)strcmp(canonical(r.file),raw),guardRefs));
    assert(isscalar(hit)&&strcmp(guardRefs{hit}.sha256,rawSHA),'C1PKAnchor:ComparisonRaw','Current primary must equal the unique reviewed0071 primary guard; old global j/Round locators are historical.');
    ts=asCells(q.targets);hit=find(cellfun(@(x)x.original_column==o.TargetOriginalColumn,ts));assert(isscalar(hit)&&strcmp(ts{hit}.native_id,t.native_id) ...
        &&isequal(ts{hit}.target_current_PK1_all9_evidence_complete,true),'C1PKAnchor:ComparisonTarget','Actual target column/ID/retained admission assessment must join fresh direct intake.');
    rows=asCells(q.primary.records);hit=find(cellfun(@(x)x.index==o.PrimaryAnchorIndex,rows));assert(isscalar(hit),'C1PKAnchor:ComparisonAnchor','The declared current anchor must be one actual0071 selected native record.');anchor=rows{hit};
    validSHA(anchor.owner_digest);assert(ischar(anchor.native_id)&&~isempty(regexp(anchor.native_id,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1PKAnchor:AnchorID','Keep actual source NativeID.');
    for side={'primary','fork'}
        s=q.(side{1});c=s.comparisons;shape=c.comparison_shape(:);assert(numel(shape)==2&&shape(2)==2,'C1PKAnchor:ComparisonShape','Use the declared selected-by-two-target layout.');
        columns=cellstr(string(c.flag_columns));ci=find(strcmp(columns,'conditions_met'));assert(isscalar(ci)&&isequal(size(c.flag_values),[prod(shape),numel(columns)]),'C1PKAnchor:ComparisonFlags','Retain actual packed predicate positions.');
        targetColumn=find([152;179]==o.TargetOriginalColumn);indices=(targetColumn-1)*shape(1)+(1:shape(1));
        assert(all(c.flag_values(indices,ci)==false),'C1PKAnchor:AlreadyCompared','Do not acquire a target already matched by an observed current record.');
    end
end

function [w,q,sp]=comparisonClosure(r,root,limit)
    check(limit);w=jsondecode(fileread(r.file));exactFields(w,{'schema','invocation_id','argv_utf8_sha256','exec_session_id','child_pid','actual_child_exit_code','actual_process_exit_observed','tool_prefix_reference','process_prefix_reference'});
    assert(strcmp(w.schema,'C1-ordinary-initializer-evidence-closure-v1')&&strcmp(w.invocation_id,'PK36h20261031-0071-direct-controls-owned-comparison-bounded-output') ...
        &&w.exec_session_id==14120&&w.child_pid==16297&&isequal(w.actual_child_exit_code,0)&&isequal(w.actual_process_exit_observed,true) ...
        &&strcmp(w.argv_utf8_sha256,'4415440eac9f5b317824a97ca2c1a15350d3b026aeca8777d8cab6af5cf422b0'),'C1PKAnchor:Closure','Bind the actual closed0071 process.');
    exactFields(w.tool_prefix_reference,{'file','prefix_bytes','prefix_sha256'});exactFields(w.process_prefix_reference,{'file','prefix_bytes','prefix_sha256'});
    assert(strcmp(w.tool_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Tool_Observations.jsonl'))&&w.tool_prefix_reference.prefix_bytes==1641348 ...
        &&strcmp(w.tool_prefix_reference.prefix_sha256,'18adac1a8203345779d34206d73f6c0506964437b2fe8c7a226d4530115d7c2d') ...
        &&strcmp(w.process_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Process_Observations.jsonl'))&&w.process_prefix_reference.prefix_bytes==2883647 ...
        &&strcmp(w.process_prefix_reference.prefix_sha256,'bf1c79181a1e1b14d35bf78d233faeda5c3aca284c0d3b8eb17cede92629a306'), ...
        'C1PKAnchor:Prefixes','Use exact immutable bounded0071 prefixes.');
    tool=prefixRows(w.tool_prefix_reference);process=prefixRows(w.process_prefix_reference);rows=tool(cellfun(@(x)isfield(x,'invocation_id')&&strcmp(x.invocation_id,w.invocation_id),tool));assert(numel(rows)==5,'C1PKAnchor:ToolRows','Require actual five ordered records.');
    terminal=0;starts={};exits={};summaries={};startPosition=[];summaryPosition=[];exitPosition=[];
    for k=1:5
        a=rows{k};assert(strcmp(a.schema,'C1-native-exec-tool-observation-v1')&&a.tool_record_ordinal==k,'C1PKAnchor:ToolOrder','Keep exact actual ordinals.');
        if k<5,assert(isfield(a,'session_id')&&a.session_id==w.exec_session_id,'C1PKAnchor:ToolSession','Every running envelope session must match.');else,assert(~isfield(a,'session_id'),'C1PKAnchor:TerminalAbsence','Actual terminal5 alone has no envelope session field.');end
        if isfield(a.record,'session_id'),assert(a.record.session_id==w.exec_session_id,'C1PKAnchor:RecordSession','Every present record session must match.');end
        if isfield(a.record,'exit_code'),assert(k==5&&a.record.exit_code==0,'C1PKAnchor:Terminal','Require sole actual terminal0.');terminal=terminal+1;end
        if isfield(a.record,'output')
            lines=strsplit(a.record.output,newline);
            for n=1:numel(lines)
                line=lines{n};
                if startsWith(line,'C1_NATIVE_PROCESS_STARTED '),starts{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_STARTED ')+1:end));startPosition=[k n];end
                if startsWith(line,'C1_NATIVE_PROCESS_EXIT '),exits{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_EXIT ')+1:end));exitPosition=[k n];end
                if startsWith(line,'C1_PK_P1_CONTROLS_OBSERVATION_ACTUAL_RETURN '),summaries{end+1}=jsondecode(line(numel('C1_PK_P1_CONTROLS_OBSERVATION_ACTUAL_RETURN ')+1:end));summaryPosition=[k n];end
            end
        end
    end
    selected=process(cellfun(@(x)isfield(x,'invocation_id')&&strcmp(x.invocation_id,w.invocation_id),process));spec={};observed={};dispatch={};
    for k=1:numel(selected),a=selected{k};if strcmp(a.schema,'C1-native-launch-specification-v1'),spec{end+1}=a;elseif strcmp(a.schema,'C1-native-process-observation-v1'),observed{end+1}=a;elseif strcmp(a.schema,'C1-native-reviewed-specification-dispatch-confirmation-v1'),dispatch{end+1}=a;end,end
    assert(terminal==1&&numel(starts)==1&&numel(exits)==1&&numel(summaries)==1&&isequal(startPosition,[1 1]) ...
        &&isequal(summaryPosition,[5 11])&&isequal(exitPosition,[5 15])&&summaryPosition(2)<exitPosition(2) ...
        &&numel(spec)==1&&numel(observed)==1&&numel(dispatch)==1,'C1PKAnchor:UniqueClosure','Join actual START1:1, SUMMARY5:11 before EXIT5:15, unique spec/dispatch/process.');
    a=starts{1};b=observed{1};sp=spec{1};di=dispatch{1};assert(strcmp(a.invocation_id,w.invocation_id)&&a.child_pid==w.child_pid&&strcmp(a.argv_utf8_sha256,w.argv_utf8_sha256) ...
        &&strcmp(b.invocation_id,w.invocation_id)&&b.child_pid==w.child_pid&&isequal(b.actual_child_exit_code,0)&&isequal(b.actual_process_exit_observed,true)&&strcmp(b.argv_utf8_sha256,w.argv_utf8_sha256) ...
        &&strcmp(sp.argv_utf8_sha256,w.argv_utf8_sha256)&&strcmp(di.argv_utf8_sha256,w.argv_utf8_sha256),'C1PKAnchor:ProcessJoin','Actual child/spec/dispatch share one argv.');
    assert(isequaln(exits{1},b)&&strcmp(sp.expected_execution_tool_options.sandbox_permissions,'require_escalated')&&isequaln(rows{1}.actual_execution_tool_options,sp.expected_execution_tool_options) ...
        &&isequaln(di.expected_execution_tool_options,sp.expected_execution_tool_options)&&isequaln(b.expected_execution_tool_options,sp.expected_execution_tool_options),'C1PKAnchor:Profile','Keep the actual reviewed execution profile.');q=summaries{1};check(limit);
end

function h=preRunHeader(f)
    h=struct('target_original_column',f.target_original_column,'primary_anchor_index',f.primary_anchor_index,'target_native_id',f.target.native_id, ...
        'source_chain_indices',f.source_chain_indices,'source_chain_native_ids',{cellfun(@(x)x.native_id,f.source_chain_headers,'UniformOutput',false)}, ...
        'candidate_source_pairs',f.candidate_source_pairs,'candidate_geometry',{cell(size(f.candidate_geometry))}, ...
        'selected_candidate_ordinal',f.selected_candidate_ordinal,'selected_source_pair',f.source_pair,'target_used_as_seed',false,'map_evaluate_calls',0);
    for k=1:numel(f.candidate_geometry)
        g=f.candidate_geometry{k};r=pickPresent(g,{'source_pair','source_native_ids','eligible','eligibility_reason','sigma','chord_distance','base_roundtrip_exact', ...
            'target_roundtrip_exact','target_exact_p_q','target_exact_complete_policy','predicted_full13_separation','predicted_coordinate_separation','target_base_full13_scaled_inf','predicted_target_full13_scaled_inf'});
        if isfield(g,'base_target_matching_section'),r.base_target_section_compatible=g.base_target_matching_section.compatible;end
        r.full_geometry_digest=C1ScientificDigest_v3(g);h.candidate_geometry{k}=r;
    end
    h.scope='All values are actual native constructor/pack/lift observations. First eligible pair in declared oldest-first order, never a Root search/reversal/abs/clip/upsize; target lift mismatch alone is not a veto.';
end

function v=pilotView(f)
    v=pickPresent(f,{'schema','source_reference','wrapper_seconds','outer_post_reserve_seconds','Run_save_margin_seconds','original_trial_seconds', ...
        'target_original_column','primary_anchor_index','source_pair','source_pair_read2_verified','source_index_read2_verified','source_index_calls_returned', ...
        'source_selected_loads_returned','target_audit_loads_returned','target_native_read2_verified','comparison_closed_verified','pre_Run_header', ...
        'selected_candidate_ordinal','output_file','checkpoint_file','component_identity','global_isolated_file','Run_calls_attempted','Run_calls_returned', ...
        'Run_return_observed_before_outer_work','Run_actual_limits_within_original_work','actual_attempt_rows','native_pending_present', ...
        'owned_fork_commit_verified','fork_native_read2_verified','cloned_seed_native_ids_preserved','file_observations','directory_changes','source_posthash','completed','status', ...
        'journal_mutated','round_mutated','primary_raw_mutated','central_frontier_reset','primary_canonical_edge_registered','target_used_as_seed', ...
        'target_projection_as_admission','fresh_fines_performed','all_four_target_cohorts_claimed','P1_original_state_admission_claimed', ...
        'scheduled_v2_trajectory_equivalence_claimed','physical_attachment_claimed','endpoint_claimed','global_completion_claimed','own_process_exit_observed', ...
        'derived_inner_cap_from_original_work','handoff_margin_seconds','fork_output_reference'});
    v.full_in_memory_facts_digest=C1ScientificDigest_v3(f);v.full_facts_durably_retained_claimed=false;
    v.target=f.target;v.target.section_chart=chartHeader(f.target.section_chart);v.source_chain_headers=cell(size(f.source_chain_headers));
    for k=1:numel(f.source_chain_headers),v.source_chain_headers{k}=recordHeader(f.source_chain_headers{k});end
    v.candidate_geometry=f.candidate_geometry;
    for k=1:numel(v.candidate_geometry)
        g=v.candidate_geometry{k};if isfield(g,'source_pair_matching_section'),m=g.source_pair_matching_section;g.source_pair_matching_section=sectionHeader(m);end
        if isfield(g,'base_target_matching_section'),g.base_target_matching_section=sectionHeader(g.base_target_matching_section);end
        if isfield(g,'scope'),g=rmfield(g,'scope');end;v.candidate_geometry{k}=g;
    end
    if isfield(f,'fork_records'),v.fork_records=cell(size(f.fork_records));for k=1:numel(f.fork_records),v.fork_records{k}=recordHeader(f.fork_records{k});end,end
    if ~isempty(fieldnames(f.cheap_target_comparison))
        c=f.cheap_target_comparison;c.matching_section=sectionHeader(c.matching_section);c=rmfield(c,'scope');v.cheap_target_comparison=c;
    else,v.cheap_target_comparison=struct();end
    v.Run_observation=pickPresent(f.Run_observation,{'protocol','new_points','new_edges','initial_output_count','final_output_count','status','persistence_completion_confirmed', ...
        'derivative_method','corrector_initializer','run_limit','work_limit','current_pair','next_step','next_derivative_index','apex_height_policy', ...
        'failure_header','pending_admission_present','pending_stage','attempts'});
    v.Run_options=f.Run_options;v.historical_qualification_digest=C1ScientificDigest_v3(f.historical_qualification);
    v.administrative_tuple_digest=C1ScientificDigest_v3(struct('budget',f.budget,'refs',{f.expected_current_references},'code',{f.actual_method_references},'closure',f.actual_comparison_closure));
    v.scope='One bounded owned-anchor fork observation. Complete administrative tuples, chart detail and full matching-section evidence are explicit typed-digest omissions; full facts are memory/return-only. No primary edge/ownership registration, fresh fine qualification, P1 original-state admission, attachment or completion claim.';
    function h=recordHeader(r)
        h=r;h.saved_full_closure_digest=C1ScientificDigest_v3(r.saved_full_closure);h=rmfield(h,{'saved_full_closure','metadata_binding'});h.section_chart=chartHeader(r.section_chart);
    end
    function h=chartHeader(c)
        h=pick(c,{'id','geometry','crossing_orientation','boundary_ownership','translational_gauge'});if isfield(c,'BL_touchdowns_per_return'),h.BL_touchdowns_per_return=c.BL_touchdowns_per_return;end
        h.omitted_full_chart_digest=C1ScientificDigest_v3(c);
    end
    function h=sectionHeader(m)
        h=pick(m,{'compatible','actual_policy_configuration_checked','policy_configuration_matches_declared_identity','rephase_or_chart_transition_inferred'});h.full_evidence_digest=C1ScientificDigest_v3(m);
    end
end

function x=geometryClock(limit),check(limit);x=0;end

function checkAttempt(a,g,constraint,base)
    assert(a.attempt==1&&a.source_point==2&&isequal(a.step,g.sigma)&&strcmp(a.derivative_method,'valid-sided')&&a.relative_step==1e-8&&strcmp(a.algorithm,'root-newton') ...
        &&isequaln(a.constraint,constraint)&&isequaln(a.predictor_state,g.capture_predictor_state),'C1PKFork:ActualPlane','Actual first Run row must use the declared plane, not a shrunk/fallback trial.');
    ci=a.corrector_initialization;assert(strcmp(ci.method,'base')&&isequaln(ci.start_state,base.state)&&isequaln(ci.start_coordinates,g.base_initial_coordinates)&&isequal(ci.base_roundtrip_exact,true) ...
        &&isequaln(ci.capture_predictor_state,g.capture_predictor_state)&&isequal(a.previous_jacobian_reuse.requested,false),'C1PKFork:ActualBase','Actual Root start remains the selected admitted base with no cross-point Jacobian reuse.');
end

function h=runHeader(s)
    h=pickPresent(s,{'protocol','output_file','configuration','new_points','new_edges','initial_output_count','final_output_count','status','persistence_completion_confirmed','derivative_method', ...
        'integration_profile','corrector_initializer','run_limit','work_limit','current_pair','next_step','next_derivative_index','apex_height_policy','completed_utc'});
    h.failure_header=storedFailureHeader(s.failure);h.pending_admission_present=~isempty(fieldnames(s.pending_admission));h.pending_stage=member(s.pending_admission,'stage','');h.isolated_native_admissions=s.isolated_native_admissions;
    h.attempts=cell(size(s.attempts));for k=1:numel(s.attempts),h.attempts{k}=pickPresent(s.attempts{k},{'attempt','source_point','step','derivative_method','relative_step','algorithm','status','all_nine','timely','capture', ...
            'edge_committed','storage_attempted','storage_timely','isolated_committed','isolated_storage_timely','corrector_initialization','apex_height_policy'});end
    h.checkpoint_fact_scope='Actual returned persistence flag remains literal; saved checkpoint intentionally retains provisional false. Full failure/native-pending payload remains in Run checkpoint, not duplicated here.';
end

function h=storedFailureHeader(e)
    h=struct();if isempty(fieldnames(e)),return;end
    id=member(e,'identifier','');msg=member(e,'message','');h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'message_prefix',msg(1:min(numel(msg),256)),'message_char_count',numel(msg), ...
        'stack_frame_count',numel(member(e,'stack',[])),'full_failure_preserved_in_Run_checkpoint',true);
end

function out=pickPresent(s,keys),out=struct();for k=1:numel(keys),if isfield(s,keys{k}),out.(keys{k})=s.(keys{k});end,end,end

function rows=prefixRows(r)
    validSHA(r.prefix_sha256);assert(ischar(r.file)&&isrow(r.file)&&isa(r.prefix_bytes,'double')&&isscalar(r.prefix_bytes)&&isfinite(r.prefix_bytes)&&r.prefix_bytes>0&&r.prefix_bytes<=16*1024*1024&&r.prefix_bytes==fix(r.prefix_bytes),'C1PKFork:Prefix','Require an exact bounded prefix.');
    f=fopen(r.file,'rb');assert(f>=0,'C1PKFork:PrefixOpen','Cannot read prefix.');closer=onCleanup(@()fclose(f));b=fread(f,r.prefix_bytes,'*uint8');assert(numel(b)==r.prefix_bytes&&b(end)==10,'C1PKFork:PrefixLength','Exact prefix must end atLF.');clear closer
    d=java.security.MessageDigest.getInstance('SHA-256');d.update(b);h=lower(reshape(dec2hex(typecast(d.digest(),'uint8'),2).',1,[]));assert(strcmp(h,r.prefix_sha256),'C1PKFork:PrefixSHA','Immutable prefix changed.');
    lines=strsplit(native2unicode(b.','UTF-8'),newline);lines(end)=[];rows=cellfun(@jsondecode,lines,'UniformOutput',false);
end

function c=asCells(x),if iscell(x),c=x(:);elseif isstruct(x),c=num2cell(x(:));else,error('C1PKFork:Cells','Require actual JSON object-array rows.');end,end

function code=forkCode(self,protected)
    names={'C1RunBudget_v3','RunC1Continuation_v3','BranchSolutionFile_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3','OrbitContentIdentity_v3','HybridOrbit_v3','Trajectory_v3','C1ScientificDigest_v3','RoundSHA256_v3', ...
        'QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3','QuadrupedAdmissibility_v3','ContinuousDynamics_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3','PoincareMap_v3','PoincareSection_v3','HybridSimulator_v3', ...
        'Quadrupedal_Dynamics_v3','PeriodicOrbitResidual_v3','EnergyFamilyResidual_v3','ConstrainedEnergyResidual_v3','PeriodicSolutionSolver_v3','RootSolver_v3','ValidSidedFiniteDifferenceJacobian_v3','FiniteDifferenceJacobian_v3', ...
        'GuardFunctions_v3','EventDetector_v3','ResetMap_v3','ModeTransition_v3','PrimitiveCycleCheck_v3','HybridCycleData_v3','GaitIdentification_v3','CompactResearchBranch_v3','SectionModeResolver_v3','HybridSystemBase_v3'};
    code={self};for k=1:numel(names),r=reference(which(names{k}));assert(any(cellfun(@(x)strcmp(x.file,r.file)&&strcmp(x.sha256,r.sha256),protected)),'C1PKFork:CallerMethodPin','Every current method resolver/hash must be caller-protected.');code{end+1,1}=r;
        if strcmp(names{k},'RunC1Continuation_v3'),assert(strcmp(r.sha256,'09e1b6813f4bdc1ca1115138d60d504bdb2758a8cb7e530f80c38987591b5bf1'),'C1PKFork:RunPin','Keep reviewed Run09 unchanged.');end
    end
end

function freshPaths(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKFork:Fresh','Preserve any existing output/pending path and refuse.');end,end

function names=directoryNames(folder),d=dir(folder);d=d(~ismember({d.name},{'.','..'}));names=sort({d.name}.');end

function [out,clean]=outputChanges(beforeResults,beforeAudits,o,isolated)
    r=directoryNames(fileparts(o.OutputFile));a=directoryNames(fileparts(o.CheckpointFile));[~,of,oe]=fileparts(o.OutputFile);[~,cf,ce]=fileparts(o.CheckpointFile);[~,nf,ne]=fileparts(isolated);
    addedR=setdiff(r,beforeResults);addedA=setdiff(a,beforeAudits);removedR=setdiff(beforeResults,r);removedA=setdiff(beforeAudits,a);unknownR=setdiff(addedR,{[of oe];[nf ne]});unknownA=setdiff(addedA,{[cf ce]});
    out=struct('added_Results',{addedR},'added_Audits',{addedA},'removed_Results',{removedR},'removed_Audits',{removedA},'retained_unresolved_Results',{unknownR},'retained_unresolved_Audits',{unknownA},'no_wrapper_delete_or_rollback',true);
    clean=isempty(unknownR)&&isempty(unknownA)&&isempty(removedR)&&isempty(removedA)&&~isfile([o.CheckpointFile,'.pending.mat']);
end

function out=outputFiles(paths,limit)
    out=cell(numel(paths),1);for k=1:numel(paths),p=paths{k};d=dir(p);a=struct('file',p,'present',isfile(p),'directory',isfolder(p),'bytes',[],'sha256','','hash_observed',false);if ~isempty(d)&&isscalar(d),a.bytes=d.bytes;end;if a.present&&left(limit)>0,a.sha256=RoundSHA256_v3(p);a.hash_observed=true;end;out{k}=a;end
end

function p=forkPartial(f,e,normalReturned)
    p=struct('schema','C1-owned-PK-NEWcol1-single-fork-partial-v1','completed',false,'normal_summary_call_returned',normalReturned,'own_process_exit_observed',false, ...
        'source_sha256',f.source_reference.sha256,'source_selected_loads_returned',f.source_selected_loads_returned,'target_audit_loads_returned',f.target_audit_loads_returned, ...
        'Run_calls_attempted',f.Run_calls_attempted,'Run_calls_returned',f.Run_calls_returned,'Run_return_observed_before_outer_work',f.Run_return_observed_before_outer_work, ...
        'Run_actual_limits_within_original_work',f.Run_actual_limits_within_original_work,'actual_attempt_rows',f.actual_attempt_rows,'native_pending_present',f.native_pending_present, ...
        'owned_fork_commit_verified',f.owned_fork_commit_verified,'source_posthash',f.source_posthash,'output_file',f.output_file,'checkpoint_file',f.checkpoint_file,'global_isolated_file',f.global_isolated_file, ...
        'failure_header',failureHeader(e),'full_facts_omitted',true,'scope','Actual outputs/pending/stages remain. Full native failure/pending is owned by existing Run checkpoint; no rollback or dense duplication is claimed.');
    p.Run_status=member(f.Run_observation,'status','');
end


function refs=references(refs)
    assert(iscell(refs)&&size(refs,2)==1,'C1PKCol1:ReferenceCells','Supply a column cell of explicit current protected references.');
    for k=1:numel(refs),refs{k}=checked(refs{k});end
end


function syntaxReferences(refs)
    assert(iscell(refs)&&isvector(refs),'C1PKCol1:HistoricalRefs','Retain literal reference cell shape without rehashing historical source paths.');
    for k=1:numel(refs),r=refs{k};exactFields(r,{'file','sha256'});assert(ischar(r.file)&&isrow(r.file)&&java.io.File(r.file).isAbsolute(),'C1PKCol1:ReferencePath','Require an absolute historical source path.');validSHA(r.sha256);end
end


function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end


function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end


function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1P1Fixed:Resolver','Current source resolution differs from its guard.');end,end


function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1P1Fixed:Changed','A bound file changed.');end,end


function r=reference(f),assert(isfile(f),'C1P1Fixed:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end


function out=exceptionData(e),causes=cell(size(e.cause));for k=1:numel(causes),causes{k}=exceptionData(e.cause{k});end;out=struct('identifier',e.identifier,'message',e.message,'stack',e.stack,'causes',{causes});end


function value=member(s,k,f),value=f;if isstruct(s)&&isscalar(s)&&isfield(s,k),value=s.(k);end,end


function x=clockPair(),x=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end


function x=shift(x,s),x.utc=x.utc+s;x.mono=x.mono+s*1e9;end


function x=left(l),x=min(l.utc-posixtime(datetime('now','TimeZone','UTC')),(l.mono-double(java.lang.System.nanoTime))/1e9);end


function check(l),assert(left(l)>0,'C1P1Fixed:Clock','The original local/science whole-call clock expired.');end


function x=canonical(x),x=char(java.io.File(char(x)).getCanonicalPath());end


function x=formatUTC(s),x=char(datetime(s,'ConvertFrom','posixtime','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end


function x=stamp(),x=formatUTC(posixtime(datetime('now','TimeZone','UTC')));end


function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end


function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end


function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end


function quiet(ledger,raw,roundFile)
    cp=[ledger(1:end-4),'_active_checkpoint.mat'];paths={cp,[cp,'.pending.mat'],[ledger,'.pending.mat'],[roundFile,'.pending.mat'],[roundFile(1:end-4),'.pending.mat'],[roundFile(1:end-4),'.json.pending.json']};
    for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1:Pending','Reconcile existing owned checkpoint/stage before this stored-only observation.');end
    d=dir(fileparts(raw));d=d(~ismember({d.name},{'.','..'}));[~,n,e]=fileparts(raw);
    assert(numel(d)==1&&~d.isdir&&strcmp(d.name,[n e]),'C1PKCol1:RawDirectory','The primary raw directory must retain exactly its one current file, with no unknown stage.');
end


function h=failureHeader(e)
    id=e.identifier;message=e.message;stack=e.stack;
    h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'identifier_truncated',numel(id)>128, ...
        'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256, ...
        'stack_frame_count',numel(stack),'first_stack_frame',struct(),'stack_detail_omitted',numel(stack)>1,'cause_count',numel(e.cause));
    if ~isempty(stack)
        a=stack(1);h.first_stack_frame=struct('file_prefix',a.file(1:min(numel(a.file),128)),'file_char_count',numel(a.file),'file_truncated',numel(a.file)>128, ...
            'name_prefix',a.name(1:min(numel(a.name),96)),'name_char_count',numel(a.name),'name_truncated',numel(a.name)>96,'line',a.line);
    end
end


function [targets,points,h]=storedControls(o,limit,read2,emitHeader)
    saved=read2(o.Saved179Reference.file,'audit','Saved1791fd2',limit);
    remaining=read2(o.RemainingReference.file,'audit','Remainingda6',limit);
    emitHeader(directHeader(saved,179));emitHeader(directHeader(remaining,152));
    assert(isstruct(saved)&&isscalar(saved)&&isequal(saved.completed,true)&&isequal(saved.source_posthash,true) ...
        &&isequal(saved.qualified_saved_control,true)&&isequal(saved.finite_original_column_conditions_met,true) ...
        &&isequal(saved.original.original_column,179),'C1PKControls:Saved179','Retain actual direct saved179 qualification, not a NEW7271 target.');
    assert(isstruct(remaining)&&isscalar(remaining)&&iscell(remaining.rows)&&isequal(remaining.completed,false)&&isequal(remaining.source_posthash,false), ...
        'C1PKControls:Remaining','Retain literal global-false Remaining audit and qualified local row separately.');
    hit=find(cellfun(@(r)isstruct(r)&&isscalar(r)&&isfield(r,'original')&&isfield(r.original,'original_column')&&isequal(r.original.original_column,152),remaining.rows));
    assert(isscalar(hit),'C1PKControls:OriginalColumn','Require one actual Remaining row whose recorded original_column is152.');
    row=remaining.rows{hit};
    assert(isequal(row.qualified_new_control,true)&&isequal(row.finite_original_column_conditions_met,true)&&isequal(row.native_all_nine,true) ...
        &&isequal(row.initial_anchor_control.passed,true),'C1PKControls:Local152','Retain literal NEW152 all9/local qualification/anchor evidence.');
    assert(isequal(saved.initial_anchor_control.passed,true),'C1PKControls:Anchor179','Retain original saved179 anchor evidence.');
    rootBack=saved.fresh_saved_root_readback;
    assert(isequal(rootBack.completed,true)&&isequal(rootBack.timely,true)&&isequal(rootBack.native_public_passes,2) ...
        &&strcmp(canonical(rootBack.reference.file),o.RemainingRawReference.file)&&strcmp(rootBack.reference.sha256,o.RemainingRawReference.sha256) ...
        &&strcmp(rootBack.variable,'raw_P1col179_PSS') ...
        &&strcmp(canonical(saved.raw_reference.file),o.Saved179RawReference.file)&&strcmp(saved.raw_reference.sha256,o.Saved179RawReference.sha256), ...
        'C1PKControls:SavedReadback','Bind actual saved179 public read2 and its PSS raw locator, distinct from own fine raw current reference.');
    points={row.new_point;saved.saved_native_point};wrappers={row.fines;saved.fines};columns=[152;179];
    ids={'native-orbit-record:sha256:9e8b7f51693bb143668212aa3a607df2b083ac6932485060b45d4e8e1ff7f69d'; ...
        'native-orbit-record:sha256:57f2c08d6a1f3703c6653acff3bacc00fd57fba0836510edcef46e6e715ea5d9'};
    targets=cell(2,1);headers=cell(2,1);principal=[10;10;20;20;1;1;0;0;2;.5];
    gateNames={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    sectionKeys={'id','geometry','crossing_orientation','boundary_ownership','translational_gauge'};
    for k=1:2
        p=points{k};assert(strcmp(p.native_id,ids{k}),'C1PKControls:DirectNativeID','Keep the exact actually observed full control NativeID.');
        assert(isstruct(p.acceptance_gates)&&isscalar(p.acceptance_gates)&&isstruct(p.classification)&&isscalar(p.classification), ...
            'C1PKControls:PointEvidenceShape','Present saved point evidence must retain scalar-struct shape.');
        gateSeen=false(size(gateNames));gateHeader=struct();
        for j=1:numel(gateNames)
            key=gateNames{j};gateSeen(j)=isfield(p.acceptance_gates,key);
            if gateSeen(j),assert(isequal(p.acceptance_gates.(key),true),'C1PKControls:AvailablePointGate','Every PROVIDED original point gate must be literaltrue.');gateHeader.(key)=p.acceptance_gates.(key);end
        end
        g=p.classification;classKeys={'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'};
        expected={'quadruped-gait-v3.5','PK',true,true,1};classSeen=false(size(classKeys));classHeader=struct();
        for j=1:numel(classKeys)
            key=classKeys{j};classSeen(j)=isfield(g,key);
            if classSeen(j)
                actual=g.(key);if j<=2,valid=strcmp(actual,expected{j});else,valid=isequal(actual,expected{j});end
                assert(valid,'C1PKControls:AvailablePointClassification','Every PROVIDED current-target classification field must match its declared PK1 contract.');
                classHeader.(key)=actual;
            end
        end
        assert(isequaln(p.parameter(:),principal),'C1PKControls:PointParameter','The direct controls retain the unchanged principal physical parameter.');
        fines=wrappers{k};assert(iscell(fines)&&numel(fines)==2,'C1PKControls:FineCount','Retain exactly two historical original-state fine wrappers.');
        configuration=[];seedBound=false(2,1);fineHeaders=cell(2,1);
        for level=1:2
            f=fines{level};
            assert(isequal(f.passed,true)&&isequal(f.initial_trajectory_row_exact,true)&&isequal(f.observation.returned,true)&&isequal(f.observation.return_timely,true) ...
                &&isequal(f.raw_custody.storage_timely,true)&&isequal(f.raw_custody.readback_timely,true) ...
                &&f.saved_period_scaled_error<=1e-8&&f.saved_stride_scaled_error<=1e-8, ...
                'C1PKControls:HistoricalFine','Keep actual historical pass/initialrow/return/storage/readback/period/stride gates.');
            m=f.matching_saved_section;
            assert(isequal(m.compatible,true)&&isequal(m.actual_policy_configuration_checked,true)&&isequal(m.policy_configuration_matches_declared_identity,true) ...
                &&isequal(m.rephase_or_chart_transition_inferred,false),'C1PKControls:FineSection','Use only the actual saved complete matching-section contract.');
            assert(isequal(m.left_policy_evidence.complete,true)&&isequal(m.right_policy_evidence.complete,true) ...
                &&isequaln(m.left_policy_configuration,m.right_policy_configuration) ...
                &&isequaln(m.left_policy_evidence.configuration,m.left_policy_configuration)&&isequaln(m.right_policy_evidence.configuration,m.right_policy_configuration), ...
                'C1PKControls:FinePolicy','Both actual fine sides must expose complete identical policy settings/evidence.');
            c=m.left_policy_configuration;
            if isempty(configuration),configuration=c;else,assert(isequaln(c,configuration),'C1PKControls:FinePolicyLevels','Both original levels must retain the SAME complete policy.');end
            for side={'left_identity','right_identity'}
                ident=m.(side{1});
                assert(isequaln(ident.initial_mode,logical(p.mode(:)))&&isequaln(ident.section,pick(p.section_chart,sectionKeys))&&ident.return_occurrence==1, ...
                    'C1PKControls:FinePointSection','Actual fine semantic section/mode/occurrence must bind the saved control point.');
            end
            inner=member(f,'fine',struct());innerAvailable=isstruct(inner)&&isscalar(inner);
            if innerAvailable&&isfield(inner,'initial_state')
                assert(isequaln(inner.initial_state,p.initial_state),'C1PKControls:FineInitialState','Every available original fine initial state must exactly equal its retained control point.');seedBound(level)=true;
            end
            if innerAvailable&&isfield(inner,'actual_policy_configuration'),assert(isequaln(inner.actual_policy_configuration,configuration),'C1PKControls:FineNumericPolicy','Available actual fine policy must equal its matching-section evidence.');end
            if innerAvailable&&isfield(inner,'event_signature'),assert(strcmp(string(inner.event_signature),string(p.section_event_signature)),'C1PKControls:FineEvent','Available actual fine token must match the saved point.');end
            fineHeaders{level}=struct('passed',f.passed,'returned',f.observation.returned,'return_timely',f.observation.return_timely, ...
                'initial_row_exact',f.initial_trajectory_row_exact,'raw_storage_timely',f.raw_custody.storage_timely,'raw_readback_timely',f.raw_custody.readback_timely, ...
                'saved_period_scaled_error',f.saved_period_scaled_error,'saved_stride_scaled_error',f.saved_stride_scaled_error, ...
                'fine_payload_scalar_struct_available',innerAvailable,'fine_initial_state_available_and_exact',seedBound(level),'raw_custody_reference_historical',f.raw_custody.reference, ...
                'historical_raw_reference_rehashed',false);
        end
        assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isequal(configuration.settings.BLTouchdownsPerReturn,1)&&isequal(configuration.settings.RequireModeClosure,true), ...
            'C1PKControls:PolicyClass','Use the recorded actual BL1/mode-closed policy, never guessed defaults or callbacks.');
        v=struct('initial_state',p.initial_state,'initial_mode',p.mode,'parameter',p.parameter,'period',p.period, ...
            'stride_displacement',p.full_stride,'return_policy_name',configuration.settings.Name);
        orbit=HybridOrbit_v3(v);assert(strcmp(OrbitContentIdentity_v3(orbit),p.native_id),'C1PKControls:DirectIDRoundtrip','The actual identity method must reproduce each saved control ID from literal identity-bearing values.');clear orbit v
        role='qualified-new-original-column152-control';if k==2,role='qualified-saved-original-column179-control';end
        targets{k}=struct('native_id',p.native_id,'role',role,'state',p.initial_state,'mode',p.mode,'parameter',p.parameter, ...
            'period',p.period,'full_stride',p.full_stride,'native_energy',p.native_energy,'policy_configuration',configuration, ...
            'current_PK1_all9_evidence_complete',all(classSeen)&&all(gateSeen));
        headers{k}=struct('original_column',columns(k),'native_id',p.native_id,'source_disposition',role,'classification',classHeader, ...
            'original_acceptance_gates',gateHeader,'target_current_PK1_all9_evidence_complete',all(classSeen)&&all(gateSeen), ...
            'missing_classification_keys_UNASSESSED',{classKeys(~classSeen)},'missing_acceptance_gate_keys_UNASSESSED',{gateNames(~gateSeen)},'fine_observations',{fineHeaders},'fine_initial_state_unavailable_is_UNASSESSED',true, ...
            'historical_process_exit_revalidated',false,'all_four_cohorts_assessed',false,'original_legacy_state_admission_claimed',false);
    end
    sourceHeaders=cell(2,1);audits={remaining;saved};
    for k=1:2
        a=audits{k};v=member(a,'source_code',[]);d='';failure='';
        try,d=C1ScientificDigest_v3(v);catch problem,failure=problem.identifier;end
        sourceHeaders{k}=struct('original_column',columns(k),'class',class(v),'count',numel(v),'digest',d,'digest_failure_identifier',failure, ...
            'field_present',isfield(a,'source_code'),'syntax_assessed',false,'currentness_claimed',false);
    end
    h=struct('direct_source_scope','No7271/common210a target join. Exact Saved179/Remaining local native evidence is used.', ...
        'saved179_parent_completed',saved.completed,'saved179_parent_source_posthash',saved.source_posthash, ...
        'saved179_qualified_saved_control',saved.qualified_saved_control,'saved179_finite_original_conditions',saved.finite_original_column_conditions_met, ...
        'remaining_parent_completed',remaining.completed,'remaining_parent_source_posthash',remaining.source_posthash, ...
        'remaining_parent_failure_identifier',member(member(remaining,'failure',struct()),'identifier',''), ...
        'remaining_other_row_qualification_UNASSESSED',true,'selected_remaining_row',hit,'rows',{headers},'historical_source_headers',{sourceHeaders}, ...
        'raw_reference_scope','Both current raw files are hash-only. Child fine/PSS locators remain historical; no old reference is rehashed against a successor file or callback invoked.', ...
        'custody_scope','Original saved qualification/fine flags are observed; present process-exit and full historical-runtime equality are not inherited.');
    check(limit);
end

function h=directHeader(a,column)
    h=struct('original_column_requested',column,'audit_class',class(a),'top_field_count',0, ...
        'matching_original_row_count',0,'observed_original_columns',[],'point_field_count',0,'native_id','', ...
        'qualified_flag_available',false,'fine_count',0,'fine_initial_state_available',false(2,1),'fine_section_policy_fields_available',false(2,1), ...
        'point_classification_key_count',0,'point_classification_keys_prefix',{{}},'point_gate_key_count',0,'point_gate_keys_prefix',{{}});
    selected=struct();
    if isstruct(a)&&isscalar(a)
        keys=fieldnames(a);h.top_field_count=numel(keys);
        if column==179
            selected=a;h.observed_original_columns=member(member(a,'original',struct()),'original_column',[]);
            h.matching_original_row_count=double(isequal(h.observed_original_columns,179));
            h.qualified_flag_available=isfield(a,'qualified_saved_control');p=member(a,'saved_native_point',struct());
        else
            rows=member(a,'rows',{});hits=[];
            if iscell(rows)
                observed=NaN(min(4,numel(rows)),1);
                for k=1:numel(rows)
                    v=member(member(rows{k},'original',struct()),'original_column',[]);
                    if k<=4&&isnumeric(v)&&isscalar(v),observed(k)=v;end
                    if isequal(v,column),hits(end+1)=k;end %#ok<AGROW>
                end
                h.observed_original_columns=observed;h.matching_original_row_count=numel(hits);
                if isscalar(hits),selected=rows{hits};end
            end
            h.qualified_flag_available=isfield(selected,'qualified_new_control');p=member(selected,'new_point',struct());
        end
        if isstruct(p)&&isscalar(p)
            h.point_field_count=numel(fieldnames(p));id=member(p,'native_id','');if ischar(id),h.native_id=id(1:min(100,numel(id)));end
            v=member(p,'classification',struct());if isstruct(v)&&isscalar(v),keys=fieldnames(v);h.point_classification_key_count=numel(keys);h.point_classification_keys_prefix=keys(1:min(5,numel(keys)));end
            v=member(p,'acceptance_gates',struct());if isstruct(v)&&isscalar(v),keys=fieldnames(v);h.point_gate_key_count=numel(keys);h.point_gate_keys_prefix=keys(1:min(5,numel(keys)));end
        end
        fs=member(selected,'fines',{});
        if iscell(fs)
            h.fine_count=numel(fs);
            for k=1:min(2,numel(fs))
                inner=member(fs{k},'fine',struct());m=member(fs{k},'matching_saved_section',struct());
                h.fine_initial_state_available(k)=isstruct(inner)&&isfield(inner,'initial_state');
                h.fine_section_policy_fields_available(k)=isstruct(m)&&all(isfield(m,{'left_policy_configuration','right_policy_configuration','left_policy_evidence','right_policy_evidence'}));
            end
        end
    end
end


function [witness,policyReport,signature]=storedSection(target,p,l)
    assert(strcmp(p.native_id,target.native_id)&&isequaln(p.initial_state,target.state)&&isfield(p,'section_chart')&&isfield(p,'section_event_signature'), ...
        'C1PKCol1:TargetSection','Use only the exact already-read2 admitted NEW P1 control chart/token.');
    configuration=target.policy_configuration;assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isstruct(configuration.settings)&&isscalar(configuration.settings)&&isfield(configuration.settings,'Name'), ...
        'C1PKCol1:Policy','Use actual complete historical BL1 policy settings.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));[~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration)&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKCol1:PolicyRoundtrip','Fresh constructor must roundtrip exact recorded BL1 policy.');
    witness=struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',target.mode,'section_chart',p.section_chart,'return_multiplicity',1);
    policyReport=struct('seed',struct('return_policy',policy));signature=p.section_event_signature;assert(strlength(string(signature))>0,'C1PKCol1:EventToken','The saved single target event token must be nonempty.');check(l);
end


function targetShapes(t,w)
    assert(isa(t.state,'double')&&isreal(t.state)&&isequal(size(t.state),[14 1])&&all(isfinite(t.state)) ...
        &&islogical(t.mode)&&isequal(size(t.mode),[4 1])&&isa(t.parameter,'double')&&isreal(t.parameter)&&isequal(size(t.parameter),[10 1])&&all(isfinite(t.parameter)) ...
        &&isa(t.full_stride,'double')&&isreal(t.full_stride)&&isequal(size(t.full_stride),[14 1])&&all(isfinite(t.full_stride)) ...
        &&isa(t.period,'double')&&isreal(t.period)&&isscalar(t.period)&&isfinite(t.period)&&t.period>0 ...
        &&isa(t.native_energy,'double')&&isreal(t.native_energy)&&isscalar(t.native_energy)&&isfinite(t.native_energy), ...
        'C1PKCol1:TargetShapes','Require exact finite native state14/mode4/p10/stride14 and scalar period/energy.');
    assert(ischar(t.native_id)&&isrow(t.native_id)&&~isempty(regexp(t.native_id,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1PKCol1:NativeID','Require the source-defined native record identity.');assert(isstruct(w.section_chart)&&isscalar(w.section_chart),'C1PKCol1:TargetChart','Retain actual marked chart.');
end


function h=pointHeader(o,r,m,ix,index)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&ix.index==index&&isstruct(m)&&isscalar(m)&&strcmp(ix.component_identity,m.component_identity), ...
        'C1PKCol1:PointBinding','Retain current native record index, owner and public metadata binding.');
    assert(isa(o.stride_displacement,'double')&&isequal(size(o.stride_displacement),[14 1])&&all(isfinite(o.stride_displacement)), ...
        'C1PKCol1:Stride','A complete finite native14 stride is required.');
    g=r.classification;[~,pe]=RecordedReturnPolicy_v3(r);
    h=struct('index',index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o), ...
        'state',o.initial_state,'mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full_stride',o.stride_displacement, ...
        'native_energy',QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter), ...
        'acceptance_gates',pick(r.acceptance_gates,{'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'}), ...
        'classification',pick(g,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'}), ...
        'policy_configuration',pe.configuration,'section_chart',o.section_chart, ...
        'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature, ...
        'event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'saved_full_closure',r.full_closure,'metadata_binding',struct('component_identity',m.component_identity,'index',ix.index,'order',ix.order));
end


function out=pick(s,keys)
    out=struct();for k=1:numel(keys),assert(isfield(s,keys{k}),'C1PKCol1:RequiredField','A required saved field is missing.');out.(keys{k})=s.(keys{k});end
end


function out=compareTarget(O,r,t,witness,policyReport,signature)
    section=MatchingReturnSection_v3(O,witness,{r,policyReport});[~,pe]=RecordedReturnPolicy_v3(r);
    delta=O.initial_state(2:14)-t.state(2:14);scale=max([ones(13,1),abs(O.initial_state(2:14)),abs(t.state(2:14))],[],2);
    dt=O.period-t.period;dq=O.stride_displacement-t.full_stride;qs=max([ones(size(dq)),abs(O.stride_displacement),abs(t.full_stride)],[],2);
    dE=QuadrupedEnergy_v3.evaluate(O.initial_state,O.initial_mode,O.parameter)-t.native_energy;
    out=struct('raw_full13_delta',delta,'raw_full13_scaled_inf',norm(delta./scale,inf),'native_energy_delta',dE,'absolute_energy_tolerance',1e-8, ...
        'period_delta',dt,'period_tolerance',1e-10*max([1,abs(O.period),abs(t.period)]),'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
        'exact_p_q',isequaln(O.parameter,t.parameter)&&isequaln(O.initial_mode,t.mode),'exact_complete_policy',pe.complete&&isequaln(pe.configuration,t.policy_configuration), ...
        'matching_section',section,'same_section_event_signature',strcmp(string(O.section_relative_event_signature),string(signature)), ...
        'conditions_met',false,'scope','Finite comparison to the independently qualified NEW P1 control control only: rawfull13/E1e-8, period/fullstride componentwise1e-10/maxscale, exactp/q/completepolicy/markedsection/events. No OriginalP1 stride/meanU, source membership, alias, union or endpoint theorem is inferred.');
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dE)<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
        &&out.exact_p_q&&out.exact_complete_policy&&section.compatible&&out.same_section_event_signature;
end


function strictPK(o,r,p)
keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};for k=1:numel(keys),assert(isequal(r.acceptance_gates.(keys{k}),true),'C1Pilot:AllNine','Require every literal original native admission gate.');end;g=r.classification;status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true)&&strcmp(g.contract_version,'quadruped-gait-v3.5')&&strcmp(g.validated_gait_type,'PK')&&isequal(g.flight_count_certain,true)&&g.flight_count==1&&isequal(g.canonical_label_qualified,true)&&isequaln(o.parameter(:),p(:)),'C1Pilot:PK','Require current qualified certain PK1 and unchanged parameters.');[policy,e]=RecordedReturnPolicy_v3(r);assert(e.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1Pilot:Policy','Require the actual complete BL1 section.');
end


function [headers,comparison,outputReference]=forkRead2(file,original,t,witness,policyReport,signature,limit,newCount,owner)
    check(limit);outputReference=reference(file);check(limit);ix=BranchSolutionFile_v3.index(file);verify({outputReference});check(limit);N=2+newCount;assert(ismember(newCount,[0 1])&&numel(ix.points)==N&&numel(ix.edges)==newCount,'C1PKFork:ForkGraph','Require exactly two NONEDGE anchors and only an actually new edge.');if newCount==1,assert(ix.edges{1}.from==2&&ix.edges{1}.to==3,'C1PKFork:ForkEdge','Only actual local2->3 is allowed.');end
    fprintf('C1_PK_COL1_FORK_BEFORE_OUTPUT_READ1\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(file,(1:N).');fprintf('C1_PK_COL1_FORK_AFTER_OUTPUT_READ1_RETURN\n');check(limit);verify({outputReference});headers=cell(N,1);comparison=struct();comp=struct();principal=[10;10;20;20;1;1;0;0;2;.5];
    for k=1:N
        strictPK(O{k},R{k},principal);headers{k}=pointHeader(O{k},R{k},M{k},ix.points{k},k);
        assert(strcmp(headers{k}.owner,owner),'C1PKFork:OutputOwner','Every output occurrence retains the explicit fresh owner.');if k<=2,assert(~M{k}.edge_enabled&&~isfield(M{k},'edge_from')&&strcmp(headers{k}.native_id,original{k}.native_id)&&strcmp(M{k}.provenance.kind,'imported nonedge initial pair')&&M{k}.provenance.source_index==original{k}.index,'C1PKFork:CloneIdentity','Both native seed identities/roles must remain unchanged.');end
    end
    if newCount==1,comp=compareTarget(O{3},R{3},t,witness,policyReport,signature);end;clear O R M;verify({outputReference});check(limit);
    fprintf('C1_PK_COL1_FORK_BEFORE_OUTPUT_READ2\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(file,(1:N).');fprintf('C1_PK_COL1_FORK_AFTER_OUTPUT_READ2_RETURN\n');check(limit);verify({outputReference});
    for k=1:N,strictPK(O{k},R{k},principal);h=pointHeader(O{k},R{k},M{k},ix.points{k},k);assert(isequaln(h,headers{k}),'C1PKFork:OutputRead2','Compact actual output values must agree across two acquisitions.');end
    if newCount==1,comparison=compareTarget(O{3},R{3},t,witness,policyReport,signature);end;assert(isequaln(comp,comparison),'C1PKFork:ComparisonRead2','Every stored comparison field must agree.');
    if newCount==1,assert(M{3}.edge_enabled&&M{3}.edge_from==2&&M{3}.provenance.source_point==2&&M{3}.provenance.attempt==1,'C1PKFork:NewEdge','Only actual first correction from local base2 earns this edge.');end
    verify({outputReference});check(limit);
end

