function facts=ObserveC1PKOwnedP1Controls20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,options)
%OBSERVEC1PKOWNEDP1CONTROLS20261031 Bounded stored152/179 comparison and PAL geometry.
% Index scalars select at most six records. No Root/map evaluation/fine or write.
    started=clockPair();validSHA(expectedLedgerSHA);validSHA(expectedRawSHA);validSHA(expectedRoundSHA);
    exactFields(options,{'Saved179Reference','RemainingReference','Saved179RawReference','RemainingRawReference','ForkReference','PrimaryShortlist','ProtectedReferences'});o=options;
    for key={'Saved179Reference','RemainingReference','Saved179RawReference','RemainingRawReference','ForkReference'},o.(key{1})=checked(o.(key{1}));end
    exactFields(o.PrimaryShortlist,{'method','count_per_target'});
    assert(strcmp(o.PrimaryShortlist.method,'index-energy-meanU-nearest')&&isequal(o.PrimaryShortlist.count_per_target,3), ...
        'C1PKControls:Shortlist','Use the declared deterministic three-per-target index selector.');
    assert(strcmp(o.Saved179Reference.sha256,'1fd2ec2572f35423ad94f524df8c95a92c3adf474f97ccf719e94c2e82fa45fd') ...
        &&strcmp(o.RemainingReference.sha256,'da6ec1687ebc62a8c21c651e3d5a2daf84f169cae7e249b6ba23baca809c5d58') ...
        &&strcmp(o.Saved179RawReference.sha256,'9f51c9b35a258e97d8734548773cec3ddf6449302286e2f809266a6e420e923e') ...
        &&strcmp(o.RemainingRawReference.sha256,'a15b6a659bb1d0ff8e2ee73324a7e3e5bb7de29584d8af3f8ecb683015c824a9'), ...
        'C1PKControls:HistoricalPins','Use the exact direct Saved179/Remaining audit and current raw authorities; no7271/common210a inference.');
    root=canonical(fileparts(which('C1RunBudget_v3')));budget=C1RunBudget_v3();finish=shift(started,600);work=shift(finish,-120);
    assert(finish.utc<budget.research_deadline_unix_seconds&&finish.mono<budget.research_deadline_monotonic_ns, ...
        'C1PKControls:WholeFit','Full600 including120 reserve must fit BOTH unchanged SCIENCE clocks.');check(work);
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));
    raw=canonical(fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'));
    roundFile=canonical(fullfile(root,'Audits','PK36h_20261031_Round.mat'));
    live={struct('file',ledger,'sha256',expectedLedgerSHA);struct('file',raw,'sha256',expectedRawSHA);struct('file',roundFile,'sha256',expectedRoundSHA)};
    assert(~strcmp(raw,o.ForkReference.file),'C1PKControls:ForkPath','Primary and retained fork are distinct native authorities.');
    protected=references(o.ProtectedReferences);self=reference(which(mfilename));code=currentCode(self,protected);
    refs=[live;{o.Saved179Reference;o.RemainingReference;o.Saved179RawReference;o.RemainingRawReference;o.ForkReference};protected];
    facts=struct('schema','C1-owned-PK-existing-P1-controls-observation-v1','source_reference',self,'budget',budget, ...
        'expected_current_references',{live},'saved179_reference',o.Saved179Reference,'remaining_reference',o.RemainingReference, ...
        'saved179_raw_reference',o.Saved179RawReference,'remaining_raw_reference',o.RemainingRawReference,'fork_reference',o.ForkReference,'actual_method_references',{code}, ...
        'declared_seconds',600,'save_post_reserve_seconds',120,'original_columns',[152;179], ...
        'target_audit_load_calls_returned',0,'target_intake_headers',{{}},'target_intake_header_calls_returned',0,'index_calls_returned',0,'selected_load_calls_returned',0, ...
        'target_native_read2_verified',false,'target_current_evidence_complete',false(2,1),'index_read2_verified',false,'selected_compact_read2_verified',false, ...
        'targets',{{}},'historical_qualification',struct(),'shortlist',struct(),'primary',struct(),'fork',struct(),'fork_geometry',struct(), ...
        'root_calls',0,'map_evaluate_calls',0,'fine_calls',0,'current_journal_decoded',false,'raw_target_deserialized',false, ...
        'source_posthash',false,'completed',false,'failure',struct(),'own_process_exit_observed',false, ...
        'all_four_target_cohorts_claimed',false,'physical_attachment_claimed',false,'exact_identity_claimed',false, ...
        'original_P1_state_admission_claimed',false,'scheduled_v2_equivalence_claimed',false,'global_absence_claimed',false, ...
        'coverage_claimed',false,'endpoint_claimed',false,'ownership_changed',false,'journal_mutated',false,'round_mutated',false,'raw_mutated',false, ...
        'started_utc',stamp(),'finished_utc','', ...
        'read2_scope','Two independent selected native acquisitions compare declared compact states, saved gates, identities, metadata, full comparisons and scalar observations. No whole runtime-callback workspace or dense-trajectory equality claim.', ...
        'selector_scope','Index-metadata E/signedmeanU ranking only. Unselected, excluded and unknown rows remain UNASSESSED; no nearest-orbit or global absence inference.', ...
        'geometry_scope','Actual retained physical fork2->3 direction in the unchanged Run pronk family; constructors/pack/lift only. Target lift/section incompatibility is observed, never repaired or used as a seed.', ...
        'clock_scope','Scalar guards observe returned uninterruptible native reads; they do not cancel an internal MAT load.', ...
        'scope','Finite stored comparisons to the independently qualified NEW152 and saved179 controls. No Root, control reacquisition, fine, new edge, admission, rephase or persistent mutation.');
    normalSummaryReturned=false;
    try
        guard(work);assert(isfile([ledger,'.writer.lock']),'C1PKControls:Lock','Use the existing stable writer-lock inode.');
        lock=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
        [targets,points,historical]=storedControls(o,work,@observedTwice,@emitIntakeHeader);facts.target_native_read2_verified=true;facts.historical_qualification=historical;
        witnesses=cell(2,1);policies=cell(2,1);signatures=cell(2,1);
        for k=1:2
            [witnesses{k},policies{k},signatures{k}]=storedSection(targets{k},points{k},work);targetShapes(targets{k},witnesses{k});
            t=targets{k};facts.targets{k,1}=struct('original_column',facts.original_columns(k),'native_id',t.native_id,'role',t.role, ...
                'state',t.state,'mode',t.mode,'parameter',t.parameter,'period',t.period,'full_stride',t.full_stride, ...
                'saved_native_energy',t.native_energy,'ranking_energy',QuadrupedEnergy_v3.evaluate(t.state,t.mode,t.parameter), ...
                'ranking_signedmeanU',t.full_stride(1)/t.period,'policy_configuration',t.policy_configuration, ...
                'section_chart',witnesses{k}.section_chart,'section_event_signature',signatures{k}, ...
                'target_current_PK1_all9_evidence_complete',t.current_PK1_all9_evidence_complete);
        end
        facts.target_current_evidence_complete=cellfun(@(t)t.current_PK1_all9_evidence_complete,targets);
        facts.comparison_admission_scope='conditions_met is the unchanged numeric/section predicate only. Missing target current-PK1/all9 deep evidence is UNASSESSED; such results are bare stored-state/PAL observations, never a qualified current-target correspondence.';
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_PRIMARY_INDEX1\n');ix=BranchSolutionFile_v3.index(raw);facts.index_calls_returned=facts.index_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_PRIMARY_INDEX1_RETURN\n');check(work);
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_PRIMARY_INDEX2\n');ix2=BranchSolutionFile_v3.index(raw);facts.index_calls_returned=facts.index_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_PRIMARY_INDEX2_RETURN\n');check(work);
        assert(isequaln(ix,ix2),'C1PKControls:IndexRead2','Entire primary indices differ.');clear ix2
        facts.shortlist=indexShortlist(ix,facts.targets);selectors=facts.shortlist.selected_union;
        facts.primary=observedSelection(raw,ix,selectors,'PRIMARY',false);
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_FORK_INDEX1\n');fx=BranchSolutionFile_v3.index(o.ForkReference.file);facts.index_calls_returned=facts.index_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_FORK_INDEX1_RETURN\n');check(work);
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_FORK_INDEX2\n');fx2=BranchSolutionFile_v3.index(o.ForkReference.file);facts.index_calls_returned=facts.index_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_FORK_INDEX2_RETURN\n');check(work);
        assert(isequaln(fx,fx2)&&numel(fx.points)>=3,'C1PKControls:ForkIndex','Require identical complete indices and the actual retained fork2/3.');clear fx2
        hit=find(cellfun(@(e)e.from==2&&e.to==3,fx.edges));assert(isscalar(hit),'C1PKControls:ForkEdge','Require literal physical fork2->3.');
        edge=fx.edges{hit};assert(strcmp(edge.component_identity,fx.points{2}.component_identity)&&strcmp(edge.component_identity,fx.points{3}.component_identity), ...
            'C1PKControls:ForkOwner','The physical edge and both occurrences must have one literal owner.');facts.fork_physical_edge=edge;
        facts.fork=observedSelection(o.ForkReference.file,fx,[2;3],'FORK',true);
        facts.fork_geometry=observedGeometry(facts.fork.records{1},facts.fork.records{2},targets,witnesses,policies,work);
        clear ix fx points targets policies witnesses signatures
        facts.index_read2_verified=true;facts.selected_compact_read2_verified=true;
        facts.read2_digest=C1ScientificDigest_v3(struct('targets',{facts.targets},'shortlist',facts.shortlist,'primary',facts.primary,'fork',facts.fork,'geometry',facts.fork_geometry));
        guard(finish);facts.source_posthash=true;facts.finished_utc=stamp();facts.completed=true;check(finish);
        encoded=jsonencode(stdoutView(facts));assert(numel(unicode2native(encoded,'UTF-8'))<=50000,'C1PKControls:SummaryBytes','Normal summary exceeds50000 UTF8 bytes.');
        fprintf('C1_PK_CONTROLS_BEFORE_FINAL_SUMMARY\n');fprintf('C1_PK_P1_CONTROLS_OBSERVATION_ACTUAL_RETURN %s\n',encoded);normalSummaryReturned=true;fprintf('C1_PK_CONTROLS_AFTER_FINAL_SUMMARY_RETURN\n');guard(finish);
    catch problem
        facts.completed=false;facts.failure=exceptionData(problem);facts.finished_utc=stamp();p=partial(facts,problem,normalSummaryReturned);encoded=jsonencode(p);
        if numel(unicode2native(encoded,'UTF-8'))>7000,p.failure_header.message_prefix='';p.failure_header.message_truncated=true;p.failure_header.first_stack_frame=struct();p.failure_header.stack_detail_omitted=true;encoded=jsonencode(p);end
        assert(numel(unicode2native(encoded,'UTF-8'))<=7000,'C1PKControls:PartialBytes','Fixed compact partial must fit7000 UTF8 bytes.');
        fprintf('C1_PK_P1_CONTROLS_OBSERVATION_PARTIAL %s\n',encoded);rethrow(problem);
    end
    function a=observedTwice(file,key,label,limit)
        check(limit);fprintf('C1_PK_CONTROLS_BEFORE_AUDIT_LOAD1 %s\n',label);x=load(file,'-mat',key);facts.target_audit_load_calls_returned=facts.target_audit_load_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_AUDIT_LOAD1_RETURN %s\n',label);check(limit);
        fprintf('C1_PK_CONTROLS_BEFORE_AUDIT_LOAD2 %s\n',label);y=load(file,'-mat',key);facts.target_audit_load_calls_returned=facts.target_audit_load_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_AUDIT_LOAD2_RETURN %s\n',label);check(limit);
        assert(isequaln(x.(key),y.(key)),'C1PKControls:AuditRead2','Whole retained plain audits differ.');a=x.(key);check(limit);
    end
    function emitIntakeHeader(header)
        facts.target_intake_headers{end+1,1}=header;encodedHeader=jsonencode(header);
        assert(numel(unicode2native(encodedHeader,'UTF-8'))<=1000,'C1PKControls:IntakeHeaderBytes','Each bounded target header must fit1000 UTF8 bytes.');
        fprintf('C1_PK_CONTROLS_DIRECT_TARGET_HEADER %s\n',encodedHeader);facts.target_intake_header_calls_returned=facts.target_intake_header_calls_returned+1;
    end
    function out=observedSelection(file,index,selected,label,requirePair)
        principal=[10;10;20;20;1;1;0;0;2;.5];N=numel(selected);first=cell(N,1);comp=cell(N,2);scalar=cell(N,1);pair=struct();
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_SELECTED_LOAD1 %s\n',label);[O,R,M]=BranchSolutionFile_v3.loadSolutions(file,selected);facts.selected_load_calls_returned=facts.selected_load_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_SELECTED_LOAD1_RETURN %s\n',label);timely1=left(work)>0;check(work);
        assert(isequal(size(O),[N 1])&&isequal(size(R),[N 1])&&isequal(size(M),[N 1]),'C1PKControls:SelectedShape','Retain requested column-cell order.');
        for i=1:N
            strictPK(O{i},R{i},principal);first{i}=pointHeader(O{i},R{i},M{i},index.points{selected(i)},selected(i));scalar{i}=nativeScalars(first{i},index.points{selected(i)});
            for j=1:2,comp{i,j}=compareTarget(O{i},R{i},targets{j},witnesses{j},policies{j},signatures{j});end
        end
        if requirePair
            pair=MatchingReturnSection_v3(O{1},O{2},{R{1},R{2}});
            assert(pair.compatible&&isequal(O{1}.parameter,O{2}.parameter)&&isequaln(first{1}.policy_configuration,first{2}.policy_configuration), ...
                'C1PKControls:Pair','Actual fork2/3 must satisfy Run source-pair policy/physical chart compatibility.');
        end
        clear O R M
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_SELECTED_LOAD2 %s\n',label);[O,R,M]=BranchSolutionFile_v3.loadSolutions(file,selected);facts.selected_load_calls_returned=facts.selected_load_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_SELECTED_LOAD2_RETURN %s\n',label);timely2=left(work)>0;check(work);
        assert(isequal(size(O),[N 1])&&isequal(size(R),[N 1])&&isequal(size(M),[N 1]),'C1PKControls:SelectedShape','Retain requested column-cell order.');
        for i=1:N
            strictPK(O{i},R{i},principal);h=pointHeader(O{i},R{i},M{i},index.points{selected(i)},selected(i));assert(isequaln(h,first{i})&&isequaln(nativeScalars(h,index.points{selected(i)}),scalar{i}), ...
                'C1PKControls:SelectedRead2','Compact native identities/states/gates/metadata/scalars differ.');
            for j=1:2,c=compareTarget(O{i},R{i},targets{j},witnesses{j},policies{j},signatures{j});assert(isequaln(c,comp{i,j}),'C1PKControls:ComparisonRead2','Actual full comparison differs.');end
        end
        if requirePair,assert(isequaln(MatchingReturnSection_v3(O{1},O{2},{R{1},R{2}}),pair),'C1PKControls:PairRead2','Actual native pair chart differs.');end
        clear O R M h c
        out=struct('selected_indices',selected,'records',{first},'comparisons',{comp},'native_index_scalar_observations',{scalar}, ...
            'physical_incident_edges',{incidentBindings(index,selected)},'pair_match',pair,'native_read2_verified',true,'return_timely',[timely1;timely2], ...
            'scope','Index ranking is not re-run after native scalar mismatches. Every unselected occurrence remains UNASSESSED.');
    end
    function guard(limit)
        check(limit);quiet(ledger,raw,roundFile);assert(~isfile([o.ForkReference.file,'.pending.mat']),'C1PKControls:ForkPending','Retain/reconcile a pending fork stage before observation.');
        verify(refs);verifyCode(code);assert(isequaln(C1RunBudget_v3(),budget),'C1PKControls:BudgetValue','The original native budget VALUE must remain literal.');check(limit);
    end
end
function [targets,points,h]=storedControls(o,limit,read2,emitHeader)
    saved=read2(o.Saved179Reference.file,'audit','Saved1791fd2',limit);
    remaining=read2(o.RemainingReference.file,'audit','Remainingda6',limit);
    emitHeader(directHeader(saved,179));emitHeader(directHeader(remaining,152));
    assert(isstruct(saved)&&isscalar(saved)&&isequal(saved.completed,true)&&isequal(saved.source_posthash,true) ...
        &&isequal(saved.qualified_saved_control,true)&&isequal(saved.finite_original_column_conditions_met,true) ...
        &&isequal(saved.original.original_column,179),'C1PKControls:Saved179','Retain actual direct saved179 qualification, not a NEW7271 target.');
    assert(isstruct(remaining)&&isscalar(remaining)&&iscell(remaining.rows)&&isequal(remaining.completed,false)&&isequal(remaining.source_posthash,false), ...
        'C1PKControls:Remaining','Retain literal global-false Remaining audit and qualified local row separately.');
    hit=find(cellfun(@(r)isstruct(r)&&isscalar(r)&&isfield(r,'original')&&isfield(r.original,'original_column')&&isequal(r.original.original_column,152),remaining.rows));
    assert(isscalar(hit),'C1PKControls:OriginalColumn','Require one actual Remaining row whose recorded original_column is152.');
    row=remaining.rows{hit};
    assert(isequal(row.qualified_new_control,true)&&isequal(row.finite_original_column_conditions_met,true)&&isequal(row.native_all_nine,true) ...
        &&isequal(row.initial_anchor_control.passed,true),'C1PKControls:Local152','Retain literal NEW152 all9/local qualification/anchor evidence.');
    assert(isequal(saved.initial_anchor_control.passed,true),'C1PKControls:Anchor179','Retain original saved179 anchor evidence.');
    rootBack=saved.fresh_saved_root_readback;
    assert(isequal(rootBack.completed,true)&&isequal(rootBack.timely,true)&&isequal(rootBack.native_public_passes,2) ...
        &&strcmp(canonical(rootBack.reference.file),o.RemainingRawReference.file)&&strcmp(rootBack.reference.sha256,o.RemainingRawReference.sha256) ...
        &&strcmp(rootBack.variable,'raw_P1col179_PSS') ...
        &&strcmp(canonical(saved.raw_reference.file),o.Saved179RawReference.file)&&strcmp(saved.raw_reference.sha256,o.Saved179RawReference.sha256), ...
        'C1PKControls:SavedReadback','Bind actual saved179 public read2 and its PSS raw locator, distinct from own fine raw current reference.');
    points={row.new_point;saved.saved_native_point};wrappers={row.fines;saved.fines};columns=[152;179];
    ids={'native-orbit-record:sha256:9e8b7f51693bb143668212aa3a607df2b083ac6932485060b45d4e8e1ff7f69d'; ...
        'native-orbit-record:sha256:57f2c08d6a1f3703c6653acff3bacc00fd57fba0836510edcef46e6e715ea5d9'};
    targets=cell(2,1);headers=cell(2,1);principal=[10;10;20;20;1;1;0;0;2;.5];
    gateNames={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    sectionKeys={'id','geometry','crossing_orientation','boundary_ownership','translational_gauge'};
    for k=1:2
        p=points{k};assert(strcmp(p.native_id,ids{k}),'C1PKControls:DirectNativeID','Keep the exact actually observed full control NativeID.');
        assert(isstruct(p.acceptance_gates)&&isscalar(p.acceptance_gates)&&isstruct(p.classification)&&isscalar(p.classification), ...
            'C1PKControls:PointEvidenceShape','Present saved point evidence must retain scalar-struct shape.');
        gateSeen=false(size(gateNames));gateHeader=struct();
        for j=1:numel(gateNames)
            key=gateNames{j};gateSeen(j)=isfield(p.acceptance_gates,key);
            if gateSeen(j),assert(isequal(p.acceptance_gates.(key),true),'C1PKControls:AvailablePointGate','Every PROVIDED original point gate must be literaltrue.');gateHeader.(key)=p.acceptance_gates.(key);end
        end
        g=p.classification;classKeys={'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'};
        expected={'quadruped-gait-v3.5','PK',true,true,1};classSeen=false(size(classKeys));classHeader=struct();
        for j=1:numel(classKeys)
            key=classKeys{j};classSeen(j)=isfield(g,key);
            if classSeen(j)
                actual=g.(key);if j<=2,valid=strcmp(actual,expected{j});else,valid=isequal(actual,expected{j});end
                assert(valid,'C1PKControls:AvailablePointClassification','Every PROVIDED current-target classification field must match its declared PK1 contract.');
                classHeader.(key)=actual;
            end
        end
        assert(isequaln(p.parameter(:),principal),'C1PKControls:PointParameter','The direct controls retain the unchanged principal physical parameter.');
        fines=wrappers{k};assert(iscell(fines)&&numel(fines)==2,'C1PKControls:FineCount','Retain exactly two historical original-state fine wrappers.');
        configuration=[];seedBound=false(2,1);fineHeaders=cell(2,1);
        for level=1:2
            f=fines{level};
            assert(isequal(f.passed,true)&&isequal(f.initial_trajectory_row_exact,true)&&isequal(f.observation.returned,true)&&isequal(f.observation.return_timely,true) ...
                &&isequal(f.raw_custody.storage_timely,true)&&isequal(f.raw_custody.readback_timely,true) ...
                &&f.saved_period_scaled_error<=1e-8&&f.saved_stride_scaled_error<=1e-8, ...
                'C1PKControls:HistoricalFine','Keep actual historical pass/initialrow/return/storage/readback/period/stride gates.');
            m=f.matching_saved_section;
            assert(isequal(m.compatible,true)&&isequal(m.actual_policy_configuration_checked,true)&&isequal(m.policy_configuration_matches_declared_identity,true) ...
                &&isequal(m.rephase_or_chart_transition_inferred,false),'C1PKControls:FineSection','Use only the actual saved complete matching-section contract.');
            assert(isequal(m.left_policy_evidence.complete,true)&&isequal(m.right_policy_evidence.complete,true) ...
                &&isequaln(m.left_policy_configuration,m.right_policy_configuration) ...
                &&isequaln(m.left_policy_evidence.configuration,m.left_policy_configuration)&&isequaln(m.right_policy_evidence.configuration,m.right_policy_configuration), ...
                'C1PKControls:FinePolicy','Both actual fine sides must expose complete identical policy settings/evidence.');
            c=m.left_policy_configuration;
            if isempty(configuration),configuration=c;else,assert(isequaln(c,configuration),'C1PKControls:FinePolicyLevels','Both original levels must retain the SAME complete policy.');end
            for side={'left_identity','right_identity'}
                ident=m.(side{1});
                assert(isequaln(ident.initial_mode,logical(p.mode(:)))&&isequaln(ident.section,pick(p.section_chart,sectionKeys))&&ident.return_occurrence==1, ...
                    'C1PKControls:FinePointSection','Actual fine semantic section/mode/occurrence must bind the saved control point.');
            end
            inner=member(f,'fine',struct());innerAvailable=isstruct(inner)&&isscalar(inner);
            if innerAvailable&&isfield(inner,'initial_state')
                assert(isequaln(inner.initial_state,p.initial_state),'C1PKControls:FineInitialState','Every available original fine initial state must exactly equal its retained control point.');seedBound(level)=true;
            end
            if innerAvailable&&isfield(inner,'actual_policy_configuration'),assert(isequaln(inner.actual_policy_configuration,configuration),'C1PKControls:FineNumericPolicy','Available actual fine policy must equal its matching-section evidence.');end
            if innerAvailable&&isfield(inner,'event_signature'),assert(strcmp(string(inner.event_signature),string(p.section_event_signature)),'C1PKControls:FineEvent','Available actual fine token must match the saved point.');end
            fineHeaders{level}=struct('passed',f.passed,'returned',f.observation.returned,'return_timely',f.observation.return_timely, ...
                'initial_row_exact',f.initial_trajectory_row_exact,'raw_storage_timely',f.raw_custody.storage_timely,'raw_readback_timely',f.raw_custody.readback_timely, ...
                'saved_period_scaled_error',f.saved_period_scaled_error,'saved_stride_scaled_error',f.saved_stride_scaled_error, ...
                'fine_payload_scalar_struct_available',innerAvailable,'fine_initial_state_available_and_exact',seedBound(level),'raw_custody_reference_historical',f.raw_custody.reference, ...
                'historical_raw_reference_rehashed',false);
        end
        assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isequal(configuration.settings.BLTouchdownsPerReturn,1)&&isequal(configuration.settings.RequireModeClosure,true), ...
            'C1PKControls:PolicyClass','Use the recorded actual BL1/mode-closed policy, never guessed defaults or callbacks.');
        v=struct('initial_state',p.initial_state,'initial_mode',p.mode,'parameter',p.parameter,'period',p.period, ...
            'stride_displacement',p.full_stride,'return_policy_name',configuration.settings.Name);
        orbit=HybridOrbit_v3(v);assert(strcmp(OrbitContentIdentity_v3(orbit),p.native_id),'C1PKControls:DirectIDRoundtrip','The actual identity method must reproduce each saved control ID from literal identity-bearing values.');clear orbit v
        role='qualified-new-original-column152-control';if k==2,role='qualified-saved-original-column179-control';end
        targets{k}=struct('native_id',p.native_id,'role',role,'state',p.initial_state,'mode',p.mode,'parameter',p.parameter, ...
            'period',p.period,'full_stride',p.full_stride,'native_energy',p.native_energy,'policy_configuration',configuration, ...
            'current_PK1_all9_evidence_complete',all(classSeen)&&all(gateSeen));
        headers{k}=struct('original_column',columns(k),'native_id',p.native_id,'source_disposition',role,'classification',classHeader, ...
            'original_acceptance_gates',gateHeader,'target_current_PK1_all9_evidence_complete',all(classSeen)&&all(gateSeen), ...
            'missing_classification_keys_UNASSESSED',{classKeys(~classSeen)},'missing_acceptance_gate_keys_UNASSESSED',{gateNames(~gateSeen)},'fine_observations',{fineHeaders},'fine_initial_state_unavailable_is_UNASSESSED',true, ...
            'historical_process_exit_revalidated',false,'all_four_cohorts_assessed',false,'original_legacy_state_admission_claimed',false);
    end
    sourceHeaders=cell(2,1);audits={remaining;saved};
    for k=1:2
        a=audits{k};v=member(a,'source_code',[]);d='';failure='';
        try,d=C1ScientificDigest_v3(v);catch problem,failure=problem.identifier;end
        sourceHeaders{k}=struct('original_column',columns(k),'class',class(v),'count',numel(v),'digest',d,'digest_failure_identifier',failure, ...
            'field_present',isfield(a,'source_code'),'syntax_assessed',false,'currentness_claimed',false);
    end
    h=struct('direct_source_scope','No7271/common210a target join. Exact Saved179/Remaining local native evidence is used.', ...
        'saved179_parent_completed',saved.completed,'saved179_parent_source_posthash',saved.source_posthash, ...
        'saved179_qualified_saved_control',saved.qualified_saved_control,'saved179_finite_original_conditions',saved.finite_original_column_conditions_met, ...
        'remaining_parent_completed',remaining.completed,'remaining_parent_source_posthash',remaining.source_posthash, ...
        'remaining_parent_failure_identifier',member(member(remaining,'failure',struct()),'identifier',''), ...
        'remaining_other_row_qualification_UNASSESSED',true,'selected_remaining_row',hit,'rows',{headers},'historical_source_headers',{sourceHeaders}, ...
        'raw_reference_scope','Both current raw files are hash-only. Child fine/PSS locators remain historical; no old reference is rehashed against a successor file or callback invoked.', ...
        'custody_scope','Original saved qualification/fine flags are observed; present process-exit and full historical-runtime equality are not inherited.');
    check(limit);
end
function h=directHeader(a,column)
    h=struct('original_column_requested',column,'audit_class',class(a),'top_field_count',0, ...
        'matching_original_row_count',0,'observed_original_columns',[],'point_field_count',0,'native_id','', ...
        'qualified_flag_available',false,'fine_count',0,'fine_initial_state_available',false(2,1),'fine_section_policy_fields_available',false(2,1), ...
        'point_classification_key_count',0,'point_classification_keys_prefix',{{}},'point_gate_key_count',0,'point_gate_keys_prefix',{{}});
    selected=struct();
    if isstruct(a)&&isscalar(a)
        keys=fieldnames(a);h.top_field_count=numel(keys);
        if column==179
            selected=a;h.observed_original_columns=member(member(a,'original',struct()),'original_column',[]);
            h.matching_original_row_count=double(isequal(h.observed_original_columns,179));
            h.qualified_flag_available=isfield(a,'qualified_saved_control');p=member(a,'saved_native_point',struct());
        else
            rows=member(a,'rows',{});hits=[];
            if iscell(rows)
                observed=NaN(min(4,numel(rows)),1);
                for k=1:numel(rows)
                    v=member(member(rows{k},'original',struct()),'original_column',[]);
                    if k<=4&&isnumeric(v)&&isscalar(v),observed(k)=v;end
                    if isequal(v,column),hits(end+1)=k;end %#ok<AGROW>
                end
                h.observed_original_columns=observed;h.matching_original_row_count=numel(hits);
                if isscalar(hits),selected=rows{hits};end
            end
            h.qualified_flag_available=isfield(selected,'qualified_new_control');p=member(selected,'new_point',struct());
        end
        if isstruct(p)&&isscalar(p)
            h.point_field_count=numel(fieldnames(p));id=member(p,'native_id','');if ischar(id),h.native_id=id(1:min(100,numel(id)));end
            v=member(p,'classification',struct());if isstruct(v)&&isscalar(v),keys=fieldnames(v);h.point_classification_key_count=numel(keys);h.point_classification_keys_prefix=keys(1:min(5,numel(keys)));end
            v=member(p,'acceptance_gates',struct());if isstruct(v)&&isscalar(v),keys=fieldnames(v);h.point_gate_key_count=numel(keys);h.point_gate_keys_prefix=keys(1:min(5,numel(keys)));end
        end
        fs=member(selected,'fines',{});
        if iscell(fs)
            h.fine_count=numel(fs);
            for k=1:min(2,numel(fs))
                inner=member(fs{k},'fine',struct());m=member(fs{k},'matching_saved_section',struct());
                h.fine_initial_state_available(k)=isstruct(inner)&&isfield(inner,'initial_state');
                h.fine_section_policy_fields_available(k)=isstruct(m)&&all(isfield(m,{'left_policy_configuration','right_policy_configuration','left_policy_evidence','right_policy_evidence'}));
            end
        end
    end
end

function result=indexShortlist(ix,targets)
    N=numel(ix.points);E=NaN(N,1);U=NaN(N,1);physical=false(N,1);label=false(N,1);
    for k=1:N
        p=ix.points{k};E(k)=p.nativeE;U(k)=p.signedmeanU;label(k)=strcmp(p.classification,'PK');
    end
    for k=1:numel(ix.edges)
        e=ix.edges{k};assert(strcmp(e.component_identity,ix.points{e.from}.component_identity)&&strcmp(e.component_identity,ix.points{e.to}.component_identity), ...
            'C1PKControls:EdgeOwner','A literal physical edge must agree with both actual occurrence owners.');physical([e.from,e.to])=true;
    end
    finite=isfinite(E)&isfinite(U);eligible=finite&physical&label;assert(nnz(eligible)>=3,'C1PKControls:Candidates','At least three finite PK index rows with physical incident edges are required.');
    selections=cell(2,1);which=find(eligible);
    for j=1:2
        et=targets{j}.ranking_energy;ut=targets{j}.ranking_signedmeanU;scales=[max(1,abs(et));max(1,abs(ut))];
        score=((E(which)-et)/scales(1)).^2+((U(which)-ut)/scales(2)).^2;
        assert(all(isfinite(score)),'C1PKControls:RankFinite','Declared finite metadata distances must remain finite.');
        sorted=sortrows([score,which],[1 2]);sel=sorted(1:3,2);
        selections{j}=struct('original_column',targets{j}.original_column,'target_native_id',targets{j}.native_id, ...
            'target_energy',et,'target_signedmeanU',ut,'fixed_scales',scales,'selected_indices',sel,'selected_squared_distance',sorted(1:3,1), ...
            'selected_index_energy',E(sel),'selected_index_signedmeanU',U(sel),'eligible_unselected_count_UNASSESSED',nnz(eligible)-3);
    end
    union=unique([selections{1}.selected_indices;selections{2}.selected_indices],'sorted');
    assert(numel(union)<=6,'C1PKControls:Union','The deterministic union cannot exceed six.');
    result=struct('method','index-energy-meanU-nearest','distance','squared2 norm with fixed target max1 scales; original index breaks ties', ...
        'count_per_target',3,'per_target',{selections},'selected_union',union,'total_index_rows',N,'eligible_count',nnz(eligible), ...
        'unknown_nonfinite_count_UNASSESSED',nnz(~finite),'nonphysical_count_UNASSESSED',nnz(~physical),'non_PK_metadata_count_UNASSESSED',nnz(~label), ...
        'total_unselected_count_UNASSESSED',N-numel(union),'excluded_count_UNASSESSED',N-nnz(eligible), ...
        'exclusion_counts_can_overlap',true,'native_admission_verified_at_selection',false,'global_absence_claimed',false,'reranking_after_native_load',false);
end
function out=nativeScalars(h,p)
    u=h.full_stride(1)/h.period;
    out=struct('index_energy',p.nativeE,'native_recomputed_energy',h.native_energy,'energy_delta',h.native_energy-p.nativeE, ...
        'energy_exact_equal',isequaln(h.native_energy,p.nativeE),'index_signedmeanU',p.signedmeanU,'native_recomputed_signedmeanU',u, ...
        'signedmeanU_delta',u-p.signedmeanU,'signedmeanU_exact_equal',isequaln(u,p.signedmeanU), ...
        'mismatch_changes_selection',false,'scope','Any mismatch stays literal; no reranking, replacement candidate or physics/admission inference.');
end
function b=incidentBindings(ix,selected)
    b=cell(numel(selected),1);
    for k=1:numel(selected)
        s=selected(k);hit=find(cellfun(@(e)e.from==s||e.to==s,ix.edges));assert(~isempty(hit),'C1PKControls:OwnedOccurrence','Each selected occurrence must have a stored physical incident edge.');
        b{k}=ix.edges(hit);
    end
end
function g=observedGeometry(a,b,targets,witnesses,policyReports,limit)
    schema=QuadrupedSchema_v3.shared();configuration=b.policy_configuration;policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));
    [~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration),'C1PKControls:BasePolicy','Fresh base-policy constructor must exactly roundtrip the actual recorded policy.');
    integration=struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001,'ODEOptions',odeset('OutputFcn',@(~,~,~)geometryClock(limit)));
    map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(schema.PhaseIndex),HybridSimulator_v3(integration),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));
    family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,b.state),b.state,b.mode,b.parameter,struct('Symmetry','pronk'));
    ua=family.packState(a.state);ub=family.packState(b.state);scale=max([ones(numel(ub),1),abs(ua),abs(ub)],[],2);
    delta=(ub-ua)./scale;distance=norm(delta);assert(isfinite(distance)&&distance>1e-10,'C1PKControls:Chord','Require the actual resolved physical fork2->3 chord.');tangent=delta/distance;
    assert(isequal(family.fullState(ub),b.state(:)),'C1PKControls:BaseRoundtrip','Actual admitted fork3 base must roundtrip exactly without projection.');
    rows=cell(2,1);
    for j=1:2
        t=targets{j};ut=family.packState(t.state);sigma=dot(tangent,(ut-ub)./scale);
        assert(isa(sigma,'double')&&isreal(sigma)&&isscalar(sigma)&&isfinite(sigma),'C1PKControls:Sigma','Record an actual finite signed native projection.');
        lifted=family.fullState(ut);predictor=family.fullState(ub+scale.*(sigma*tangent));
        section=MatchingReturnSection_v3(struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',b.mode,'section_chart',b.section_chart,'return_multiplicity',1), ...
            witnesses{j},{struct('seed',struct('return_policy',policy)),policyReports{j}});
        rows{j}=struct('native_id',t.native_id,'target_coordinates',ut,'signed_sigma',sigma,'sigma_in_declared_Run_bounds',sigma>=1e-7&&sigma<=.1, ...
            'target_lift_minus_raw',lifted-t.state(:),'target_roundtrip_exact',isequal(lifted,t.state(:)),'target_parameter_mode_equal',isequaln(b.parameter,t.parameter)&&isequaln(b.mode,t.mode), ...
            'target_matching_section',section,'capture_predictor_state',predictor,'target_used_as_seed',false, ...
            'predictor_full13_separation',norm((predictor(2:14)-b.state(2:14))./max(ones(13,1),abs(b.state(2:14))),inf), ...
            'predictor_target_full13_scaled_inf',norm((predictor(2:14)-t.state(2:14))./max([ones(13,1),abs(predictor(2:14)),abs(t.state(2:14))],[],2),inf));
    end
    g=struct('source_pair',[2 3],'source_native_ids',{{a.native_id;b.native_id}},'symmetry','pronk','coordinate_indices',family.CoordinateIndices, ...
        'closure_indices',family.ClosureIndices,'energy_pivot',family.EnergyPivot,'scale',scale,'ua',ua,'ub',ub,'tangent',tangent,'chord_distance',distance, ...
        'source_A_lift_minus_raw',family.fullState(ua)-a.state(:),'base_roundtrip_exact',true,'base_energy',QuadrupedEnergy_v3.evaluate(b.state,b.mode,b.parameter), ...
        'targets',{rows},'map_evaluate_calls',0,'source_direction_reversed',false,'scope','Exact Run chart/scale/tangent calculation only. Signed projections, lift mismatch and section incompatibility are observations, never a physical connection or authorized Root target.');
    check(limit);
end
function x=geometryClock(limit),check(limit);x=0;end
function code=currentCode(self,protected)
    names={'C1RunBudget_v3','BranchSolutionFile_v3','QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3','QuadrupedAdmissibility_v3','ContinuousDynamics_v3', ...
        'RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3','MatchingReturnSection_v3','OrbitContentIdentity_v3','HybridOrbit_v3','Trajectory_v3','RoundSHA256_v3','C1ScientificDigest_v3', ...
        'RunC1Continuation_v3','PoincareMap_v3','Quadrupedal_Dynamics_v3','PoincareSection_v3','HybridSimulator_v3','PeriodicOrbitResidual_v3','EnergyFamilyResidual_v3','HybridSystemBase_v3'};
    code={self};
    for k=1:numel(names)
        r=reference(which(names{k}));assert(any(cellfun(@(q)strcmp(q.file,r.file)&&strcmp(q.sha256,r.sha256),protected)),'C1PKControls:CallerPin','Every declared current resolver must be caller-protected.');
        if strcmp(names{k},'RunC1Continuation_v3'),assert(strcmp(r.sha256,'09e1b6813f4bdc1ca1115138d60d504bdb2758a8cb7e530f80c38987591b5bf1'),'C1PKControls:RunPin','Keep actual Run09 geometry authority; Run is not invoked.');end
        code{end+1,1}=r;
    end
end
function v=stdoutView(f)
    % Output projection only. Full comparisons/read2/digest remain unchanged.
    % Fixed maximum: six selected primary records, two fork records, two targets.
    baseKeys={'schema','declared_seconds','save_post_reserve_seconds','original_columns', ...
        'target_audit_load_calls_returned','target_intake_header_calls_returned','index_calls_returned','selected_load_calls_returned', ...
        'target_native_read2_verified','target_current_evidence_complete','index_read2_verified','selected_compact_read2_verified', ...
        'root_calls','map_evaluate_calls','fine_calls','current_journal_decoded','raw_target_deserialized','source_posthash','completed', ...
        'own_process_exit_observed','all_four_target_cohorts_claimed','physical_attachment_claimed','exact_identity_claimed', ...
        'original_P1_state_admission_claimed','scheduled_v2_equivalence_claimed','global_absence_claimed','coverage_claimed', ...
        'endpoint_claimed','ownership_changed','journal_mutated','round_mutated','raw_mutated','started_utc','finished_utc','read2_digest'};
    v=pick(f,baseKeys);v.source_sha256=f.source_reference.sha256;
    v.full_in_memory_facts_digest=C1ScientificDigest_v3(f);v.full_facts_durably_retained_claimed=false;
    admin=pick(f,{'source_reference','budget','expected_current_references','saved179_reference','remaining_reference', ...
        'saved179_raw_reference','remaining_raw_reference','fork_reference','actual_method_references','target_intake_headers'});
    v.omitted_administrative_evidence=struct('typed_digest',C1ScientificDigest_v3(admin), ...
        'method_count',numel(f.actual_method_references),'authority_count',numel(f.expected_current_references)+5, ...
        'intake_header_count',numel(f.target_intake_headers),'scope','Packet-bound file/source/budget tuples and already printed intake headers are omitted, not revalidated or silently changed by this projection.');
    v.targets=f.targets;
    for k=1:numel(v.targets)
        t=v.targets{k};t.section_chart=chartView(t.section_chart);v.targets{k}=t;
    end
    h=f.historical_qualification;
    h=rmfield(h,{'direct_source_scope','raw_reference_scope','custody_scope'});
    for k=1:numel(h.rows)
        row=h.rows{k};
        for level=1:numel(row.fine_observations)
            item=row.fine_observations{level};r=item.raw_custody_reference_historical;
            item.raw_custody_reference_historical=struct('sha256',r.sha256,'full_reference_digest',C1ScientificDigest_v3(r),'file_path_omitted',true);
            row.fine_observations{level}=item;
        end
        h.rows{k}=row;
    end
    v.historical_qualification=h;v.shortlist=f.shortlist;
    v.primary=selectionView(f.primary);v.fork=selectionView(f.fork);
    v.fork_physical_edge=edgeView(f.fork_physical_edge);
    g=f.fork_geometry;g=rmfield(g,'scope');
    for k=1:numel(g.targets),g.targets{k}.target_matching_section=sectionView(g.targets{k}.target_matching_section);end
    v.fork_geometry=g;
    v.projection_mode='compact_full_numeric_vectors';
    v.projection_scope='All selected/target state14,p/q,T,stride14,NativeID/owner, exact policy, chart identity, saved tokens, numeric comparison vectors/tolerances/flags and PAL numbers remain. Full chart detail, repeated matching-section evidence and packet-bound administrative tuples are digest/count omissions. Full facts exist only in memory/the function return if it returns.';
    v.comparison_scope='conditions_met is finite numeric/section comparison only. Target current-PK1/all9 missing keys stay UNASSESSED. No current-target admission, attachment, original-v2 trajectory equivalence, endpoint, coverage or absence claim.';
    % Do not lose all scientific outcomes to a second output-size refusal.
    % The scalar fallback drops vectors explicitly, never changes a predicate.
    if numel(unicode2native(jsonencode(v),'UTF-8'))>40000
        normalDigest=C1ScientificDigest_v3(v);small=pick(v,baseKeys);small.source_sha256=v.source_sha256;
        small.full_in_memory_facts_digest=v.full_in_memory_facts_digest;small.full_facts_durably_retained_claimed=false;
        small.omitted_administrative_evidence=v.omitted_administrative_evidence;
        small.primary=scalarSelection(f.primary);small.fork=scalarSelection(f.fork);
        small.targets=cell(numel(f.targets),1);
        for k=1:numel(f.targets)
            t=f.targets{k};small.targets{k}=struct('original_column',t.original_column,'native_id',t.native_id, ...
                'period',t.period,'saved_native_energy',t.saved_native_energy,'ranking_energy',t.ranking_energy, ...
                'ranking_signedmeanU',t.ranking_signedmeanU,'target_current_PK1_all9_evidence_complete',t.target_current_PK1_all9_evidence_complete, ...
                'state_count',numel(t.state),'mode_count',numel(t.mode),'parameter_count',numel(t.parameter),'stride_count',numel(t.full_stride), ...
                'omitted_full_target_digest',C1ScientificDigest_v3(t));
        end
        small.historical_qualification=pick(h,{'saved179_parent_completed','saved179_parent_source_posthash','saved179_qualified_saved_control', ...
            'saved179_finite_original_conditions','remaining_parent_completed','remaining_parent_source_posthash', ...
            'remaining_other_row_qualification_UNASSESSED','selected_remaining_row'});
        small.historical_qualification.omitted_detail_digest=C1ScientificDigest_v3(h);
        identifier=char(h.remaining_parent_failure_identifier);
        small.historical_qualification.remaining_parent_failure_identifier_prefix=identifier(1:min(128,numel(identifier)));
        small.historical_qualification.remaining_parent_failure_identifier_digest=C1ScientificDigest_v3(h.remaining_parent_failure_identifier);
        small.fork_geometry=pick(f.fork_geometry,{'source_pair','source_native_ids','symmetry','chord_distance','base_roundtrip_exact','base_energy', ...
            'map_evaluate_calls','source_direction_reversed'});small.fork_geometry.targets=cell(numel(f.fork_geometry.targets),1);
        for k=1:numel(f.fork_geometry.targets)
            t=f.fork_geometry.targets{k};x=pick(t,{'native_id','signed_sigma','sigma_in_declared_Run_bounds','target_roundtrip_exact', ...
                'target_parameter_mode_equal','target_used_as_seed','predictor_full13_separation','predictor_target_full13_scaled_inf'});
            x.target_matching_section=sectionView(t.target_matching_section);x.omitted_full_target_geometry_digest=C1ScientificDigest_v3(t);
            small.fork_geometry.targets{k}=x;
        end
        small.fork_geometry.omitted_full_geometry_digest=C1ScientificDigest_v3(f.fork_geometry);
        small.shortlist=pick(f.shortlist,{'selected_union','total_index_rows','eligible_count','total_unselected_count_UNASSESSED', ...
            'excluded_count_UNASSESSED','global_absence_claimed','reranking_after_native_load'});
        small.shortlist.omitted_full_shortlist_digest=C1ScientificDigest_v3(f.shortlist);
        small.projection_mode='bounded_scientific_scalar_fallback';small.omitted_compact_vector_projection_digest=normalDigest;
        small.projection_scope='Scalar fallback preserves actual record/target IDs,index/owner,T,E,meanU, finite comparison norms/energy/period/stride ratios+tolerances+flags, and signed PAL sigma. Full state/pq/stride vectors, raw comparison vectors, policy/chart/token and coordinate arrays are OMITTED with typed digests/counts; they are not claimed retained. No new calculation of the map/admission is performed.';
        small.comparison_scope=v.comparison_scope;v=small;
    end

    function out=selectionView(s)
        out=pick(s,{'selected_indices','native_read2_verified','return_timely'});out.records=cell(size(s.records));
        for i=1:numel(s.records)
            r=s.records{i};r.saved_full_closure_digest=C1ScientificDigest_v3(r.saved_full_closure);
            r=rmfield(r,{'saved_full_closure','metadata_binding'});r.section_chart=chartView(r.section_chart);out.records{i}=r;
        end
        out.native_index_scalar_observations=cell(size(s.native_index_scalar_observations));
        for i=1:numel(s.native_index_scalar_observations),out.native_index_scalar_observations{i}=rmfield(s.native_index_scalar_observations{i},'scope');end
        out.comparisons=packedComparisons(s.comparisons,true);out.physical_incident_edges=cell(size(s.physical_incident_edges));
        for i=1:numel(s.physical_incident_edges)
            rows=s.physical_incident_edges{i};out.physical_incident_edges{i}=cell(size(rows));
            for j=1:numel(rows),out.physical_incident_edges{i}{j}=edgeView(rows{j});end
        end
        if isempty(fieldnames(s.pair_match)),out.pair_match=struct();else,out.pair_match=sectionView(s.pair_match);end
    end
    function out=scalarSelection(s)
        out=pick(s,{'selected_indices','native_read2_verified','return_timely'});out.records=cell(size(s.records));
        for i=1:numel(s.records)
            r=s.records{i};owner=char(r.owner);out.records{i}=struct('index',r.index,'owner_prefix',owner(1:min(128,numel(owner))), ...
                'owner_char_count',numel(owner),'owner_digest',C1ScientificDigest_v3(r.owner),'owner_order',r.owner_order,'native_id',r.native_id, ...
                'period',r.period,'native_energy',r.native_energy,'signed_mean_U',r.full_stride(1)/r.period, ...
                'state_count',numel(r.state),'mode_count',numel(r.mode),'parameter_count',numel(r.parameter),'stride_count',numel(r.full_stride), ...
                'omitted_full_record_digest',C1ScientificDigest_v3(r));
        end
        out.comparisons=packedComparisons(s.comparisons,false);
        out.native_index_scalar_observations=cell(size(s.native_index_scalar_observations));
        for i=1:numel(s.native_index_scalar_observations),out.native_index_scalar_observations{i}=rmfield(s.native_index_scalar_observations{i},'scope');end
        out.omitted_full_selection_digest=C1ScientificDigest_v3(s);
    end
    function out=packedComparisons(rows,withVectors)
        out=struct('comparison_shape',size(rows),'linear_order','MATLAB column-major: selected record rows; target columns152,179', ...
            'scalar_columns',{{'raw_full13_scaled_inf','native_energy_delta','absolute_energy_tolerance','period_delta','period_tolerance','max_abs_stride_delta_over_component_tolerance'}}, ...
            'scalar_values',zeros(numel(rows),6),'flag_columns',{{'exact_p_q','exact_complete_policy','same_section_event_signature','conditions_met'}}, ...
            'flag_values',false(numel(rows),4),'matching_section',{cell(numel(rows),1)},'full_comparison_digests',{cell(numel(rows),1)});
        if withVectors,out.raw_full13_delta=zeros(13,numel(rows));out.full_stride_delta=zeros(14,numel(rows));out.full_stride_tolerance=zeros(14,numel(rows));end
        for i=1:numel(rows)
            c=rows{i};out.scalar_values(i,:)=[c.raw_full13_scaled_inf,c.native_energy_delta,c.absolute_energy_tolerance,c.period_delta,c.period_tolerance,max(abs(c.full_stride_delta)./c.full_stride_tolerance)];
            out.flag_values(i,:)=[c.exact_p_q,c.exact_complete_policy,c.same_section_event_signature,c.conditions_met];
            out.matching_section{i}=sectionView(c.matching_section);out.full_comparison_digests{i}=C1ScientificDigest_v3(c);
            if withVectors,out.raw_full13_delta(:,i)=c.raw_full13_delta;out.full_stride_delta(:,i)=c.full_stride_delta;out.full_stride_tolerance(:,i)=c.full_stride_tolerance;end
        end
        out.raw_full13_delta_count_per_comparison=13;out.full_stride_delta_count_per_comparison=14;out.full_stride_tolerance_count_per_comparison=14;
        out.raw_vectors_retained=withVectors;
    end
    function out=sectionView(m)
        out=pick(m,{'compatible','actual_policy_configuration_checked','policy_configuration_matches_declared_identity','rephase_or_chart_transition_inferred'});
        out.left_missing_field_count=numel(m.left_missing_fields);out.right_missing_field_count=numel(m.right_missing_fields);
        out.full_evidence_digest=C1ScientificDigest_v3(m);
    end
    function out=chartView(c)
        out=pick(c,{'id','geometry','crossing_orientation','boundary_ownership','translational_gauge'});
        if isfield(c,'BL_touchdowns_per_return'),out.BL_touchdowns_per_return=c.BL_touchdowns_per_return;end
        out.full_chart_field_count=numel(fieldnames(c));out.full_chart_digest=C1ScientificDigest_v3(c);out.nonidentity_chart_detail_omitted=true;
    end
    function out=edgeView(e)
        out=pick(e,{'from','to','component_identity'});out.full_edge_field_count=numel(fieldnames(e));out.full_edge_digest=C1ScientificDigest_v3(e);
    end
end
function p=partial(f,e,normal)
    p=struct('schema','C1-owned-PK-existing-P1-controls-observation-partial-v1','completed',false,'normal_summary_call_returned',normal, ...
        'own_process_exit_observed',false,'source_sha256',f.source_reference.sha256,'target_audit_load_calls_returned',f.target_audit_load_calls_returned, ...
        'index_calls_returned',f.index_calls_returned,'selected_load_calls_returned',f.selected_load_calls_returned, ...
        'target_native_read2_verified',f.target_native_read2_verified,'target_intake_header_calls_returned',f.target_intake_header_calls_returned, ...
        'target_intake_headers',{f.target_intake_headers},'index_read2_verified',f.index_read2_verified, ...
        'selected_compact_read2_verified',f.selected_compact_read2_verified,'source_posthash',f.source_posthash, ...
        'root_calls',f.root_calls,'map_evaluate_calls',f.map_evaluate_calls,'fine_calls',f.fine_calls, ...
        'journal_mutated',f.journal_mutated,'round_mutated',f.round_mutated,'raw_mutated',f.raw_mutated, ...
        'failure_header',failureHeader(e),'full_facts_omitted',true,'omission_scope','No target/owned arrays, full causes or any previous normal summary are repeated.');
end

function [witness,policyReport,signature]=storedSection(target,p,l)
    assert(strcmp(p.native_id,target.native_id)&&isequaln(p.initial_state,target.state)&&isfield(p,'section_chart')&&isfield(p,'section_event_signature'), ...
        'C1PKCol1:TargetSection','Use only the exact already-read2 admitted NEW P1 control chart/token.');
    configuration=target.policy_configuration;assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isstruct(configuration.settings)&&isscalar(configuration.settings)&&isfield(configuration.settings,'Name'), ...
        'C1PKCol1:Policy','Use actual complete historical BL1 policy settings.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));[~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration)&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKCol1:PolicyRoundtrip','Fresh constructor must roundtrip exact recorded BL1 policy.');
    witness=struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',target.mode,'section_chart',p.section_chart,'return_multiplicity',1);
    policyReport=struct('seed',struct('return_policy',policy));signature=p.section_event_signature;assert(strlength(string(signature))>0,'C1PKCol1:EventToken','The saved single target event token must be nonempty.');check(l);
end

function targetShapes(t,w)
    assert(isa(t.state,'double')&&isreal(t.state)&&isequal(size(t.state),[14 1])&&all(isfinite(t.state)) ...
        &&islogical(t.mode)&&isequal(size(t.mode),[4 1])&&isa(t.parameter,'double')&&isreal(t.parameter)&&isequal(size(t.parameter),[10 1])&&all(isfinite(t.parameter)) ...
        &&isa(t.full_stride,'double')&&isreal(t.full_stride)&&isequal(size(t.full_stride),[14 1])&&all(isfinite(t.full_stride)) ...
        &&isa(t.period,'double')&&isreal(t.period)&&isscalar(t.period)&&isfinite(t.period)&&t.period>0 ...
        &&isa(t.native_energy,'double')&&isreal(t.native_energy)&&isscalar(t.native_energy)&&isfinite(t.native_energy), ...
        'C1PKCol1:TargetShapes','Require exact finite native state14/mode4/p10/stride14 and scalar period/energy.');
    assert(ischar(t.native_id)&&isrow(t.native_id)&&~isempty(regexp(t.native_id,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1PKCol1:NativeID','Require the source-defined native record identity.');assert(isstruct(w.section_chart)&&isscalar(w.section_chart),'C1PKCol1:TargetChart','Retain actual marked chart.');
end

function h=pointHeader(o,r,m,ix,index)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&ix.index==index&&isstruct(m)&&isscalar(m)&&strcmp(ix.component_identity,m.component_identity), ...
        'C1PKCol1:PointBinding','Retain current native record index, owner and public metadata binding.');
    assert(isa(o.stride_displacement,'double')&&isequal(size(o.stride_displacement),[14 1])&&all(isfinite(o.stride_displacement)), ...
        'C1PKCol1:Stride','A complete finite native14 stride is required.');
    g=r.classification;[~,pe]=RecordedReturnPolicy_v3(r);
    h=struct('index',index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o), ...
        'state',o.initial_state,'mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full_stride',o.stride_displacement, ...
        'native_energy',QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter), ...
        'acceptance_gates',pick(r.acceptance_gates,{'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'}), ...
        'classification',pick(g,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'}), ...
        'policy_configuration',pe.configuration,'section_chart',o.section_chart, ...
        'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature, ...
        'event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'saved_full_closure',r.full_closure,'metadata_binding',struct('component_identity',m.component_identity,'index',ix.index,'order',ix.order));
end

function out=pick(s,keys)
    out=struct();for k=1:numel(keys),assert(isfield(s,keys{k}),'C1PKCol1:RequiredField','A required saved field is missing.');out.(keys{k})=s.(keys{k});end
end

function refs=references(refs)
    assert(iscell(refs)&&size(refs,2)==1,'C1PKCol1:ReferenceCells','Supply a column cell of explicit current protected references.');
    for k=1:numel(refs),refs{k}=checked(refs{k});end
end

function syntaxReferences(refs)
    assert(iscell(refs)&&isvector(refs),'C1PKCol1:HistoricalRefs','Retain literal reference cell shape without rehashing historical source paths.');
    for k=1:numel(refs),r=refs{k};exactFields(r,{'file','sha256'});assert(ischar(r.file)&&isrow(r.file)&&java.io.File(r.file).isAbsolute(),'C1PKCol1:ReferencePath','Require an absolute historical source path.');validSHA(r.sha256);end
end

function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end

function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end

function out=compareTarget(O,r,t,witness,policyReport,signature)
    section=MatchingReturnSection_v3(O,witness,{r,policyReport});[~,pe]=RecordedReturnPolicy_v3(r);
    delta=O.initial_state(2:14)-t.state(2:14);scale=max([ones(13,1),abs(O.initial_state(2:14)),abs(t.state(2:14))],[],2);
    dt=O.period-t.period;dq=O.stride_displacement-t.full_stride;qs=max([ones(size(dq)),abs(O.stride_displacement),abs(t.full_stride)],[],2);
    dE=QuadrupedEnergy_v3.evaluate(O.initial_state,O.initial_mode,O.parameter)-t.native_energy;
    out=struct('raw_full13_delta',delta,'raw_full13_scaled_inf',norm(delta./scale,inf),'native_energy_delta',dE,'absolute_energy_tolerance',1e-8, ...
        'period_delta',dt,'period_tolerance',1e-10*max([1,abs(O.period),abs(t.period)]),'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
        'exact_p_q',isequaln(O.parameter,t.parameter)&&isequaln(O.initial_mode,t.mode),'exact_complete_policy',pe.complete&&isequaln(pe.configuration,t.policy_configuration), ...
        'matching_section',section,'same_section_event_signature',strcmp(string(O.section_relative_event_signature),string(signature)), ...
        'conditions_met',false,'scope','Finite comparison to the independently qualified NEW P1 control control only: rawfull13/E1e-8, period/fullstride componentwise1e-10/maxscale, exactp/q/completepolicy/markedsection/events. No OriginalP1 stride/meanU, source membership, alias, union or endpoint theorem is inferred.');
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dE)<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
        &&out.exact_p_q&&out.exact_complete_policy&&section.compatible&&out.same_section_event_signature;
end

function strictPK(o,r,p)
keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};for k=1:numel(keys),assert(isequal(r.acceptance_gates.(keys{k}),true),'C1Pilot:AllNine','Require every literal original native admission gate.');end;g=r.classification;status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true)&&strcmp(g.contract_version,'quadruped-gait-v3.5')&&strcmp(g.validated_gait_type,'PK')&&isequal(g.flight_count_certain,true)&&g.flight_count==1&&isequal(g.canonical_label_qualified,true)&&isequaln(o.parameter(:),p(:)),'C1Pilot:PK','Require current qualified certain PK1 and unchanged parameters.');[policy,e]=RecordedReturnPolicy_v3(r);assert(e.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1Pilot:Policy','Require the actual complete BL1 section.');
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1P1Fixed:Resolver','Current source resolution differs from its guard.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1P1Fixed:Changed','A bound file changed.');end,end

function r=reference(f),assert(isfile(f),'C1P1Fixed:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function out=exceptionData(e),causes=cell(size(e.cause));for k=1:numel(causes),causes{k}=exceptionData(e.cause{k});end;out=struct('identifier',e.identifier,'message',e.message,'stack',e.stack,'causes',{causes});end

function value=member(s,k,f),value=f;if isstruct(s)&&isscalar(s)&&isfield(s,k),value=s.(k);end,end

function x=clockPair(),x=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function x=shift(x,s),x.utc=x.utc+s;x.mono=x.mono+s*1e9;end

function x=left(l),x=min(l.utc-posixtime(datetime('now','TimeZone','UTC')),(l.mono-double(java.lang.System.nanoTime))/1e9);end

function check(l),assert(left(l)>0,'C1P1Fixed:Clock','The original local/science whole-call clock expired.');end

function x=canonical(x),x=char(java.io.File(char(x)).getCanonicalPath());end

function x=formatUTC(s),x=char(datetime(s,'ConvertFrom','posixtime','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function x=stamp(),x=formatUTC(posixtime(datetime('now','TimeZone','UTC')));end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

function quiet(ledger,raw,roundFile)
    cp=[ledger(1:end-4),'_active_checkpoint.mat'];paths={cp,[cp,'.pending.mat'],[ledger,'.pending.mat'],[roundFile,'.pending.mat'],[roundFile(1:end-4),'.pending.mat'],[roundFile(1:end-4),'.json.pending.json']};
    for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1:Pending','Reconcile existing owned checkpoint/stage before this stored-only observation.');end
    d=dir(fileparts(raw));d=d(~ismember({d.name},{'.','..'}));[~,n,e]=fileparts(raw);
    assert(numel(d)==1&&~d.isdir&&strcmp(d.name,[n e]),'C1PKCol1:RawDirectory','The primary raw directory must retain exactly its one current file, with no unknown stage.');
end

function h=failureHeader(e)
    id=e.identifier;message=e.message;stack=e.stack;
    h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'identifier_truncated',numel(id)>128, ...
        'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256, ...
        'stack_frame_count',numel(stack),'first_stack_frame',struct(),'stack_detail_omitted',numel(stack)>1,'cause_count',numel(e.cause));
    if ~isempty(stack)
        a=stack(1);h.first_stack_frame=struct('file_prefix',a.file(1:min(numel(a.file),128)),'file_char_count',numel(a.file),'file_truncated',numel(a.file)>128, ...
            'name_prefix',a.name(1:min(numel(a.name),96)),'name_char_count',numel(a.name),'name_truncated',numel(a.name)>96,'line',a.line);
    end
end
