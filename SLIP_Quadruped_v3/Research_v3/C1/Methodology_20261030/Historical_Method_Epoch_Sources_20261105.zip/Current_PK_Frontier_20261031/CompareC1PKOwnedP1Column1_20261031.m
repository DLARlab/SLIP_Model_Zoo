function facts=CompareC1PKOwnedP1Column1_20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,options)
%COMPAREC1PKOWNEDP1COLUMN1_20261031 Stored-only three-owned/NEWcol1 comparison.
% No Root, map, ODE, replay, fine, admission, ownership or status mutation.
% The original P1 state is not admitted by this comparison. All flags are finite.
    started=clockPair();
    validSHA(expectedLedgerSHA);validSHA(expectedRawSHA);validSHA(expectedRoundSHA);
    required={'TargetInputReference','TargetQualificationReference','TargetRawReference','HistoricalClosureReference','ProtectedReferences'};
    exactFields(options,required);o=options;
    o.TargetInputReference=checked(o.TargetInputReference);o.TargetQualificationReference=checked(o.TargetQualificationReference);
    o.TargetRawReference=checked(o.TargetRawReference);o.HistoricalClosureReference=checked(o.HistoricalClosureReference);
    assert(strcmp(o.TargetInputReference.sha256,'7271b42befe2b47426ded73031d0833dc1a4dd1f34a17498515e2c5cc72c0652') ...
        &&strcmp(o.TargetQualificationReference.sha256,'210a54d6282acd0abe57ecf6fce491c52d78329a01adfe72b136554fba683a28') ...
        &&strcmp(o.TargetRawReference.sha256,'cf8a0a2af207955a8ba8cc228548e4012f3310e5e1d5dc5e7a297c917ee5a87a') ...
        &&strcmp(o.HistoricalClosureReference.sha256,'9d0dd2ee6f174934fb35d1193b8e4f9de1e58df4db45d13b6ae60963862b0759'), ...
        'C1PKCol1:HistoricalPins','Only the exact retained NEWcol1 authorities and original Short01 custody bytes are permitted.');
    root=canonical(fileparts(which('C1RunBudget_v3')));budget=C1RunBudget_v3();
    finish=shift(started,600);work=shift(finish,-120);
    assert(finish.utc<budget.research_deadline_unix_seconds&&finish.mono<budget.research_deadline_monotonic_ns, ...
        'C1PKCol1:WholeFit','The full600 seconds including120 reserve must fit BOTH unchanged science clocks.');check(work);
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));
    raw=canonical(fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'));
    roundFile=canonical(fullfile(root,'Audits','PK36h_20261031_Round.mat'));
    live={struct('file',ledger,'sha256',expectedLedgerSHA);struct('file',raw,'sha256',expectedRawSHA);struct('file',roundFile,'sha256',expectedRoundSHA)};
    protected=references(o.ProtectedReferences);self=reference(which(mfilename));code=currentCode(self);
    refs=[live;{o.TargetInputReference;o.TargetQualificationReference;o.TargetRawReference;o.HistoricalClosureReference};protected];
    selectors=[464;465;466];
    facts=struct('schema','C1-owned-PK-NEWcol1-stored-comparison-v1','source_reference',self,'budget',budget, ...
        'declared_seconds',600,'save_post_reserve_seconds',120,'expected_current_references',{live}, ...
        'target_input_reference',o.TargetInputReference,'target_qualification_reference',o.TargetQualificationReference, ...
        'target_raw_reference',o.TargetRawReference,'historical_closure_reference',o.HistoricalClosureReference, ...
        'actual_method_references',{code},'selected_owned_indices',selectors,'target',struct(),'owned',{{}},'comparisons',{{}}, ...
        'target_native_read2_verified',false,'target_audit_loads_returned',0,'current_journal_decoded',false,'index_read2_verified',false, ...
        'index_calls_returned',0,'selected_load_calls_returned',0,'selected_load_return_timely',false(2,1), ...
        'selected_compact_read2_verified',false,'source_posthash',false,'completed',false,'failure',struct(), ...
        'root_calls',0,'map_calls',0,'fine_calls',0,'native_raw_target_deserialized',false, ...
        'all_four_target_cohorts_available',false,'all_four_target_cohorts_claimed',false, ...
        'target_cohort_scope','Four target cohorts are unassessed/not established by this one-token protocol; false is not proof that those saved cohorts are absent.', ...
        'frontier_reset',false,'ownership_changed',false,'journal_mutated',false,'round_mutated',false,'raw_mutated',false, ...
        'canonical_graph_mutated',false,'P1_original_state_admission_claimed',false,'scheduled_v2_stride_equivalence_claimed',false, ...
        'physical_attachment_claimed',false,'exact_identity_claimed',false,'endpoint_claimed',false,'global_completion_claimed',false, ...
        'own_process_exit_observed',false,'started_utc',stamp(),'finished_utc','', ...
        'closed_boundary_scope','Caller/external actual closed custody supplies current ledger/Round SHA; this helper locks the existing writer inode and checks checkpoint/stage absence but does not decode the current ledger or Round.','public_api_count_scope','Two explicit public index calls plus two selected bulk loads; each bulk load also internally validates the whole index.','read2_scope','Two independent selected native loads reduced to identical declared compact states/admission/identity/metadata bindings/comparisons. Dense trajectories, runtime callback workspaces and full reports are not claimed equal.', ...
        'scope','Fixed known owned records464/465/466 versus the separately qualified NEWcol1 control. Stored-only finite comparison; no selector, frontier eligibility, admission, graph or connection is changed.');
    normalSummaryReturned=false;
    try
        guard(work);
        assert(isfile([ledger,'.writer.lock']),'C1PKCol1:ExistingLock','Use the existing stable writer-lock inode.');
        lock=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
        [target,historical,targetPoint]=storedTarget(o,work,@observedTwice);facts.target_native_read2_verified=true;facts.historical_qualification=historical;
        [witness,policyReport,signature]=storedSection(target,targetPoint,work);targetShapes(target,witness);
        facts.target=struct('role',target.role,'native_id',target.native_id,'state',target.state,'mode',target.mode, ...
            'parameter',target.parameter,'period',target.period,'full_stride',target.full_stride,'native_energy',target.native_energy, ...
            'policy_configuration',target.policy_configuration,'section_chart',witness.section_chart,'section_event_signature',signature);
        guard(work);fprintf('C1_PK_COL1_BEFORE_INDEX1\n');ix=BranchSolutionFile_v3.index(raw);facts.index_calls_returned=1;fprintf('C1_PK_COL1_AFTER_INDEX1_RETURN\n');check(work);
        guard(work);fprintf('C1_PK_COL1_BEFORE_INDEX2\n');ix2=BranchSolutionFile_v3.index(raw);facts.index_calls_returned=2;fprintf('C1_PK_COL1_AFTER_INDEX2_RETURN\n');check(work);
        assert(isequaln(ix,ix2),'C1PKCol1:IndexRead2','Two entire current public indices must agree.');clear ix2
        facts.index_read2_verified=true;facts.source_point_count=numel(ix.points);assert(numel(ix.points)>=466,'C1PKCol1:Indices','All three fixed owned records must exist.');
        facts.physical_edge_bindings=physicalBindings(ix,selectors);
        principal=[10;10;20;20;1;1;0;0;2;.5];first=cell(3,1);firstComparisons=cell(3,1);
        guard(work);fprintf('C1_PK_COL1_BEFORE_SELECTED_LOAD1\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(raw,selectors);facts.selected_load_calls_returned=1;fprintf('C1_PK_COL1_AFTER_SELECTED_LOAD1_RETURN\n');facts.selected_load_return_timely(1)=left(work)>0;check(work);
        assert(isequal(size(O),[3 1])&&isequal(size(R),[3 1])&&isequal(size(M),[3 1]),'C1PKCol1:SelectedShape','Public selected results must retain requested column order.');
        for k=1:3
            strictPK(O{k},R{k},principal);first{k}=pointHeader(O{k},R{k},M{k},ix.points{selectors(k)},selectors(k));
            firstComparisons{k}=compareTarget(O{k},R{k},target,witness,policyReport,signature);
        end
        clear O R M
        guard(work);fprintf('C1_PK_COL1_BEFORE_SELECTED_LOAD2\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(raw,selectors);facts.selected_load_calls_returned=2;fprintf('C1_PK_COL1_AFTER_SELECTED_LOAD2_RETURN\n');facts.selected_load_return_timely(2)=left(work)>0;check(work);
        assert(isequal(size(O),[3 1])&&isequal(size(R),[3 1])&&isequal(size(M),[3 1]),'C1PKCol1:SelectedShape','Public selected results must retain requested column order.');
        for k=1:3
            strictPK(O{k},R{k},principal);second=pointHeader(O{k},R{k},M{k},ix.points{selectors(k)},selectors(k));comparison=compareTarget(O{k},R{k},target,witness,policyReport,signature);
            assert(isequaln(first{k},second)&&isequaln(firstComparisons{k},comparison),'C1PKCol1:SelectedRead2','Declared compact public values and every comparison field must agree across independent acquisitions.');
        end
        clear O R M second comparison ix
        facts.owned=first;facts.comparisons=firstComparisons;facts.selected_compact_read2_verified=true;
        facts.comparison_passed=cellfun(@(x)x.conditions_met,firstComparisons);
        facts.read2_digest=C1ScientificDigest_v3(struct('target',facts.target,'owned',{first},'comparisons',{firstComparisons},'physical_edge_bindings',{facts.physical_edge_bindings}));
        guard(finish);facts.source_posthash=true;facts.finished_utc=stamp();facts.completed=true;check(finish);
        encoded=jsonencode(facts);assert(numel(unicode2native(encoded,'UTF-8'))<=50000,'C1PKCol1:SummaryBytes','The full normal structured summary exceeds the declared50000 UTF8-byte bound; emit only a bounded partial receipt.');
        fprintf('C1_PK_COL1_BEFORE_FINAL_SUMMARY\n');fprintf('C1_PK_COL1_STORED_COMPARISON_ACTUAL_RETURN %s\n',encoded);normalSummaryReturned=true;fprintf('C1_PK_COL1_AFTER_FINAL_SUMMARY_RETURN\n');guard(finish);
    catch problem
        facts.completed=false;facts.failure=exceptionData(problem);facts.finished_utc=stamp();
        partial=partialSummary(facts,problem,normalSummaryReturned);encoded=jsonencode(partial);
        if numel(unicode2native(encoded,'UTF-8'))>7000
            partial.failure_header.message_prefix='';partial.failure_header.message_truncated=true;partial.failure_header.first_stack_frame=struct();partial.failure_header.stack_detail_omitted=true;encoded=jsonencode(partial);
        end
        assert(numel(unicode2native(encoded,'UTF-8'))<=7000,'C1PKCol1:PartialBytes','The bounded fixed-schema partial receipt must remain within7000 UTF8 bytes.');
        fprintf('C1_PK_COL1_STORED_COMPARISON_PARTIAL %s\n',encoded);rethrow(problem);
    end
    function out=observedTwice(file,key,label,limit)
        check(limit);fprintf('C1_PK_COL1_BEFORE_TARGET_AUDIT_LOAD1 %s\n',label);a=load(file,'-mat',key);facts.target_audit_loads_returned=facts.target_audit_loads_returned+1;fprintf('C1_PK_COL1_AFTER_TARGET_AUDIT_LOAD1_RETURN %s\n',label);check(limit);
        fprintf('C1_PK_COL1_BEFORE_TARGET_AUDIT_LOAD2 %s\n',label);b=load(file,'-mat',key);facts.target_audit_loads_returned=facts.target_audit_loads_returned+1;fprintf('C1_PK_COL1_AFTER_TARGET_AUDIT_LOAD2_RETURN %s\n',label);check(limit);
        assert(isequaln(a.(key),b.(key)),'C1PKCol1:TargetRead2','Two whole historical plain audit reads must agree.');out=a.(key);check(limit);
    end
    function guard(limit)
        check(limit);quiet(ledger,raw,roundFile);verify(refs);verifyCode(code);assert(isequaln(C1RunBudget_v3(),budget),'C1PKCol1:BudgetValue','The immutable grant value must remain literal.');check(limit);
    end
end
function p=partialSummary(f,e,normalReturned)
    p=struct('schema','C1-owned-PK-NEWcol1-stored-comparison-partial-v1','completed',false, ...
        'normal_summary_call_returned',normalReturned,'own_process_exit_observed',false, ...
        'source_sha256',f.source_reference.sha256,'selected_owned_indices',f.selected_owned_indices, ...
        'target_audit_loads_returned',f.target_audit_loads_returned,'target_native_read2_verified',f.target_native_read2_verified, ...
        'index_calls_returned',f.index_calls_returned,'index_read2_verified',f.index_read2_verified, ...
        'selected_load_calls_returned',f.selected_load_calls_returned,'selected_load_return_timely',f.selected_load_return_timely, ...
        'selected_compact_read2_verified',f.selected_compact_read2_verified,'source_posthash',f.source_posthash, ...
        'root_calls',f.root_calls,'map_calls',f.map_calls,'fine_calls',f.fine_calls, ...
        'native_raw_target_deserialized',f.native_raw_target_deserialized,'current_journal_decoded',f.current_journal_decoded, ...
        'frontier_reset',f.frontier_reset,'ownership_changed',f.ownership_changed,'journal_mutated',f.journal_mutated, ...
        'round_mutated',f.round_mutated,'raw_mutated',f.raw_mutated,'canonical_graph_mutated',f.canonical_graph_mutated, ...
        'comparison_passed',[],'failure_header',failureHeader(e),'full_facts_omitted',true, ...
        'omission_scope','Only actual compact counters/flags and a bounded original failure header are emitted. Target/candidate arrays, full reports, nested causes and any prior normal summary are not repeated.');
    if isfield(f,'comparison_passed'),p.comparison_passed=f.comparison_passed;end
end
function h=failureHeader(e)
    id=e.identifier;message=e.message;stack=e.stack;
    h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'identifier_truncated',numel(id)>128, ...
        'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256, ...
        'stack_frame_count',numel(stack),'first_stack_frame',struct(),'stack_detail_omitted',numel(stack)>1,'cause_count',numel(e.cause));
    if ~isempty(stack)
        a=stack(1);h.first_stack_frame=struct('file_prefix',a.file(1:min(numel(a.file),128)),'file_char_count',numel(a.file),'file_truncated',numel(a.file)>128, ...
            'name_prefix',a.name(1:min(numel(a.name),96)),'name_char_count',numel(a.name),'name_truncated',numel(a.name)>96,'line',a.line);
    end
end

function [t,h,p]=storedTarget(o,l,read2)
    a=read2(o.TargetInputReference.file,'audit','intake7271',l);assert(isstruct(a)&&isscalar(a)&&isequal(a.completed,true)&&isequal(a.source_posthash,true)&&isempty(fieldnames(a.failure)), ...
        'C1PKCol1:TargetIntake','Require the exact complete independently qualified target intake.');
    assert(iscell(a.targets)&&~isempty(a.targets),'C1PKCol1:Targets','Use the original first target without a numerical selector.');t=a.targets{1};
    assert(strcmp(t.role,'P1_col1_NEW_qualified_control')&&isequaln(t.authority.audit_reference,o.TargetQualificationReference)&&isequaln(t.authority.final_raw_reference,o.TargetRawReference), ...
        'C1PKCol1:TargetAuthority','Use exact named NEWcol1 authority; not UNIT or OriginalP1 raw.');
    old=read2(o.TargetQualificationReference.file,'audit','qualified210a',l);assert(iscell(old.rows)&&~isempty(old.rows),'C1PKCol1:TargetRow','Retain original first delegated row.');r=old.rows{1};
    assert(isequal(old.completed,false)&&isequal(old.source_posthash,false)&&r.original.original_column==1 ...
        &&isequal(r.qualified_new_control,true)&&isequal(r.finite_original_column_conditions_met,true)&&isequal(r.native_all_nine,true)&&isequal(r.initial_anchor_control.passed,true) ...
        &&numel(r.fines)==2&&all(cellfun(@(f)isequal(f.passed,true)&&isequal(f.observation.returned,true)&&isequal(f.observation.return_timely,true)&&isequal(f.raw_custody.storage_timely,true)&&isequal(f.raw_custody.readback_timely,true),r.fines)), ...
        'C1PKCol1:LocalQualification','Historical global false and actual local qualified NEWcol1/two original timely fines must remain distinct.');
    p=r.new_point;assert(strcmp(t.native_id,p.native_id)&&isequaln(t.state,p.initial_state)&&isequaln(t.mode,p.mode)&&isequaln(t.parameter,p.parameter)&&isequaln(t.period,p.period)&&isequaln(t.full_stride,p.full_stride), ...
        'C1PKCol1:TargetValues','Bind every identity-bearing plain target value to the independently admitted row.');
    syntaxReferences(a.source_code);c=jsondecode(fileread(o.HistoricalClosureReference.file));
    assert(isstruct(c)&&isscalar(c)&&isstruct(c.child)&&c.child.child_exit_code==0&&c.child.child_pid==7809&&c.metadata.completed&&c.metadata.source_posthash ...
        &&isempty(fieldnames(c.metadata.failure))&&~c.metadata.native_pending_present&&c.metadata.native_all_nine&&c.metadata.qualified_nonedge_control&&c.metadata.finite_NEW_col1_conditions_met ...
        &&islogical(c.metadata.endpoint_fines_passed)&&numel(c.metadata.endpoint_fines_passed)==2&&all(c.metadata.endpoint_fines_passed(:)) ...
        &&islogical(c.metadata.control_fines_passed)&&numel(c.metadata.control_fines_passed)==2&&all(c.metadata.control_fines_passed(:)) ...
        &&c.metadata.prepared_requests==5&&c.metadata.actual_requests_invoked==5&&c.metadata.actual_requests_returned==5, ...
        'C1PKCol1:HistoricalClosure','Retain actual original Short01 process closure and finite comparison scope.');
    h=struct('target_source_code_historical_syntax_only',{a.source_code},'original_column',r.original.original_column, ...
        'historical_parent_completed',old.completed,'historical_parent_source_posthash',old.source_posthash, ...
        'local_native_all_nine',r.native_all_nine,'qualified_new_control',r.qualified_new_control, ...
        'finite_original_column_conditions_met',r.finite_original_column_conditions_met,'initial_anchor_passed',r.initial_anchor_control.passed, ...
        'original_solved_control_fine_passed',cellfun(@(x)x.passed,r.fines),'raw_target_deserialized',false, ...
        'short01_child_exit_code',c.child.child_exit_code,'short01_child_pid',c.child.child_pid, ...
        'short01_finite_NEW_col1_conditions_met',c.metadata.finite_NEW_col1_conditions_met, ...
        'scope','Historical pinned NEWcontrol qualification and actual closed endpoint-control comparison; never original legacy-state admission, old global flag upgrade or present process exit.');check(l);
end
function [witness,policyReport,signature]=storedSection(target,p,l)
    assert(strcmp(p.native_id,target.native_id)&&isequaln(p.initial_state,target.state)&&isfield(p,'section_chart')&&isfield(p,'section_event_signature'), ...
        'C1PKCol1:TargetSection','Use only the exact already-read2 admitted NEWcol1 chart/token.');
    configuration=target.policy_configuration;assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isstruct(configuration.settings)&&isscalar(configuration.settings)&&isfield(configuration.settings,'Name'), ...
        'C1PKCol1:Policy','Use actual complete historical BL1 policy settings.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));[~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration)&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKCol1:PolicyRoundtrip','Fresh constructor must roundtrip exact recorded BL1 policy.');
    witness=struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',target.mode,'section_chart',p.section_chart,'return_multiplicity',1);
    policyReport=struct('seed',struct('return_policy',policy));signature=p.section_event_signature;assert(strlength(string(signature))>0,'C1PKCol1:EventToken','The saved single target event token must be nonempty.');check(l);
end
function targetShapes(t,w)
    assert(isa(t.state,'double')&&isreal(t.state)&&isequal(size(t.state),[14 1])&&all(isfinite(t.state)) ...
        &&islogical(t.mode)&&isequal(size(t.mode),[4 1])&&isa(t.parameter,'double')&&isreal(t.parameter)&&isequal(size(t.parameter),[10 1])&&all(isfinite(t.parameter)) ...
        &&isa(t.full_stride,'double')&&isreal(t.full_stride)&&isequal(size(t.full_stride),[14 1])&&all(isfinite(t.full_stride)) ...
        &&isa(t.period,'double')&&isreal(t.period)&&isscalar(t.period)&&isfinite(t.period)&&t.period>0 ...
        &&isa(t.native_energy,'double')&&isreal(t.native_energy)&&isscalar(t.native_energy)&&isfinite(t.native_energy), ...
        'C1PKCol1:TargetShapes','Require exact finite native state14/mode4/p10/stride14 and scalar period/energy.');
    assert(ischar(t.native_id)&&isrow(t.native_id)&&~isempty(regexp(t.native_id,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1PKCol1:NativeID','Require the source-defined native record identity.');assert(isstruct(w.section_chart)&&isscalar(w.section_chart),'C1PKCol1:TargetChart','Retain actual marked chart.');
end
function quiet(ledger,raw,roundFile)
    cp=[ledger(1:end-4),'_active_checkpoint.mat'];paths={cp,[cp,'.pending.mat'],[ledger,'.pending.mat'],[roundFile,'.pending.mat'],[roundFile(1:end-4),'.pending.mat'],[roundFile(1:end-4),'.json.pending.json']};
    for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1:Pending','Reconcile existing owned checkpoint/stage before this stored-only observation.');end
    d=dir(fileparts(raw));d=d(~ismember({d.name},{'.','..'}));[~,n,e]=fileparts(raw);
    assert(numel(d)==1&&~d.isdir&&strcmp(d.name,[n e]),'C1PKCol1:RawDirectory','The primary raw directory must retain exactly its one current file, with no unknown stage.');
end
function b=physicalBindings(ix,selectors)
    b=cell(2,1);
    for k=1:2
        hit=find(cellfun(@(e)e.from==selectors(k)&&e.to==selectors(k+1),ix.edges));
        assert(isscalar(hit),'C1PKCol1:PhysicalEdge','Require the actual literal owned464-to465 and465-to466 edges.');e=ix.edges{hit};
        a=ix.points{selectors(k)};z=ix.points{selectors(k+1)};
        assert(strcmp(e.component_identity,a.component_identity)&&strcmp(e.component_identity,z.component_identity), ...
            'C1PKCol1:OwnerEdge','Stored physical edges and both native occurrences must retain their actual common owner.');b{k}=e;
    end
end
function h=pointHeader(o,r,m,ix,index)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&ix.index==index&&isstruct(m)&&isscalar(m)&&strcmp(ix.component_identity,m.component_identity), ...
        'C1PKCol1:PointBinding','Retain current native record index, owner and public metadata binding.');
    assert(isa(o.stride_displacement,'double')&&isequal(size(o.stride_displacement),[14 1])&&all(isfinite(o.stride_displacement)), ...
        'C1PKCol1:Stride','A complete finite native14 stride is required.');
    g=r.classification;[~,pe]=RecordedReturnPolicy_v3(r);
    h=struct('index',index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o), ...
        'state',o.initial_state,'mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full_stride',o.stride_displacement, ...
        'native_energy',QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter), ...
        'acceptance_gates',pick(r.acceptance_gates,{'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'}), ...
        'classification',pick(g,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'}), ...
        'policy_configuration',pe.configuration,'section_chart',o.section_chart, ...
        'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature, ...
        'event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'saved_full_closure',r.full_closure,'metadata_binding',struct('component_identity',m.component_identity,'index',ix.index,'order',ix.order));
end
function code=currentCode(self)
    names={'C1RunBudget_v3','BranchSolutionFile_v3','QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3', ...
        'QuadrupedAdmissibility_v3','ContinuousDynamics_v3','RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3', ...
        'MatchingReturnSection_v3','OrbitContentIdentity_v3','HybridOrbit_v3','Trajectory_v3','RoundSHA256_v3','C1ScientificDigest_v3'};
    code={self};for k=1:numel(names),code{end+1,1}=reference(which(names{k}));end
end
function out=pick(s,keys)
    out=struct();for k=1:numel(keys),assert(isfield(s,keys{k}),'C1PKCol1:RequiredField','A required saved field is missing.');out.(keys{k})=s.(keys{k});end
end
function refs=references(refs)
    assert(iscell(refs)&&size(refs,2)==1,'C1PKCol1:ReferenceCells','Supply a column cell of explicit current protected references.');
    for k=1:numel(refs),refs{k}=checked(refs{k});end
end
function syntaxReferences(refs)
    assert(iscell(refs)&&isvector(refs),'C1PKCol1:HistoricalRefs','Retain literal reference cell shape without rehashing historical source paths.');
    for k=1:numel(refs),r=refs{k};exactFields(r,{'file','sha256'});assert(ischar(r.file)&&isrow(r.file)&&java.io.File(r.file).isAbsolute(),'C1PKCol1:ReferencePath','Require an absolute historical source path.');validSHA(r.sha256);end
end
function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end
function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end

function out=compareTarget(O,r,t,witness,policyReport,signature)
    section=MatchingReturnSection_v3(O,witness,{r,policyReport});[~,pe]=RecordedReturnPolicy_v3(r);
    delta=O.initial_state(2:14)-t.state(2:14);scale=max([ones(13,1),abs(O.initial_state(2:14)),abs(t.state(2:14))],[],2);
    dt=O.period-t.period;dq=O.stride_displacement-t.full_stride;qs=max([ones(size(dq)),abs(O.stride_displacement),abs(t.full_stride)],[],2);
    dE=QuadrupedEnergy_v3.evaluate(O.initial_state,O.initial_mode,O.parameter)-t.native_energy;
    out=struct('raw_full13_delta',delta,'raw_full13_scaled_inf',norm(delta./scale,inf),'native_energy_delta',dE,'absolute_energy_tolerance',1e-8, ...
        'period_delta',dt,'period_tolerance',1e-10*max([1,abs(O.period),abs(t.period)]),'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
        'exact_p_q',isequaln(O.parameter,t.parameter)&&isequaln(O.initial_mode,t.mode),'exact_complete_policy',pe.complete&&isequaln(pe.configuration,t.policy_configuration), ...
        'matching_section',section,'same_section_event_signature',strcmp(string(O.section_relative_event_signature),string(signature)), ...
        'conditions_met',false,'scope','Finite comparison to the independently qualified NEWcol1 control only: rawfull13/E1e-8, period/fullstride componentwise1e-10/maxscale, exactp/q/completepolicy/markedsection/events. No OriginalP1 stride/meanU, source membership, alias, union or endpoint theorem is inferred.');
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dE)<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
        &&out.exact_p_q&&out.exact_complete_policy&&section.compatible&&out.same_section_event_signature;
end

function strictPK(o,r,p)
keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};for k=1:numel(keys),assert(isequal(r.acceptance_gates.(keys{k}),true),'C1Pilot:AllNine','Require every literal original native admission gate.');end;g=r.classification;status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true)&&strcmp(g.contract_version,'quadruped-gait-v3.5')&&strcmp(g.validated_gait_type,'PK')&&isequal(g.flight_count_certain,true)&&g.flight_count==1&&isequal(g.canonical_label_qualified,true)&&isequaln(o.parameter(:),p(:)),'C1Pilot:PK','Require current qualified certain PK1 and unchanged parameters.');[policy,e]=RecordedReturnPolicy_v3(r);assert(e.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1Pilot:Policy','Require the actual complete BL1 section.');
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1P1Fixed:Resolver','Current source resolution differs from its guard.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1P1Fixed:Changed','A bound file changed.');end,end

function r=reference(f),assert(isfile(f),'C1P1Fixed:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function out=exceptionData(e),causes=cell(size(e.cause));for k=1:numel(causes),causes{k}=exceptionData(e.cause{k});end;out=struct('identifier',e.identifier,'message',e.message,'stack',e.stack,'causes',{causes});end

function value=member(s,k,f),value=f;if isstruct(s)&&isscalar(s)&&isfield(s,k),value=s.(k);end,end

function x=clockPair(),x=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function x=shift(x,s),x.utc=x.utc+s;x.mono=x.mono+s*1e9;end

function x=left(l),x=min(l.utc-posixtime(datetime('now','TimeZone','UTC')),(l.mono-double(java.lang.System.nanoTime))/1e9);end

function check(l),assert(left(l)>0,'C1P1Fixed:Clock','The original local/science whole-call clock expired.');end

function x=canonical(x),x=char(java.io.File(char(x)).getCanonicalPath());end

function x=formatUTC(s),x=char(datetime(s,'ConvertFrom','posixtime','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function x=stamp(),x=formatUTC(posixtime(datetime('now','TimeZone','UTC')));end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

