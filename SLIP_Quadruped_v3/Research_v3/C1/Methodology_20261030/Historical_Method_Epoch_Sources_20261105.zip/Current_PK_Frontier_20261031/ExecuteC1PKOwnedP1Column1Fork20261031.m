function facts=ExecuteC1PKOwnedP1Column1Fork20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,options)
% One fresh native PAL fork. No primary/journal/frontier reset or merge.
    entry=clockPair();validSHA(expectedLedgerSHA);validSHA(expectedRawSHA);validSHA(expectedRoundSHA);
    exactFields(options,{'TargetInputReference','TargetQualificationReference','TargetRawReference','HistoricalClosureReference', ...
        'HistoricalComparisonClosureReference','OutputFile','CheckpointFile','ComponentIdentity','ProtectedReferences'});o=options;
    for key={'TargetInputReference','TargetQualificationReference','TargetRawReference','HistoricalClosureReference','HistoricalComparisonClosureReference'},o.(key{1})=checked(o.(key{1}));end
    assert(strcmp(o.TargetInputReference.sha256,'7271b42befe2b47426ded73031d0833dc1a4dd1f34a17498515e2c5cc72c0652') ...
        &&strcmp(o.TargetQualificationReference.sha256,'210a54d6282acd0abe57ecf6fce491c52d78329a01adfe72b136554fba683a28') ...
        &&strcmp(o.TargetRawReference.sha256,'cf8a0a2af207955a8ba8cc228548e4012f3310e5e1d5dc5e7a297c917ee5a87a') ...
        &&strcmp(o.HistoricalClosureReference.sha256,'9d0dd2ee6f174934fb35d1193b8e4f9de1e58df4db45d13b6ae60963862b0759') ...
        &&strcmp(o.HistoricalComparisonClosureReference.sha256,'7b6786e78836ec8b5238bd53d9ce199ea794434d6adf136e1932969f6b690b05'), ...
        'C1PKFork:Authorities','Bind exact earned NEWcol1 and actual0061 closed-comparison authorities.');
    root=canonical(fileparts(which('C1RunBudget_v3')));budget=C1RunBudget_v3();finish=shift(entry,900);work=shift(finish,-120);
    assert(finish.utc<budget.research_deadline_unix_seconds&&finish.mono<budget.research_deadline_monotonic_ns,'C1PKFork:WholeFit','All900 seconds including120 reserve must fit BOTH original science clocks.');check(work);
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));raw=canonical(fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'));
    roundFile=canonical(fullfile(root,'Audits','PK36h_20261031_Round.mat'));o.OutputFile=canonical(o.OutputFile);o.CheckpointFile=canonical(o.CheckpointFile);
    assert(ischar(o.ComponentIdentity)&&isrow(o.ComponentIdentity)&&~isempty(regexp(o.ComponentIdentity,'^[A-Za-z][A-Za-z0-9_-]{0,95}$','once')),'C1PKFork:Owner','Declare an explicit fresh unique owner.');
    assert(strcmp(fileparts(o.OutputFile),canonical(fullfile(root,'Results')))&&strcmp(fileparts(o.CheckpointFile),canonical(fullfile(root,'Audits'))) ...
        &&endsWith(o.OutputFile,'.mat')&&endsWith(o.CheckpointFile,'.mat'),'C1PKFork:Paths','Use a fresh Results fork and separate Audits checkpoint.');
    assert(isfield(budget,'result_suffix')&&isequal(budget.result_suffix,'_20261031'),'C1PKFork:Suffix','Keep the unchanged original result suffix.');
    isolated=canonical(fullfile(root,'Results',['C1_Isolated_Native_Admissions',budget.result_suffix,'.mat']));
    live={struct('file',ledger,'sha256',expectedLedgerSHA);struct('file',raw,'sha256',expectedRawSHA);struct('file',roundFile,'sha256',expectedRoundSHA)};
    protected=references(o.ProtectedReferences);self=reference(which(mfilename));code=forkCode(self,protected);
    refs=[live;{o.TargetInputReference;o.TargetQualificationReference;o.TargetRawReference;o.HistoricalClosureReference;o.HistoricalComparisonClosureReference};protected];
    writes={o.OutputFile;o.CheckpointFile;[o.CheckpointFile,'.pending.mat'];[o.OutputFile,'.pending.mat'];isolated;[isolated,'.pending.mat']};freshPaths(writes);
    assert(numel(unique(writes))==numel(writes),'C1PKFork:DistinctWrites','All write paths must be distinct.');
    for k=1:numel(refs),assert(~any(strcmp(refs{k}.file,writes)),'C1PKFork:ProtectedWrite','No output may alias an immutable input.');end
    beforeResults=directoryNames(fileparts(o.OutputFile));beforeAudits=directoryNames(fileparts(o.CheckpointFile));
    facts=struct('schema','C1-owned-PK-NEWcol1-single-fork-v1','source_reference',self,'budget',budget,'wrapper_entry',entry,'wrapper_finish',finish,'wrapper_work',work, ...
        'wrapper_seconds',900,'outer_post_reserve_seconds',120,'Run_save_margin_seconds',120,'original_trial_seconds',240, ...
        'expected_current_references',{live},'actual_method_references',{code},'source_pair',[464 465],'source_pair_read2_verified',false, ...
        'source_index_read2_verified',false,'source_index_calls_returned',0,'source_selected_loads_returned',0,'target_audit_loads_returned',0,'target_native_read2_verified',false, ...
        'historical_comparison_closed_verified',false,'native_geometry',struct(),'output_file',o.OutputFile,'checkpoint_file',o.CheckpointFile,'component_identity',o.ComponentIdentity, ...
        'global_isolated_file',isolated,'declared_fixed_write_paths',{writes},'Run_calls_attempted',0,'Run_calls_returned',0,'Run_return_observed_before_outer_work',false, ...
        'Run_actual_limits_within_original_work',false,'Run_options',struct(),'Run_observation',struct(),'actual_attempt_rows',0,'native_pending_present',false, ...
        'owned_fork_commit_verified',false,'fork_native_read2_verified',false,'cloned_seed_native_ids_preserved',false,'cheap_NEWcol1_comparison',struct(), ...
        'file_observations',struct(),'directory_changes',struct(),'source_posthash',false,'completed',false,'failure',struct(),'status','prepared', ...
        'journal_mutated',false,'round_mutated',false,'primary_raw_mutated',false,'central_frontier_reset',false,'primary_canonical_edge_registered',false, ...
        'target_used_as_seed',false,'target_projection_as_admission',false,'fresh_fines_performed',false,'all_four_target_cohorts_claimed',false, ...
        'P1_original_state_admission_claimed',false,'scheduled_v2_trajectory_equivalence_claimed',false,'physical_attachment_claimed',false,'endpoint_claimed',false,'global_completion_claimed',false,'own_process_exit_observed',false, ...
        'write_union_scope','Unchanged Run may write fork/checkpoint/pending/globalisolated and random tempname MAT stages. Unknown stages are retained/reported; wrapper never deletes or rolls back.', ...
        'scope','One fresh fork from native464/465; imported local1/2 NONEDGE, only an actual all9/captured/timely correction earns local2->3. No primary registration, fine qualification or completion is inferred.');
    normalReturned=false;
    try
        guard(work);assert(isfile([ledger,'.writer.lock']),'C1PKFork:ExistingLock','Require the stable existing writer-lock inode.');lock=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
        [target,historical,targetPoint]=storedTarget(o,work,@observedTwice);facts.target_native_read2_verified=true;
        facts.historical_target_source_code_digest=C1ScientificDigest_v3(historical.target_source_code_historical_syntax_only);facts.historical_qualification=rmfield(historical,'target_source_code_historical_syntax_only');
        [witness,policyReport,signature]=storedSection(target,targetPoint,work);targetShapes(target,witness);
        [closed,q]=comparisonClosure(o.HistoricalComparisonClosureReference,root,work);facts.historical_comparison_closed_verified=true;facts.actual0061_closure=closed;bindComparison(q,o,raw,expectedRawSHA,target);
        fprintf('C1_PK_COL1_FORK_BEFORE_INDEX1\n');ix=BranchSolutionFile_v3.index(raw);facts.source_index_calls_returned=1;fprintf('C1_PK_COL1_FORK_AFTER_INDEX1_RETURN\n');check(work);
        fprintf('C1_PK_COL1_FORK_BEFORE_INDEX2\n');ix2=BranchSolutionFile_v3.index(raw);facts.source_index_calls_returned=2;fprintf('C1_PK_COL1_FORK_AFTER_INDEX2_RETURN\n');check(work);
        assert(isequaln(ix,ix2),'C1PKFork:IndexRead2','Two complete current indices differ.');clear ix2;facts.source_index_read2_verified=true;
        hit=find(cellfun(@(e)e.from==464&&e.to==465,ix.edges));assert(isscalar(hit),'C1PKFork:SourceEdge','Require the actual464->465 physical edge.');edge=ix.edges{hit};
        assert(strcmp(ix.points{464}.component_identity,ix.points{465}.component_identity)&&strcmp(edge.component_identity,ix.points{465}.component_identity) ...
            &&~any(cellfun(@(x)strcmp(x.component_identity,o.ComponentIdentity),ix.points)),'C1PKFork:Owner','Source edge owner must agree; new fork owner must be unique.');facts.actual_original_source_edge=edge;
        guard(work);fprintf('C1_PK_COL1_FORK_BEFORE_SELECTED1\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(raw,[464;465]);facts.source_selected_loads_returned=1;fprintf('C1_PK_COL1_FORK_AFTER_SELECTED1_RETURN\n');check(work);
        first=cell(2,1);principal=[10;10;20;20;1;1;0;0;2;.5];for k=1:2,strictPK(O{k},R{k},principal);first{k}=pointHeader(O{k},R{k},M{k},ix.points{463+k},463+k);end;clear O R M
        guard(work);fprintf('C1_PK_COL1_FORK_BEFORE_SELECTED2\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(raw,[464;465]);facts.source_selected_loads_returned=2;fprintf('C1_PK_COL1_FORK_AFTER_SELECTED2_RETURN\n');check(work);
        for k=1:2,strictPK(O{k},R{k},principal);h=pointHeader(O{k},R{k},M{k},ix.points{463+k},463+k);assert(isequaln(h,first{k}),'C1PKFork:SourceRead2','Compact seed state/admission/identity/owner differs.');end
        facts.source_pair_read2_verified=true;old=asCells(q.owned);assert(numel(old)==3,'C1PKFork:0061Rows','Require the actual three-row comparison.');
        for k=1:2,assert(strcmp(old{k}.native_id,first{k}.native_id)&&old{k}.index==463+k&&strcmp(old{k}.owner,first{k}.owner),'C1PKFork:0061Identity','Fresh native identities must join0061; JSON numbers are not geometry inputs.');end
        [policy,~]=RecordedReturnPolicy_v3(R{2});match=MatchingReturnSection_v3(O{1},O{2},{R{1},R{2}});assert(match.compatible&&isequaln(O{1}.parameter,O{2}.parameter),'C1PKFork:PairSection','Source pair needs identical complete section/policy/p.');
        [geometry,constraint]=nativeGeometry(O{1},O{2},target,policy,work);facts.native_geometry=geometry;facts.imported_source_headers=first;
        facts.target=struct('native_id',target.native_id,'state',target.state,'mode',target.mode,'parameter',target.parameter,'period',target.period,'full_stride',target.full_stride,'native_energy',target.native_energy);
        clear O R M h ix policy match old q targetPoint
        guard(work);freshPaths(writes);assert(left(work)-2>240+120+10,'C1PKFork:RunSlot','Full240 trial+Run120 save+10 existing fit must remain inside ORIGINAL outerWORK.');
        cap=left(work)-2;ro=struct('Budget',budget,'MaxWallSeconds',cap,'TrialSeconds',240,'SaveMarginSeconds',120,'MaxAccepted',1,'MaxAttempts',1, ...
            'InitialStep',geometry.sigma,'MinimumStep',1e-7,'MaximumStep',.1,'StepGrowth',1.3,'StepShrink',.5,'CaptureRadius',.02,'MaxSavedFailures',2, ...
            'DerivativeMethod','valid-sided','FiniteDifferenceSteps',1e-8,'ReusePreviousJacobian',false,'Algorithm','root-newton','AllowedClasses',{{'PK'}}, ...
            'ComponentIdentity',o.ComponentIdentity,'IntegrationMaxStep',.001,'CorrectorInitializer','base','InPlace',false,'CheckpointFile',o.CheckpointFile,'InitialDerivativeIndex',1,'MinimumApexHeightRatio',.5);
        facts.Run_options=rmfield(ro,'Budget');facts.derived_inner_cap_from_original_work=cap;facts.handoff_margin_seconds=2;
        facts.clock_scope='Run cap derives once from remaining ORIGINAL wrapperWORK; actual inner limits must remain within that WORK. Outer120 and Run120 reserves remain distinct. Scalar fences do not cancel blocking IO/cold-entry delay.';
        fprintf('C1_PK_COL1_FORK_BEFORE_RUN\n');facts.Run_calls_attempted=1;s=RunC1Continuation_v3(o.OutputFile,raw,[464 465],'pronk',ro);facts.Run_calls_returned=1;fprintf('C1_PK_COL1_FORK_AFTER_RUN_RETURN\n');
        facts.Run_return_observed_before_outer_work=left(work)>0;facts.Run_actual_limits_within_original_work=s.run_limit.deadline_unix_seconds<=work.utc&&s.run_limit.deadline_monotonic_ns<=work.mono ...
            &&s.work_limit.deadline_unix_seconds<=work.utc-120&&s.work_limit.deadline_monotonic_ns<=work.mono-120e9;
        assert(isequaln(s.original_budget,budget),'C1PKFork:RunBudget','Returned Run grant must remain literal.');facts.Run_observation=runHeader(s);facts.actual_attempt_rows=numel(s.attempts);facts.native_pending_present=~isempty(fieldnames(s.pending_admission));
        assert(numel(s.attempts)<=1&&s.new_points<=1&&s.new_edges<=1,'C1PKFork:OneAttempt','Retain one-attempt/one-accepted limits.');if ~isempty(s.attempts),checkAttempt(s.attempts{1},geometry,constraint,first{2});end
        clean=facts.Run_return_observed_before_outer_work&&facts.Run_actual_limits_within_original_work&&isequal(s.persistence_completion_confirmed,true)&&~facts.native_pending_present ...
            &&isempty(fieldnames(s.failure))&&~ismember(s.status,{'committed_data_but_storage_late','isolated_native_storage_late','native_all_nine_pending_after_clock','child_or_work_budget_exhausted'});
        facts.status='clean_return_no_owned_commit';
        if facts.native_pending_present,facts.status='native_pending_requires_reconciliation';
        elseif ~facts.Run_return_observed_before_outer_work||~facts.Run_actual_limits_within_original_work,facts.status='original_clock_requires_review';
        elseif clean
            if s.new_points==1
                a=s.attempts{1};assert(a.all_nine&&a.timely&&a.edge_committed&&isequal(a.storage_timely,true),'C1PKFork:ActualCommit','Require actual timely all9/captured/storage row.');
            end
            [facts.fork_records,facts.cheap_NEWcol1_comparison,facts.fork_output_reference]=forkRead2(o.OutputFile,first,target,witness,policyReport,signature,finish,s.new_points,o.ComponentIdentity);
            facts.fork_native_read2_verified=true;facts.cloned_seed_native_ids_preserved=true;
            if s.new_points==1,facts.owned_fork_commit_verified=true;facts.status='finite_owned_fork_stored_comparison_only';end
        end
        guard(finish);[facts.directory_changes,dirsClean]=outputChanges(beforeResults,beforeAudits,o,isolated);facts.file_observations=outputFiles(writes,finish);
        if ~dirsClean,facts.status='retained_stage_requires_reconciliation';clean=false;end
        facts.source_posthash=true;facts.completed=clean&&dirsClean;emit(facts);guard(finish);
    catch problem
        facts.completed=false;facts.failure=exceptionData(problem);facts.status='partial_or_refused';
        try,[facts.directory_changes,~]=outputChanges(beforeResults,beforeAudits,o,isolated);facts.file_observations=outputFiles(writes,finish);catch captureProblem,facts.output_capture_failure=struct('identifier',captureProblem.identifier,'message',captureProblem.message);end
        p=forkPartial(facts,problem,normalReturned);encoded=jsonencode(p);assert(numel(unicode2native(encoded,'UTF-8'))<=7000,'C1PKFork:PartialBound','Bound partial stdout to7000 UTF8 bytes.');fprintf('C1_PK_COL1_FORK_PARTIAL %s\n',encoded);rethrow(problem);
    end
    function out=observedTwice(file,key,label,limit)
        check(limit);fprintf('C1_PK_COL1_FORK_BEFORE_TARGET_LOAD1 %s\n',label);a=load(file,'-mat',key);facts.target_audit_loads_returned=facts.target_audit_loads_returned+1;fprintf('C1_PK_COL1_FORK_AFTER_TARGET_LOAD1_RETURN %s\n',label);check(limit);
        fprintf('C1_PK_COL1_FORK_BEFORE_TARGET_LOAD2 %s\n',label);b=load(file,'-mat',key);facts.target_audit_loads_returned=facts.target_audit_loads_returned+1;fprintf('C1_PK_COL1_FORK_AFTER_TARGET_LOAD2_RETURN %s\n',label);check(limit);assert(isequaln(a.(key),b.(key)),'C1PKFork:TargetRead2','Two plain historical audit loads differ.');out=a.(key);
    end
    function guard(limit)
        check(limit);quiet(ledger,raw,roundFile);verify(refs);verifyCode(code);if isfield(facts,'fork_output_reference'),verify({facts.fork_output_reference});end;assert(isequaln(C1RunBudget_v3(),budget),'C1PKFork:BudgetValue','Original grant value changed.');check(limit);
    end
    function emit(value)
        encoded=jsonencode(value);assert(numel(unicode2native(encoded,'UTF-8'))<=50000,'C1PKFork:SummaryBound','Emit bounded partial instead of oversized full summary.');
        fprintf('C1_PK_COL1_FORK_BEFORE_SUMMARY\n');fprintf('C1_PK_COL1_OWNED_FORK_ACTUAL_RETURN %s\n',encoded);normalReturned=true;fprintf('C1_PK_COL1_FORK_AFTER_SUMMARY_RETURN\n');
    end
end

function [g,constraint]=nativeGeometry(a,b,t,policy,limit)
    s=QuadrupedSchema_v3.shared();integration=struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001,'ODEOptions',odeset('OutputFcn',@(~,~,~)geometryClock(limit)));
    map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(integration),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));
    f=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,b.initial_state),b.initial_state,b.initial_mode,b.parameter,struct('Symmetry','pronk'));
    ua=f.packState(a.initial_state);ub=f.packState(b.initial_state);ut=f.packState(t.state);scale=max([ones(numel(ub),1),abs(ua),abs(ub)],[],2);
    delta=(ub-ua)./scale;distance=norm(delta);assert(isfinite(distance)&&distance>1e-10,'C1PKFork:Chord','Require the actual resolved source chord.');tangent=delta/distance;
    sigma=dot(tangent,(ut-ub)./scale);assert(isa(sigma,'double')&&isreal(sigma)&&isscalar(sigma)&&isfinite(sigma)&&sigma>=1e-7&&sigma<=.1, ...
        'C1PKFork:SignedProgress','Native signed target progress itself must lie in1e-7..0.1; no abs, clipping or enlargement.');
    assert(isequal(f.fullState(ub),b.initial_state(:)),'C1PKFork:BaseRoundtrip','Admitted base465 must roundtrip exactly, without projection.');
    up=ub+scale.*(sigma*tangent);xp=f.fullState(up);xt=f.fullState(ut);E=QuadrupedEnergy_v3.evaluate(b.initial_state,b.initial_mode,b.parameter);
    constraint=struct('reference',[ub;E],'normal',[tangent./scale;0],'target',sigma);
    g=struct('coordinate_indices',f.CoordinateIndices,'closure_indices',f.ClosureIndices,'energy_pivot',f.EnergyPivot,'ua',ua,'ub',ub,'target_coordinates',ut,'scale',scale,'tangent',tangent, ...
        'chord_distance',distance,'sigma',sigma,'constraint',constraint,'base_energy',E,'base_roundtrip_exact',true, ...
        'source_A_lift_minus_raw',f.fullState(ua)-a.initial_state(:),'target_lift_minus_raw',xt-t.state(:),'target_roundtrip_exact',isequal(xt,t.state(:)), ...
        'capture_predictor_state',xp,'base_root_start',b.initial_state(:),'base_initial_coordinates',[ub;E], ...
        'predicted_full13_separation',norm((xp(2:14)-b.initial_state(2:14))./max(ones(13,1),abs(b.initial_state(2:14))),Inf), ...
        'predicted_target_full13_scaled_inf',norm((xp(2:14)-t.state(2:14))./max([ones(13,1),abs(xp(2:14)),abs(t.state(2:14))],[],2),Inf), ...
        'target_used_as_seed',false,'map_evaluate_calls',0,'scope','Native coordinate geometry only; target lift discrepancy is recorded, not repaired. Actual all9/capture/fullstate comparison determines the result.');check(limit);
end
function x=geometryClock(limit),check(limit);x=0;end
function checkAttempt(a,g,constraint,base)
    assert(a.attempt==1&&a.source_point==2&&isequal(a.step,g.sigma)&&strcmp(a.derivative_method,'valid-sided')&&a.relative_step==1e-8&&strcmp(a.algorithm,'root-newton') ...
        &&isequaln(a.constraint,constraint)&&isequaln(a.predictor_state,g.capture_predictor_state),'C1PKFork:ActualPlane','Actual first Run row must use the declared plane, not a shrunk/fallback trial.');
    ci=a.corrector_initialization;assert(strcmp(ci.method,'base')&&isequaln(ci.start_state,base.state)&&isequaln(ci.start_coordinates,g.base_initial_coordinates)&&isequal(ci.base_roundtrip_exact,true) ...
        &&isequaln(ci.capture_predictor_state,g.capture_predictor_state)&&isequal(a.previous_jacobian_reuse.requested,false),'C1PKFork:ActualBase','Actual Root start remains base465 with no cross-point Jacobian reuse.');
end
function h=runHeader(s)
    h=pickPresent(s,{'protocol','output_file','configuration','new_points','new_edges','initial_output_count','final_output_count','status','persistence_completion_confirmed','derivative_method', ...
        'integration_profile','corrector_initializer','run_limit','work_limit','current_pair','next_step','next_derivative_index','apex_height_policy','completed_utc'});
    h.failure_header=storedFailureHeader(s.failure);h.pending_admission_present=~isempty(fieldnames(s.pending_admission));h.pending_stage=member(s.pending_admission,'stage','');h.isolated_native_admissions=s.isolated_native_admissions;
    h.attempts=cell(size(s.attempts));for k=1:numel(s.attempts),h.attempts{k}=pickPresent(s.attempts{k},{'attempt','source_point','step','derivative_method','relative_step','algorithm','status','all_nine','timely','capture', ...
            'edge_committed','storage_attempted','storage_timely','isolated_committed','isolated_storage_timely','corrector_initialization','apex_height_policy'});end
    h.checkpoint_fact_scope='Actual returned persistence flag remains literal; saved checkpoint intentionally retains provisional false. Full failure/native-pending payload remains in Run checkpoint, not duplicated here.';
end
function h=storedFailureHeader(e)
    h=struct();if isempty(fieldnames(e)),return;end
    id=member(e,'identifier','');msg=member(e,'message','');h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'message_prefix',msg(1:min(numel(msg),256)),'message_char_count',numel(msg), ...
        'stack_frame_count',numel(member(e,'stack',[])),'full_failure_preserved_in_Run_checkpoint',true);
end
function out=pickPresent(s,keys),out=struct();for k=1:numel(keys),if isfield(s,keys{k}),out.(keys{k})=s.(keys{k});end,end,end
function [headers,comparison,outputReference]=forkRead2(file,original,t,witness,policyReport,signature,limit,newCount,owner)
    check(limit);outputReference=reference(file);check(limit);ix=BranchSolutionFile_v3.index(file);verify({outputReference});check(limit);N=2+newCount;assert(ismember(newCount,[0 1])&&numel(ix.points)==N&&numel(ix.edges)==newCount,'C1PKFork:ForkGraph','Require exactly two NONEDGE anchors and only an actually new edge.');if newCount==1,assert(ix.edges{1}.from==2&&ix.edges{1}.to==3,'C1PKFork:ForkEdge','Only actual local2->3 is allowed.');end
    fprintf('C1_PK_COL1_FORK_BEFORE_OUTPUT_READ1\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(file,(1:N).');fprintf('C1_PK_COL1_FORK_AFTER_OUTPUT_READ1_RETURN\n');check(limit);verify({outputReference});headers=cell(N,1);comparison=struct();comp=struct();principal=[10;10;20;20;1;1;0;0;2;.5];
    for k=1:N
        strictPK(O{k},R{k},principal);headers{k}=pointHeader(O{k},R{k},M{k},ix.points{k},k);
        assert(strcmp(headers{k}.owner,owner),'C1PKFork:OutputOwner','Every output occurrence retains the explicit fresh owner.');if k<=2,assert(~M{k}.edge_enabled&&~isfield(M{k},'edge_from')&&strcmp(headers{k}.native_id,original{k}.native_id)&&strcmp(M{k}.provenance.kind,'imported nonedge initial pair')&&M{k}.provenance.source_index==463+k,'C1PKFork:CloneIdentity','Both native seed identities/roles must remain unchanged.');end
    end
    if newCount==1,comp=compareTarget(O{3},R{3},t,witness,policyReport,signature);end;clear O R M;verify({outputReference});check(limit);
    fprintf('C1_PK_COL1_FORK_BEFORE_OUTPUT_READ2\n');[O,R,M]=BranchSolutionFile_v3.loadSolutions(file,(1:N).');fprintf('C1_PK_COL1_FORK_AFTER_OUTPUT_READ2_RETURN\n');check(limit);verify({outputReference});
    for k=1:N,strictPK(O{k},R{k},principal);h=pointHeader(O{k},R{k},M{k},ix.points{k},k);assert(isequaln(h,headers{k}),'C1PKFork:OutputRead2','Compact actual output values must agree across two acquisitions.');end
    if newCount==1,comparison=compareTarget(O{3},R{3},t,witness,policyReport,signature);end;assert(isequaln(comp,comparison),'C1PKFork:ComparisonRead2','Every stored comparison field must agree.');
    if newCount==1,assert(M{3}.edge_enabled&&M{3}.edge_from==2&&M{3}.provenance.source_point==2&&M{3}.provenance.attempt==1,'C1PKFork:NewEdge','Only actual first correction from local base2 earns this edge.');end
    verify({outputReference});check(limit);
end
function bindComparison(q,o,raw,rawSHA,t)
    assert(strcmp(q.schema,'C1-owned-PK-NEWcol1-stored-comparison-v1')&&isequal(q.completed,true)&&isequal(q.source_posthash,true)&&isempty(fieldnames(q.failure)) ...
        &&strcmp(q.source_reference.sha256,'8665a5bcf63bba36311c2a42aa0806221774f51ade71138447fb19c641c3bff6') ...
        &&q.target_native_read2_verified&&q.index_read2_verified&&q.selected_compact_read2_verified&&q.index_calls_returned==2&&q.selected_load_calls_returned==2&&all(q.selected_load_return_timely(:)) ...
        &&isequal(q.own_process_exit_observed,false)&&q.root_calls==0&&q.map_calls==0&&q.fine_calls==0,'C1PKFork:Comparison','Require actual complete stored-only0061 observation, separate from its actual0 closure.');
    rr=asCells(q.expected_current_references);hit=find(cellfun(@(r)strcmp(canonical(r.file),raw),rr));assert(isscalar(hit)&&strcmp(rr{hit}.sha256,rawSHA),'C1PKFork:CurrentPrimary','Primary raw must still equal0061; old global ledger/Round references remain historical.');
    assert(isequaln(q.target_input_reference,o.TargetInputReference)&&isequaln(q.target_qualification_reference,o.TargetQualificationReference)&&isequaln(q.target_raw_reference,o.TargetRawReference) ...
        &&strcmp(q.target.native_id,t.native_id)&&isequal(q.selected_owned_indices(:),[464;465;466]),'C1PKFork:TargetJoin','Retain the same qualified target and actual source occurrences.');
    rows=asCells(q.comparisons);assert(numel(rows)==3&&all(cellfun(@(x)isequal(x.conditions_met,false),rows)),'C1PKFork:AlreadyMatched','Refuse another acquisition if any selected owned record already meets the stored target comparison.');
end
function [w,q]=comparisonClosure(r,root,limit)
    check(limit);w=jsondecode(fileread(r.file));exactFields(w,{'schema','invocation_id','argv_utf8_sha256','exec_session_id','child_pid','actual_child_exit_code','actual_process_exit_observed','tool_prefix_reference','process_prefix_reference'});
    assert(strcmp(w.schema,'C1-ordinary-initializer-evidence-closure-v1')&&strcmp(w.invocation_id,'PK36h20261031-0061-owned-P1-column1-stored-comparison')&&w.exec_session_id==52933&&w.child_pid==6715 ...
        &&isequal(w.actual_child_exit_code,0)&&isequal(w.actual_process_exit_observed,true)&&strcmp(w.argv_utf8_sha256,'4f1993b623aaa219439fc5e1a24f9e3798f168d68931734b21b30a15c95ac161'),'C1PKFork:Closure','Keep exact actual0061 session/pid/argv/exit authority.');
    exactFields(w.tool_prefix_reference,{'file','prefix_bytes','prefix_sha256'});exactFields(w.process_prefix_reference,{'file','prefix_bytes','prefix_sha256'});
    assert(strcmp(w.tool_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Tool_Observations.jsonl'))&&strcmp(w.process_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Process_Observations.jsonl')),'C1PKFork:PrefixPaths','Use known bounded immutable observation prefixes.');
    tool=prefixRows(w.tool_prefix_reference);process=prefixRows(w.process_prefix_reference);rows=tool(cellfun(@(x)isfield(x,'invocation_id')&&strcmp(x.invocation_id,w.invocation_id),tool));assert(numel(rows)==6,'C1PKFork:ToolRows','Require the actual six ordered records.');
    terminal=0;starts={};exits={};summaries={};summaryOrdinal=[];
    for k=1:6
        a=rows{k};assert(strcmp(a.schema,'C1-native-exec-tool-observation-v1')&&a.tool_record_ordinal==k,'C1PKFork:ToolOrder','Actual ordinals must be1..6.');
        if k<6,assert(isfield(a,'session_id')&&a.session_id==w.exec_session_id,'C1PKFork:ToolSession','Running envelope sessions must match.');else,assert(~isfield(a,'session_id'),'C1PKFork:TerminalAbsence','Actual terminal6 alone lacks envelope session.');end
        if isfield(a.record,'session_id'),assert(a.record.session_id==w.exec_session_id,'C1PKFork:RecordSession','Every present record session must match.');end
        if isfield(a.record,'exit_code'),assert(k==6&&a.record.exit_code==0,'C1PKFork:Terminal','Require sole actual terminal0.');terminal=terminal+1;end
        if isfield(a.record,'output')
            lines=strsplit(a.record.output,newline);
            for n=1:numel(lines)
                line=lines{n};
                if startsWith(line,'C1_NATIVE_PROCESS_STARTED '),starts{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_STARTED ')+1:end));end
                if startsWith(line,'C1_NATIVE_PROCESS_EXIT '),exits{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_EXIT ')+1:end));end
                if startsWith(line,'C1_PK_COL1_STORED_COMPARISON_ACTUAL_RETURN '),summaries{end+1}=jsondecode(line(numel('C1_PK_COL1_STORED_COMPARISON_ACTUAL_RETURN ')+1:end));summaryOrdinal(end+1)=k;end
            end
        end
    end
    selected=process(cellfun(@(x)isfield(x,'invocation_id')&&strcmp(x.invocation_id,w.invocation_id),process));spec={};observed={};dispatch={};
    for k=1:numel(selected),a=selected{k};if strcmp(a.schema,'C1-native-launch-specification-v1'),spec{end+1}=a;elseif strcmp(a.schema,'C1-native-process-observation-v1'),observed{end+1}=a;elseif strcmp(a.schema,'C1-native-reviewed-specification-dispatch-confirmation-v1'),dispatch{end+1}=a;end,end
    assert(terminal==1&&numel(starts)==1&&numel(exits)==1&&numel(summaries)==1&&isequal(summaryOrdinal,5)&&numel(spec)==1&&numel(observed)==1&&numel(dispatch)==1,'C1PKFork:UniqueClosure','Require unique START/EXIT/summary/spec/dispatch/process joins.');
    a=starts{1};b=observed{1};sp=spec{1};di=dispatch{1};assert(strcmp(a.invocation_id,w.invocation_id)&&a.child_pid==w.child_pid&&strcmp(a.argv_utf8_sha256,w.argv_utf8_sha256) ...
        &&strcmp(b.invocation_id,w.invocation_id)&&b.child_pid==w.child_pid&&isequal(b.actual_child_exit_code,0)&&isequal(b.actual_process_exit_observed,true)&&strcmp(b.argv_utf8_sha256,w.argv_utf8_sha256) ...
        &&strcmp(sp.argv_utf8_sha256,w.argv_utf8_sha256)&&strcmp(di.argv_utf8_sha256,w.argv_utf8_sha256),'C1PKFork:ProcessJoin','Join actual child and reviewed dispatch to the same argv.');
    assert(isequaln(exits{1},b)&&strcmp(sp.expected_execution_tool_options.sandbox_permissions,'require_escalated')&&isequaln(rows{1}.actual_execution_tool_options,sp.expected_execution_tool_options) ...
        &&isequaln(di.expected_execution_tool_options,sp.expected_execution_tool_options)&&isequaln(b.expected_execution_tool_options,sp.expected_execution_tool_options),'C1PKFork:Profile','Preserve actual execution profile and EXIT observation.');
    q=summaries{1};check(limit);
end
function rows=prefixRows(r)
    validSHA(r.prefix_sha256);assert(ischar(r.file)&&isrow(r.file)&&isa(r.prefix_bytes,'double')&&isscalar(r.prefix_bytes)&&isfinite(r.prefix_bytes)&&r.prefix_bytes>0&&r.prefix_bytes<=16*1024*1024&&r.prefix_bytes==fix(r.prefix_bytes),'C1PKFork:Prefix','Require an exact bounded prefix.');
    f=fopen(r.file,'rb');assert(f>=0,'C1PKFork:PrefixOpen','Cannot read prefix.');closer=onCleanup(@()fclose(f));b=fread(f,r.prefix_bytes,'*uint8');assert(numel(b)==r.prefix_bytes&&b(end)==10,'C1PKFork:PrefixLength','Exact prefix must end atLF.');clear closer
    d=java.security.MessageDigest.getInstance('SHA-256');d.update(b);h=lower(reshape(dec2hex(typecast(d.digest(),'uint8'),2).',1,[]));assert(strcmp(h,r.prefix_sha256),'C1PKFork:PrefixSHA','Immutable prefix changed.');
    lines=strsplit(native2unicode(b.','UTF-8'),newline);lines(end)=[];rows=cellfun(@jsondecode,lines,'UniformOutput',false);
end
function c=asCells(x),if iscell(x),c=x(:);elseif isstruct(x),c=num2cell(x(:));else,error('C1PKFork:Cells','Require actual JSON object-array rows.');end,end
function code=forkCode(self,protected)
    names={'C1RunBudget_v3','RunC1Continuation_v3','BranchSolutionFile_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3','OrbitContentIdentity_v3','HybridOrbit_v3','Trajectory_v3','C1ScientificDigest_v3','RoundSHA256_v3', ...
        'QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3','QuadrupedAdmissibility_v3','ContinuousDynamics_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3','PoincareMap_v3','PoincareSection_v3','HybridSimulator_v3', ...
        'Quadrupedal_Dynamics_v3','PeriodicOrbitResidual_v3','EnergyFamilyResidual_v3','ConstrainedEnergyResidual_v3','PeriodicSolutionSolver_v3','RootSolver_v3','ValidSidedFiniteDifferenceJacobian_v3','FiniteDifferenceJacobian_v3', ...
        'GuardFunctions_v3','EventDetector_v3','ResetMap_v3','ModeTransition_v3','PrimitiveCycleCheck_v3','HybridCycleData_v3','GaitIdentification_v3','CompactResearchBranch_v3','SectionModeResolver_v3','HybridSystemBase_v3'};
    code={self};for k=1:numel(names),r=reference(which(names{k}));assert(any(cellfun(@(x)strcmp(x.file,r.file)&&strcmp(x.sha256,r.sha256),protected)),'C1PKFork:CallerMethodPin','Every current method resolver/hash must be caller-protected.');code{end+1,1}=r;
        if strcmp(names{k},'RunC1Continuation_v3'),assert(strcmp(r.sha256,'09e1b6813f4bdc1ca1115138d60d504bdb2758a8cb7e530f80c38987591b5bf1'),'C1PKFork:RunPin','Keep reviewed Run09 unchanged.');end
    end
end
function freshPaths(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKFork:Fresh','Preserve any existing output/pending path and refuse.');end,end
function names=directoryNames(folder),d=dir(folder);d=d(~ismember({d.name},{'.','..'}));names=sort({d.name}.');end
function [out,clean]=outputChanges(beforeResults,beforeAudits,o,isolated)
    r=directoryNames(fileparts(o.OutputFile));a=directoryNames(fileparts(o.CheckpointFile));[~,of,oe]=fileparts(o.OutputFile);[~,cf,ce]=fileparts(o.CheckpointFile);[~,nf,ne]=fileparts(isolated);
    addedR=setdiff(r,beforeResults);addedA=setdiff(a,beforeAudits);removedR=setdiff(beforeResults,r);removedA=setdiff(beforeAudits,a);unknownR=setdiff(addedR,{[of oe];[nf ne]});unknownA=setdiff(addedA,{[cf ce]});
    out=struct('added_Results',{addedR},'added_Audits',{addedA},'removed_Results',{removedR},'removed_Audits',{removedA},'retained_unresolved_Results',{unknownR},'retained_unresolved_Audits',{unknownA},'no_wrapper_delete_or_rollback',true);
    clean=isempty(unknownR)&&isempty(unknownA)&&isempty(removedR)&&isempty(removedA)&&~isfile([o.CheckpointFile,'.pending.mat']);
end
function out=outputFiles(paths,limit)
    out=cell(numel(paths),1);for k=1:numel(paths),p=paths{k};d=dir(p);a=struct('file',p,'present',isfile(p),'directory',isfolder(p),'bytes',[],'sha256','','hash_observed',false);if ~isempty(d)&&isscalar(d),a.bytes=d.bytes;end;if a.present&&left(limit)>0,a.sha256=RoundSHA256_v3(p);a.hash_observed=true;end;out{k}=a;end
end
function p=forkPartial(f,e,normalReturned)
    p=struct('schema','C1-owned-PK-NEWcol1-single-fork-partial-v1','completed',false,'normal_summary_call_returned',normalReturned,'own_process_exit_observed',false, ...
        'source_sha256',f.source_reference.sha256,'source_selected_loads_returned',f.source_selected_loads_returned,'target_audit_loads_returned',f.target_audit_loads_returned, ...
        'Run_calls_attempted',f.Run_calls_attempted,'Run_calls_returned',f.Run_calls_returned,'Run_return_observed_before_outer_work',f.Run_return_observed_before_outer_work, ...
        'Run_actual_limits_within_original_work',f.Run_actual_limits_within_original_work,'actual_attempt_rows',f.actual_attempt_rows,'native_pending_present',f.native_pending_present, ...
        'owned_fork_commit_verified',f.owned_fork_commit_verified,'source_posthash',f.source_posthash,'output_file',f.output_file,'checkpoint_file',f.checkpoint_file,'global_isolated_file',f.global_isolated_file, ...
        'failure_header',failureHeader(e),'full_facts_omitted',true,'scope','Actual outputs/pending/stages remain. Full native failure/pending is owned by existing Run checkpoint; no rollback or dense duplication is claimed.');
    p.Run_status=member(f.Run_observation,'status','');
end

function [t,h,p]=storedTarget(o,l,read2)
    a=read2(o.TargetInputReference.file,'audit','intake7271',l);assert(isstruct(a)&&isscalar(a)&&isequal(a.completed,true)&&isequal(a.source_posthash,true)&&isempty(fieldnames(a.failure)), ...
        'C1PKCol1:TargetIntake','Require the exact complete independently qualified target intake.');
    assert(iscell(a.targets)&&~isempty(a.targets),'C1PKCol1:Targets','Use the original first target without a numerical selector.');t=a.targets{1};
    assert(strcmp(t.role,'P1_col1_NEW_qualified_control')&&isequaln(t.authority.audit_reference,o.TargetQualificationReference)&&isequaln(t.authority.final_raw_reference,o.TargetRawReference), ...
        'C1PKCol1:TargetAuthority','Use exact named NEWcol1 authority; not UNIT or OriginalP1 raw.');
    old=read2(o.TargetQualificationReference.file,'audit','qualified210a',l);assert(iscell(old.rows)&&~isempty(old.rows),'C1PKCol1:TargetRow','Retain original first delegated row.');r=old.rows{1};
    assert(isequal(old.completed,false)&&isequal(old.source_posthash,false)&&r.original.original_column==1 ...
        &&isequal(r.qualified_new_control,true)&&isequal(r.finite_original_column_conditions_met,true)&&isequal(r.native_all_nine,true)&&isequal(r.initial_anchor_control.passed,true) ...
        &&numel(r.fines)==2&&all(cellfun(@(f)isequal(f.passed,true)&&isequal(f.observation.returned,true)&&isequal(f.observation.return_timely,true)&&isequal(f.raw_custody.storage_timely,true)&&isequal(f.raw_custody.readback_timely,true),r.fines)), ...
        'C1PKCol1:LocalQualification','Historical global false and actual local qualified NEWcol1/two original timely fines must remain distinct.');
    p=r.new_point;assert(strcmp(t.native_id,p.native_id)&&isequaln(t.state,p.initial_state)&&isequaln(t.mode,p.mode)&&isequaln(t.parameter,p.parameter)&&isequaln(t.period,p.period)&&isequaln(t.full_stride,p.full_stride), ...
        'C1PKCol1:TargetValues','Bind every identity-bearing plain target value to the independently admitted row.');
    syntaxReferences(a.source_code);c=jsondecode(fileread(o.HistoricalClosureReference.file));
    assert(isstruct(c)&&isscalar(c)&&isstruct(c.child)&&c.child.child_exit_code==0&&c.child.child_pid==7809&&c.metadata.completed&&c.metadata.source_posthash ...
        &&isempty(fieldnames(c.metadata.failure))&&~c.metadata.native_pending_present&&c.metadata.native_all_nine&&c.metadata.qualified_nonedge_control&&c.metadata.finite_NEW_col1_conditions_met ...
        &&islogical(c.metadata.endpoint_fines_passed)&&numel(c.metadata.endpoint_fines_passed)==2&&all(c.metadata.endpoint_fines_passed(:)) ...
        &&islogical(c.metadata.control_fines_passed)&&numel(c.metadata.control_fines_passed)==2&&all(c.metadata.control_fines_passed(:)) ...
        &&c.metadata.prepared_requests==5&&c.metadata.actual_requests_invoked==5&&c.metadata.actual_requests_returned==5, ...
        'C1PKCol1:HistoricalClosure','Retain actual original Short01 process closure and finite comparison scope.');
    h=struct('target_source_code_historical_syntax_only',{a.source_code},'original_column',r.original.original_column, ...
        'historical_parent_completed',old.completed,'historical_parent_source_posthash',old.source_posthash, ...
        'local_native_all_nine',r.native_all_nine,'qualified_new_control',r.qualified_new_control, ...
        'finite_original_column_conditions_met',r.finite_original_column_conditions_met,'initial_anchor_passed',r.initial_anchor_control.passed, ...
        'original_solved_control_fine_passed',cellfun(@(x)x.passed,r.fines),'raw_target_deserialized',false, ...
        'short01_child_exit_code',c.child.child_exit_code,'short01_child_pid',c.child.child_pid, ...
        'short01_finite_NEW_col1_conditions_met',c.metadata.finite_NEW_col1_conditions_met, ...
        'scope','Historical pinned NEWcontrol qualification and actual closed endpoint-control comparison; never original legacy-state admission, old global flag upgrade or present process exit.');check(l);
end

function [witness,policyReport,signature]=storedSection(target,p,l)
    assert(strcmp(p.native_id,target.native_id)&&isequaln(p.initial_state,target.state)&&isfield(p,'section_chart')&&isfield(p,'section_event_signature'), ...
        'C1PKCol1:TargetSection','Use only the exact already-read2 admitted NEWcol1 chart/token.');
    configuration=target.policy_configuration;assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isstruct(configuration.settings)&&isscalar(configuration.settings)&&isfield(configuration.settings,'Name'), ...
        'C1PKCol1:Policy','Use actual complete historical BL1 policy settings.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));[~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration)&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKCol1:PolicyRoundtrip','Fresh constructor must roundtrip exact recorded BL1 policy.');
    witness=struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',target.mode,'section_chart',p.section_chart,'return_multiplicity',1);
    policyReport=struct('seed',struct('return_policy',policy));signature=p.section_event_signature;assert(strlength(string(signature))>0,'C1PKCol1:EventToken','The saved single target event token must be nonempty.');check(l);
end

function targetShapes(t,w)
    assert(isa(t.state,'double')&&isreal(t.state)&&isequal(size(t.state),[14 1])&&all(isfinite(t.state)) ...
        &&islogical(t.mode)&&isequal(size(t.mode),[4 1])&&isa(t.parameter,'double')&&isreal(t.parameter)&&isequal(size(t.parameter),[10 1])&&all(isfinite(t.parameter)) ...
        &&isa(t.full_stride,'double')&&isreal(t.full_stride)&&isequal(size(t.full_stride),[14 1])&&all(isfinite(t.full_stride)) ...
        &&isa(t.period,'double')&&isreal(t.period)&&isscalar(t.period)&&isfinite(t.period)&&t.period>0 ...
        &&isa(t.native_energy,'double')&&isreal(t.native_energy)&&isscalar(t.native_energy)&&isfinite(t.native_energy), ...
        'C1PKCol1:TargetShapes','Require exact finite native state14/mode4/p10/stride14 and scalar period/energy.');
    assert(ischar(t.native_id)&&isrow(t.native_id)&&~isempty(regexp(t.native_id,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1PKCol1:NativeID','Require the source-defined native record identity.');assert(isstruct(w.section_chart)&&isscalar(w.section_chart),'C1PKCol1:TargetChart','Retain actual marked chart.');
end

function h=pointHeader(o,r,m,ix,index)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&ix.index==index&&isstruct(m)&&isscalar(m)&&strcmp(ix.component_identity,m.component_identity), ...
        'C1PKCol1:PointBinding','Retain current native record index, owner and public metadata binding.');
    assert(isa(o.stride_displacement,'double')&&isequal(size(o.stride_displacement),[14 1])&&all(isfinite(o.stride_displacement)), ...
        'C1PKCol1:Stride','A complete finite native14 stride is required.');
    g=r.classification;[~,pe]=RecordedReturnPolicy_v3(r);
    h=struct('index',index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o), ...
        'state',o.initial_state,'mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full_stride',o.stride_displacement, ...
        'native_energy',QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter), ...
        'acceptance_gates',pick(r.acceptance_gates,{'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'}), ...
        'classification',pick(g,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'}), ...
        'policy_configuration',pe.configuration,'section_chart',o.section_chart, ...
        'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature, ...
        'event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'saved_full_closure',r.full_closure,'metadata_binding',struct('component_identity',m.component_identity,'index',ix.index,'order',ix.order));
end

function out=pick(s,keys)
    out=struct();for k=1:numel(keys),assert(isfield(s,keys{k}),'C1PKCol1:RequiredField','A required saved field is missing.');out.(keys{k})=s.(keys{k});end
end

function refs=references(refs)
    assert(iscell(refs)&&size(refs,2)==1,'C1PKCol1:ReferenceCells','Supply a column cell of explicit current protected references.');
    for k=1:numel(refs),refs{k}=checked(refs{k});end
end

function syntaxReferences(refs)
    assert(iscell(refs)&&isvector(refs),'C1PKCol1:HistoricalRefs','Retain literal reference cell shape without rehashing historical source paths.');
    for k=1:numel(refs),r=refs{k};exactFields(r,{'file','sha256'});assert(ischar(r.file)&&isrow(r.file)&&java.io.File(r.file).isAbsolute(),'C1PKCol1:ReferencePath','Require an absolute historical source path.');validSHA(r.sha256);end
end

function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end

function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end

function out=compareTarget(O,r,t,witness,policyReport,signature)
    section=MatchingReturnSection_v3(O,witness,{r,policyReport});[~,pe]=RecordedReturnPolicy_v3(r);
    delta=O.initial_state(2:14)-t.state(2:14);scale=max([ones(13,1),abs(O.initial_state(2:14)),abs(t.state(2:14))],[],2);
    dt=O.period-t.period;dq=O.stride_displacement-t.full_stride;qs=max([ones(size(dq)),abs(O.stride_displacement),abs(t.full_stride)],[],2);
    dE=QuadrupedEnergy_v3.evaluate(O.initial_state,O.initial_mode,O.parameter)-t.native_energy;
    out=struct('raw_full13_delta',delta,'raw_full13_scaled_inf',norm(delta./scale,inf),'native_energy_delta',dE,'absolute_energy_tolerance',1e-8, ...
        'period_delta',dt,'period_tolerance',1e-10*max([1,abs(O.period),abs(t.period)]),'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
        'exact_p_q',isequaln(O.parameter,t.parameter)&&isequaln(O.initial_mode,t.mode),'exact_complete_policy',pe.complete&&isequaln(pe.configuration,t.policy_configuration), ...
        'matching_section',section,'same_section_event_signature',strcmp(string(O.section_relative_event_signature),string(signature)), ...
        'conditions_met',false,'scope','Finite comparison to the independently qualified NEWcol1 control only: rawfull13/E1e-8, period/fullstride componentwise1e-10/maxscale, exactp/q/completepolicy/markedsection/events. No OriginalP1 stride/meanU, source membership, alias, union or endpoint theorem is inferred.');
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dE)<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
        &&out.exact_p_q&&out.exact_complete_policy&&section.compatible&&out.same_section_event_signature;
end

function strictPK(o,r,p)
keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};for k=1:numel(keys),assert(isequal(r.acceptance_gates.(keys{k}),true),'C1Pilot:AllNine','Require every literal original native admission gate.');end;g=r.classification;status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true)&&strcmp(g.contract_version,'quadruped-gait-v3.5')&&strcmp(g.validated_gait_type,'PK')&&isequal(g.flight_count_certain,true)&&g.flight_count==1&&isequal(g.canonical_label_qualified,true)&&isequaln(o.parameter(:),p(:)),'C1Pilot:PK','Require current qualified certain PK1 and unchanged parameters.');[policy,e]=RecordedReturnPolicy_v3(r);assert(e.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1Pilot:Policy','Require the actual complete BL1 section.');
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1P1Fixed:Resolver','Current source resolution differs from its guard.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1P1Fixed:Changed','A bound file changed.');end,end

function r=reference(f),assert(isfile(f),'C1P1Fixed:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function out=exceptionData(e),causes=cell(size(e.cause));for k=1:numel(causes),causes{k}=exceptionData(e.cause{k});end;out=struct('identifier',e.identifier,'message',e.message,'stack',e.stack,'causes',{causes});end

function value=member(s,k,f),value=f;if isstruct(s)&&isscalar(s)&&isfield(s,k),value=s.(k);end,end

function x=clockPair(),x=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function x=shift(x,s),x.utc=x.utc+s;x.mono=x.mono+s*1e9;end

function x=left(l),x=min(l.utc-posixtime(datetime('now','TimeZone','UTC')),(l.mono-double(java.lang.System.nanoTime))/1e9);end

function check(l),assert(left(l)>0,'C1P1Fixed:Clock','The original local/science whole-call clock expired.');end

function x=canonical(x),x=char(java.io.File(char(x)).getCanonicalPath());end

function x=formatUTC(s),x=char(datetime(s,'ConvertFrom','posixtime','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function x=stamp(),x=formatUTC(posixtime(datetime('now','TimeZone','UTC')));end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

function quiet(ledger,raw,roundFile)
    cp=[ledger(1:end-4),'_active_checkpoint.mat'];paths={cp,[cp,'.pending.mat'],[ledger,'.pending.mat'],[roundFile,'.pending.mat'],[roundFile(1:end-4),'.pending.mat'],[roundFile(1:end-4),'.json.pending.json']};
    for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1:Pending','Reconcile existing owned checkpoint/stage before this stored-only observation.');end
    d=dir(fileparts(raw));d=d(~ismember({d.name},{'.','..'}));[~,n,e]=fileparts(raw);
    assert(numel(d)==1&&~d.isdir&&strcmp(d.name,[n e]),'C1PKCol1:RawDirectory','The primary raw directory must retain exactly its one current file, with no unknown stage.');
end

function h=failureHeader(e)
    id=e.identifier;message=e.message;stack=e.stack;
    h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'identifier_truncated',numel(id)>128, ...
        'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256, ...
        'stack_frame_count',numel(stack),'first_stack_frame',struct(),'stack_detail_omitted',numel(stack)>1,'cause_count',numel(e.cause));
    if ~isempty(stack)
        a=stack(1);h.first_stack_frame=struct('file_prefix',a.file(1:min(numel(a.file),128)),'file_char_count',numel(a.file),'file_truncated',numel(a.file)>128, ...
            'name_prefix',a.name(1:min(numel(a.name),96)),'name_char_count',numel(a.name),'name_truncated',numel(a.name)>96,'line',a.line);
    end
end

