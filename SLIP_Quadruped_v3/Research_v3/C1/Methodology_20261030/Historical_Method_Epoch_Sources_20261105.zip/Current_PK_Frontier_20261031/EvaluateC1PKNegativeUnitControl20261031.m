function facts=EvaluateC1PKNegativeUnitControl20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,expectedCatalogueSHA)
% ONE independent negative NONEDGE shooting control, not production PAL.
% Coupled free E is retained. The added scalar equation is L0-y=0.
    root=fileparts(which('C1RunBudget_v3'));budget=C1RunBudget_v3();startClock=struct('u',utc(),'m',nano());
    finish=struct('u',min(startClock.u+2400,budget.research_deadline_unix_seconds),'m',min(startClock.m+2400e9,budget.research_deadline_monotonic_ns));
    assert(left(finish)>2399,'C1PKNegative:WholeFit','The full2400 wrapper must fit BOTH original science clocks.');work=struct('u',finish.u-180,'m',finish.m-180e9);
    ledger=fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat');core=fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat');output=fullfile(root,'Audits','PK36h_20261031_Round.mat');json=[output(1:end-4) '.json'];
    unitFile=fullfile(root,'Results','C1_PK_Reversible_Unit_Height_NONEDGE_PKHalfUnit01_20261027.mat');catalogue=fullfile(root,'Results','PK36h_Endpoint_Experimental_Controls_20261031.mat');pending=[catalogue '.pending-admission.mat'];
    closedPaths={[ledger '.pending.mat'],[ledger(1:end-4) '_active_checkpoint.mat'],[ledger(1:end-4) '_active_checkpoint.mat.pending.mat'],[core '.pending.mat'],[output '.pending.mat'],[json '.pending.json']};
    self=reference([mfilename('fullpath') '.m']);before=reference(ledger);source=reference(core);roundBefore=reference(output);unitReference=reference(unitFile);catalogueBefore=reference(catalogue);
    assert(strcmp(before.sha256,expectedLedgerSHA)&&strcmp(source.sha256,expectedRawSHA)&&strcmp(roundBefore.sha256,expectedRoundSHA)&&strcmp(catalogueBefore.sha256,expectedCatalogueSHA),'C1PKNegative:Current','Require the actual declared closed current authorities.');
    assert(strcmp(unitReference.sha256,'02761bfd7e121799acce3e7c43494a93a1d944925a24fa48b432373fd110f19b')&&~isfile(pending)&&~isfolder(pending)&&~isfile([catalogue '.pending.mat'])&&~isfolder([catalogue '.pending.mat']),'C1PKNegative:OriginalUnit','Require the original positive unit file and no unresolved accepted catalogue payload.');
    guards={before;source;unitReference;catalogueBefore};closedPathsCheck(closedPaths,work);phase('negative_journal_read2_begin',startClock,struct());
    v=load(ledger,'journal');[f,options,epoch]=negativeJournal(v.journal,core,budget);clear v
    v=load(ledger,'journal');[f2,o2,e2]=negativeJournal(v.journal,core,budget);assertPublicEqual(f,f2,0);assertPublicEqual(options,o2,0);assertPublicEqual(epoch,e2,0);clear v f2 o2 e2
    refs={self};names={'BranchSolutionFile_v3','EnergyFamilyResidual_v3','ConstrainedEnergyResidual_v3','PeriodicSolutionSolver_v3','RootSolver_v3','ValidSidedFiniteDifferenceJacobian_v3','CompactResearchBranch_v3','C1PlainFineQualificationReplay_v3','MatchingReturnSection_v3','RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','QuadrupedEnergy_v3','QuadrupedSchema_v3','OrbitContentIdentity_v3','PeriodicOrbitResidual_v3','PoincareMap_v3','HybridSimulator_v3','Quadrupedal_Dynamics_v3','PoincareSection_v3','OrbitSpeed_v3','C1ScientificDigest_v3','QuadrupedPhysicalChart_v3','SourceTrialTrace_v3','HybridOrbit_v3','Trajectory_v3'};
    for k=1:numel(names),refs{end+1,1}=reference(which(names{k}));end
    verifySources(budget,epoch,refs,guards,work);phase('negative_raw_and_catalogue_read2_begin',startClock,struct('source_pair',f.source_pair));
    ix=BranchSolutionFile_v3.index(core);[O,R,M]=BranchSolutionFile_v3.loadSolutions(core,f.source_pair);[P,S,T]=BranchSolutionFile_v3.loadSolutions(core,f.source_pair);assertPublicEqual(O,P,0);assertPublicEqual(M,T,0);assertPublicEqual(reportView(R),reportView(S),0);clear P S T
    a=O{1};C=O{2};ra=R{1};rc=R{2};[~,pa]=admitted(a,ra);[policy,pc]=admitted(C,rc);assertPrimitive(ra);assertPrimitive(rc);
    hit=find(cellfun(@(e)e.from==f.source_pair(1)&&e.to==f.source_pair(2)&&strcmp(e.component_identity,M{1}.component_identity)&&strcmp(e.component_identity,M{2}.component_identity),ix.edges));assert(isscalar(hit),'C1PKNegative:OwnedEdge','Require the actual current owned parent-to-C physical edge.');
    pairSection=MatchingReturnSection_v3(a,C,{ra,rc});assert(isequaln(C.initial_state,f.initial_state)&&isequaln(C.initial_mode,f.initial_mode)&&f.last_accepted_index==f.source_pair(2)&&pairSection.compatible&&isequaln(pa.configuration,pc.configuration),'C1PKNegative:ActualOwnedC','The selected current frontier, nativeC and owned pair must agree.');
    ui=BranchSolutionFile_v3.index(unitFile);assert(numel(ui.points)==1&&isempty(ui.edges),'C1PKNegative:OriginalUnitIndex','The original positive control remains one isolated point.');[U,UR,UM]=BranchSolutionFile_v3.loadSolutions(unitFile,1);[P,S,T]=BranchSolutionFile_v3.loadSolutions(unitFile,1);assertPublicEqual(U,P,0);assertPublicEqual(UM,T,0);assertPublicEqual(reportView(UR),reportView(S),0);clear P S T
    unit=U{1};unitReport=UR{1};[~,pu]=admitted(unit,unitReport);assertPrimitive(unitReport);assert(isequaln(C.parameter,unit.parameter)&&isequaln(pc.configuration,pu.configuration),'C1PKNegative:InputPolicy','Keep the original physical parameter and complete BL policy.');
    oldIndex=BranchSolutionFile_v3.index(catalogue);oldIndex2=BranchSolutionFile_v3.index(catalogue);assertPublicEqual(oldIndex,oldIndex2,0);clear oldIndex2;assert(numel(oldIndex.points)==2&&isempty(oldIndex.edges),'C1PKNegative:CatalogueTwo','Require exactly the two preserved isolated experimental points.');
    [oldO,oldR,oldM]=BranchSolutionFile_v3.loadSolutions(catalogue,[1 2]);[P,S,T]=BranchSolutionFile_v3.loadSolutions(catalogue,[1 2]);assertPublicEqual(oldO,P,0);assertPublicEqual(oldR,S,0);assertPublicEqual(oldM,T,0);assert(all(cellfun(@(m)~m.edge_enabled,oldM)),'C1PKNegative:CatalogueNONEDGE','The old two catalogue records must remain NONEDGE.');clear P S T
    rr=load(output,'round');ss=load(output,'round');assertPublicEqual(rr.round,ss.round,0);round=rr.round;clear rr ss
    assert(isequaln(round.budget,budget)&&isequaln(jsondecode(fileread(json)),jsondecode(jsonencode(round)))&&~isfield(round.primary_diagnostics,'negative_unit_height_NONEDGE'),'C1PKNegative:Round','Require the matching current Round and a never-run negative-control field.');
    priorUnit=round.primary_diagnostics.endpoint_analytic_intake.control.records{1};assert(strcmp(priorUnit.native_id,OrbitContentIdentity_v3(unit))&&strcmp(priorUnit.owner,ui.points{1}.component_identity)&&priorUnit.owner_order==ui.points{1}.order,'C1PKNegative:OriginalUnitIdentity','Join the unchanged original positive unit NativeID/owner/order to the prior native intake.');clear priorUnit
    schema=QuadrupedSchema_v3.shared();p=C.parameter;piLeg=[3 4 1 2];
    assert(isequal(p([1 3 5]),p([2 4 6]))&&all(p(7:8)==0)&&isequal(p(10),.5)&&isfinite(p(9))&&p(5)>0,'C1PKNegative:ReflectionParameters','Require the source-supported fore/hind parameter symmetry and positive commonL0.');
    reflected=unit.initial_state;reflected([schema.State.x schema.State.dx schema.State.phi schema.State.dphi])=-unit.initial_state([schema.State.x schema.State.dx schema.State.phi schema.State.dphi]);reflected(schema.Leg.AngleIndices)=-unit.initial_state(schema.Leg.AngleIndices(piLeg));reflected(schema.Leg.RateIndices)=-unit.initial_state(schema.Leg.RateIndices(piLeg));qpi=unit.initial_mode(piLeg);
    assert(isequaln(C.initial_mode,qpi)&&C.initial_state(schema.State.dx)<0&&reflected(schema.State.dx)<0,'C1PKNegative:NegativeDirection','Require the actual negative owned direction and exact reflected mode; no absolute-value or sign repair.');
    section=PoincareSection_v3.apex(schema.PhaseIndex);assert(section.isOnSection(C.initial_state,p)&&section.isOnSection(reflected,p)&&section.derivative(0,reflected,qpi,p,Quadrupedal_Dynamics_v3())<0,'C1PKNegative:MarkedSection','The exact reflected seed must lie on the genuine downward marked-apex section.');
    orbit=[];rawReport=struct();storedReport=struct();pendingFacts=struct();
    facts=struct('schema','C1-PK-negative-fixed-height-NONEDGE-control-v1','experiment_id','PK36h20261031-Negative86-UnitControl-01','source_reference',self,'journal_reference',before,'raw_source_reference',source,'round_before_reference',roundBefore,'unit_control_reference',unitReference,'catalogue_before_reference',catalogueBefore,'frontier_before',f,'original_owned_edge',ix.edges{hit},'original_records',{{record(a,ra,M{1},ix.points{f.source_pair(1)});record(C,rc,M{2},ix.points{f.source_pair(2)});record(unit,unitReport,UM{1},ui.points{1})}},'periodic_solver_calls_attempted',0,'root_returned',false,'root_all_nine',false,'root_timely_observed',false,'actual_RootSolver_return_present',false,'root_solver_facts',struct(),'catalogue_append_attempted',false,'catalogue_committed',false,'catalogue_read2_verified',false,'catalogue_original_two_preservation_verified',false,'catalogue_storage_timely_observed',false,'pending_save_attempted',false,'pending_saved_read2_verified',false,'pending_admission_retained',false,'pending_file_present',false,'fines',{{}},'fine_profile_requests',0,'fine_full_return_map_calls_attempted',0,'all_two_control_fines_passed',false,'all_four_original_fines_passed',false,'finite_unit_conditions_met',false,'comparison',struct(),'failure',struct(),'status','prepared','completed',false,'journal_mutated',false,'raw_store_mutated',false,'physical_edges_added',0,'canonical_graph_mutated',false,'global_endpoint_claimed',false,'owned_connection_claimed',false,'half_height_stop_claimed',false,'own_process_exit_observed',false);
    facts.wrapper=struct('declared_seconds',2400,'save_post_reserve_seconds',180,'Root_seconds',240,'maximum_original_fine_requests',4,'original_fine_seconds',300,'fixed_budget',budget,'no_retry',true);
    facts.reflection=struct('exact_reflected14_seed',reflected,'exact_reflected_mode',qpi,'leg_permutation',piLeg,'parameter',p,'seed_admitted',false,'seed_symmetry_related_only',true,'time_reversed',false);
    phase('negative_intake_read2_returned',startClock,struct('ownedC',f.source_pair(2),'unit_native_id',OrbitContentIdentity_v3(unit)));
    try
        map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),section,HybridSimulator_v3(integration(work,options.IntegrationMaxStep)),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,C.initial_state),C.initial_state,qpi,p,struct('Symmetry','none'));
        uC=family.packState(C.initial_state);uSeed=family.packState(reflected);liftedSeed=family.fullState(uSeed);assert(isequaln(liftedSeed,reflected),'C1PKNegative:ExactSeedRoundtrip','Symmetrynone pack/lift must preserve the exact reflected14 seed; no fallback projection.');
        yPosition=find(family.CoordinateIndices==schema.State.y);assert(isscalar(yPosition),'C1PKNegative:HeightCoordinate','The actual free family chart must expose the marked COM height.');nCoord=numel(uC);nAug=nCoord+1;
        energy_C=QuadrupedEnergy_v3.evaluate(C.initial_state,qpi,p);marked_height_C=C.initial_state(schema.State.y);target_height=p(schema.Parameter.l_l_b);requested_height_step=marked_height_C-target_height;assert(requested_height_step>0,'C1PKNegative:HeightDirection','The predeclared experiment decreases marked height to the common rest length.');
        normal=zeros(nAug,1);normal(yPosition)=-1;constraint=struct('reference',[uC;energy_C],'normal',normal,'target',requested_height_step);Eguess=QuadrupedEnergy_v3.evaluate(reflected,qpi,p);initialCoordinates=[uSeed;Eguess];
        assert(isequal(normal(end),0)&&abs(normal.'*(initialCoordinates-constraint.reference)-constraint.target-(target_height-reflected(schema.State.y)))<=10*eps(max(1,abs(target_height))),'C1PKNegative:HeightEquation','The added residual must be L0-y in length units, with zero energy normal.');
        facts.definition=struct('family_symmetry','none','coordinate_indices',family.CoordinateIndices,'closure_indices',family.ClosureIndices,'energy_pivot',family.EnergyPivot,'chart',family.Chart,'nCoord',nCoord,'nAug',nAug,'maximum_function_calls_per_fresh_valid_sided_J',1+6*nAug,'FD_relative_step',1e-8,'FD_maximum_halvings',2,'FD_classical_derivative_claimed',false,'height_coordinate_position',yPosition,'height_state_index',schema.State.y,'energy_C',energy_C,'marked_height_C',marked_height_C,'target_height',target_height,'requested_height_step',requested_height_step,'height_units','native model length','energy_units','native Hamiltonian energy','constraint',constraint,'height_residual_definition','L0-y; separate NONEDGE fixed-observable shooting problem, not PAL progress','initial_coordinates',initialCoordinates,'initial_augmented_parameter',[p;Eguess],'exact_seed_roundtrip',true,'Einitial',Eguess,'physical_parameter_changed',false);
        facts.production_geometry_seed=productionGeometry(a,C,ra,rc,reflected,f,options,policy,work);
        verifySources(budget,epoch,refs,guards,work);assert(left(work)>240+4*300+180,'C1PKNegative:ScientificCapsFit','Reserve the full240 Root, maximum four300 fines and180 intake/storage allowance before the ONE Root.');trial=struct('u',utc()+240,'m',nano()+240e9);assert(trial.u<work.u&&trial.m<work.m,'C1PKNegative:RootFit','Never shorten the Root cap.');
        map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),section,HybridSimulator_v3(integration(trial,options.IntegrationMaxStep)),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,C.initial_state),C.initial_state,qpi,p,struct('Symmetry','none'));assert(isequal(family.CoordinateIndices,facts.definition.coordinate_indices)&&isequaln(family.fullState(uSeed),reflected),'C1PKNegative:TrialChart','The actual trial retains the declared exact-seed none chart.');native=ConstrainedEnergyResidual_v3(family,1:nCoord,constraint,ones(nAug,1));
        jacobian=ValidSidedFiniteDifferenceJacobian_v3(struct('RelativeStep',1e-8,'DeadlineUnixSeconds',trial.u,'DeadlineMonotonicNs',trial.m));solver=struct('Algorithm','root-newton','MaxIterations',40,'MaxFunctionEvaluations',3000,'FunctionTolerance',1e-11,'ResidualAcceptanceTolerance',1e-10,'StepTolerance',1e-13,'OptimalityTolerance',1e-18,'InitialDamping',1e-12,'ReuseJacobian',true,'InitialJacobian',[],'UseBroyden',true,'JacobianRefreshInterval',5,'Jacobian',jacobian);
        seed=struct('state',reflected,'mode',qpi,'parameter',p,'return_policy',policy,'occurrence',1,'provenance',struct('kind','unadmitted exact reflected unit initializer; NEW negative fixed-height NONEDGE shooting','experiment_id',facts.experiment_id,'unit_reference',unitReference,'owned_pair',f.source_pair));settings=struct('Symmetry','none','Residual',native,'Coordinates',initialCoordinates,'AugmentedParameter',[p;Eguess],'SolverOptions',solver,'MaxWallSeconds',max(.001,left(trial)));
        facts.declared_root_settings=struct('solver_options',rmfield(solver,'Jacobian'),'jacobian',jacobianDescriptor(jacobian),'integration',struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',options.IntegrationMaxStep),'trial_limit',trial,'cross_point_InitialJacobian_supplied',false);facts.periodic_solver_calls_attempted=1;phase('negative_periodic_Root_begin',startClock,struct('nCoord',nCoord,'nAug',nAug,'full_cap_seconds',240));
        [orbit,rawReport]=PeriodicSolutionSolver_v3(seed,settings);facts.root_returned=true;facts.root_timely_observed=left(trial)>0&&left(work)>0;facts.root_all_nine=nine(rawReport);facts.actual_RootSolver_return_present=isfield(rawReport,'solver')&&isstruct(rawReport.solver)&&isscalar(rawReport.solver)&&isfield(rawReport.solver,'functionEvaluationCount');facts.root_solver_facts=rootFacts(rawReport);facts.root_status=rawReport.status;phase('negative_periodic_Root_returned',startClock,struct('all_nine',facts.root_all_nine,'timely',facts.root_timely_observed,'RootSolver_return_present',facts.actual_RootSolver_return_present));
        facts.original_PSS_headers=originalPSSHeaders(rawReport);currentAdmission=isa(orbit,'HybridOrbit_v3')&&isscalar(orbit)&&facts.root_all_nine;
        if currentAdmission,pendingFacts=essentialPending(rawReport,facts);facts.pending_save_attempted=true;savePending(pending,orbit,pendingFacts);facts.pending_saved_read2_verified=true;facts.pending_admission_retained=true;end
        [rawReport,facts.report_sample_retention]=retireNewTraceSamples(rawReport,reference(which('SourceTrialTrace_v3')));storedReport=compactReport(rawReport);plain(storedReport);C1ScientificDigest_v3(storedReport);
        if facts.report_sample_retention.retirement_refused,facts.failed_native_report=storedReport;facts.status='diagnostic_retirement_refused_original_plain_report_retained';
        elseif ~currentAdmission,facts.failed_native_report=storedReport;facts.status='Root_returned_without_native_all_nine_admission';
        else
            facts.candidate_native_id=OrbitContentIdentity_v3(orbit);facts.candidate_saved_PK1_primitive=qualified(storedReport.classification);[controlPolicy,controlPolicyEvidence]=RecordedReturnPolicy_v3(storedReport);speed=OrbitSpeed_v3(orbit);
            meta=struct('component_identity',facts.experiment_id,'classification',storedReport.classification.validated_gait_type,'nativeE',QuadrupedEnergy_v3.evaluate(orbit.initial_state,orbit.initial_mode,orbit.parameter),'signedmeanU',speed.mean_signed_velocity,'edge_enabled',false,'provenance',struct('kind','independent negative fixed-height experimental NONEDGE all9 return','experiment_id',facts.experiment_id,'source_pair',f.source_pair,'source_reference',self,'root_all_nine',true,'root_timely_observed',facts.root_timely_observed,'primary_connection_claimed',false));
            assert(numel(guards)==4&&isequaln(guards{4},catalogueBefore)&&strcmp(RoundSHA256_v3(catalogue),catalogueBefore.sha256),'C1PKNegative:CatalogueCAS','Preserve both old points until the ONE authorized append.');guards(4)=[];facts.catalogue_guard_transition='append_in_progress_outcome_unknown';facts.catalogue_append_attempted=true;facts.catalogue_committed=[];phase('negative_catalogue_append_begin',startClock,struct('root_timely',facts.root_timely_observed));
            [newIndex,newPoint]=BranchSolutionFile_v3.append(catalogue,orbit,storedReport,meta);facts.catalogue_committed=true;facts.catalogue_index=newPoint;facts.catalogue_reference=reference(catalogue);
            x1=BranchSolutionFile_v3.index(catalogue);x2=BranchSolutionFile_v3.index(catalogue);assertPublicEqual(x1,x2,0);assertPublicEqual(newIndex,x1,0);assert(newPoint==3&&numel(x1.points)==3&&isempty(x1.edges),'C1PKNegative:CataloguePoint3','Retain point3 with no physical edge.');
            [Q,QR,QM]=BranchSolutionFile_v3.loadSolutions(catalogue,[1 2 3]);[P,S,T]=BranchSolutionFile_v3.loadSolutions(catalogue,[1 2 3]);assertPublicEqual(Q,P,0);assertPublicEqual(QR,S,0);assertPublicEqual(QM,T,0);assertPublicEqual(orbit,Q{3},0);assertPublicEqual(storedReport,QR{3},0);assertPublicEqual(meta,QM{3},0);
            for k=1:2,assertPublicEqual(oldO{k},Q{k},0);assertPublicEqual(oldR{k},QR{k},0);assertPublicEqual(oldM{k},QM{k},0);assertPublicEqual(oldIndex.points{k},x1.points{k},0);end;assertPublicEqual(oldIndex.metadata,x1.metadata,0);assert(all(cellfun(@(m)~m.edge_enabled,QM)),'C1PKNegative:CatalogueNoEdges','All three records remain isolated NONEDGE.');facts.catalogue_original_two_preservation_verified=true;facts.catalogue_read2_verified=true;guards{end+1,1}=facts.catalogue_reference;facts.catalogue_guard_transition='returned_point3_reference_after_all_three_native_read2';verifySources(budget,epoch,refs,guards,finish);retirePending(pending,orbit,pendingFacts);facts.pending_admission_retained=false;facts.catalogue_storage_timely_observed=left(work)>0;phase('negative_catalogue_read2_returned',startClock,struct('index',newPoint,'timely',facts.catalogue_storage_timely_observed));facts.candidate_record=record(orbit,storedReport,meta,x1.points{newPoint});clear Q QR QM P S T x1 x2 newIndex
            facts.comparison=localComparison(orbit,C,storedReport,rc);facts.production_geometry_control=productionGeometry(a,C,ra,rc,orbit.initial_state,f,options,policy,work);facts.actual_control_marked_height=orbit.initial_state(schema.State.y);facts.actual_control_height_error=facts.actual_control_marked_height-target_height;
            suitableControl=facts.candidate_saved_PK1_primitive&&isequaln(orbit.parameter,p)&&isequaln(orbit.initial_mode,qpi)&&orbit.initial_state(schema.State.dx)<0&&speed.mean_signed_velocity<0&&controlPolicyEvidence.complete&&isequaln(controlPolicyEvidence.configuration,pc.configuration);
            if ~facts.root_timely_observed||~facts.catalogue_storage_timely_observed,facts.status='all9_control_retained_but_late_unqualified';
            elseif ~suitableControl,facts.status='all9_control_retained_control_scope_refused';
            else
                [live,reconstruction]=freshIntegration(storedReport.replay_integration,work);limits=pick(storedReport.options,{'MaxReturnTime','MaxCycleEvents','MaxSectionCrossings'});assert(limits.MaxReturnTime==30&&limits.MaxCycleEvents==1000&&limits.MaxSectionCrossings==64,'C1PKNegative:FineLimits','Keep the original map horizon/event bounds.');service=struct('replay_integration',live,'correction_return_policy',controlPolicy,'options',limits,'acceptance',storedReport.acceptance,'classification',storedReport.classification,'event_signature',storedReport.event_signature);
                contract=struct('schema','C1-negative-unit-common-fine-service-v1','numeric_integration',reconstruction.all_other_integration_settings,'numeric_ODE_options',reconstruction.all_other_ODE_options,'solver','ode45','acceptance',storedReport.acceptance,'map_limits',limits,'BL_policy_configuration',controlPolicyEvidence.configuration,'event_signature',storedReport.event_signature,'called_method_references',{[epoch(:);refs(:)]},'profile_steps',[.0005 .00025],'RelTol',1e-12,'AbsTol',1e-14,'original_profile_cap_seconds',300,'deadline_callback_scope','Fresh immutable deadline only; never execute a historical saved callback.');plain(contract);facts.common_fine_service_contract=contract;facts.common_fine_service_contract_digest=C1ScientificDigest_v3(contract);facts.common_fine_runtime_reconstruction=reconstruction;
                sides=1;if facts.comparison.conditions_met,sides=[1 2];end;facts.fine_split_decision=struct('cheap_strict_comparison_passed',facts.comparison.conditions_met,'planned_sides',sides,'planned_original_profiles',2*numel(sides),'deferred_owned_profiles',2*(numel(sides)==1),'scope','Two control profiles alone never establish four-profile or finite owned-unit qualification. A later owned pair must reconstruct this exact control-derived common service contract.');targets={orbit;C};steps=[.0005 .00025];
                for side=sides
                    seed=struct('state',targets{side}.initial_state,'mode',targets{side}.initial_mode,'parameter',targets{side}.parameter,'return_policy',controlPolicy,'occurrence',1);
                    for level=1:2
                        verifySources(budget,epoch,refs,guards,work);assert(left(work)>300,'C1PKNegative:FineFit','Never shorten an original300 fine.');limit=fineLimit(300,budget,work);facts.fine_profile_requests=facts.fine_profile_requests+1;phase('negative_original_fine_begin',startClock,struct('side',side,'level',level,'full_cap_seconds',300));
                        [fine,ev,g]=C1PlainFineQualificationReplay_v3(seed,steps(level),service,limit);timely=utc()<limit.deadline_unix_seconds&&nano()<limit.deadline_monotonic_ns;facts.fine_full_return_map_calls_attempted=facts.fine_full_return_map_calls_attempted+double(ev.map_complete||strcmp(ev.phase_at_failure,'map'));item=negativeFineObservation(fine,ev,g,seed,targets{side},side,level,live,steps(level),timely,controlPolicyEvidence.configuration);facts.fines{end+1,1}=item;phase('negative_original_fine_returned',startClock,struct('side',side,'level',level,'timely',timely,'passed',item.all_declared_conditions_met));clear fine ev g item
                    end
                end
                mask=cellfun(@(v)v.side==1,facts.fines);facts.all_two_control_fines_passed=sum(mask)==2&&all(cellfun(@(v)v.all_declared_conditions_met,facts.fines(mask)));facts.all_four_original_fines_passed=numel(facts.fines)==4&&all(cellfun(@(v)v.all_declared_conditions_met,facts.fines));facts.finite_unit_conditions_met=facts.all_four_original_fines_passed&&facts.comparison.conditions_met;facts.status='negative_control_two_original_fines_returned_owned_fines_deferred';if numel(facts.fines)==4,facts.status='negative_control_and_owned_four_original_fines_returned';end
            end
        end
    catch problem
        facts.failure=exceptionData(problem);facts.status='partial_or_refused';
        if isfield(facts,'report_sample_retention')&&facts.report_sample_retention.retirement_refused&&~isfield(facts,'failed_native_report')
            facts.report_sample_retention.full_dense_payload_retained=false;facts.report_sample_retention.original_full_report_persistence_refused=true;facts.report_sample_retention.serialization_exception=exceptionData(problem);
        end
    end
    clear O R M U UR UM oldO oldR oldM oldIndex a C ra rc unit unitReport orbit rawReport storedReport map family native jacobian solver settings seed service live targets policy controlPolicy
    facts.pending_file_present=isfile(pending);facts.pending_admission_retained=facts.pending_saved_read2_verified&&facts.pending_file_present;facts.catalogue_file_present=isfile(catalogue);facts.catalogue_native_stage_present=isfile([catalogue '.pending.mat']);facts.completed=true;facts.finished_utc=stamp();facts.elapsed_seconds=(nano()-startClock.m)/1e9;
    facts.scope='One separately admitted Symmetrynone negative fixed-height NONEDGE control. Any close finite comparison is not physical attachment, reflected admission, exact grazing, branch completion, H<.5, or global endpoint evidence. Production pronkPAL geometry is measurement only; no step/status/source epoch changed.';facts.root_fact_scope='One PSS call only; actual RootSolver/J availability and timeliness are retained literally.1+6*nAug is the per-fresh-J maximum, not a bound on every Root evaluation.';
    verifySources(budget,epoch,refs,guards,finish);closedPathsCheck(closedPaths,finish);assert(strcmp(RoundSHA256_v3(output),roundBefore.sha256),'C1PKNegative:RoundClosest','Round changed before this one consolidated publication.');phase('negative_Round_publication_begin',startClock,struct('status',facts.status));round.primary_diagnostics.negative_unit_height_NONEDGE=facts;saveRound(output,json,round);clear round
    verifySources(budget,epoch,refs,guards,finish);closedPathsCheck(closedPaths,finish);small=negativeStdout(facts);text=jsonencode(small);assert(numel(unicode2native(text,'UTF-8'))<=100000,'C1PKNegative:Stdout','Full plain facts are in the read2-verified Round.');check(finish);fprintf('C1_PK_NEGATIVE_UNIT_CONTROL_ACTUAL_RETURN %s\n',text);check(finish);
end

function [f,o,epoch]=negativeJournal(j,core,budget)
    assert(isempty(fieldnames(j.active_run))&&isequaln(j.active_budget,budget)&&~strcmp(j.status,'native_pending_requires_reconciliation'),'C1PKNegative:ClosedJournal','Require the actual closed journal under the unchanged grant.');at=find(cellfun(@(x)strcmp(x.id,'PK_file_0006_graph_0001_leaf_000086'),j.frontiers));assert(isscalar(at),'C1PKNegative:Frontier','Select only the declared current negative86 frontier.');f=pick(j.frontiers{at},{'id','component_id','component_file','source_pair','source_reference','status','step','minimum_step','maximum_step','strategy_index','derivative_index','last_stop_reason','last_dispatched_sequence','run_count','consecutive_no_growth','total_new_points','initial_state','initial_mode','last_accepted_index'});o=j.options;epoch=j.source_code;
    assert(strcmp(f.component_file,core)&&isequal(f.source_pair,[483 484])&&strcmp(f.status,'ordinary_initializer_pilot_requires_review')&&f.derivative_index==1&&ismember(f.strategy_index,[1 2])&&o.TrialSeconds==240&&~o.ReusePreviousJacobian&&o.MinimumApexHeightRatio==.5&&~o.StopOnRangeCoverage,'C1PKNegative:Current86','Require the actual declared held owned pair; no status/control reset or global old hash assumption.');
end
function verifySources(budget,epoch,refs,guards,limit)
    check(limit);assert(isequaln(C1RunBudget_v3(),budget),'C1PKNegative:Budget','The original grant VALUE changed.');methods=[epoch(:);refs(:)];for k=1:numel(methods),r=methods{k};[~,name,extension]=fileparts(r.file);actual=which(name);assert(strcmp(extension,'.m')&&~isempty(actual)&&strcmp(char(java.io.File(actual).getCanonicalPath()),char(java.io.File(r.file).getCanonicalPath())),'C1PKNegative:Resolver','An actual called/source resolver differs: %s',r.file);end
    allRefs=[methods;guards(:)];for k=1:numel(allRefs),r=allRefs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1PKNegative:Source','A protected source or authority changed: %s',r.file);end;check(limit);
end
function out=productionGeometry(a,C,ra,rc,x,f,o,policy,limit)
    s=QuadrupedSchema_v3.shared();map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(integration(limit,o.IntegrationMaxStep)),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,C.initial_state),C.initial_state,C.initial_mode,C.parameter,struct('Symmetry','pronk'));ua=family.packState(a.initial_state);uC=family.packState(C.initial_state);scale=max([ones(numel(uC),1),abs(ua),abs(uC)],[],2);chord=(uC-ua)./scale;distance=norm(chord);assert(isfinite(distance)&&distance>1e-10,'C1PKNegative:ProductionChord','The unmodified production pair direction must resolve.');t=chord/distance;u=family.packState(x);lift=family.fullState(u);signedProjection=dot(t,(u-uC)./scale);predictor=family.fullState(uC+scale.*(signedProjection*t));sx=max(ones(13,1),abs(predictor(2:14)));out=struct('scope','PreRoot/returned-control measurement under the unchanged productionpronk chart only. No owned capture/admission or step proposal is performed.','coordinate_indices',family.CoordinateIndices,'ua',ua,'uC',uC,'scale',scale,'unit_tangent',t,'signed_PAL_projection',signedProjection,'scaled_coordinate_separation',norm((u-uC)./scale,inf),'requested_projection_predictor',predictor,'full13_capture_scaled_inf',norm((x(2:14)-predictor(2:14))./sx,inf),'capture_radius',.02,'full14_control_roundtrip_delta',lift-x,'control_roundtrip_exact',isequaln(lift,x),'current_frontier_step',f.step,'frontier_minimum_step',f.minimum_step,'global_minimum_step',o.MinimumStep,'positive_direction',signedProjection>0,'within_current_step_bounds',signedProjection>=max(f.minimum_step,o.MinimumStep)&&signedProjection<=min(f.maximum_step,o.MaximumStep),'current_pair_section_match',MatchingReturnSection_v3(a,C,{ra,rc}),'sign_or_absolute_value_repair_applied',false);
end
function [out,receipt]=retireNewTraceSamples(value,producer)
    out=value;receipt=struct('schema','C1-new-report-SourceTrialTrace-sample-retention-v1','omission_applied',false,'retirement_refused',false,'refusal',struct(),'path','partial_evidence.failure_trace.sample_diagnostics','observed_producer_reference',producer,'full_dense_payload_retained',true);
    if ~isfield(value,'partial_evidence')||~isstruct(value.partial_evidence)||~isscalar(value.partial_evidence)||~isfield(value.partial_evidence,'failure_trace'),return;end
    t=value.partial_evidence.failure_trace;names={'schema_version';'diagnostic_only';'accepted_periodic_solution';'initial_state';'initial_mode';'physical_parameter';'effective_integration_settings';'horizon';'trajectory';'execution';'scheduled_events';'first_physical_failure';'first_event_discrepancy';'sample_diagnostics';'actual_events'};
    known=isstruct(t)&&isscalar(t)&&isequal(sort(fieldnames(t)),sort(names));if known,known=ischar(t.schema_version)&&isrow(t.schema_version)&&strcmp(t.schema_version,'source-trial-trace-v3-1')&&isequal(t.diagnostic_only,true)&&isequal(t.accepted_periodic_solution,false);end
    if ~known,receipt.retirement_refused=true;receipt.refusal=struct('identifier','C1PKNegative:TraceSchema','message','Unknown trace schema: the original report is returned unaltered for ordinary report compaction/persistence; no sample omission.');return;end
    expectedProducer='abb9dfdb81f5e0a0b1d6b7443d266e1f099c3f93cd685df2e6dba74ac691698a';
    if ~strcmp(producer.sha256,expectedProducer)||~strcmp(RoundSHA256_v3(producer.file),expectedProducer),receipt.retirement_refused=true;receipt.refusal=struct('identifier','C1PKNegative:TraceProducer','message','The exact approved observed-current SourceTrialTrace producer is required before any recognized omission.');return;end
    removed=t.sample_diagnostics;fields={'time';'source';'state';'mode';'guard_values';'guard_directions';'guard_derivatives';'guard_enabled';'physical_admissibility';'axial_forces';'energy';'diagnostic_error'};
    if ~(isstruct(removed)&&(isvector(removed)||isempty(removed))&&isequal(sort(fieldnames(removed)),sort(fields))),receipt.retirement_refused=true;receipt.refusal=struct('identifier','C1PKNegative:SampleSchema','message','Unknown sample schema: the original report is returned unaltered; no guessed diagnostic summary.');return;end
    try,plain(removed);w=whos('removed');digest=C1ScientificDigest_v3(removed);catch problem,receipt.retirement_refused=true;receipt.refusal=exceptionData(problem);return;end
    descriptor=struct('schema','C1-retired-SourceTrialTrace-sample-diagnostics-v1','original_field','sample_diagnostics','original_class',class(removed),'original_shape',size(removed),'original_count',numel(removed),'original_logical_native_bytes',w.bytes,'typed_digest_schema','C1-plain-scientific-digest-v1','typed_digest',digest,'original_trace_field_order',{fieldnames(t)},'source_trace_schema',t.schema_version,'producer_source_observed_now',producer,'producer_birth_pin_available',false,'full_dense_payload_retained',false,'recomputed_physics',false,'scope','NEW report only: diagnostic per-sample payload intentionally unavailable. Other trace/report fields, Root/J/stencils/settings/failure/execution/first witnesses/events remain literal before the declared existing runtime-report compactor.');changed=rmfield(t,'sample_diagnostics');changed.retired_sample_diagnostics=descriptor;out.partial_evidence.failure_trace=changed;
    inverse=out;restored=rmfield(changed,'retired_sample_diagnostics');restored.sample_diagnostics=removed;restored=orderfields(restored,fieldnames(t));inverse.partial_evidence.failure_trace=restored;assertPublicEqual(value,inverse,0);receipt.omission_applied=true;receipt.full_dense_payload_retained=false;receipt.descriptor=descriptor;receipt.whole_other_fields_RAM_inverse_verified=true;
end
function h=originalPSSHeaders(r)
    h=struct('schema','C1-original-PSS-bounded-failure-headers-v1','scope','Literal known original PSS and first-witness scalar/text headers captured before report retirement/serialization. They do not summarize an unknown trace or replace the full plain report when that can be persisted.','text_prefix_limit',4096);
    for key={'status','failure_stage'},name=key{1};if isfield(r,name)&&ischar(r.(name))&&isrow(r.(name)),v=r.(name);h.(name)=v(1:min(4096,numel(v)));h.([name '_original_characters'])=numel(v);h.([name '_complete'])=numel(v)<=4096;end;end
    for key={'primary_failure','replay_failure','finalization_failure','failure','error'}
        name=key{1};if ~isfield(r,name)||~isstruct(r.(name))||~isscalar(r.(name)),continue;end;e=r.(name);q=struct();
        for textKey={'identifier','message'},field=textKey{1};if isfield(e,field)&&ischar(e.(field))&&(isrow(e.(field))||isempty(e.(field))),v=e.(field);q.(field)=v(1:min(4096,numel(v)));q.([field '_original_characters'])=numel(v);q.([field '_complete'])=numel(v)<=4096;end;end
        if isfield(e,'exitflag')&&isnumeric(e.exitflag)&&isscalar(e.exitflag),q.exitflag=e.exitflag;end;h.(name)=q;
    end
    if isfield(r,'partial_evidence')&&isstruct(r.partial_evidence)&&isscalar(r.partial_evidence)&&isfield(r.partial_evidence,'failure_trace')
        t=r.partial_evidence.failure_trace;if isstruct(t)&&isscalar(t)
            for key={'first_physical_failure','first_event_discrepancy'}
                name=key{1};if ~isfield(t,name)||~isstruct(t.(name))||~isscalar(t.(name)),continue;end;e=t.(name);q=struct();
                for scalarKey={'time','sample','found','cluster_index','time_difference'},field=scalarKey{1};if isfield(e,field)&&(isnumeric(e.(field))||islogical(e.(field)))&&isscalar(e.(field)),q.(field)=e.(field);end;end
                for textKey={'source','reason'},field=textKey{1};if isfield(e,field)&&ischar(e.(field))&&(isrow(e.(field))||isempty(e.(field))),v=e.(field);q.(field)=v(1:min(4096,numel(v)));q.([field '_original_characters'])=numel(v);q.([field '_complete'])=numel(v)<=4096;end;end;h.(name)=q;
            end
        end
    end
    plain(h);
end
function out=negativeFineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration)
    out=fineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration);names={'negative_control','owned_negative_C'};out.side_name=names{side};
end
function small=negativeStdout(facts)
    small=pick(facts,{'schema','experiment_id','source_reference','journal_reference','raw_source_reference','round_before_reference','unit_control_reference','catalogue_before_reference','periodic_solver_calls_attempted','root_returned','root_all_nine','root_timely_observed','actual_RootSolver_return_present','root_solver_facts','root_status','original_PSS_headers','actual_control_marked_height','actual_control_height_error','candidate_native_id','candidate_saved_PK1_primitive','catalogue_append_attempted','catalogue_committed','catalogue_index','catalogue_reference','catalogue_read2_verified','catalogue_original_two_preservation_verified','catalogue_storage_timely_observed','pending_save_attempted','pending_saved_read2_verified','pending_admission_retained','pending_file_present','comparison','fine_split_decision','common_fine_service_contract_digest','fine_profile_requests','fine_full_return_map_calls_attempted','all_two_control_fines_passed','all_four_original_fines_passed','finite_unit_conditions_met','report_sample_retention','failure','status','completed','journal_mutated','raw_store_mutated','physical_edges_added','canonical_graph_mutated','global_endpoint_claimed','owned_connection_claimed','half_height_stop_claimed','own_process_exit_observed','finished_utc','elapsed_seconds','scope','root_fact_scope'});
    if isfield(facts,'definition'),small.definition=pick(facts.definition,{'family_symmetry','nCoord','nAug','maximum_function_calls_per_fresh_valid_sided_J','height_coordinate_position','energy_C','marked_height_C','target_height','requested_height_step','Einitial','exact_seed_roundtrip'});end
    for key={'production_geometry_seed','production_geometry_control'},name=key{1};if isfield(facts,name),small.(name)=pick(facts.(name),{'signed_PAL_projection','scaled_coordinate_separation','full13_capture_scaled_inf','capture_radius','control_roundtrip_exact','current_frontier_step','frontier_minimum_step','global_minimum_step','positive_direction','within_current_step_bounds','sign_or_absolute_value_repair_applied'});end;end
    small.fines=cell(size(facts.fines));for k=1:numel(facts.fines),f=facts.fines{k};q=pick(f,{'side','side_name','original_profile_level','timely_observed','initial_trajectory_row_exact','qualified_PK1_primitive','saved_period_scaled_error','saved_full14_stride_scaled_error','map_complete','classifier_complete','sample_count','completed_scalar_sample_count','failure_phase','timings','effective_ODE_profile','all_declared_conditions_met'});q.fine=pick(f.fine,{'MaxStep','passed','status','budget_refusal','failure','full13_norm','period','maximum_energy_variation','maximum_stance_constraint'});q.classification_header=pick(f.actual_full_classification,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count','flight_count_certain','status'});if isfield(f.actual_full_classification,'primitive'),q.primitive_header=pick(f.actual_full_classification.primitive,{'status','cover_count','checked_cover_bound','primitive_period','global_primitivity_proved'});end;small.fines{k}=q;end
end

function yes=nine(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};yes=isstruct(r)&&isscalar(r)&&isfield(r,'acceptance_gates')&&all(isfield(r.acceptance_gates,keys))&&all(cellfun(@(k)isequal(r.acceptance_gates.(k),true),keys));
end
function assertPrimitive(r)
    assert(isfield(r,'primitive')&&strcmp(r.primitive.status,'primitive_within_checked_bound'),'C1PKE0:Primitive','Retain an actually checked primitive result independently of the optional primitive gate.');
end
function out=essentialPending(r,facts)
    keys={'status','accepted','initial_residual','initial_scaled_norm','initial_physical_norm','final_residual','final_scaled_norm','final_physical_norm','final_coordinates','final_candidate','failure','failure_stage','primary_failure','finalization_failure','solver','acceptance','acceptance_gates','classification','primitive','family_conditions','elapsed_seconds'};out=pick(r,keys);out.experiment_id=facts.experiment_id;out.root_timely_observed=facts.root_timely_observed;out.declared_root_settings=facts.declared_root_settings;out.definition=facts.definition;out.scope='Declared essential accepted-native custody projection, not full raw-report archive. Full numeric Root/J/FD/error/settings fields remain; nested runtime orbit/trace duplicates use the public explicit descriptors.';holder=CompactResearchBranch_v3(struct('essential_native_report',out));out=holder.essential_native_report;plain(out);C1ScientificDigest_v3(out);
end
function savePending(file,orbit,facts)
    assert(~isfile(file)&&~isfolder(file),'C1PKE0:PendingExists','Never overwrite an unresolved accepted-native payload.');pending=struct('schema','C1-PK-E0-accepted-native-pending-v1','orbit',orbit,'essential_plain_facts',facts);save(file,'pending','-v7');a=load(file,'pending');b=load(file,'pending');assertPublicEqual(pending,a.pending,0);assertPublicEqual(pending,b.pending,0);
end
function retirePending(file,orbit,facts)
    a=load(file,'pending');b=load(file,'pending');assertPublicEqual(a.pending,b.pending,0);assertPublicEqual(orbit,a.pending.orbit,0);assertPublicEqual(facts,a.pending.essential_plain_facts,0);delete(file);assert(~isfile(file),'C1PKE0:PendingRetirement','Owned pending retirement did not return.');
end
function out=fineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration)
    returnedPolicy=isfield(fine,'actual_policy');if returnedPolicy,[~,used]=RecordedReturnPolicy_v3(struct('correction_return_policy',fine.actual_policy));assert(used.complete&&isequaln(used.configuration,configuration),'C1PKE0:FinePolicy','Fresh fine changed the actual return policy.');fine.actual_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',configuration.source_class,'settings',configuration.settings);end
    firstExact=ev.sample_count>0&&isequaln(ev.trajectory.state(1,:).',seed.state)&&isequaln(logical(ev.trajectory.mode(1,:).'),logical(seed.mode));periodError=NaN;strideError=NaN;if isfield(fine,'period'),periodError=abs(fine.period-original.period)/max([1,abs(fine.period),abs(original.period)]);end;if isfield(fine,'stride_displacement'),sx=max([ones(14,1),abs(fine.stride_displacement(:)),abs(original.stride_displacement(:))],[],2);strideError=norm((fine.stride_displacement(:)-original.stride_displacement(:))./sx,Inf);end
    names={'candidate','original_unit'};out=struct('side',side,'side_name',names{side},'original_profile_level',level,'fine',fine,'actual_full_classification',g,'timely_observed',timely,'initial_trajectory_row_exact',firstExact,'qualified_PK1_primitive',qualified(g),'saved_period_scaled_error',periodError,'saved_full14_stride_scaled_error',strideError,'map_complete',ev.map_complete,'classifier_complete',ev.classifier_complete,'sample_count',ev.sample_count,'completed_scalar_sample_count',ev.completed_scalar_sample_count,'failure_phase',ev.phase_at_failure,'timings',ev.timings,'effective_ODE_profile',effectiveProfile(integration,step),'all_declared_conditions_met',fine.passed&&timely&&qualified(g)&&firstExact&&returnedPolicy&&ev.map_complete&&ev.classifier_complete&&ev.completed_scalar_sample_count==ev.sample_count&&periodError<=1e-8&&strideError<=1e-8);
end
function closedPathsCheck(paths,limit)
    check(limit);for k=1:numel(paths),assert(~isfile(paths{k}),'C1PKE0:Unresolved','An unresolved native journal/core/Round stage exists: %s',paths{k});end
end
function phase(name,start,extra)
    item=struct('phase',name,'utc',stamp(),'outer_elapsed_seconds',(nano()-start.m)/1e9,'detail',extra);text=jsonencode(item);assert(numel(unicode2native(text,'UTF-8'))<=10000,'C1PKE0:PhaseOutput','Stage marker exceeded its declared bound.');fprintf('C1_PK_E0_STAGE %s\n',text);
end
function value=integration(limit,maxStep)
    value=struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',maxStep,'ODEOptions',odeset('OutputFcn',@(~,~,~)double(left(limit)<=0)));
end
function out=record(o,r,m,ix)
    out=struct('index',ix.index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o),'initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full14_stride',o.stride_displacement,'metadata',m,'saved_all_nine',r.acceptance_gates,'saved_classification',r.classification,'saved_primitive',r.primitive);
end

function out=rootFacts(r)
    out=struct('available',isfield(r,'solver'));if ~out.available,return;end;s=r.solver;out.literal=pick(s,{'solver','exitflag','converged','residualNorm','functionEvaluationCount','mapEvaluationCount','cacheHitCount','invalidEvaluationCount','jacobianEvaluationCount','derivativeModel','derivativeEvaluated','acceptedNewtonIterations','invalidTrialCount','stateScale','finalJacobian','jacobianReliable','selectedFiniteDifferenceSteps','perColumnReliability'});if isfield(s,'output'),out.output=pick(s.output,{'iterations','funcCount','algorithm','rootTolerance','stepsize','acceptedIterations','invalidTrialCount','initialJacobianUsed','RootNewtonMinimumRcond','lastReciprocalCondition','lastLinearRelativeBackwardError','finalJacobianFreshAtFinalState','message'});end
end

function out=reportView(reports)
    out=cell(size(reports));for k=1:numel(reports),out{k}=pick(reports{k},{'status','accepted','native_status','classification','primitive','acceptance','acceptance_gates','replay_integration','event_signature','correction_return_policy','options'});out{k}.bounded_root_facts=rootFacts(reports{k});end
end

function yes=sameCohort(a,b)
    yes=true;for key={'section_relative_event_signature','cyclic_event_signature','event_cluster_signature','cyclic_event_cluster_signature'},x=a.(key{1});y=b.(key{1});yes=yes&&strlength(string(x))>0&&strlength(string(y))>0&&strcmp(string(x),string(y));end
end

function out=localComparison(a,b,ra,rb)
    dx=a.initial_state(2:14)-b.initial_state(2:14);sx=max([ones(13,1),abs(a.initial_state(2:14)),abs(b.initial_state(2:14))],[],2);dt=a.period-b.period;ts=max([1,abs(a.period),abs(b.period)]);dq=a.stride_displacement(:)-b.stride_displacement(:);qs=max([ones(14,1),abs(a.stride_displacement(:)),abs(b.stride_displacement(:))],[],2);match=MatchingReturnSection_v3(a,b,{ra,rb});[~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);
    out=struct('raw_full13_delta',dx,'raw_full13_scaled_inf',norm(dx./sx,inf),'period_delta',dt,'period_tolerance',1e-10*ts,'full14_stride_delta',dq,'full14_stride_tolerance',1e-10*qs,'native_energy_delta',QuadrupedEnergy_v3.evaluate(a.initial_state,a.initial_mode,a.parameter)-QuadrupedEnergy_v3.evaluate(b.initial_state,b.initial_mode,b.parameter),'exact_state_equal',isequaln(a.initial_state,b.initial_state),'exact_p_q_equal',isequaln(a.parameter,b.parameter)&&isequaln(a.initial_mode,b.initial_mode),'matching_section',match,'exact_complete_policy_equal',pa.complete&&pb.complete&&isequaln(pa.configuration,pb.configuration),'saved_four_discrete_cohort_match',sameCohort(a,b),'conditions_met',false);
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full14_stride_tolerance)&&out.exact_p_q_equal&&match.compatible&&out.exact_complete_policy_equal&&out.saved_four_discrete_cohort_match;
end

function audit=savedIntegrationAudit(saved)
    assert(isstruct(saved)&&isscalar(saved)&&all(isfield(saved,{'ODESolver','ODEOptions'}))&&isstruct(saved.ODEOptions)&&isscalar(saved.ODEOptions));audit=struct('solver_header',callbackHeader(saved.ODESolver),'output_callback_header',struct(),'events_callback_header',struct(),'stop_condition_header',struct(),'saved_closure_executed',false);numeric=rmfield(saved,{'ODESolver','ODEOptions'});nested=saved.ODEOptions;
    if isfield(numeric,'StopCondition'),audit.stop_condition_header=callbackHeader(numeric.StopCondition);numeric=rmfield(numeric,'StopCondition');end
    if isfield(nested,'OutputFcn'),audit.output_callback_header=callbackHeader(nested.OutputFcn);nested=rmfield(nested,'OutputFcn');end
    if isfield(nested,'Events'),audit.events_callback_header=callbackHeader(nested.Events);nested=rmfield(nested,'Events');end
    plain(numeric);plain(nested);audit.all_other_integration_settings=numeric;audit.all_other_ODE_options=nested;
end

function [live,audit]=freshIntegration(saved,limit)
    native=HybridSimulator_v3();defaults=native.Options;assert(isstruct(saved)&&isscalar(saved)&&isequal(sort(fieldnames(saved)),sort(fieldnames(defaults))),'C1PKFine:IntegrationSchema','Native verification refused; original observations are retained.');
    assert(isempty(saved.StopCondition)&&isstruct(saved.ODEOptions)&&isscalar(saved.ODEOptions),'C1PKFine:Callback','Native verification refused; original observations are retained.');
    odeDefaults=odeset();assert(isequal(sort(fieldnames(saved.ODEOptions)),sort(fieldnames(odeDefaults)))&&isempty(saved.ODEOptions.Events),'C1PKFine:ODEFields','Native verification refused; original observations are retained.');
    solverHeader=knownCallback(saved.ODESolver,'ode45');outputHeader=knownCallback(saved.ODEOptions.OutputFcn,'@(~,~,~)double(left(limit)<=0)');
    numeric=saved;numeric=rmfield(numeric,{'ODESolver','ODEOptions'});plain(numeric);odeNumeric=rmfield(saved.ODEOptions,'OutputFcn');plain(odeNumeric);
    live=saved;live.ODESolver=@ode45;live.ODEOptions.OutputFcn=@(~,~,~)budgetOutput(limit);rebuilt=HybridSimulator_v3(live);assert(isequaln(rebuilt.Options,live),'C1PKFine:IntegrationRoundtrip','Native verification refused; original observations are retained.');
    audit=struct('original_solver_header',solverHeader,'original_output_callback_header',outputHeader,'all_other_integration_settings',numeric,'all_other_ODE_options',odeNumeric, ...
        'replacements',{{'Known native ode45 descriptor to fresh @ode45','Known old deadline OutputFcn to fresh immutable-limit callback'}},'saved_closure_executed',false);
end

function out=knownCallback(value,expected)
    header=callbackHeader(value);detail=jsonencode(header);
    if isa(value,'function_handle')&&isscalar(value),signature=func2str(value);out=struct('class',class(value),'signature',signature);
    else
        assert(isstruct(value)&&isscalar(value)&&isequal(sort(fieldnames(value)),sort({'diagnostic_kind';'signature';'requires_runtime_reconstruction'}))&&strcmp(value.diagnostic_kind,'runtime-function-descriptor')&&isequal(value.requires_runtime_reconstruction,true),'C1PKFine:CallbackDescriptor','Unsupported saved callback header: %s',detail);signature=value.signature;out=value;
    end
    assert(ischar(signature)&&isrow(signature)&&strcmp(regexprep(signature,'\s',''),expected),'C1PKFine:CallbackSignature','Unexpected saved callback; no callback is rehydrated. Header: %s',detail);
end

function header=callbackHeader(value)
    header=struct('class',class(value),'size',size(value),'total_field_count',0,'fieldnames_first_32',{{}});
    if isstruct(value)
        names=fieldnames(value);header.total_field_count=numel(names);header.fieldnames_first_32=names(1:min(32,numel(names)));
        if isscalar(value)&&isfield(value,'signature')
            literal=value.signature;header.signature_class=class(literal);header.signature_size=size(literal);
            if ischar(literal)&&isrow(literal)&&numel(literal)<=1024,header.signature_text=literal;end
        end
    elseif isa(value,'function_handle')&&isscalar(value)
        literal=func2str(value);header.signature_length=numel(literal);header.signature_text=literal(1:min(1024,numel(literal)));
    end
end

function p=effectiveProfile(integration,step)
    nested=integration.ODEOptions;rel=1e-12;absolute=1e-14;if ~isempty(nested.RelTol),rel=min(rel,nested.RelTol);end;if ~isempty(nested.AbsTol),absolute=min(absolute,nested.AbsTol);end
    h=step;if ~isempty(nested.MaxStep),h=min(h,nested.MaxStep);end;p=struct('declared_RelTol',1e-12,'declared_AbsTol',1e-14,'declared_MaxStep',step,'effective_RelTol',max(rel,100*eps),'configured_minimum_RelTol',rel,'effective_AbsTol',absolute,'effective_MaxStep',h,'ode45_RelTol_floor',100*eps,'nested_options_preserved',true);
end

function yes=qualified(g)
    yes=isstruct(g)&&isscalar(g)&&strcmp(member(g,'contract_version',''),'quadruped-gait-v3.5')&&strcmp(member(g,'validated_gait_type',''),'PK')&&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1)&&isfield(g,'primitive')&&strcmp(member(g.primitive,'status',''),'primitive_within_checked_bound');
end

function value=fineLimit(seconds,budget,work)
    u=utc()+seconds;m=nano()+seconds*1e9;assert(u<work.u&&m<work.m,'C1PKFine:FineFit','Native verification refused; original observations are retained.');value=struct('deadline_unix_seconds',u,'deadline_utc',utcString(u),'deadline_monotonic_ns',m,'campaign_deadline_utc',utcString(budget.research_deadline_unix_seconds),'campaign_deadline_monotonic_ns',budget.research_deadline_monotonic_ns);
end

function s=utcString(u),v=datetime(u,'ConvertFrom','posixtime','TimeZone','UTC');v.Format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";s=char(v);end

function status=budgetOutput(limit),check(limit);status=0;end

function e=exceptionData(p),e=struct('identifier',p.identifier,'message',p.message,'stack',p.stack);end

function plain(v)
    if isstruct(v),for k=1:numel(v),for f=fieldnames(v).',plain(v(k).(f{1}));end,end
    elseif iscell(v),for k=1:numel(v),plain(v{k});end
    else,assert(isnumeric(v)||islogical(v)||ischar(v)||isstring(v),'C1PKFine:NonportableSetting','Unknown runtime setting is not silently replaced.');end
end


function [policy,evidence]=admitted(o,r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&isfield(r,'acceptance_gates')&&all(isfield(r.acceptance_gates,keys))&&all(cellfun(@(k)isequal(r.acceptance_gates.(k),true),keys)),'C1PKPrimary:AllNine','Native verification refused; original observations are retained.');
    if isfield(r,'accepted'),accepted=isequal(r.accepted,true);else,accepted=strcmp(member(r,'status',member(r,'native_status','')),'accepted');end
    assert(accepted&&strcmp(r.classification.contract_version,'quadruped-gait-v3.5')&&strcmp(r.classification.validated_gait_type,'PK')&&isequal(r.classification.canonical_label_qualified,true)&&isequal(r.classification.flight_count_certain,true)&&isequal(r.classification.flight_count,1),'C1PKPrimary:Class','Native verification refused; original observations are retained.');
    [policy,evidence]=RecordedReturnPolicy_v3(r);assert(evidence.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKPrimary:Policy','Native verification refused; original observations are retained.');
end

function assertPublicEqual(a,b,depth)
    assert(depth<=128&&strcmp(class(a),class(b))&&isequal(size(a),size(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    if isnumeric(a)||islogical(a),assert(issparse(a)==issparse(b)&&isreal(a)==isreal(b)&&isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif ischar(a)||isstring(a),assert(isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif iscell(a),for k=1:numel(a),assertPublicEqual(a{k},b{k},depth+1);end
    elseif isstruct(a),keys=fieldnames(a);assert(isequal(keys,fieldnames(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    elseif ismember(class(a),{'HybridOrbit_v3','Trajectory_v3'}),keys=sort(properties(a));assert(isequal(keys,sort(properties(b))),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    else,assert(isequaln(a,b),'C1PKPrimary:NativeRead2','Native verification refused; original observations are retained.');end
end

function saveRound(file,json,round)
    stage=[file '.pending.mat'];save(stage,'round','-v7');a=load(stage,'round');b=load(stage,'round');assert(isequaln(a.round,round)&&isequaln(b.round,round),'C1PKPrimary:StageRead2','Native verification refused; original observations are retained.');[ok,msg]=movefile(stage,file,'f');assert(ok,'C1PKPrimary:Publish','%s',msg);
    text=jsonencode(round,PrettyPrint=true);stage=[json '.pending.json'];fid=fopen(stage,'w');assert(fid>=0);closer=onCleanup(@()fclose(fid));bytes=unicode2native(text,'UTF-8');assert(fwrite(fid,bytes,'uint8')==numel(bytes));clear closer
    assert(isequaln(jsondecode(fileread(stage)),jsondecode(text)));[ok,msg]=movefile(stage,json,'f');assert(ok,'C1PKPrimary:Publish','%s',msg);a=load(file,'round');b=load(file,'round');assert(isequaln(a.round,round)&&isequaln(b.round,round)&&isequaln(jsondecode(fileread(json)),jsondecode(text)),'C1PKPrimary:InstalledRead2','Native verification refused; original observations are retained.');
end

function out=pick(s,keys),out=struct();for k=1:numel(keys),if isstruct(s)&&isscalar(s)&&isfield(s,keys{k}),out.(keys{k})=s.(keys{k});end,end,end

function out=member(s,key,fallback),out=fallback;if isstruct(s)&&isscalar(s)&&isfield(s,key),out=s.(key);end,end

function r=reference(file),r=struct('file',file,'sha256',RoundSHA256_v3(file));end

function check(c),assert(left(c)>0,'C1PKPrimary:Clock','Native verification refused; original observations are retained.');end

function value=left(c),value=min(c.u-utc(),(c.m-nano())/1e9);end

function u=utc(),u=posixtime(datetime('now','TimeZone','UTC'));end

function m=nano(),m=double(java.lang.System.nanoTime);end

function t=stamp(),v=datetime('now','TimeZone','UTC');v.Format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";t=char(v);end


function value=compactReport(value)
    % Preserve correction facts while omitting only runtime reconstruction.
    [~,policyEvidence]=RecordedReturnPolicy_v3(value);
    if policyEvidence.complete
        c=policyEvidence.configuration;
        value.correction_return_policy=struct('diagnostic_kind','runtime-object-descriptor', ...
            'source_class',c.source_class,'settings',c.settings);
    end
    if isfield(value,'options')&&isstruct(value.options)
        if isfield(value.options,'Residual')&&~isempty(value.options.Residual)
            value.options.Residual=[];value.options_residual_runtime_object_omitted=true;
        end
        if isfield(value.options,'SolverOptions')&&isstruct(value.options.SolverOptions) ...
                &&isfield(value.options.SolverOptions,'Jacobian')&&isobject(value.options.SolverOptions.Jacobian)
            j=value.options.SolverOptions.Jacobian;
            assert(isa(j,'FiniteDifferenceJacobian_v3'),'C1Continuation:Report','Unexpected Jacobian runtime object.');
            value.options.SolverOptions.Jacobian=jacobianDescriptor(j);
        end
    end
    holder=CompactResearchBranch_v3(struct('report',value));value=holder.report;
end


function out=jacobianDescriptor(j)
    keys={'Method','RelativeStep','MinimumStep','MaximumStep','CheckFinite','FailurePolicy'};
    if strcmp(class(j),'ValidSidedFiniteDifferenceJacobian_v3')
        keys=[keys,{'DeadlineUnixSeconds','DeadlineMonotonicNs','MaximumHalvings'}];
    else
        assert(strcmp(class(j),'FiniteDifferenceJacobian_v3'), ...
            'C1Continuation:Report','Unknown Jacobian runtime class.');
    end
    assert(isscalar(j) ...
        &&isequal(sort(properties(j)),sort(keys(:))), ...
        'C1Continuation:Report','The complete exact known FD settings schema is required.');
    settings=struct();for k=1:numel(keys),settings.(keys{k})=j.(keys{k});end
    out=struct('diagnostic_kind','runtime-object-descriptor', ...
        'source_class',class(j),'settings',settings);
end

