function audit=QualifyC1PKOwnedP1ControlAnchorFork20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,options)
% Two fresh original-state profiles of the ACTUAL closed0073 owned152 fork.
% No Root, control reacquisition, admission, graph/status/journal/raw/Round mutation.
    entry=clockPair();validSHA(expectedLedgerSHA);validSHA(expectedRawSHA);validSHA(expectedRoundSHA);
    exactFields(options,{'ForkReference','CheckpointReference','ForkClosureReference','Saved179Reference','RemainingReference', ...
        'Saved179RawReference','RemainingRawReference','OutputAuditFile','ProtectedReferences'});o=options;
    keys={'ForkReference','CheckpointReference','ForkClosureReference','Saved179Reference','RemainingReference','Saved179RawReference','RemainingRawReference'};
    for k=1:numel(keys),o.(keys{k})=checked(o.(keys{k}));end
    expected={'458361b3a9894cc864a1bccd31f6024f26a2a7934a9950225a3e040361262e2d';'ff0322a8bd516d71894a5ecc10521ca45e8af1a36fa2a1b4625f072522463060'; ...
        '0d23d3437127ae4492fe928590aa59e2af5137451df9e5c387b4e5f07c49a816';'1fd2ec2572f35423ad94f524df8c95a92c3adf474f97ccf719e94c2e82fa45fd'; ...
        'da6ec1687ebc62a8c21c651e3d5a2daf84f169cae7e249b6ba23baca809c5d58';'9f51c9b35a258e97d8734548773cec3ddf6449302286e2f809266a6e420e923e'; ...
        'a15b6a659bb1d0ff8e2ee73324a7e3e5bb7de29584d8af3f8ecb683015c824a9'};
    for k=1:numel(keys),assert(strcmp(o.(keys{k}).sha256,expected{k}),'C1PKAnchorFine:Authority','Bind exact actual0073 fork/checkpoint/closure and actual direct historical control authorities.');end
    root=canonical(fileparts(which('C1RunBudget_v3')));budget=C1RunBudget_v3();finish=shift(entry,1800);work=shift(finish,-180);
    assert(finish.utc<budget.research_deadline_unix_seconds&&finish.mono<budget.research_deadline_monotonic_ns,'C1PKAnchorFine:WholeFit','Full1800 including180 reserve must fit BOTH unchanged SCIENCE clocks.');
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));raw=canonical(fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'));
    roundFile=canonical(fullfile(root,'Audits','PK36h_20261031_Round.mat'));o.OutputAuditFile=canonical(o.OutputAuditFile);stage=[o.OutputAuditFile,'.pending.mat'];
    assert(strcmp(fileparts(o.OutputAuditFile),canonical(fullfile(root,'Audits')))&&endsWith(o.OutputAuditFile,'.mat'),'C1PKAnchorFine:Output','Use one fresh Audits MAT.');
    live={struct('file',ledger,'sha256',expectedLedgerSHA);struct('file',raw,'sha256',expectedRawSHA);struct('file',roundFile,'sha256',expectedRoundSHA)};
    refs=live;for k=1:numel(keys),refs{end+1,1}=o.(keys{k});end;refs=[refs;references(o.ProtectedReferences)];
    self=reference(which(mfilename));code=codeRefs(self,o.ProtectedReferences);for k=1:numel(refs),assert(~ismember(refs{k}.file,{o.OutputAuditFile,stage}),'C1PKAnchorFine:Disjoint','Outputs cannot replace any consumed authority.');end
    fresh({o.OutputAuditFile,stage});audit=struct('schema','C1-owned-PK-P1-control-anchor-fork-two-fine-qualification-v1','source_reference',self,'options',o, ...
        'budget',budget,'wrapper_entry',entry,'wrapper_finish',finish,'wrapper_work',work,'original_profile_seconds',300,'profile_steps',[.0005 .00025], ...
        'target_original_column',152,'current_references',{live},'actual_method_references',{code},'fork_reference',o.ForkReference,'checkpoint_reference',o.CheckpointReference, ...
        'actual_fork_closed_verified',false,'fork_native_read2_verified',false,'target_native_read2_verified',false,'owned_edge_verified',false, ...
        'stored_checkpoint_persistence_completion_confirmed',false,'actual_return_persistence_completion_confirmed',false,'records',{{}},'comparison',struct(), ...
        'target_intake_headers',{{}},'historical_qualification',struct(),'historical_contract_observations',{{}},'historical_common_contract_equality','UNASSESSED', ...
        'historical_common_contract_claimed',false,'all_four_target_cohorts_established',false,'all_four_target_cohorts_scope','UNASSESSED; one target section-relative token is established, not absence of other cohorts.', ...
        'fresh_service_contract',struct(),'fresh_service_contract_digest','','fines',{{}},'fine_calls_attempted',0,'fine_calls_returned',0,'all_two_owned_fines_passed',false, ...
        'finite_NEW152_comparison_with_independent_fines',false,'root_calls',0,'admissions',0,'physical_edges_added',0,'source_posthash',false, ...
        'stage_save_returned',false,'stage_read2_verified',false,'publication_returned',false,'installed_read2_verified',false,'completed',false,'failure',struct(),'own_process_exit_observed',false, ...
        'journal_mutated',false,'raw_mutated',false,'Round_mutated',false,'graph_mutated',false,'frontier_status_changed',false,'endpoint_claimed',false,'global_completion_claimed',false, ...
        'status','prepared','scope','Two new unchanged-state owned152 profiles plus separate historical NEW152 qualification. No Root, common-contract/four-cohort upgrade, primary merge, original-v2 trajectory identity, endpoint or completion.');
    normalReturned=false;
    try
        guard(work);assert(isfile([ledger,'.writer.lock']),'C1PKAnchorFine:Lock','Require stable existing ledger lock.');lock=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
        [w,q,sp]=forkClosure(o.ForkClosureReference,root,work);validateForkMarker(q,sp,o,raw,expectedRawSHA);audit.actual_fork_closed_verified=true;audit.actual_fork_closure=w;
        [targets,points,historical]=storedControls(o,work,@nativeTwice,@emitTargetHeader);target=targets{1};targetPoint=points{1};audit.target_native_read2_verified=true;
        assert(target.current_PK1_all9_evidence_complete,'C1PKAnchorFine:TargetAdmission','Current NEW152 evidence must be complete for this qualification, not merely a bare stored-state comparison.');
        audit.historical_qualification=historical;audit.target=target;
        [witness,policyReport,signature]=storedSection(target,targetPoint,work);targetShapes(target,witness);clear targets points targetPoint historical
        s=nativeTwice(o.CheckpointReference.file,'summary','fork_checkpoint',work);
        assert(isequal(s.persistence_completion_confirmed,false),'C1PKAnchorFine:Checkpoint','Retain original provisional checkpoint false.');
        h=projectRunHeader(s);h.persistence_completion_confirmed=true;
        assert(isequaln(jsondecode(jsonencode(h)),q.Run_observation),'C1PKAnchorFine:ReturnedSummary','Compare EXACT e171 Run projection with only provisional persistence normalized; retain both original flags separately.');
        assert(s.new_points==1&&s.new_edges==1&&s.initial_output_count==2&&s.final_output_count==3&&numel(s.attempts)==1 ...
            &&isempty(fieldnames(s.pending_admission))&&isempty(fieldnames(s.failure))&&isempty(s.isolated_native_admissions)&&isequaln(s.original_budget,budget) ...
            &&strcmp(canonical(s.configuration.source_file),raw)&&isequal(s.configuration.source_indices,q.source_pair(:).'), ...
            'C1PKAnchorFine:NativeRun','Require one clean actual owned append and original native grant/source pair; pending/late/recovery is not repaired.');
        a=s.attempts{1};assert(a.attempt==1&&a.source_point==2&&a.all_nine&&a.timely&&a.edge_committed&&a.storage_attempted&&a.storage_timely ...
            &&~a.isolated_committed&&isempty(a.isolated_storage_timely)&&strcmp(a.algorithm,'root-newton')&&strcmp(s.corrector_initializer,'base') ...
            &&strcmp(a.corrector_initialization.method,'base')&&~a.previous_jacobian_reuse.requested,'C1PKAnchorFine:ActualAttempt','Bind original timely all9/captured owned row.');
        checkCapture(a.capture);audit.actual_owned_attempt=pick(a,{'attempt','source_point','step','algorithm','derivative_method','relative_step','timely','all_nine','edge_committed','storage_attempted','storage_timely','capture','corrector_initialization'});
        audit.stored_checkpoint_persistence_completion_confirmed=s.persistence_completion_confirmed;audit.actual_return_persistence_completion_confirmed=q.Run_observation.persistence_completion_confirmed;
        fprintf('C1_PK_ANCHOR_FINE_BEFORE_FORK_INDEX\n');ix=BranchSolutionFile_v3.index(o.ForkReference.file);fprintf('C1_PK_ANCHOR_FINE_AFTER_FORK_INDEX_RETURN\n');guard(work);
        assert(numel(ix.points)==3&&numel(ix.edges)==1&&ix.edges{1}.from==2&&ix.edges{1}.to==3&&strcmp(ix.edges{1}.component_identity,q.component_identity),'C1PKAnchorFine:Edge','Preserve exact local2->3 and its fresh owner.');
        projected=asCells(q.fork_records);sourceHeaders=asCells(q.source_chain_headers);
        for pass=1:2
            fprintf('C1_PK_ANCHOR_FINE_BEFORE_FORK_LOAD %d\n',pass);[O,R,M]=BranchSolutionFile_v3.loadSolutions(o.ForkReference.file,(1:3).');fprintf('C1_PK_ANCHOR_FINE_AFTER_FORK_LOAD_RETURN %d\n',pass);guard(work);
            headers=cell(3,1);for k=1:3
                strictPK(O{k},R{k},[10;10;20;20;1;1;0;0;2;.5]);headers{k}=pointHeader(O{k},R{k},M{k},ix.points{k},k);
                assert(strcmp(headers{k}.owner,q.component_identity)&&isequaln(jsondecode(jsonencode(projectRecordHeader(headers{k}))),projected{k}), ...
                    'C1PKAnchorFine:ForkIdentity','Native read must equal EXACT e171 compact record projection, not an invented full-header JSON proof.');
            end
            if pass==1,first=headers;clear O R M;else,assertPublicEqual(headers,first,0);end
        end
        assert(strcmp(headers{3}.native_id,'native-orbit-record:sha256:de2377899ffd105216ab6f155e26a7bbdb1027fd87ea932319a012b1e548df84') ...
            &&M{3}.edge_enabled&&M{3}.edge_from==2&&M{3}.provenance.source_point==2&&M{3}.provenance.attempt==1 ...
            &&isequaln(M{3}.provenance.capture,a.capture)&&isequaln(M{3}.provenance.corrector_initialization,a.corrector_initialization), ...
            'C1PKAnchorFine:OwnedProvenance','Use actual0073 point3 and unchanged attempt/capture/base initialization.');
        for k=1:2
            hit=find(cellfun(@(x)x.index==q.source_pair(k),sourceHeaders));assert(isscalar(hit),'C1PKAnchorFine:SourceSelector','Use one actual original source record per imported seed.');
            assert(~M{k}.edge_enabled&&~isfield(M{k},'edge_from')&&strcmp(M{k}.provenance.kind,'imported nonedge initial pair') ...
                &&M{k}.provenance.source_index==q.source_pair(k)&&strcmp(headers{k}.native_id,sourceHeaders{hit}.native_id), ...
                'C1PKAnchorFine:Seeds','Both selected actual source NativeIDs remain imported NONEDGE anchors.');
        end
        audit.records=headers;audit.fork_native_read2_verified=true;audit.owned_edge_verified=true;audit.actual_owned_edge=ix.edges{1};
        audit.comparison=compareTarget(O{3},R{3},target,witness,policyReport,signature);assert(audit.comparison.conditions_met,'C1PKAnchorFine:CheapComparison','Only the actual cheap-match success authorizes owned fines.');
        [service,integration,serviceAudit]=forkFineService(R{3},work);serviceAudit.called_method_references=code;audit.fresh_service_contract=serviceAudit;audit.fresh_service_contract_digest=C1ScientificDigest_v3(serviceAudit);
        seed=struct('state',O{3}.initial_state,'mode',O{3}.initial_mode,'parameter',O{3}.parameter,'return_policy',service.correction_return_policy,'occurrence',1);
        audit.original_owned_seed=struct('state',seed.state,'mode',seed.mode,'parameter',seed.parameter,'native_id',headers{3}.native_id);
        assert(left(work)>2*300+60,'C1PKAnchorFine:BothSlots','Both full original300 slots plus post-call allowance must fit before any fine.');steps=[.0005 .00025];
        for level=1:2
            guard(work);assert(left(work)>300,'C1PKAnchorFine:FineFit','Never shorten an original300 profile.');limit=fineLimit(300,budget,struct('u',work.utc,'m',work.mono));
            audit.fine_calls_attempted=audit.fine_calls_attempted+1;fprintf('C1_PK_ANCHOR_FINE_BEFORE_PROFILE %d\n',level);
            [fine,ev,g]=C1PlainFineQualificationReplay_v3(seed,steps(level),service,limit);audit.fine_calls_returned=audit.fine_calls_returned+1;fprintf('C1_PK_ANCHOR_FINE_AFTER_PROFILE_RETURN %d\n',level);
            timely=posixtime(datetime('now','TimeZone','UTC'))<limit.deadline_unix_seconds&&double(java.lang.System.nanoTime)<limit.deadline_monotonic_ns;
            item=fineObservation(fine,ev,g,seed,O{3},1,level,integration,steps(level),timely,serviceAudit.BL_policy_configuration);
            item.side_name='owned_P1_column152_anchor_fork';item.seed_native_id=headers{3}.native_id;item.evidence=ev;item.evidence_retention='Full unchanged plain fb35 trajectory, energies, stance residuals, counts, phase and timings retained in this native audit.';
            item.actual_service_contract_digest=audit.fresh_service_contract_digest;plain(item);audit.fines{end+1,1}=item;clear fine ev g item
            guard(work);
        end
        audit.all_two_owned_fines_passed=numel(audit.fines)==2&&all(cellfun(@(x)x.all_declared_conditions_met,audit.fines));
        audit.finite_NEW152_comparison_with_independent_fines=audit.comparison.conditions_met&&audit.all_two_owned_fines_passed;
        audit.historical_contract_observations=cell(2,1);
        for historicalLevel=1:2
            audit.historical_contract_observations{historicalLevel}=struct('profile',historicalLevel,'assessment','UNASSESSED_NOT_ATTEMPTED', ...
                'inspection_attempted',false,'raw_variable_availability_assessed',false,'raw_variable_available',false,'raw_payload_loaded',false,'failure',struct());
        end
        audit.historical_raw_contract_scope='Historical NEW152 numeric/service/raw-variable inspection was NOT attempted. Both current historical raw files remain hash-only in this worker; unavailable flags are UNASSESSED, not proof of absent saved evidence. No common-four contract is claimed.';
        audit.status='two_original_owned_profiles_observed';if audit.finite_NEW152_comparison_with_independent_fines,audit.status='finite_NEW152_record_match_and_independent_fines';end
        clear O R M s a ix seed integration service target witness policyReport headers first q sp projected sourceHeaders
        guard(work);audit.source_posthash=true;audit.completed=true;publishAudit();small=stdoutView(audit);encoded=jsonencode(small);assert(numel(unicode2native(encoded,'UTF-8'))<=50000,'C1PKAnchorFine:Stdout','Bound normal projection to50000 UTF8 bytes.');
        fprintf('C1_PK_CONTROL_ANCHOR_FORK_FINE_ACTUAL_RETURN %s\n',encoded);normalReturned=true;guard(finish);
    catch problem
        audit.completed=false;audit.failure=exceptionData(problem);audit.status='partial_or_refused';
        try,if ~audit.publication_returned,publishAudit();end;catch persistenceProblem,audit.audit_persistence_failure=struct('identifier',persistenceProblem.identifier,'message',persistenceProblem.message);end
        p=struct('schema','C1-owned-PK-P1-control-anchor-fork-fine-partial-v1','completed',false,'normal_summary_returned',normalReturned,'fine_calls_attempted',audit.fine_calls_attempted,'fine_calls_returned',audit.fine_calls_returned, ...
            'stage_save_returned',audit.stage_save_returned,'stage_read2_verified',audit.stage_read2_verified,'publication_returned',audit.publication_returned,'installed_read2_verified',audit.installed_read2_verified, ...
            'failure_header',failureHeader(problem),'full_facts_omitted',true,'own_process_exit_observed',false);encoded=jsonencode(p);assert(numel(unicode2native(encoded,'UTF-8'))<=7000,'C1PKAnchorFine:Partial','Bound partial projection.');fprintf('C1_PK_CONTROL_ANCHOR_FORK_FINE_PARTIAL %s\n',encoded);rethrow(problem)
    end
    function out=nativeTwice(file,key,label,limit)
        check(limit);fprintf('C1_PK_ANCHOR_FINE_BEFORE_NATIVE_LOAD1 %s\n',label);x=load(file,'-mat',key);fprintf('C1_PK_ANCHOR_FINE_AFTER_NATIVE_LOAD1_RETURN %s\n',label);check(limit);
        fprintf('C1_PK_ANCHOR_FINE_BEFORE_NATIVE_LOAD2 %s\n',label);y=load(file,'-mat',key);fprintf('C1_PK_ANCHOR_FINE_AFTER_NATIVE_LOAD2_RETURN %s\n',label);check(limit);assertPublicEqual(x.(key),y.(key),0);out=x.(key);
    end
    function emitTargetHeader(h)
        audit.target_intake_headers{end+1,1}=h;v=jsonencode(h);assert(numel(unicode2native(v,'UTF-8'))<=1000,'C1PKAnchorFine:IntakeHeader','Bound each direct intake header.');fprintf('C1_PK_ANCHOR_FINE_TARGET_HEADER %s\n',v);
    end
    function guard(limit)
        check(limit);quiet(ledger,raw,roundFile);for p={o.ForkReference.file,o.CheckpointReference.file},assert(~isfile([p{1},'.pending.mat']),'C1PKAnchorFine:Pending','Resolve fork/checkpoint stages first.');end
        verify(refs);verifyCode(code);assert(isequaln(C1RunBudget_v3(),budget),'C1PKAnchorFine:Budget','Keep unchanged original grant.');check(limit);
    end
    function publishAudit()
        check(finish);fresh({o.OutputAuditFile,stage});audit.headroom_observation=struct();v=whos('audit');audit.headroom_observation=struct('native_logical_bytes_before_stage',v.bytes,'refusal_threshold',1750000000,'format_capacity_guaranteed',false);
        assert(v.bytes<1750000000,'C1PKAnchorFine:Headroom','Refuse before native-v7 stage at conservative observed logical-byte threshold.');
        savedAudit=audit;save(stage,'audit','-v7');audit.stage_save_returned=true;fprintf('C1_PK_ANCHOR_FINE_AFTER_AUDIT_STAGE_SAVE_RETURN\n');
        x=load(stage,'audit');y=load(stage,'audit');assertPublicEqual(x.audit,savedAudit,0);assertPublicEqual(y.audit,savedAudit,0);audit.stage_read2_verified=true;check(finish);
        fresh({o.OutputAuditFile});[ok,message]=movefile(stage,o.OutputAuditFile);assert(ok,'C1PKAnchorFine:Publish','%s',message);audit.publication_returned=true;fprintf('C1_PK_ANCHOR_FINE_AFTER_AUDIT_PUBLICATION_RETURN\n');
        x=load(o.OutputAuditFile,'audit');y=load(o.OutputAuditFile,'audit');assertPublicEqual(x.audit,savedAudit,0);assertPublicEqual(y.audit,savedAudit,0);audit.installed_read2_verified=true;
        audit.audit_reference=reference(o.OutputAuditFile);audit.publication_scope='Stored MAT records prepublication flags false; actual returned flags/immutable external closure qualify publication separately.';check(finish);
    end
end

function validateForkMarker(q,sp,o,raw,rawSHA)
    assert(strcmp(q.schema,'C1-owned-PK-P1-control-anchor-single-fork-v1')&&q.completed&&q.source_posthash ...
        &&strcmp(q.source_reference.sha256,'e1718175d75cecb130fefaec4023367dfa01095cd207c24ec11c4a34cad5da73') ...
        &&q.target_original_column==152&&q.primary_anchor_index==340&&isequal(q.source_pair(:).',[338 339]) ...
        &&q.Run_calls_attempted==1&&q.Run_calls_returned==1&&q.Run_return_observed_before_outer_work&&q.Run_actual_limits_within_original_work ...
        &&q.owned_fork_commit_verified&&q.fork_native_read2_verified&&q.cloned_seed_native_ids_preserved&&q.cheap_target_comparison.conditions_met ...
        &&q.source_pair_read2_verified&&q.source_index_read2_verified&&q.target_native_read2_verified&&q.comparison_closed_verified ...
        &&~q.native_pending_present&&isequal(q.own_process_exit_observed,false),'C1PKAnchorFine:ActualFork','Require actual clean0073 owned152 fork and cheap match, not prepared intent.');
    assert(strcmp(canonical(q.output_file),o.ForkReference.file)&&strcmp(canonical(q.checkpoint_file),o.CheckpointReference.file) ...
        &&isequaln(q.fork_output_reference,o.ForkReference)&&q.Run_observation.persistence_completion_confirmed ...
        &&strcmp(q.component_identity,'PK36h20261031_P1Column152_OwnedAnchorFork01'),'C1PKAnchorFine:ForkRefs','Actual returned proof binds fork bytes and genuine return flag.');
    files=asCells(q.file_observations);hit=find(cellfun(@(x)strcmp(canonical(x.file),o.CheckpointReference.file),files));
    assert(isscalar(hit)&&isequal(files{hit}.hash_observed,true)&&strcmp(files{hit}.sha256,o.CheckpointReference.sha256),'C1PKAnchorFine:CheckpointRef','Join actual post-return checkpoint observation to its exact bytes.');
    assert(isequaln(sp.source_reference,q.source_reference)&&strcmp(canonical(sp.source_reference.file),canonical(fullfile('/private/tmp/c1_pk36h_20261031_candidates', ...
        'PK36h_0072_P1179OwnedAnchor','ExecuteC1PKOwnedP1ControlAnchorFork20261031.m'))),'C1PKAnchorFine:Source','Actual Processspec binds exact proper e171 execution source.');
    rr=asCells(sp.operative_guard_references);hit=find(cellfun(@(x)strcmp(canonical(x.file),raw),rr));
    assert(isscalar(hit)&&strcmp(rr{hit}.sha256,rawSHA),'C1PKAnchorFine:PrimaryUnchanged','Current raw equals the unique actual0073 Processspec guard; old global j/Round refs remain historical.');
    ro=q.Run_options;assert(ro.MaxAttempts==1&&ro.MaxAccepted==1&&strcmp(ro.CorrectorInitializer,'base')&&~ro.InPlace&&strcmp(ro.ComponentIdentity,q.component_identity) ...
        &&strcmp(ro.Algorithm,'root-newton')&&strcmp(ro.DerivativeMethod,'valid-sided')&&ro.FiniteDifferenceSteps==1e-8&&~ro.ReusePreviousJacobian ...
        &&ro.InitialDerivativeIndex==1&&ro.TrialSeconds==240&&ro.SaveMarginSeconds==120&&ro.MinimumApexHeightRatio==.5, ...
        'C1PKAnchorFine:Options','Preserve actual standalone1/1 original policy.');
end

function h=projectRunHeader(s)
    h=runHeader(s);h=pickPresent(h,{'protocol','new_points','new_edges','initial_output_count','final_output_count','status','persistence_completion_confirmed', ...
        'derivative_method','corrector_initializer','run_limit','work_limit','current_pair','next_step','next_derivative_index','apex_height_policy', ...
        'failure_header','pending_admission_present','pending_stage','attempts'});
end

function h=projectRecordHeader(r)
    h=r;h.saved_full_closure_digest=C1ScientificDigest_v3(r.saved_full_closure);h=rmfield(h,{'saved_full_closure','metadata_binding'});
    c=r.section_chart;h.section_chart=pick(c,{'id','geometry','crossing_orientation','boundary_ownership','translational_gauge'});
    if isfield(c,'BL_touchdowns_per_return'),h.section_chart.BL_touchdowns_per_return=c.BL_touchdowns_per_return;end
    h.section_chart.omitted_full_chart_digest=C1ScientificDigest_v3(c);
end

function [w,q,sp]=forkClosure(r,root,limit)
    check(limit);w=jsondecode(fileread(r.file));exactFields(w,{'schema','invocation_id','argv_utf8_sha256','exec_session_id','child_pid','actual_child_exit_code','actual_process_exit_observed','tool_prefix_reference','process_prefix_reference'});
    assert(strcmp(w.schema,'C1-ordinary-initializer-evidence-closure-v1')&&strcmp(w.invocation_id,'PK36h20261031-0073-owned-control152-local-PAL-anchor-fork')&&w.exec_session_id==3029&&w.child_pid==19114 ...
        &&isequal(w.actual_child_exit_code,0)&&isequal(w.actual_process_exit_observed,true)&&strcmp(w.argv_utf8_sha256,'1410ce13ae76f3d3e33f784e14f11944f68f1eac73b2661061bf6389dcc36b4d'),'C1PKFork:Closure','Keep exact actual0073 session/pid/argv/exit authority.');
    exactFields(w.tool_prefix_reference,{'file','prefix_bytes','prefix_sha256'});exactFields(w.process_prefix_reference,{'file','prefix_bytes','prefix_sha256'});
    assert(strcmp(w.tool_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Tool_Observations.jsonl'))&&strcmp(w.process_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Process_Observations.jsonl')),'C1PKFork:PrefixPaths','Use known bounded immutable observation prefixes.');
    assert(w.tool_prefix_reference.prefix_bytes==1735862&&strcmp(w.tool_prefix_reference.prefix_sha256,'879c48bd0974339ffdf7d8a294515291e204717c184563f0e63ba62280a0106e') ...
        &&w.process_prefix_reference.prefix_bytes==3173432&&strcmp(w.process_prefix_reference.prefix_sha256,'116de778269bf1045dabd6bd34135754ee452b3771f60199895646a57891dac8'),'C1PKFork:Prefixes','Bind exact actual0073 immutable prefixes.');
    tool=prefixRows(w.tool_prefix_reference);process=prefixRows(w.process_prefix_reference);rows=tool(cellfun(@(x)isfield(x,'invocation_id')&&strcmp(x.invocation_id,w.invocation_id),tool));assert(numel(rows)==2,'C1PKFork:ToolRows','Require the actual two ordered records.');
    terminal=0;starts={};exits={};summaries={};pre={};startPosition=[];prePosition=[];summaryOrdinal=[];summaryLine=[];exitOrdinal=[];exitLine=[];
    for k=1:2
        a=rows{k};assert(strcmp(a.schema,'C1-native-exec-tool-observation-v1')&&a.tool_record_ordinal==k,'C1PKFork:ToolOrder','Actual ordinals must be1..2.');
        if k<2,assert(isfield(a,'session_id')&&a.session_id==w.exec_session_id,'C1PKFork:ToolSession','Running envelope sessions must match.');else,assert(~isfield(a,'session_id'),'C1PKFork:TerminalAbsence','Actual terminal2 alone lacks envelope session.');end
        if isfield(a.record,'session_id'),assert(a.record.session_id==w.exec_session_id,'C1PKFork:RecordSession','Every present record session must match.');end
        if isfield(a.record,'exit_code'),assert(k==2&&a.record.exit_code==0,'C1PKFork:Terminal','Require sole actual terminal0.');terminal=terminal+1;end
        if isfield(a.record,'output')
            lines=strsplit(a.record.output,newline);
            for n=1:numel(lines)
                line=lines{n};
                if startsWith(line,'C1_NATIVE_PROCESS_STARTED '),starts{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_STARTED ')+1:end));startPosition=[k n];end
                if startsWith(line,'C1_NATIVE_PROCESS_EXIT '),exits{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_EXIT ')+1:end));exitOrdinal(end+1)=k;exitLine(end+1)=n;end
                if startsWith(line,'C1_PK_CONTROL_ANCHOR_PRE_RUN '),pre{end+1}=jsondecode(line(numel('C1_PK_CONTROL_ANCHOR_PRE_RUN ')+1:end));prePosition=[k n];end
                if startsWith(line,'C1_PK_OWNED_ANCHOR_FORK_ACTUAL_RETURN '),summaries{end+1}=jsondecode(line(numel('C1_PK_OWNED_ANCHOR_FORK_ACTUAL_RETURN ')+1:end));summaryOrdinal(end+1)=k;summaryLine(end+1)=n;end
            end
        end
    end
    selected=process(cellfun(@(x)isfield(x,'invocation_id')&&strcmp(x.invocation_id,w.invocation_id),process));spec={};observed={};dispatch={};
    for k=1:numel(selected),a=selected{k};if strcmp(a.schema,'C1-native-launch-specification-v1'),spec{end+1}=a;elseif strcmp(a.schema,'C1-native-process-observation-v1'),observed{end+1}=a;elseif strcmp(a.schema,'C1-native-reviewed-specification-dispatch-confirmation-v1'),dispatch{end+1}=a;end,end
    assert(terminal==1&&numel(starts)==1&&numel(exits)==1&&numel(summaries)==1&&isequal(startPosition,[1 1])&&numel(pre)==1&&isequal(prePosition,[2 24])&&isequal(summaryOrdinal,2)&&isequal(summaryLine,32)&&isequal(exitOrdinal,2)&&isequal(exitLine,35)&&summaryLine<exitLine&&numel(spec)==1&&numel(observed)==1&&numel(dispatch)==1,'C1PKFork:UniqueClosure','Require unique START/EXIT/summary/spec/dispatch/process joins.');
    a=starts{1};b=observed{1};sp=spec{1};di=dispatch{1};assert(strcmp(a.invocation_id,w.invocation_id)&&a.child_pid==w.child_pid&&strcmp(a.argv_utf8_sha256,w.argv_utf8_sha256) ...
        &&strcmp(b.invocation_id,w.invocation_id)&&b.child_pid==w.child_pid&&isequal(b.actual_child_exit_code,0)&&isequal(b.actual_process_exit_observed,true)&&strcmp(b.argv_utf8_sha256,w.argv_utf8_sha256) ...
        &&strcmp(sp.argv_utf8_sha256,w.argv_utf8_sha256)&&strcmp(di.argv_utf8_sha256,w.argv_utf8_sha256),'C1PKFork:ProcessJoin','Join actual child and reviewed dispatch to the same argv.');
    assert(isequaln(exits{1},b)&&strcmp(sp.expected_execution_tool_options.sandbox_permissions,'require_escalated')&&isequaln(rows{1}.actual_execution_tool_options,sp.expected_execution_tool_options) ...
        &&isequaln(di.expected_execution_tool_options,sp.expected_execution_tool_options)&&isequaln(b.expected_execution_tool_options,sp.expected_execution_tool_options),'C1PKFork:Profile','Preserve actual execution profile and EXIT observation.');
    q=summaries{1};assert(isequaln(pre{1},q.pre_Run_header),'C1PKFork:PreRun','Actual pre-Root pair/eligibility projection must be preserved in final marker.');check(limit);
end

function checkCapture(c)
    assert(c.radius==.02&&c.full13_scaled_inf<c.radius&&c.achieved_state_progress>1e-8&&c.distinct_state_distance>1e-8&&abs(c.PAL_error)<=1e-8&&c.section_compatible,'C1PKCol1Fine:Capture','Actual unrelaxed capture/progress/separation must pass.');
end
function [service,integration,c]=forkFineService(report,work)
    [integration,reconstruction]=freshIntegration(report.replay_integration,struct('u',work.utc,'m',work.mono));[~,pe]=RecordedReturnPolicy_v3(report);
    assert(pe.complete&&strcmp(pe.configuration.source_class,'BLMarkedApexReturnPolicy_v3'),'C1PKCol1Fine:Policy','Use actual complete fork BL policy.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(pe.configuration.settings,'Name'));[~,freshPolicy]=RecordedReturnPolicy_v3(struct('correction_return_policy',policy));
    assert(freshPolicy.complete&&isequaln(freshPolicy.configuration,pe.configuration),'C1PKCol1Fine:PolicyRoundtrip','Fresh policy must preserve every actual setting.');
    service=struct('replay_integration',integration,'correction_return_policy',policy,'options',pickPresent(report.options,{'MaxReturnTime','MaxCycleEvents','MaxSectionCrossings'}), ...
        'acceptance',report.acceptance,'classification',report.classification,'event_signature',report.event_signature);
    c=struct('schema','C1-P1-owned-fork-fine-service-contract-v1','numeric_integration',reconstruction.all_other_integration_settings,'numeric_ODE_options',reconstruction.all_other_ODE_options, ...
        'solver','ode45','BL_policy_configuration',freshPolicy.configuration,'map_limits',service.options,'acceptance',service.acceptance, ...
        'classification_contract',pickPresent(service.classification,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count','flight_count_certain'}), ...
        'event_signature',service.event_signature,'profile_steps',[.0005 .00025],'original_profile_cap_seconds',300,'runtime_reconstruction',reconstruction, ...
        'historical_service_equality_claimed',false,'saved_closure_executed',false);
    assert(isequal(sort(fieldnames(service.options)),sort({'MaxReturnTime';'MaxCycleEvents';'MaxSectionCrossings'})),'C1PKCol1Fine:Limits','Use only actual numeric map limits.');plain(c);
end
function small=stdoutView(a)
    small=pickPresent(a,{'schema','source_reference','target_original_column','fork_reference','checkpoint_reference','actual_fork_closed_verified','fork_native_read2_verified','owned_edge_verified','stored_checkpoint_persistence_completion_confirmed', ...
        'actual_return_persistence_completion_confirmed','comparison','fresh_service_contract_digest','historical_common_contract_equality','historical_common_contract_claimed','all_four_target_cohorts_established','all_four_target_cohorts_scope', ...
        'fine_calls_attempted','fine_calls_returned','all_two_owned_fines_passed','finite_NEW152_comparison_with_independent_fines','root_calls','admissions','physical_edges_added','source_posthash','stage_save_returned','stage_read2_verified', ...
        'publication_returned','installed_read2_verified','audit_reference','completed','failure','status','own_process_exit_observed','scope'});
    small.fines=cell(size(a.fines));for k=1:numel(a.fines),x=a.fines{k};y=pickPresent(x,{'side_name','original_profile_level','timely_observed','initial_trajectory_row_exact','qualified_PK1_primitive','saved_period_scaled_error','saved_full14_stride_scaled_error', ...
        'map_complete','classifier_complete','sample_count','completed_scalar_sample_count','all_declared_conditions_met','seed_native_id','actual_service_contract_digest'});y.fine=pickPresent(x.fine,{'MaxStep','passed','status','budget_refusal','failure','full13_norm','period','maximum_energy_variation','maximum_stance_constraint'});small.fines{k}=y;end
    small.historical_contract_observations=cell(size(a.historical_contract_observations));
    for k=1:numel(a.historical_contract_observations)
        x=a.historical_contract_observations{k};y=pickPresent(x,{'profile','assessment','inspection_attempted','raw_variable_availability_assessed','raw_variable_available','raw_payload_loaded','numeric_service_keys_equal'});
        if isfield(x,'method_comparison'),y.method_comparison_counts=pickPresent(x.method_comparison,{'current_method_count','matched_count','changed_count','missing_or_ambiguous_count'});end
        y.failure_header=struct();if ~isempty(fieldnames(x.failure))
            id=x.failure.identifier;message=x.failure.message;y.failure_header=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id), ...
                'identifier_truncated',numel(id)>128,'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256);
        end
        small.historical_contract_observations{k}=y;
    end
    small.historical_qualification_scope=pickPresent(a.historical_qualification,{'saved179_parent_completed','saved179_parent_source_posthash','saved179_qualified_saved_control','saved179_finite_original_conditions','remaining_parent_completed','remaining_parent_source_posthash','remaining_parent_failure_identifier'});
    small.evidence_scope='Complete plain fine/evidence/classification/settings retained in native audit; stdout intentionally omits dense evidence. Two new owned profiles are separate from the historical target2; no common-contract claim.';
end
function code=codeRefs(self,protected)
    protected=references(protected);names={'C1RunBudget_v3','BranchSolutionFile_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3','OrbitContentIdentity_v3','HybridOrbit_v3','Trajectory_v3','C1ScientificDigest_v3','RoundSHA256_v3', ...
        'QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3','QuadrupedAdmissibility_v3','ContinuousDynamics_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3','PoincareMap_v3','PoincareSection_v3','HybridSimulator_v3', ...
        'Quadrupedal_Dynamics_v3','PeriodicOrbitResidual_v3','GuardFunctions_v3','EventDetector_v3','ResetMap_v3','ModeTransition_v3','PrimitiveCycleCheck_v3','HybridCycleData_v3','GaitIdentification_v3','GaitSemanticTable_v3','CircularPhase_v3','SectionModeResolver_v3','HybridSystemBase_v3','C1PlainFineQualificationReplay_v3'};
    code={self};for k=1:numel(names),r=reference(which(names{k}));assert(any(cellfun(@(x)strcmp(x.file,r.file)&&strcmp(x.sha256,r.sha256),protected)),'C1PKCol1Fine:CallerPin','Every actual method must be caller-pinned.');code{end+1,1}=r;end
    r=reference(which('C1PlainFineQualificationReplay_v3'));assert(strcmp(r.sha256,'fb35df74f7de49f65f72040e3577080d8a55e96de039646528bdf3991a2c41df'),'C1PKCol1Fine:FinePin','Keep the original fullrow fine adapter.');
    d=reference(which('C1ScientificDigest_v3'));assert(strcmp(d.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'),'C1PKCol1Fine:DigestPin','Keep the reviewed typed digest.');
end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1Fine:Fresh','Preserve an existing/uncertain output or stage.');end,end
function [witness,policyReport,signature]=storedSection(target,p,l)
    assert(strcmp(p.native_id,target.native_id)&&isequaln(p.initial_state,target.state)&&isfield(p,'section_chart')&&isfield(p,'section_event_signature'), ...
        'C1PKCol1:TargetSection','Use only the exact already-read2 admitted NEW P1 control chart/token.');
    configuration=target.policy_configuration;assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isstruct(configuration.settings)&&isscalar(configuration.settings)&&isfield(configuration.settings,'Name'), ...
        'C1PKCol1:Policy','Use actual complete historical BL1 policy settings.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));[~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration)&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKCol1:PolicyRoundtrip','Fresh constructor must roundtrip exact recorded BL1 policy.');
    witness=struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',target.mode,'section_chart',p.section_chart,'return_multiplicity',1);
    policyReport=struct('seed',struct('return_policy',policy));signature=p.section_event_signature;assert(strlength(string(signature))>0,'C1PKCol1:EventToken','The saved single target event token must be nonempty.');check(l);
end

function targetShapes(t,w)
    assert(isa(t.state,'double')&&isreal(t.state)&&isequal(size(t.state),[14 1])&&all(isfinite(t.state)) ...
        &&islogical(t.mode)&&isequal(size(t.mode),[4 1])&&isa(t.parameter,'double')&&isreal(t.parameter)&&isequal(size(t.parameter),[10 1])&&all(isfinite(t.parameter)) ...
        &&isa(t.full_stride,'double')&&isreal(t.full_stride)&&isequal(size(t.full_stride),[14 1])&&all(isfinite(t.full_stride)) ...
        &&isa(t.period,'double')&&isreal(t.period)&&isscalar(t.period)&&isfinite(t.period)&&t.period>0 ...
        &&isa(t.native_energy,'double')&&isreal(t.native_energy)&&isscalar(t.native_energy)&&isfinite(t.native_energy), ...
        'C1PKCol1:TargetShapes','Require exact finite native state14/mode4/p10/stride14 and scalar period/energy.');
    assert(ischar(t.native_id)&&isrow(t.native_id)&&~isempty(regexp(t.native_id,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1PKCol1:NativeID','Require the source-defined native record identity.');assert(isstruct(w.section_chart)&&isscalar(w.section_chart),'C1PKCol1:TargetChart','Retain actual marked chart.');
end

function h=pointHeader(o,r,m,ix,index)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&ix.index==index&&isstruct(m)&&isscalar(m)&&strcmp(ix.component_identity,m.component_identity), ...
        'C1PKCol1:PointBinding','Retain current native record index, owner and public metadata binding.');
    assert(isa(o.stride_displacement,'double')&&isequal(size(o.stride_displacement),[14 1])&&all(isfinite(o.stride_displacement)), ...
        'C1PKCol1:Stride','A complete finite native14 stride is required.');
    g=r.classification;[~,pe]=RecordedReturnPolicy_v3(r);
    h=struct('index',index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o), ...
        'state',o.initial_state,'mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full_stride',o.stride_displacement, ...
        'native_energy',QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter), ...
        'acceptance_gates',pick(r.acceptance_gates,{'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'}), ...
        'classification',pick(g,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'}), ...
        'policy_configuration',pe.configuration,'section_chart',o.section_chart, ...
        'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature, ...
        'event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'saved_full_closure',r.full_closure,'metadata_binding',struct('component_identity',m.component_identity,'index',ix.index,'order',ix.order));
end

function h=runHeader(s)
    h=pickPresent(s,{'protocol','output_file','configuration','new_points','new_edges','initial_output_count','final_output_count','status','persistence_completion_confirmed','derivative_method', ...
        'integration_profile','corrector_initializer','run_limit','work_limit','current_pair','next_step','next_derivative_index','apex_height_policy','completed_utc'});
    h.failure_header=storedFailureHeader(s.failure);h.pending_admission_present=~isempty(fieldnames(s.pending_admission));h.pending_stage=member(s.pending_admission,'stage','');h.isolated_native_admissions=s.isolated_native_admissions;
    h.attempts=cell(size(s.attempts));for k=1:numel(s.attempts),h.attempts{k}=pickPresent(s.attempts{k},{'attempt','source_point','step','derivative_method','relative_step','algorithm','status','all_nine','timely','capture', ...
            'edge_committed','storage_attempted','storage_timely','isolated_committed','isolated_storage_timely','corrector_initialization','apex_height_policy'});end
    h.checkpoint_fact_scope='Actual returned persistence flag remains literal; saved checkpoint intentionally retains provisional false. Full failure/native-pending payload remains in Run checkpoint, not duplicated here.';
end

function h=storedFailureHeader(e)
    h=struct();if isempty(fieldnames(e)),return;end
    id=member(e,'identifier','');msg=member(e,'message','');h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'message_prefix',msg(1:min(numel(msg),256)),'message_char_count',numel(msg), ...
        'stack_frame_count',numel(member(e,'stack',[])),'full_failure_preserved_in_Run_checkpoint',true);
end

function out=pickPresent(s,keys),out=struct();for k=1:numel(keys),if isfield(s,keys{k}),out.(keys{k})=s.(keys{k});end,end,end

function out=compareTarget(O,r,t,witness,policyReport,signature)
    section=MatchingReturnSection_v3(O,witness,{r,policyReport});[~,pe]=RecordedReturnPolicy_v3(r);
    delta=O.initial_state(2:14)-t.state(2:14);scale=max([ones(13,1),abs(O.initial_state(2:14)),abs(t.state(2:14))],[],2);
    dt=O.period-t.period;dq=O.stride_displacement-t.full_stride;qs=max([ones(size(dq)),abs(O.stride_displacement),abs(t.full_stride)],[],2);
    dE=QuadrupedEnergy_v3.evaluate(O.initial_state,O.initial_mode,O.parameter)-t.native_energy;
    out=struct('raw_full13_delta',delta,'raw_full13_scaled_inf',norm(delta./scale,inf),'native_energy_delta',dE,'absolute_energy_tolerance',1e-8, ...
        'period_delta',dt,'period_tolerance',1e-10*max([1,abs(O.period),abs(t.period)]),'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
        'exact_p_q',isequaln(O.parameter,t.parameter)&&isequaln(O.initial_mode,t.mode),'exact_complete_policy',pe.complete&&isequaln(pe.configuration,t.policy_configuration), ...
        'matching_section',section,'same_section_event_signature',strcmp(string(O.section_relative_event_signature),string(signature)), ...
        'conditions_met',false,'scope','Finite comparison to the independently qualified NEW P1 control control only: rawfull13/E1e-8, period/fullstride componentwise1e-10/maxscale, exactp/q/completepolicy/markedsection/events. No OriginalP1 stride/meanU, source membership, alias, union or endpoint theorem is inferred.');
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dE)<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
        &&out.exact_p_q&&out.exact_complete_policy&&section.compatible&&out.same_section_event_signature;
end

function strictPK(o,r,p)
keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};for k=1:numel(keys),assert(isequal(r.acceptance_gates.(keys{k}),true),'C1Pilot:AllNine','Require every literal original native admission gate.');end;g=r.classification;status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true)&&strcmp(g.contract_version,'quadruped-gait-v3.5')&&strcmp(g.validated_gait_type,'PK')&&isequal(g.flight_count_certain,true)&&g.flight_count==1&&isequal(g.canonical_label_qualified,true)&&isequaln(o.parameter(:),p(:)),'C1Pilot:PK','Require current qualified certain PK1 and unchanged parameters.');[policy,e]=RecordedReturnPolicy_v3(r);assert(e.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1Pilot:Policy','Require the actual complete BL1 section.');
end

function refs=references(refs)
    assert(iscell(refs)&&size(refs,2)==1,'C1PKCol1:ReferenceCells','Supply a column cell of explicit current protected references.');
    for k=1:numel(refs),refs{k}=checked(refs{k});end
end

function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end

function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1P1Fixed:Resolver','Current source resolution differs from its guard.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1P1Fixed:Changed','A bound file changed.');end,end

function r=reference(f),assert(isfile(f),'C1P1Fixed:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function out=exceptionData(e),causes=cell(size(e.cause));for k=1:numel(causes),causes{k}=exceptionData(e.cause{k});end;out=struct('identifier',e.identifier,'message',e.message,'stack',e.stack,'causes',{causes});end

function value=member(s,k,f),value=f;if isstruct(s)&&isscalar(s)&&isfield(s,k),value=s.(k);end,end

function x=clockPair(),x=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function x=shift(x,s),x.utc=x.utc+s;x.mono=x.mono+s*1e9;end

function check(l),assert(left(l)>0,'C1P1Fixed:Clock','The original local/science whole-call clock expired.');end

function x=canonical(x),x=char(java.io.File(char(x)).getCanonicalPath());end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

function quiet(ledger,raw,roundFile)
    cp=[ledger(1:end-4),'_active_checkpoint.mat'];paths={cp,[cp,'.pending.mat'],[ledger,'.pending.mat'],[roundFile,'.pending.mat'],[roundFile(1:end-4),'.pending.mat'],[roundFile(1:end-4),'.json.pending.json']};
    for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1:Pending','Reconcile existing owned checkpoint/stage before this stored-only observation.');end
    d=dir(fileparts(raw));d=d(~ismember({d.name},{'.','..'}));[~,n,e]=fileparts(raw);
    assert(numel(d)==1&&~d.isdir&&strcmp(d.name,[n e]),'C1PKCol1:RawDirectory','The primary raw directory must retain exactly its one current file, with no unknown stage.');
end

function h=failureHeader(e)
    id=e.identifier;message=e.message;stack=e.stack;
    h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'identifier_truncated',numel(id)>128, ...
        'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256, ...
        'stack_frame_count',numel(stack),'first_stack_frame',struct(),'stack_detail_omitted',numel(stack)>1,'cause_count',numel(e.cause));
    if ~isempty(stack)
        a=stack(1);h.first_stack_frame=struct('file_prefix',a.file(1:min(numel(a.file),128)),'file_char_count',numel(a.file),'file_truncated',numel(a.file)>128, ...
            'name_prefix',a.name(1:min(numel(a.name),96)),'name_char_count',numel(a.name),'name_truncated',numel(a.name)>96,'line',a.line);
    end
end

function rows=prefixRows(r)
    validSHA(r.prefix_sha256);assert(ischar(r.file)&&isrow(r.file)&&isa(r.prefix_bytes,'double')&&isscalar(r.prefix_bytes)&&isfinite(r.prefix_bytes)&&r.prefix_bytes>0&&r.prefix_bytes<=16*1024*1024&&r.prefix_bytes==fix(r.prefix_bytes),'C1PKFork:Prefix','Require an exact bounded prefix.');
    f=fopen(r.file,'rb');assert(f>=0,'C1PKFork:PrefixOpen','Cannot read prefix.');closer=onCleanup(@()fclose(f));b=fread(f,r.prefix_bytes,'*uint8');assert(numel(b)==r.prefix_bytes&&b(end)==10,'C1PKFork:PrefixLength','Exact prefix must end atLF.');clear closer
    d=java.security.MessageDigest.getInstance('SHA-256');d.update(b);h=lower(reshape(dec2hex(typecast(d.digest(),'uint8'),2).',1,[]));assert(strcmp(h,r.prefix_sha256),'C1PKFork:PrefixSHA','Immutable prefix changed.');
    lines=strsplit(native2unicode(b.','UTF-8'),newline);lines(end)=[];rows=cellfun(@jsondecode,lines,'UniformOutput',false);
end

function c=asCells(x),if iscell(x),c=x(:);elseif isstruct(x),c=num2cell(x(:));else,error('C1PKFork:Cells','Require actual JSON object-array rows.');end,end

function x=left(l),if isfield(l,'utc'),u=l.utc;m=l.mono;else,u=l.u;m=l.m;end;x=min(u-posixtime(datetime('now','TimeZone','UTC')),(m-double(java.lang.System.nanoTime))/1e9);end

function out=fineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration)
    returnedPolicy=isfield(fine,'actual_policy');if returnedPolicy,[~,used]=RecordedReturnPolicy_v3(struct('correction_return_policy',fine.actual_policy));assert(used.complete&&isequaln(used.configuration,configuration),'C1PKE0:FinePolicy','Fresh fine changed the actual return policy.');fine.actual_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',configuration.source_class,'settings',configuration.settings);end
    firstExact=ev.sample_count>0&&isequaln(ev.trajectory.state(1,:).',seed.state)&&isequaln(logical(ev.trajectory.mode(1,:).'),logical(seed.mode));periodError=NaN;strideError=NaN;if isfield(fine,'period'),periodError=abs(fine.period-original.period)/max([1,abs(fine.period),abs(original.period)]);end;if isfield(fine,'stride_displacement'),sx=max([ones(14,1),abs(fine.stride_displacement(:)),abs(original.stride_displacement(:))],[],2);strideError=norm((fine.stride_displacement(:)-original.stride_displacement(:))./sx,Inf);end
    names={'candidate','original_unit'};out=struct('side',side,'side_name',names{side},'original_profile_level',level,'fine',fine,'actual_full_classification',g,'timely_observed',timely,'initial_trajectory_row_exact',firstExact,'qualified_PK1_primitive',qualified(g),'saved_period_scaled_error',periodError,'saved_full14_stride_scaled_error',strideError,'map_complete',ev.map_complete,'classifier_complete',ev.classifier_complete,'sample_count',ev.sample_count,'completed_scalar_sample_count',ev.completed_scalar_sample_count,'failure_phase',ev.phase_at_failure,'timings',ev.timings,'effective_ODE_profile',effectiveProfile(integration,step),'all_declared_conditions_met',fine.passed&&timely&&qualified(g)&&firstExact&&returnedPolicy&&ev.map_complete&&ev.classifier_complete&&ev.completed_scalar_sample_count==ev.sample_count&&periodError<=1e-8&&strideError<=1e-8);
end

function [live,audit]=freshIntegration(saved,limit)
    native=HybridSimulator_v3();defaults=native.Options;assert(isstruct(saved)&&isscalar(saved)&&isequal(sort(fieldnames(saved)),sort(fieldnames(defaults))),'C1PKFine:IntegrationSchema','Native verification refused; original observations are retained.');
    assert(isempty(saved.StopCondition)&&isstruct(saved.ODEOptions)&&isscalar(saved.ODEOptions),'C1PKFine:Callback','Native verification refused; original observations are retained.');
    odeDefaults=odeset();assert(isequal(sort(fieldnames(saved.ODEOptions)),sort(fieldnames(odeDefaults)))&&isempty(saved.ODEOptions.Events),'C1PKFine:ODEFields','Native verification refused; original observations are retained.');
    solverHeader=knownCallback(saved.ODESolver,'ode45');outputHeader=knownCallback(saved.ODEOptions.OutputFcn,'@(~,~,~)double(left(limit)<=0)');
    numeric=saved;numeric=rmfield(numeric,{'ODESolver','ODEOptions'});plain(numeric);odeNumeric=rmfield(saved.ODEOptions,'OutputFcn');plain(odeNumeric);
    live=saved;live.ODESolver=@ode45;live.ODEOptions.OutputFcn=@(~,~,~)budgetOutput(limit);rebuilt=HybridSimulator_v3(live);assert(isequaln(rebuilt.Options,live),'C1PKFine:IntegrationRoundtrip','Native verification refused; original observations are retained.');
    audit=struct('original_solver_header',solverHeader,'original_output_callback_header',outputHeader,'all_other_integration_settings',numeric,'all_other_ODE_options',odeNumeric, ...
        'replacements',{{'Known native ode45 descriptor to fresh @ode45','Known old deadline OutputFcn to fresh immutable-limit callback'}},'saved_closure_executed',false);
end

function out=knownCallback(value,expected)
    header=callbackHeader(value);detail=jsonencode(header);
    if isa(value,'function_handle')&&isscalar(value),signature=func2str(value);out=struct('class',class(value),'signature',signature);
    else
        assert(isstruct(value)&&isscalar(value)&&isequal(sort(fieldnames(value)),sort({'diagnostic_kind';'signature';'requires_runtime_reconstruction'}))&&strcmp(value.diagnostic_kind,'runtime-function-descriptor')&&isequal(value.requires_runtime_reconstruction,true),'C1PKFine:CallbackDescriptor','Unsupported saved callback header: %s',detail);signature=value.signature;out=value;
    end
    assert(ischar(signature)&&isrow(signature)&&strcmp(regexprep(signature,'\s',''),expected),'C1PKFine:CallbackSignature','Unexpected saved callback; no callback is rehydrated. Header: %s',detail);
end

function header=callbackHeader(value)
    header=struct('class',class(value),'size',size(value),'total_field_count',0,'fieldnames_first_32',{{}});
    if isstruct(value)
        names=fieldnames(value);header.total_field_count=numel(names);header.fieldnames_first_32=names(1:min(32,numel(names)));
        if isscalar(value)&&isfield(value,'signature')
            literal=value.signature;header.signature_class=class(literal);header.signature_size=size(literal);
            if ischar(literal)&&isrow(literal)&&numel(literal)<=1024,header.signature_text=literal;end
        end
    elseif isa(value,'function_handle')&&isscalar(value)
        literal=func2str(value);header.signature_length=numel(literal);header.signature_text=literal(1:min(1024,numel(literal)));
    end
end

function p=effectiveProfile(integration,step)
    nested=integration.ODEOptions;rel=1e-12;absolute=1e-14;if ~isempty(nested.RelTol),rel=min(rel,nested.RelTol);end;if ~isempty(nested.AbsTol),absolute=min(absolute,nested.AbsTol);end
    h=step;if ~isempty(nested.MaxStep),h=min(h,nested.MaxStep);end;p=struct('declared_RelTol',1e-12,'declared_AbsTol',1e-14,'declared_MaxStep',step,'effective_RelTol',max(rel,100*eps),'configured_minimum_RelTol',rel,'effective_AbsTol',absolute,'effective_MaxStep',h,'ode45_RelTol_floor',100*eps,'nested_options_preserved',true);
end

function yes=qualified(g)
    yes=isstruct(g)&&isscalar(g)&&strcmp(member(g,'contract_version',''),'quadruped-gait-v3.5')&&strcmp(member(g,'validated_gait_type',''),'PK')&&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1)&&isfield(g,'primitive')&&strcmp(member(g.primitive,'status',''),'primitive_within_checked_bound');
end

function value=fineLimit(seconds,budget,work)
    u=utc()+seconds;m=nano()+seconds*1e9;assert(u<work.u&&m<work.m,'C1PKFine:FineFit','Native verification refused; original observations are retained.');value=struct('deadline_unix_seconds',u,'deadline_utc',utcString(u),'deadline_monotonic_ns',m,'campaign_deadline_utc',utcString(budget.research_deadline_unix_seconds),'campaign_deadline_monotonic_ns',budget.research_deadline_monotonic_ns);
end

function s=utcString(u),v=datetime(u,'ConvertFrom','posixtime','TimeZone','UTC');v.Format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";s=char(v);end

function status=budgetOutput(limit),check(limit);status=0;end

function plain(v)
    if isstruct(v),for k=1:numel(v),for f=fieldnames(v).',plain(v(k).(f{1}));end,end
    elseif iscell(v),for k=1:numel(v),plain(v{k});end
    else,assert(isnumeric(v)||islogical(v)||ischar(v)||isstring(v),'C1PKFine:NonportableSetting','Unknown runtime setting is not silently replaced.');end
end

function assertPublicEqual(a,b,depth)
    assert(depth<=128&&strcmp(class(a),class(b))&&isequal(size(a),size(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    if isnumeric(a)||islogical(a),assert(issparse(a)==issparse(b)&&isreal(a)==isreal(b)&&isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif ischar(a)||isstring(a),assert(isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif iscell(a),for k=1:numel(a),assertPublicEqual(a{k},b{k},depth+1);end
    elseif isstruct(a),keys=fieldnames(a);assert(isequal(keys,fieldnames(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    elseif ismember(class(a),{'HybridOrbit_v3','Trajectory_v3'}),keys=sort(properties(a));assert(isequal(keys,sort(properties(b))),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    else,assert(isequaln(a,b),'C1PKPrimary:NativeRead2','Native verification refused; original observations are retained.');end
end

function u=utc(),u=posixtime(datetime('now','TimeZone','UTC'));end
function m=nano(),m=double(java.lang.System.nanoTime);end
function [targets,points,h]=storedControls(o,limit,read2,emitHeader)
    saved=read2(o.Saved179Reference.file,'audit','Saved1791fd2',limit);
    remaining=read2(o.RemainingReference.file,'audit','Remainingda6',limit);
    emitHeader(directHeader(saved,179));emitHeader(directHeader(remaining,152));
    assert(isstruct(saved)&&isscalar(saved)&&isequal(saved.completed,true)&&isequal(saved.source_posthash,true) ...
        &&isequal(saved.qualified_saved_control,true)&&isequal(saved.finite_original_column_conditions_met,true) ...
        &&isequal(saved.original.original_column,179),'C1PKControls:Saved179','Retain actual direct saved179 qualification, not a NEW7271 target.');
    assert(isstruct(remaining)&&isscalar(remaining)&&iscell(remaining.rows)&&isequal(remaining.completed,false)&&isequal(remaining.source_posthash,false), ...
        'C1PKControls:Remaining','Retain literal global-false Remaining audit and qualified local row separately.');
    hit=find(cellfun(@(r)isstruct(r)&&isscalar(r)&&isfield(r,'original')&&isfield(r.original,'original_column')&&isequal(r.original.original_column,152),remaining.rows));
    assert(isscalar(hit),'C1PKControls:OriginalColumn','Require one actual Remaining row whose recorded original_column is152.');
    row=remaining.rows{hit};
    assert(isequal(row.qualified_new_control,true)&&isequal(row.finite_original_column_conditions_met,true)&&isequal(row.native_all_nine,true) ...
        &&isequal(row.initial_anchor_control.passed,true),'C1PKControls:Local152','Retain literal NEW152 all9/local qualification/anchor evidence.');
    assert(isequal(saved.initial_anchor_control.passed,true),'C1PKControls:Anchor179','Retain original saved179 anchor evidence.');
    rootBack=saved.fresh_saved_root_readback;
    assert(isequal(rootBack.completed,true)&&isequal(rootBack.timely,true)&&isequal(rootBack.native_public_passes,2) ...
        &&strcmp(canonical(rootBack.reference.file),o.RemainingRawReference.file)&&strcmp(rootBack.reference.sha256,o.RemainingRawReference.sha256) ...
        &&strcmp(rootBack.variable,'raw_P1col179_PSS') ...
        &&strcmp(canonical(saved.raw_reference.file),o.Saved179RawReference.file)&&strcmp(saved.raw_reference.sha256,o.Saved179RawReference.sha256), ...
        'C1PKControls:SavedReadback','Bind actual saved179 public read2 and its PSS raw locator, distinct from own fine raw current reference.');
    points={row.new_point;saved.saved_native_point};wrappers={row.fines;saved.fines};columns=[152;179];
    ids={'native-orbit-record:sha256:9e8b7f51693bb143668212aa3a607df2b083ac6932485060b45d4e8e1ff7f69d'; ...
        'native-orbit-record:sha256:57f2c08d6a1f3703c6653acff3bacc00fd57fba0836510edcef46e6e715ea5d9'};
    targets=cell(2,1);headers=cell(2,1);principal=[10;10;20;20;1;1;0;0;2;.5];
    gateNames={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    sectionKeys={'id','geometry','crossing_orientation','boundary_ownership','translational_gauge'};
    for k=1:2
        p=points{k};assert(strcmp(p.native_id,ids{k}),'C1PKControls:DirectNativeID','Keep the exact actually observed full control NativeID.');
        assert(isstruct(p.acceptance_gates)&&isscalar(p.acceptance_gates)&&isstruct(p.classification)&&isscalar(p.classification), ...
            'C1PKControls:PointEvidenceShape','Present saved point evidence must retain scalar-struct shape.');
        gateSeen=false(size(gateNames));gateHeader=struct();
        for j=1:numel(gateNames)
            key=gateNames{j};gateSeen(j)=isfield(p.acceptance_gates,key);
            if gateSeen(j),assert(isequal(p.acceptance_gates.(key),true),'C1PKControls:AvailablePointGate','Every PROVIDED original point gate must be literaltrue.');gateHeader.(key)=p.acceptance_gates.(key);end
        end
        g=p.classification;classKeys={'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'};
        expected={'quadruped-gait-v3.5','PK',true,true,1};classSeen=false(size(classKeys));classHeader=struct();
        for j=1:numel(classKeys)
            key=classKeys{j};classSeen(j)=isfield(g,key);
            if classSeen(j)
                actual=g.(key);if j<=2,valid=strcmp(actual,expected{j});else,valid=isequal(actual,expected{j});end
                assert(valid,'C1PKControls:AvailablePointClassification','Every PROVIDED current-target classification field must match its declared PK1 contract.');
                classHeader.(key)=actual;
            end
        end
        assert(isequaln(p.parameter(:),principal),'C1PKControls:PointParameter','The direct controls retain the unchanged principal physical parameter.');
        fines=wrappers{k};assert(iscell(fines)&&numel(fines)==2,'C1PKControls:FineCount','Retain exactly two historical original-state fine wrappers.');
        configuration=[];seedBound=false(2,1);fineHeaders=cell(2,1);
        for level=1:2
            f=fines{level};
            assert(isequal(f.passed,true)&&isequal(f.initial_trajectory_row_exact,true)&&isequal(f.observation.returned,true)&&isequal(f.observation.return_timely,true) ...
                &&isequal(f.raw_custody.storage_timely,true)&&isequal(f.raw_custody.readback_timely,true) ...
                &&f.saved_period_scaled_error<=1e-8&&f.saved_stride_scaled_error<=1e-8, ...
                'C1PKControls:HistoricalFine','Keep actual historical pass/initialrow/return/storage/readback/period/stride gates.');
            m=f.matching_saved_section;
            assert(isequal(m.compatible,true)&&isequal(m.actual_policy_configuration_checked,true)&&isequal(m.policy_configuration_matches_declared_identity,true) ...
                &&isequal(m.rephase_or_chart_transition_inferred,false),'C1PKControls:FineSection','Use only the actual saved complete matching-section contract.');
            assert(isequal(m.left_policy_evidence.complete,true)&&isequal(m.right_policy_evidence.complete,true) ...
                &&isequaln(m.left_policy_configuration,m.right_policy_configuration) ...
                &&isequaln(m.left_policy_evidence.configuration,m.left_policy_configuration)&&isequaln(m.right_policy_evidence.configuration,m.right_policy_configuration), ...
                'C1PKControls:FinePolicy','Both actual fine sides must expose complete identical policy settings/evidence.');
            c=m.left_policy_configuration;
            if isempty(configuration),configuration=c;else,assert(isequaln(c,configuration),'C1PKControls:FinePolicyLevels','Both original levels must retain the SAME complete policy.');end
            for side={'left_identity','right_identity'}
                ident=m.(side{1});
                assert(isequaln(ident.initial_mode,logical(p.mode(:)))&&isequaln(ident.section,pick(p.section_chart,sectionKeys))&&ident.return_occurrence==1, ...
                    'C1PKControls:FinePointSection','Actual fine semantic section/mode/occurrence must bind the saved control point.');
            end
            inner=member(f,'fine',struct());innerAvailable=isstruct(inner)&&isscalar(inner);
            if innerAvailable&&isfield(inner,'initial_state')
                assert(isequaln(inner.initial_state,p.initial_state),'C1PKControls:FineInitialState','Every available original fine initial state must exactly equal its retained control point.');seedBound(level)=true;
            end
            if innerAvailable&&isfield(inner,'actual_policy_configuration'),assert(isequaln(inner.actual_policy_configuration,configuration),'C1PKControls:FineNumericPolicy','Available actual fine policy must equal its matching-section evidence.');end
            if innerAvailable&&isfield(inner,'event_signature'),assert(strcmp(string(inner.event_signature),string(p.section_event_signature)),'C1PKControls:FineEvent','Available actual fine token must match the saved point.');end
            fineHeaders{level}=struct('passed',f.passed,'returned',f.observation.returned,'return_timely',f.observation.return_timely, ...
                'initial_row_exact',f.initial_trajectory_row_exact,'raw_storage_timely',f.raw_custody.storage_timely,'raw_readback_timely',f.raw_custody.readback_timely, ...
                'saved_period_scaled_error',f.saved_period_scaled_error,'saved_stride_scaled_error',f.saved_stride_scaled_error, ...
                'fine_payload_scalar_struct_available',innerAvailable,'fine_initial_state_available_and_exact',seedBound(level),'raw_custody_reference_historical',f.raw_custody.reference, ...
                'historical_raw_reference_rehashed',false);
        end
        assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isequal(configuration.settings.BLTouchdownsPerReturn,1)&&isequal(configuration.settings.RequireModeClosure,true), ...
            'C1PKControls:PolicyClass','Use the recorded actual BL1/mode-closed policy, never guessed defaults or callbacks.');
        v=struct('initial_state',p.initial_state,'initial_mode',p.mode,'parameter',p.parameter,'period',p.period, ...
            'stride_displacement',p.full_stride,'return_policy_name',configuration.settings.Name);
        orbit=HybridOrbit_v3(v);assert(strcmp(OrbitContentIdentity_v3(orbit),p.native_id),'C1PKControls:DirectIDRoundtrip','The actual identity method must reproduce each saved control ID from literal identity-bearing values.');clear orbit v
        role='qualified-new-original-column152-control';if k==2,role='qualified-saved-original-column179-control';end
        targets{k}=struct('native_id',p.native_id,'role',role,'state',p.initial_state,'mode',p.mode,'parameter',p.parameter, ...
            'period',p.period,'full_stride',p.full_stride,'native_energy',p.native_energy,'policy_configuration',configuration, ...
            'current_PK1_all9_evidence_complete',all(classSeen)&&all(gateSeen));
        headers{k}=struct('original_column',columns(k),'native_id',p.native_id,'source_disposition',role,'classification',classHeader, ...
            'original_acceptance_gates',gateHeader,'target_current_PK1_all9_evidence_complete',all(classSeen)&&all(gateSeen), ...
            'missing_classification_keys_UNASSESSED',{classKeys(~classSeen)},'missing_acceptance_gate_keys_UNASSESSED',{gateNames(~gateSeen)},'fine_observations',{fineHeaders},'fine_initial_state_unavailable_is_UNASSESSED',true, ...
            'historical_process_exit_revalidated',false,'all_four_cohorts_assessed',false,'original_legacy_state_admission_claimed',false);
    end
    sourceHeaders=cell(2,1);audits={remaining;saved};
    for k=1:2
        a=audits{k};v=member(a,'source_code',[]);d='';failure='';
        try,d=C1ScientificDigest_v3(v);catch problem,failure=problem.identifier;end
        sourceHeaders{k}=struct('original_column',columns(k),'class',class(v),'count',numel(v),'digest',d,'digest_failure_identifier',failure, ...
            'field_present',isfield(a,'source_code'),'syntax_assessed',false,'currentness_claimed',false);
    end
    h=struct('direct_source_scope','No7271/common210a target join. Exact Saved179/Remaining local native evidence is used.', ...
        'saved179_parent_completed',saved.completed,'saved179_parent_source_posthash',saved.source_posthash, ...
        'saved179_qualified_saved_control',saved.qualified_saved_control,'saved179_finite_original_conditions',saved.finite_original_column_conditions_met, ...
        'remaining_parent_completed',remaining.completed,'remaining_parent_source_posthash',remaining.source_posthash, ...
        'remaining_parent_failure_identifier',member(member(remaining,'failure',struct()),'identifier',''), ...
        'remaining_other_row_qualification_UNASSESSED',true,'selected_remaining_row',hit,'rows',{headers},'historical_source_headers',{sourceHeaders}, ...
        'raw_reference_scope','Both current raw files are hash-only. Child fine/PSS locators remain historical; no old reference is rehashed against a successor file or callback invoked.', ...
        'custody_scope','Original saved qualification/fine flags are observed; present process-exit and full historical-runtime equality are not inherited.');
    check(limit);
end
function h=directHeader(a,column)
    h=struct('original_column_requested',column,'audit_class',class(a),'top_field_count',0, ...
        'matching_original_row_count',0,'observed_original_columns',[],'point_field_count',0,'native_id','', ...
        'qualified_flag_available',false,'fine_count',0,'fine_initial_state_available',false(2,1),'fine_section_policy_fields_available',false(2,1), ...
        'point_classification_key_count',0,'point_classification_keys_prefix',{{}},'point_gate_key_count',0,'point_gate_keys_prefix',{{}});
    selected=struct();
    if isstruct(a)&&isscalar(a)
        keys=fieldnames(a);h.top_field_count=numel(keys);
        if column==179
            selected=a;h.observed_original_columns=member(member(a,'original',struct()),'original_column',[]);
            h.matching_original_row_count=double(isequal(h.observed_original_columns,179));
            h.qualified_flag_available=isfield(a,'qualified_saved_control');p=member(a,'saved_native_point',struct());
        else
            rows=member(a,'rows',{});hits=[];
            if iscell(rows)
                observed=NaN(min(4,numel(rows)),1);
                for k=1:numel(rows)
                    v=member(member(rows{k},'original',struct()),'original_column',[]);
                    if k<=4&&isnumeric(v)&&isscalar(v),observed(k)=v;end
                    if isequal(v,column),hits(end+1)=k;end %#ok<AGROW>
                end
                h.observed_original_columns=observed;h.matching_original_row_count=numel(hits);
                if isscalar(hits),selected=rows{hits};end
            end
            h.qualified_flag_available=isfield(selected,'qualified_new_control');p=member(selected,'new_point',struct());
        end
        if isstruct(p)&&isscalar(p)
            h.point_field_count=numel(fieldnames(p));id=member(p,'native_id','');if ischar(id),h.native_id=id(1:min(100,numel(id)));end
            v=member(p,'classification',struct());if isstruct(v)&&isscalar(v),keys=fieldnames(v);h.point_classification_key_count=numel(keys);h.point_classification_keys_prefix=keys(1:min(5,numel(keys)));end
            v=member(p,'acceptance_gates',struct());if isstruct(v)&&isscalar(v),keys=fieldnames(v);h.point_gate_key_count=numel(keys);h.point_gate_keys_prefix=keys(1:min(5,numel(keys)));end
        end
        fs=member(selected,'fines',{});
        if iscell(fs)
            h.fine_count=numel(fs);
            for k=1:min(2,numel(fs))
                inner=member(fs{k},'fine',struct());m=member(fs{k},'matching_saved_section',struct());
                h.fine_initial_state_available(k)=isstruct(inner)&&isfield(inner,'initial_state');
                h.fine_section_policy_fields_available(k)=isstruct(m)&&all(isfield(m,{'left_policy_configuration','right_policy_configuration','left_policy_evidence','right_policy_evidence'}));
            end
        end
    end
end

function out=pick(s,keys)
    out=struct();for k=1:numel(keys),assert(isfield(s,keys{k}),'C1PKCol1:RequiredField','A required saved field is missing.');out.(keys{k})=s.(keys{k});end
end

