function facts=ObserveC1PKOwnedP1Controls20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,options)
%OBSERVEC1PKOWNEDP1CONTROLS20261031 Bounded stored152/179 comparison and PAL geometry.
% Index scalars select at most six records. No Root/map evaluation/fine or write.
    started=clockPair();validSHA(expectedLedgerSHA);validSHA(expectedRawSHA);validSHA(expectedRoundSHA);
    exactFields(options,{'TargetInputReference','TargetQualificationReference','TargetRawReference','ForkReference','PrimaryShortlist','ProtectedReferences'});o=options;
    for key={'TargetInputReference','TargetQualificationReference','TargetRawReference','ForkReference'},o.(key{1})=checked(o.(key{1}));end
    exactFields(o.PrimaryShortlist,{'method','count_per_target'});
    assert(strcmp(o.PrimaryShortlist.method,'index-energy-meanU-nearest')&&isequal(o.PrimaryShortlist.count_per_target,3), ...
        'C1PKControls:Shortlist','Use the declared deterministic three-per-target index selector.');
    assert(strcmp(o.TargetInputReference.sha256,'7271b42befe2b47426ded73031d0833dc1a4dd1f34a17498515e2c5cc72c0652') ...
        &&strcmp(o.TargetQualificationReference.sha256,'210a54d6282acd0abe57ecf6fce491c52d78329a01adfe72b136554fba683a28') ...
        &&strcmp(o.TargetRawReference.sha256,'cf8a0a2af207955a8ba8cc228548e4012f3310e5e1d5dc5e7a297c917ee5a87a'), ...
        'C1PKControls:HistoricalPins','Use the retained independently qualified NEW controls, not original legacy states.');
    root=canonical(fileparts(which('C1RunBudget_v3')));budget=C1RunBudget_v3();finish=shift(started,600);work=shift(finish,-120);
    assert(finish.utc<budget.research_deadline_unix_seconds&&finish.mono<budget.research_deadline_monotonic_ns, ...
        'C1PKControls:WholeFit','Full600 including120 reserve must fit BOTH unchanged SCIENCE clocks.');check(work);
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));
    raw=canonical(fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'));
    roundFile=canonical(fullfile(root,'Audits','PK36h_20261031_Round.mat'));
    live={struct('file',ledger,'sha256',expectedLedgerSHA);struct('file',raw,'sha256',expectedRawSHA);struct('file',roundFile,'sha256',expectedRoundSHA)};
    assert(~strcmp(raw,o.ForkReference.file),'C1PKControls:ForkPath','Primary and retained fork are distinct native authorities.');
    protected=references(o.ProtectedReferences);self=reference(which(mfilename));code=currentCode(self,protected);
    refs=[live;{o.TargetInputReference;o.TargetQualificationReference;o.TargetRawReference;o.ForkReference};protected];
    facts=struct('schema','C1-owned-PK-existing-P1-controls-observation-v1','source_reference',self,'budget',budget, ...
        'expected_current_references',{live},'target_input_reference',o.TargetInputReference,'target_qualification_reference',o.TargetQualificationReference, ...
        'target_raw_reference',o.TargetRawReference,'fork_reference',o.ForkReference,'actual_method_references',{code}, ...
        'declared_seconds',600,'save_post_reserve_seconds',120,'original_columns',[152;179], ...
        'target_audit_load_calls_returned',0,'index_calls_returned',0,'selected_load_calls_returned',0, ...
        'target_native_read2_verified',false,'index_read2_verified',false,'selected_compact_read2_verified',false, ...
        'targets',{{}},'historical_qualification',struct(),'shortlist',struct(),'primary',struct(),'fork',struct(),'fork_geometry',struct(), ...
        'root_calls',0,'map_evaluate_calls',0,'fine_calls',0,'current_journal_decoded',false,'raw_target_deserialized',false, ...
        'source_posthash',false,'completed',false,'failure',struct(),'own_process_exit_observed',false, ...
        'all_four_target_cohorts_claimed',false,'physical_attachment_claimed',false,'exact_identity_claimed',false, ...
        'original_P1_state_admission_claimed',false,'scheduled_v2_equivalence_claimed',false,'global_absence_claimed',false, ...
        'coverage_claimed',false,'endpoint_claimed',false,'ownership_changed',false,'journal_mutated',false,'round_mutated',false,'raw_mutated',false, ...
        'started_utc',stamp(),'finished_utc','', ...
        'read2_scope','Two independent selected native acquisitions compare declared compact states, saved gates, identities, metadata, full comparisons and scalar observations. No whole runtime-callback workspace or dense-trajectory equality claim.', ...
        'selector_scope','Index-metadata E/signedmeanU ranking only. Unselected, excluded and unknown rows remain UNASSESSED; no nearest-orbit or global absence inference.', ...
        'geometry_scope','Actual retained physical fork2->3 direction in the unchanged Run pronk family; constructors/pack/lift only. Target lift/section incompatibility is observed, never repaired or used as a seed.', ...
        'clock_scope','Scalar guards observe returned uninterruptible native reads; they do not cancel an internal MAT load.', ...
        'scope','Finite stored comparisons to already qualified NEW controls152/179. No Root, control reacquisition, fine, new edge, admission, rephase or persistent mutation.');
    normalSummaryReturned=false;
    try
        guard(work);assert(isfile([ledger,'.writer.lock']),'C1PKControls:Lock','Use the existing stable writer-lock inode.');
        lock=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
        [targets,points,historical]=storedControls(o,work,@observedTwice);facts.target_native_read2_verified=true;facts.historical_qualification=historical;
        witnesses=cell(2,1);policies=cell(2,1);signatures=cell(2,1);
        for k=1:2
            [witnesses{k},policies{k},signatures{k}]=storedSection(targets{k},points{k},work);targetShapes(targets{k},witnesses{k});
            t=targets{k};facts.targets{k,1}=struct('original_column',facts.original_columns(k),'native_id',t.native_id,'role',t.role, ...
                'state',t.state,'mode',t.mode,'parameter',t.parameter,'period',t.period,'full_stride',t.full_stride, ...
                'saved_native_energy',t.native_energy,'ranking_energy',QuadrupedEnergy_v3.evaluate(t.state,t.mode,t.parameter), ...
                'ranking_signedmeanU',t.full_stride(1)/t.period,'policy_configuration',t.policy_configuration, ...
                'section_chart',witnesses{k}.section_chart,'section_event_signature',signatures{k});
        end
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_PRIMARY_INDEX1\n');ix=BranchSolutionFile_v3.index(raw);facts.index_calls_returned=facts.index_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_PRIMARY_INDEX1_RETURN\n');check(work);
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_PRIMARY_INDEX2\n');ix2=BranchSolutionFile_v3.index(raw);facts.index_calls_returned=facts.index_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_PRIMARY_INDEX2_RETURN\n');check(work);
        assert(isequaln(ix,ix2),'C1PKControls:IndexRead2','Entire primary indices differ.');clear ix2
        facts.shortlist=indexShortlist(ix,facts.targets);selectors=facts.shortlist.selected_union;
        facts.primary=observedSelection(raw,ix,selectors,'PRIMARY',false);
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_FORK_INDEX1\n');fx=BranchSolutionFile_v3.index(o.ForkReference.file);facts.index_calls_returned=facts.index_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_FORK_INDEX1_RETURN\n');check(work);
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_FORK_INDEX2\n');fx2=BranchSolutionFile_v3.index(o.ForkReference.file);facts.index_calls_returned=facts.index_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_FORK_INDEX2_RETURN\n');check(work);
        assert(isequaln(fx,fx2)&&numel(fx.points)>=3,'C1PKControls:ForkIndex','Require identical complete indices and the actual retained fork2/3.');clear fx2
        hit=find(cellfun(@(e)e.from==2&&e.to==3,fx.edges));assert(isscalar(hit),'C1PKControls:ForkEdge','Require literal physical fork2->3.');
        edge=fx.edges{hit};assert(strcmp(edge.component_identity,fx.points{2}.component_identity)&&strcmp(edge.component_identity,fx.points{3}.component_identity), ...
            'C1PKControls:ForkOwner','The physical edge and both occurrences must have one literal owner.');facts.fork_physical_edge=edge;
        facts.fork=observedSelection(o.ForkReference.file,fx,[2;3],'FORK',true);
        facts.fork_geometry=observedGeometry(facts.fork.records{1},facts.fork.records{2},targets,witnesses,policies,work);
        clear ix fx points targets policies witnesses signatures
        facts.index_read2_verified=true;facts.selected_compact_read2_verified=true;
        facts.read2_digest=C1ScientificDigest_v3(struct('targets',{facts.targets},'shortlist',facts.shortlist,'primary',facts.primary,'fork',facts.fork,'geometry',facts.fork_geometry));
        guard(finish);facts.source_posthash=true;facts.finished_utc=stamp();facts.completed=true;check(finish);
        encoded=jsonencode(stdoutView(facts));assert(numel(unicode2native(encoded,'UTF-8'))<=50000,'C1PKControls:SummaryBytes','Normal summary exceeds50000 UTF8 bytes.');
        fprintf('C1_PK_CONTROLS_BEFORE_FINAL_SUMMARY\n');fprintf('C1_PK_P1_CONTROLS_OBSERVATION_ACTUAL_RETURN %s\n',encoded);normalSummaryReturned=true;fprintf('C1_PK_CONTROLS_AFTER_FINAL_SUMMARY_RETURN\n');guard(finish);
    catch problem
        facts.completed=false;facts.failure=exceptionData(problem);facts.finished_utc=stamp();p=partial(facts,problem,normalSummaryReturned);encoded=jsonencode(p);
        if numel(unicode2native(encoded,'UTF-8'))>7000,p.failure_header.message_prefix='';p.failure_header.message_truncated=true;p.failure_header.first_stack_frame=struct();p.failure_header.stack_detail_omitted=true;encoded=jsonencode(p);end
        assert(numel(unicode2native(encoded,'UTF-8'))<=7000,'C1PKControls:PartialBytes','Fixed compact partial must fit7000 UTF8 bytes.');
        fprintf('C1_PK_P1_CONTROLS_OBSERVATION_PARTIAL %s\n',encoded);rethrow(problem);
    end
    function a=observedTwice(file,key,label,limit)
        check(limit);fprintf('C1_PK_CONTROLS_BEFORE_AUDIT_LOAD1 %s\n',label);x=load(file,'-mat',key);facts.target_audit_load_calls_returned=facts.target_audit_load_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_AUDIT_LOAD1_RETURN %s\n',label);check(limit);
        fprintf('C1_PK_CONTROLS_BEFORE_AUDIT_LOAD2 %s\n',label);y=load(file,'-mat',key);facts.target_audit_load_calls_returned=facts.target_audit_load_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_AUDIT_LOAD2_RETURN %s\n',label);check(limit);
        assert(isequaln(x.(key),y.(key)),'C1PKControls:AuditRead2','Whole retained plain audits differ.');a=x.(key);check(limit);
    end
    function out=observedSelection(file,index,selected,label,requirePair)
        principal=[10;10;20;20;1;1;0;0;2;.5];N=numel(selected);first=cell(N,1);comp=cell(N,2);scalar=cell(N,1);pair=struct();
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_SELECTED_LOAD1 %s\n',label);[O,R,M]=BranchSolutionFile_v3.loadSolutions(file,selected);facts.selected_load_calls_returned=facts.selected_load_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_SELECTED_LOAD1_RETURN %s\n',label);timely1=left(work)>0;check(work);
        assert(isequal(size(O),[N 1])&&isequal(size(R),[N 1])&&isequal(size(M),[N 1]),'C1PKControls:SelectedShape','Retain requested column-cell order.');
        for i=1:N
            strictPK(O{i},R{i},principal);first{i}=pointHeader(O{i},R{i},M{i},index.points{selected(i)},selected(i));scalar{i}=nativeScalars(first{i},index.points{selected(i)});
            for j=1:2,comp{i,j}=compareTarget(O{i},R{i},targets{j},witnesses{j},policies{j},signatures{j});end
        end
        if requirePair
            pair=MatchingReturnSection_v3(O{1},O{2},{R{1},R{2}});
            assert(pair.compatible&&isequal(O{1}.parameter,O{2}.parameter)&&isequaln(first{1}.policy_configuration,first{2}.policy_configuration), ...
                'C1PKControls:Pair','Actual fork2/3 must satisfy Run source-pair policy/physical chart compatibility.');
        end
        clear O R M
        guard(work);fprintf('C1_PK_CONTROLS_BEFORE_SELECTED_LOAD2 %s\n',label);[O,R,M]=BranchSolutionFile_v3.loadSolutions(file,selected);facts.selected_load_calls_returned=facts.selected_load_calls_returned+1;fprintf('C1_PK_CONTROLS_AFTER_SELECTED_LOAD2_RETURN %s\n',label);timely2=left(work)>0;check(work);
        assert(isequal(size(O),[N 1])&&isequal(size(R),[N 1])&&isequal(size(M),[N 1]),'C1PKControls:SelectedShape','Retain requested column-cell order.');
        for i=1:N
            strictPK(O{i},R{i},principal);h=pointHeader(O{i},R{i},M{i},index.points{selected(i)},selected(i));assert(isequaln(h,first{i})&&isequaln(nativeScalars(h,index.points{selected(i)}),scalar{i}), ...
                'C1PKControls:SelectedRead2','Compact native identities/states/gates/metadata/scalars differ.');
            for j=1:2,c=compareTarget(O{i},R{i},targets{j},witnesses{j},policies{j},signatures{j});assert(isequaln(c,comp{i,j}),'C1PKControls:ComparisonRead2','Actual full comparison differs.');end
        end
        if requirePair,assert(isequaln(MatchingReturnSection_v3(O{1},O{2},{R{1},R{2}}),pair),'C1PKControls:PairRead2','Actual native pair chart differs.');end
        clear O R M h c
        out=struct('selected_indices',selected,'records',{first},'comparisons',{comp},'native_index_scalar_observations',{scalar}, ...
            'physical_incident_edges',{incidentBindings(index,selected)},'pair_match',pair,'native_read2_verified',true,'return_timely',[timely1;timely2], ...
            'scope','Index ranking is not re-run after native scalar mismatches. Every unselected occurrence remains UNASSESSED.');
    end
    function guard(limit)
        check(limit);quiet(ledger,raw,roundFile);assert(~isfile([o.ForkReference.file,'.pending.mat']),'C1PKControls:ForkPending','Retain/reconcile a pending fork stage before observation.');
        verify(refs);verifyCode(code);assert(isequaln(C1RunBudget_v3(),budget),'C1PKControls:BudgetValue','The original native budget VALUE must remain literal.');check(limit);
    end
end
function [targets,points,h]=storedControls(o,limit,read2)
    a=read2(o.TargetInputReference.file,'audit','intake7271',limit);
    old=read2(o.TargetQualificationReference.file,'audit','qualified210a',limit);
    assert(isstruct(a)&&isscalar(a)&&isequal(a.completed,true)&&isequal(a.source_posthash,true)&&isempty(fieldnames(a.failure))&&iscell(a.targets) ...
        &&isstruct(old)&&isscalar(old)&&iscell(old.rows)&&isequal(old.completed,false)&&isequal(old.source_posthash,false), ...
        'C1PKControls:Authorities','Keep complete target intake and original literal global-false qualification authority.');
    syntaxReferences(a.source_code);columns=[152;179];targets=cell(2,1);points=cell(2,1);rows=cell(2,1);
    for k=1:2
        hit=find(cellfun(@(r)isstruct(r)&&isscalar(r)&&isfield(r,'original')&&isfield(r.original,'original_column')&&isequal(r.original.original_column,columns(k)),old.rows));
        assert(isscalar(hit),'C1PKControls:OriginalColumn','Select exactly one retained row by actual original_column152/179.');r=old.rows{hit};
        assert(isequal(r.qualified_new_control,true)&&isequal(r.finite_original_column_conditions_met,true)&&isequal(r.native_all_nine,true) ...
            &&isequal(r.initial_anchor_control.passed,true)&&iscell(r.fines)&&numel(r.fines)==2 ...
            &&all(cellfun(@(f)isequal(f.passed,true)&&isequal(f.observation.returned,true)&&isequal(f.observation.return_timely,true)&&isequal(f.raw_custody.storage_timely,true)&&isequal(f.raw_custody.readback_timely,true),r.fines)), ...
            'C1PKControls:LocalQualification','Each existing NEW control must retain its actual local all9/two timely original-state fine qualification.');
        p=r.new_point;join=find(cellfun(@(t)isstruct(t)&&isscalar(t)&&isfield(t,'native_id')&&strcmp(t.native_id,p.native_id),a.targets));
        assert(isscalar(join),'C1PKControls:NativeIDJoin','Join actual full NativeID uniquely; never guess targets array order or role.');t=a.targets{join};
        assert(ischar(t.role)&&isrow(t.role)&&~isempty(t.role)&&isequaln(t.authority.audit_reference,o.TargetQualificationReference)&&isequaln(t.authority.final_raw_reference,o.TargetRawReference) ...
            &&isequaln(t.state,p.initial_state)&&isequaln(t.mode,p.mode)&&isequaln(t.parameter,p.parameter)&&isequaln(t.period,p.period)&&isequaln(t.full_stride,p.full_stride), ...
            'C1PKControls:TargetValues','Bind each target identity-bearing value and original qualification/raw authority exactly.');
        targets{k}=t;points{k}=p;
        rows{k}=struct('original_column',columns(k),'qualification_row',hit,'target_intake_row',join,'native_id',t.native_id,'role',t.role, ...
            'native_all_nine',r.native_all_nine,'qualified_new_control',r.qualified_new_control,'finite_original_column_conditions_met',r.finite_original_column_conditions_met, ...
            'initial_anchor_passed',r.initial_anchor_control.passed,'two_original_fines_passed',cellfun(@(f)f.passed,r.fines), ...
            'historical_process_exit_revalidated',false,'all_four_cohorts_assessed',false,'original_legacy_state_admitted',false);
    end
    parentSourceClass='';parentSourceCount=0;if isfield(old,'source_code'),parentSourceClass=class(old.source_code);parentSourceCount=numel(old.source_code);end
    h=struct('parent_completed',old.completed,'parent_source_posthash',old.source_posthash,'rows',{rows}, ...
        'target_intake_source_code_historical_syntax_only',{a.source_code},'qualification_parent_source_code_currentness_claimed',false, ...
        'qualification_parent_source_code_schema_assessed',false,'qualification_parent_source_code_field_present',isfield(old,'source_code'), ...
        'qualification_parent_source_code_class',parentSourceClass,'qualification_parent_source_code_count',parentSourceCount, ...
        'raw_reference_scope','Pinned target raw cf8a is hash-only; no variable names, callback execution or native raw payload are guessed.', ...
        'custody_scope','Immutable saved audit/local qualification flags are observed. No Short01-col1 closure is promoted to152/179 and no present process-exit claim is inherited.');
    check(limit);
end
function result=indexShortlist(ix,targets)
    N=numel(ix.points);E=NaN(N,1);U=NaN(N,1);physical=false(N,1);label=false(N,1);
    for k=1:N
        p=ix.points{k};E(k)=p.nativeE;U(k)=p.signedmeanU;label(k)=strcmp(p.classification,'PK');
    end
    for k=1:numel(ix.edges)
        e=ix.edges{k};assert(strcmp(e.component_identity,ix.points{e.from}.component_identity)&&strcmp(e.component_identity,ix.points{e.to}.component_identity), ...
            'C1PKControls:EdgeOwner','A literal physical edge must agree with both actual occurrence owners.');physical([e.from,e.to])=true;
    end
    finite=isfinite(E)&isfinite(U);eligible=finite&physical&label;assert(nnz(eligible)>=3,'C1PKControls:Candidates','At least three finite PK index rows with physical incident edges are required.');
    selections=cell(2,1);which=find(eligible);
    for j=1:2
        et=targets{j}.ranking_energy;ut=targets{j}.ranking_signedmeanU;scales=[max(1,abs(et));max(1,abs(ut))];
        score=((E(which)-et)/scales(1)).^2+((U(which)-ut)/scales(2)).^2;
        assert(all(isfinite(score)),'C1PKControls:RankFinite','Declared finite metadata distances must remain finite.');
        sorted=sortrows([score,which],[1 2]);sel=sorted(1:3,2);
        selections{j}=struct('original_column',targets{j}.original_column,'target_native_id',targets{j}.native_id, ...
            'target_energy',et,'target_signedmeanU',ut,'fixed_scales',scales,'selected_indices',sel,'selected_squared_distance',sorted(1:3,1), ...
            'selected_index_energy',E(sel),'selected_index_signedmeanU',U(sel),'eligible_unselected_count_UNASSESSED',nnz(eligible)-3);
    end
    union=unique([selections{1}.selected_indices;selections{2}.selected_indices],'sorted');
    assert(numel(union)<=6,'C1PKControls:Union','The deterministic union cannot exceed six.');
    result=struct('method','index-energy-meanU-nearest','distance','squared2 norm with fixed target max1 scales; original index breaks ties', ...
        'count_per_target',3,'per_target',{selections},'selected_union',union,'total_index_rows',N,'eligible_count',nnz(eligible), ...
        'unknown_nonfinite_count_UNASSESSED',nnz(~finite),'nonphysical_count_UNASSESSED',nnz(~physical),'non_PK_metadata_count_UNASSESSED',nnz(~label), ...
        'total_unselected_count_UNASSESSED',N-numel(union),'excluded_count_UNASSESSED',N-nnz(eligible), ...
        'exclusion_counts_can_overlap',true,'native_admission_verified_at_selection',false,'global_absence_claimed',false,'reranking_after_native_load',false);
end
function out=nativeScalars(h,p)
    u=h.full_stride(1)/h.period;
    out=struct('index_energy',p.nativeE,'native_recomputed_energy',h.native_energy,'energy_delta',h.native_energy-p.nativeE, ...
        'energy_exact_equal',isequaln(h.native_energy,p.nativeE),'index_signedmeanU',p.signedmeanU,'native_recomputed_signedmeanU',u, ...
        'signedmeanU_delta',u-p.signedmeanU,'signedmeanU_exact_equal',isequaln(u,p.signedmeanU), ...
        'mismatch_changes_selection',false,'scope','Any mismatch stays literal; no reranking, replacement candidate or physics/admission inference.');
end
function b=incidentBindings(ix,selected)
    b=cell(numel(selected),1);
    for k=1:numel(selected)
        s=selected(k);hit=find(cellfun(@(e)e.from==s||e.to==s,ix.edges));assert(~isempty(hit),'C1PKControls:OwnedOccurrence','Each selected occurrence must have a stored physical incident edge.');
        b{k}=ix.edges(hit);
    end
end
function g=observedGeometry(a,b,targets,witnesses,policyReports,limit)
    schema=QuadrupedSchema_v3.shared();configuration=b.policy_configuration;policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));
    [~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration),'C1PKControls:BasePolicy','Fresh base-policy constructor must exactly roundtrip the actual recorded policy.');
    integration=struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001,'ODEOptions',odeset('OutputFcn',@(~,~,~)geometryClock(limit)));
    map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(schema.PhaseIndex),HybridSimulator_v3(integration),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));
    family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,b.state),b.state,b.mode,b.parameter,struct('Symmetry','pronk'));
    ua=family.packState(a.state);ub=family.packState(b.state);scale=max([ones(numel(ub),1),abs(ua),abs(ub)],[],2);
    delta=(ub-ua)./scale;distance=norm(delta);assert(isfinite(distance)&&distance>1e-10,'C1PKControls:Chord','Require the actual resolved physical fork2->3 chord.');tangent=delta/distance;
    assert(isequal(family.fullState(ub),b.state(:)),'C1PKControls:BaseRoundtrip','Actual admitted fork3 base must roundtrip exactly without projection.');
    rows=cell(2,1);
    for j=1:2
        t=targets{j};ut=family.packState(t.state);sigma=dot(tangent,(ut-ub)./scale);
        assert(isa(sigma,'double')&&isreal(sigma)&&isscalar(sigma)&&isfinite(sigma),'C1PKControls:Sigma','Record an actual finite signed native projection.');
        lifted=family.fullState(ut);predictor=family.fullState(ub+scale.*(sigma*tangent));
        section=MatchingReturnSection_v3(struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',b.mode,'section_chart',b.section_chart,'return_multiplicity',1), ...
            witnesses{j},{struct('seed',struct('return_policy',policy)),policyReports{j}});
        rows{j}=struct('native_id',t.native_id,'target_coordinates',ut,'signed_sigma',sigma,'sigma_in_declared_Run_bounds',sigma>=1e-7&&sigma<=.1, ...
            'target_lift_minus_raw',lifted-t.state(:),'target_roundtrip_exact',isequal(lifted,t.state(:)),'target_parameter_mode_equal',isequaln(b.parameter,t.parameter)&&isequaln(b.mode,t.mode), ...
            'target_matching_section',section,'capture_predictor_state',predictor,'target_used_as_seed',false, ...
            'predictor_full13_separation',norm((predictor(2:14)-b.state(2:14))./max(ones(13,1),abs(b.state(2:14))),inf), ...
            'predictor_target_full13_scaled_inf',norm((predictor(2:14)-t.state(2:14))./max([ones(13,1),abs(predictor(2:14)),abs(t.state(2:14))],[],2),inf));
    end
    g=struct('source_pair',[2 3],'source_native_ids',{{a.native_id;b.native_id}},'symmetry','pronk','coordinate_indices',family.CoordinateIndices, ...
        'closure_indices',family.ClosureIndices,'energy_pivot',family.EnergyPivot,'scale',scale,'ua',ua,'ub',ub,'tangent',tangent,'chord_distance',distance, ...
        'source_A_lift_minus_raw',family.fullState(ua)-a.state(:),'base_roundtrip_exact',true,'base_energy',QuadrupedEnergy_v3.evaluate(b.state,b.mode,b.parameter), ...
        'targets',{rows},'map_evaluate_calls',0,'source_direction_reversed',false,'scope','Exact Run chart/scale/tangent calculation only. Signed projections, lift mismatch and section incompatibility are observations, never a physical connection or authorized Root target.');
    check(limit);
end
function x=geometryClock(limit),check(limit);x=0;end
function code=currentCode(self,protected)
    names={'C1RunBudget_v3','BranchSolutionFile_v3','QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3','QuadrupedAdmissibility_v3','ContinuousDynamics_v3', ...
        'RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3','MatchingReturnSection_v3','OrbitContentIdentity_v3','HybridOrbit_v3','Trajectory_v3','RoundSHA256_v3','C1ScientificDigest_v3', ...
        'RunC1Continuation_v3','PoincareMap_v3','Quadrupedal_Dynamics_v3','PoincareSection_v3','HybridSimulator_v3','PeriodicOrbitResidual_v3','EnergyFamilyResidual_v3','HybridSystemBase_v3'};
    code={self};
    for k=1:numel(names)
        r=reference(which(names{k}));assert(any(cellfun(@(q)strcmp(q.file,r.file)&&strcmp(q.sha256,r.sha256),protected)),'C1PKControls:CallerPin','Every declared current resolver must be caller-protected.');
        if strcmp(names{k},'RunC1Continuation_v3'),assert(strcmp(r.sha256,'09e1b6813f4bdc1ca1115138d60d504bdb2758a8cb7e530f80c38987591b5bf1'),'C1PKControls:RunPin','Keep actual Run09 geometry authority; Run is not invoked.');end
        code{end+1,1}=r;
    end
end
function v=stdoutView(f)
    % Projection only: scientific comparisons/read2/digest use complete facts.
    v=f;v.full_in_memory_facts_digest=C1ScientificDigest_v3(f);
    history=v.historical_qualification;tuple=history.target_intake_source_code_historical_syntax_only;
    history=rmfield(history,'target_intake_source_code_historical_syntax_only');
    history.target_intake_historical_source_count=numel(tuple);history.target_intake_historical_source_digest=C1ScientificDigest_v3(tuple);
    history.target_intake_historical_source_payload_omitted=true;v.historical_qualification=history;
    sectionKeys={'compatible','actual_policy_configuration_checked','policy_configuration_matches_declared_identity','rephase_or_chart_transition_inferred','left_missing_fields','right_missing_fields'};
    for side={'primary','fork'}
        name=side{1};s=v.(name);s=rmfield(s,'scope');
        for k=1:numel(s.comparisons)
            c=s.comparisons{k};m=c.matching_section;
            c=rmfield(c,{'matching_section','scope'});c.matching_section_header=pick(m,sectionKeys);
            c.full_matching_section_evidence_digest=C1ScientificDigest_v3(m);s.comparisons{k}=c;
        end
        for k=1:numel(s.records)
            h=s.records{k};h.saved_full_closure_digest=C1ScientificDigest_v3(h.saved_full_closure);
            h=rmfield(h,{'saved_full_closure','metadata_binding'});s.records{k}=h;
            s.native_index_scalar_observations{k}=rmfield(s.native_index_scalar_observations{k},'scope');
        end
        if ~isempty(fieldnames(s.pair_match))
            m=s.pair_match;s.pair_match=pick(m,sectionKeys);s.full_pair_match_evidence_digest=C1ScientificDigest_v3(m);
        end
        v.(name)=s;
    end
    for k=1:numel(v.fork_geometry.targets)
        m=v.fork_geometry.targets{k}.target_matching_section;
        v.fork_geometry.targets{k}.target_matching_section=pick(m,sectionKeys);
        v.fork_geometry.targets{k}.full_target_section_evidence_digest=C1ScientificDigest_v3(m);
    end
    v=rmfield(v,{'read2_scope','selector_scope','geometry_scope','clock_scope'});
    v.projection_scope='All selected/target state14, p/q, T, stride14, NativeID/owner, policy/chart/cohort tokens, raw comparison deltas/tolerances/strict flags and PAL numbers remain. Repeated section policy/evidence, saved closure reports/duplicate metadata and historical7271 tuple payload are omitted with digests. Complete facts exist only in memory/the function return if it actually returns, not a durable full-facts audit.';
    v.comparison_scope='Finite saved NEW-control rawfull13/E<=1e-8, period/fullstride componentwise1e-10/maxscale and exactp/q/completepolicy/markedsection/ONEeventtoken. No original-v2 trajectory, admission, connection or global absence inference.';
    v.native_scalar_scope='Native-vs-index E/meanU mismatches are literal; no reranking or fallback. Excluded/unselected records remain UNASSESSED.';
    v.full_facts_durably_retained_claimed=false;
end
function p=partial(f,e,normal)
    p=struct('schema','C1-owned-PK-existing-P1-controls-observation-partial-v1','completed',false,'normal_summary_call_returned',normal, ...
        'own_process_exit_observed',false,'source_sha256',f.source_reference.sha256,'target_audit_load_calls_returned',f.target_audit_load_calls_returned, ...
        'index_calls_returned',f.index_calls_returned,'selected_load_calls_returned',f.selected_load_calls_returned, ...
        'target_native_read2_verified',f.target_native_read2_verified,'index_read2_verified',f.index_read2_verified, ...
        'selected_compact_read2_verified',f.selected_compact_read2_verified,'source_posthash',f.source_posthash, ...
        'root_calls',f.root_calls,'map_evaluate_calls',f.map_evaluate_calls,'fine_calls',f.fine_calls, ...
        'journal_mutated',f.journal_mutated,'round_mutated',f.round_mutated,'raw_mutated',f.raw_mutated, ...
        'failure_header',failureHeader(e),'full_facts_omitted',true,'omission_scope','No target/owned arrays, full causes or any previous normal summary are repeated.');
end

function [witness,policyReport,signature]=storedSection(target,p,l)
    assert(strcmp(p.native_id,target.native_id)&&isequaln(p.initial_state,target.state)&&isfield(p,'section_chart')&&isfield(p,'section_event_signature'), ...
        'C1PKCol1:TargetSection','Use only the exact already-read2 admitted NEW P1 control chart/token.');
    configuration=target.policy_configuration;assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isstruct(configuration.settings)&&isscalar(configuration.settings)&&isfield(configuration.settings,'Name'), ...
        'C1PKCol1:Policy','Use actual complete historical BL1 policy settings.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));[~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration)&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKCol1:PolicyRoundtrip','Fresh constructor must roundtrip exact recorded BL1 policy.');
    witness=struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',target.mode,'section_chart',p.section_chart,'return_multiplicity',1);
    policyReport=struct('seed',struct('return_policy',policy));signature=p.section_event_signature;assert(strlength(string(signature))>0,'C1PKCol1:EventToken','The saved single target event token must be nonempty.');check(l);
end

function targetShapes(t,w)
    assert(isa(t.state,'double')&&isreal(t.state)&&isequal(size(t.state),[14 1])&&all(isfinite(t.state)) ...
        &&islogical(t.mode)&&isequal(size(t.mode),[4 1])&&isa(t.parameter,'double')&&isreal(t.parameter)&&isequal(size(t.parameter),[10 1])&&all(isfinite(t.parameter)) ...
        &&isa(t.full_stride,'double')&&isreal(t.full_stride)&&isequal(size(t.full_stride),[14 1])&&all(isfinite(t.full_stride)) ...
        &&isa(t.period,'double')&&isreal(t.period)&&isscalar(t.period)&&isfinite(t.period)&&t.period>0 ...
        &&isa(t.native_energy,'double')&&isreal(t.native_energy)&&isscalar(t.native_energy)&&isfinite(t.native_energy), ...
        'C1PKCol1:TargetShapes','Require exact finite native state14/mode4/p10/stride14 and scalar period/energy.');
    assert(ischar(t.native_id)&&isrow(t.native_id)&&~isempty(regexp(t.native_id,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1PKCol1:NativeID','Require the source-defined native record identity.');assert(isstruct(w.section_chart)&&isscalar(w.section_chart),'C1PKCol1:TargetChart','Retain actual marked chart.');
end

function h=pointHeader(o,r,m,ix,index)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&ix.index==index&&isstruct(m)&&isscalar(m)&&strcmp(ix.component_identity,m.component_identity), ...
        'C1PKCol1:PointBinding','Retain current native record index, owner and public metadata binding.');
    assert(isa(o.stride_displacement,'double')&&isequal(size(o.stride_displacement),[14 1])&&all(isfinite(o.stride_displacement)), ...
        'C1PKCol1:Stride','A complete finite native14 stride is required.');
    g=r.classification;[~,pe]=RecordedReturnPolicy_v3(r);
    h=struct('index',index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o), ...
        'state',o.initial_state,'mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full_stride',o.stride_displacement, ...
        'native_energy',QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter), ...
        'acceptance_gates',pick(r.acceptance_gates,{'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'}), ...
        'classification',pick(g,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'}), ...
        'policy_configuration',pe.configuration,'section_chart',o.section_chart, ...
        'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature, ...
        'event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'saved_full_closure',r.full_closure,'metadata_binding',struct('component_identity',m.component_identity,'index',ix.index,'order',ix.order));
end

function out=pick(s,keys)
    out=struct();for k=1:numel(keys),assert(isfield(s,keys{k}),'C1PKCol1:RequiredField','A required saved field is missing.');out.(keys{k})=s.(keys{k});end
end

function refs=references(refs)
    assert(iscell(refs)&&size(refs,2)==1,'C1PKCol1:ReferenceCells','Supply a column cell of explicit current protected references.');
    for k=1:numel(refs),refs{k}=checked(refs{k});end
end

function syntaxReferences(refs)
    assert(iscell(refs)&&isvector(refs),'C1PKCol1:HistoricalRefs','Retain literal reference cell shape without rehashing historical source paths.');
    for k=1:numel(refs),r=refs{k};exactFields(r,{'file','sha256'});assert(ischar(r.file)&&isrow(r.file)&&java.io.File(r.file).isAbsolute(),'C1PKCol1:ReferencePath','Require an absolute historical source path.');validSHA(r.sha256);end
end

function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end

function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end

function out=compareTarget(O,r,t,witness,policyReport,signature)
    section=MatchingReturnSection_v3(O,witness,{r,policyReport});[~,pe]=RecordedReturnPolicy_v3(r);
    delta=O.initial_state(2:14)-t.state(2:14);scale=max([ones(13,1),abs(O.initial_state(2:14)),abs(t.state(2:14))],[],2);
    dt=O.period-t.period;dq=O.stride_displacement-t.full_stride;qs=max([ones(size(dq)),abs(O.stride_displacement),abs(t.full_stride)],[],2);
    dE=QuadrupedEnergy_v3.evaluate(O.initial_state,O.initial_mode,O.parameter)-t.native_energy;
    out=struct('raw_full13_delta',delta,'raw_full13_scaled_inf',norm(delta./scale,inf),'native_energy_delta',dE,'absolute_energy_tolerance',1e-8, ...
        'period_delta',dt,'period_tolerance',1e-10*max([1,abs(O.period),abs(t.period)]),'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
        'exact_p_q',isequaln(O.parameter,t.parameter)&&isequaln(O.initial_mode,t.mode),'exact_complete_policy',pe.complete&&isequaln(pe.configuration,t.policy_configuration), ...
        'matching_section',section,'same_section_event_signature',strcmp(string(O.section_relative_event_signature),string(signature)), ...
        'conditions_met',false,'scope','Finite comparison to the independently qualified NEW P1 control control only: rawfull13/E1e-8, period/fullstride componentwise1e-10/maxscale, exactp/q/completepolicy/markedsection/events. No OriginalP1 stride/meanU, source membership, alias, union or endpoint theorem is inferred.');
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dE)<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
        &&out.exact_p_q&&out.exact_complete_policy&&section.compatible&&out.same_section_event_signature;
end

function strictPK(o,r,p)
keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};for k=1:numel(keys),assert(isequal(r.acceptance_gates.(keys{k}),true),'C1Pilot:AllNine','Require every literal original native admission gate.');end;g=r.classification;status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true)&&strcmp(g.contract_version,'quadruped-gait-v3.5')&&strcmp(g.validated_gait_type,'PK')&&isequal(g.flight_count_certain,true)&&g.flight_count==1&&isequal(g.canonical_label_qualified,true)&&isequaln(o.parameter(:),p(:)),'C1Pilot:PK','Require current qualified certain PK1 and unchanged parameters.');[policy,e]=RecordedReturnPolicy_v3(r);assert(e.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1Pilot:Policy','Require the actual complete BL1 section.');
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1P1Fixed:Resolver','Current source resolution differs from its guard.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1P1Fixed:Changed','A bound file changed.');end,end

function r=reference(f),assert(isfile(f),'C1P1Fixed:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function out=exceptionData(e),causes=cell(size(e.cause));for k=1:numel(causes),causes{k}=exceptionData(e.cause{k});end;out=struct('identifier',e.identifier,'message',e.message,'stack',e.stack,'causes',{causes});end

function value=member(s,k,f),value=f;if isstruct(s)&&isscalar(s)&&isfield(s,k),value=s.(k);end,end

function x=clockPair(),x=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function x=shift(x,s),x.utc=x.utc+s;x.mono=x.mono+s*1e9;end

function x=left(l),x=min(l.utc-posixtime(datetime('now','TimeZone','UTC')),(l.mono-double(java.lang.System.nanoTime))/1e9);end

function check(l),assert(left(l)>0,'C1P1Fixed:Clock','The original local/science whole-call clock expired.');end

function x=canonical(x),x=char(java.io.File(char(x)).getCanonicalPath());end

function x=formatUTC(s),x=char(datetime(s,'ConvertFrom','posixtime','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function x=stamp(),x=formatUTC(posixtime(datetime('now','TimeZone','UTC')));end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

function quiet(ledger,raw,roundFile)
    cp=[ledger(1:end-4),'_active_checkpoint.mat'];paths={cp,[cp,'.pending.mat'],[ledger,'.pending.mat'],[roundFile,'.pending.mat'],[roundFile(1:end-4),'.pending.mat'],[roundFile(1:end-4),'.json.pending.json']};
    for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1:Pending','Reconcile existing owned checkpoint/stage before this stored-only observation.');end
    d=dir(fileparts(raw));d=d(~ismember({d.name},{'.','..'}));[~,n,e]=fileparts(raw);
    assert(numel(d)==1&&~d.isdir&&strcmp(d.name,[n e]),'C1PKCol1:RawDirectory','The primary raw directory must retain exactly its one current file, with no unknown stage.');
end

function h=failureHeader(e)
    id=e.identifier;message=e.message;stack=e.stack;
    h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'identifier_truncated',numel(id)>128, ...
        'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256, ...
        'stack_frame_count',numel(stack),'first_stack_frame',struct(),'stack_detail_omitted',numel(stack)>1,'cause_count',numel(e.cause));
    if ~isempty(stack)
        a=stack(1);h.first_stack_frame=struct('file_prefix',a.file(1:min(numel(a.file),128)),'file_char_count',numel(a.file),'file_truncated',numel(a.file)>128, ...
            'name_prefix',a.name(1:min(numel(a.name),96)),'name_char_count',numel(a.name),'name_truncated',numel(a.name)>96,'line',a.line);
    end
end
