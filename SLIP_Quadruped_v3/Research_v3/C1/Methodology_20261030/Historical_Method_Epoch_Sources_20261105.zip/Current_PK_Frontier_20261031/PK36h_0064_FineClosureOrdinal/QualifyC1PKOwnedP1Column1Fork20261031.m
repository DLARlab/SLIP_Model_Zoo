function audit=QualifyC1PKOwnedP1Column1Fork20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,options)
% Two fresh original-state fines of the ACTUAL closed0062 owned fork point3.
% No Root, correction, admission, graph/status/journal/raw/Round mutation.
    entry=clockPair();validSHA(expectedLedgerSHA);validSHA(expectedRawSHA);validSHA(expectedRoundSHA);
    exactFields(options,{'ForkReference','CheckpointReference','ForkClosureReference','TargetInputReference','TargetQualificationReference', ...
        'TargetRawReference','HistoricalClosureReference','OutputAuditFile','ProtectedReferences'});o=options;
    for key={'ForkReference','CheckpointReference','ForkClosureReference','TargetInputReference','TargetQualificationReference','TargetRawReference','HistoricalClosureReference'},o.(key{1})=checked(o.(key{1}));end
    assert(strcmp(o.ForkReference.sha256,'8b2ca0f81f4ce331cd61928c4aa1f900abbbbf1f70334fb89bd65f1ab58ea90c') ...
        &&strcmp(o.CheckpointReference.sha256,'f25ba354f9522074c59711d38d47dfcb05c921b9dea7b71554418a8d9a7477f6') ...
        &&strcmp(o.ForkClosureReference.sha256,'7a8b51d37b4c38e8377ae37708842e2ef871938f0c25530deb71dc30bf81321a') ...
        &&strcmp(o.TargetInputReference.sha256,'7271b42befe2b47426ded73031d0833dc1a4dd1f34a17498515e2c5cc72c0652') ...
        &&strcmp(o.TargetQualificationReference.sha256,'210a54d6282acd0abe57ecf6fce491c52d78329a01adfe72b136554fba683a28') ...
        &&strcmp(o.TargetRawReference.sha256,'cf8a0a2af207955a8ba8cc228548e4012f3310e5e1d5dc5e7a297c917ee5a87a') ...
        &&strcmp(o.HistoricalClosureReference.sha256,'9d0dd2ee6f174934fb35d1193b8e4f9de1e58df4db45d13b6ae60963862b0759'), ...
        'C1PKCol1Fine:Authorities','Use exact actual0062 fork/checkpoint/closure and earned NEWcol1 authorities.');
    root=canonical(fileparts(which('C1RunBudget_v3')));budget=C1RunBudget_v3();finish=shift(entry,1800);work=shift(finish,-180);
    assert(finish.utc<budget.research_deadline_unix_seconds&&finish.mono<budget.research_deadline_monotonic_ns,'C1PKCol1Fine:WholeFit','Full1800 including180 reserve must fit BOTH unchanged SCIENCE clocks.');
    ledger=canonical(fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat'));raw=canonical(fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'));
    roundFile=canonical(fullfile(root,'Audits','PK36h_20261031_Round.mat'));o.OutputAuditFile=canonical(o.OutputAuditFile);stage=[o.OutputAuditFile,'.pending.mat'];
    assert(strcmp(fileparts(o.OutputAuditFile),canonical(fullfile(root,'Audits')))&&endsWith(o.OutputAuditFile,'.mat'),'C1PKCol1Fine:Output','Use one fresh Audits MAT.');
    live={struct('file',ledger,'sha256',expectedLedgerSHA);struct('file',raw,'sha256',expectedRawSHA);struct('file',roundFile,'sha256',expectedRoundSHA)};
    refs=[live;{o.ForkReference;o.CheckpointReference;o.ForkClosureReference;o.TargetInputReference;o.TargetQualificationReference;o.TargetRawReference;o.HistoricalClosureReference};references(o.ProtectedReferences)];
    self=reference(which(mfilename));code=codeRefs(self,o.ProtectedReferences);for k=1:numel(refs),assert(~ismember(refs{k}.file,{o.OutputAuditFile,stage}),'C1PKCol1Fine:Disjoint','Outputs cannot replace any consumed authority.');end
    fresh({o.OutputAuditFile,stage});audit=struct('schema','C1-owned-PK-NEWcol1-fork-two-fine-qualification-v1','source_reference',self,'options',o, ...
        'budget',budget,'wrapper_entry',entry,'wrapper_finish',finish,'wrapper_work',work,'original_profile_seconds',300,'profile_steps',[.0005 .00025], ...
        'current_references',{live},'actual_method_references',{code},'fork_reference',o.ForkReference,'checkpoint_reference',o.CheckpointReference, ...
        'actual_fork_closed_verified',false,'fork_native_read2_verified',false,'target_native_read2_verified',false,'owned_edge_verified',false, ...
        'stored_checkpoint_persistence_completion_confirmed',false,'actual_return_persistence_completion_confirmed',false,'records',{{}},'comparison',struct(), ...
        'historical_qualification',struct(),'historical_contract_observations',{{}},'historical_common_contract_equality','UNASSESSED', ...
        'historical_common_contract_claimed',false,'all_four_target_cohorts_established',false,'all_four_target_cohorts_scope','UNASSESSED; one target section-relative token is established, not absence of other cohorts.', ...
        'fresh_service_contract',struct(),'fresh_service_contract_digest','','fines',{{}},'fine_calls_attempted',0,'fine_calls_returned',0,'all_two_owned_fines_passed',false, ...
        'finite_NEWcol1_comparison_with_independent_fines',false,'root_calls',0,'admissions',0,'physical_edges_added',0,'source_posthash',false, ...
        'stage_save_returned',false,'stage_read2_verified',false,'publication_returned',false,'installed_read2_verified',false,'completed',false,'failure',struct(),'own_process_exit_observed',false, ...
        'journal_mutated',false,'raw_mutated',false,'Round_mutated',false,'graph_mutated',false,'frontier_status_changed',false,'endpoint_claimed',false,'global_completion_claimed',false, ...
        'status','prepared','scope','Two new unchanged-state owned-fork profiles plus separate historical NEWcol1 qualification. No Root, common-contract/four-cohort upgrade, physical primary merge, original-v2 trajectory identity, endpoint or branch completion.');
    normalReturned=false;
    try
        guard(work);assert(isfile([ledger,'.writer.lock']),'C1PKCol1Fine:Lock','Require stable existing ledger lock.');lock=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
        [w,q]=forkClosure(o.ForkClosureReference,root,work);audit.actual_fork_closed_verified=true;audit.actual_fork_closure=w;validateForkMarker(q,o,raw,expectedRawSHA,budget);
        [target,historical,targetPoint]=storedTarget(o,work,@nativeTwice);audit.target_native_read2_verified=true;
        audit.historical_target_source_code_digest=C1ScientificDigest_v3(historical.target_source_code_historical_syntax_only);audit.historical_qualification=rmfield(historical,'target_source_code_historical_syntax_only');
        [witness,policyReport,signature]=storedSection(target,targetPoint,work);targetShapes(target,witness);
        s=nativeTwice(o.CheckpointReference.file,'summary','fork_checkpoint',work);h=runHeader(s);assert(isequal(s.persistence_completion_confirmed,false),'C1PKCol1Fine:Checkpoint','Retain original provisional checkpoint false.');
        h.persistence_completion_confirmed=true;assert(isequaln(jsondecode(jsonencode(h)),q.Run_observation),'C1PKCol1Fine:ReturnedSummary','Only persistence flag is normalized for comparison; external actual returned true remains separate.');
        assert(s.new_points==1&&s.new_edges==1&&s.initial_output_count==2&&s.final_output_count==3&&numel(s.attempts)==1 ...
            &&isempty(fieldnames(s.pending_admission))&&isempty(fieldnames(s.failure))&&isempty(s.isolated_native_admissions)&&isequaln(s.original_budget,budget), ...
            'C1PKCol1Fine:NativeRun','Require one clean actual owned append; pending/late/recovery is not repaired.');
        a=s.attempts{1};assert(a.attempt==1&&a.source_point==2&&a.all_nine&&a.timely&&a.edge_committed&&a.storage_attempted&&a.storage_timely ...
            &&~a.isolated_committed&&isempty(a.isolated_storage_timely)&&strcmp(a.algorithm,'root-newton')&&strcmp(s.corrector_initializer,'base') ...
            &&strcmp(a.corrector_initialization.method,'base')&&~a.previous_jacobian_reuse.requested,'C1PKCol1Fine:ActualAttempt','Bind original timely all9/captured owned row.');
        checkCapture(a.capture);audit.actual_owned_attempt=pick(a,{'attempt','source_point','step','algorithm','derivative_method','relative_step','timely','all_nine','edge_committed','storage_attempted','storage_timely','capture','corrector_initialization'});
        audit.stored_checkpoint_persistence_completion_confirmed=s.persistence_completion_confirmed;audit.actual_return_persistence_completion_confirmed=q.Run_observation.persistence_completion_confirmed;
        fprintf('C1_PK_COL1_FINE_BEFORE_FORK_INDEX\n');ix=BranchSolutionFile_v3.index(o.ForkReference.file);fprintf('C1_PK_COL1_FINE_AFTER_FORK_INDEX_RETURN\n');guard(work);
        assert(numel(ix.points)==3&&numel(ix.edges)==1&&ix.edges{1}.from==2&&ix.edges{1}.to==3&&strcmp(ix.edges{1}.component_identity,q.component_identity),'C1PKCol1Fine:Edge','Preserve exact local2->3 and its fresh owner.');
        for pass=1:2
            fprintf('C1_PK_COL1_FINE_BEFORE_FORK_LOAD %d\n',pass);[O,R,M]=BranchSolutionFile_v3.loadSolutions(o.ForkReference.file,(1:3).');fprintf('C1_PK_COL1_FINE_AFTER_FORK_LOAD_RETURN %d\n',pass);guard(work);
            headers=cell(3,1);for k=1:3,strictPK(O{k},R{k},[10;10;20;20;1;1;0;0;2;.5]);headers{k}=pointHeader(O{k},R{k},M{k},ix.points{k},k);end
            assert(isequaln(jsondecode(jsonencode(headers)),q.fork_records),'C1PKCol1Fine:ForkIdentity','Native read must equal actual0062 public compact record proof.');
            if pass==1,first=headers;clear O R M;else,assertPublicEqual(headers,first,0);end
        end
        assert(strcmp(OrbitContentIdentity_v3(O{3}),'native-orbit-record:sha256:c7e2df3b9f19bf20f255cddf2a744d222bddd260eb09de47c723a05ca3b4652e') ...
            &&M{3}.edge_enabled&&M{3}.edge_from==2&&M{3}.provenance.source_point==2&&M{3}.provenance.attempt==1 ...
            &&isequaln(M{3}.provenance.capture,a.capture)&&isequaln(M{3}.provenance.corrector_initialization,a.corrector_initialization), ...
            'C1PKCol1Fine:OwnedProvenance','Use actual0062 point3 and unchanged attempt/capture/base initialization.');
        imported=asCells(q.imported_source_headers);for k=1:2
            assert(~M{k}.edge_enabled&&~isfield(M{k},'edge_from')&&strcmp(M{k}.provenance.kind,'imported nonedge initial pair')&&M{k}.provenance.source_index==463+k ...
                &&strcmp(headers{k}.native_id,imported{k}.native_id),'C1PKCol1Fine:Seeds','Both actual imported native identities remain NONEDGE.');
        end
        audit.records=headers;audit.fork_native_read2_verified=true;audit.owned_edge_verified=true;audit.actual_owned_edge=ix.edges{1};
        audit.comparison=compareTarget(O{3},R{3},target,witness,policyReport,signature);assert(audit.comparison.conditions_met,'C1PKCol1Fine:CheapComparison','Only the actual cheap-match success authorizes owned fines.');
        [service,integration,serviceAudit]=forkFineService(R{3},work);serviceAudit.called_method_references=code;audit.fresh_service_contract=serviceAudit;audit.fresh_service_contract_digest=C1ScientificDigest_v3(serviceAudit);
        old=nativeTwice(o.TargetQualificationReference.file,'audit','historical_contract210a',work);audit.historical_contract_observations=historicalContracts(old.rows{1},old,o,serviceAudit,work,@nativeTwice);
        seed=struct('state',O{3}.initial_state,'mode',O{3}.initial_mode,'parameter',O{3}.parameter,'return_policy',service.correction_return_policy,'occurrence',1);
        audit.original_owned_seed=struct('state',seed.state,'mode',seed.mode,'parameter',seed.parameter,'native_id',headers{3}.native_id);
        assert(left(work)>2*300+60,'C1PKCol1Fine:BothSlots','Both full original300 slots plus post-call allowance must fit before any fine.');steps=[.0005 .00025];
        for level=1:2
            guard(work);assert(left(work)>300,'C1PKCol1Fine:FineFit','Never shorten an original300 profile.');limit=fineLimit(300,budget,struct('u',work.utc,'m',work.mono));
            audit.fine_calls_attempted=audit.fine_calls_attempted+1;fprintf('C1_PK_COL1_FINE_BEFORE_PROFILE %d\n',level);
            [fine,ev,g]=C1PlainFineQualificationReplay_v3(seed,steps(level),service,limit);audit.fine_calls_returned=audit.fine_calls_returned+1;fprintf('C1_PK_COL1_FINE_AFTER_PROFILE_RETURN %d\n',level);
            timely=posixtime(datetime('now','TimeZone','UTC'))<limit.deadline_unix_seconds&&double(java.lang.System.nanoTime)<limit.deadline_monotonic_ns;
            item=fineObservation(fine,ev,g,seed,O{3},1,level,integration,steps(level),timely,serviceAudit.BL_policy_configuration);
            item.side_name='owned_P1_column1_fork';item.seed_native_id=headers{3}.native_id;item.evidence=ev;item.evidence_retention='Full unchanged plain fb35 trajectory, energies, stance residuals, counts, phase and timings retained in this native audit.';
            item.actual_service_contract_digest=audit.fresh_service_contract_digest;plain(item);audit.fines{end+1,1}=item;clear fine ev g item
            guard(work);
        end
        audit.all_two_owned_fines_passed=numel(audit.fines)==2&&all(cellfun(@(x)x.all_declared_conditions_met,audit.fines));
        audit.finite_NEWcol1_comparison_with_independent_fines=audit.comparison.conditions_met&&audit.all_two_owned_fines_passed;
        audit.status='two_original_owned_profiles_observed';if audit.finite_NEWcol1_comparison_with_independent_fines,audit.status='finite_NEWcol1_record_match_and_independent_fines';end
        clear O R M s a old ix seed integration service target targetPoint witness policyReport headers first q imported
        guard(work);audit.source_posthash=true;audit.completed=true;publishAudit();small=stdoutView(audit);encoded=jsonencode(small);assert(numel(unicode2native(encoded,'UTF-8'))<=50000,'C1PKCol1Fine:Stdout','Bound normal projection to50000 UTF8 bytes.');
        fprintf('C1_PK_COL1_FORK_FINE_ACTUAL_RETURN %s\n',encoded);normalReturned=true;guard(finish);
    catch problem
        audit.completed=false;audit.failure=exceptionData(problem);audit.status='partial_or_refused';
        try,if ~audit.publication_returned,publishAudit();end;catch persistenceProblem,audit.audit_persistence_failure=struct('identifier',persistenceProblem.identifier,'message',persistenceProblem.message);end
        p=struct('schema','C1-owned-PK-NEWcol1-fork-fine-partial-v1','completed',false,'normal_summary_returned',normalReturned,'fine_calls_attempted',audit.fine_calls_attempted,'fine_calls_returned',audit.fine_calls_returned, ...
            'stage_save_returned',audit.stage_save_returned,'stage_read2_verified',audit.stage_read2_verified,'publication_returned',audit.publication_returned,'installed_read2_verified',audit.installed_read2_verified, ...
            'failure_header',failureHeader(problem),'full_facts_omitted',true,'own_process_exit_observed',false);encoded=jsonencode(p);assert(numel(unicode2native(encoded,'UTF-8'))<=7000,'C1PKCol1Fine:Partial','Bound partial projection.');fprintf('C1_PK_COL1_FORK_FINE_PARTIAL %s\n',encoded);rethrow(problem)
    end
    function out=nativeTwice(file,key,label,limit)
        check(limit);fprintf('C1_PK_COL1_FINE_BEFORE_NATIVE_LOAD1 %s\n',label);x=load(file,'-mat',key);fprintf('C1_PK_COL1_FINE_AFTER_NATIVE_LOAD1_RETURN %s\n',label);check(limit);
        fprintf('C1_PK_COL1_FINE_BEFORE_NATIVE_LOAD2 %s\n',label);y=load(file,'-mat',key);fprintf('C1_PK_COL1_FINE_AFTER_NATIVE_LOAD2_RETURN %s\n',label);check(limit);assertPublicEqual(x.(key),y.(key),0);out=x.(key);
    end
    function guard(limit)
        check(limit);quiet(ledger,raw,roundFile);for p={o.ForkReference.file,o.CheckpointReference.file},assert(~isfile([p{1},'.pending.mat']),'C1PKCol1Fine:Pending','Resolve fork/checkpoint stages first.');end
        verify(refs);verifyCode(code);assert(isequaln(C1RunBudget_v3(),budget),'C1PKCol1Fine:Budget','Keep unchanged original grant.');check(limit);
    end
    function publishAudit()
        check(finish);fresh({o.OutputAuditFile,stage});audit.headroom_observation=struct();v=whos('audit');audit.headroom_observation=struct('native_logical_bytes_before_stage',v.bytes,'refusal_threshold',1750000000,'format_capacity_guaranteed',false);
        assert(v.bytes<1750000000,'C1PKCol1Fine:Headroom','Refuse before native-v7 stage at conservative observed logical-byte threshold.');
        savedAudit=audit;save(stage,'audit','-v7');audit.stage_save_returned=true;fprintf('C1_PK_COL1_FINE_AFTER_AUDIT_STAGE_SAVE_RETURN\n');
        x=load(stage,'audit');y=load(stage,'audit');assertPublicEqual(x.audit,savedAudit,0);assertPublicEqual(y.audit,savedAudit,0);audit.stage_read2_verified=true;check(finish);
        fresh({o.OutputAuditFile});[ok,message]=movefile(stage,o.OutputAuditFile);assert(ok,'C1PKCol1Fine:Publish','%s',message);audit.publication_returned=true;fprintf('C1_PK_COL1_FINE_AFTER_AUDIT_PUBLICATION_RETURN\n');
        x=load(o.OutputAuditFile,'audit');y=load(o.OutputAuditFile,'audit');assertPublicEqual(x.audit,savedAudit,0);assertPublicEqual(y.audit,savedAudit,0);audit.installed_read2_verified=true;
        audit.audit_reference=reference(o.OutputAuditFile);audit.publication_scope='Stored MAT records prepublication flags false; actual returned flags/immutable external closure qualify publication separately.';check(finish);
    end
end

function validateForkMarker(q,o,raw,rawSHA,budget)
    assert(strcmp(q.schema,'C1-owned-PK-NEWcol1-single-fork-v1')&&q.completed&&q.source_posthash&&isempty(fieldnames(q.failure)) ...
        &&strcmp(q.source_reference.sha256,'b42cba485ab8a90d8dabaac4e924c684e63d487ec38db788a84ce709a740a603') ...
        &&q.Run_calls_attempted==1&&q.Run_calls_returned==1&&q.Run_return_observed_before_outer_work&&q.Run_actual_limits_within_original_work ...
        &&q.owned_fork_commit_verified&&q.fork_native_read2_verified&&q.cloned_seed_native_ids_preserved&&q.cheap_NEWcol1_comparison.conditions_met ...
        &&~q.native_pending_present&&isequal(q.own_process_exit_observed,false)&&isequaln(q.budget,jsondecode(jsonencode(budget))),'C1PKCol1Fine:ActualFork','Require actual clean0062 owned fork and cheap match, not a prepared intent.');
    assert(strcmp(canonical(q.output_file),o.ForkReference.file)&&strcmp(canonical(q.checkpoint_file),o.CheckpointReference.file) ...
        &&isequaln(q.fork_output_reference,o.ForkReference)&&q.Run_observation.persistence_completion_confirmed,'C1PKCol1Fine:ForkRefs','Actual returned proof must bind fork bytes/checkpoint and genuine return flag.');
    rr=asCells(q.expected_current_references);at=find(cellfun(@(x)strcmp(canonical(x.file),raw),rr));assert(isscalar(at)&&strcmp(rr{at}.sha256,rawSHA),'C1PKCol1Fine:PrimaryUnchanged','Current raw must still equal0062 source; historical ledger/Round refs stay historical.');
    ro=q.Run_options;assert(ro.MaxAttempts==1&&ro.MaxAccepted==1&&strcmp(ro.CorrectorInitializer,'base')&&~ro.InPlace&&strcmp(ro.ComponentIdentity,q.component_identity) ...
        &&strcmp(ro.Algorithm,'root-newton')&&strcmp(ro.DerivativeMethod,'valid-sided')&&ro.FiniteDifferenceSteps==1e-8&&~ro.ReusePreviousJacobian ...
        &&ro.InitialDerivativeIndex==1&&ro.TrialSeconds==240&&ro.SaveMarginSeconds==120&&ro.MinimumApexHeightRatio==.5,'C1PKCol1Fine:Options','Preserve actual standalone1/1 original policy.');
end
function checkCapture(c)
    assert(c.radius==.02&&c.full13_scaled_inf<c.radius&&c.achieved_state_progress>1e-8&&c.distinct_state_distance>1e-8&&abs(c.PAL_error)<=1e-8&&c.section_compatible,'C1PKCol1Fine:Capture','Actual unrelaxed capture/progress/separation must pass.');
end
function [service,integration,c]=forkFineService(report,work)
    [integration,reconstruction]=freshIntegration(report.replay_integration,struct('u',work.utc,'m',work.mono));[~,pe]=RecordedReturnPolicy_v3(report);
    assert(pe.complete&&strcmp(pe.configuration.source_class,'BLMarkedApexReturnPolicy_v3'),'C1PKCol1Fine:Policy','Use actual complete fork BL policy.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(pe.configuration.settings,'Name'));[~,freshPolicy]=RecordedReturnPolicy_v3(struct('correction_return_policy',policy));
    assert(freshPolicy.complete&&isequaln(freshPolicy.configuration,pe.configuration),'C1PKCol1Fine:PolicyRoundtrip','Fresh policy must preserve every actual setting.');
    service=struct('replay_integration',integration,'correction_return_policy',policy,'options',pick(report.options,{'MaxReturnTime','MaxCycleEvents','MaxSectionCrossings'}), ...
        'acceptance',report.acceptance,'classification',report.classification,'event_signature',report.event_signature);
    c=struct('schema','C1-P1-owned-fork-fine-service-contract-v1','numeric_integration',reconstruction.all_other_integration_settings,'numeric_ODE_options',reconstruction.all_other_ODE_options, ...
        'solver','ode45','BL_policy_configuration',freshPolicy.configuration,'map_limits',service.options,'acceptance',service.acceptance, ...
        'classification_contract',pick(service.classification,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count','flight_count_certain'}), ...
        'event_signature',service.event_signature,'profile_steps',[.0005 .00025],'original_profile_cap_seconds',300,'runtime_reconstruction',reconstruction, ...
        'historical_service_equality_claimed',false,'saved_closure_executed',false);
    assert(isequal(sort(fieldnames(service.options)),sort({'MaxReturnTime';'MaxCycleEvents';'MaxSectionCrossings'})),'C1PKCol1Fine:Limits','Use only actual numeric map limits.');plain(c);
end
function rows=historicalContracts(row,parent,o,current,limit,read2)
    rows=cell(2,1);
    for k=1:2
        f=row.fines{k};x=struct('profile',k,'historical_passed',f.passed,'historical_returned',f.observation.returned,'historical_return_timely',f.observation.return_timely, ...
            'historical_storage_timely',f.raw_custody.storage_timely,'historical_readback_timely',f.raw_custody.readback_timely, ...
            'assessment','UNASSESSED','available_fine_fields',{fieldnames(f)},'raw_variable_available',false,'raw_payload_loaded',false,'contract',struct(),'comparison',struct(), ...
            'source_tuple_historical_only',true,'historical_callbacks_executed',false,'failure',struct());
        try
            if isfield(f,'fine'),x.recorded_numeric_fine=pick(f.fine,{'MaxStep','RelTol','AbsTol','return_map_limits','actual_policy_configuration','service_event_signature'});plain(x.recorded_numeric_fine);end
            if isfield(parent,'source_code')
                syntaxReferences(parent.source_code);x.historical_method_references=parent.source_code;
                methods=current.called_method_references;mc=struct('current_method_count',numel(methods),'matched_count',0,'changed_count',0,'missing_or_ambiguous_count',0,'rows',{cell(numel(methods),1)}, ...
                    'scope','Retained historical/current method strings only; no obsolete path is rehashed and no source compatibility bridge is inferred.');
                oldNames=cell(size(parent.source_code));for j=1:numel(oldNames),[~,oldNames{j}]=fileparts(parent.source_code{j}.file);end
                for j=1:numel(methods)
                    r=methods{j};[~,name]=fileparts(r.file);hit=find(strcmp(oldNames,name));z=struct('method_name',name,'current_reference',r,'historical_match_count',numel(hit),'same_path',false,'same_sha256',false);
                    if isscalar(hit)
                        h=parent.source_code{hit};z.historical_reference=h;z.same_path=strcmp(h.file,r.file);z.same_sha256=strcmp(h.sha256,r.sha256);
                        if z.same_path&&z.same_sha256,mc.matched_count=mc.matched_count+1;else,mc.changed_count=mc.changed_count+1;end
                    else,mc.missing_or_ambiguous_count=mc.missing_or_ambiguous_count+1;end
                    mc.rows{j}=z;
                end
                x.method_comparison=mc;
            end
            if isfield(f.raw_custody,'variable')&&ischar(f.raw_custody.variable)&&isrow(f.raw_custody.variable)&&isvarname(f.raw_custody.variable)
                key=f.raw_custody.variable;x.raw_variable_available=true;x.raw_variable=key;payload=read2(o.TargetRawReference.file,key,'historical_fine_contract_raw',limit);x.raw_payload_loaded=true;x.raw_payload_fieldnames=fieldnames(payload);
                if isstruct(payload)&&isscalar(payload)&&isfield(payload,'service')
                    [c,complete]=observedHistoricalService(payload.service);x.contract=c;
                    if complete
                        keys={'numeric_integration','numeric_ODE_options','solver','BL_policy_configuration','map_limits','acceptance','classification_contract','event_signature'};
                        equal=true;x.comparison=struct();for j=1:numel(keys),key=keys{j};same=isequaln(c.(key),current.(key));x.comparison.(key)=same;equal=equal&&same;end
                        x.numeric_service_keys_equal=equal;x.assessment='OBSERVED_KEYS_ONLY_SOURCE_BRIDGE_UNASSESSED';
                    end
                end
                clear payload
            end
        catch problem,x.failure=struct('identifier',problem.identifier,'message',problem.message);x.assessment='UNASSESSED';end
        rows{k}=x;check(limit);
    end
end
function [c,complete]=observedHistoricalService(s)
    c=struct();complete=false;
    if ~isstruct(s)||~isscalar(s)||~isequal(sort(fieldnames(s)),sort({'replay_integration';'correction_return_policy';'options';'acceptance';'classification';'event_signature'})),return;end
    in=s.replay_integration;defaults=HybridSimulator_v3();defaults=defaults.Options;
    if ~isstruct(in)||~isscalar(in)||~isequal(sort(fieldnames(in)),sort(fieldnames(defaults)))||~isstruct(in.ODEOptions)||~isscalar(in.ODEOptions)||~isfield(in.ODEOptions,'OutputFcn'),return;end
    solver=callbackHeader(in.ODESolver);output=callbackHeader(in.ODEOptions.OutputFcn);numeric=rmfield(in,{'ODESolver','ODEOptions'});nested=rmfield(in.ODEOptions,'OutputFcn');plain(numeric);plain(nested);
    [~,pe]=RecordedReturnPolicy_v3(s);if ~pe.complete,return;end
    c=struct('numeric_integration',numeric,'numeric_ODE_options',nested,'solver_header',solver,'output_callback_header',output,'solver','UNASSESSED', ...
        'BL_policy_configuration',pe.configuration,'map_limits',s.options,'acceptance',s.acceptance,'classification_contract',pick(s.classification,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count','flight_count_certain'}), ...
        'event_signature',s.event_signature,'saved_callback_executed',false);
    if isfield(solver,'signature_text')&&strcmp(regexprep(solver.signature_text,'\s',''),'ode45'),c.solver='ode45';else,return;end
    plain(c);complete=true;
end
function small=stdoutView(a)
    small=pick(a,{'schema','source_reference','fork_reference','checkpoint_reference','actual_fork_closed_verified','fork_native_read2_verified','owned_edge_verified','stored_checkpoint_persistence_completion_confirmed', ...
        'actual_return_persistence_completion_confirmed','comparison','fresh_service_contract_digest','historical_common_contract_equality','historical_common_contract_claimed','all_four_target_cohorts_established','all_four_target_cohorts_scope', ...
        'fine_calls_attempted','fine_calls_returned','all_two_owned_fines_passed','finite_NEWcol1_comparison_with_independent_fines','root_calls','admissions','physical_edges_added','source_posthash','stage_save_returned','stage_read2_verified', ...
        'publication_returned','installed_read2_verified','audit_reference','completed','failure','status','own_process_exit_observed','scope'});
    small.fines=cell(size(a.fines));for k=1:numel(a.fines),x=a.fines{k};y=pick(x,{'side_name','original_profile_level','timely_observed','initial_trajectory_row_exact','qualified_PK1_primitive','saved_period_scaled_error','saved_full14_stride_scaled_error', ...
        'map_complete','classifier_complete','sample_count','completed_scalar_sample_count','all_declared_conditions_met','seed_native_id','actual_service_contract_digest'});y.fine=pick(x.fine,{'MaxStep','passed','status','budget_refusal','failure','full13_norm','period','maximum_energy_variation','maximum_stance_constraint'});small.fines{k}=y;end
    small.historical_contract_observations=cell(size(a.historical_contract_observations));
    for k=1:numel(a.historical_contract_observations)
        x=a.historical_contract_observations{k};y=pick(x,{'profile','assessment','raw_variable_available','raw_payload_loaded','numeric_service_keys_equal'});
        if isfield(x,'method_comparison'),y.method_comparison_counts=pick(x.method_comparison,{'current_method_count','matched_count','changed_count','missing_or_ambiguous_count'});end
        y.failure_header=struct();if ~isempty(fieldnames(x.failure))
            id=x.failure.identifier;message=x.failure.message;y.failure_header=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id), ...
                'identifier_truncated',numel(id)>128,'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256);
        end
        small.historical_contract_observations{k}=y;
    end
    small.evidence_scope='Complete plain fine/evidence/classification/settings retained in native audit; stdout intentionally omits dense evidence. Two new owned profiles are separate from the historical target2; no common-contract claim.';
end
function code=codeRefs(self,protected)
    protected=references(protected);names={'C1RunBudget_v3','BranchSolutionFile_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3','OrbitContentIdentity_v3','HybridOrbit_v3','Trajectory_v3','C1ScientificDigest_v3','RoundSHA256_v3', ...
        'QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3','QuadrupedAdmissibility_v3','ContinuousDynamics_v3','BLMarkedApexReturnPolicy_v3','ReturnPolicyBase_v3','PoincareMap_v3','PoincareSection_v3','HybridSimulator_v3', ...
        'Quadrupedal_Dynamics_v3','PeriodicOrbitResidual_v3','GuardFunctions_v3','EventDetector_v3','ResetMap_v3','ModeTransition_v3','PrimitiveCycleCheck_v3','HybridCycleData_v3','GaitIdentification_v3','GaitSemanticTable_v3','CircularPhase_v3','SectionModeResolver_v3','HybridSystemBase_v3','C1PlainFineQualificationReplay_v3'};
    code={self};for k=1:numel(names),r=reference(which(names{k}));assert(any(cellfun(@(x)strcmp(x.file,r.file)&&strcmp(x.sha256,r.sha256),protected)),'C1PKCol1Fine:CallerPin','Every actual method must be caller-pinned.');code{end+1,1}=r;end
    r=reference(which('C1PlainFineQualificationReplay_v3'));assert(strcmp(r.sha256,'fb35df74f7de49f65f72040e3577080d8a55e96de039646528bdf3991a2c41df'),'C1PKCol1Fine:FinePin','Keep the original fullrow fine adapter.');
    d=reference(which('C1ScientificDigest_v3'));assert(strcmp(d.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'),'C1PKCol1Fine:DigestPin','Keep the reviewed typed digest.');
end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1Fine:Fresh','Preserve an existing/uncertain output or stage.');end,end
function [w,q]=forkClosure(r,root,limit)
    check(limit);w=jsondecode(fileread(r.file));exactFields(w,{'schema','invocation_id','argv_utf8_sha256','exec_session_id','child_pid','actual_child_exit_code','actual_process_exit_observed','tool_prefix_reference','process_prefix_reference'});
    assert(strcmp(w.schema,'C1-ordinary-initializer-evidence-closure-v1')&&strcmp(w.invocation_id,'PK36h20261031-0062-one-owned-P1-column1-PAL-fork')&&w.exec_session_id==80917&&w.child_pid==8352 ...
        &&isequal(w.actual_child_exit_code,0)&&isequal(w.actual_process_exit_observed,true)&&strcmp(w.argv_utf8_sha256,'3a4182adbaa01f6ea2888b24f142293bb808392ddc533ea2aef049c60c02cd6d'),'C1PKFork:Closure','Keep exact actual0062 session/pid/argv/exit authority.');
    exactFields(w.tool_prefix_reference,{'file','prefix_bytes','prefix_sha256'});exactFields(w.process_prefix_reference,{'file','prefix_bytes','prefix_sha256'});
    assert(strcmp(w.tool_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Tool_Observations.jsonl'))&&strcmp(w.process_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Process_Observations.jsonl')),'C1PKFork:PrefixPaths','Use known bounded immutable observation prefixes.');
    tool=prefixRows(w.tool_prefix_reference);process=prefixRows(w.process_prefix_reference);rows=tool(cellfun(@(x)isfield(x,'invocation_id')&&strcmp(x.invocation_id,w.invocation_id),tool));assert(numel(rows)==6,'C1PKFork:ToolRows','Require the actual six ordered records.');
    terminal=0;starts={};exits={};summaries={};summaryOrdinal=[];summaryLine=[];exitOrdinal=[];exitLine=[];
    for k=1:6
        a=rows{k};assert(strcmp(a.schema,'C1-native-exec-tool-observation-v1')&&a.tool_record_ordinal==k,'C1PKFork:ToolOrder','Actual ordinals must be1..6.');
        if k<6,assert(isfield(a,'session_id')&&a.session_id==w.exec_session_id,'C1PKFork:ToolSession','Running envelope sessions must match.');else,assert(~isfield(a,'session_id'),'C1PKFork:TerminalAbsence','Actual terminal6 alone lacks envelope session.');end
        if isfield(a.record,'session_id'),assert(a.record.session_id==w.exec_session_id,'C1PKFork:RecordSession','Every present record session must match.');end
        if isfield(a.record,'exit_code'),assert(k==6&&a.record.exit_code==0,'C1PKFork:Terminal','Require sole actual terminal0.');terminal=terminal+1;end
        if isfield(a.record,'output')
            lines=strsplit(a.record.output,newline);
            for n=1:numel(lines)
                line=lines{n};
                if startsWith(line,'C1_NATIVE_PROCESS_STARTED '),starts{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_STARTED ')+1:end));end
                if startsWith(line,'C1_NATIVE_PROCESS_EXIT '),exits{end+1}=jsondecode(line(numel('C1_NATIVE_PROCESS_EXIT ')+1:end));exitOrdinal(end+1)=k;exitLine(end+1)=n;end
                if startsWith(line,'C1_PK_COL1_OWNED_FORK_ACTUAL_RETURN '),summaries{end+1}=jsondecode(line(numel('C1_PK_COL1_OWNED_FORK_ACTUAL_RETURN ')+1:end));summaryOrdinal(end+1)=k;summaryLine(end+1)=n;end
            end
        end
    end
    selected=process(cellfun(@(x)isfield(x,'invocation_id')&&strcmp(x.invocation_id,w.invocation_id),process));spec={};observed={};dispatch={};
    for k=1:numel(selected),a=selected{k};if strcmp(a.schema,'C1-native-launch-specification-v1'),spec{end+1}=a;elseif strcmp(a.schema,'C1-native-process-observation-v1'),observed{end+1}=a;elseif strcmp(a.schema,'C1-native-reviewed-specification-dispatch-confirmation-v1'),dispatch{end+1}=a;end,end
    assert(terminal==1&&numel(starts)==1&&numel(exits)==1&&numel(summaries)==1&&isequal(summaryOrdinal,6)&&isequal(exitOrdinal,6)&&summaryLine<exitLine&&numel(spec)==1&&numel(observed)==1&&numel(dispatch)==1,'C1PKFork:UniqueClosure','Require unique START/EXIT/summary/spec/dispatch/process joins.');
    a=starts{1};b=observed{1};sp=spec{1};di=dispatch{1};assert(strcmp(a.invocation_id,w.invocation_id)&&a.child_pid==w.child_pid&&strcmp(a.argv_utf8_sha256,w.argv_utf8_sha256) ...
        &&strcmp(b.invocation_id,w.invocation_id)&&b.child_pid==w.child_pid&&isequal(b.actual_child_exit_code,0)&&isequal(b.actual_process_exit_observed,true)&&strcmp(b.argv_utf8_sha256,w.argv_utf8_sha256) ...
        &&strcmp(sp.argv_utf8_sha256,w.argv_utf8_sha256)&&strcmp(di.argv_utf8_sha256,w.argv_utf8_sha256),'C1PKFork:ProcessJoin','Join actual child and reviewed dispatch to the same argv.');
    assert(isequaln(exits{1},b)&&strcmp(sp.expected_execution_tool_options.sandbox_permissions,'require_escalated')&&isequaln(rows{1}.actual_execution_tool_options,sp.expected_execution_tool_options) ...
        &&isequaln(di.expected_execution_tool_options,sp.expected_execution_tool_options)&&isequaln(b.expected_execution_tool_options,sp.expected_execution_tool_options),'C1PKFork:Profile','Preserve actual execution profile and EXIT observation.');
    q=summaries{1};check(limit);
end

function [t,h,p]=storedTarget(o,l,read2)
    a=read2(o.TargetInputReference.file,'audit','intake7271',l);assert(isstruct(a)&&isscalar(a)&&isequal(a.completed,true)&&isequal(a.source_posthash,true)&&isempty(fieldnames(a.failure)), ...
        'C1PKCol1:TargetIntake','Require the exact complete independently qualified target intake.');
    assert(iscell(a.targets)&&~isempty(a.targets),'C1PKCol1:Targets','Use the original first target without a numerical selector.');t=a.targets{1};
    assert(strcmp(t.role,'P1_col1_NEW_qualified_control')&&isequaln(t.authority.audit_reference,o.TargetQualificationReference)&&isequaln(t.authority.final_raw_reference,o.TargetRawReference), ...
        'C1PKCol1:TargetAuthority','Use exact named NEWcol1 authority; not UNIT or OriginalP1 raw.');
    old=read2(o.TargetQualificationReference.file,'audit','qualified210a',l);assert(iscell(old.rows)&&~isempty(old.rows),'C1PKCol1:TargetRow','Retain original first delegated row.');r=old.rows{1};
    assert(isequal(old.completed,false)&&isequal(old.source_posthash,false)&&r.original.original_column==1 ...
        &&isequal(r.qualified_new_control,true)&&isequal(r.finite_original_column_conditions_met,true)&&isequal(r.native_all_nine,true)&&isequal(r.initial_anchor_control.passed,true) ...
        &&numel(r.fines)==2&&all(cellfun(@(f)isequal(f.passed,true)&&isequal(f.observation.returned,true)&&isequal(f.observation.return_timely,true)&&isequal(f.raw_custody.storage_timely,true)&&isequal(f.raw_custody.readback_timely,true),r.fines)), ...
        'C1PKCol1:LocalQualification','Historical global false and actual local qualified NEWcol1/two original timely fines must remain distinct.');
    p=r.new_point;assert(strcmp(t.native_id,p.native_id)&&isequaln(t.state,p.initial_state)&&isequaln(t.mode,p.mode)&&isequaln(t.parameter,p.parameter)&&isequaln(t.period,p.period)&&isequaln(t.full_stride,p.full_stride), ...
        'C1PKCol1:TargetValues','Bind every identity-bearing plain target value to the independently admitted row.');
    syntaxReferences(a.source_code);c=jsondecode(fileread(o.HistoricalClosureReference.file));
    assert(isstruct(c)&&isscalar(c)&&isstruct(c.child)&&c.child.child_exit_code==0&&c.child.child_pid==7809&&c.metadata.completed&&c.metadata.source_posthash ...
        &&isempty(fieldnames(c.metadata.failure))&&~c.metadata.native_pending_present&&c.metadata.native_all_nine&&c.metadata.qualified_nonedge_control&&c.metadata.finite_NEW_col1_conditions_met ...
        &&islogical(c.metadata.endpoint_fines_passed)&&numel(c.metadata.endpoint_fines_passed)==2&&all(c.metadata.endpoint_fines_passed(:)) ...
        &&islogical(c.metadata.control_fines_passed)&&numel(c.metadata.control_fines_passed)==2&&all(c.metadata.control_fines_passed(:)) ...
        &&c.metadata.prepared_requests==5&&c.metadata.actual_requests_invoked==5&&c.metadata.actual_requests_returned==5, ...
        'C1PKCol1:HistoricalClosure','Retain actual original Short01 process closure and finite comparison scope.');
    h=struct('target_source_code_historical_syntax_only',{a.source_code},'original_column',r.original.original_column, ...
        'historical_parent_completed',old.completed,'historical_parent_source_posthash',old.source_posthash, ...
        'local_native_all_nine',r.native_all_nine,'qualified_new_control',r.qualified_new_control, ...
        'finite_original_column_conditions_met',r.finite_original_column_conditions_met,'initial_anchor_passed',r.initial_anchor_control.passed, ...
        'original_solved_control_fine_passed',cellfun(@(x)x.passed,r.fines),'raw_target_deserialized',false, ...
        'short01_child_exit_code',c.child.child_exit_code,'short01_child_pid',c.child.child_pid, ...
        'short01_finite_NEW_col1_conditions_met',c.metadata.finite_NEW_col1_conditions_met, ...
        'scope','Historical pinned NEWcontrol qualification and actual closed endpoint-control comparison; never original legacy-state admission, old global flag upgrade or present process exit.');check(l);
end

function [witness,policyReport,signature]=storedSection(target,p,l)
    assert(strcmp(p.native_id,target.native_id)&&isequaln(p.initial_state,target.state)&&isfield(p,'section_chart')&&isfield(p,'section_event_signature'), ...
        'C1PKCol1:TargetSection','Use only the exact already-read2 admitted NEWcol1 chart/token.');
    configuration=target.policy_configuration;assert(strcmp(configuration.source_class,'BLMarkedApexReturnPolicy_v3')&&isstruct(configuration.settings)&&isscalar(configuration.settings)&&isfield(configuration.settings,'Name'), ...
        'C1PKCol1:Policy','Use actual complete historical BL1 policy settings.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));[~,pe]=RecordedReturnPolicy_v3(struct('seed',struct('return_policy',policy)));
    assert(pe.complete&&isequaln(pe.configuration,configuration)&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKCol1:PolicyRoundtrip','Fresh constructor must roundtrip exact recorded BL1 policy.');
    witness=struct('return_policy_name',policy.Name,'return_policy',class(policy),'initial_mode',target.mode,'section_chart',p.section_chart,'return_multiplicity',1);
    policyReport=struct('seed',struct('return_policy',policy));signature=p.section_event_signature;assert(strlength(string(signature))>0,'C1PKCol1:EventToken','The saved single target event token must be nonempty.');check(l);
end

function targetShapes(t,w)
    assert(isa(t.state,'double')&&isreal(t.state)&&isequal(size(t.state),[14 1])&&all(isfinite(t.state)) ...
        &&islogical(t.mode)&&isequal(size(t.mode),[4 1])&&isa(t.parameter,'double')&&isreal(t.parameter)&&isequal(size(t.parameter),[10 1])&&all(isfinite(t.parameter)) ...
        &&isa(t.full_stride,'double')&&isreal(t.full_stride)&&isequal(size(t.full_stride),[14 1])&&all(isfinite(t.full_stride)) ...
        &&isa(t.period,'double')&&isreal(t.period)&&isscalar(t.period)&&isfinite(t.period)&&t.period>0 ...
        &&isa(t.native_energy,'double')&&isreal(t.native_energy)&&isscalar(t.native_energy)&&isfinite(t.native_energy), ...
        'C1PKCol1:TargetShapes','Require exact finite native state14/mode4/p10/stride14 and scalar period/energy.');
    assert(ischar(t.native_id)&&isrow(t.native_id)&&~isempty(regexp(t.native_id,'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),'C1PKCol1:NativeID','Require the source-defined native record identity.');assert(isstruct(w.section_chart)&&isscalar(w.section_chart),'C1PKCol1:TargetChart','Retain actual marked chart.');
end

function h=pointHeader(o,r,m,ix,index)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&ix.index==index&&isstruct(m)&&isscalar(m)&&strcmp(ix.component_identity,m.component_identity), ...
        'C1PKCol1:PointBinding','Retain current native record index, owner and public metadata binding.');
    assert(isa(o.stride_displacement,'double')&&isequal(size(o.stride_displacement),[14 1])&&all(isfinite(o.stride_displacement)), ...
        'C1PKCol1:Stride','A complete finite native14 stride is required.');
    g=r.classification;[~,pe]=RecordedReturnPolicy_v3(r);
    h=struct('index',index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o), ...
        'state',o.initial_state,'mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full_stride',o.stride_displacement, ...
        'native_energy',QuadrupedEnergy_v3.evaluate(o.initial_state,o.initial_mode,o.parameter), ...
        'acceptance_gates',pick(r.acceptance_gates,{'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'}), ...
        'classification',pick(g,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count_certain','flight_count'}), ...
        'policy_configuration',pe.configuration,'section_chart',o.section_chart, ...
        'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature, ...
        'event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'saved_full_closure',r.full_closure,'metadata_binding',struct('component_identity',m.component_identity,'index',ix.index,'order',ix.order));
end

function h=runHeader(s)
    h=pickPresent(s,{'protocol','output_file','configuration','new_points','new_edges','initial_output_count','final_output_count','status','persistence_completion_confirmed','derivative_method', ...
        'integration_profile','corrector_initializer','run_limit','work_limit','current_pair','next_step','next_derivative_index','apex_height_policy','completed_utc'});
    h.failure_header=storedFailureHeader(s.failure);h.pending_admission_present=~isempty(fieldnames(s.pending_admission));h.pending_stage=member(s.pending_admission,'stage','');h.isolated_native_admissions=s.isolated_native_admissions;
    h.attempts=cell(size(s.attempts));for k=1:numel(s.attempts),h.attempts{k}=pickPresent(s.attempts{k},{'attempt','source_point','step','derivative_method','relative_step','algorithm','status','all_nine','timely','capture', ...
            'edge_committed','storage_attempted','storage_timely','isolated_committed','isolated_storage_timely','corrector_initialization','apex_height_policy'});end
    h.checkpoint_fact_scope='Actual returned persistence flag remains literal; saved checkpoint intentionally retains provisional false. Full failure/native-pending payload remains in Run checkpoint, not duplicated here.';
end

function h=storedFailureHeader(e)
    h=struct();if isempty(fieldnames(e)),return;end
    id=member(e,'identifier','');msg=member(e,'message','');h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'message_prefix',msg(1:min(numel(msg),256)),'message_char_count',numel(msg), ...
        'stack_frame_count',numel(member(e,'stack',[])),'full_failure_preserved_in_Run_checkpoint',true);
end

function out=pickPresent(s,keys),out=struct();for k=1:numel(keys),if isfield(s,keys{k}),out.(keys{k})=s.(keys{k});end,end,end

function out=compareTarget(O,r,t,witness,policyReport,signature)
    section=MatchingReturnSection_v3(O,witness,{r,policyReport});[~,pe]=RecordedReturnPolicy_v3(r);
    delta=O.initial_state(2:14)-t.state(2:14);scale=max([ones(13,1),abs(O.initial_state(2:14)),abs(t.state(2:14))],[],2);
    dt=O.period-t.period;dq=O.stride_displacement-t.full_stride;qs=max([ones(size(dq)),abs(O.stride_displacement),abs(t.full_stride)],[],2);
    dE=QuadrupedEnergy_v3.evaluate(O.initial_state,O.initial_mode,O.parameter)-t.native_energy;
    out=struct('raw_full13_delta',delta,'raw_full13_scaled_inf',norm(delta./scale,inf),'native_energy_delta',dE,'absolute_energy_tolerance',1e-8, ...
        'period_delta',dt,'period_tolerance',1e-10*max([1,abs(O.period),abs(t.period)]),'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
        'exact_p_q',isequaln(O.parameter,t.parameter)&&isequaln(O.initial_mode,t.mode),'exact_complete_policy',pe.complete&&isequaln(pe.configuration,t.policy_configuration), ...
        'matching_section',section,'same_section_event_signature',strcmp(string(O.section_relative_event_signature),string(signature)), ...
        'conditions_met',false,'scope','Finite comparison to the independently qualified NEWcol1 control only: rawfull13/E1e-8, period/fullstride componentwise1e-10/maxscale, exactp/q/completepolicy/markedsection/events. No OriginalP1 stride/meanU, source membership, alias, union or endpoint theorem is inferred.');
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dE)<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
        &&out.exact_p_q&&out.exact_complete_policy&&section.compatible&&out.same_section_event_signature;
end

function strictPK(o,r,p)
keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};for k=1:numel(keys),assert(isequal(r.acceptance_gates.(keys{k}),true),'C1Pilot:AllNine','Require every literal original native admission gate.');end;g=r.classification;status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true)&&strcmp(g.contract_version,'quadruped-gait-v3.5')&&strcmp(g.validated_gait_type,'PK')&&isequal(g.flight_count_certain,true)&&g.flight_count==1&&isequal(g.canonical_label_qualified,true)&&isequaln(o.parameter(:),p(:)),'C1Pilot:PK','Require current qualified certain PK1 and unchanged parameters.');[policy,e]=RecordedReturnPolicy_v3(r);assert(e.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1Pilot:Policy','Require the actual complete BL1 section.');
end

function refs=references(refs)
    assert(iscell(refs)&&size(refs,2)==1,'C1PKCol1:ReferenceCells','Supply a column cell of explicit current protected references.');
    for k=1:numel(refs),refs{k}=checked(refs{k});end
end

function syntaxReferences(refs)
    assert(iscell(refs)&&isvector(refs),'C1PKCol1:HistoricalRefs','Retain literal reference cell shape without rehashing historical source paths.');
    for k=1:numel(refs),r=refs{k};exactFields(r,{'file','sha256'});assert(ischar(r.file)&&isrow(r.file)&&java.io.File(r.file).isAbsolute(),'C1PKCol1:ReferencePath','Require an absolute historical source path.');validSHA(r.sha256);end
end

function exactFields(s,names)
    assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(names(:))),'C1PKCol1:Fields','The declared interface field set must match exactly.');
end

function validSHA(s)
    assert(ischar(s)&&isrow(s)&&~isempty(regexp(s,'^[0-9a-f]{64}$','once')),'C1PKCol1:SHA','Require one lowercase64 SHA256.');
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1P1Fixed:Resolver','Current source resolution differs from its guard.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1P1Fixed:Changed','A bound file changed.');end,end

function r=reference(f),assert(isfile(f),'C1P1Fixed:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function out=exceptionData(e),causes=cell(size(e.cause));for k=1:numel(causes),causes{k}=exceptionData(e.cause{k});end;out=struct('identifier',e.identifier,'message',e.message,'stack',e.stack,'causes',{causes});end

function value=member(s,k,f),value=f;if isstruct(s)&&isscalar(s)&&isfield(s,k),value=s.(k);end,end

function x=clockPair(),x=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function x=shift(x,s),x.utc=x.utc+s;x.mono=x.mono+s*1e9;end

function check(l),assert(left(l)>0,'C1P1Fixed:Clock','The original local/science whole-call clock expired.');end

function x=canonical(x),x=char(java.io.File(char(x)).getCanonicalPath());end

function x=formatUTC(s),x=char(datetime(s,'ConvertFrom','posixtime','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function x=stamp(),x=formatUTC(posixtime(datetime('now','TimeZone','UTC')));end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

function quiet(ledger,raw,roundFile)
    cp=[ledger(1:end-4),'_active_checkpoint.mat'];paths={cp,[cp,'.pending.mat'],[ledger,'.pending.mat'],[roundFile,'.pending.mat'],[roundFile(1:end-4),'.pending.mat'],[roundFile(1:end-4),'.json.pending.json']};
    for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKCol1:Pending','Reconcile existing owned checkpoint/stage before this stored-only observation.');end
    d=dir(fileparts(raw));d=d(~ismember({d.name},{'.','..'}));[~,n,e]=fileparts(raw);
    assert(numel(d)==1&&~d.isdir&&strcmp(d.name,[n e]),'C1PKCol1:RawDirectory','The primary raw directory must retain exactly its one current file, with no unknown stage.');
end

function h=failureHeader(e)
    id=e.identifier;message=e.message;stack=e.stack;
    h=struct('identifier_prefix',id(1:min(numel(id),128)),'identifier_char_count',numel(id),'identifier_truncated',numel(id)>128, ...
        'message_prefix',message(1:min(numel(message),256)),'message_char_count',numel(message),'message_truncated',numel(message)>256, ...
        'stack_frame_count',numel(stack),'first_stack_frame',struct(),'stack_detail_omitted',numel(stack)>1,'cause_count',numel(e.cause));
    if ~isempty(stack)
        a=stack(1);h.first_stack_frame=struct('file_prefix',a.file(1:min(numel(a.file),128)),'file_char_count',numel(a.file),'file_truncated',numel(a.file)>128, ...
            'name_prefix',a.name(1:min(numel(a.name),96)),'name_char_count',numel(a.name),'name_truncated',numel(a.name)>96,'line',a.line);
    end
end

function rows=prefixRows(r)
    validSHA(r.prefix_sha256);assert(ischar(r.file)&&isrow(r.file)&&isa(r.prefix_bytes,'double')&&isscalar(r.prefix_bytes)&&isfinite(r.prefix_bytes)&&r.prefix_bytes>0&&r.prefix_bytes<=16*1024*1024&&r.prefix_bytes==fix(r.prefix_bytes),'C1PKFork:Prefix','Require an exact bounded prefix.');
    f=fopen(r.file,'rb');assert(f>=0,'C1PKFork:PrefixOpen','Cannot read prefix.');closer=onCleanup(@()fclose(f));b=fread(f,r.prefix_bytes,'*uint8');assert(numel(b)==r.prefix_bytes&&b(end)==10,'C1PKFork:PrefixLength','Exact prefix must end atLF.');clear closer
    d=java.security.MessageDigest.getInstance('SHA-256');d.update(b);h=lower(reshape(dec2hex(typecast(d.digest(),'uint8'),2).',1,[]));assert(strcmp(h,r.prefix_sha256),'C1PKFork:PrefixSHA','Immutable prefix changed.');
    lines=strsplit(native2unicode(b.','UTF-8'),newline);lines(end)=[];rows=cellfun(@jsondecode,lines,'UniformOutput',false);
end

function c=asCells(x),if iscell(x),c=x(:);elseif isstruct(x),c=num2cell(x(:));else,error('C1PKFork:Cells','Require actual JSON object-array rows.');end,end

function x=left(l),if isfield(l,'utc'),u=l.utc;m=l.mono;else,u=l.u;m=l.m;end;x=min(u-posixtime(datetime('now','TimeZone','UTC')),(m-double(java.lang.System.nanoTime))/1e9);end

function out=fineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration)
    returnedPolicy=isfield(fine,'actual_policy');if returnedPolicy,[~,used]=RecordedReturnPolicy_v3(struct('correction_return_policy',fine.actual_policy));assert(used.complete&&isequaln(used.configuration,configuration),'C1PKE0:FinePolicy','Fresh fine changed the actual return policy.');fine.actual_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',configuration.source_class,'settings',configuration.settings);end
    firstExact=ev.sample_count>0&&isequaln(ev.trajectory.state(1,:).',seed.state)&&isequaln(logical(ev.trajectory.mode(1,:).'),logical(seed.mode));periodError=NaN;strideError=NaN;if isfield(fine,'period'),periodError=abs(fine.period-original.period)/max([1,abs(fine.period),abs(original.period)]);end;if isfield(fine,'stride_displacement'),sx=max([ones(14,1),abs(fine.stride_displacement(:)),abs(original.stride_displacement(:))],[],2);strideError=norm((fine.stride_displacement(:)-original.stride_displacement(:))./sx,Inf);end
    names={'candidate','original_unit'};out=struct('side',side,'side_name',names{side},'original_profile_level',level,'fine',fine,'actual_full_classification',g,'timely_observed',timely,'initial_trajectory_row_exact',firstExact,'qualified_PK1_primitive',qualified(g),'saved_period_scaled_error',periodError,'saved_full14_stride_scaled_error',strideError,'map_complete',ev.map_complete,'classifier_complete',ev.classifier_complete,'sample_count',ev.sample_count,'completed_scalar_sample_count',ev.completed_scalar_sample_count,'failure_phase',ev.phase_at_failure,'timings',ev.timings,'effective_ODE_profile',effectiveProfile(integration,step),'all_declared_conditions_met',fine.passed&&timely&&qualified(g)&&firstExact&&returnedPolicy&&ev.map_complete&&ev.classifier_complete&&ev.completed_scalar_sample_count==ev.sample_count&&periodError<=1e-8&&strideError<=1e-8);
end

function [live,audit]=freshIntegration(saved,limit)
    native=HybridSimulator_v3();defaults=native.Options;assert(isstruct(saved)&&isscalar(saved)&&isequal(sort(fieldnames(saved)),sort(fieldnames(defaults))),'C1PKFine:IntegrationSchema','Native verification refused; original observations are retained.');
    assert(isempty(saved.StopCondition)&&isstruct(saved.ODEOptions)&&isscalar(saved.ODEOptions),'C1PKFine:Callback','Native verification refused; original observations are retained.');
    odeDefaults=odeset();assert(isequal(sort(fieldnames(saved.ODEOptions)),sort(fieldnames(odeDefaults)))&&isempty(saved.ODEOptions.Events),'C1PKFine:ODEFields','Native verification refused; original observations are retained.');
    solverHeader=knownCallback(saved.ODESolver,'ode45');outputHeader=knownCallback(saved.ODEOptions.OutputFcn,'@(~,~,~)double(left(limit)<=0)');
    numeric=saved;numeric=rmfield(numeric,{'ODESolver','ODEOptions'});plain(numeric);odeNumeric=rmfield(saved.ODEOptions,'OutputFcn');plain(odeNumeric);
    live=saved;live.ODESolver=@ode45;live.ODEOptions.OutputFcn=@(~,~,~)budgetOutput(limit);rebuilt=HybridSimulator_v3(live);assert(isequaln(rebuilt.Options,live),'C1PKFine:IntegrationRoundtrip','Native verification refused; original observations are retained.');
    audit=struct('original_solver_header',solverHeader,'original_output_callback_header',outputHeader,'all_other_integration_settings',numeric,'all_other_ODE_options',odeNumeric, ...
        'replacements',{{'Known native ode45 descriptor to fresh @ode45','Known old deadline OutputFcn to fresh immutable-limit callback'}},'saved_closure_executed',false);
end

function out=knownCallback(value,expected)
    header=callbackHeader(value);detail=jsonencode(header);
    if isa(value,'function_handle')&&isscalar(value),signature=func2str(value);out=struct('class',class(value),'signature',signature);
    else
        assert(isstruct(value)&&isscalar(value)&&isequal(sort(fieldnames(value)),sort({'diagnostic_kind';'signature';'requires_runtime_reconstruction'}))&&strcmp(value.diagnostic_kind,'runtime-function-descriptor')&&isequal(value.requires_runtime_reconstruction,true),'C1PKFine:CallbackDescriptor','Unsupported saved callback header: %s',detail);signature=value.signature;out=value;
    end
    assert(ischar(signature)&&isrow(signature)&&strcmp(regexprep(signature,'\s',''),expected),'C1PKFine:CallbackSignature','Unexpected saved callback; no callback is rehydrated. Header: %s',detail);
end

function header=callbackHeader(value)
    header=struct('class',class(value),'size',size(value),'total_field_count',0,'fieldnames_first_32',{{}});
    if isstruct(value)
        names=fieldnames(value);header.total_field_count=numel(names);header.fieldnames_first_32=names(1:min(32,numel(names)));
        if isscalar(value)&&isfield(value,'signature')
            literal=value.signature;header.signature_class=class(literal);header.signature_size=size(literal);
            if ischar(literal)&&isrow(literal)&&numel(literal)<=1024,header.signature_text=literal;end
        end
    elseif isa(value,'function_handle')&&isscalar(value)
        literal=func2str(value);header.signature_length=numel(literal);header.signature_text=literal(1:min(1024,numel(literal)));
    end
end

function p=effectiveProfile(integration,step)
    nested=integration.ODEOptions;rel=1e-12;absolute=1e-14;if ~isempty(nested.RelTol),rel=min(rel,nested.RelTol);end;if ~isempty(nested.AbsTol),absolute=min(absolute,nested.AbsTol);end
    h=step;if ~isempty(nested.MaxStep),h=min(h,nested.MaxStep);end;p=struct('declared_RelTol',1e-12,'declared_AbsTol',1e-14,'declared_MaxStep',step,'effective_RelTol',max(rel,100*eps),'configured_minimum_RelTol',rel,'effective_AbsTol',absolute,'effective_MaxStep',h,'ode45_RelTol_floor',100*eps,'nested_options_preserved',true);
end

function yes=qualified(g)
    yes=isstruct(g)&&isscalar(g)&&strcmp(member(g,'contract_version',''),'quadruped-gait-v3.5')&&strcmp(member(g,'validated_gait_type',''),'PK')&&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1)&&isfield(g,'primitive')&&strcmp(member(g.primitive,'status',''),'primitive_within_checked_bound');
end

function value=fineLimit(seconds,budget,work)
    u=utc()+seconds;m=nano()+seconds*1e9;assert(u<work.u&&m<work.m,'C1PKFine:FineFit','Native verification refused; original observations are retained.');value=struct('deadline_unix_seconds',u,'deadline_utc',utcString(u),'deadline_monotonic_ns',m,'campaign_deadline_utc',utcString(budget.research_deadline_unix_seconds),'campaign_deadline_monotonic_ns',budget.research_deadline_monotonic_ns);
end

function s=utcString(u),v=datetime(u,'ConvertFrom','posixtime','TimeZone','UTC');v.Format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";s=char(v);end

function status=budgetOutput(limit),check(limit);status=0;end

function plain(v)
    if isstruct(v),for k=1:numel(v),for f=fieldnames(v).',plain(v(k).(f{1}));end,end
    elseif iscell(v),for k=1:numel(v),plain(v{k});end
    else,assert(isnumeric(v)||islogical(v)||ischar(v)||isstring(v),'C1PKFine:NonportableSetting','Unknown runtime setting is not silently replaced.');end
end

function assertPublicEqual(a,b,depth)
    assert(depth<=128&&strcmp(class(a),class(b))&&isequal(size(a),size(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    if isnumeric(a)||islogical(a),assert(issparse(a)==issparse(b)&&isreal(a)==isreal(b)&&isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif ischar(a)||isstring(a),assert(isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif iscell(a),for k=1:numel(a),assertPublicEqual(a{k},b{k},depth+1);end
    elseif isstruct(a),keys=fieldnames(a);assert(isequal(keys,fieldnames(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    elseif ismember(class(a),{'HybridOrbit_v3','Trajectory_v3'}),keys=sort(properties(a));assert(isequal(keys,sort(properties(b))),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    else,assert(isequaln(a,b),'C1PKPrimary:NativeRead2','Native verification refused; original observations are retained.');end
end

function out=pick(s,keys),out=struct();for k=1:numel(keys),if isstruct(s)&&isscalar(s)&&isfield(s,keys{k}),out.(keys{k})=s.(keys{k});end,end,end

function u=utc(),u=posixtime(datetime('now','TimeZone','UTC'));end
function m=nano(),m=double(java.lang.System.nanoTime);end
