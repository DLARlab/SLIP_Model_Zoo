function facts=InspectC1PKOwnedTargetGeometry20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,actualQualifierClosure)
% Current target geometry only: two fresh original fine traces and two locals.
% Predecessor is public native read2/saved-trace comparison only, never refined.
    root=fileparts(which('C1RunBudget_v3'));budget=C1RunBudget_v3();startClock=struct('u',utc(),'m',nano());
    finish=struct('u',min(startClock.u+1800,budget.research_deadline_unix_seconds),'m',min(startClock.m+1800e9,budget.research_deadline_monotonic_ns));
    assert(left(finish)>1799,'C1PKGeometry:WholeFit','The full1800 cap must fit BOTH unchanged science clocks.');work=struct('u',finish.u-180,'m',finish.m-180e9);
    ledger=fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat');core=fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat');
    output=fullfile(root,'Audits','PK36h_20261031_Round.mat');json=[output(1:end-4) '.json'];catalogue=fullfile(root,'Results','PK36h_Endpoint_Experimental_Controls_20261031.mat');
    paths={[ledger '.pending.mat'],[ledger(1:end-4) '_active_checkpoint.mat'],[ledger(1:end-4) '_active_checkpoint.mat.pending.mat'],[core '.pending.mat'],[output '.pending.mat'],[json '.pending.json'],[catalogue '.pending.mat'],[catalogue '.pending-admission.mat']};
    digest=reference(which('C1ScientificDigest_v3'));assert(strcmp(digest.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3') ...
        &&strcmp(digest.file,fullfile(fileparts(fileparts(root)),'4_Solution_Management','C1ScientificDigest_v3.m')),'C1PKGeometry:Digest','Pin the public typed digest before consuming any proof.');
    self=reference([mfilename('fullpath') '.m']);before=reference(ledger);source=reference(core);roundBefore=reference(output);jsonBefore=reference(json);
    assert(all(cellfun(@validSHA,{expectedLedgerSHA,expectedRawSHA,expectedRoundSHA}))&&strcmp(before.sha256,expectedLedgerSHA) ...
        &&strcmp(source.sha256,expectedRawSHA)&&strcmp(roundBefore.sha256,expectedRoundSHA),'C1PKGeometry:Current','Require the actual next CLOSED journal/raw/Round.');closedTargetPaths(paths,work);
    phase('geometry_Round_read2_begin',startClock,struct());x=load(output,'round');y=load(output,'round');assertPublicEqual(x.round,y.round,0);round=x.round;clear x y
    assert(strcmp(round.schema,'C1-PK-new36h-bounded-round-v1')&&isequaln(round.budget,budget)&&isequaln(jsondecode(fileread(json)),jsondecode(jsonencode(round))) ...
        &&isfield(round,'primary_diagnostics')&&~isfield(round.primary_diagnostics,'owned_negative_target_true_flow_geometry'),'C1PKGeometry:Round','Require matching native/JSON Round and a fresh observation field.');
    q=round.primary_diagnostics.owned_negative_target_unit_qualification;control=round.primary_diagnostics.negative_unit_height_NONEDGE;geometryIntake(q,control,source,budget);
    projection=jsondecode(jsonencode(targetStdout(q)));exact(actualQualifierClosure.tool_prefix_reference,{'file','prefix_bytes','prefix_sha256'});exact(actualQualifierClosure.process_prefix_reference,{'file','prefix_bytes','prefix_sha256'});
    witness=verifiedEvidenceClosure(actualQualifierClosure,projection,'C1_PK_OWNED_TARGET_UNIT_QUALIFICATION_ACTUAL_RETURN ',root);
    phase('geometry_journal_read2_begin',startClock,struct());x=load(ledger,'journal');v=geometryJournal(x.journal,q,core,budget,source);clear x
    x=load(ledger,'journal');v2=geometryJournal(x.journal,q,core,budget,source);assertPublicEqual(v,v2,0);clear x v2
    epoch=v.source_code;refs={self;q.source_reference;reference(which('C1PlainFineQualificationReplay_v3'));digest};
    assert(strcmp(refs{3}.sha256,'fb35df74f7de49f65f72040e3577080d8a55e96de039646528bdf3991a2c41df'),'C1PKGeometry:FineMethod','Keep the unchanged original fine helper.');
    for name={'BranchSolutionFile_v3','HybridCycleData_v3','ContinuousDynamics_v3','GuardFunctions_v3','HybridSimulator_v3','RecordedReturnPolicy_v3','BLMarkedApexReturnPolicy_v3','PoincareSection_v3','Quadrupedal_Dynamics_v3','QuadrupedPhysicalChart_v3','QuadrupedSchema_v3','QuadrupedEnergy_v3','EnergyFamilyResidual_v3','GaitIdentification_v3','OrbitContentIdentity_v3','MatchingReturnSection_v3','ode45','deval','fzero'},refs{end+1,1}=reference(which(name{1}));end
    historicalMethods=[q.actual_driver_method_references(:);control.common_fine_service_contract.called_method_references(:)];guards={before;source};verifySources(budget,epoch,[refs;historicalMethods],guards,work);
    phase('geometry_owned_pair_read2_begin',startClock,struct('parent',v.parent,'target',v.target,'attempt',q.target_attempt.attempt));
    ix=BranchSolutionFile_v3.index(core);[O,R,M]=BranchSolutionFile_v3.loadSolutions(core,[v.parent v.target]);[P,U,V]=BranchSolutionFile_v3.loadSolutions(core,[v.parent v.target]);
    assertPublicEqual(O,P,0);assertPublicEqual(M,V,0);assertPublicEqual(reportView(R),reportView(U),0);clear P U V
    assertPublicEqual(record(O{2},R{2},M{2},ix.points{v.target}),q.original_records{1},0);assertPublicEqual(record(O{1},R{1},M{1},ix.points{v.parent}),control.original_records{2},0);
    assert(strcmp(OrbitContentIdentity_v3(O{2}),q.target_native_id)&&strcmp(M{1}.component_identity,M{2}.component_identity),'C1PKGeometry:NativeID','Bind the actual qualified target and its native owned predecessor.');
    hit=find(cellfun(@(e)e.from==v.parent&&e.to==v.target&&strcmp(e.component_identity,M{2}.component_identity),ix.edges));assert(isscalar(hit),'C1PKGeometry:OwnedEdge','Require exactly the existing current physical edge.');assertPublicEqual(ix.edges{hit},q.actual_earned_physical_edge,0);
    p=M{2}.provenance;assert(M{2}.edge_enabled&&M{2}.edge_from==v.parent&&p.source_point==v.parent&&isequal(p.attempt,q.target_attempt.attempt) ...
        &&isequaln(p.capture,q.target_attempt.capture)&&isequaln(p.corrector_initialization,q.target_attempt.corrector_initialization),'C1PKGeometry:Attempt','Do not select a later shrink point or the frontier finalpair.');
    [~,pb]=admitted(O{1},R{1});[~,pt]=admitted(O{2},R{2});assertPrimitive(R{1});assertPrimitive(R{2});assert(isequaln(pb.configuration,pt.configuration)&&isequaln(O{1}.parameter,O{2}.parameter),'C1PKGeometry:Policy','Keep the complete native policy and physical parameter.');
    facts=struct('schema','C1-PK-current-owned-target-true-flow-geometry-v1','source_reference',self,'journal_reference',before,'raw_source_reference',source,'round_before_reference',roundBefore, ...
        'qualifier_reference',struct('Round_reference',roundBefore,'field','primary_diagnostics.owned_negative_target_unit_qualification','typed_digest',C1ScientificDigest_v3(q)), ...
        'actual_closed_qualifier',witness,'target_index',v.target,'target_native_id',q.target_native_id,'target_attempt',pick(q.target_attempt,{'attempt','source_point','step','capture','status','all_nine','timely','edge_committed','storage_timely'}), ...
        'predecessor_index',v.parent,'predecessor_native_id',OrbitContentIdentity_v3(O{1}),'actual_earned_physical_edge',ix.edges{hit}, ...
        'actual_source_code',{epoch},'actual_method_references',{refs},'historical_guarded_method_references',{historicalMethods}, ...
        'wrapper',struct('declared_seconds',1800,'save_post_reserve_seconds',180,'fresh_target_original_fine_seconds',300,'maximum_fresh_target_fine_requests',2,'local_seconds',120,'maximum_local_profiles',2,'fixed_budget',budget), ...
        'predecessor_saved_geometry',struct(),'target_saved_geometry',struct(),'fines',{{}},'local_profiles',{{}},'fine_profile_requests',0,'fresh_target_return_map_calls_attempted',0,'local_integrations_attempted',0,'diagnostic_scalar_root_calls',0, ...
        'all_original_target_fines_passed',false,'combined_finite_sensitivity_returned',false,'completed',false,'failure',struct(),'status','prepared', ...
        'periodic_root_attempts',0,'admissions',0,'journal_mutated',false,'raw_store_mutated',false,'catalogue_mutated',false,'canonical_graph_mutated',false,'frontier_status_changed',false,'own_process_exit_observed',false, ...
        'physical_endpoint_claimed',false,'exact_grazing_claimed',false,'branch_turn_claimed',false,'maximality_claimed',false,'continuous_nonpenetration_certified',false,'global_PK_completion_claimed',false,'half_height_stop_claimed',false);
    try
        facts.predecessor_saved_geometry=pointGeometry(O{1},R{1},v.parent,work);facts.target_saved_geometry=pointGeometry(O{2},R{2},v.target,work);
        facts.predecessor_scope='Native public read2 and saved primitive samples/BL margins only; no fresh predecessor replay, local refinement or neighborhood crossing/turn test.';
        [service,live,runtimeAudit,contract]=geometryService(R{2},pt.configuration,[epoch(:);refs(:)],work);facts.fresh_fine_service_reconstruction=runtimeAudit;facts.target_fine_service_contract=contract;facts.target_fine_service_contract_digest=C1ScientificDigest_v3(contract);
        verifySources(budget,epoch,[refs;historicalMethods],guards,work);assert(left(work)>2*300+2*120+60,'C1PKGeometry:AllCapsFit','Both full300 target fines and both full120 locals must fit before the first replay.');
        seed=struct('state',O{2}.initial_state,'mode',O{2}.initial_mode,'parameter',O{2}.parameter,'return_policy',service.correction_return_policy,'occurrence',1);steps=[.0005 .00025];brackets=cell(2,1);
        for level=1:2
            verifySources(budget,epoch,[refs;historicalMethods],guards,work);assert(left(work)>300,'C1PKGeometry:FineFit','Do not shorten an original300 target profile.');limit=fineLimit(300,budget,work);facts.fine_profile_requests=facts.fine_profile_requests+1;
            phase('geometry_target_fine_begin',startClock,struct('level',level,'MaxStep',steps(level),'full_cap_seconds',300));[fine,ev,g]=C1PlainFineQualificationReplay_v3(seed,steps(level),service,limit);timely=utc()<limit.deadline_unix_seconds&&nano()<limit.deadline_monotonic_ns;
            facts.fresh_target_return_map_calls_attempted=facts.fresh_target_return_map_calls_attempted+double(ev.map_complete||strcmp(ev.phase_at_failure,'map'));
            item=fineObservation(fine,ev,g,seed,O{2},2,level,live,steps(level),timely,pt.configuration);item.side_name='current_owned_target';item.seed_native_id=q.target_native_id;
            item.BL_margins=struct();item.minimum_bracket=struct();item.bracket_failure=struct();facts.fines{level,1}=item;
            if item.all_declared_conditions_met
                facts.fines{level}.BL_margins=blMargins(fine.section_chart,pt.configuration.settings);
                try,brackets{level}=expandedBracket(ev.trajectory,fine,seed.parameter,work);facts.fines{level}.minimum_bracket=brackets{level};catch problem,facts.fines{level}.bracket_failure=exceptionData(problem);end
            end
            phase('geometry_target_fine_returned',startClock,struct('level',level,'timely',timely,'passed',item.all_declared_conditions_met,'cyclic_bracket_available',~isempty(brackets{level})));clear fine ev g item
        end
        facts.all_original_target_fines_passed=numel(facts.fines)==2&&all(cellfun(@(x)x.all_declared_conditions_met&&x.timely_observed,facts.fines));
        if facts.all_original_target_fines_passed
            for level=1:2
                if isempty(brackets{level}),continue;end
                verifySources(budget,epoch,[refs;historicalMethods],guards,work);assert(left(work)>120+2,'C1PKGeometry:LocalFit','The full120 local cap plus construction margin must fit.');local=struct('u',utc()+120,'m',nano()+120e9);assert(local.u<work.u&&local.m<work.m,'C1PKGeometry:LocalClockFit','The actual full120 absolute deadlines must remain within BOTH work clocks.');
                phase('geometry_target_local_begin',startClock,struct('fresh_fine_level',level,'local_profile_level',level,'full_cap_seconds',120));r=localProfile(brackets{level},level,seed.parameter,local);r.source_fine_level=level;
                facts.local_integrations_attempted=facts.local_integrations_attempted+double(r.integration_call_attempted);facts.diagnostic_scalar_root_calls=facts.diagnostic_scalar_root_calls+r.scalar_root_calls;facts.local_profiles{end+1,1}=r;
                phase('geometry_target_local_returned',startClock,struct('fresh_fine_level',level,'completed',r.completed));
            end
            if numel(facts.local_profiles)==2,[facts.combined_profile_differences,facts.combined_finite_sensitivity_returned]=compareRoots(facts.local_profiles{1},facts.local_profiles{2});end
        end
        facts.status='finite_current_target_geometry_partial';if facts.all_original_target_fines_passed&&facts.combined_finite_sensitivity_returned,facts.status='finite_current_target_two_profile_geometry_returned';end
    catch problem,facts.failure=exceptionData(problem);facts.status='partial_or_refused';end
    clear O R M ix p pb pt service live seed fine ev g item brackets r control contract
    facts.combined_sensitivity_scope='Fine1/local1 versus fine2/local2 changes BOTH fresh replay and local integration profile; differences are combined finite sensitivity, not separate convergence tests or rigorous error bounds.';
    facts.scope='Current qualified target only: all4 actual raw foot guards and true-flow stationary minima in a common event-free ALL-FLIGHT cyclic bracket. Missing brackets/exact-zero plateaus or skipped partial-stance swing intervals remain unresolved; no whole-cycle global minimum or sign certificate is claimed. Raw13/T0/mode/stride defects, right-state errors and profile differences accompany every margin. Predecessor is saved-only comparison. No endpoint, exact grazing, turn, maximality, H<.5, new edge, new admission or branch/global completion follows.';
    facts.completed=true;facts.finished_utc=stamp();facts.elapsed_seconds=(nano()-startClock.m)/1e9;
    verifySources(budget,epoch,[refs;historicalMethods],guards,finish);closedTargetPaths(paths,finish);verifiedEvidenceClosure(witness,projection,'C1_PK_OWNED_TARGET_UNIT_QUALIFICATION_ACTUAL_RETURN ',root);
    assert(strcmp(RoundSHA256_v3(output),roundBefore.sha256)&&strcmp(RoundSHA256_v3(json),jsonBefore.sha256),'C1PKGeometry:RoundClosest','Do not overwrite an independently changed Round.');
    phase('geometry_Round_publication_begin',startClock,struct('status',facts.status));round.primary_diagnostics.owned_negative_target_true_flow_geometry=facts;saveRound(output,json,round);clear round q
    verifySources(budget,epoch,[refs;historicalMethods],guards,finish);closedTargetPaths(paths,finish);verifiedEvidenceClosure(witness,projection,'C1_PK_OWNED_TARGET_UNIT_QUALIFICATION_ACTUAL_RETURN ',root);
    small=geometryStdout(facts);literal=jsonencode(small);assert(numel(unicode2native(literal,'UTF-8'))<=100000,'C1PKGeometry:Stdout','Full facts stay in the one native Round field.');check(finish);fprintf('C1_PK_OWNED_TARGET_GEOMETRY_ACTUAL_RETURN %s\n',literal);check(finish);
end
function geometryIntake(q,control,rawRef,budget)
    assert(isstruct(q)&&isscalar(q)&&strcmp(q.schema,'C1-PK-owned-target-versus-negative-unit-finite-qualification-v1') ...
        &&strcmp(q.source_reference.sha256,'60d9d035ce25f430fd3cc4b07e96e75a825480af4560ba2a1a29d61b14e0582a') ...
        &&q.completed&&isempty(fieldnames(q.failure))&&q.finite_unit_conditions_met&&q.exact_target_owned_commit&&q.whole_batch_closed_timely ...
        &&q.all_two_owned_fines_passed&&q.four_unique_original_profiles_verified&&q.all_four_original_fines_passed ...
        &&q.comparison.conditions_met&&q.saved_four_discrete_cohort_match&&~q.own_process_exit_observed ...
        &&isequaln(q.wrapper.fixed_budget,budget)&&isequaln(q.raw_source_reference,rawRef),'C1PKGeometry:QualifiedIntake','Require actual successful60d9 finite qualification and the EXACT unchanged current raw source.');
    assert(strcmp(C1ScientificDigest_v3(control),q.control_qualification_reference.typed_digest) ...
        &&isequaln(control.common_fine_service_contract,q.historical_common_service_contract) ...
        &&strcmp(control.common_fine_service_contract_digest,q.common_service_contract_digest),'C1PKGeometry:ControlProof','The historical closed control/service remains literal, not a new control execution.');
    e=q.actual_earned_physical_edge;a=q.target_attempt;
    assert(isa(q.owned_point_index,'double')&&isscalar(q.owned_point_index)&&q.owned_point_index>=1&&q.owned_point_index==fix(q.owned_point_index) ...
        &&e.to==q.owned_point_index&&e.from==a.source_point&&a.all_nine&&a.timely&&a.edge_committed&&a.storage_timely ...
        &&isequal(a.step,q.target_step)&&strcmp(a.corrector_initialization.method,'predictor-energy') ...
        &&strcmp(q.original_records{1}.native_id,q.target_native_id)&&q.original_records{1}.index==e.to ...
        &&control.original_records{2}.index==e.from,'C1PKGeometry:DynamicSelector','Use the qualified actual attempt/NativeID/current physical edge, never a guessed future index or finalpair.');
end
function v=geometryJournal(j,q,core,budget,rawRef)
    assert(strcmp(j.schema,'C1-persistent-PK-frontier-ledger-v1')&&isempty(fieldnames(j.active_run))&&isequaln(j.active_budget,budget) ...
        &&~strcmp(j.status,'native_pending_requires_reconciliation')&&isequaln(j.source_code,q.actual_driver_source_code),'C1PKGeometry:ClosedJournal','Require the unchanged current method epoch and no active native custody.');
    if isfield(j.last_run_full,'pending_admission'),assert(isempty(fieldnames(j.last_run_full.pending_admission)),'C1PKGeometry:PendingAdmission','Reconcile retained accepted native payloads first.');end
    at=find(cellfun(@(f)strcmp(f.id,q.authorization.frontier_id),j.frontiers));assert(isscalar(at),'C1PKGeometry:Frontier','The qualified frontier must still exist.');f=j.frontiers{at};
    assert(strcmp(f.component_file,core)&&isequaln(f.source_reference,rawRef) ...
        &&isequal(f.last_dispatched_sequence,q.canonical_run_sequence)&&isequal(f.source_pair,q.actual_frontier_after.source_pair) ...
        &&isequal(f.step,q.actual_frontier_after.step)&&isequal(f.strategy_index,q.actual_frontier_after.strategy_index) ...
        &&isequal(f.derivative_index,q.actual_frontier_after.derivative_index),'C1PKGeometry:CurrentLocalContext','Require unchanged local controls; unrelated global-component growth or an explicit status-only hold does not rehash historical q journal/Round refs.');
    v=struct('source_code',{j.source_code},'parent',q.actual_earned_physical_edge.from,'target',q.owned_point_index);
end
function out=pointGeometry(o,r,index,limit)
    [~,pe]=admitted(o,r);s=QuadrupedSchema_v3.shared();section=PoincareSection_v3.apex(s.PhaseIndex);
    assert(section.isOnSection(o.initial_state,o.parameter)&&section.derivative(0,o.initial_state,o.initial_mode,o.parameter,Quadrupedal_Dynamics_v3())<0,'C1PKGeometry:Apex','Require the actual native downward marked section.');
    assert(isfield(r,'period')&&isequal(r.period,o.period)&&isfield(r,'primitive')&&isequal(r.primitive.recorded_period,o.period),'C1PKGeometry:PrimitiveSpan','The saved primitive trace must match this native return.');
    out=struct('point_index',index,'native_id',OrbitContentIdentity_v3(o),'initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full14_stride',o.stride_displacement, ...
        'marked_height',o.initial_state(s.State.y),'rest_length',o.parameter(s.Parameter.l_l_b),'BL_margins',blMargins(o.section_chart,pe.configuration.settings), ...
        'actual_marked_state_guard_geometry',geometry(o.initial_state,o.initial_mode,o.parameter,ContinuousDynamics_v3(),GuardFunctions_v3()), ...
        'saved_classification_header',pick(r.classification,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count','flight_count_certain','status'}),'saved_primitive',r.primitive);
    out.saved_allflight_scan=scan(o,index,limit);out.exact_vs_tolerant_invariance=invariance(o,out.saved_allflight_scan);
end
function out=blMargins(chart,settings)
    assert(strcmp(chart.id,'apex-before-BL-TD-local')&&strcmp(chart.geometry,'dy=0, ddy<0')&&chart.crossing_orientation==-1,'C1PKGeometry:BLChart','Keep the actual native marked chart.');
    out=struct('section_chart',chart,'actual_TimeTolerance',settings.TimeTolerance,'both_marks_positive_separation',false);
    for key={'initial_mark','return_mark'},m=chart.(key{1});assert(m.marked&&isfinite(m.apex_to_touchdown_margin)&&isfinite(m.touchdown_to_next_apex_margin) ...
            &&m.apex_to_touchdown_margin>settings.TimeTolerance&&m.touchdown_to_next_apex_margin>settings.TimeTolerance,'C1PKGeometry:BLMargin','Retain actual positive BL separating margins.');end
    out.both_marks_positive_separation=true;
end
function out=invariance(o,a)
    s=QuadrupedSchema_v3.shared();p=o.parameter;pair=p([s.Parameter.k_l_b,s.Parameter.k_s_b,s.Parameter.l_l_b,s.Parameter.rsla_b])-p([s.Parameter.k_l_f,s.Parameter.k_s_f,s.Parameter.l_l_f,s.Parameter.rsla_f]);
    exactSamples=a.stored_phi_abs_max==0&&a.stored_dphi_abs_max==0&&a.stored_leg_angle_max_difference==0&&a.stored_leg_rate_max_difference==0&&a.stored_modes_all_synchronized;
    tolerantSamples=max([a.stored_phi_abs_max,a.stored_dphi_abs_max,a.stored_leg_angle_max_difference,a.stored_leg_rate_max_difference])<=1e-8&&a.stored_modes_all_synchronized;
    out=struct('paired_parameter_differences',pair,'COM_offset_from_half',p(s.Parameter.l_com)-.5,'exact_parameter_symmetry',all(pair==0)&&p(s.Parameter.l_com)==.5, ...
        'exact_upright_synchronous_saved_samples',exactSamples,'within_pronk_intake_tolerances_at_saved_samples',tolerantSamples&&norm(pair,Inf)<=1e-12&&abs(p(s.Parameter.l_com)-.5)<=1e-12, ...
        'state_intake_tolerance',1e-8,'parameter_intake_tolerance',1e-12,'membership_scope','Literal saved sample comparisons only. EnergyFamilyResidual accepts tolerance-small fixed reference pitch/rate; neither finite sample result proves exact continuous invariant-subspace membership.', ...
        'continuous_exact_invariance_proved',false,'height_bound_hypotheses_verified',false);
end
function small=geometryStdout(f)
    small=pick(f,{'schema','source_reference','journal_reference','raw_source_reference','round_before_reference','qualifier_reference','actual_closed_qualifier','target_index','target_native_id','target_attempt','predecessor_index','predecessor_native_id','actual_earned_physical_edge','wrapper','fine_profile_requests','fresh_target_return_map_calls_attempted','local_integrations_attempted','diagnostic_scalar_root_calls','all_original_target_fines_passed','combined_finite_sensitivity_returned','combined_profile_differences','combined_sensitivity_scope','completed','failure','status','periodic_root_attempts','admissions','journal_mutated','raw_store_mutated','catalogue_mutated','canonical_graph_mutated','frontier_status_changed','own_process_exit_observed','physical_endpoint_claimed','exact_grazing_claimed','branch_turn_claimed','maximality_claimed','continuous_nonpenetration_certified','global_PK_completion_claimed','half_height_stop_claimed','finished_utc','elapsed_seconds','scope'});
    for key={'predecessor_saved_geometry','target_saved_geometry'},name=key{1};a=member(f,name,struct());r=pick(a,{'point_index','native_id','marked_height','rest_length','period','full14_stride','BL_margins','exact_vs_tolerant_invariance'});if isfield(a,'saved_allflight_scan'),r.saved_scan=pick(a.saved_allflight_scan,{'sample_count','allflight_sample_count','sampled_allflight_guard_minima','raw_return_minus_initial','stride_adjusted_seam_error','raw_mode_closure','raw_minus_recorded_stride','cyclic_wrap_available','stationary_zero_sample_counts','exact_subspace_membership_proved','no_bracket_means_no_grazing'});end;small.(name)=r;end
    small.fines=cell(size(f.fines));for k=1:numel(f.fines),a=f.fines{k};r=pick(a,{'side_name','original_profile_level','timely_observed','initial_trajectory_row_exact','qualified_PK1_primitive','saved_period_scaled_error','saved_full14_stride_scaled_error','map_complete','classifier_complete','sample_count','all_declared_conditions_met','BL_margins','bracket_failure'});r.fine=pick(a.fine,{'MaxStep','passed','status','failure','full13_norm','period','minimum_physical_margins','minimum_guard_transversality','section_transversality'});r.minimum_bracket=stdoutBracket(a.minimum_bracket);small.fines{k}=r;end
    small.local_profiles=f.local_profiles;for k=1:numel(small.local_profiles),small.local_profiles{k}.bracket=stdoutBracket(small.local_profiles{k}.bracket);end
end

function out=scan(o,pointIndex,limit)
    data=HybridCycleData_v3.unpack(o);s=QuadrupedSchema_v3.shared();dynamics=ContinuousDynamics_v3(s);guards=GuardFunctions_v3(s);events=HybridCycleData_v3.physicalEvents(data);eventTimes=reshape([events.cycle_time],[],1);period=data.period;
    t=data.time-data.start_time;assert(isequal(data.state(1,:).',o.initial_state(:))&&isequal(data.mode(1,:).',logical(o.initial_mode(:)))&&abs(t(end)-period)<=data.time_tolerance,'C1PKPrimary:StoredSpan','Require the exact owned primitive trace span; a longer or mismatched trace needs an explicit source-backed interval rule.');inside=find(t>=-data.time_tolerance&t<=period+data.time_tolerance);phase=t(inside);phase(abs(phase-period)<=data.time_tolerance)=0;phase(abs(phase)<=data.time_tolerance)=0;
    [phase,at]=unique(phase,'first');raw=inside(at);x=data.state(raw,:);q=data.mode(raw,:);n=numel(raw);g=NaN(n,4);lie=g;
    for k=1:n,if mod(k-1,64)==0,check(limit);end;if any(q(k,:)),continue;end;F=dynamics.evaluate(data.time(raw(k)),x(k,:).',q(k,:).',o.parameter);g(k,:)=guards.legValues(x(k,:).',o.parameter).';lie(k,:)=guards.legLieDerivatives(x(k,:).',F,o.parameter).';assert(all(isfinite([F(:);g(k,:).';lie(k,:).'])),'C1PKPrimary:FiniteFlow');end
    i0=find(abs(t)<=data.time_tolerance,1,'last');iT=find(abs(t-period)<=data.time_tolerance,1,'last');assert(~isempty(i0)&&~isempty(iT),'C1PKPrimary:RawSeam');
    seam=data.state(iT,:).'-data.state(i0,:).';translation=seam(1);recordedStride=o.stride_displacement;
    assert(isempty(recordedStride)||(isnumeric(recordedStride)&&isreal(recordedStride)&&isequal(size(recordedStride),[14,1])&&all(isfinite(recordedStride))),'C1PKPrimary:StrideShape','Native orbit stride must be empty legacy metadata or the source-defined finite14-column displacement; actual class=%s size=%s.',class(recordedStride),mat2str(size(recordedStride)));
    strideDifference=[];if ~isempty(recordedStride),strideDifference=data.state(iT,:).'-data.state(i0,:).'-recordedStride;end
    seam(1)=0; % Translation removed by the observed raw primitive endpoint difference, not by a missing annotation.
    wrapAvailable=isequal(data.mode(i0,:),data.mode(iT,:))&&~any(data.mode(i0,:))&&~any(data.mode(iT,:));
    wrapReason='raw_end_modes_not_equal_allflight';if wrapAvailable,wrapReason='raw_end_modes_equal_allflight';end
    out=struct('point_index',pointIndex,'raw_trace_span',[t(1),t(end)],'primitive_span_verified',true,'sample_count',n,'allflight_sample_count',sum(~any(q,2)),'physical_events',events,'period',period,'stride',translation,'stride_source','Observed raw primitive endpoint xT-x0','recorded_orbit_stride',{recordedStride},'raw_minus_recorded_stride',strideDifference, ...
        'raw_seam_rows',[i0,iT],'raw_return_minus_initial',data.state(iT,:).'-data.state(i0,:).','raw_translation',translation,'stride_adjusted_seam_error',seam,'raw_mode_closure',isequal(data.mode(i0,:),data.mode(iT,:)), ...
        'cyclic_wrap_available',wrapAvailable,'cyclic_wrap_mode_reason',wrapReason,'cyclic_candidate_scope','Raw saved samples shifted by observed raw primitive xT-x0; all other13 seam errors retained; wrap remains provisional until true local-flow/right-state refinement.','brackets',{{}},'stationary_zero_sample_counts',sum(lie==0,1),'no_bracket_means_no_grazing',false, ...
        'stored_phi_abs_max',max(abs(data.state(inside,s.State.phi))),'stored_dphi_abs_max',max(abs(data.state(inside,s.State.dphi))),'stored_leg_angle_max_difference',max(max(abs(data.state(inside,[7,9,11,13])-data.state(inside,7)))),'stored_leg_rate_max_difference',max(max(abs(data.state(inside,[8,10,12,14])-data.state(inside,8)))),'stored_modes_all_synchronized',all(all(data.mode(inside,:)==data.mode(inside,1))),'exact_subspace_membership_proved',false);
    valid=isfinite(g);out.sampled_allflight_guard_minima=NaN(1,4);for leg=1:4,if any(valid(:,leg)),out.sampled_allflight_guard_minima(leg)=min(g(valid(:,leg),leg));end,end
    for leg=1:4
        nz=find(isfinite(lie(:,leg))&lie(:,leg)~=0);if numel(nz)<2,continue;end
        for z=1:numel(nz)
            a=nz(z);b=nz(mod(z,numel(nz))+1);wrap=b<=a;if wrap&&~wrapAvailable,continue;end
            if ~(lie(a,leg)<0&&lie(b,leg)>0),continue;end
            if wrap,chain=[a:n,1:b];ta=phase(a);tb=phase(b)+period;else,chain=a:b;ta=phase(a);tb=phase(b);end
            if tb<=ta||any(any(q(chain,:))),continue;end
            shifted=eventTimes;shifted(shifted<ta)=shifted(shifted<ta)+period;
            if any(shifted>=ta-data.time_tolerance&shifted<=tb+data.time_tolerance),continue;end
            assert(numel(out.brackets)<16,'C1PKPrimary:BracketBound');right=x(b,:).';if wrap,right(1)=right(1)+translation;end
            separation=Inf;if ~isempty(eventTimes),separation=min(min(abs([ta;tb]-[eventTimes;eventTimes+period;eventTimes-period].'),[],2));end
            row=struct('leg',leg,'leg_name',s.Leg.Names{leg},'raw_rows',[raw(a),raw(b)],'phase_times',[ta,tb],'cyclic_wrap',wrap,'left_state',x(a,:).','right_saved_state_with_actual_stride_shift',right,'mode',q(a,:).','parameter',o.parameter,'saved_guard_values',[g(a,leg),g(b,leg)],'saved_actual_flow_Lie',[lie(a,leg),lie(b,leg)],'exact_zero_samples_inside',sum(lie(chain,leg)==0),'no_physical_event_in_closed_interval',true,'endpoint_event_separation',separation,'within_existing_local_width_cap',tb-ta<=.01,'stationary_minimum_candidate_only',true,'true_flow_refinement_performed',false);
            out.brackets{end+1,1}=row;
        end
    end
    out.phase_deduplication='One saved representative per exact phase; period endpoint mapped to phase0 with raw seam retained. Negative/positive nonzero neighbors include intervening exact-zero samples. No interpolation used.';
end
function b=expandedBracket(trace,fine,p,limit)
    check(limit);t=trace.time(:)-trace.time(1);X=trace.state;Q=logical(trace.mode);T=fine.period;tol=128*eps(max(1,max(abs(t))));assert(size(X,2)==14&&size(Q,2)==4&&numel(t)==size(X,1)&&abs(t(end)-T)<=tol,'C1PKFine:TraceSpan');
    assert(~any(Q(1,:))&&isequal(Q(1,:),Q(end,:)),'C1PKFine:FlightSeam');rawDelta=X(end,:).'-X(1,:).';
    data=struct('history',fine.event_history,'schema',QuadrupedSchema_v3.shared(),'start_time',trace.time(1),'period',T,'time_tolerance',tol);events=HybridCycleData_v3.physicalEvents(data);times=reshape([events.cycle_time],[],1);
    d=ContinuousDynamics_v3();guards=GuardFunctions_v3();lie=NaN(numel(t),4);
    for k=1:numel(t),if mod(k-1,64)==0,check(limit);end;if any(Q(k,:)),continue;end;F=d.evaluate(t(k),X(k,:).',Q(k,:).',p);lie(k,:)=guards.legLieDerivatives(X(k,:).',F,p).';end
    a=find(t<T-tol&all(lie<0,2),1,'last');c=find(t>tol&all(lie>0,2),1,'first');assert(~isempty(a)&&~isempty(c),'C1PKFine:NoFlightBracket');ta=t(a);tb=t(c)+T;assert(tb>ta&&tb-ta<=.01&&~any(any(Q([a:numel(t),1:c],:))),'C1PKFine:FlightBracket');
    extended=[times;times+T];assert(~any(extended>=ta-tol&extended<=tb+tol),'C1PKFine:PhysicalEvent');right=X(c,:).';right(1)=right(1)+rawDelta(1);
    b=struct('times',[ta,tb],'left_state',X(a,:).','right_saved_state',right,'mode',Q(a,:).','raw_rows',[a,c],'actual_period',T,'observed_raw_displacement',rawDelta,'raw_mode_closed',true,'saved_endpoint_Lie',[lie(a,:);lie(c,:)],'physical_events',events,'physical_event_separation',min(min(abs([ta;tb]-[times;times+T;times-T].'),[],2)), ...
        'scope','Actual positive-time post0 sample extends the cyclic bracket; x alone is shifted by observed raw stride. All13 other closure defects remain.');
end
function r=localProfile(b,level,p,limit)
    rel=[5e-14,3e-14];absTol=[5e-16,2.5e-16];divisor=[8,16];width=diff(b.times);profile=struct('RelTol',rel(level),'AbsTol',absTol(level),'MaxStep',width/divisor(level),'solver','ode45','physical_mode_fixed',true,'state_projection',false);
    r=struct('local_profile_level',level,'profile',profile,'bracket',b,'legs',{{}},'integration_call_attempted',false,'scalar_root_calls',0,'completed',false,'failure',struct(),'scope','Conditional event-free fixed-allflight dense-flow diagnostic; finite sensitivity, not a continuous error certificate.');
    dynamics=ContinuousDynamics_v3();guards=GuardFunctions_v3();q=b.mode;
    try
        check(limit);options=odeset('RelTol',profile.RelTol,'AbsTol',profile.AbsTol,'MaxStep',profile.MaxStep,'Events',[],'OutputFcn',@(~,~,~)budgetOutput(limit));
        r.integration_call_attempted=true;sol=ode45(@(t,x)fixedFlow(t,x,q,p,dynamics,limit),b.times,b.left_state,options);check(limit);assert(sol.x(1)==b.times(1)&&sol.x(end)==b.times(2)&&isequaln(deval(sol,b.times(1)),b.left_state),'C1PKFine:LocalSpan');
        right=deval(sol,b.times(2));r.right_state_error=right-b.right_saved_state;r.right_state_scaled_inf=norm(r.right_state_error./max(1,abs(b.right_saved_state)),Inf);assert(r.right_state_scaled_inf<=1e-9,'C1PKFine:RightState');
        for leg=1:4
            a=struct('leg',leg,'completed',false,'failure',struct());
            try
                ends=[denseLie(sol,b.times(1),q,p,leg,dynamics,guards,limit),denseLie(sol,b.times(2),q,p,leg,dynamics,guards,limit)];a.actual_endpoint_Lie=ends;assert(ends(1)<0&&ends(2)>0,'C1PKFine:RootBracket');
                tol=max(16*eps(max(1,max(abs(b.times)))),width*1e-10);r.scalar_root_calls=r.scalar_root_calls+1;
                [tr,fr,flag,out]=fzero(@(t)denseLie(sol,t,q,p,leg,dynamics,guards,limit),b.times,optimset('TolX',tol,'Display','off'));
                a.root_time=tr;a.root_phase_relative_to_marked_apex=tr-b.actual_period;a.root_Lie=fr;a.fzero_exitflag=flag;a.fzero_output=out;assert(flag>0&&tr>b.times(1)&&tr<b.times(2)&&abs(fr)<=1e-8,'C1PKFine:Root');
                delta=min([tr-b.times(1),b.times(2)-tr,width/16])/4;assert(delta>8*eps(max(1,abs(tr))),'C1PKFine:RootResolution');a.flank_times=[tr-delta,tr+delta];a.flank_Lie=[denseLie(sol,tr-delta,q,p,leg,dynamics,guards,limit),denseLie(sol,tr+delta,q,p,leg,dynamics,guards,limit)];assert(a.flank_Lie(1)<0&&a.flank_Lie(2)>0,'C1PKFine:Minimum');
                x=deval(sol,tr);a.geometry=geometry(x,q,p,dynamics,guards);a.guard_minimum=a.geometry.guard_values(leg);a.curvature=a.geometry.guard_second_derivatives(leg);a.guard_below_exact_zero=a.guard_minimum<0;a.guard_below_negative_admission_tolerance=a.guard_minimum<-a.geometry.physical.active_tolerances.swing_penetration;check(limit);a.completed=true;
            catch problem,a.failure=exceptionData(problem);end
            r.legs{leg,1}=a;
        end
        r.completed=all(cellfun(@(a)a.completed,r.legs));check(limit);
    catch problem,r.completed=false;r.failure=exceptionData(problem);end
end
function g=geometry(x,q,p,dynamics,guards)
    s=QuadrupedSchema_v3.shared();e=s.expandParameters(p);F=dynamics.evaluate(0,x,q,p);phi=x(s.State.phi);theta=phi+x(s.Leg.AngleIndices);thetaDot=F(s.State.phi)+F(s.Leg.AngleIndices);
    second=F(s.State.dy)+e.s.*(-sin(phi).*F(s.State.phi).^2+cos(phi).*F(s.State.dphi))+e.l_0.*(cos(theta).*thetaDot.^2+sin(theta).*(F(s.State.dphi)+F(s.Leg.RateIndices)));
    g=struct('state',x,'mode',q,'parameter',p,'flow',F,'guard_values',guards.legValues(x,p),'guard_true_Lie',guards.legLieDerivatives(x,F,p),'guard_second_derivatives',second,'physical',dynamics.admissibilityReport(x,q,p,'accepted-state'),'derivative_scope','General native all-flight flow at the actual state; no exact-upright/harmonic projection.');
end
function [rows,complete]=compareRoots(a,b)
    rows=cell(4,1);complete=a.completed&&b.completed;if ~complete,return;end
    for leg=1:4,u=a.legs{leg};v=b.legs{leg};rows{leg}=struct('leg',leg,'guard_minimum_difference',v.guard_minimum-u.guard_minimum,'root_phase_difference',v.root_phase_relative_to_marked_apex-u.root_phase_relative_to_marked_apex,'root_state_inf_difference',norm(v.geometry.state-u.geometry.state,Inf),'curvature_difference',v.curvature-u.curvature,'rigorous_bound_claimed',false);end
end
function F=fixedFlow(t,x,q,p,dynamics,limit),check(limit);F=dynamics.evaluate(t,x,q,p);end
function v=denseLie(sol,t,q,p,leg,dynamics,guards,limit),check(limit);x=deval(sol,t);F=dynamics.evaluate(t,x,q,p);v=guards.legLieDerivatives(x,F,p);v=v(leg);end
function b=stdoutBracket(b)
    if isfield(b,'physical_events'),b.physical_event_count=numel(b.physical_events);b=rmfield(b,'physical_events');b.physical_events_omitted_from_stdout=true;end
end
function [service,live,audit,contract]=geometryService(report,configuration,methods,work)
    [live,reconstruction]=freshIntegration(report.replay_integration,work);[~,savedPolicy]=RecordedReturnPolicy_v3(report);
    assert(savedPolicy.complete&&isequaln(savedPolicy.configuration,configuration),'C1PKGeometry:SavedPolicy','Use this target native report and its complete policy.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(configuration.settings,'Name'));[~,actual]=RecordedReturnPolicy_v3(struct('correction_return_policy',policy));
    assert(actual.complete&&isequaln(actual.configuration,configuration),'C1PKGeometry:PolicyRoundtrip','Fresh runtime policy must preserve every target setting.');
    limits=pick(report.options,{'MaxReturnTime','MaxCycleEvents','MaxSectionCrossings'});assert(all(isfield(limits,{'MaxReturnTime','MaxCycleEvents','MaxSectionCrossings'}))&&limits.MaxReturnTime==30,'C1PKGeometry:MapLimits','Keep the exact target native map horizon and event/crossing limits.');
    service=struct('replay_integration',live,'correction_return_policy',policy,'options',limits,'acceptance',report.acceptance,'classification',report.classification,'event_signature',report.event_signature);
    contract=struct('schema','C1-PK-owned-target-geometry-fine-service-v1','numeric_integration',reconstruction.all_other_integration_settings,'numeric_ODE_options',reconstruction.all_other_ODE_options, ...
        'solver','ode45','map_limits',limits,'acceptance',report.acceptance,'saved_classification',report.classification,'event_signature',report.event_signature,'BL_policy_configuration',actual.configuration, ...
        'declared_method_references',{methods},'profile_steps',[.0005 .00025],'RelTol',1e-12,'AbsTol',1e-14,'original_profile_cap_seconds',300, ...
        'deadline_callback_scope','Only the known saved deadline callback is replaced with a fresh immutable deadline; no historical callback is executed.');plain(contract);
    audit=struct('runtime_reconstruction',reconstruction,'actual_policy_configuration',actual.configuration,'target_saved_settings_preserved',true,'fresh_deadline_only',true,'original_saved_callback_executed',false, ...
        'scope','NEW target-derived geometry replay contract, distinct from the prior cross-orbit four-profile comparison; no equality with the historical0050 common service is assumed or claimed.');
end
function closedTargetPaths(paths,limit)
    check(limit);for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKTarget:Pending','Reconcile native active/pending custody first: %s',paths{k});end
end
function small=targetStdout(f)
    small=pick(f,{'schema','source_reference','journal_reference','raw_source_reference','round_before_reference','catalogue_reference','authorization','target_step','canonical_run_sequence','canonical_run_index','canonical_run_status','canonical_run_failure_header','administrative_zero_attempt','original_child_return_observed','canonical_persistence_completion_confirmed','target_attempted','target_attempt_ordinal','whole_batch_closed_timely','exact_target_owned_commit','owned_point_index','target_native_id','actual_owned_observables','comparison','saved_four_discrete_cohort_match','common_service_contract_digest','fine_profile_requests','fine_full_return_map_calls_attempted','all_two_owned_fines_passed','four_unique_original_profiles_verified','all_four_original_fines_passed','finite_unit_conditions_met','periodic_root_attempts','admissions','journal_mutated','raw_store_mutated','catalogue_mutated','canonical_graph_mutated','frontier_status_changed','global_endpoint_claimed','owned_connection_claimed','half_height_stop_claimed','own_process_exit_observed','completed','failure','status','finished_utc','elapsed_seconds','root_fact_scope','scope'});
    small.target_attempt=pick(f.target_attempt,{'attempt','source_point','step','status','algorithm','derivative_method','relative_step','all_nine','timely','edge_committed','storage_attempted','storage_timely','isolated_committed','isolated_storage_timely','capture'});
    small.fines=cell(size(f.fines));for k=1:numel(f.fines),x=f.fines{k};r=pick(x,{'side','side_name','original_profile_level','timely_observed','initial_trajectory_row_exact','qualified_PK1_primitive','saved_period_scaled_error','saved_full14_stride_scaled_error','map_complete','classifier_complete','sample_count','completed_scalar_sample_count','all_declared_conditions_met','seed_native_id','common_service_contract_digest'});r.fine=pick(x.fine,{'MaxStep','passed','status','budget_refusal','failure','full13_norm','period','maximum_energy_variation','maximum_stance_constraint'});small.fines{k}=r;end
end
function verifySources(budget,epoch,refs,guards,limit)
    check(limit);assert(isequaln(C1RunBudget_v3(),budget),'C1PKNegative:Budget','The original grant VALUE changed.');methods=[epoch(:);refs(:)];for k=1:numel(methods),r=methods{k};[~,name,extension]=fileparts(r.file);actual=which(name);assert(strcmp(extension,'.m')&&~isempty(actual)&&strcmp(char(java.io.File(actual).getCanonicalPath()),char(java.io.File(r.file).getCanonicalPath())),'C1PKNegative:Resolver','An actual called/source resolver differs: %s',r.file);end
    allRefs=[methods;guards(:)];for k=1:numel(allRefs),r=allRefs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1PKNegative:Source','A protected source or authority changed: %s',r.file);end;check(limit);
end
function assertPrimitive(r)
    assert(isfield(r,'primitive')&&strcmp(r.primitive.status,'primitive_within_checked_bound'),'C1PKE0:Primitive','Retain an actually checked primitive result independently of the optional primitive gate.');
end
function out=fineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration)
    returnedPolicy=isfield(fine,'actual_policy');if returnedPolicy,[~,used]=RecordedReturnPolicy_v3(struct('correction_return_policy',fine.actual_policy));assert(used.complete&&isequaln(used.configuration,configuration),'C1PKE0:FinePolicy','Fresh fine changed the actual return policy.');fine.actual_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',configuration.source_class,'settings',configuration.settings);end
    firstExact=ev.sample_count>0&&isequaln(ev.trajectory.state(1,:).',seed.state)&&isequaln(logical(ev.trajectory.mode(1,:).'),logical(seed.mode));periodError=NaN;strideError=NaN;if isfield(fine,'period'),periodError=abs(fine.period-original.period)/max([1,abs(fine.period),abs(original.period)]);end;if isfield(fine,'stride_displacement'),sx=max([ones(14,1),abs(fine.stride_displacement(:)),abs(original.stride_displacement(:))],[],2);strideError=norm((fine.stride_displacement(:)-original.stride_displacement(:))./sx,Inf);end
    names={'candidate','original_unit'};out=struct('side',side,'side_name',names{side},'original_profile_level',level,'fine',fine,'actual_full_classification',g,'timely_observed',timely,'initial_trajectory_row_exact',firstExact,'qualified_PK1_primitive',qualified(g),'saved_period_scaled_error',periodError,'saved_full14_stride_scaled_error',strideError,'map_complete',ev.map_complete,'classifier_complete',ev.classifier_complete,'sample_count',ev.sample_count,'completed_scalar_sample_count',ev.completed_scalar_sample_count,'failure_phase',ev.phase_at_failure,'timings',ev.timings,'effective_ODE_profile',effectiveProfile(integration,step),'all_declared_conditions_met',fine.passed&&timely&&qualified(g)&&firstExact&&returnedPolicy&&ev.map_complete&&ev.classifier_complete&&ev.completed_scalar_sample_count==ev.sample_count&&periodError<=1e-8&&strideError<=1e-8);
end
function phase(name,start,extra)
    item=struct('phase',name,'utc',stamp(),'outer_elapsed_seconds',(nano()-start.m)/1e9,'detail',extra);text=jsonencode(item);assert(numel(unicode2native(text,'UTF-8'))<=10000,'C1PKE0:PhaseOutput','Stage marker exceeded its declared bound.');fprintf('C1_PK_E0_STAGE %s\n',text);
end
function out=record(o,r,m,ix)
    out=struct('index',ix.index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o),'initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full14_stride',o.stride_displacement,'metadata',m,'saved_all_nine',r.acceptance_gates,'saved_classification',r.classification,'saved_primitive',r.primitive);
end

function out=rootFacts(r)
    out=struct('available',isfield(r,'solver'));if ~out.available,return;end;s=r.solver;out.literal=pick(s,{'solver','exitflag','converged','residualNorm','functionEvaluationCount','mapEvaluationCount','cacheHitCount','invalidEvaluationCount','jacobianEvaluationCount','derivativeModel','derivativeEvaluated','acceptedNewtonIterations','invalidTrialCount','stateScale','finalJacobian','jacobianReliable','selectedFiniteDifferenceSteps','perColumnReliability'});if isfield(s,'output'),out.output=pick(s.output,{'iterations','funcCount','algorithm','rootTolerance','stepsize','acceptedIterations','invalidTrialCount','initialJacobianUsed','RootNewtonMinimumRcond','lastReciprocalCondition','lastLinearRelativeBackwardError','finalJacobianFreshAtFinalState','message'});end
end

function out=reportView(reports)
    out=cell(size(reports));for k=1:numel(reports),out{k}=pick(reports{k},{'status','accepted','native_status','classification','primitive','acceptance','acceptance_gates','replay_integration','event_signature','correction_return_policy','options'});out{k}.bounded_root_facts=rootFacts(reports{k});end
end

function [live,audit]=freshIntegration(saved,limit)
    native=HybridSimulator_v3();defaults=native.Options;assert(isstruct(saved)&&isscalar(saved)&&isequal(sort(fieldnames(saved)),sort(fieldnames(defaults))),'C1PKFine:IntegrationSchema','Native verification refused; original observations are retained.');
    assert(isempty(saved.StopCondition)&&isstruct(saved.ODEOptions)&&isscalar(saved.ODEOptions),'C1PKFine:Callback','Native verification refused; original observations are retained.');
    odeDefaults=odeset();assert(isequal(sort(fieldnames(saved.ODEOptions)),sort(fieldnames(odeDefaults)))&&isempty(saved.ODEOptions.Events),'C1PKFine:ODEFields','Native verification refused; original observations are retained.');
    solverHeader=knownCallback(saved.ODESolver,'ode45');outputHeader=knownCallback(saved.ODEOptions.OutputFcn,'@(~,~,~)double(left(limit)<=0)');
    numeric=saved;numeric=rmfield(numeric,{'ODESolver','ODEOptions'});plain(numeric);odeNumeric=rmfield(saved.ODEOptions,'OutputFcn');plain(odeNumeric);
    live=saved;live.ODESolver=@ode45;live.ODEOptions.OutputFcn=@(~,~,~)budgetOutput(limit);rebuilt=HybridSimulator_v3(live);assert(isequaln(rebuilt.Options,live),'C1PKFine:IntegrationRoundtrip','Native verification refused; original observations are retained.');
    audit=struct('original_solver_header',solverHeader,'original_output_callback_header',outputHeader,'all_other_integration_settings',numeric,'all_other_ODE_options',odeNumeric, ...
        'replacements',{{'Known native ode45 descriptor to fresh @ode45','Known old deadline OutputFcn to fresh immutable-limit callback'}},'saved_closure_executed',false);
end

function out=knownCallback(value,expected)
    header=callbackHeader(value);detail=jsonencode(header);
    if isa(value,'function_handle')&&isscalar(value),signature=func2str(value);out=struct('class',class(value),'signature',signature);
    else
        assert(isstruct(value)&&isscalar(value)&&isequal(sort(fieldnames(value)),sort({'diagnostic_kind';'signature';'requires_runtime_reconstruction'}))&&strcmp(value.diagnostic_kind,'runtime-function-descriptor')&&isequal(value.requires_runtime_reconstruction,true),'C1PKFine:CallbackDescriptor','Unsupported saved callback header: %s',detail);signature=value.signature;out=value;
    end
    assert(ischar(signature)&&isrow(signature)&&strcmp(regexprep(signature,'\s',''),expected),'C1PKFine:CallbackSignature','Unexpected saved callback; no callback is rehydrated. Header: %s',detail);
end

function header=callbackHeader(value)
    header=struct('class',class(value),'size',size(value),'total_field_count',0,'fieldnames_first_32',{{}});
    if isstruct(value)
        names=fieldnames(value);header.total_field_count=numel(names);header.fieldnames_first_32=names(1:min(32,numel(names)));
        if isscalar(value)&&isfield(value,'signature')
            literal=value.signature;header.signature_class=class(literal);header.signature_size=size(literal);
            if ischar(literal)&&isrow(literal)&&numel(literal)<=1024,header.signature_text=literal;end
        end
    elseif isa(value,'function_handle')&&isscalar(value)
        literal=func2str(value);header.signature_length=numel(literal);header.signature_text=literal(1:min(1024,numel(literal)));
    end
end

function p=effectiveProfile(integration,step)
    nested=integration.ODEOptions;rel=1e-12;absolute=1e-14;if ~isempty(nested.RelTol),rel=min(rel,nested.RelTol);end;if ~isempty(nested.AbsTol),absolute=min(absolute,nested.AbsTol);end
    h=step;if ~isempty(nested.MaxStep),h=min(h,nested.MaxStep);end;p=struct('declared_RelTol',1e-12,'declared_AbsTol',1e-14,'declared_MaxStep',step,'effective_RelTol',max(rel,100*eps),'configured_minimum_RelTol',rel,'effective_AbsTol',absolute,'effective_MaxStep',h,'ode45_RelTol_floor',100*eps,'nested_options_preserved',true);
end

function yes=qualified(g)
    yes=isstruct(g)&&isscalar(g)&&strcmp(member(g,'contract_version',''),'quadruped-gait-v3.5')&&strcmp(member(g,'validated_gait_type',''),'PK')&&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1)&&isfield(g,'primitive')&&strcmp(member(g.primitive,'status',''),'primitive_within_checked_bound');
end

function value=fineLimit(seconds,budget,work)
    u=utc()+seconds;m=nano()+seconds*1e9;assert(u<work.u&&m<work.m,'C1PKFine:FineFit','Native verification refused; original observations are retained.');value=struct('deadline_unix_seconds',u,'deadline_utc',utcString(u),'deadline_monotonic_ns',m,'campaign_deadline_utc',utcString(budget.research_deadline_unix_seconds),'campaign_deadline_monotonic_ns',budget.research_deadline_monotonic_ns);
end

function s=utcString(u),v=datetime(u,'ConvertFrom','posixtime','TimeZone','UTC');v.Format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";s=char(v);end

function status=budgetOutput(limit),check(limit);status=0;end

function e=exceptionData(p),e=struct('identifier',p.identifier,'message',p.message,'stack',p.stack);end

function plain(v)
    if isstruct(v),for k=1:numel(v),for f=fieldnames(v).',plain(v(k).(f{1}));end,end
    elseif iscell(v),for k=1:numel(v),plain(v{k});end
    else,assert(isnumeric(v)||islogical(v)||ischar(v)||isstring(v),'C1PKFine:NonportableSetting','Unknown runtime setting is not silently replaced.');end
end


function [policy,evidence]=admitted(o,r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&isfield(r,'acceptance_gates')&&all(isfield(r.acceptance_gates,keys))&&all(cellfun(@(k)isequal(r.acceptance_gates.(k),true),keys)),'C1PKPrimary:AllNine','Native verification refused; original observations are retained.');
    if isfield(r,'accepted'),accepted=isequal(r.accepted,true);else,accepted=strcmp(member(r,'status',member(r,'native_status','')),'accepted');end
    assert(accepted&&strcmp(r.classification.contract_version,'quadruped-gait-v3.5')&&strcmp(r.classification.validated_gait_type,'PK')&&isequal(r.classification.canonical_label_qualified,true)&&isequal(r.classification.flight_count_certain,true)&&isequal(r.classification.flight_count,1),'C1PKPrimary:Class','Native verification refused; original observations are retained.');
    [policy,evidence]=RecordedReturnPolicy_v3(r);assert(evidence.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKPrimary:Policy','Native verification refused; original observations are retained.');
end

function assertPublicEqual(a,b,depth)
    assert(depth<=128&&strcmp(class(a),class(b))&&isequal(size(a),size(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    if isnumeric(a)||islogical(a),assert(issparse(a)==issparse(b)&&isreal(a)==isreal(b)&&isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif ischar(a)||isstring(a),assert(isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif iscell(a),for k=1:numel(a),assertPublicEqual(a{k},b{k},depth+1);end
    elseif isstruct(a),keys=fieldnames(a);assert(isequal(keys,fieldnames(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    elseif ismember(class(a),{'HybridOrbit_v3','Trajectory_v3'}),keys=sort(properties(a));assert(isequal(keys,sort(properties(b))),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    else,assert(isequaln(a,b),'C1PKPrimary:NativeRead2','Native verification refused; original observations are retained.');end
end

function saveRound(file,json,round)
    stage=[file '.pending.mat'];save(stage,'round','-v7');a=load(stage,'round');b=load(stage,'round');assert(isequaln(a.round,round)&&isequaln(b.round,round),'C1PKPrimary:StageRead2','Native verification refused; original observations are retained.');[ok,msg]=movefile(stage,file,'f');assert(ok,'C1PKPrimary:Publish','%s',msg);
    text=jsonencode(round,PrettyPrint=true);stage=[json '.pending.json'];fid=fopen(stage,'w');assert(fid>=0);closer=onCleanup(@()fclose(fid));bytes=unicode2native(text,'UTF-8');assert(fwrite(fid,bytes,'uint8')==numel(bytes));clear closer
    assert(isequaln(jsondecode(fileread(stage)),jsondecode(text)));[ok,msg]=movefile(stage,json,'f');assert(ok,'C1PKPrimary:Publish','%s',msg);a=load(file,'round');b=load(file,'round');assert(isequaln(a.round,round)&&isequaln(b.round,round)&&isequaln(jsondecode(fileread(json)),jsondecode(text)),'C1PKPrimary:InstalledRead2','Native verification refused; original observations are retained.');
end

function out=pick(s,keys),out=struct();for k=1:numel(keys),if isstruct(s)&&isscalar(s)&&isfield(s,keys{k}),out.(keys{k})=s.(keys{k});end,end,end

function out=member(s,key,fallback),out=fallback;if isstruct(s)&&isscalar(s)&&isfield(s,key),out=s.(key);end,end

function r=reference(file),r=struct('file',file,'sha256',RoundSHA256_v3(file));end

function check(c),assert(left(c)>0,'C1PKPrimary:Clock','Native verification refused; original observations are retained.');end

function value=left(c),value=min(c.u-utc(),(c.m-nano())/1e9);end

function u=utc(),u=posixtime(datetime('now','TimeZone','UTC'));end

function m=nano(),m=double(java.lang.System.nanoTime);end

function t=stamp(),v=datetime('now','TimeZone','UTC');v.Format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";t=char(v);end


function w=verifiedEvidenceClosure(w,q,tag,root)
    exact(w,{'schema','invocation_id','argv_utf8_sha256','exec_session_id','child_pid','actual_child_exit_code', ...
        'actual_process_exit_observed','tool_prefix_reference','process_prefix_reference'});
    assert(strcmp(w.schema,'C1-ordinary-initializer-evidence-closure-v1')&&isequal(w.actual_child_exit_code,0) ...
        &&isequal(w.actual_process_exit_observed,true)&&validSHA(w.argv_utf8_sha256),'C1OrdinaryCAS:Closure');text(w.invocation_id);
    for key={'exec_session_id','child_pid'},v=w.(key{1});assert(isa(v,'double')&&isreal(v)&&isscalar(v)&&isfinite(v)&&v>=1&&v==fix(v),'C1OrdinaryCAS:ClosureType');end
    assert(strcmp(w.tool_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Tool_Observations.jsonl')) ...
        &&strcmp(w.process_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Process_Observations.jsonl')),'C1OrdinaryCAS:ClosurePaths');
    t=prefixRows(w.tool_prefix_reference);p=prefixRows(w.process_prefix_reference);terminal=0;marker=0;returned=0;spec=0;
    for k=1:numel(t),r=t{k};if ~isfield(r,'invocation_id')||~strcmp(r.invocation_id,w.invocation_id),continue;end;assert(r.session_id==w.exec_session_id,'C1OrdinaryCAS:ToolSession');if isfield(r.record,'exit_code'),assert(r.record.exit_code==0,'C1OrdinaryCAS:ToolExit');terminal=terminal+1;end;if isfield(r.record,'output'),lines=strsplit(r.record.output,newline);for n=1:numel(lines),if startsWith(lines{n},tag),value=jsondecode(lines{n}(numel(tag)+1:end));assertPublicEqual(value,q,0);marker=marker+1;end,end,end,end
    for k=1:numel(p),r=p{k};if ~isfield(r,'invocation_id')||~strcmp(r.invocation_id,w.invocation_id),continue;end;if strcmp(r.schema,'C1-native-process-observation-v1'),assert(r.child_pid==w.child_pid&&r.actual_child_exit_code==0&&r.actual_process_exit_observed&&strcmp(r.argv_utf8_sha256,w.argv_utf8_sha256),'C1OrdinaryCAS:ProcessExit');returned=returned+1;end;if strcmp(r.schema,'C1-native-launch-specification-v1'),assert(strcmp(r.argv_utf8_sha256,w.argv_utf8_sha256),'C1OrdinaryCAS:Specification');spec=spec+1;end,end
    assert(terminal==1&&marker==1&&returned==1&&spec==1,'C1OrdinaryCAS:UniqueClosure');
end
function exact(s,keys),assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(keys(:))),'C1OrdinaryCAS:Fields');end
function text(v),assert(ischar(v)&&isrow(v)&&~isempty(v),'C1OrdinaryCAS:Text');end

function rows=prefixRows(r)
    assert(ischar(r.file)&&validSHA(r.prefix_sha256)&&isa(r.prefix_bytes,'double')&&isscalar(r.prefix_bytes)&&r.prefix_bytes>0&&r.prefix_bytes<=16*1024*1024&&r.prefix_bytes==fix(r.prefix_bytes),'C1PKEpoch:Prefix','Invalid bounded immutable prefix reference.');f=fopen(r.file,'rb');assert(f>=0,'C1PKEpoch:PrefixOpen','Cannot read witness prefix.');c=onCleanup(@()fclose(f));b=fread(f,r.prefix_bytes,'*uint8');assert(numel(b)==r.prefix_bytes&&b(end)==10,'C1PKEpoch:PrefixLength','Witness prefix must end at the exact LF.');clear c;d=java.security.MessageDigest.getInstance('SHA-256');d.update(b);h=lower(reshape(dec2hex(typecast(d.digest(),'uint8'),2).',1,[]));assert(strcmp(h,r.prefix_sha256),'C1PKEpoch:PrefixSHA','Witness prefix changed.');lines=strsplit(native2unicode(b.','UTF-8'),newline);lines(end)=[];rows=cellfun(@jsondecode,lines,'UniformOutput',false);
end

function yes=validSHA(v),yes=ischar(v)&&isrow(v)&&~isempty(regexp(v,'^[0-9a-f]{64}$','once'));end

