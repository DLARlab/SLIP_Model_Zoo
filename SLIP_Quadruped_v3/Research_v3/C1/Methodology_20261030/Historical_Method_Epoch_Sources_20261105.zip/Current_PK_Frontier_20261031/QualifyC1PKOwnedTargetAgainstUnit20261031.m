function facts=QualifyC1PKOwnedTargetAgainstUnit20261031(expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,expectedCatalogueSHA,actualOwnedBatchClosure)
% ONE post-owned finite comparison. No Root/correction/admission or status CAS.
% Historical control2 plus, only when close, two newly returned OWNED fines.
    root=fileparts(which('C1RunBudget_v3'));budget=C1RunBudget_v3();startClock=struct('u',utc(),'m',nano());
    finish=struct('u',min(startClock.u+1800,budget.research_deadline_unix_seconds),'m',min(startClock.m+1800e9,budget.research_deadline_monotonic_ns));
    assert(left(finish)>1799,'C1PKTarget:WholeFit','The full1800 observation cap must fit both unchanged science clocks.');work=struct('u',finish.u-180,'m',finish.m-180e9);
    ledger=fullfile(root,'Audits','PK_Persistent_Frontiers_20261026.mat');core=fullfile(root,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat');
    output=fullfile(root,'Audits','PK36h_20261031_Round.mat');json=[output(1:end-4) '.json'];catalogue=fullfile(root,'Results','PK36h_Endpoint_Experimental_Controls_20261031.mat');
    paths={[ledger '.pending.mat'],[ledger(1:end-4) '_active_checkpoint.mat'],[ledger(1:end-4) '_active_checkpoint.mat.pending.mat'],[core '.pending.mat'],[output '.pending.mat'],[json '.pending.json'],[catalogue '.pending.mat'],[catalogue '.pending-admission.mat']};
    digestReference=reference(which('C1ScientificDigest_v3'));assert(strcmp(digestReference.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3') ...
        &&strcmp(digestReference.file,fullfile(fileparts(fileparts(root)),'4_Solution_Management','C1ScientificDigest_v3.m')), ...
        'C1PKTarget:DigestIntake','Pin the public typed digest BEFORE any authorization/control digest is consumed.');
    self=reference([mfilename('fullpath') '.m']);before=reference(ledger);source=reference(core);roundBefore=reference(output);jsonBefore=reference(json);catalogueRef=reference(catalogue);
    assert(all(cellfun(@validSHA,{expectedLedgerSHA,expectedRawSHA,expectedRoundSHA,expectedCatalogueSHA})) ...
        &&strcmp(before.sha256,expectedLedgerSHA)&&strcmp(source.sha256,expectedRawSHA) ...
        &&strcmp(roundBefore.sha256,expectedRoundSHA)&&strcmp(catalogueRef.sha256,expectedCatalogueSHA), ...
        'C1PKTarget:Current','Require the actual declared CLOSED current authorities.');closedTargetPaths(paths,work);
    phase('target_Round_read2_begin',startClock,struct());x=load(output,'round');y=load(output,'round');assertPublicEqual(x.round,y.round,0);round=x.round;clear x y
    assert(strcmp(round.schema,'C1-PK-new36h-bounded-round-v1')&&isequaln(round.budget,budget) ...
        &&~isfield(round.primary_diagnostics,'owned_negative_target_unit_qualification') ...
        &&isequaln(jsondecode(fileread(json)),jsondecode(jsonencode(round))), ...
        'C1PKTarget:Round','Require matching native/JSON Round and a never-published target observation.');
    phase('target_journal_read2_begin',startClock,struct());x=load(ledger,'journal');v=targetJournalView(x.journal,round,core,budget,before,source);clear x
    x=load(ledger,'journal');v2=targetJournalView(x.journal,round,core,budget,before,source);assertPublicEqual(v,v2,0);clear x v2
    control=round.primary_diagnostics.negative_unit_height_NONEDGE;validateHistoricalControl(control,v,catalogueRef,budget);
    ownedProjection=jsondecode(jsonencode(v.batch));controlProjection=jsondecode(jsonencode(negativeStdout(control)));
    for item={actualOwnedBatchClosure,v.control_closure}
        exact(item{1}.tool_prefix_reference,{'file','prefix_bytes','prefix_sha256'});exact(item{1}.process_prefix_reference,{'file','prefix_bytes','prefix_sha256'});
    end
    witness=verifiedEvidenceClosure(actualOwnedBatchClosure,ownedProjection,'C1_PK_NEW36H_BATCH_ACTUAL_RETURN ',root);
    controlWitness=verifiedEvidenceClosure(v.control_closure,controlProjection,'C1_PK_NEGATIVE_UNIT_CONTROL_ACTUAL_RETURN ',root);
    assert(~isempty(regexp(controlWitness.invocation_id,'^PK36h20261031-0050-','once')),'C1PKTarget:ControlInvocation','Retain the actual closed0050 control provenance.');
    epoch=v.source_code;refs={self;reference(which('C1PlainFineQualificationReplay_v3'));v.authorization.adoption_source_reference;v.actual_transition_source_reference;v.batch.source_reference};
    assert(strcmp(refs{2}.sha256,'fb35df74f7de49f65f72040e3577080d8a55e96de039646528bdf3991a2c41df'),'C1PKTarget:FineMethod','Use the unchanged original fine method.');
    for name={'BranchSolutionFile_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3','C1ScientificDigest_v3','OrbitContentIdentity_v3','HybridOrbit_v3','QuadrupedEnergy_v3','QuadrupedSchema_v3','BLMarkedApexReturnPolicy_v3','HybridSimulator_v3','Quadrupedal_Dynamics_v3','GaitIdentification_v3'},refs{end+1,1}=reference(which(name{1}));end
    assert(strcmp(RoundSHA256_v3(which('C1ScientificDigest_v3')),'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'),'C1PKTarget:Digest','Keep the exact typed digest.');
    historicalMethods=control.common_fine_service_contract.called_method_references;
    guards={before;source;catalogueRef};verifySources(budget,epoch,[refs;historicalMethods],guards,work);verifyMethodResolvers([refs;historicalMethods]);
    facts=struct('schema','C1-PK-owned-target-versus-negative-unit-finite-qualification-v1','source_reference',self, ...
        'journal_reference',before,'raw_source_reference',source,'round_before_reference',roundBefore,'catalogue_reference',catalogueRef, ...
        'actual_closed_owned_batch',witness,'actual_public_batch',v.batch,'actual_frontier_after',v.frontier, ...
        'authorization',v.authorization,'target_step',v.target_step,'actual_registered_options',v.registered_options, ...
        'canonical_run_sequence',v.run_sequence,'canonical_run_index',v.run_index,'canonical_run_status',v.run_status, ...
        'canonical_run_failure_header',v.run_failure_header,'administrative_zero_attempt',v.administrative_zero_attempt,'original_child_return_observed',v.original_return, ...
        'canonical_persistence_completion_confirmed',v.persistence_confirmed,'committed_append_recovery',v.recovery, ...
        'bounded_actual_attempts',{v.attempts},'later_ordinary_outcomes_scope','Later ordinary invalid/reduced-step attempts remain literal. They do not erase an earlier exact-target owned point; whole-public lateness/unknown/recovery remains separate.', ...
        'control_qualification_reference',struct('Round_reference',roundBefore,'field','primary_diagnostics.negative_unit_height_NONEDGE','typed_digest',C1ScientificDigest_v3(control)), ...
        'control_closed_witness',controlWitness,'historical_control_fines',{control.fines}, ...
        'historical_common_service_contract',control.common_fine_service_contract,'common_service_contract_digest',control.common_fine_service_contract_digest, ...
        'actual_driver_source_code',{epoch},'actual_driver_method_references',{refs}, ...
        'historical_control_method_tuple_scope','The retained876b tuple is rehashed/resolved as provenance, not a new negative-control invocation; the actual qualification driver and its source tuple are recorded separately.', ...
        'wrapper',struct('declared_seconds',1800,'save_post_reserve_seconds',180,'original_owned_fine_seconds',300,'maximum_owned_fine_requests',2,'fixed_budget',budget), ...
        'target_attempted',v.target_attempted,'target_attempt_ordinal',v.target_attempt_ordinal,'target_attempt',v.target_attempt, ...
        'whole_batch_closed_timely',v.whole_batch_closed_timely,'exact_target_owned_commit',false,'owned_point_index',[], ...
        'target_native_id','','original_records',{{}},'comparison',struct(),'saved_four_discrete_cohort_match',false, ...
        'fines',{{}},'fine_profile_requests',0,'fine_full_return_map_calls_attempted',0,'all_two_owned_fines_passed',false, ...
        'four_unique_original_profiles_verified',false,'all_four_original_fines_passed',false,'finite_unit_conditions_met',false, ...
        'periodic_root_attempts',0,'admissions',0,'journal_mutated',false,'raw_store_mutated',false,'catalogue_mutated',false, ...
        'canonical_graph_mutated',false,'frontier_status_changed',false,'global_endpoint_claimed',false,'owned_connection_claimed',false, ...
        'half_height_stop_claimed',false,'own_process_exit_observed',false,'completed',false,'failure',struct(),'status','prepared');
    try
        if ~v.whole_batch_closed_timely
            facts.status='whole_batch_original_timing_or_recovery_requires_review';
        elseif ~v.target_attempted
            if v.administrative_zero_attempt,facts.status='closed_zero_attempt_administrative_yield_target_not_attempted';
            else,facts.status='closed_target_not_attempted_native_outcome_retained';end
        elseif ~v.target_commit_eligible
            facts.status='exact_target_attempt_did_not_earn_a_timely_captured_owned_commit';
        else
            a=v.target_attempt;phase('target_native_selected_read2_begin',startClock,struct('source_point',484,'attempt',a.attempt,'requested_ds',v.target_step));
            ix=BranchSolutionFile_v3.index(core);assert(isequaln(source,reference(core)),'C1PKTarget:SourceRead','The current raw authority changed.');
            hits=[];for k=485:numel(ix.points)
                m=ix.points{k}.metadata;if isfield(m,'edge_enabled')&&isequal(m.edge_enabled,true)&&isfield(m,'edge_from')&&m.edge_from==484 ...
                        &&isfield(m,'provenance')&&isfield(m.provenance,'source_point')&&m.provenance.source_point==484 ...
                        &&isfield(m.provenance,'attempt')&&isequal(m.provenance.attempt,a.attempt),hits(end+1)=k;end %#ok<AGROW>
            end
            assert(isscalar(hits),'C1PKTarget:TargetIdentity','Select the exact target attempt provenance, never the final frontier pair.');ownedIndex=hits;
            [O,R,M]=BranchSolutionFile_v3.loadSolutions(core,[484 ownedIndex]);[P,S,T]=BranchSolutionFile_v3.loadSolutions(core,[484 ownedIndex]);
            assertPublicEqual(O,P,0);assertPublicEqual(M,T,0);assertPublicEqual(reportView(R),reportView(S),0);clear P S T
            ci=BranchSolutionFile_v3.index(catalogue);assert(numel(ci.points)==3&&isempty(ci.edges),'C1PKTarget:Catalogue','The negative unit is still isolated catalogue3.');
            [U,UR,UM]=BranchSolutionFile_v3.loadSolutions(catalogue,3);[P,S,T]=BranchSolutionFile_v3.loadSolutions(catalogue,3);
            assertPublicEqual(U,P,0);assertPublicEqual(UM,T,0);assertPublicEqual(reportView(UR),reportView(S),0);clear P S T
            assertPublicEqual(record(O{1},R{1},M{1},ix.points{484}),control.original_records{2},0);
            assertPublicEqual(record(U{1},UR{1},UM{1},ci.points{3}),control.candidate_record,0);
            hit=find(cellfun(@(e)e.from==484&&e.to==ownedIndex&&strcmp(e.component_identity,M{1}.component_identity)&&strcmp(e.component_identity,M{2}.component_identity),ix.edges));assert(isscalar(hit),'C1PKTarget:OwnedEdge','Observe only the actual earned target physical edge.');
            provenance=M{2}.provenance;assert(M{2}.edge_enabled&&M{2}.edge_from==484&&provenance.source_point==484 ...
                &&isequal(provenance.attempt,a.attempt)&&isequaln(provenance.capture,a.capture) ...
                &&isequaln(provenance.corrector_initialization,a.corrector_initialization) ...
                &&strcmp(provenance.corrector_initialization.method,'predictor-energy') ...
                &&isequaln(provenance.corrector_initialization.capture_predictor_state,a.predictor_state), ...
                'C1PKTarget:AttemptProvenance','Bind the actual target capture and native initializer without a copied NONEDGE state.');
            [~,pb]=admitted(O{1},R{1});[~,po]=admitted(O{2},R{2});[~,pu]=admitted(U{1},UR{1});assertPrimitive(R{1});assertPrimitive(R{2});assertPrimitive(UR{1});
            assert(isequaln(pb.configuration,po.configuration)&&isequaln(po.configuration,pu.configuration) ...
                &&isequaln(O{1}.parameter,O{2}.parameter)&&isequaln(O{1}.initial_mode,O{2}.initial_mode) ...
                &&strcmp(OrbitContentIdentity_v3(U{1}),control.candidate_native_id)&&~UM{1}.edge_enabled, ...
                'C1PKTarget:Policy','Keep complete native parameter/mode/BL policy and isolated control identity.');
            facts.exact_target_owned_commit=true;facts.owned_point_index=ownedIndex;facts.target_native_id=OrbitContentIdentity_v3(O{2});facts.actual_earned_physical_edge=ix.edges{hit};
            facts.original_records={record(O{2},R{2},M{2},ix.points{ownedIndex});record(U{1},UR{1},UM{1},ci.points{3})};facts.target_root_solver_facts=rootFacts(R{2});
            s=QuadrupedSchema_v3.shared();facts.actual_owned_observables=struct('marked_height',O{2}.initial_state(s.State.y),'rest_length',O{2}.parameter(s.Parameter.l_l_b),'period',O{2}.period,'full14_stride',O{2}.stride_displacement,'signed_apex_dx',O{2}.initial_state(s.State.dx),'native_energy',QuadrupedEnergy_v3.evaluate(O{2}.initial_state,O{2}.initial_mode,O{2}.parameter));
            facts.comparison=localComparison(O{2},U{1},R{2},UR{1});facts.saved_four_discrete_cohort_match=sameCohort(O{2},U{1});
            phase('target_cheap_comparison_returned',startClock,struct('index',ownedIndex,'NativeID',facts.target_native_id,'conditions_met',facts.comparison.conditions_met));
            if ~facts.comparison.conditions_met
                facts.status='exact_owned_target_not_close_enough_no_owned_fines';
            else
                [service,live,runtimeAudit]=controlService(UR{1},control,work);facts.common_fresh_service_reconstruction=runtimeAudit;
                verifySources(budget,epoch,[refs;historicalMethods],guards,work);assert(left(work)>2*300+60,'C1PKTarget:FineCapsFit','Both full original300-second owned profiles must fit before the first one.');steps=[.0005 .00025];
                seed=struct('state',O{2}.initial_state,'mode',O{2}.initial_mode,'parameter',O{2}.parameter,'return_policy',service.correction_return_policy,'occurrence',1);
                for level=1:2
                    verifySources(budget,epoch,[refs;historicalMethods],guards,work);assert(left(work)>300,'C1PKTarget:FineFit','Never shorten an original300 fine.');limit=fineLimit(300,budget,work);
                    facts.fine_profile_requests=facts.fine_profile_requests+1;phase('target_owned_original_fine_begin',startClock,struct('side',2,'level',level,'MaxStep',steps(level),'full_cap_seconds',300));
                    [fine,ev,g]=C1PlainFineQualificationReplay_v3(seed,steps(level),service,limit);timely=utc()<limit.deadline_unix_seconds&&nano()<limit.deadline_monotonic_ns;
                    facts.fine_full_return_map_calls_attempted=facts.fine_full_return_map_calls_attempted+double(ev.map_complete||strcmp(ev.phase_at_failure,'map'));
                    item=negativeFineObservation(fine,ev,g,seed,O{2},2,level,live,steps(level),timely,control.common_fine_service_contract.BL_policy_configuration);
                    item.seed_native_id=facts.target_native_id;item.common_service_contract_digest=control.common_fine_service_contract_digest;facts.fines{end+1,1}=item;
                    phase('target_owned_original_fine_returned',startClock,struct('side',2,'level',level,'timely',timely,'passed',item.all_declared_conditions_met));clear fine ev g item
                end
                facts.all_two_owned_fines_passed=numel(facts.fines)==2&&all(cellfun(@(x)x.all_declared_conditions_met&&x.timely_observed,facts.fines));
                facts.four_unique_original_profiles_verified=fourProfiles(control.fines,facts.fines,control.common_fine_service_contract_digest,facts.target_native_id);
                facts.all_four_original_fines_passed=control.all_two_control_fines_passed&&facts.all_two_owned_fines_passed&&facts.four_unique_original_profiles_verified;
                facts.finite_unit_conditions_met=facts.exact_target_owned_commit&&facts.comparison.conditions_met&&facts.saved_four_discrete_cohort_match&&facts.all_four_original_fines_passed;
                facts.status='two_new_owned_profiles_joined_to_two_original_closed_control_profiles';
            end
        end
    catch problem,facts.failure=exceptionData(problem);facts.status='partial_or_refused';end
    clear O R M P S T U UR UM ix ci service live seed fine ev g provenance pb po pu a
    facts.completed=true;facts.finished_utc=stamp();facts.elapsed_seconds=(nano()-startClock.m)/1e9;
    facts.root_fact_scope='Saved actual Root facts only; zero iterations or unavailable J remain literal. No Root or FD repair is performed or certified.';
    facts.scope='Finite comparison of one exact actually owned target with a separately admitted negative NONEDGE unit control. Historical control2 and new owned2 are four distinct original profiles under one verified common contract, not four new profiles or freshly reconstructed cross-orbit cohort tokens. No endpoint, exact grazing, H<.5, branch completion, new canonical seam or status authorization is inferred.';
    verifySources(budget,epoch,[refs;historicalMethods],guards,finish);verifyMethodResolvers([refs;historicalMethods]);closedTargetPaths(paths,finish);
    verifiedEvidenceClosure(witness,ownedProjection,'C1_PK_NEW36H_BATCH_ACTUAL_RETURN ',root);verifiedEvidenceClosure(controlWitness,controlProjection,'C1_PK_NEGATIVE_UNIT_CONTROL_ACTUAL_RETURN ',root);
    assert(strcmp(RoundSHA256_v3(output),roundBefore.sha256)&&strcmp(RoundSHA256_v3(json),jsonBefore.sha256),'C1PKTarget:RoundClosest','Retain any changed Round for explicit review.');
    phase('target_Round_publication_begin',startClock,struct('status',facts.status));round.primary_diagnostics.owned_negative_target_unit_qualification=facts;saveRound(output,json,round);clear round
    verifySources(budget,epoch,[refs;historicalMethods],guards,finish);closedTargetPaths(paths,finish);
    verifiedEvidenceClosure(witness,ownedProjection,'C1_PK_NEW36H_BATCH_ACTUAL_RETURN ',root);verifiedEvidenceClosure(controlWitness,controlProjection,'C1_PK_NEGATIVE_UNIT_CONTROL_ACTUAL_RETURN ',root);
    small=targetStdout(facts);text=jsonencode(small);assert(numel(unicode2native(text,'UTF-8'))<=100000,'C1PKTarget:Stdout','Full facts stay in one native Round field.');check(finish);fprintf('C1_PK_OWNED_TARGET_UNIT_QUALIFICATION_ACTUAL_RETURN %s\n',text);check(finish);
end
function v=targetJournalView(j,round,core,budget,ledgerRef,rawRef)
    assert(strcmp(j.schema,'C1-persistent-PK-frontier-ledger-v1')&&isempty(fieldnames(j.active_run))&&isequaln(j.active_budget,budget) ...
        &&~strcmp(j.status,'native_pending_requires_reconciliation'),'C1PKTarget:ClosedJournal','Reconcile actual active/pending custody first.');
    if isfield(j.last_run_full,'pending_admission'),assert(isempty(fieldnames(j.last_run_full.pending_admission)),'C1PKTarget:PendingAdmission','No unresolved accepted native payload may enter this observer.');end
    at=find(cellfun(@(f)strcmp(f.id,'PK_file_0006_graph_0001_leaf_000086'),j.frontiers));assert(isscalar(at),'C1PKTarget:Frontier','Only the declared86 target is eligible.');f=j.frontiers{at};
    assert(strcmp(f.component_file,core)&&isequaln(f.source_reference,rawRef)&&ismember(f.strategy_index,1:3),'C1PKTarget:FrontierSource','Bind the actual postbatch frontier without treating its finalpair as the target.');
    a=[];for k=numel(j.ordinary_initializer_authorizations):-1:1,x=j.ordinary_initializer_authorizations{k};if strcmp(x.frontier_id,f.id),a=x;break;end;end
    assert(~isempty(a)&&strcmp(a.authorization_id,'PK36h20261031-Negative86-OrdinaryInitializer-Target01') ...
        &&strcmp(a.mode,'ordinary')&&strcmp(a.phase,'ordinary_authorized')&&strcmp(a.initializer,'predictor-energy') ...
        &&strcmp(a.grant_id,budget.grant_id)&&isequaln(a.source_code,j.source_code)&&isequal(a.pilot_source_pair,[483 484]) ...
        &&isequal(a.pilot_step,4.1883804439521584e-7)&&a.pilot_derivative_index==1 ...
        &&strcmp(C1ScientificDigest_v3(a.evidence),a.evidence_digest),'C1PKTarget:Authorization','Require the exact digest-bound Target01 prospective policy.');
    d=a.evidence.target_step_declaration;assert(isequal(d.target_step,a.pilot_step)&&isequal(d.factor,.9999) ...
        &&isequal(d.stored_signed_projection,4.1887993238845468e-7)&&isequal(d.target_step,d.factor*d.stored_signed_projection) ...
        &&strcmp(a.evidence.actual_transition_source_reference.sha256,'94e3d9f3502d7ea28a7655786c9daccb1312ee37421afea6ac97b50977b1fc08'), ...
        'C1PKTarget:DeclaredStep','The exact attempted ds must match the actual adopted target declaration.');
    options=j.options;assert(options.BatchAccepted==4&&options.BatchAttempts==12&&options.TrialSeconds==240 ...
        &&options.MinimumApexHeightRatio==.5&&~options.StopOnRangeCoverage&&~options.ReusePreviousJacobian,'C1PKTarget:Options','Global4/12 and the unchanged user policy remain literal.');
    hits=[];for k=1:numel(round.rows),b=round.rows{k};if strcmp(b.frontier_before.frontier_id,f.id) ...
        &&isequal(b.frontier_before.source_pair,a.pilot_source_pair)&&isequal(b.frontier_before.step,a.pilot_step),hits(end+1)=k;end;end %#ok<AGROW>
    assert(isscalar(hits),'C1PKTarget:BatchUnique','Require the one closed selected batch starting at the exact declared pair/step.');b=round.rows{hits};
    assert(strcmp(b.schema,'C1-PK-one-selected-batch-v1')&&strcmp(b.source_reference.sha256,'5fb865e7ef50b480a0e177d127021174e79386ecd5761d439f47bdba7bf10551') ...
        &&strcmp(b.source_reference.file,fullfile(fileparts(fileparts(ledgerRef.file)),'RunC1PKRoundBatch20261031_v3.m')) ...
        &&strcmp(b.ledger_after.file,ledgerRef.file)&&strcmp(b.core_after.file,rawRef.file)&&isequaln(b.core_after,rawRef) ...
        &&isequaln(b.options_after,options)&&ismember(b.frontier_before.strategy_index,[1 2]) ...
        &&b.frontier_before.strategy_index==a.prior_frontier.strategy_index&&b.frontier_before.derivative_index==a.pilot_derivative_index ...
        &&b.public_resume_options.MaxBatches==1&&b.public_resume_options.MaxWallSeconds==1800 ...
        &&~b.public_resume_options.AdoptNewGrant&&strcmp(b.public_resume_options.PreferredFrontierID,f.id), ...
        'C1PKTarget:Batch','Join the actual canonical selected batch without demanding it be the latest global row.');
    clean=b.public_call_returned&&b.return_within_public1800_observed&&b.counts_known&&isempty(fieldnames(b.failure)) ...
        &&~b.active_run_present&&~b.unresolved_dispatch_or_stage_present&&~b.file_pending_present;
    attempts=cell(0,1);runIndex=[];runSequence=[];runStatus='not_dispatched';runFailureHeader=struct();administrativeZero=false;registered=struct();returned=false;persistence=false;recovery=struct();targetAttempt=struct();targetOrdinal=[];targetAttempted=false;eligible=false;
    if b.sequence>b.frontier_before.sequence
        runIndex=find(cellfun(@(r)strcmp(r.frontier_id,f.id)&&isequal(r.sequence,b.sequence),j.runs));assert(isscalar(runIndex),'C1PKTarget:RunUnique','Require the actual unique canonical run key.');r=j.runs{runIndex};runSequence=r.sequence;
        if isfield(r,'literal_pending_metadata'),assert(~isempty(fieldnames(r.committed_append_recovery)),'C1PKTarget:RunPending','Unreconciled pending metadata is ineligible; a closed recovered append remains literal nonqualification.');end
        assert(b.sequence==b.frontier_before.sequence+1&&b.new_points==r.actual_committed_new_points_observed ...
            &&b.new_edges==r.actual_committed_new_edges_observed&&f.last_dispatched_sequence==r.sequence ...
            &&isequal(r.current_pair,f.source_pair)&&strcmp(r.configuration.source_file,core) ...
            &&isequal(r.configuration.source_indices,a.pilot_source_pair)&&strcmp(r.configuration.symmetry,'pronk') ...
            &&isequal(r.configuration.in_place,true)&&strcmp(r.corrector_initializer,'predictor-energy') ...
            &&r.registered_strategy.MaxAccepted==4&&r.registered_strategy.MaxAttempts==12 ...
            &&strcmp(r.registered_strategy.Algorithm,'root-newton')&&r.registered_strategy.TrialSeconds==240 ...
            &&r.registered_strategy.MaxWallSeconds==900&&~r.registered_strategy.ReusePreviousJacobian ...
            &&r.registered_strategy.InitialDerivativeIndex==a.pilot_derivative_index ...
            &&isequal(r.registered_strategy.InitialStep,a.pilot_step)&&strcmp(r.registered_strategy.CorrectorInitializer,'predictor-energy') ...
            &&strcmp(r.ordinary_initializer_authorization.authorization_id,a.authorization_id) ...
            &&strcmp(r.ordinary_initializer_authorization.pilot_id,a.pilot_id)&&strcmp(r.ordinary_initializer_authorization.mode,'ordinary') ...
            &&numel(r.attempts)==b.root_attempt_count,'C1PKTarget:ActualRun','Join actual ordinary global4/12 dispatch and local postbatch state.');
        claim=r.ordinary_initializer_authorization;assert(isa(claim.registry_index,'double')&&isscalar(claim.registry_index) ...
            &&isfinite(claim.registry_index)&&claim.registry_index>=1&&claim.registry_index==fix(claim.registry_index) ...
            &&claim.registry_index<=numel(j.ordinary_initializer_authorizations) ...
            &&isequaln(j.ordinary_initializer_authorizations{claim.registry_index},a),'C1PKTarget:RegistryJoin','Bind the actual dispatched current authorization by its literal registry identity.');
        registered=r.registered_strategy;returned=r.original_child_return_observed;persistence=r.persistence_completion_confirmed;recovery=r.committed_append_recovery;runStatus=r.status;
        runFailureHeader=pick(r.failure,{'identifier','message'});
        for key={'identifier','message'}
            name=key{1};if isfield(runFailureHeader,name),value=runFailureHeader.(name);assert(ischar(value)&&(isrow(value)||isempty(value)),'C1PKTarget:FailureHeader','The known canonical failure header must retain literal text.');runFailureHeader.(name)=value(1:min(4096,numel(value)));runFailureHeader.([name '_original_characters'])=numel(value);runFailureHeader.([name '_complete'])=numel(value)<=4096;end
        end
        if isfield(r,'scheduler_administrative_yield')
            y=r.scheduler_administrative_yield;assert(strcmp(y.schema,'C1-zero-attempt-administrative-yield-v1') ...
                &&y.root_attempts==0&&isequal(y.control_state_unchanged,true)&&isempty(r.attempts) ...
                &&b.new_points==0&&b.new_edges==0,'C1PKTarget:AdministrativeZero','Only the canonical native administrative-yield proof earns that label.');administrativeZero=true;
        end
        clean=clean&&isequal(returned,true)&&isequal(persistence,true)&&isempty(fieldnames(recovery));
        for k=1:numel(r.attempts)
            x=r.attempts{k};row=b.attempts{k};for key={'attempt','status','all_nine','edge_committed','timely','storage_attempted','storage_timely','isolated_committed','isolated_storage_timely','step','derivative_method','relative_step','algorithm'},assertPublicEqual(row.(key{1}),x.(key{1}),0);end
            attempts{k,1}=pick(x,{'attempt','source_point','step','status','algorithm','derivative_method','relative_step','all_nine','timely','edge_committed','storage_attempted','storage_timely','isolated_committed','isolated_storage_timely','capture','corrector_initialization','predictor_state','constraint','wrapper_failure'});
            if x.source_point==484&&isequal(x.step,a.pilot_step),assert(isempty(targetOrdinal),'C1PKTarget:TargetUnique','Never choose a duplicate target attempt.');targetOrdinal=k;targetAttempt=attempts{k};targetAttempted=true;end
        end
        if targetAttempted
            assert(targetOrdinal==1&&isequal(targetAttempt.step,4.1883804439521584e-7)&&strcmp(targetAttempt.corrector_initialization.method,'predictor-energy'), ...
                'C1PKTarget:FirstTarget','The first actual native attempt must be the exact prospective target, not a later shrunken point.');
            c=targetAttempt.capture;eligible=targetAttempt.all_nine&&targetAttempt.timely&&targetAttempt.edge_committed ...
                &&targetAttempt.storage_attempted&&isequal(targetAttempt.storage_timely,true)&&~targetAttempt.isolated_committed ...
                &&isempty(targetAttempt.isolated_storage_timely)&&isfield(c,'requested_progress')&&isequal(c.requested_progress,a.pilot_step) ...
                &&c.full13_scaled_inf<c.radius&&c.radius==.02&&c.achieved_state_progress>1e-8&&c.distinct_state_distance>1e-8 ...
                &&abs(c.PAL_error)<=1e-8&&c.section_compatible;
        else,assert(isempty(r.attempts),'C1PKTarget:WrongAttempt','A nonzero batch without the declared first target requires protocol review.');end
    else
        assert(b.sequence==b.frontier_before.sequence&&b.root_attempt_count==0&&b.new_points==0&&b.new_edges==0,'C1PKTarget:NoDispatch','No canonical dispatch can only be reported as zero-attempt nonqualification.');
    end
    v=struct('source_code',{j.source_code},'options',options,'frontier',pick(f,{'id','component_file','source_reference','source_pair','status','step','strategy_index','derivative_index','last_dispatched_sequence','last_accepted_index','initial_state','initial_mode','last_stop_reason'}), ...
        'authorization',pick(a,{'schema','authorization_id','frontier_id','component_file','grant_id','source_code','mode','phase','pilot_id','pilot_source_pair','pilot_step','pilot_derivative_index','evidence_digest','adoption_source_reference'}), ...
        'target_step',a.pilot_step,'control_qualification_digest',C1ScientificDigest_v3(a.evidence.control_qualification), ...
        'control_closure',a.evidence.control_closure,'actual_transition_source_reference',a.evidence.actual_transition_source_reference, ...
        'batch',b,'run_sequence',runSequence,'run_index',runIndex,'run_status',runStatus,'run_failure_header',runFailureHeader, ...
        'administrative_zero_attempt',administrativeZero,'registered_options',registered,'original_return',returned, ...
        'persistence_confirmed',persistence,'recovery',recovery,'attempts',{attempts},'target_attempted',targetAttempted, ...
        'target_attempt_ordinal',targetOrdinal,'target_attempt',targetAttempt,'target_commit_eligible',eligible,'whole_batch_closed_timely',clean);
end
function validateHistoricalControl(q,v,catalogueRef,budget)
    assert(strcmp(q.schema,'C1-PK-negative-fixed-height-NONEDGE-control-v1')&&strcmp(q.source_reference.sha256,'876bba14be23e4ba27cb708cb2a312b1703aa81b52c8aedf448f3e2c7af076e5') ...
        &&strcmp(C1ScientificDigest_v3(q),v.control_qualification_digest)&&isequaln(q.catalogue_reference,catalogueRef) ...
        &&q.completed&&q.root_returned&&q.root_all_nine&&q.root_timely_observed&&q.candidate_saved_PK1_primitive ...
        &&q.catalogue_committed&&q.catalogue_index==3&&q.catalogue_read2_verified&&q.catalogue_original_two_preservation_verified ...
        &&q.catalogue_storage_timely_observed&&~q.pending_admission_retained&&~q.pending_file_present&&isempty(fieldnames(q.failure)) ...
        &&q.all_two_control_fines_passed&&numel(q.fines)==2&&isequaln(q.wrapper.fixed_budget,budget), ...
        'C1PKTarget:HistoricalControl','Require the literal closed0050 control proof and unchanged live catalogue, not current rehashes of its historical raw/j-before references.');
    c=q.common_fine_service_contract;assert(strcmp(c.schema,'C1-negative-unit-common-fine-service-v1')&&strcmp(C1ScientificDigest_v3(c),q.common_fine_service_contract_digest) ...
        &&isequal(c.profile_steps,[.0005 .00025])&&c.original_profile_cap_seconds==300,'C1PKTarget:ControlContract','Retain the frozen common service.');
    levels=zeros(1,2);for k=1:2,x=q.fines{k};levels(k)=x.original_profile_level;assert(x.side==1&&strcmp(x.side_name,'negative_control') ...
        &&x.all_declared_conditions_met&&x.timely_observed&&x.initial_trajectory_row_exact&&x.qualified_PK1_primitive ...
        &&x.map_complete&&x.classifier_complete&&x.completed_scalar_sample_count==x.sample_count&&x.fine.passed ...
        &&~x.fine.budget_refusal&&isempty(fieldnames(x.fine.failure))&&x.fine.MaxStep==c.profile_steps(x.original_profile_level), ...
        'C1PKTarget:ControlFine','Each original closed control fine must remain complete and timely.');end
    assert(isequal(sort(levels),[1 2]),'C1PKTarget:ControlLevels','The two original control profiles are distinct.');
end
function [service,live,audit]=controlService(report,q,work)
    c=q.common_fine_service_contract;[live,reconstruction]=freshIntegration(report.replay_integration,work);[~,savedPolicy]=RecordedReturnPolicy_v3(report);
    assert(savedPolicy.complete&&isequaln(savedPolicy.configuration,c.BL_policy_configuration),'C1PKTarget:ServicePolicy','Reconstruct the exact control-derived policy.');
    policy=BLMarkedApexReturnPolicy_v3(rmfield(c.BL_policy_configuration.settings,'Name'));[~,actual]=RecordedReturnPolicy_v3(struct('correction_return_policy',policy));
    assert(actual.complete&&isequaln(actual.configuration,c.BL_policy_configuration),'C1PKTarget:PolicyRoundtrip','The fresh policy must preserve every declared setting.');
    rebuilt=c;rebuilt.numeric_integration=reconstruction.all_other_integration_settings;rebuilt.numeric_ODE_options=reconstruction.all_other_ODE_options;
    rebuilt.solver='ode45';rebuilt.acceptance=report.acceptance;rebuilt.map_limits=pick(report.options,{'MaxReturnTime','MaxCycleEvents','MaxSectionCrossings'});rebuilt.BL_policy_configuration=actual.configuration;rebuilt.event_signature=report.event_signature;
    assert(strcmp(C1ScientificDigest_v3(rebuilt),q.common_fine_service_contract_digest),'C1PKTarget:ExactService','Every numeric/settings/event/method contract value must equal the frozen control-derived service; only the deadline callback is fresh.');
    service=struct('replay_integration',live,'correction_return_policy',policy,'options',rebuilt.map_limits,'acceptance',report.acceptance,'classification',report.classification,'event_signature',report.event_signature);
    audit=struct('exact_frozen_contract_digest',q.common_fine_service_contract_digest,'runtime_reconstruction',reconstruction,'actual_policy_configuration',actual.configuration, ...
        'historical_called_method_references',{c.called_method_references},'fresh_deadline_only',true,'original_saved_callback_executed',false,'control_orbit_replayed_here',false);
end
function yes=fourProfiles(control,owned,digest,nativeID)
    keys=zeros(0,2);yes=numel(control)==2&&numel(owned)==2;
    for k=1:numel(control),x=control{k};keys(end+1,:)=[x.side x.original_profile_level];yes=yes&&x.side==1&&x.all_declared_conditions_met&&x.timely_observed;end %#ok<AGROW>
    for k=1:numel(owned),x=owned{k};keys(end+1,:)=[x.side x.original_profile_level];yes=yes&&x.side==2&&x.all_declared_conditions_met&&x.timely_observed&&strcmp(x.common_service_contract_digest,digest)&&strcmp(x.seed_native_id,nativeID);end %#ok<AGROW>
    yes=yes&&isequal(sortrows(keys),[1 1;1 2;2 1;2 2]);
end
function closedTargetPaths(paths,limit)
    check(limit);for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'C1PKTarget:Pending','Reconcile native active/pending custody first: %s',paths{k});end
end
function verifyMethodResolvers(refs)
    for k=1:numel(refs),r=refs{k};[~,name,ext]=fileparts(r.file);assert(strcmp(ext,'.m')&&strcmp(char(java.io.File(which(name)).getCanonicalPath()),char(java.io.File(r.file).getCanonicalPath())), ...
        'C1PKTarget:Resolver','A declared current or provenance method resolves elsewhere: %s',r.file);end
end
function small=targetStdout(f)
    small=pick(f,{'schema','source_reference','journal_reference','raw_source_reference','round_before_reference','catalogue_reference','authorization','target_step','canonical_run_sequence','canonical_run_index','canonical_run_status','canonical_run_failure_header','administrative_zero_attempt','original_child_return_observed','canonical_persistence_completion_confirmed','target_attempted','target_attempt_ordinal','whole_batch_closed_timely','exact_target_owned_commit','owned_point_index','target_native_id','actual_owned_observables','comparison','saved_four_discrete_cohort_match','common_service_contract_digest','fine_profile_requests','fine_full_return_map_calls_attempted','all_two_owned_fines_passed','four_unique_original_profiles_verified','all_four_original_fines_passed','finite_unit_conditions_met','periodic_root_attempts','admissions','journal_mutated','raw_store_mutated','catalogue_mutated','canonical_graph_mutated','frontier_status_changed','global_endpoint_claimed','owned_connection_claimed','half_height_stop_claimed','own_process_exit_observed','completed','failure','status','finished_utc','elapsed_seconds','root_fact_scope','scope'});
    small.target_attempt=pick(f.target_attempt,{'attempt','source_point','step','status','algorithm','derivative_method','relative_step','all_nine','timely','edge_committed','storage_attempted','storage_timely','isolated_committed','isolated_storage_timely','capture'});
    small.fines=cell(size(f.fines));for k=1:numel(f.fines),x=f.fines{k};r=pick(x,{'side','side_name','original_profile_level','timely_observed','initial_trajectory_row_exact','qualified_PK1_primitive','saved_period_scaled_error','saved_full14_stride_scaled_error','map_complete','classifier_complete','sample_count','completed_scalar_sample_count','all_declared_conditions_met','seed_native_id','common_service_contract_digest'});r.fine=pick(x.fine,{'MaxStep','passed','status','budget_refusal','failure','full13_norm','period','maximum_energy_variation','maximum_stance_constraint'});small.fines{k}=r;end
end
function verifySources(budget,epoch,refs,guards,limit)
    check(limit);assert(isequaln(C1RunBudget_v3(),budget),'C1PKNegative:Budget','The original grant VALUE changed.');methods=[epoch(:);refs(:)];for k=1:numel(methods),r=methods{k};[~,name,extension]=fileparts(r.file);actual=which(name);assert(strcmp(extension,'.m')&&~isempty(actual)&&strcmp(char(java.io.File(actual).getCanonicalPath()),char(java.io.File(r.file).getCanonicalPath())),'C1PKNegative:Resolver','An actual called/source resolver differs: %s',r.file);end
    allRefs=[methods;guards(:)];for k=1:numel(allRefs),r=allRefs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1PKNegative:Source','A protected source or authority changed: %s',r.file);end;check(limit);
end
function out=negativeFineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration)
    out=fineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration);names={'negative_control','owned_negative_C'};out.side_name=names{side};
end
function small=negativeStdout(facts)
    small=pick(facts,{'schema','experiment_id','source_reference','journal_reference','raw_source_reference','round_before_reference','unit_control_reference','catalogue_before_reference','periodic_solver_calls_attempted','root_returned','root_all_nine','root_timely_observed','actual_RootSolver_return_present','root_solver_facts','root_status','original_PSS_headers','actual_control_marked_height','actual_control_height_error','candidate_native_id','candidate_saved_PK1_primitive','catalogue_append_attempted','catalogue_committed','catalogue_index','catalogue_reference','catalogue_read2_verified','catalogue_original_two_preservation_verified','catalogue_storage_timely_observed','pending_save_attempted','pending_saved_read2_verified','pending_admission_retained','pending_file_present','comparison','fine_split_decision','common_fine_service_contract_digest','fine_profile_requests','fine_full_return_map_calls_attempted','all_two_control_fines_passed','all_four_original_fines_passed','finite_unit_conditions_met','report_sample_retention','failure','status','completed','journal_mutated','raw_store_mutated','physical_edges_added','canonical_graph_mutated','global_endpoint_claimed','owned_connection_claimed','half_height_stop_claimed','own_process_exit_observed','finished_utc','elapsed_seconds','scope','root_fact_scope'});
    if isfield(facts,'definition'),small.definition=pick(facts.definition,{'family_symmetry','nCoord','nAug','maximum_function_calls_per_fresh_valid_sided_J','height_coordinate_position','energy_C','marked_height_C','target_height','requested_height_step','Einitial','exact_seed_roundtrip'});end
    for key={'production_geometry_seed','production_geometry_control'},name=key{1};if isfield(facts,name),small.(name)=pick(facts.(name),{'signed_PAL_projection','scaled_coordinate_separation','full13_capture_scaled_inf','capture_radius','control_roundtrip_exact','current_frontier_step','frontier_minimum_step','global_minimum_step','positive_direction','within_current_step_bounds','sign_or_absolute_value_repair_applied'});end;end
    small.fines=cell(size(facts.fines));for k=1:numel(facts.fines),f=facts.fines{k};q=pick(f,{'side','side_name','original_profile_level','timely_observed','initial_trajectory_row_exact','qualified_PK1_primitive','saved_period_scaled_error','saved_full14_stride_scaled_error','map_complete','classifier_complete','sample_count','completed_scalar_sample_count','failure_phase','timings','effective_ODE_profile','all_declared_conditions_met'});q.fine=pick(f.fine,{'MaxStep','passed','status','budget_refusal','failure','full13_norm','period','maximum_energy_variation','maximum_stance_constraint'});q.classification_header=pick(f.actual_full_classification,{'contract_version','validated_gait_type','canonical_label_qualified','flight_count','flight_count_certain','status'});if isfield(f.actual_full_classification,'primitive'),q.primitive_header=pick(f.actual_full_classification.primitive,{'status','cover_count','checked_cover_bound','primitive_period','global_primitivity_proved'});end;small.fines{k}=q;end
end

function assertPrimitive(r)
    assert(isfield(r,'primitive')&&strcmp(r.primitive.status,'primitive_within_checked_bound'),'C1PKE0:Primitive','Retain an actually checked primitive result independently of the optional primitive gate.');
end
function out=fineObservation(fine,ev,g,seed,original,side,level,integration,step,timely,configuration)
    returnedPolicy=isfield(fine,'actual_policy');if returnedPolicy,[~,used]=RecordedReturnPolicy_v3(struct('correction_return_policy',fine.actual_policy));assert(used.complete&&isequaln(used.configuration,configuration),'C1PKE0:FinePolicy','Fresh fine changed the actual return policy.');fine.actual_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',configuration.source_class,'settings',configuration.settings);end
    firstExact=ev.sample_count>0&&isequaln(ev.trajectory.state(1,:).',seed.state)&&isequaln(logical(ev.trajectory.mode(1,:).'),logical(seed.mode));periodError=NaN;strideError=NaN;if isfield(fine,'period'),periodError=abs(fine.period-original.period)/max([1,abs(fine.period),abs(original.period)]);end;if isfield(fine,'stride_displacement'),sx=max([ones(14,1),abs(fine.stride_displacement(:)),abs(original.stride_displacement(:))],[],2);strideError=norm((fine.stride_displacement(:)-original.stride_displacement(:))./sx,Inf);end
    names={'candidate','original_unit'};out=struct('side',side,'side_name',names{side},'original_profile_level',level,'fine',fine,'actual_full_classification',g,'timely_observed',timely,'initial_trajectory_row_exact',firstExact,'qualified_PK1_primitive',qualified(g),'saved_period_scaled_error',periodError,'saved_full14_stride_scaled_error',strideError,'map_complete',ev.map_complete,'classifier_complete',ev.classifier_complete,'sample_count',ev.sample_count,'completed_scalar_sample_count',ev.completed_scalar_sample_count,'failure_phase',ev.phase_at_failure,'timings',ev.timings,'effective_ODE_profile',effectiveProfile(integration,step),'all_declared_conditions_met',fine.passed&&timely&&qualified(g)&&firstExact&&returnedPolicy&&ev.map_complete&&ev.classifier_complete&&ev.completed_scalar_sample_count==ev.sample_count&&periodError<=1e-8&&strideError<=1e-8);
end
function phase(name,start,extra)
    item=struct('phase',name,'utc',stamp(),'outer_elapsed_seconds',(nano()-start.m)/1e9,'detail',extra);text=jsonencode(item);assert(numel(unicode2native(text,'UTF-8'))<=10000,'C1PKE0:PhaseOutput','Stage marker exceeded its declared bound.');fprintf('C1_PK_E0_STAGE %s\n',text);
end
function out=record(o,r,m,ix)
    out=struct('index',ix.index,'owner',ix.component_identity,'owner_order',ix.order,'native_id',OrbitContentIdentity_v3(o),'initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'full14_stride',o.stride_displacement,'metadata',m,'saved_all_nine',r.acceptance_gates,'saved_classification',r.classification,'saved_primitive',r.primitive);
end

function out=rootFacts(r)
    out=struct('available',isfield(r,'solver'));if ~out.available,return;end;s=r.solver;out.literal=pick(s,{'solver','exitflag','converged','residualNorm','functionEvaluationCount','mapEvaluationCount','cacheHitCount','invalidEvaluationCount','jacobianEvaluationCount','derivativeModel','derivativeEvaluated','acceptedNewtonIterations','invalidTrialCount','stateScale','finalJacobian','jacobianReliable','selectedFiniteDifferenceSteps','perColumnReliability'});if isfield(s,'output'),out.output=pick(s.output,{'iterations','funcCount','algorithm','rootTolerance','stepsize','acceptedIterations','invalidTrialCount','initialJacobianUsed','RootNewtonMinimumRcond','lastReciprocalCondition','lastLinearRelativeBackwardError','finalJacobianFreshAtFinalState','message'});end
end

function out=reportView(reports)
    out=cell(size(reports));for k=1:numel(reports),out{k}=pick(reports{k},{'status','accepted','native_status','classification','primitive','acceptance','acceptance_gates','replay_integration','event_signature','correction_return_policy','options'});out{k}.bounded_root_facts=rootFacts(reports{k});end
end

function yes=sameCohort(a,b)
    yes=true;for key={'section_relative_event_signature','cyclic_event_signature','event_cluster_signature','cyclic_event_cluster_signature'},x=a.(key{1});y=b.(key{1});yes=yes&&strlength(string(x))>0&&strlength(string(y))>0&&strcmp(string(x),string(y));end
end

function out=localComparison(a,b,ra,rb)
    dx=a.initial_state(2:14)-b.initial_state(2:14);sx=max([ones(13,1),abs(a.initial_state(2:14)),abs(b.initial_state(2:14))],[],2);dt=a.period-b.period;ts=max([1,abs(a.period),abs(b.period)]);dq=a.stride_displacement(:)-b.stride_displacement(:);qs=max([ones(14,1),abs(a.stride_displacement(:)),abs(b.stride_displacement(:))],[],2);match=MatchingReturnSection_v3(a,b,{ra,rb});[~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);
    out=struct('raw_full13_delta',dx,'raw_full13_scaled_inf',norm(dx./sx,inf),'period_delta',dt,'period_tolerance',1e-10*ts,'full14_stride_delta',dq,'full14_stride_tolerance',1e-10*qs,'native_energy_delta',QuadrupedEnergy_v3.evaluate(a.initial_state,a.initial_mode,a.parameter)-QuadrupedEnergy_v3.evaluate(b.initial_state,b.initial_mode,b.parameter),'exact_state_equal',isequaln(a.initial_state,b.initial_state),'exact_p_q_equal',isequaln(a.parameter,b.parameter)&&isequaln(a.initial_mode,b.initial_mode),'matching_section',match,'exact_complete_policy_equal',pa.complete&&pb.complete&&isequaln(pa.configuration,pb.configuration),'saved_four_discrete_cohort_match',sameCohort(a,b),'conditions_met',false);
    out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full14_stride_tolerance)&&out.exact_p_q_equal&&match.compatible&&out.exact_complete_policy_equal&&out.saved_four_discrete_cohort_match;
end

function [live,audit]=freshIntegration(saved,limit)
    native=HybridSimulator_v3();defaults=native.Options;assert(isstruct(saved)&&isscalar(saved)&&isequal(sort(fieldnames(saved)),sort(fieldnames(defaults))),'C1PKFine:IntegrationSchema','Native verification refused; original observations are retained.');
    assert(isempty(saved.StopCondition)&&isstruct(saved.ODEOptions)&&isscalar(saved.ODEOptions),'C1PKFine:Callback','Native verification refused; original observations are retained.');
    odeDefaults=odeset();assert(isequal(sort(fieldnames(saved.ODEOptions)),sort(fieldnames(odeDefaults)))&&isempty(saved.ODEOptions.Events),'C1PKFine:ODEFields','Native verification refused; original observations are retained.');
    solverHeader=knownCallback(saved.ODESolver,'ode45');outputHeader=knownCallback(saved.ODEOptions.OutputFcn,'@(~,~,~)double(left(limit)<=0)');
    numeric=saved;numeric=rmfield(numeric,{'ODESolver','ODEOptions'});plain(numeric);odeNumeric=rmfield(saved.ODEOptions,'OutputFcn');plain(odeNumeric);
    live=saved;live.ODESolver=@ode45;live.ODEOptions.OutputFcn=@(~,~,~)budgetOutput(limit);rebuilt=HybridSimulator_v3(live);assert(isequaln(rebuilt.Options,live),'C1PKFine:IntegrationRoundtrip','Native verification refused; original observations are retained.');
    audit=struct('original_solver_header',solverHeader,'original_output_callback_header',outputHeader,'all_other_integration_settings',numeric,'all_other_ODE_options',odeNumeric, ...
        'replacements',{{'Known native ode45 descriptor to fresh @ode45','Known old deadline OutputFcn to fresh immutable-limit callback'}},'saved_closure_executed',false);
end

function out=knownCallback(value,expected)
    header=callbackHeader(value);detail=jsonencode(header);
    if isa(value,'function_handle')&&isscalar(value),signature=func2str(value);out=struct('class',class(value),'signature',signature);
    else
        assert(isstruct(value)&&isscalar(value)&&isequal(sort(fieldnames(value)),sort({'diagnostic_kind';'signature';'requires_runtime_reconstruction'}))&&strcmp(value.diagnostic_kind,'runtime-function-descriptor')&&isequal(value.requires_runtime_reconstruction,true),'C1PKFine:CallbackDescriptor','Unsupported saved callback header: %s',detail);signature=value.signature;out=value;
    end
    assert(ischar(signature)&&isrow(signature)&&strcmp(regexprep(signature,'\s',''),expected),'C1PKFine:CallbackSignature','Unexpected saved callback; no callback is rehydrated. Header: %s',detail);
end

function header=callbackHeader(value)
    header=struct('class',class(value),'size',size(value),'total_field_count',0,'fieldnames_first_32',{{}});
    if isstruct(value)
        names=fieldnames(value);header.total_field_count=numel(names);header.fieldnames_first_32=names(1:min(32,numel(names)));
        if isscalar(value)&&isfield(value,'signature')
            literal=value.signature;header.signature_class=class(literal);header.signature_size=size(literal);
            if ischar(literal)&&isrow(literal)&&numel(literal)<=1024,header.signature_text=literal;end
        end
    elseif isa(value,'function_handle')&&isscalar(value)
        literal=func2str(value);header.signature_length=numel(literal);header.signature_text=literal(1:min(1024,numel(literal)));
    end
end

function p=effectiveProfile(integration,step)
    nested=integration.ODEOptions;rel=1e-12;absolute=1e-14;if ~isempty(nested.RelTol),rel=min(rel,nested.RelTol);end;if ~isempty(nested.AbsTol),absolute=min(absolute,nested.AbsTol);end
    h=step;if ~isempty(nested.MaxStep),h=min(h,nested.MaxStep);end;p=struct('declared_RelTol',1e-12,'declared_AbsTol',1e-14,'declared_MaxStep',step,'effective_RelTol',max(rel,100*eps),'configured_minimum_RelTol',rel,'effective_AbsTol',absolute,'effective_MaxStep',h,'ode45_RelTol_floor',100*eps,'nested_options_preserved',true);
end

function yes=qualified(g)
    yes=isstruct(g)&&isscalar(g)&&strcmp(member(g,'contract_version',''),'quadruped-gait-v3.5')&&strcmp(member(g,'validated_gait_type',''),'PK')&&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1)&&isfield(g,'primitive')&&strcmp(member(g.primitive,'status',''),'primitive_within_checked_bound');
end

function value=fineLimit(seconds,budget,work)
    u=utc()+seconds;m=nano()+seconds*1e9;assert(u<work.u&&m<work.m,'C1PKFine:FineFit','Native verification refused; original observations are retained.');value=struct('deadline_unix_seconds',u,'deadline_utc',utcString(u),'deadline_monotonic_ns',m,'campaign_deadline_utc',utcString(budget.research_deadline_unix_seconds),'campaign_deadline_monotonic_ns',budget.research_deadline_monotonic_ns);
end

function s=utcString(u),v=datetime(u,'ConvertFrom','posixtime','TimeZone','UTC');v.Format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";s=char(v);end

function status=budgetOutput(limit),check(limit);status=0;end

function e=exceptionData(p),e=struct('identifier',p.identifier,'message',p.message,'stack',p.stack);end

function plain(v)
    if isstruct(v),for k=1:numel(v),for f=fieldnames(v).',plain(v(k).(f{1}));end,end
    elseif iscell(v),for k=1:numel(v),plain(v{k});end
    else,assert(isnumeric(v)||islogical(v)||ischar(v)||isstring(v),'C1PKFine:NonportableSetting','Unknown runtime setting is not silently replaced.');end
end


function [policy,evidence]=admitted(o,r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&isfield(r,'acceptance_gates')&&all(isfield(r.acceptance_gates,keys))&&all(cellfun(@(k)isequal(r.acceptance_gates.(k),true),keys)),'C1PKPrimary:AllNine','Native verification refused; original observations are retained.');
    if isfield(r,'accepted'),accepted=isequal(r.accepted,true);else,accepted=strcmp(member(r,'status',member(r,'native_status','')),'accepted');end
    assert(accepted&&strcmp(r.classification.contract_version,'quadruped-gait-v3.5')&&strcmp(r.classification.validated_gait_type,'PK')&&isequal(r.classification.canonical_label_qualified,true)&&isequal(r.classification.flight_count_certain,true)&&isequal(r.classification.flight_count,1),'C1PKPrimary:Class','Native verification refused; original observations are retained.');
    [policy,evidence]=RecordedReturnPolicy_v3(r);assert(evidence.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1PKPrimary:Policy','Native verification refused; original observations are retained.');
end

function assertPublicEqual(a,b,depth)
    assert(depth<=128&&strcmp(class(a),class(b))&&isequal(size(a),size(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    if isnumeric(a)||islogical(a),assert(issparse(a)==issparse(b)&&isreal(a)==isreal(b)&&isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif ischar(a)||isstring(a),assert(isequaln(a,b),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');
    elseif iscell(a),for k=1:numel(a),assertPublicEqual(a{k},b{k},depth+1);end
    elseif isstruct(a),keys=fieldnames(a);assert(isequal(keys,fieldnames(b)),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    elseif ismember(class(a),{'HybridOrbit_v3','Trajectory_v3'}),keys=sort(properties(a));assert(isequal(keys,sort(properties(b))),'C1PKPrimary:Read2','Native verification refused; original observations are retained.');for k=1:numel(a),for z=1:numel(keys),assertPublicEqual(a(k).(keys{z}),b(k).(keys{z}),depth+1);end,end
    else,assert(isequaln(a,b),'C1PKPrimary:NativeRead2','Native verification refused; original observations are retained.');end
end

function saveRound(file,json,round)
    stage=[file '.pending.mat'];save(stage,'round','-v7');a=load(stage,'round');b=load(stage,'round');assert(isequaln(a.round,round)&&isequaln(b.round,round),'C1PKPrimary:StageRead2','Native verification refused; original observations are retained.');[ok,msg]=movefile(stage,file,'f');assert(ok,'C1PKPrimary:Publish','%s',msg);
    text=jsonencode(round,PrettyPrint=true);stage=[json '.pending.json'];fid=fopen(stage,'w');assert(fid>=0);closer=onCleanup(@()fclose(fid));bytes=unicode2native(text,'UTF-8');assert(fwrite(fid,bytes,'uint8')==numel(bytes));clear closer
    assert(isequaln(jsondecode(fileread(stage)),jsondecode(text)));[ok,msg]=movefile(stage,json,'f');assert(ok,'C1PKPrimary:Publish','%s',msg);a=load(file,'round');b=load(file,'round');assert(isequaln(a.round,round)&&isequaln(b.round,round)&&isequaln(jsondecode(fileread(json)),jsondecode(text)),'C1PKPrimary:InstalledRead2','Native verification refused; original observations are retained.');
end

function out=pick(s,keys),out=struct();for k=1:numel(keys),if isstruct(s)&&isscalar(s)&&isfield(s,keys{k}),out.(keys{k})=s.(keys{k});end,end,end

function out=member(s,key,fallback),out=fallback;if isstruct(s)&&isscalar(s)&&isfield(s,key),out=s.(key);end,end

function r=reference(file),r=struct('file',file,'sha256',RoundSHA256_v3(file));end

function check(c),assert(left(c)>0,'C1PKPrimary:Clock','Native verification refused; original observations are retained.');end

function value=left(c),value=min(c.u-utc(),(c.m-nano())/1e9);end

function u=utc(),u=posixtime(datetime('now','TimeZone','UTC'));end

function m=nano(),m=double(java.lang.System.nanoTime);end

function t=stamp(),v=datetime('now','TimeZone','UTC');v.Format="yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";t=char(v);end


function w=verifiedEvidenceClosure(w,q,tag,root)
    exact(w,{'schema','invocation_id','argv_utf8_sha256','exec_session_id','child_pid','actual_child_exit_code', ...
        'actual_process_exit_observed','tool_prefix_reference','process_prefix_reference'});
    assert(strcmp(w.schema,'C1-ordinary-initializer-evidence-closure-v1')&&isequal(w.actual_child_exit_code,0) ...
        &&isequal(w.actual_process_exit_observed,true)&&validSHA(w.argv_utf8_sha256),'C1OrdinaryCAS:Closure');text(w.invocation_id);
    for key={'exec_session_id','child_pid'},v=w.(key{1});assert(isa(v,'double')&&isreal(v)&&isscalar(v)&&isfinite(v)&&v>=1&&v==fix(v),'C1OrdinaryCAS:ClosureType');end
    assert(strcmp(w.tool_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Tool_Observations.jsonl')) ...
        &&strcmp(w.process_prefix_reference.file,fullfile(root,'Audits','PK36h_20261031_Process_Observations.jsonl')),'C1OrdinaryCAS:ClosurePaths');
    t=prefixRows(w.tool_prefix_reference);p=prefixRows(w.process_prefix_reference);terminal=0;marker=0;returned=0;spec=0;
    for k=1:numel(t),r=t{k};if ~isfield(r,'invocation_id')||~strcmp(r.invocation_id,w.invocation_id),continue;end;assert(r.session_id==w.exec_session_id,'C1OrdinaryCAS:ToolSession');if isfield(r.record,'exit_code'),assert(r.record.exit_code==0,'C1OrdinaryCAS:ToolExit');terminal=terminal+1;end;if isfield(r.record,'output'),lines=strsplit(r.record.output,newline);for n=1:numel(lines),if startsWith(lines{n},tag),value=jsondecode(lines{n}(numel(tag)+1:end));assertPublicEqual(value,q,0);marker=marker+1;end,end,end,end
    for k=1:numel(p),r=p{k};if ~isfield(r,'invocation_id')||~strcmp(r.invocation_id,w.invocation_id),continue;end;if strcmp(r.schema,'C1-native-process-observation-v1'),assert(r.child_pid==w.child_pid&&r.actual_child_exit_code==0&&r.actual_process_exit_observed&&strcmp(r.argv_utf8_sha256,w.argv_utf8_sha256),'C1OrdinaryCAS:ProcessExit');returned=returned+1;end;if strcmp(r.schema,'C1-native-launch-specification-v1'),assert(strcmp(r.argv_utf8_sha256,w.argv_utf8_sha256),'C1OrdinaryCAS:Specification');spec=spec+1;end,end
    assert(terminal==1&&marker==1&&returned==1&&spec==1,'C1OrdinaryCAS:UniqueClosure');
end
function exact(s,keys),assert(isstruct(s)&&isscalar(s)&&isequal(sort(fieldnames(s)),sort(keys(:))),'C1OrdinaryCAS:Fields');end
function text(v),assert(ischar(v)&&isrow(v)&&~isempty(v),'C1OrdinaryCAS:Text');end

function rows=prefixRows(r)
    assert(ischar(r.file)&&validSHA(r.prefix_sha256)&&isa(r.prefix_bytes,'double')&&isscalar(r.prefix_bytes)&&r.prefix_bytes>0&&r.prefix_bytes<=16*1024*1024&&r.prefix_bytes==fix(r.prefix_bytes),'C1PKEpoch:Prefix','Invalid bounded immutable prefix reference.');f=fopen(r.file,'rb');assert(f>=0,'C1PKEpoch:PrefixOpen','Cannot read witness prefix.');c=onCleanup(@()fclose(f));b=fread(f,r.prefix_bytes,'*uint8');assert(numel(b)==r.prefix_bytes&&b(end)==10,'C1PKEpoch:PrefixLength','Witness prefix must end at the exact LF.');clear c;d=java.security.MessageDigest.getInstance('SHA-256');d.update(b);h=lower(reshape(dec2hex(typecast(d.digest(),'uint8'),2).',1,[]));assert(strcmp(h,r.prefix_sha256),'C1PKEpoch:PrefixSHA','Witness prefix changed.');lines=strsplit(native2unicode(b.','UTF-8'),newline);lines(end)=[];rows=cellfun(@jsondecode,lines,'UniformOutput',false);
end

function yes=validSHA(v),yes=ischar(v)&&isrow(v)&&~isempty(regexp(v,'^[0-9a-f]{64}$','once'));end

