# Retained C1 method sources

This bundle preserves seven core method sources from the 29–31 October round. The SHA index records their original paths, hashes and public dependencies. The ordinary repository retains the dynamics, root solver, continuation controller, return policies, codec and reader utilities; those sources are not duplicated here.

The scientific cutoff was 2026-10-30 22:52:47 UTC. The final cutoff was 2026-10-31 01:52:47 UTC. The saved grant does not authorize new roots after its scientific cutoff. Repeating numerical work requires a fresh explicit grant and native budget adoption. Several private phase wrappers contain fixed historical hashes and expired clocks. Their old byte-for-byte reexecution was deliberately retired along with obsolete snapshots; use them as method/configuration evidence, with fresh inputs and receipts through the existing public services.

## Numerical method and result boundary

Continue existing ledgers through ResumeC1PKFrontiers_v3 and RunC1PersistentFrontiers_v3. Preserve registered component order, recorded return policy, physical parameters and current frontier state. Corrections use PeriodicSolutionSolver_v3 and root-newton with coupled state/energy solving, ordinary finite differences and no cross-point Jacobian reuse in the final B24 run. Do not introduce optimization, relax admission tolerances, project states to manufacture admission, or relabel failed historical flags.

The retained merged PK store contains 465 occurrences and 453 physical continuation edges. The 0073/0193 connection includes a separately qualified numerical overlap, distinct from a physical edge or exact identity. Ten exact-record links and one numerical overlap remain distinct graph relations. Three independent native controls correspond finitely to P1 columns 1, 152 and 179. The final low-speed control passed its declared strict comparison and original-state fine checks, but no physical continuation edge from the connected endpoint to that control was earned. Full PK/P1 coverage and the complete C1 bifurcation chain remain unresolved.

H means hind spread / fore synchronized; F means fore spread / hind synchronized, following the user's later correction. C2 is outside this round.

## Storage and loading

One raw MAT file stores the merged numerical component and its individual loadable occurrences. The current frontier journal and raw stores remain continuation authority while the search is unfinished. Additive compact exports preserve the declared scientific projection and typed connectivity. They do not reproduce dense trajectories, complete runtime objects or a new admission; trajectory-dependent viewing needs fresh replay.

The Final03 audit preserves all original descriptors and source indices for 24 callback-name conversions and six omitted Jacobian leaves. Those six saved FiniteDifferenceJacobian_v3 descriptors have no settings. Settings were not defaulted or reconstructed, and their producer remains unknown. Equality claims concern the normalized retained projection, not lossless original method settings.

For an existing raw or qualified compact component:
```matlab
addpath(v3);
V3AddPaths_v3(v3);
ix = BranchSolutionFile_v3.index(file);
[orbit, report, metadata] = BranchSolutionFile_v3.loadSolution(file, 1);
```
Set v3 to the repository's SLIP_Quadruped_v3 directory and file to the desired MAT file. Load only the required occurrences. Compact public-reader qualification and its scope are recorded in the storage report and final manifest; loading a thin record does not establish trajectory replay or raw-resume support.

Large working files are allowed when necessary to finish the search. The final five-times target uses the original corresponding whole v2 branch file; equal-point-count comparisons are diagnostics. Neither comparison may reject a valid root or stop continuation.

After each closed run, retain the current authority, concise actual outcome and essential numerical evidence. Remove consumed stages, fixtures, caches and duplicate diagnostics after their last consumer finishes. Do not create exhaustive per-run archives or full-journal return copies. Retired historical locators are not promises of continued byte recovery.

From the repository root, see SLIP_Quadruped_v3/Docs_v3/Storage_Reduction_20261030.md and SLIP_Quadruped_v3/Research_v3/C1/C1_Frontier_Status_20261029.txt for actual final storage, qualification, cleanup and scientific limits. The administrative publication source targets the current macOS environment; this bundle is method evidence rather than a claim of cross-platform execution.

The full BE and PK candidates passed the independent native read-only qualification (4411, exit 0): one recomputed index and two complete public thin-loader passes. The original exporter (16485) remains a failed uncaught-crash attempt. The filesystem publisher (9054) copied and read back all three products, then exited 1 at a metadata guard. Separate read-only FS qualification (44184, exit 0) verified the current products and sources; the published tuples differed only in ctime, with actor unknown. Its internal native-baseline pass covered 175 references once and its final union covered 124; an independent after-exit check covered the complete current union. No failure flag was rewritten.

The public GUI, range audit and recent-result inspector were installed with exact before backups and read2 checks. Their separate native cold-runtime experiment was not attempted before the cleanup reserve. The codec and whole-store thin reads passed; installation does not establish GUI, range, replay or full-runtime qualification. The PK snapshot is 1,740,487 bytes, exceeding its 554,305-byte final target. The unfinished search retains its 804,959,685-byte raw component and current journal.
