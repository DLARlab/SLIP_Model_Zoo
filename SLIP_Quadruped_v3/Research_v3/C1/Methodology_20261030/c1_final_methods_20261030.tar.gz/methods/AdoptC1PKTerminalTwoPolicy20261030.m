function audit=AdoptC1PKTerminalTwoPolicy20261030(workerClosure,options)
% PURE metadata: four declared controls, typed history, native whole inverse.
% No Main/Resume/Run/PSS/Root/map/replay/classification call and no point import.
% The receipt grants NO future Root call or endpoint-window authorization.
    if nargin<2,options=struct();end
    entered=pairClock();root=canonical(fileparts(which('C1RunBudget_v3')));folder=fullfile(root,'Audits');
    o=struct('RunName','TerminalTwo01','Mode','terminal2','JournalReference',struct(),'MergedComponentReference',struct(), ...
        'LastPublicAuditReference',struct(),'LastPublicSourceReference',struct(),'ClosedWorkerSourceReference',struct(), ...
        'OriginalStep04PolicyReference',struct(),'PreviousPolicyReceiptReference',struct(),'TargetIntakeReference',struct(),'MaxWallSeconds',900);
    assert(isstruct(options)&&isscalar(options)&&all(ismember(fieldnames(options),fieldnames(o))),'C1BoundedPAL:Options');
    for key=fieldnames(options).',o.(key{1})=options.(key{1});end
    assert(ischar(o.RunName)&&isrow(o.RunName)&&~isempty(regexp(o.RunName,'^[A-Za-z][A-Za-z0-9_]{0,40}$','once')) ...
        &&ischar(o.Mode)&&strcmp(o.Mode,'terminal2'),'C1BoundedPAL:Mode');
    validateattributes(o.MaxWallSeconds,{'double'},{'scalar','real','finite','>',302,'<=',900});
    keys={'JournalReference','MergedComponentReference','LastPublicAuditReference','LastPublicSourceReference', ...
        'ClosedWorkerSourceReference','OriginalStep04PolicyReference','PreviousPolicyReceiptReference','TargetIntakeReference'};
    for k=1:numel(keys),o.(keys{k})=checked(o.(keys{k}));end
    closed(workerClosure,o.ClosedWorkerSourceReference);
    assert(sameRef(o.ClosedWorkerSourceReference,o.LastPublicSourceReference),'C1BoundedPAL:ClosedPublic','Require the actually closed current PUBLIC worker, not an unqualified interim process.');
    budget=C1RunBudget_v3();assert(strcmp(budget.grant_id,'20261029_PK_46h_Extension10h'),'C1BoundedPAL:Grant');
    finish=minLimit(shift(entered,o.MaxWallSeconds),scienceLimit(budget));work=shift(finish,-120);
    assert(left(work)>182,'C1BoundedPAL:WholeFit','Fit the bounded pure-metadata transaction and postcommit/save allowances within ORIGINAL science; no future Root is authorized.');
    ledger=canonical(fullfile(folder,'PK_Persistent_Frontiers_20261026.mat'));assert(strcmp(ledger,o.JournalReference.file),'C1BoundedPAL:Ledger');
    lease=acquireWriterLock([ledger,'.writer.lock']); %#ok<NASGU>
    before=twice(ledger,'journal',work);B=twice(o.LastPublicAuditReference.file,'audit',work);
    assert(strcmp(B.schema,'C1-one-public-batch-extended-merged-B-campaign-v1')&&B.completed&&B.source_posthash ...
        &&B.normal_closed_accounting_verified&&~B.native_pending_present&&isempty(fieldnames(B.failure)) ...
        &&B.actual_public_return_observed&&B.actual_public_return_timely&&B.public_call.invoked&&B.public_call.returned ...
        &&B.raw_outcome.storage_timely&&B.raw_outcome.readback_timely ...
        &&ismember(B.disposition,{'continue_only_after_review_in_fresh_process','stop_full_next_public_observation_and_save_do_not_fit_before_endpoint_fence', ...
        'stop_bounded_policy_requires_new_pair_specific_review'}) ...
        &&isempty(fieldnames(B.first_literal_signed_dx_crossing))&&~isfield(B,'final_near_phase')&&~isfield(B,'terminal_two_phase')&&cleanAttempts(B.run_facts) ...
        &&B.run_facts.new_points>0&&B.run_facts.new_edges==B.run_facts.new_points&&numel(B.new_points)==B.run_facts.new_points&&B.call_ordinal<64, ...
        'C1BoundedPAL:Public','Only an actual clean closed current PUBLIC cursor without crossing/strategy/domain/pending failure qualifies.');
    assert(sameRef(B.current_ledger_reference,o.JournalReference)&&sameRef(B.current_component_reference,o.MergedComponentReference) ...
        &&sameRef(B.step_policy_reference,o.OriginalStep04PolicyReference)&&sameRef(B.target_intake_reference,o.TargetIntakeReference) ...
        &&isequaln(B.budget,budget)&&isequaln(B.scientific_policy,before.options),'C1BoundedPAL:CurrentBinding');
    assert(isequaln(before.active_budget,budget)&&numel(before.source_code)==30 ...
        &&isequaln(reshape(B.source_code(1:30),[],1),before.source_code(:)) ...
        &&isempty(fieldnames(before.active_run))&&isempty(fieldnames(before.failure))&&~before.range_coverage_verified ...
        &&before.options.BatchWallSeconds==900&&before.options.TrialSeconds==240&&before.options.SaveMarginSeconds==30 ...
        &&before.options.BatchAttempts==12&&isequal(before.options.ReusePreviousJacobian,false), ...
        'C1BoundedPAL:ClosedCurrent','Keep source30/original budget/root policy/attempt cap/FD strategy and actual closed state literal.');
    original=twice(o.OriginalStep04PolicyReference.file,'audit',work);
    assert(strcmp(original.schema,'C1-PK-preferred-B-PAL-step-policy-epoch-v1')&&original.completed&&original.source_posthash ...
        &&original.whole_three_numeric_and_history_inverse_verified&&original.no_new_scientific_dispatch_verified ...
        &&~original.native_pending_present&&isempty(fieldnames(original.failure))&&isequaln(original.budget,budget), ...
        'C1BoundedPAL:Original04','Original B14/pilot/.04 qualification remains historical and unchanged; no snapshot is reopened.');
    previous=twice(o.PreviousPolicyReceiptReference.file,'audit',work);
    previousBoundedPolicy(previous,o.OriginalStep04PolicyReference,budget,before.source_code);
    assert(isfield(B,'bounded_policy_reference')&&sameRef(B.bounded_policy_reference,o.PreviousPolicyReceiptReference) ...
        &&strcmp(B.bounded_policy_mode,previous.mode),'C1NearPlane:ActualPrevious','Never skip the actual previous v1/v2 bounded receipt.');
    if strcmp(previous.schema,'C1-PK-preferred-B-bounded-PAL-policy-epoch-v1')
        assert(strcmp(o.LastPublicSourceReference.sha256,'8ffa29165849f68531be3796f40a8126020dc54c547ee2bc90661be127bf95f1'),'C1NearPlane:FirstSource','The first v2 transition follows the actual closed reviewed v1 controlled observer.');
    elseif strcmp(previous.schema,'C1-PK-preferred-B-bounded-PAL-policy-epoch-v2')
        assert(strcmp(o.LastPublicSourceReference.file,canonical(which('ObserveC1PKNearPlaneFrontier20261030'))),'C1NearPlane:LaterSource','The actual previous v2 cursor follows the independently pinned near observer resolver.');
    else
        assert(strcmp(o.LastPublicSourceReference.file,canonical(which('ObserveC1PKTwoPointPlaneFrontier20261030'))),'C1NearPlane:PriorTwoPointSource','The actual previous v3 cursor follows its unique independently pinned two-point observer.');
    end
    assert(isequaln(before.options,previous.scientific_policy_after)&&isfield(before,'pal_step_policy_history') ...
        &&iscell(before.pal_step_policy_history)&&isequaln(before.pal_step_policy_history,previous.pal_step_policy_history_after), ...
        'C1BoundedPAL:PreviousPolicy','Current numerical options and whole small policy-history prefix must match actual prior authority.');
    fid='PK_file_0009_graph_0001_leaf_000001';hit=find(cellfun(@(f)strcmp(f.id,fid),before.frontiers));assert(isscalar(hit),'C1BoundedPAL:Frontier');f=before.frontiers{hit};
    assert(startsWith(f.status,'runnable')&&sameRef(f.source_reference,o.MergedComponentReference) ...
        &&strcmp(canonical(f.component_file),o.MergedComponentReference.file)&&isequaln(f.source_pair,B.run_facts.current_pair) ...
        &&f.last_accepted_index==f.source_pair(2)&&f.derivative_index==1 ...
        &&ismember(before.options.MaximumStep,[.08,.1])&&f.maximum_step==before.options.MaximumStep, ...
        'C1BoundedPAL:ActualFrontier','Bind the actual saved B pair/owner/FD1/strategy; do not substitute an old pair or reset control state.');
    assert(hit==previous.selected_frontier_index&&strcmp(fid,previous.selected_frontier_id) ...
        &&f.maximum_step==previous.controls_after.frontier_maximum_step&&before.options.BatchAccepted==previous.controls_after.batch_accepted, ...
        'C1NearPlane:PriorCurrentControls','Current maxima/accepted cap retain the actual prior receipt; native-grown carried step is bound to the current PUBLIC cursor, not reset to a historical initial value.');
    core=[B.preserved_core_references(:);{o.MergedComponentReference}];assert(numel(core)==44,'C1BoundedPAL:Core');verify(core);verify(before.component_files);
    roster=resultsRoster(root);resultsRefs=cell(numel(roster),1);for k=1:numel(roster),resultsRefs{k}=reference(roster{k});end
    cp=[ledger(1:end-4),'_active_checkpoint.mat'];isolated=fullfile(root,'Results',['C1_Isolated_Native_Admissions',budget.result_suffix,'.mat']);isolatedBefore=fileState(isolated);
    assert(~isolatedBefore.present&&~isolatedBefore.pending_present,'C1BoundedPAL:Isolation','Any native isolation requires separate review.');
    fresh({cp,[cp,'.pending.mat'],[ledger,'.pending.mat']});
    sourceStat=dir(o.MergedComponentReference.file);assert(isscalar(sourceStat)&&~sourceStat.isdir,'C1NearPlane:SourceStat');sourceUnchanged(o.MergedComponentReference,sourceStat);
    ix=BranchSolutionFile_v3.index(o.MergedComponentReference.file);ix2=BranchSolutionFile_v3.index(o.MergedComponentReference.file);
    assert(isequaln(ix,ix2),'C1BoundedPAL:IndexRead2');sourceUnchanged(o.MergedComponentReference,sourceStat);owned(ix,f.source_pair(1),f.source_pair(2));
    [O,R,M]=nativeSelectedSolutions(o.MergedComponentReference.file,f.source_pair,ix,o.MergedComponentReference,sourceStat);
    [O2,R2,M2]=nativeSelectedSolutions(o.MergedComponentReference.file,f.source_pair,ix,o.MergedComponentReference,sourceStat);
    publicEqual(O,O2,0);publicEqual(R,R2,0);publicEqual(M,M2,0);a=O{1};b=O{2};
    for k=1:2,strictPK(O{k},R{k},b.parameter);assert(strcmp(M{k}.component_identity,B.source_owner),'C1BoundedPAL:Owner');end
    [~,pa]=RecordedReturnPolicy_v3(R{1});[~,pb]=RecordedReturnPolicy_v3(R{2});match=MatchingReturnSection_v3(a,b,R);
    assert(match.compatible&&isequaln(pa.configuration,pb.configuration)&&isequaln(pb.configuration,f.policy_configuration) ...
        &&isequaln(a.initial_mode,b.initial_mode)&&isequaln(a.parameter,b.parameter) ...
        &&isequaln(b.initial_state,f.initial_state)&&isequaln(b.initial_mode,f.initial_mode),'C1BoundedPAL:LiteralPair');
    [target,targetRefs]=col1Target(o.TargetIntakeReference,before.source_code,work);
    [selection,newStep,newAccepted]=selectPolicy(a,b,target,o.Mode,before.options.MinimumStep);
    controlsBefore=controls(before,hit);controlsAfter=struct('global_maximum_step',newStep,'frontier_maximum_step',newStep,'frontier_step',newStep,'batch_accepted',newAccepted);
    historyBefore=before.pal_step_policy_history;
    code=before.source_code(:);for name={'AdoptC1PKTerminalTwoPolicy20261030','HybridOrbit_v3','Trajectory_v3','EnergyFamilyResidual_v3', ...
            'QuadrupedPhysicalChart_v3','QuadrupedSchema_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3','BranchSolutionFile_v3','RoundSHA256_v3'},code{end+1,1}=reference(which(name{1}));end;verifyCode(code);
    inputs=[{o.LastPublicAuditReference;o.LastPublicSourceReference;o.OriginalStep04PolicyReference;o.PreviousPolicyReceiptReference; ...
        o.TargetIntakeReference;B.raw_outcome.reference};targetRefs];verify(inputs);
    entry=struct('schema','C1-PK-preferred-B-bounded-PAL-history-v4','mode',o.Mode,'entry_id',char(java.util.UUID.randomUUID()), ...
        'recorded_utc',stamp(),'source_reference',reference([mfilename('fullpath'),'.m']), ...
        'before_ledger_reference',o.JournalReference,'last_public_audit_reference',o.LastPublicAuditReference, ...
        'previous_policy_receipt_reference',o.PreviousPolicyReceiptReference,'target_intake_reference',o.TargetIntakeReference, ...
        'frontier_id',fid,'source_pair',f.source_pair,'source_owner',B.source_owner, ...
        'controls_before',controlsBefore,'controls_after',controlsAfter, ...
        'changed_fields',{{'options.MaximumStep','options.BatchAccepted','selected_frontier.maximum_step','selected_frontier.step'}}, ...
        'scope','Pair-specific prospective metadata only. Global MaximumStep and BatchAccepted affect Main generally; only separately reviewed PreferredB/MaxBatches1 execution is allowed. No next Root or endpoint window is authorized here.');
    planned=before;planned.options.MaximumStep=newStep;planned.options.BatchAccepted=newAccepted;planned.frontiers{hit}.maximum_step=newStep;planned.frontiers{hit}.step=newStep;
    planned.pal_step_policy_history=[historyBefore(:);{entry}];planned.updated_utc=stamp();inverse(planned,before,hit);
    base=fullfile(folder,['PK_Terminal_Two_Policy_',o.RunName,'_20261030']);output=[base,'.mat'];json=[base,'.json'];stage=[ledger,'.pending.mat'];eventFile=[base,'_Atomic_Return.mat'];
    fresh({output,json,[output,'.pending.mat'],[json,'.pending.json'],stage,eventFile,[eventFile,'.pending.mat']});
    audit=struct('schema','C1-PK-preferred-B-bounded-PAL-policy-epoch-v4','mode',o.Mode,'options',o,'worker_closure',workerClosure, ...
        'budget',budget,'finish',finish,'work_limit',work,'save_margin_seconds',120, ...
        'clock_scope','PURE metadata under ORIGINAL science UTC/JVM, local<=900; no finalreserve/renewal/future Root authorization.', ...
        'original_step04_policy_reference',o.OriginalStep04PolicyReference,'previous_policy_receipt_reference',o.PreviousPolicyReceiptReference, ...
        'last_public_audit_reference',o.LastPublicAuditReference,'last_public_source_reference',o.LastPublicSourceReference, ...
        'last_public_raw_reference',B.raw_outcome.reference,'target_intake_reference',o.TargetIntakeReference, ...
        'before_ledger_reference',o.JournalReference,'after_ledger_reference',struct(),'merged_component_reference',o.MergedComponentReference, ...
        'selected_frontier_id',fid,'selected_frontier_index',hit,'selected_source_pair',f.source_pair,'selected_source_owner',B.source_owner, ...
        'selected_derivative_index_unchanged',f.derivative_index,'selected_strategy_index_unchanged',f.strategy_index, ...
        'scientific_policy_before',before.options,'scientific_policy_after',planned.options,'controls_before',controlsBefore,'controls_after',controlsAfter, ...
        'journal_source_code',{before.source_code},'policy_history_entry',entry, ...
        'pal_step_policy_history_before',{historyBefore},'pal_step_policy_history_after',{planned.pal_step_policy_history}, ...
        'selection_evidence',selection,'core_references',{core},'results_references',{resultsRefs},'results_MAT_roster',{roster}, ...
        'source_code',{code},'inputs',{inputs},'journal_stage_file',stage,'prepared_journal_stage_reference',struct(), ...
        'prepared_whole_inverse_verified',true,'atomic_replace_return_observed',false,'atomic_replace_return_timely',false, ...
        'atomic_return_reference',struct(),'atomic_return_custody_timely',false,'canonical_ledger_state','old_exact_bytes_verified', ...
        'whole_control_and_history_inverse_verified',false,'no_new_scientific_dispatch_verified',false, ...
        'permanent_full_ledger_snapshots_created',false,'native_pending_present',false,'completed',false,'source_posthash',false,'failure',struct(), ...
        'scope','Four explicit controls plus one policy-history entry/updatedUTC only. Whole installed native inverse is checked in memory. Before/after hashes are historical locators, never a future current-j equality or full-runtime recovery promise. Read scope: two PUBLIC schema2 indices include complete variable-directory/class validation; selected native orbit/report loads are independent read2 with exact ee7336 validator/metadata semantics and SHA/stat guards, not public loadSolutions calls. A future public process must separately review this exact pair-specific mode, clocks and endpoint tradeoff.');
    try
        verifyBefore();audit.native_pending_present=true;publish(output,json,audit,finish);
        journal=planned;save(stage,'journal','-v7');assert(isequaln(twice(stage,'journal',work),planned),'C1BoundedPAL:PreparedJournal');
        audit.prepared_journal_stage_reference=reference(stage);publish(output,json,audit,finish);verifyBefore();verify({audit.prepared_journal_stage_reference});
        assert(left(work)>182,'C1BoundedPAL:ClosestCommitFit','Preserve declared native verification/save allowance before atomic replacement.');
        move(stage,ledger,true);audit.atomic_replace_return_observed=true;returned=pairClock();
        audit.atomic_replace_return_timely=returned.utc<work.utc&&returned.mono<work.mono;audit.canonical_ledger_state='replace_returned_native_verification_pending';
        event=struct('schema','C1-bounded-PAL-metadata-atomic-return-v1','return_observed',true,'return_clock',returned, ...
            'return_timely',audit.atomic_replace_return_timely,'destination_file',ledger,'prepared_stage_reference',audit.prepared_journal_stage_reference, ...
            'scope','Atomic replace returned; installed native equality/inverse and future process exit remain unobserved by this raw event.');
        audit.atomic_return_reference=saveAtomicEvent(eventFile,event);audit.atomic_return_custody_timely=left(work)>0;
        audit.after_ledger_reference=reference(ledger);after=twice(ledger,'journal',work);
        assert(isequaln(after,planned)&&strcmp(audit.after_ledger_reference.sha256,audit.prepared_journal_stage_reference.sha256),'C1BoundedPAL:Installed');inverse(after,before,hit);
        audit.whole_control_and_history_inverse_verified=true;audit.no_new_scientific_dispatch_verified=true;
        audit.native_pending_present=false;audit.canonical_ledger_state='verified_four_controls_and_history_committed';
        assert(audit.atomic_replace_return_timely&&audit.atomic_return_custody_timely,'C1BoundedPAL:Late','Keep actual commit/custody lateness without promoting the epoch.');
        verifyAfter();audit.completed=true;audit.source_posthash=true;audit.finished_utc=stamp();publish(output,json,audit,finish);verifyAfter();
        fprintf('C1_TERMINAL_TWO_POLICY completed=1 mode=%s pair=[%d %d] initialStep=%.17g max=%.17g BatchAccepted=%d FD=%d inverse=1 noRootAuthorization=1\n', ...
            o.Mode,f.source_pair,newStep,newStep,newAccepted,f.derivative_index);check(finish);
    catch problem
        audit.completed=false;audit.source_posthash=false;audit.failure=exceptionData(problem);audit.finished_utc=stamp();
        if strcmp(RoundSHA256_v3(ledger),o.JournalReference.sha256),audit.canonical_ledger_state='proven_exact_old_ledger_no_rollback'; ...
        elseif ~strcmp(audit.canonical_ledger_state,'verified_four_controls_and_history_committed'),audit.canonical_ledger_state='changed_or_uncertain_preserve_no_rollback';end
        if left(finish)>0,publish(output,json,audit,finish);end;rethrow(problem);
    end
    function verifyFixed()
        verify(core);verify(resultsRefs);verify(inputs);verifyCode(code);
        assert(isequaln(coreRoster(root,o.MergedComponentReference.file),sort(cellfun(@(r)canonical(r.file),core,'UniformOutput',false))) ...
            &&isequaln(resultsRoster(root),roster)&&isequaln(fileState(isolated),isolatedBefore)&&isequaln(C1RunBudget_v3(),budget),'C1BoundedPAL:Fixed');
        fresh({cp,[cp,'.pending.mat'],[isolated,'.pending.mat']});check(work);
    end
    function verifyBefore(),verifyFixed();verify({o.JournalReference});end
    function verifyAfter(),verifyFixed();fresh({stage});verify({audit.after_ledger_reference;audit.atomic_return_reference});check(finish);end
end

function out=controls(j,k)
    f=j.frontiers{k};out=struct('global_maximum_step',j.options.MaximumStep,'frontier_maximum_step',f.maximum_step,'frontier_step',f.step,'batch_accepted',j.options.BatchAccepted);
end
function inverse(after,before,k)
    inv=after;inv.options.MaximumStep=before.options.MaximumStep;inv.options.BatchAccepted=before.options.BatchAccepted;
    inv.frontiers{k}.maximum_step=before.frontiers{k}.maximum_step;inv.frontiers{k}.step=before.frontiers{k}.step;
    inv.pal_step_policy_history=before.pal_step_policy_history;inv.updated_utc=before.updated_utc;
    assert(isequaln(inv,before),'C1BoundedPAL:WholeInverse','Only four declared controls/history/updatedUTC differ; every other frontier/pair/FD/strategy/counter/run/source/budget/registry/control remains ENTIRE-native equal.');
end
function yes=cleanAttempts(facts)
    assert(all(isfield(facts,{'failed_root_journal_count','timely_noncommitted_attempt_count','attempts'}))&&iscell(facts.attempts),'C1BoundedPAL:AttemptFacts');
    yes=facts.failed_root_journal_count==0&&facts.timely_noncommitted_attempt_count==0&&~isempty(facts.attempts);
    for k=1:numel(facts.attempts),a=facts.attempts{k};assert(isstruct(a)&&isscalar(a)&&all(isfield(a,{'algorithm','all_nine','timely','edge_committed','storage_attempted','storage_timely','isolated_committed'})),'C1BoundedPAL:AttemptFacts');yes=yes&&strcmp(a.algorithm,'root-newton')&&a.all_nine&&a.timely&&a.edge_committed&&a.storage_attempted&&a.storage_timely&&~a.isolated_committed;end
end
function [s,step,count]=selectPolicy(a,b,t,mode,minimum)
    schema=QuadrupedSchema_v3.shared();F=EnergyFamilyResidual_v3(struct('Map',[]),b.initial_state,b.initial_mode,b.parameter,struct('Symmetry','pronk'));
    ua=F.packState(a.initial_state);ub=F.packState(b.initial_state);
    assert(numel(ub)==4&&numel(F.ClosureIndices)==3&&isequaln(F.CoordinateIndices,[2,3,7,8]) ...
        &&isequaln(F.fullState(ua),a.initial_state)&&isequaln(F.fullState(ub),b.initial_state),'C1BoundedPAL:ExactChart','Both literal owned states must losslessly pack/lift in the actual native pronk4 chart.');
    scale=max([ones(numel(ub),1),abs(ua),abs(ub)],[],2);delta=(ub-ua)./scale;distance=norm(delta);
    assert(isfinite(distance)&&distance>1e-10,'C1BoundedPAL:Chord');tangent=delta/distance;slot=find(F.CoordinateIndices==schema.State.dx);assert(isscalar(slot),'C1BoundedPAL:DxSlot');
    aDx=a.initial_state(schema.State.dx);bDx=b.initial_state(schema.State.dx);target=t.state(schema.State.dx);gap=bDx-target;
    assert(isfinite(aDx)&&isfinite(bDx)&&isfinite(target)&&gap>0,'C1BoundedPAL:TargetPriority','An already reached/crossed target has endpoint priority.');
    assert(strcmp(mode,'terminal2')&&abs(aDx)<=1&&abs(bDx)<=1&&tangent(slot)<0,'C1TerminalTwo:Direction','Require the literal descending resolved saved pair and unit dx coordinate scale.');
    dsPlane=(target-bDx)/(scale(slot)*tangent(slot));assert(isfinite(dsPlane)&&dsPlane>0,'C1TerminalTwo:PlaneStep');
    halfPlane=dsPlane/2;step=min(.1,halfPlane);count=2;
    predictor=ub+scale.*(step*tangent);full=F.fullState(predictor);
    assert(all(isfinite(scale))&&all(isfinite(tangent))&&all(isfinite(full))&&isfinite(step)&&step>=minimum&&step<=.1, ...
        'C1TerminalTwo:LegalStep','No below-MinimumStep clamp or retry; the same finite d caps global/frontier growth and the first step.');
    assert(full(schema.State.dx)<bDx&&abs(full(schema.State.dx))<=1,'C1TerminalTwo:InitialPredictor','Use the actual descending unit lifted predictor, without target packing or snapping.');
    allowance=64*eps(max([1,abs(aDx),abs(bDx),abs(full(schema.State.dx)),abs(target)]));buffer=1e-10;
    required=max(buffer,allowance);margin=full(schema.State.dx)-target-.02;
    assert(isfinite(margin)&&margin>required,'C1TerminalTwo:FirstNoCrossMargin','Require a comfortable actual P0 gap beyond capture radius; otherwise refuse before any metadata commit.');
    s=struct('schema','C1-PK-bounded-PAL-pair-selection-v4','policy_mode',mode,'xa',a.initial_state,'xb',b.initial_state, ...
        'mode',b.initial_mode,'parameter',b.parameter,'coordinate_indices',F.CoordinateIndices,'closure_indices',F.ClosureIndices, ...
        'energy_pivot',F.EnergyPivot,'ua',ua,'ub',ub,'scale',scale,'normalized_chord',delta,'chord_norm',distance,'tangent',tangent, ...
        'dx_position',slot,'a_dx',aDx,'b_dx',bDx,'target_dx',target,'target_gap',gap,'ds_plane',dsPlane,'selected_ds',step, ...
        'unclamped_half_plane_ds',halfPlane,'clamped_at_point_one',halfPlane>.1,'selected_step_is_half_plane',step==halfPlane, ...
        'predictor_coordinates',predictor,'lifted_predictor_state',full,'maximum_owned_commits_for_bound',count,'capture_radius_unchanged',.02, ...
        'first_no_cross_gap_margin',margin,'selection_buffer',buffer,'proof_roundoff_allowance',allowance,'required_strict_margin',required, ...
        'second_plane_or_crossing_guaranteed',false,'targeting_is_empirical',true, ...
        'scope','First same-pair FD/shrink predictors interpolate from b to actual P0, so the strict capture margin prevents FIRST crossing only. The second correction has a fresh tangent and is empirical; no above-plane predictor, dx-overshoot, full13 endpoint or speed guarantee. A clamped half-plane step is not exact half-plane targeting. The variable d only caps growth; no Root/admission/target-state change or future call authority.');
end
function r=saveAtomicEvent(file,event)
    stage=[file,'.pending.mat'];fresh({file,stage});save(stage,'event','-v7');
    a=load(stage,'-mat','event');b=load(stage,'-mat','event');assert(isequaln(a.event,event)&&isequaln(b.event,event),'C1BoundedPAL:AtomicEvent');
    move(stage,file,false);a=load(file,'-mat','event');b=load(file,'-mat','event');assert(isequaln(a.event,event)&&isequaln(b.event,event),'C1BoundedPAL:AtomicEvent');r=reference(file);
    % Deliberately no postclock refusal before the actual replace-return event is retained.
end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function yes=sameRef(a,b),yes=isstruct(a)&&isstruct(b)&&all(isfield(a,{'file','sha256'}))&&all(isfield(b,{'file','sha256'}))&&strcmp(canonical(a.file),canonical(b.file))&&strcmp(a.sha256,b.sha256);end

function closed(w,r)
    fields={'schema','actual_process_exit_observed','all_owned_native_workers_exit_observed','process_session_id','exit_code','source_sha256','custody_complete','pending_boundary_reviewed'};
    assert(isstruct(w)&&isscalar(w)&&all(isfield(w,fields))&&strcmp(w.schema,'C1-closed-owned-native-worker-v1')&&isequal(w.actual_process_exit_observed,true)&&isequal(w.all_owned_native_workers_exit_observed,true) ...
        &&isnumeric(w.process_session_id)&&isscalar(w.process_session_id)&&isfinite(w.process_session_id)&&w.process_session_id>0&&w.process_session_id==fix(w.process_session_id)&&isequal(w.exit_code,0) ...
        &&strcmp(w.source_sha256,r.sha256)&&isequal(w.custody_complete,true)&&isequal(w.pending_boundary_reviewed,true), ...
        'C1MergedB:WorkerClosure','Require actual previous owned-worker exit0 and completed custody/pending review; marker/current empty active fields alone do not prove process closure.');
    [~,name,ext]=fileparts(r.file);assert(strcmp(ext,'.m')&&strcmp(canonical(which(name)),r.file),'C1MergedB:WorkerSource','The actually closed helper source must match its retained current resolver.');
end

function paths=coreRoster(root,merged)
    d=dir(fullfile(root,'Components'));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==43&&~any([d.isdir])&&all(endsWith(lower(string({d.name})),'.mat'))&&~any(contains(lower(string({d.name})),'pending')),'C1MergedB:OriginalCores','Keep exact43 untouched core MATs and no unknown stage.');paths=cellfun(@(n)canonical(fullfile(root,'Components',n)),{d.name}.','UniformOutput',false);
    d=dir(fileparts(merged));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==1&&~d.isdir&&strcmp(canonical(fullfile(d.folder,d.name)),merged),'C1MergedB:MergedDirectory','The permanent merged directory contains exactly its current one MAT with no random/stage file.');paths=sort([paths;{merged}]);
end

function names=resultsRoster(root)
    d=dir(fullfile(root,'Results','*.mat'));assert(~any([d.isdir]),'C1MergedB:ResultsDirectory','A Results MAT entry cannot be a directory.');names=sort(cellfun(@(n)canonical(fullfile(root,'Results',n)),{d.name}.','UniformOutput',false));
end

function s=fileState(file)
s=struct('file',file,'present',isfile(file),'reference',struct(),'pending_present',isfile([file,'.pending.mat']),'pending_reference',struct());assert(~isfolder(file)&&~isfolder([file,'.pending.mat']),'C1UnitOwned:OutputDirectory','A reserved native output or stage is a directory.');if s.present,s.reference=reference(file);end;if s.pending_present,s.pending_reference=reference([file,'.pending.mat']);end
end

function l=scienceLimit(b),l=struct('utc',b.research_deadline_unix_seconds,'mono',b.research_deadline_monotonic_ns);end

function l=minLimit(a,b),l=struct('utc',min(a.utc,b.utc),'mono',min(a.mono,b.mono));end


function out=twice(file,key,l),check(l);a=load(file,'-mat',key);check(l);b=load(file,'-mat',key);assert(isequaln(a.(key),b.(key)),'C1Pilot:NativeReads','Two whole native reads differ.');out=a.(key);check(l);end

function publish(file,json,audit,l)
check(l);stage=[file,'.pending.mat'];fresh({stage});save(stage,'audit','-v7');a=load(stage,'-mat','audit');b=load(stage,'-mat','audit');assert(isequaln(a.audit,audit)&&isequaln(b.audit,audit),'C1Pilot:Audit','Both complete plain audit reads must agree.');move(stage,file,isfile(file));stage=[json,'.pending.json'];fresh({stage});text=jsonencode(audit,PrettyPrint=true);h=fopen(stage,'w');assert(h>=0,'C1Pilot:JSON','Cannot open fresh JSON stage.');c=onCleanup(@()fclose(h));bytes=unicode2native(text,'UTF-8');assert(fwrite(h,bytes,'uint8')==numel(bytes),'C1Pilot:JSON','Write every projected byte.');clear c;assert(isequaln(jsondecode(fileread(stage)),jsondecode(text)),'C1Pilot:JSON','Projected JSON differs.');move(stage,json,isfile(json));a=load(file,'-mat','audit');b=load(file,'-mat','audit');assert(isequaln(a.audit,audit)&&isequaln(b.audit,audit),'C1Pilot:Installed','Both whole installed audit reads must agree.');check(l);
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1Pilot:Resolver','A guarded implementation resolves elsewhere.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Pilot:Changed','A guarded authority/source/core changed.');end,end

function r=reference(f),assert(isfile(f),'C1Pilot:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function move(a,b,replace),if replace,v=javaArray('java.nio.file.CopyOption',2);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');v(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');else,fresh({b});v=javaArray('java.nio.file.CopyOption',1);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');end;javaMethod('move','java.nio.file.Files',java.io.File(a).toPath(),java.io.File(b).toPath(),v);end

function fresh(files),for k=1:numel(files),assert(~isfile(files{k})&&~isfolder(files{k}),'C1Pilot:Fresh','Retain an existing authority or uncertain stage.');end,end

function e=exceptionData(x),causes=cell(size(x.cause));for k=1:numel(causes),causes{k}=exceptionData(x.cause{k});end;e=struct('identifier',x.identifier,'message',x.message,'stack',x.stack,'causes',{causes});end

function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end

function t=pairClock(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function t=shift(t,s),t.utc=t.utc+s;t.mono=t.mono+s*1e9;end

function v=left(t),v=min(t.utc-posixtime(datetime('now','TimeZone','UTC')),(t.mono-double(java.lang.System.nanoTime))/1e9);end

function check(t),assert(left(t)>0,'C1Pilot:Clock','The fixed whole/local/science clock expired.');end

function s=stamp(),s=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end


function [t,refs]=col1Target(ir,current,l)
    assert(strcmp(ir.sha256,'7271b42befe2b47426ded73031d0833dc1a4dd1f34a17498515e2c5cc72c0652'),'C1MergedB:TargetIntake','Use exact saved7271 independently qualified target authority.');a=twice(ir.file,'audit',l);assert(a.completed&&a.source_posthash&&isempty(fieldnames(a.failure)),'C1MergedB:TargetIntake','The saved target intake must actually be complete.');t=a.targets{1};assert(strcmp(t.role,'P1_col1_NEW_qualified_control'),'C1MergedB:TargetRole','The crossing observable belongs to qualified NEW col1, not OriginalP1 raw or UNIT.');
    ar=t.authority.audit_reference;rr=t.authority.final_raw_reference;assert(strcmp(ar.sha256,'210a54d6282acd0abe57ecf6fce491c52d78329a01adfe72b136554fba683a28')&&strcmp(rr.sha256,'cf8a0a2af207955a8ba8cc228548e4012f3310e5e1d5dc5e7a297c917ee5a87a'), ...
        'C1MergedB:TargetAuthorities','Copy exact reviewed source7271/210a54/finalcf8a authorities; no deleted callback or raw target deserialization.');verify({ar;rr});old=twice(ar.file,'audit',l);r=old.rows{1};
    assert(~old.completed&&~old.source_posthash&&r.original.original_column==1&&r.qualified_new_control&&r.finite_original_column_conditions_met&&r.native_all_nine&&r.initial_anchor_control.passed ...
        &&numel(r.fines)==2&&all(cellfun(@(f)f.passed&&f.observation.returned&&f.observation.return_timely&&f.raw_custody.storage_timely&&f.raw_custody.readback_timely,r.fines)), ...
        'C1MergedB:TargetQualification','Preserve historical globalfalse separately from actual qualified NEW col1 row and original-solved-root fine facts.');
    p=r.new_point;assert(strcmp(t.native_id,p.native_id)&&isequaln(t.state,p.initial_state)&&isequaln(t.mode,p.mode)&&isequaln(t.parameter,p.parameter)&&isequaln(t.period,p.period)&&isequaln(t.full_stride,p.full_stride), ...
        'C1MergedB:TargetValues','Immutable intake and qualified row bind all identity-bearing target values; only literal signed initial dx is used for crossing.');
    for k=1:numel(current),q=current{k};[~,name]=fileparts(q.file);if ismember(name,{'C1RunBudget_v3','PlanC1PKFrontiers_v3'}),continue;end;hit=find(cellfun(@(v)strcmp(canonical(v.file),canonical(q.file)),a.source_code));assert(~isempty(hit)&&all(cellfun(@(v)strcmp(v.sha256,q.sha256),a.source_code(hit))), ...
            'C1MergedB:TargetPhysics','Historical target physics/service equals current guards; only provider/history and storage-only Plan epochs differ explicitly.');end
    t=rmfield(t,intersect(fieldnames(t),{'incoming_ancestry_pairs','incoming_ancestry_rows','unevaluated_candidate_rows','origin_frontier'}));t.historical_global_completed=old.completed;t.historical_global_source_posthash=old.source_posthash;t.raw_target_deserialized=false;refs={ar;rr};check(l);
end
function strictPK(o,r,p)
keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};for k=1:numel(keys),assert(isequal(r.acceptance_gates.(keys{k}),true),'C1Pilot:AllNine','Require every literal original native admission gate.');end;g=r.classification;status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true)&&strcmp(g.contract_version,'quadruped-gait-v3.5')&&strcmp(g.validated_gait_type,'PK')&&isequal(g.flight_count_certain,true)&&g.flight_count==1&&isequal(g.canonical_label_qualified,true)&&isequaln(o.parameter(:),p(:)),'C1Pilot:PK','Require current qualified certain PK1 and unchanged parameters.');[policy,e]=RecordedReturnPolicy_v3(r);assert(e.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1Pilot:Policy','Require the actual complete BL1 section.');
end
function owned(ix,a,b),assert(nnz(cellfun(@(e)e.from==a&&e.to==b,ix.edges))==1,'C1Pilot:Edge','Require exactly one literal physical continuation edge.');end
function publicEqual(a,b,d)
assert(d<128&&strcmp(class(a),class(b))&&isequal(size(a),size(b)),'C1Pilot:Public','Native public class/shape/nesting differs.');if isnumeric(a)||islogical(a),assert(issparse(a)==issparse(b)&&isreal(a)==isreal(b)&&isequaln(a,b),'C1Pilot:Public','Native numeric value differs.');elseif ischar(a)||isstring(a),assert(isequaln(a,b),'C1Pilot:Public','Native text differs.');elseif iscell(a),for k=1:numel(a),publicEqual(a{k},b{k},d+1);end;elseif isstruct(a),names=fieldnames(a);assert(isequal(names,fieldnames(b)),'C1Pilot:Public','Native public fields differ.');for k=1:numel(a),for z=1:numel(names),publicEqual(a(k).(names{z}),b(k).(names{z}),d+1);end,end;else,assert(isa(a,'HybridOrbit_v3')||isa(a,'Trajectory_v3'),'C1Pilot:Public','Unexpected scientific object.');names=properties(a);for k=1:numel(a),for z=1:numel(names),publicEqual(a(k).(names{z}),b(k).(names{z}),d+1);end,end;end
end
function v=member(s,k,f),v=f;if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);end,end
function previousBoundedPolicy(p,original,budget,sourceCode)
    v1=strcmp(p.schema,'C1-PK-preferred-B-bounded-PAL-policy-epoch-v1');v2=strcmp(p.schema,'C1-PK-preferred-B-bounded-PAL-policy-epoch-v2');v3=strcmp(p.schema,'C1-PK-preferred-B-bounded-PAL-policy-epoch-v3');
    assert((v1||v2||v3)&&p.completed&&p.source_posthash&&isempty(fieldnames(p.failure))&&~p.native_pending_present ...
        &&p.whole_control_and_history_inverse_verified&&p.no_new_scientific_dispatch_verified ...
        &&p.atomic_replace_return_observed&&p.atomic_replace_return_timely&&p.atomic_return_custody_timely ...
        &&strcmp(p.canonical_ledger_state,'verified_four_controls_and_history_committed') ...
        &&strcmp(p.after_ledger_reference.sha256,p.prepared_journal_stage_reference.sha256) ...
        &&sameRef(p.original_step04_policy_reference,original)&&isequaln(p.budget,budget)&&isequaln(p.journal_source_code,sourceCode), ...
        'C1NearPlane:PreviousReceipt','Use the actual complete v1/v2/v3 metadata authority; historical before/after locators are not reopened as current state.');
    h=p.pal_step_policy_history_before;a=p.pal_step_policy_history_after;
    assert(iscell(h)&&iscell(a)&&iscolumn(h)&&iscolumn(a)&&numel(a)==numel(h)+1 ...
        &&isequaln(a(1:end-1),h)&&isequaln(a{end},p.policy_history_entry) ...
        &&isequaln(p.policy_history_entry.controls_before,p.controls_before)&&isequaln(p.policy_history_entry.controls_after,p.controls_after) ...
        &&isequaln(p.policy_history_entry.source_pair,p.selected_source_pair)&&strcmp(p.policy_history_entry.frontier_id,p.selected_frontier_id), ...
        'C1NearPlane:PreviousHistory','Keep the ENTIRE actual ordered prefix and the literal prior entry/controls/pair; no manufactured or superseded history.');
    if v1,cap=.08;historySchema='C1-PK-preferred-B-bounded-PAL-history-v1';
    elseif v2,cap=.1;historySchema='C1-PK-preferred-B-bounded-PAL-history-v2';
    else,cap=.1;historySchema='C1-PK-preferred-B-bounded-PAL-history-v3';end
    assert(strcmp(p.policy_history_entry.schema,historySchema)&&strcmp(p.policy_history_entry.mode,p.mode) ...
        &&p.scientific_policy_after.MaximumStep==cap&&p.controls_after.global_maximum_step==cap ...
        &&p.controls_after.frontier_maximum_step==cap&&p.controls_after.frontier_step>=p.scientific_policy_after.MinimumStep ...
        &&p.controls_after.frontier_step<=cap&&p.controls_after.batch_accepted==p.scientific_policy_after.BatchAccepted, ...
        'C1NearPlane:PreviousControls','Each actual prior version keeps its original maximum and exact accepted cap.');
    if v1&&strcmp(p.mode,'coarse3'),assert(p.controls_after.batch_accepted==3&&p.controls_after.frontier_step==.08,'C1NearPlane:PreviousCoarse');
    elseif v3,assert(strcmp(p.mode,'coarse2')&&p.controls_after.batch_accepted==2&&p.controls_after.frontier_step==.1,'C1NearPlane:PreviousTwoPoint');
    else,assert(strcmp(p.mode,'near1')&&p.controls_after.batch_accepted==1,'C1NearPlane:PreviousNear');end
    restored=p.scientific_policy_after;restored.MaximumStep=p.scientific_policy_before.MaximumStep;restored.BatchAccepted=p.scientific_policy_before.BatchAccepted;
    assert(isequaln(restored,p.scientific_policy_before) ...
        &&p.controls_before.global_maximum_step==p.scientific_policy_before.MaximumStep ...
        &&p.controls_before.batch_accepted==p.scientific_policy_before.BatchAccepted, ...
        'C1NearPlane:PreviousPolicyInverse','No other numerical option may differ in a previous actual bounded epoch.');
end
function [orbits, reports, pointMetadata] = nativeSelectedSolutions(file, pointIndices, branch_index, source, sourceStat)
    % Full native values from the actual twice-public-validated index.
    % Results are column cells in requested order. Repeated indices
    % refer to the same objects in this one native load; use separate
    % calls when independent deserialization is required.
    file = sourceFileName(file);
    assert(strcmp(file,source.file)&&strcmp(branch_index.storage_version,'BranchSolutionFile_v3:2') ...
        &&strcmp(RoundSHA256_v3(which('BranchSolutionFile_v3')),'ee7336bee19d5fca4bd5be62b6bab22e428d14fdfe37e801c7b040610aa8bccc'), ...
        'C1NearPlane:NativeReader','Use the pinned schema2 public index/complete-variable proof and unchanged public validator semantics.');
    sourceUnchanged(source,sourceStat);
    assert(isnumeric(pointIndices) && isreal(pointIndices) && ...
        (isvector(pointIndices) || isempty(pointIndices)), ...
        'BranchSolutionFile_v3:Bounds', ...
        'Point indices must be a real numeric vector.');
    pointIndices = pointIndices(:);
    count = numel(pointIndices);
    orbits = cell(count, 1);
    reports = cell(count, 1);
    pointMetadata = cell(count, 1);
    variables = cell(count * (1 + double(nargout > 1)), 1);
    variableIndex = 0;
    for k = 1:count
        sourcePositiveIndex(pointIndices(k));
        assert(pointIndices(k) <= numel(branch_index.points), ...
            'BranchSolutionFile_v3:Bounds', 'Point index is outside this file.');
        point = branch_index.points{pointIndices(k)};
        variableIndex = variableIndex + 1;
        variables{variableIndex} = point.solution_variable;
        if nargout > 1
            variableIndex = variableIndex + 1;
            variables{variableIndex} = point.report_variable;
        end
    end
    if count == 0, return; end
    saved = load(file, variables{:});
    for k = 1:count
        point = branch_index.points{pointIndices(k)};
        orbit = saved.(point.solution_variable);
        assert(strcmp(class(orbit), 'HybridOrbit_v3') && isscalar(orbit), ...
            'BranchSolutionFile_v3:Orbit', 'The saved solution is not one native HybridOrbit_v3.');
        sourceValidateValue(orbit, true, 0);
        orbits{k} = orbit;
        if nargout > 1
            report = saved.(point.report_variable);
            sourceValidateValue(report, false, 0);
            reports{k} = report;
        end
        if nargout > 2, pointMetadata{k} = point.metadata; end
    end
    sourceUnchanged(source,sourceStat);
end

function sourceValidateValue(value, allowNative, depth)
    assert(depth <= 128, 'BranchSolutionFile_v3:Depth', ...
        'Cyclic or excessively nested data is unsupported.');
    if isnumeric(value) || islogical(value) || ischar(value) || isstring(value)
        return
    elseif iscell(value)
        for k = 1:numel(value)
            sourceValidateValue(value{k}, allowNative, depth + 1);
        end
    elseif isstruct(value)
        names = fieldnames(value);
        for k = 1:numel(value)
            for j = 1:numel(names)
                sourceValidateValue(value(k).(names{j}), allowNative, depth + 1);
            end
        end
    elseif allowNative && any(strcmp(class(value), {'HybridOrbit_v3', 'Trajectory_v3'}))
        names = properties(value);
        for k = 1:numel(value)
            for j = 1:numel(names)
                sourceValidateValue(value(k).(names{j}), true, depth + 1);
            end
        end
    else
        error('BranchSolutionFile_v3:ValueClass', ...
            'Unsupported data class %s; reports and metadata must contain plain data.', class(value));
    end
end

function sourceUnchanged(source,before)
    after=dir(source.file);assert(isscalar(after)&&~after.isdir&&isequal(after.bytes,before.bytes)&&isequal(after.datenum,before.datenum), ...
        'C1EssentialComplete:SourceStat','The pinned source metadata changed between index and selected-variable reads.');verify({source});
end

function file = sourceFileName(file)
    sourceTextScalar(file);
    file = char(java.io.File(char(file)).getCanonicalPath());
    [~, ~, extension] = fileparts(file);
    assert(strcmpi(extension, '.mat'), ...
        'BranchSolutionFile_v3:Path', 'The branch file must end in .mat.');
end

function sourceTextScalar(value)
    assert((ischar(value) && isrow(value)) || (isstring(value) && isscalar(value)), ...
        'BranchSolutionFile_v3:Text', 'Expected nonempty scalar text.');
    assert(~ismissing(string(value)) && strlength(strtrim(string(value))) > 0, ...
        'BranchSolutionFile_v3:Text', 'Expected nonempty scalar text.');
end

function sourcePositiveIndex(value)
    assert(isnumeric(value) && isreal(value) && isscalar(value) && ...
        isfinite(value) && value >= 1 && value == fix(value) && value <= flintmax, ...
        'BranchSolutionFile_v3:Bounds', 'Expected one positive integer index.');
end

