function receipt=CompactPKStudyEvidence_v3(sourceReferences,outputFile,options)
%COMPACTPKSTUDYEVIDENCE_V3 Retain known PK study facts without dense traces.
% Supported producers are the literal-P1, PIP-daughter and P1-counterpart
% audits, and the known C1 pending-native custody summaries. This is a
% retention projection, never admission, pending reconciliation or resume.
% The existing CompactResearchBranch transform supplies endpoint/event trace
% summaries. Primary native orbit properties are additionally retained as
% plain records, so its shorter diagnostic-orbit summary loses no core field.
% Live constrained residual/FD objects become explicit data descriptors.
% Original sources are never modified or removed. The caller owns retirement.
    timer=tic;entryUTC=unixNow();
    keys={'MaximumBytes';'MaxWallSeconds';'SaveMarginSeconds'};
    assert(nargin==3&&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort(keys)), ...
        'PKStudyCompact:Options','Supply MaximumBytes, MaxWallSeconds and SaveMarginSeconds.');
    o=options;
    for k=1:numel(keys),validateattributes(o.(keys{k}),{'double'},{'scalar','real','finite','positive'});end
    assert(o.MaximumBytes<=30*1024^2&&o.SaveMarginSeconds<o.MaxWallSeconds, ...
        'PKStudyCompact:Bounds','Use at most30MiB and a positive reserve below the whole wall cap.');
    assert(iscell(sourceReferences)&&iscolumn(sourceReferences)&&~isempty(sourceReferences)&&numel(sourceReferences)<=6, ...
        'PKStudyCompact:Sources','Use one to six explicit immutable native source references.');
    outputFile=canonical(outputFile);stage=[outputFile,'.pending.mat'];embedded=[outputFile,'.embedded_checkpoint.mat'];
    assert(isfolder(fileparts(outputFile))&&~isfile(outputFile)&&~isfile(stage)&&~isfile(embedded), ...
        'PKStudyCompact:Fresh','Use fresh output, stage and owned embedded-checkpoint paths.');
    sources=cellfun(@checkedReference,sourceReferences,'UniformOutput',false);
    assert(numel(unique(cellfun(@(r)r.file,sources,'UniformOutput',false)))==numel(sources) ...
        &&~any(cellfun(@(r)strcmp(r.file,outputFile),sources)), ...
        'PKStudyCompact:Ownership','Sources must be distinct and the output cannot replace a source.');
    methods={reference([mfilename('fullpath'),'.m']);reference(which('CompactResearchBranch_v3')); ...
        reference(which('OrbitContentIdentity_v3'));reference(which('RoundSHA256_v3'))};
    evidence=struct('schema','C1-PK-compact-study-evidence-v1','source_references',{sources}, ...
        'source_code',{methods},'studies',{cell(numel(sources),1)},'completed',false,'source_posthash',false, ...
        'physical_services',0,'pending_reconciliation_performed',false,'fresh_admission_claimed',false, ...
        'loss_disclosure',['Dense trajectory samples and nested diagnostic orbits are replaced by the existing ', ...
        'endpoint/event summaries. Runtime residual/map closures and callbacks cannot be reconstructed. ', ...
        'Embedded old MAT byte images are omitted after exact native restoration and projection. ', ...
        'Saved numerical flags, matrices, configurations, event/flight evidence and pending states remain historical data. ', ...
        'This file cannot resume an interrupted service or reproduce omitted FD/dense replay tapes.']);
    visits=0;runtimeNotes={};temporarySHA='';
    for si=1:numel(sources)
        guard(false);s=sources{si};verify(s);names=whos('-file',s.file);
        variableNames={names.name};
        assert(xor(any(strcmp(variableNames,'audit')),any(strcmp(variableNames,'summary'))), ...
            'PKStudyCompact:Variable','A known source must contain audit or summary, without ambiguity.');
        if any(strcmp(variableNames,'audit')),variable='audit';else,variable='summary';end
        saved=load(s.file,variable);original=saved.(variable);clear saved
        assert(isstruct(original)&&isscalar(original),'PKStudyCompact:Producer','Use a scalar known native producer structure.');
        runtimeNotes={};primary={};restoredSummary=[];
        if strcmp(variable,'summary')
            requireCustody(original);producer=original.protocol;
            primary=primaryPending(original,'summary');studyType='historical-pending-native-custody';
        else
            assert(isfield(original,'schema'),'PKStudyCompact:Producer','The native audit needs its literal producer schema.');
            producer=original.schema;studyType=studyKind(producer);
            if strcmp(studyType,'embedded-pending-native-custody')
                requireFields(original,{'exact_original_checkpoint_file_bytes','original_checkpoint_reference'});
                bytes=original.exact_original_checkpoint_file_bytes;r=original.original_checkpoint_reference;
                assert(isa(bytes,'uint8')&&isvector(bytes)&&isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})), ...
                    'PKStudyCompact:Embedded','Require the literal embedded uint8 MAT image and its recorded reference.');
                assert(~isfile(embedded),'PKStudyCompact:EmbeddedStage','An earlier embedded stage is held for inspection.');
                fid=fopen(embedded,'wb');assert(fid>=0,'PKStudyCompact:Write','Cannot create the owned embedded stage.');
                closer=onCleanup(@()fclose(fid));count=fwrite(fid,bytes,'uint8');clear closer
                assert(count==numel(bytes)&&strcmp(RoundSHA256_v3(embedded),r.sha256), ...
                    'PKStudyCompact:EmbeddedSHA','The exact embedded MAT bytes do not match their original checkpoint.');
                temporarySHA=r.sha256;guard(false);z=load(embedded,'summary');restoredSummary=z.summary;clear z
                requireCustody(restoredSummary);primary=primaryPending(restoredSummary,'embedded.summary');
                original.exact_original_checkpoint_file_bytes=struct('diagnostic_kind','omitted-exact-MAT-byte-image', ...
                    'source_reference',r,'uint8_count',numel(bytes),'exact_restoration_SHA_verified',true,'byte_rerun_available',false);
                clear bytes
            else
                requireFields(original,{'rows','cursor','completed','source_posthash'});
                expected=179;if strcmp(studyType,'PIP-parents-and-daughters'),expected=18;elseif strcmp(studyType,'P1-pronk-counterparts'),expected=3;end
                assert(iscell(original.rows)&&numel(original.rows)==expected&&all(~cellfun(@isempty,original.rows)) ...
                    &&isequal(original.cursor,expected+1)&&isequal(original.completed,true)&&isequal(original.source_posthash,true), ...
                    'PKStudyCompact:CompleteStudy','Require the actual completed source; preserve partial custody through its separate known adapter.');
                for ri=1:expected
                    row=original.rows{ri};
                    if isfield(row,'orbit')&&isa(row.orbit,'HybridOrbit_v3')&&isscalar(row.orbit)
                        primary{end+1,1}=nativeRecord(row.orbit,sprintf('audit.rows{%d}.orbit',ri));
                    end
                end
            end
        end
        clean=runtimeData(original,'source',0);holder=CompactResearchBranch_v3(struct('evidence',clean));
        projection=holder.evidence;
        verifyFacts(clean,projection,'source',0);assertPlain(projection,0);
        additional=struct();
        if ~isempty(restoredSummary)
            cleanSummary=runtimeData(restoredSummary,'embedded.summary',0);
            h=CompactResearchBranch_v3(struct('evidence',cleanSummary));additional=h.evidence;
            verifyFacts(cleanSummary,additional,'embedded.summary',0);assertPlain(additional,0);
        end
        for pi=1:numel(primary),assertPlain(primary{pi},0);end
        evidence.studies{si}=struct('kind',studyType,'source_reference',s,'source_variable',variable, ...
            'source_producer_schema',producer,'source_field_names',{fieldnames(original)}, ...
            'projection',projection,'restored_pending_summary',additional,'primary_native_records',{primary}, ...
            'runtime_descriptors',{runtimeNotes},'existing_compaction_report',holder.compact_checkpoint, ...
            'nontrace_facts_verified_unchanged',true,'primary_native_properties_verified',true);
        verify(s);guard(false);clear original clean projection holder primary restoredSummary cleanSummary h additional
    end
    for k=1:numel(sources),verify(sources{k});end
    for k=1:numel(methods),verify(methods{k});end
    evidence.completed=true;evidence.source_posthash=true;guard(true);
    save(stage,'evidence','-v7');d=dir(stage);
    assert(d.bytes<=o.MaximumBytes,'PKStudyCompact:MaximumBytes','The projected study file exceeds its declared maximum; retain source and unqualified stage.');
    one=load(stage,'evidence');two=load(stage,'evidence');
    assert(isequaln(evidence,one.evidence)&&isequaln(evidence,two.evidence), ...
        'PKStudyCompact:Readback','Two independent native reads must preserve the complete plain evidence.');
    guard(true);for k=1:numel(sources),verify(sources{k});end
    for k=1:numel(methods),verify(methods{k});end
    opts=javaArray('java.nio.file.CopyOption',1);opts(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');
    javaMethod('move','java.nio.file.Files',java.io.File(stage).toPath(),java.io.File(outputFile).toPath(),opts);
    out=reference(outputFile);guard(true);
    if ~isempty(temporarySHA)
        assert(strcmp(RoundSHA256_v3(embedded),temporarySHA),'PKStudyCompact:TemporarySHA','The owned restored checkpoint stage changed.');
        delete(embedded); % Only this utility's verified temporary byte image.
    end
    receipt=struct('schema','C1-PK-compact-study-evidence-receipt-v1','output_reference',out, ...
        'source_references',{sources},'source_code',{methods},'study_count',numel(sources), ...
        'all_nontrace_facts_verified',true,'plain_independent_read2_verified',true,'source_posthash',true, ...
        'elapsed_seconds',toc(timer),'physical_services',0,'pending_reconciliation_performed',false, ...
        'original_sources_removed',0,'loss_disclosure',evidence.loss_disclosure);

    function record=nativeRecord(orbit,path)
        values=struct();nativePropertyNames=properties(orbit);
        for ni=1:numel(nativePropertyNames),values.(nativePropertyNames{ni})=orbit.(nativePropertyNames{ni});end
        cleanValues=runtimeData(values,path,0);nativeHolder=CompactResearchBranch_v3(struct('native_record',cleanValues));
        nativeProperties=nativeHolder.native_record;
        verifyFacts(cleanValues,nativeProperties,path,0);assertPlain(nativeProperties,0);
        record=struct('source_path',path,'native_id',OrbitContentIdentity_v3(orbit), ...
            'original_properties',{nativePropertyNames},'properties',nativeProperties,'dense_trajectory_retained',false);
    end
    function records=primaryPending(s,path)
        records={};p=s.pending_admission;
        if isstruct(p)&&isscalar(p)&&isfield(p,'orbit')&&isa(p.orbit,'HybridOrbit_v3')
            records{end+1,1}=nativeRecord(p.orbit,[path,'.pending_admission.orbit']);
        end
        if isfield(s,'pending_batch')
            assert(iscell(s.pending_batch),'PKStudyCompact:PendingBatch','Keep the literal pending batch shape.');
            for bi=1:numel(s.pending_batch)
                p=s.pending_batch{bi};if isfield(p,'orbit')&&isa(p.orbit,'HybridOrbit_v3'),records{end+1,1}=nativeRecord(p.orbit,sprintf('%s.pending_batch{%d}.orbit',path,bi));end
            end
        end
        assert(~isempty(records),'PKStudyCompact:CustodyOrbit','The known pending custody must retain an actual native orbit.');
    end
    function out=runtimeData(v,path,depth)
        visit(depth);out=v;
        if strcmp(class(v),'ConstrainedEnergyResidual_v3')&&isscalar(v)
            fields={'ClosureTolerance','ActivePositions','ReferenceCoordinates','EquationPositions','Constraint','Augmented','ResidualScale'};data=struct();
            for fi=1:numel(fields),data.(fields{fi})=v.(fields{fi});end
            f=v.Family;assert(strcmp(class(f),'EnergyFamilyResidual_v3'),'PKStudyCompact:Residual','Only the known energy residual capture is supported.');
            family=struct();fields={'Chart','CoordinateIndices','ClosureIndices','EnergyPivot','PhysicalParameter','Symmetry','ClosureTolerance','EnergyGradientTolerance'};
            for fi=1:numel(fields),family.(fields{fi})=f.(fields{fi});end
            data.Family=family;out=struct('diagnostic_kind','omitted-live-residual-capture','source_class',class(v), ...
                'numerical_definition',data,'omitted_runtime_fields',{{'Map','Family.Map','Family.BaseProblem'}},'requires_runtime_reconstruction',true);
            runtimeNotes{end+1,1}=struct('path',path,'source_class',class(v),'scope','Numerical definition retained; runtime graph omitted.');
        elseif any(strcmp(class(v),{'FiniteDifferenceJacobian_v3','ValidSidedFiniteDifferenceJacobian_v3'}))&&isscalar(v)
            fields=properties(v);data=struct();for fi=1:numel(fields),data.(fields{fi})=v.(fields{fi});end
            out=struct('diagnostic_kind','runtime-object-descriptor','source_class',class(v),'settings',data,'requires_runtime_reconstruction',true);
            runtimeNotes{end+1,1}=struct('path',path,'source_class',class(v),'scope','Every public FD setting retained as data.');
        elseif isstruct(v)
            fields=fieldnames(v);for vi=1:numel(v),for fi=1:numel(fields),out(vi).(fields{fi})=runtimeData(v(vi).(fields{fi}),sprintf('%s(%d).%s',path,vi,fields{fi}),depth+1);end;end
        elseif iscell(v)
            for vi=1:numel(v),out{vi}=runtimeData(v{vi},sprintf('%s{%d}',path,vi),depth+1);end
        end
    end
    function verifyFacts(a,b,path,depth)
        visit(depth);
        if isstruct(b)&&isscalar(b)&&isfield(b,'diagnostic_kind')
            kind=char(b.diagnostic_kind);
            if any(strcmp(kind,{'duplicate-orbit-summary','duplicate-trajectory-summary'}))&&~existingSummary(a)
                assert(strcmp(b.source_class,class(a))&&isequal(b.full_trace_preserved,false),'PKStudyCompact:SummaryClass','Unexpected trace transform at %s.',path);
                fields=fieldnames(b);skip={'diagnostic_kind','source_class','full_trace_preserved','sample_count','time_interval','initial_state','final_state','initial_mode','final_mode'};
                if strcmp(kind,'duplicate-trajectory-summary')
                    t=member(a,'time',[]);x=member(a,'state',[]);q=member(a,'mode',[]);
                    assert(b.sample_count==numel(t),'PKStudyCompact:TraceCount','Trace sample count changed at %s.',path);
                    if ~isempty(t),assert(isequaln(b.time_interval,[t(1),t(end)]),'PKStudyCompact:TraceEndpoints','Trace times changed.');end
                    if ~isempty(x),assert(isequaln(b.initial_state,x(1,:))&&isequaln(b.final_state,x(end,:)),'PKStudyCompact:TraceEndpoints','Trace state endpoints changed.');end
                    if ~isempty(q),assert(isequaln(b.initial_mode,q(1,:))&&isequaln(b.final_mode,q(end,:)),'PKStudyCompact:TraceEndpoints','Trace mode endpoints changed.');end
                else,skip={'diagnostic_kind','source_class','full_trace_preserved'};end
                for fi=1:numel(fields),key=fields{fi};if ~ismember(key,skip),verifyFacts(member(a,key,[]),b.(key),[path,'.',key],depth+1);end;end
                return
            elseif isa(a,'function_handle')
                assert(strcmp(kind,'runtime-function-descriptor')&&strcmp(b.signature,func2str(a))&&b.requires_runtime_reconstruction, ...
                    'PKStudyCompact:Callback','A callback descriptor changed at %s.',path);return
            elseif isobject(a)&&~isstring(a)
                assert(strcmp(kind,'runtime-object-descriptor')&&strcmp(b.source_class,class(a)),'PKStudyCompact:Runtime','An unknown runtime object remains at %s.',path);
                fields=properties(a);for fi=1:numel(fields),key=fields{fi};verifyFacts(a.(key),b.settings.(key),[path,'.',key],depth+1);end;return
            end
        end
        if isstruct(a)
            assert(isstruct(b)&&isequal(size(a),size(b))&&isequal(fieldnames(a),fieldnames(b)),'PKStudyCompact:Fields','Nontrace fields changed at %s.',path);
            fields=fieldnames(a);for vi=1:numel(a),for fi=1:numel(fields),key=fields{fi};verifyFacts(a(vi).(key),b(vi).(key),[path,'.',key],depth+1);end;end
        elseif iscell(a)
            assert(iscell(b)&&isequal(size(a),size(b)),'PKStudyCompact:CellShape','Cell shape changed at %s.',path);
            for vi=1:numel(a),verifyFacts(a{vi},b{vi},sprintf('%s{%d}',path,vi),depth+1);end
        else
            assert(~isobject(a)||isstring(a),'PKStudyCompact:UnknownObject','Unsupported retained object at %s.',path);
            assert(isequaln(a,b),'PKStudyCompact:Fact','A nontrace fact changed at %s.',path);
        end
    end
    function yes=existingSummary(v)
        yes=isstruct(v)&&isscalar(v)&&all(isfield(v,{'diagnostic_kind','source_class','full_trace_preserved'})) ...
            &&any(strcmp(v.diagnostic_kind,{'duplicate-orbit-summary','duplicate-trajectory-summary'})) ...
            &&isequal(v.full_trace_preserved,false);
    end
    function assertPlain(v,depth)
        visit(depth);
        if isstruct(v),fields=fieldnames(v);for vi=1:numel(v),for fi=1:numel(fields),assertPlain(v(vi).(fields{fi}),depth+1);end;end
        elseif iscell(v),for vi=1:numel(v),assertPlain(v{vi},depth+1);end
        else,assert(isnumeric(v)||islogical(v)||ischar(v)||isstring(v),'PKStudyCompact:Plain','The projection retains an unsupported runtime value.');end
    end
    function visit(depth)
        assert(depth<=64,'PKStudyCompact:Depth','The known source exceeds its bounded structural depth.');
        visits=visits+1;if mod(visits,1000)==0,guard(false);end
    end
    function guard(final)
        remaining=o.MaxWallSeconds-max(toc(timer),unixNow()-entryUTC);if ~final,remaining=remaining-o.SaveMarginSeconds;end
        assert(remaining>0,'PKStudyCompact:Clock','The bounded projection cap expired; preserve original sources and any unqualified stage.');
    end
end

function kind=studyKind(schema)
    switch char(schema)
        case 'PK15h-literal-P1-current-native-return-audit-v1',kind='literal-P1-returns';
        case 'PK15h-known-PIP-native-parent-daughter-stageB-v1',kind='PIP-parents-and-daughters';
        case 'PK15h-three-NEW-pronk-P1-counterpart-pilots-v1',kind='P1-pronk-counterparts';
        case 'C1-late-native-exact-custody-prepared-transaction-v1',kind='embedded-pending-native-custody';
        otherwise,error('PKStudyCompact:UnknownProducer','Unsupported producer schema: %s.',char(schema));
    end
end
function requireCustody(s)
    requireFields(s,{'protocol','pending_admission'});
    assert(strcmp(s.protocol,'C1-compact-native-state-PAL-v1')&&isstruct(s.pending_admission)&&isscalar(s.pending_admission), ...
        'PKStudyCompact:CustodySchema','Only the known C1 pending-native summary protocol is supported.');
end
function requireFields(s,fields)
    assert(all(isfield(s,fields)),'PKStudyCompact:Fields','The known producer is missing required fields.');
end
function value=member(v,key,fallback)
    value=fallback;if isstruct(v)&&isscalar(v)&&isfield(v,key),value=v.(key);elseif isobject(v)&&isscalar(v)&&isprop(v,key),value=v.(key);end
end
function r=checkedReference(r)
    assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'PKStudyCompact:Reference','Use an immutable FILE/SHA reference.');
    f=canonical(r.file);d=dir(f);assert(isscalar(d)&&~d.isdir,'PKStudyCompact:Missing','A selected source is unavailable.');
    if isfield(r,'bytes'),assert(d.bytes==r.bytes,'PKStudyCompact:Bytes','Selected source bytes changed.');end
    r=struct('file',f,'sha256',r.sha256,'bytes',d.bytes);verify(r);
end
function verify(r)
    d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
        'PKStudyCompact:Changed','An immutable source or method changed: %s.',r.file);
end
function r=reference(file)
    file=canonical(file);d=dir(file);assert(isscalar(d)&&~d.isdir,'PKStudyCompact:Missing','A required method/output is unavailable.');
    r=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',d.bytes);
end
function file=canonical(file),file=char(java.io.File(char(file)).getCanonicalPath());end
function value=unixNow(),value=posixtime(datetime('now','TimeZone','UTC'));end
