function catalog=CompleteRemaining53SnapshotBytes20261105(rosterReference,prefixReference,maxWallSeconds)
% Exact byte custody of the remaining small legacy snapshots, not a loader.
% No graph/point/model validation or native object restoration is performed.
validateattributes(maxWallSeconds,{'double'},{'scalar','real','finite','>',120,'<=',1800});
timer=tic;u0=unixNow();method=ref([mfilename('fullpath'),'.m']);rosterReference=checkRef(rosterReference);prefixReference=checkRef(prefixReference);
roster=jsondecode(fileread(rosterReference.file));assert(strcmp(roster.schema,'C1-explicit-native-facts-source-roster-v1')&&numel(roster.source_references)==53,'Byte53:Roster','Use the exact closed53-source roster.');
sources=roster.source_references;if isstruct(sources),sources=num2cell(sources(:));else,sources=sources(:);end
z=load(prefixReference.file,'catalog');catalog=z.catalog;clear z
assert(strcmp(catalog.schema,'C1-historical-essential-audit-facts-v1')&&numel(catalog.rows)==53 ...
    &&catalog.cursor>=41&&catalog.cursor<=54,'Byte53:Prefix','Use the exact closed remaining53 catalog after its first40 slots.');
replaceHeld=[5,9,11,14];protected=setdiff(1:40,replaceHeld);first40=catalog.rows(protected);priorSHA=prefixReference.sha256;output=prefixReference.file;
assert(~isfile([output,'.byte.pending.mat']),'Byte53:Stage','Preserve any unknown byte-custody stage.');
if ~isfield(catalog,'exact_snapshot_byte_custody'),catalog.exact_snapshot_byte_custody={};end
catalog.exact_snapshot_byte_custody{end+1,1}=struct('method_reference',method,'roster_reference',rosterReference, ...
    'previous_reference',prefixReference,'first_source_index',catalog.cursor,'replaced_held_outcomes',{{}},'scope','Complete original MAT streams; no scientific/current-loader validation or new admission.');
catalog.source_posthash=false;
indices=[replaceHeld,catalog.cursor:53];
for k=indices
    guard(60);r=catalog.rows{k};source=checkRef(sources{k});
    assert(source.bytes<=8*1024^2,'Byte53:SourceBound','This bounded route accepts only the declared small remaining snapshots.');
    assert(isequaln(r.inventory_reference,sources{k}),'Byte53:Membership','Source membership changed.');
    if k<=40
        if r.retirement_eligible&&isfield(r,'retention_schema')&&strcmp(r.retention_schema,'C1-exact-unvalidated-legacy-MAT-byte-custody-v1'),continue;end
        assert(startsWith(r.status,'RAW_HELD')&&~r.retirement_eligible,'Byte53:Held','Replace only the four explicit already-assessed raw holds.');
        catalog.exact_snapshot_byte_custody{end}.replaced_held_outcomes{k}=r;
    elseif ~startsWith(r.status,'NOT_ASSESSED'),catalog.cursor=k+1;continue;end
    one=readBytes(source.file);two=readBytes(source.file);
    assert(numel(one)==source.bytes&&isequal(one,two),'Byte53:Read2','Independent native source-byte reads changed.');checkRef(source);guard(30);
    r.source_reference=source;r.source_posthash=true;r.retirement_eligible=true;
    r.status='ESSENTIAL_FACTS_PROJECTED';r.primary_records={};r.selected_final_facts={};r.unknowns={};r.failure=struct();
    r.facts=struct('schema','C1-exact-unvalidated-legacy-MAT-byte-custody-v1','original_reference',source, ...
        'original_mat_file_bytes',one,'independent_native_fread_equal',true, ...
        'current_loader_or_scientific_validation_performed',false, ...
        'restoration_scope','Write these exact bytes to a MAT file and verify original SHA/length before a suitable reader; all original historical decisions and missingness are preserved.');
    r.retention_schema='C1-exact-unvalidated-legacy-MAT-byte-custody-v1';
    r.retention_scope='The complete original payload is retained, not requalified; no Root, model, replay, graph or point evaluation.';
    r.omissions={};catalog.rows{k}=r;if k>=41,catalog.cursor=k+1;end;clear one two
    persist();fprintf('EXACT_SNAPSHOT_BYTES source=%d/53 original_bytes=%d\n',k,source.bytes);
end
checkRef(method);checkRef(rosterReference);guard(0);catalog.source_posthash=true;catalog.completed=true;persist();
fprintf('EXACT_SNAPSHOT_BYTES_RETURN cursor=%d complete=%d eligible=%d held=%d seconds=%.6f\n',catalog.cursor,catalog.completed,catalog.retirement_eligible_count,catalog.raw_held_count,toc(timer));
    function guard(reserve)
        assert(max(toc(timer),unixNow()-u0)<maxWallSeconds-reserve,'Byte53:Clock','The explicit data-only clock expired; preserve prior catalog and originals.');
    end
    function persist()
        guard(0);assert(isequaln(catalog.rows(protected),first40),'Byte53:Prefix','A successful first40 literal outcome changed.');
        assert(strcmp(RoundSHA256_v3(output),priorSHA),'Byte53:CAS','The owned catalog changed.');
        catalog.retirement_eligible_count=sum(cellfun(@(r)r.retirement_eligible,catalog.rows));
        catalog.raw_held_count=sum(cellfun(@(r)startsWith(r.status,'RAW_HELD')||startsWith(r.status,'KEEP_ORIGINAL'),catalog.rows));
        stage=[output,'.byte.pending.mat'];assert(~isfile(stage),'Byte53:Stage','An unknown owned stage remains held.');
        save(stage,'catalog','-v7');a=load(stage,'catalog');b=load(stage,'catalog');
        assert(isequaln(a.catalog,catalog)&&isequaln(b.catalog,catalog),'Byte53:AggregateRead2','The complete native plain aggregate/byte vectors changed.');
        d=dir(stage);assert(d.bytes<=40*1024^2,'Byte53:Size','The complete byte-custody aggregate exceeds its explicit40MiB cap.');
        guard(0);[ok,msg]=movefile(stage,output,'f');assert(ok,'Byte53:Publish','%s',msg);priorSHA=RoundSHA256_v3(output);
        index=rmfield(catalog,'rows');index.rows=cellfun(@(r)struct('inventory_reference',r.inventory_reference, ...
            'source_reference',r.source_reference,'status',r.status,'retirement_eligible',r.retirement_eligible, ...
            'source_posthash',r.source_posthash,'failure',r.failure,'unknowns',{r.unknowns}),catalog.rows,'UniformOutput',false);
        encoded=unicode2native(jsonencode(index),'UTF-8');jsonStage=[output,'.json.byte.pending'];
        assert(~isfile(jsonStage),'Byte53:Stage','An unknown JSON stage remains held.');
        fid=fopen(jsonStage,'w');assert(fid>=0,'Byte53:Open','Cannot create the JSON stage.');closer=onCleanup(@()fclose(fid));
        assert(fwrite(fid,encoded,'uint8')==numel(encoded),'Byte53:Write','Short JSON write.');clear closer
        [ok,msg]=movefile(jsonStage,[output,'.json'],'f');assert(ok,'Byte53:Publish','%s',msg);
    end
end
function bytes=readBytes(file)
fid=fopen(file,'r');assert(fid>=0,'Byte53:Open','Cannot read the exact original MAT stream.');closeFile=onCleanup(@()fclose(fid));bytes=fread(fid,Inf,'*uint8');clear closeFile
end
function r=checkRef(r)
d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'Byte53:Hash','An exact closed input changed.');
end
function r=ref(file)
d=dir(file);r=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',d.bytes);
end
function u=unixNow(),u=posixtime(datetime('now','TimeZone','UTC'));end
