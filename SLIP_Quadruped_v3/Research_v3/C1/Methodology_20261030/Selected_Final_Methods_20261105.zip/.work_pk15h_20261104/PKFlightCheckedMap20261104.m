classdef PKFlightCheckedMap20261104 < PoincareMap_v3
    %PKFLIGHTCHECKEDMAP20261104 Private raw-flight supplement on native maps.
    % The native map and residual chain are unchanged. A trial that cannot
    % pass the declared supplement never returns a finite residual upstream.
    properties (SetAccess=immutable)
        FlightOptions
        MethodReferences
    end
    properties (SetAccess=private)
        LastFlightCheck=struct()
    end
    methods
        function obj=PKFlightCheckedMap20261104(system,section,simulator,policy,mapOptions,flightOptions,methodReferences)
            obj@PoincareMap_v3(system,section,simulator,policy,mapOptions);
            assert(isstruct(flightOptions)&&isscalar(flightOptions) ...
                &&isfield(flightOptions,'EventTimeTolerance')&&isfield(flightOptions,'Limits'), ...
                'PKFlightCheckedMap:Configuration','Declare immutable flight tolerances, cushions and parent clocks.');
            assert(isequal(flightOptions.EventTimeTolerance,simulator.Options.EventTimeTolerance), ...
                'PKFlightCheckedMap:TimeTolerance','Retain the native simulator EventTimeTolerance.');
            assert(iscell(methodReferences)&&iscolumn(methodReferences)&&numel(methodReferences)>=5, ...
                'PKFlightCheckedMap:Methods','Supply exact source SHA/byte bindings as a column cell.');
            obj.FlightOptions=flightOptions;obj.MethodReferences=methodReferences;obj.verifyMethods();obj.checkParent();
        end
        function [xNext,info]=evaluate(obj,x0,q0,p,evaluationOptions)
            if nargin<5,evaluationOptions=struct();end
            obj.LastFlightCheck=struct();obj.verifyMethods();obj.checkParent();
            [xNext,info]=evaluate@PoincareMap_v3(obj,x0,q0,p,evaluationOptions);
            actualTimeTolerance=obj.Simulator.Options.EventTimeTolerance;
            if isfield(info.integration_overrides,'EventTimeTolerance')
                actualTimeTolerance=info.integration_overrides.EventTimeTolerance;
            end
            assert(isequal(actualTimeTolerance,obj.FlightOptions.EventTimeTolerance), ...
                'PKFlightCheckedMap:TimeTolerance','Evaluation changed the declared native EventTimeTolerance.');
            evidence=CheckC1PKOrbitFlights_v3(info,p,obj.FlightOptions);
            evidence.method_references=obj.MethodReferences;obj.LastFlightCheck=evidence;
            info.c1_PK_actual_flight_supplement=evidence;obj.verifyMethods();obj.checkParent();
            if strcmp(evidence.status,'VIOLATION')
                error('PKFlightCheckedMap:Violation','Actual raw flight supplement rejected this map: %s.',evidence.reason);
            elseif ~strcmp(evidence.status,'PASS')||~evidence.return_timely
                error('PKFlightCheckedMap:Unassessed','Actual raw flight supplement is unassessed: %s.',evidence.reason);
            end
        end
    end
    methods (Access=private)
        function checkParent(obj)
            l=obj.FlightOptions.Limits;
            assert(all(isfield(l,{'deadline_unix_seconds','deadline_monotonic_ns'})) ...
                &&double(java.time.Instant.now().toEpochMilli())/1000<l.deadline_unix_seconds ...
                &&double(java.lang.System.nanoTime())<l.deadline_monotonic_ns, ...
                'PKFlightCheckedMap:Unassessed','Parent deadline expired before a finite residual could return.');
        end
        function verifyMethods(obj)
            required={'PoincareMap_v3','AllFlightClearanceBounds_v3','CheckC1PKFlightInterval_v3', ...
                'CheckC1PKOrbitFlights_v3','PKFlightCheckedMap20261104'};
            paths=cell(size(obj.MethodReferences));
            for k=1:numel(obj.MethodReferences)
                r=obj.MethodReferences{k};
                assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256','bytes'})), ...
                    'PKFlightCheckedMap:Methods','Each source binding needs file/SHA256/bytes.');
                d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes ...
                    &&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
                    'PKFlightCheckedMap:MethodChanged','Frozen source bytes changed.');
                paths{k}=char(java.io.File(r.file).getCanonicalPath());
            end
            for k=1:numel(required)
                live=which(required{k});assert(~isempty(live)&&any(strcmp(paths, ...
                    char(java.io.File(live).getCanonicalPath()))), ...
                    'PKFlightCheckedMap:MethodBinding','The actual loaded method has no exact source binding.');
            end
        end
    end
end
