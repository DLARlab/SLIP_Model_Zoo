function result=AuditPK15hKnownPIPCriticalRoots20261104(B,options)
%AUDITPK15HKNOWNPIPCRITICALROOTS20261104 Finite restricted +1-root audit.
% Uses the existing vertical-parent variational service at TWO known origins.
% This neither shoots a native parent/daughter nor establishes an attachment.
    started=tic;utc=@()posixtime(datetime('now','TimeZone','UTC'));
    mono=@()double(java.lang.System.nanoTime());
    required={'OutputFile','SourceReferences','MaxWallSeconds','ReserveSeconds'};
    assert(isstruct(options)&&isscalar(options)&&all(isfield(options,required)) ...
        &&numel(fieldnames(options))==numel(required),'PKPIPRoots:Options','Use the four explicit options.');
    assert(B.capture.pid==feature('getpid'),'PKPIPRoots:Budget','Use this process calibration.');
    validateattributes(options.MaxWallSeconds,{'numeric'},{'scalar','real','finite','positive'});
    validateattributes(options.ReserveSeconds,{'numeric'},{'scalar','real','finite','positive'});
    assert(options.MaxWallSeconds>options.ReserveSeconds+30,'PKPIPRoots:Budget','Keep a real save reserve.');
    finishU=min(B.research_deadline_unix_seconds,utc()+options.MaxWallSeconds);
    finishM=min(B.research_deadline_monotonic_ns,mono()+options.MaxWallSeconds*1e9);
    out=char(java.io.File(options.OutputFile).getCanonicalPath());stage=[out,'.pending.mat'];
    jsonFile=[out,'.json'];
    assert(startsWith(out,[V3Root_v3(),filesep])&&endsWith(out,'.mat') ...
        &&~isfile(out)&&~isfile(stage)&&~isfile(jsonFile),'PKPIPRoots:Fresh','Use fresh v3 output paths.');
    refs=options.SourceReferences;if isstruct(refs),refs=num2cell(refs(:));else,refs=refs(:);end
    assert(iscell(refs)&&~isempty(refs),'PKPIPRoots:Sources','Supply the guarded method references.');
    servicePins=cellfun(@(r)isfield(r,'name')&&strcmp(r.name,'RestrictedPIPParentMatrix_v3'),refs);
    assert(nnz(servicePins)==1,'PKPIPRoots:Sources','Guard the one canonical restricted variational provider.');
    verify();checkWork();calls=0;
    p=[10;10;20;20;1;1;0;0;2;.5];
    brackets=[1.11,1.125;1.69,1.705];labels={'short_P1_related','known_long'};
    settings={struct('RelTol',1e-11,'AbsTol',1e-13), ...
        struct('RelTol',3e-13,'AbsTol',3e-15)};
    rows=cell(2,1);
    for k=1:2
        checkWork();row=struct('label',labels{k},'bracket',brackets(k,:), ...
            'status','UNASSESSED','failure',struct(),'numerical_checks_passed',false);
        try
            roots=zeros(1,2);passes=cell(2,1);
            for j=1:2
                lo=determinant(brackets(k,1),j);hi=determinant(brackets(k,2),j);
                assert(isfinite(lo)&&isfinite(hi)&&lo*hi<0,'PKPIPRoots:Bracket','Known bracket must strictly change sign.');
                [energy,value,exitflag,rootOutput]=fzero(@(e)determinant(e,j),brackets(k,:), ...
                    optimset('Display','off','TolX',1e-12));
                checkWork();assert(exitflag>0&&isfinite(energy)&&isfinite(value), ...
                    'PKPIPRoots:Root','A finite bracketed scalar root must actually return.');
                [M,info]=matrixAt(energy,j);J=M-eye(3);[U,S,V]=svd(J);
                v=V(:,end);[~,signIndex]=max(abs(v));if v(signIndex)<0,v=-v;end
                w=U(:,end);pair=w.'*v;
                assert(abs(pair)>1e-8,'PKPIPRoots:Simple','Left/right kernel pairing is too small for a simple eigenvalue.');
                w=w/pair;eigenvalues=eig(M);[eigenError,critical]=min(abs(eigenvalues-1));
                other=eigenvalues;other(critical)=[];
                steps=[1e-5,5e-6];derivatives=zeros(1,2);crossings=cell(2,1);
                for a=1:2
                    [left,leftInfo]=matrixAt(energy-steps(a),j);
                    [right,rightInfo]=matrixAt(energy+steps(a),j);
                    derivative=(right-left)/(2*steps(a));derivatives(a)=w.'*derivative*v;
                    crossings{a}=struct('energy_step',steps(a),'left_matrix',left,'right_matrix',right, ...
                        'left_determinant',det(left-eye(3)),'right_determinant',det(right-eye(3)), ...
                        'left_minimum_vertical_height',leftInfo.minimum_vertical_height, ...
                        'right_minimum_vertical_height',rightInfo.minimum_vertical_height, ...
                        'eigenvalue_directional_derivative',derivatives(a));
                end
                derivativeAgreement=abs(diff(derivatives))/max(abs(derivatives));
                strictCross=all(cellfun(@(c)c.left_determinant*c.right_determinant<0,crossings));
                checks=struct('positive_parent_height',info.minimum_vertical_height>0, ...
                    'small_root_determinant',abs(det(J))<1e-8, ...
                    'small_critical_eigenvalue_error',eigenError<1e-8, ...
                    'one_dimensional_numerical_kernel',S(2,2)>1e-5&&S(3,3)<1e-8, ...
                    'other_eigenvalues_separated_from_one',min(abs(other-1))>1e-5, ...
                    'horizontal_kernel_component_nonzero',abs(v(1))>1e-8, ...
                    'strict_determinant_crossings',strictCross, ...
                    'nonzero_consistent_eigenvalue_crossing',all(abs(derivatives)>1e-5) ...
                        &&prod(derivatives)>0&&isfinite(derivativeAgreement)&&derivativeAgreement<1e-3);
                passes{j}=struct('energy',energy,'fzero_value',value,'fzero_exitflag',exitflag, ...
                    'fzero_output',rootOutput,'matrix',M,'original_restricted_info',info, ...
                    'singular_values_DP_minus_I',diag(S),'right_kernel',v,'left_kernel_paired',w, ...
                    'raw_left_right_pairing',pair,'eigenvalues',eigenvalues, ...
                    'critical_eigenvalue_error',eigenError,'crossings',{crossings}, ...
                    'directional_derivative_relative_disagreement',derivativeAgreement,'checks',checks, ...
                    'all_checks_passed',all(structfun(@(x)logical(x),checks)));
                roots(j)=energy;
            end
            row.passes=passes;row.root_energy_agreement=abs(diff(roots));
            row.numerical_checks_passed=all(cellfun(@(x)x.all_checks_passed,passes))&&row.root_energy_agreement<5e-9;
            if row.numerical_checks_passed
                row.status='RESTRICTED_SIMPLE_PLUS_ONE_NUMERICALLY_SUPPORTED';
            else
                row.status='NUMERICAL_CHECK_NOT_SATISFIED';
            end
        catch problem
            row.failure=struct('identifier',problem.identifier,'message',problem.message);
        end
        rows{k}=row;
    end
    checkWork();verify();result=struct('schema','C1-known-PK-PIP-critical-root-audit-v1', ...
        'completed',true,'source_posthash',true,'physical_parameter',p,'rows',{rows}, ...
        'matrix_service_calls',calls,'all_numerical_checks_passed',all(cellfun(@(r)r.numerical_checks_passed,rows)), ...
        'source_references',{refs},'fixed_grant',struct('grant_id',B.grant_id,'start_utc',B.start_utc, ...
            'research_deadline_utc',B.research_deadline_utc,'deadline_utc',B.deadline_utc), ...
        'current_process_calibration',B.capture,'native_parent_shoots',0,'native_daughter_shoots',0, ...
        'new_P_edges',0,'new_M_relations',0,'parent_attachments_created',0, ...
        'full_quadruped_bifurcation_certificate',false,'formal_interval_certificate',false, ...
        'scope','Two known restricted fixed-energy synchronized-pronk origins only; numerical +1 evidence is not a parent/daughter attachment.', ...
        'matlab_release',version('-release'),'elapsed_seconds',toc(started));
    save(stage,'result','-v7');back=load(stage,'result');assert(isequaln(back.result,result),'PKPIPRoots:Readback','Plain audit readback differs.');
    assert(remaining()>0&&~isfile(out),'PKPIPRoots:Publication','Retain pending custody if late or target appeared.');
    [ok,msg]=movefile(stage,out);assert(ok,'PKPIPRoots:Publication','%s',msg);
    summaryRows=cellfun(@(r)struct('label',r.label,'status',r.status, ...
        'numerical_checks_passed',r.numerical_checks_passed,'failure',r.failure),rows,'UniformOutput',false);
    summary=struct('completed',result.completed,'source_posthash',result.source_posthash, ...
        'all_numerical_checks_passed',result.all_numerical_checks_passed,'rows',{summaryRows}, ...
        'matrix_service_calls',calls,'native_parent_shoots',0,'native_daughter_shoots',0, ...
        'parent_attachments_created',0,'new_P_edges',0,'new_M_relations',0, ...
        'audit_reference',struct('file',out,'sha256',RoundSHA256_v3(out),'bytes',fileBytes(out)));
    assert(~isfile(jsonFile),'PKPIPRoots:Fresh','Fresh JSON output appeared.');
    fid=fopen(jsonFile,'w');assert(fid>=0,'PKPIPRoots:JSON','Cannot create fresh JSON.');closer=onCleanup(@()fclose(fid));
    fwrite(fid,jsonencode(summary),'char');clear closer
    assert(remaining()>0,'PKPIPRoots:Publication','Publication returned after the operation deadline.');
    fprintf('PK15_KNOWN_PIP_CRITICAL_ROOTS %s\n',jsonencode(summary));
    function value=remaining(),value=min(finishU-utc(),(finishM-mono())/1e9);end
    function checkWork(),assert(remaining()>options.ReserveSeconds,'PKPIPRoots:Budget','Work slot ended; preserve the save reserve.');end
    function [M,info]=matrixAt(e,j)
        checkWork();calls=calls+1;assert(calls<=500,'PKPIPRoots:Calls','The finite two-root matrix-call cap was reached.');
        [M,info]=RestrictedPIPParentMatrix_v3(e,p,settings{j});checkWork();
        assert(isequal(size(M),[3,3])&&all(isfinite(M(:))),'PKPIPRoots:Matrix','Restricted matrix must remain finite 3 by 3.');
    end
    function value=determinant(e,j),M=matrixAt(e,j);value=det(M-eye(3));end
    function verify()
        for z=1:numel(refs)
            r=refs{z};assert(fileBytes(r.file)==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
                'PKPIPRoots:Changed','An immutable input method changed.');
            if isfield(r,'name'),assert(strcmp(which(r.name),r.file),'PKPIPRoots:Provider','A guarded method provider differs.');end
        end
    end
end

function n=fileBytes(file),d=dir(file);assert(isscalar(d)&&~d.isdir,'PKPIPRoots:File','Expected one regular file.');n=d.bytes;end
