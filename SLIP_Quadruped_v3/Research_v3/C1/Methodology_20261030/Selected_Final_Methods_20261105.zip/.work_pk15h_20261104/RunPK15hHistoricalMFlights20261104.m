function result=RunPK15hHistoricalMFlights20261104(action,B,queryReference,o)
%RUNPK15HHISTORICALMFLIGHTS20261104 Conditional flight beside unchanged old M.
% intake reads saved authorities only; supplement adds2 saved-flight checks
% and4 literal fine MAPs. No Root/P/qualify/classifier/old-file mutation.
keys={'OutputFile';'ResumeReference';'OldMRows';'MaxCases';'MaxWallSeconds';'SaveMarginSeconds';'FineReplaySeconds';'FlightOptions';'SourceReferences'};
assert(nargin==4&&any(strcmp(action,{'intake','supplement'}))&&isequal(sort(fieldnames(o)),sort(keys))&&B.capture.pid==feature('getpid'), ...
 'PKHistoricalM:API','Use the declared owned intake/supplement interface.');
assert(isequal(o.OldMRows(:),[2;3;6;9;10;11;13;15])&&isequal(o.FineReplaySeconds,120)&&iscell(o.SourceReferences)&&iscolumn(o.SourceReferences), ...
 'PKHistoricalM:Selection','Keep the eight literal generic95e rows and fixed fine cap.');
validateattributes(o.MaxCases,{'double'},{'scalar','integer','positive','<=',8});validateattributes(o.MaxWallSeconds,{'double'},{'scalar','finite','>',240,'<=',7200});
validateattributes(o.SaveMarginSeconds,{'double'},{'scalar','>=',120,'<',o.MaxWallSeconds/2});
assert(isstruct(o.FlightOptions)&&isscalar(o.FlightOptions)&&~isfield(o.FlightOptions,'Limits')&&o.FlightOptions.MaxWallSeconds==60, ...
 'PKHistoricalM:FlightOptions','Keep explicit physical cushions and60-second whole-flight caps.');
n=nowClock();finish=struct('u',min(B.research_deadline_unix_seconds,n.u+o.MaxWallSeconds),'m',min(B.research_deadline_monotonic_ns,n.m+o.MaxWallSeconds*1e9));
work=struct('u',finish.u-o.SaveMarginSeconds,'m',finish.m-o.SaveMarginSeconds*1e9);
providers(o.SourceReferences);pins=[o.SourceReferences;{queryReference}];verify(pins);check(work);
assert(strcmp(queryReference.sha256,'c1be4c8bd75d167038e3e4442bcf796931b0e1004c3c315f5e729879338e7781'),'PKHistoricalM:Query','Use the actual closed M/A selector query.');
z=load('-mat',queryReference.file,'query');q=z.query;clear z
assert(strcmp(q.schema,'PK15h-old-M-literal-selector-query-v1')&&q.completed&&q.source_posthash&&q.native_orbit_loads==0&&q.relations_promoted==0, ...
 'PKHistoricalM:QueryContract','The selector query itself must be closed saved-data evidence.');
pins=[pins;{q.current_reference;q.old_graph_reference}];verify(pins);
file=canonical(o.OutputFile);cp=[file,'.checkpoint.mat'];writing=[cp,'.writing.mat'];
assert(startsWith(file,[V3Root_v3(),filesep])&&endsWith(file,'.mat')&&~isfile(file)&&~isfolder(file)&&~isfile(writing), ...
 'PKHistoricalM:Fresh','Use a new sidecar and preserve original audits/carriers/evidence.');
grant=struct('grant_id',B.grant_id,'start_utc',B.start_utc,'research_deadline_utc',B.research_deadline_utc,'deadline_utc',B.deadline_utc);
configuration=struct('query_reference',queryReference,'selected_old_M_rows',o.OldMRows(:),'source_references',{o.SourceReferences}, ...
 'flight_options',o.FlightOptions,'fine_seconds',o.FineReplaySeconds,'output_file',file,'fixed_grant',grant);
owned='';
if isempty(fieldnames(o.ResumeReference))
 assert(~isfile(cp),'PKHistoricalM:FreshPrefix','Do not overwrite an earlier sidecar prefix.');
 overlay=struct('schema','PK15h-historical-generic-M-conditional-flight-sidecar-v1','configuration',configuration,'cursor',1,'rows',{cell(8,1)}, ...
  'completed',false,'source_posthash',false,'root_calls',0,'new_P_edges',0,'new_M_relations',0,'qualification_calls',0,'classification_calls',0, ...
  'historical_evidence_changed',false,'historical_flags_changed',false,'own_process_exit_claimed',false, ...
  'scope','Conditional current flight evidence beside unchanged qualified finite M only. Original e/audit/witness/P/flags remain authoritative and unchanged. No fresh all-nine admission, new M/P, identity, global branch or endpoint completion.');
 owned=savePrefix(cp,writing,overlay,owned,finish);
else
 assert(strcmp(canonical(o.ResumeReference.file),cp),'PKHistoricalM:ResumePath','Resume only the exact owned prefix.');verify({o.ResumeReference});
 z=load('-mat',cp,'overlay');overlay=z.overlay;clear z;owned=o.ResumeReference.sha256;
 assert(strcmp(overlay.schema,'PK15h-historical-generic-M-conditional-flight-sidecar-v1')&&isequaln(overlay.configuration,configuration) ...
  &&overlay.cursor>=1&&overlay.cursor<=9&&overlay.completed==(overlay.cursor==9),'PKHistoricalM:ResumeConfig','Resume identical fixed grant, inputs, physical settings and unfinished cursor.');
end
overlay.source_posthash=false;owned=savePrefix(cp,writing,overlay,owned,finish);processed=0;failure=struct();hold=false;
if strcmp(action,'intake'),queue=find(cellfun(@(r)isempty(r)||~r.intake_complete,overlay.rows));else,queue=overlay.cursor:8;end
for at=queue(:).'
 if processed>=o.MaxCases||left(work)<90,break;end
 queryRow=q.old_M{o.OldMRows(at)};e=queryRow.evidence;
 assert(strcmp(queryRow.kind,'GENERIC95E')&&strcmp(e.schema,'C1-qualified-finite-numerical-overlap-v1'), ...
  'PKHistoricalM:GenericOnly','Never coerce GateB or aliases into the generic retained protocol.');
 if isempty(overlay.rows{at})
  overlay.rows{at}=struct('old_M_row',o.OldMRows(at),'query_row',rmfield(queryRow,'evidence'),'original_evidence',e,'intake_complete',false, ...
   'epoch',struct(),'authority_references',{{}},'parent_flight_evidence',queryRow.incoming_P_parents{1}, ...
   'retained_validation_passed',false,'endpoint_rows',{cell(2,1)},'fine_rows',{cell(2,2)},'finalized',false, ...
   'six_current_flight_checks_PASS',false,'current_M_flight_eligible',false,'status','PREPARED_INTAKE','failure',struct());
  owned=savePrefix(cp,writing,overlay,owned,finish);
 end
 row=overlay.rows{at};a=[];
 try
  authority={e.audit_reference;queryRow.endpoints{1}.source_reference;queryRow.endpoints{2}.source_reference};verify(authority);
  z=load('-mat',e.audit_reference.file,'audit');a=z.audit;clear z
  assert(strcmp(a.schema,'C1-finite-owned-PAL-numerical-overlap-experiment-v1')&&a.completed&&a.source_posthash&&a.ordinary_edge_earned ...
   &&a.qualified_numerical_relation&&a.fine_calls_returned==4&&isempty(fieldnames(a.failure)), ...
   'PKHistoricalM:Acquisition','Use the unchanged successful original acquisition and its four literal fines.');
  row.epoch=epochEvidence(a,o.SourceReferences);row.authority_references=authority;row.intake_complete=true;
  row.status='INTAKE_MATCHED_RELEVANT_CURRENT_EPOCH';if ~row.epoch.complete,row.status='UNASSESSED_RECORDED_MODEL_PSS_FINE_EPOCH';end
  overlay.rows{at}=row;owned=savePrefix(cp,writing,overlay,owned,finish);
  if strcmp(action,'intake'),verify(authority);processed=processed+1;clear a row;continue;end
  if ~row.epoch.complete,verify(authority);row.finalized=true;overlay.rows{at}=row;overlay.cursor=at+1;processed=processed+1;owned=savePrefix(cp,writing,overlay,owned,finish);clear a row;continue;end
  if left(work)<870,break;end
  L=queryRow.endpoints{1};R=queryRow.endpoints{2};parents=queryRow.incoming_P_parents{1};
  assert(numel(parents)==1&&parents{1}.parent_flight_context.conditional_seed_flight_eligible&&L.current_flight_context.conditional_seed_flight_eligible ...
   &&R.current_flight_context.conditional_seed_flight_eligible&&strcmp(parents{1}.parent_source_reference.file,L.source_reference.file) ...
   &&strcmp(parents{1}.parent_source_reference.sha256,L.source_reference.sha256)&&strcmp(L.source_reference.file,R.source_reference.file) ...
   &&strcmp(L.source_reference.sha256,R.source_reference.sha256),'PKHistoricalM:ParentFlight','Bind the literal owned parent and both endpoints to own/E-conditional flight evidence.');
  indices=[parents{1}.parent_source_index,L.source_index,R.source_index];ix=BranchSolutionFile_v3.index(L.source_reference.file);
  edge=find(cellfun(@(v)v.from==indices(1)&&v.to==indices(2),ix.edges));
  assert(isscalar(edge)&&strcmp(ix.points{indices(1)}.component_identity,ix.points{indices(2)}.component_identity), ...
   'PKHistoricalM:OwnedCarrierP','Retain the actual stored parent-to-candidate P orientation.');
  [native,reports]=BranchSolutionFile_v3.loadSolutions(L.source_reference.file,indices);
  C1FiniteNumericalOverlap_v3.validateRetained(e,native{2},native{3},reports{2},reports{3},native{1});
  C1FiniteNumericalOverlap_v3.validateRetained(e,a.candidate_orbit,a.target_orbit,a.candidate_report,a.target_report,native{1});
  assert(strcmp(OrbitContentIdentity_v3(native{1}),parents{1}.parent_native_ID)&&strcmp(OrbitContentIdentity_v3(native{2}),L.native_ID) ...
   &&strcmp(OrbitContentIdentity_v3(native{3}),R.native_ID),'PKHistoricalM:NativeSelectors','All literal carrier selectors must retain their actual NativeIDs.');
  row.retained_validation_passed=true;records=native(2:3);originalReports={a.candidate_report;a.target_report};profiles=cell(2,1);
  for side=1:2
   [profiles{side},owner]=RecordedOrbitReplayProfile_v3(records{side},originalReports{side});
   assert(owner.complete,'PKHistoricalM:ActualSavedOwner','The ORIGINAL acquisition second-replay report must bind the literal carrier trajectory.');
   if isempty(row.endpoint_rows{side})
    er=struct('native_ID',OrbitContentIdentity_v3(records{side}),'profile_owner',owner,'owner_authority',e.audit_reference, ...
     'owner_report_path','candidate_report','checked',false,'flight',struct(),'PASS',false,'failure',struct());if side==2,er.owner_report_path='target_report';end
    try,fo=flightOptions(o.FlightOptions,profiles{side}.EventTimeTolerance,work);er.flight=CheckC1PKOrbitFlights_v3(records{side},records{side}.parameter,fo);er.PASS=strcmp(er.flight.status,'PASS')&&er.flight.return_timely;catch problem,er.failure=failed(problem);end
    er.checked=true;row.endpoint_rows{side}=er;overlay.rows{at}=row;owned=savePrefix(cp,writing,overlay,owned,finish);
   end
  end
  for side=1:2
   for level=1:2
    prior=a.fines{side,level};original=records{side};r=originalReports{side};fr=row.fine_rows{side,level};
    if ~isempty(fr)&&fr.map_invoked&&~fr.map_returned&&~fr.native_exception_known,row.status='HOLD_UNKNOWN_PREVIOUS_NATIVE_FINE_OUTCOME';hold=true;break;end
    if isempty(fr)
     if left(work)<=o.FineReplaySeconds+70,hold=true;row.status='PARTIAL_CAP_BEFORE_NEXT_FINE';break;end
     [policy,pe]=RecordedReturnPolicy_v3(r);assert(pe.complete&&isa(policy,'ReturnPolicyBase_v3'),'PKHistoricalM:FinePolicy','Use the unchanged complete literal policy.');
     steps=[.0005,.00025];assert(prior.qualified&&prior.fine.RelTol==1e-12&&prior.fine.AbsTol==1e-14&&prior.fine.MaxStep==steps(level), ...
      'PKHistoricalM:OriginalFineProfile','Keep the actual original fixed fine levels and numerical tolerances.');
     child=childLimit(work,o.FineReplaySeconds);[integration,codec]=fineProfile(steps(level),child);
     limits=struct('MaxReturnTime',r.options.MaxReturnTime,'MaxCycleEvents',r.options.MaxCycleEvents,'MaxSectionCrossings',r.options.MaxSectionCrossings);
     assert(isequaln(limits,prior.fine.return_map_limits)&&isequaln(pe.configuration,prior.fine.actual_policy_configuration), ...
      'PKHistoricalM:OriginalFineProblem','Keep exact original fine policy and map horizons.');
     s=QuadrupedSchema_v3.shared();map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(integration),policy,limits);
     fr=struct('side',side,'level',level,'source_native_ID',OrbitContentIdentity_v3(original),'integration',integration,'clock_codec',codec, ...
      'policy_configuration',pe.configuration,'map_limits',limits,'map_invoked',true,'map_returned',false,'native_exception_known',false, ...
      'native_timely',false,'canonical_return_state',[],'raw_return_state',[],'map_info',struct(),'native_result_saved_before_check',false, ...
      'postcheck_completed',false,'original_fine_comparison',struct(),'flight',struct(),'PASS',false,'status','MAP_INVOKED','failure',struct());
     row.fine_rows{side,level}=fr;overlay.rows{at}=row;owned=savePrefix(cp,writing,overlay,owned,finish);
     try
      [next,info]=map.evaluate(original.initial_state,original.initial_mode,original.parameter);fr.map_returned=true;fr.canonical_return_state=next;
      fr.raw_return_state=info.raw_return_state;fr.map_info=info;fr.native_timely=left(child)>0&&left(work)>0;
     catch problem,fr.native_exception_known=true;fr.failure=failed(problem);fr.status='UNASSESSED_NATIVE_FINE_EXCEPTION';end
     row.fine_rows{side,level}=fr;overlay.rows{at}=row;owned=savePrefix(cp,writing,overlay,owned,finish);clear map next info
    end
    if fr.map_returned&&~fr.postcheck_completed
     fr.native_result_saved_before_check=true;
     try
      fr.original_fine_comparison=fineComparison(fr.canonical_return_state,fr.map_info,original,prior);
      fo=flightOptions(o.FlightOptions,fr.integration.EventTimeTolerance,work);fr.flight=CheckC1PKOrbitFlights_v3(fr.map_info,original.parameter,fo);
      fr.PASS=fr.native_timely&&fr.original_fine_comparison.passed&&strcmp(fr.flight.status,'PASS')&&fr.flight.return_timely;fr.status=fr.flight.status;
      if ~fr.original_fine_comparison.passed,fr.status='ORIGINAL_FINE_CORRESPONDENCE_NOT_MET';end
     catch problem,fr.failure=failed(problem);fr.status='UNASSESSED_FINE_SUPPLEMENT';end
     fr.postcheck_completed=true;
    end
    row.fine_rows{side,level}=fr;overlay.rows{at}=row;owned=savePrefix(cp,writing,overlay,owned,finish);
   end
   if hold,break;end
  end
  if ~hold
   row.six_current_flight_checks_PASS=all(cellfun(@(v)v.PASS,row.endpoint_rows))&&all(cellfun(@(v)~isempty(v)&&v.PASS,row.fine_rows(:)));
   row.current_M_flight_eligible=row.six_current_flight_checks_PASS&&row.epoch.complete&&row.retained_validation_passed;
   row.finalized=true;row.status='SIX_SUPPLEMENTS_COMPLETE_UNASSESSED_OR_FAILED';if row.current_M_flight_eligible,row.status='CONDITIONAL_CURRENT_FLIGHT_M_ELIGIBLE_UNCHANGED_OLD_PROOF';end
  end
 catch problem,row.failure=failed(problem);row.status='UNASSESSED_CASE_CONTRACT_OR_CHECK_EXCEPTION';row.finalized=true;end
 verify(authority);overlay.rows{at}=row;if row.finalized,overlay.cursor=at+1;processed=processed+1;end
 owned=savePrefix(cp,writing,overlay,owned,finish);fprintf('PK15_HISTORICAL_M_CASE %s\n',jsonencode(caseSummary(row)));
 clear a row native reports records originalReports profiles original r prior fr fo integration policy owner
 if hold,break;end
end
overlay.completed=overlay.cursor==9;verify(pins);for k=1:numel(overlay.rows),if ~isempty(overlay.rows{k})&&overlay.rows{k}.intake_complete,verify(overlay.rows{k}.authority_references);end;end;overlay.source_posthash=true;owned=savePrefix(cp,writing,overlay,owned,finish);check(finish);out=reference(cp);
if overlay.completed&&strcmp(action,'supplement')
 assert(strcmp(RoundSHA256_v3(cp),owned)&&~isfile(file),'PKHistoricalM:FinalCAS','The completed owned prefix changed.');javaMethod('move','java.nio.file.Files',java.io.File(cp).toPath(),java.io.File(file).toPath(),javaArray('java.nio.file.CopyOption',0));out=reference(file);
end
result=struct('action',action,'completed',overlay.completed,'source_posthash',overlay.source_posthash,'cursor',overlay.cursor,'processed_this_call',processed, ...
 'rows',{cellfun(@caseSummary,overlay.rows,'UniformOutput',false)},'output_reference',out,'return_timely',left(finish)>0,'root_calls',0,'new_P_edges',0,'new_M_relations',0,'qualification_calls',0,'failure',failure);
fprintf('PK15_HISTORICAL_M_RETURN %s\n',jsonencode(result));
end

function c=fineComparison(next,info,original,prior)
f=prior.fine;oldRaw=prior.evidence.trajectory.state(end,:).';raw=info.raw_return_state;
scale=max([ones(14,1),abs(next(:)),abs(f.return_state(:))],[],2);
rawScale=max([ones(14,1),abs(raw(:)),abs(oldRaw(:))],[],2);
ss=max([ones(size(info.stride_displacement)),abs(info.stride_displacement),abs(f.stride_displacement)],[],2);
c=struct('original_fine_qualified',prior.qualified,'literal_initial_state_exact',isequaln(info.initial_state,original.initial_state), ...
    'literal_initial_mode_exact',isequaln(info.initial_mode,original.initial_mode),'canonical_return_bitwise_equal',isequaln(next,f.return_state), ...
    'canonical_return_scaled_inf',norm((next(:)-f.return_state(:))./scale,inf),'raw_return_bitwise_equal',isequaln(raw,oldRaw), ...
    'raw_return_scaled_inf',norm((raw(:)-oldRaw(:))./rawScale,inf),'period_delta',info.period-f.period, ...
    'period_tolerance',1e-10*max([1,abs(info.period),abs(f.period)]),'stride_delta',info.stride_displacement-f.stride_displacement, ...
    'stride_tolerance',1e-10*ss,'mode_closed',info.discrete_closed,'event_signature_equal',isequaln(info.section_relative_event_signature,f.event_signature), ...
    'native_map_conditions',info.success&&info.valid&&info.integration_success&&info.return_policy_accepted&&info.cycle_complete&&info.admissible,'passed',false);
c.passed=c.original_fine_qualified&&c.literal_initial_state_exact&&c.literal_initial_mode_exact&&c.canonical_return_scaled_inf<=1e-10&&c.raw_return_scaled_inf<=1e-10 ...
    &&abs(c.period_delta)<=c.period_tolerance&&all(abs(c.stride_delta)<=c.stride_tolerance)&&c.mode_closed&&c.event_signature_equal&&c.native_map_conditions;
end
function evidence=epochEvidence(a,current)
required={'PoincareMap_v3','PoincareSection_v3','HybridSimulator_v3','Quadrupedal_Dynamics_v3','ContinuousDynamics_v3', ...
 'EventDetector_v3','GuardFunctions_v3','ResetMap_v3','ModeTransition_v3','PeriodicSolutionSolver_v3','C1PlainFineQualificationReplay_v3','QuadrupedSchema_v3'};
paths=cellfun(@(r)r.file,current,'UniformOutput',false);names=cell(0,1);checks=cell(0,1);mapSeen=false;
for k=1:numel(a.source_code)
 old=a.source_code{k};[~,name,ext]=fileparts(old.file);isMap=strcmp(name,'locations')&&strcmp(ext,'.json');if ~strcmp(ext,'.m')&&~isMap,continue;end
 live=old.file;if strcmp(ext,'.m'),live=which(name);names{end+1,1}=name;else,mapSeen=true;end
 hit=find(strcmp(paths,live));r=struct('recorded_reference',old,'current_reference',struct(),'matched',false,'reason','MISSING_OR_UNPINNED_CURRENT_PROVIDER');
 if isscalar(hit),r.current_reference=current{hit};r.matched=strcmp(old.file,live)&&strcmp(old.sha256,current{hit}.sha256);r.reason='RECORDED_EPOCH_MISMATCH';if r.matched,r.reason='EXACT_RECORDED_HEADER_MATCH';end;end
 checks{end+1,1}=r;
end
missing=setdiff(required,names,'stable');evidence=struct('complete',isempty(missing)&&mapSeen&&all(cellfun(@(r)r.matched,checks)), ...
 'required_providers',{required},'missing_required_providers',{missing},'locations_map_present',mapSeen,'checks',{checks}, ...
 'scope','Every originally recorded MATLAB provider and locations map compared to current pinned literal headers. This is a recorded source tuple, not an unrecorded transitive execution trace. Any mismatch remains UNASSESSED; no old protocol epoch is promoted.');
end
function [profile,observation]=fineProfile(step,child)
% Exact Acquire freshFineService + C1PlainFineQualificationReplay mechanism.
simulator=HybridSimulator_v3(struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001));profile=simulator.Options;
before=rmfield(profile,{'ODESolver','ODEOptions'});old=profile.ODEOptions.OutputFcn;
assert(isa(profile.ODESolver,'function_handle')&&strcmp(func2str(profile.ODESolver),'ode45')&&isempty(old), ...
 'PKHistoricalM:FreshFineService','Use the original fresh native ode45 fine service, never the saved endpoint replay profile.');
profile.MaxStep=step;
profile.ODEOptions=odeset(profile.ODEOptions,'OutputFcn',@(~,~,~)budgetOutput(child));
observation=struct('fresh_service_numeric_profile',before,'original_output_function_empty',isempty(old),'solver_signature','ode45','new_limits',child, ...
 'fine_overrides',struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',step),'scope','Exact original fresh fine constructor and level step with an owned clock. The saved replay profile belongs only to the two endpoint trajectory checks.');
end
function fo=flightOptions(fo,tol,work)
assert(left(work)>fo.MaxWallSeconds+2,'PKHistoricalM:FlightFit','Keep the full whole-flight service cap.');fo.EventTimeTolerance=tol;fo.Limits=struct('deadline_unix_seconds',work.u,'deadline_monotonic_ns',work.m);
end
function s=caseSummary(r)
if isempty(r),s=struct('status','UNATTEMPTED','current_M_flight_eligible',false);return;end
s=struct('old_M_row',r.old_M_row,'intake_complete',r.intake_complete,'epoch_complete',member(r.epoch,'complete',false), ...
 'retained_validation_passed',r.retained_validation_passed,'finalized',r.finalized,'six_current_flight_checks_PASS',r.six_current_flight_checks_PASS, ...
 'current_M_flight_eligible',r.current_M_flight_eligible,'status',r.status,'failure',r.failure,'endpoints',{cell(2,1)},'fines',{cell(2,2)});
for k=1:2,v=r.endpoint_rows{k};if ~isempty(v),s.endpoints{k}=struct('PASS',v.PASS,'flight',v.flight,'failure',v.failure);end;end
for k=1:4,v=r.fine_rows{k};if ~isempty(v),s.fines{k}=struct('side',v.side,'level',v.level,'map_invoked',v.map_invoked,'map_returned',v.map_returned, ...
 'native_exception_known',v.native_exception_known,'native_timely',v.native_timely,'native_result_saved_before_check',v.native_result_saved_before_check, ...
 'postcheck_completed',v.postcheck_completed,'PASS',v.PASS,'status',v.status,'original_fine_comparison',v.original_fine_comparison,'failure',v.failure);end;end
end
function sha=savePrefix(cp,writing,overlay,previous,limit)
check(limit);assert(~isfile(writing),'PKHistoricalM:Writing','Preserve a staged sidecar outcome.');
if isempty(previous),assert(~isfile(cp),'PKHistoricalM:FreshCheckpoint','Preserve an existing prefix.');else,assert(strcmp(RoundSHA256_v3(cp),previous),'PKHistoricalM:CAS','The owned prefix changed.');end
save(writing,'overlay','-v7');z=load('-mat',writing,'overlay');assert(isequaln(z.overlay.configuration,overlay.configuration)&&z.overlay.cursor==overlay.cursor ...
 &&z.overlay.source_posthash==overlay.source_posthash&&z.overlay.completed==overlay.completed,'PKHistoricalM:Readback','The plain prefix header changed.');
for k=1:numel(overlay.rows)
 a=overlay.rows{k};b=z.overlay.rows{k};assert(isequaln(caseSummary(a),caseSummary(b)),'PKHistoricalM:OutcomeReadback','Every actual completed/prepared outcome must survive readback.');
 if isempty(a),continue;end
 assert(isequaln(a.original_evidence,b.original_evidence)&&isequaln(a.epoch,b.epoch),'PKHistoricalM:ProofReadback','The unchanged old proof or epoch report changed.');
 for j=1:4
  x=a.fine_rows{j};y=b.fine_rows{j};if isempty(x)||~x.map_returned,continue;end
  assert(isequaln(x.canonical_return_state,y.canonical_return_state)&&isequaln(x.raw_return_state,y.raw_return_state) ...
   &&isequaln(x.map_info.trajectory.event_batches,y.map_info.trajectory.event_batches),'PKHistoricalM:ActualMapReadback','Retain real raw/canonical results and actual native trajectory cohorts.');
 end
end
clear z;check(limit);if ~isempty(previous),assert(strcmp(RoundSHA256_v3(cp),previous),'PKHistoricalM:CAS','The owned prefix changed before publication.');end
opts=javaArray('java.nio.file.CopyOption',2);opts(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');opts(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');
javaMethod('move','java.nio.file.Files',java.io.File(writing).toPath(),java.io.File(cp).toPath(),opts);sha=RoundSHA256_v3(cp);
end
function providers(refs)
names={'RunPK15hHistoricalMFlights20261104','RunPK15hCurrentMeeting20261104','ValidateStoredPeriodicOrbit_v3','C1FiniteNumericalOverlap_v3', ...
 'C1PlainFineQualificationReplay_v3','RecordedOrbitReplayProfile_v3','RecordedReturnPolicy_v3','CompactResearchBranch_v3', ...
 'BranchSolutionFile_v3','OrbitContentIdentity_v3','PoincareMap_v3','PoincareSection_v3','HybridSimulator_v3','Quadrupedal_Dynamics_v3', ...
 'QuadrupedSchema_v3','CheckC1PKOrbitFlights_v3','CheckC1PKFlightInterval_v3','AllFlightClearanceBounds_v3','RoundSHA256_v3'};
paths=cellfun(@(r)r.file,refs,'UniformOutput',false);for k=1:numel(names),assert(sum(strcmp(paths,which(names{k})))==1,'PKHistoricalM:Provider','Pin resolved provider %s.',names{k});end
end
function verify(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(strcmp(canonical(r.file),r.file)&&isscalar(d)&&~d.isdir&&(~isfield(r,'bytes')||d.bytes==r.bytes)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKHistoricalM:Changed','Changed immutable input: %s.',r.file);end;end
function l=childLimit(parent,seconds),n=nowClock();assert(left(parent)>seconds+2,'PKHistoricalM:ChildFit','Keep the full child cap.');l=struct('u',n.u+seconds,'m',n.m+seconds*1e9);end
function status=budgetOutput(l),check(l);status=0;end
function r=reference(f),d=dir(f);r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',d.bytes);end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function r=failed(e),r=struct('identifier',e.identifier,'message',e.message);end
function v=member(s,k,d),v=d;if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);end;end
function n=nowClock(),n=struct('u',double(java.time.Instant.now().toEpochMilli())/1000,'m',double(java.lang.System.nanoTime()));end
function v=left(l),n=nowClock();v=min(l.u-n.u,(l.m-n.m)/1e9);end
function check(l),assert(left(l)>0,'PKHistoricalM:Deadline','Current operation or original science deadline expired.');end
