function result=RunPK15hPIPDaughters20261104(B,refs,o)
%RUNPK15HPIPDAUGHTERS20261104 Native vertical controls and NEW signed daughters.
% Parent controls: four independent coordinates at fixed recorded Ecrit.
% Daughters: [dx,h,alpha,omega,E], free energy and vx=b selector; no elimination.
rkeys={'CriticalReference';'ProfileReference';'SourceReferences'};
keys={'OutputFile';'ResumeReference';'MaxRootServices';'ParentSeconds';'DaughterSeconds';'FlightOptions';'MaxWallSeconds';'ReserveSeconds'};
assert(nargin==3&&isstruct(refs)&&isscalar(refs)&&isequal(sort(fieldnames(refs)),sort(rkeys)) ...
    &&isstruct(o)&&isscalar(o)&&isequal(sort(fieldnames(o)),sort(keys)),'PKPIPDaughters:Options');
assert(iscell(refs.SourceReferences)&&iscolumn(refs.SourceReferences)&&isequal(o.ParentSeconds,180)&&isequal(o.DaughterSeconds,300),'PKPIPDaughters:Caps');
validateattributes(o.MaxRootServices,{'double'},{'real','finite','scalar','integer','positive','<=',4});
validateattributes(o.MaxWallSeconds,{'double'},{'real','finite','scalar','positive','<=',2400});
validateattributes(o.ReserveSeconds,{'double'},{'real','finite','scalar','>=',120,'<',o.MaxWallSeconds/2});
assert(isstruct(o.FlightOptions)&&isscalar(o.FlightOptions)&&~isfield(o.FlightOptions,'Limits') ...
    &&isequal(o.FlightOptions.MaxWallSeconds,60),'PKPIPDaughters:FlightOptions');
entry=nowClock();assert(B.capture.pid==feature('getpid'),'PKPIPDaughters:Budget');
finish=struct('u',min(B.research_deadline_unix_seconds,entry.u+o.MaxWallSeconds),'m',min(B.research_deadline_monotonic_ns,entry.m+o.MaxWallSeconds*1e9));
work=struct('u',finish.u-o.ReserveSeconds,'m',finish.m-o.ReserveSeconds*1e9);assert(left(work)>362,'PKPIPDaughters:Fit');
file=canonical(o.OutputFile);cp=[file,'.checkpoint.mat'];writing=[cp,'.writing.mat'];
assert(startsWith(file,[V3Root_v3(),filesep])&&endsWith(file,'.mat')&&~isfile(file)&&~isfolder(file) ...
    &&~isfile(writing)&&~isfolder(writing),'PKPIPDaughters:Fresh');
providers(refs.SourceReferences);pins=[refs.SourceReferences;{refs.CriticalReference;refs.ProfileReference}];verify(pins);check(work);
assert(strcmp(refs.CriticalReference.sha256,'82cdf77421772b4536cf3d20a7ef372b31d930ae13dc413a5c2bfff9eb2e9648') ...
    &&strcmp(refs.ProfileReference.sha256,'6c2a8aa1cc21f1ad485f34e35d9d0423dd6c433a6eabdeb48d1a715126278278'),'PKPIPDaughters:Authorities');
z=load('-mat',refs.CriticalReference.file,'result');critical=z.result;clear z
assert(critical.completed&&critical.source_posthash&&critical.all_numerical_checks_passed&&numel(critical.rows)==2, ...
    'PKPIPDaughters:CriticalRoots','Use the actual completed two-root audit.');
p=critical.physical_parameter(:);assert(isequal(p,[10;10;20;20;1;1;0;0;2;.5]),'PKPIPDaughters:Parameters');
origins=cell(2,1);
for k=1:2
    r=critical.rows{k};a=r.passes{2};M=a.matrix;
    assert(r.numerical_checks_passed&&a.all_checks_passed&&isequal(size(M),[3,3])&&all(isfinite(M(:))) ...
        &&isequal(a.original_restricted_info.coordinate_order,{'dx','common_alpha','common_dalpha'}),'PKPIPDaughters:RestrictedContract');
    [~,D,V]=svd(M-eye(3));v=V(:,end);
    assert(D(2,2)>1e-5&&D(3,3)<1e-8&&abs(v(1))>1e-8&&norm((M-eye(3))*v,inf)<1e-8 ...
        &&abs(v.'*a.right_kernel/norm(a.right_kernel))>1-1e-8,'PKPIPDaughters:Kernel','Use the actual second-pass critical kernel.');
    v=v/v(1);origins{k}=struct('label',r.label,'critical_energy',a.energy,'kernel_dx_normalized',v, ...
        'singular_values',diag(D),'matrix',M,'analytic_parent_period',a.original_restricted_info.period, ...
        'minimum_analytic_parent_height',a.original_restricted_info.minimum_vertical_height);
end
z=load('-mat',refs.ProfileReference.file,'study');study=z.study;r=study.native_report;
assert(study.completed&&study.source_posthash&&study.native_all_nine&&r.accepted&&isequal(study.native_orbit.parameter(:),p),'PKPIPDaughters:Profile');
[policy,pe]=RecordedReturnPolicy_v3(r);assert(pe.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3') ...
    &&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'PKPIPDaughters:Policy');
profile=struct('Integration',r.integration,'ReplayIntegration',r.replay_integration,'EffectiveReplayODE',r.effective_replay_ode, ...
    'Acceptance',r.acceptance,'MaxReturnTime',r.options.MaxReturnTime,'MaxCycleEvents',r.options.MaxCycleEvents, ...
    'MaxSectionCrossings',r.options.MaxSectionCrossings);clear z study r critical
queue={struct('origin',1,'kind','parent','b',0);struct('origin',2,'kind','parent','b',0)};
for radius=[.02,.01,.005,.0025],for k=1:2,for sign=[1,-1],queue{end+1,1}=struct('origin',k,'kind','daughter','b',sign*radius);end;end;end
grant=struct('grant_id',B.grant_id,'start_utc',B.start_utc,'research_deadline_utc',B.research_deadline_utc,'deadline_utc',B.deadline_utc);
config=struct('authorities',refs,'fixed_grant',grant,'queue',{queue},'origins',{origins},'flight_options',o.FlightOptions, ...
    'parent_seconds',o.ParentSeconds,'daughter_seconds',o.DaughterSeconds,'output_file',file);
owned='';
if isempty(fieldnames(o.ResumeReference))
    assert(~isfile(cp)&&~isfolder(cp),'PKPIPDaughters:FreshCheckpoint');
    audit=struct('schema','PK15h-known-PIP-native-parent-daughter-stageB-v1','configuration',config,'profile_policy',pe.configuration, ...
        'cursor',1,'rows',{cell(numel(queue),1)},'service_attempts',0,'service_returns',0,'completed',false,'source_posthash',true, ...
        'new_P_edges',0,'new_M_relations',0,'parent_attachments_created',0,'global_bifurcation_certificate',false, ...
        'scope','Finite NEW native controls and daughter acquisitions only. Restricted +1 roots and shrinking daughter evidence do not alone prove a full-space bifurcation or branch attachment.');
    owned=savePrefix(cp,writing,audit,owned,finish);
else
    assert(strcmp(canonical(o.ResumeReference.file),cp),'PKPIPDaughters:ResumePath');verify({o.ResumeReference});
    z=load('-mat',cp,'audit');audit=z.audit;clear z;owned=o.ResumeReference.sha256;
    assert(strcmp(audit.schema,'PK15h-known-PIP-native-parent-daughter-stageB-v1')&&isequaln(audit.configuration,config) ...
        &&audit.cursor>=1&&audit.cursor<=numel(queue)+1&&audit.completed==(audit.cursor>numel(queue)),'PKPIPDaughters:ResumeConfig');
    verify({o.ResumeReference});
end
services=0;status='BATCH_CAP_OR_CLOCK';failure=struct();s=QuadrupedSchema_v3.shared();q=false(4,1);
try
    while audit.cursor<=numel(queue)
        index=audit.cursor;item=queue{index};origin=origins{item.origin};E=origin.critical_energy;b=item.b;
        if isempty(audit.rows{index})
            x=zeros(14,1);x(s.State.y)=E;
            if strcmp(item.kind,'daughter')
                x(s.State.dx)=b;x(s.State.y)=E-b^2/2;
                x(s.Leg.AngleIndices)=b*origin.kernel_dx_normalized(2);x(s.Leg.RateIndices)=b*origin.kernel_dx_normalized(3);
            end
            audit.rows{index}=struct('queue_index',index,'origin',item.origin,'kind',item.kind,'b',b,'critical_energy',E, ...
                'NEW_seed_state',x,'NEW_seed_mode',q,'physical_parameter',p,'initial_energy_guess',E,'kernel_ray',origin.kernel_dx_normalized, ...
                'height_guess_scope','Ecrit-b^2/2 is an initial daughter guess only; h and E remain independent root coordinates.', ...
                'service_attempts',{{}},'native_returned',false,'native_exception_known',false,'native_timely',false,'orbit',[],'report',struct(), ...
                'native_outcome_saved_before_checks',false,'last_correction_flight_check',struct(),'native_all_nine',false, ...
                'classification',struct(),'flight',struct(),'flight_PASS',false,'target_classification_passed',false,'metrics',struct(), ...
                'status','PREPARED','failure',struct());
            owned=savePrefix(cp,writing,audit,owned,finish);
        end
        row=audit.rows{index};
        if ~row.native_returned
            if ~row.native_exception_known&&~isempty(row.service_attempts)
                row.status='HOLD_UNKNOWN_PREVIOUS_NATIVE_OUTCOME';audit.rows{index}=row;
                owned=savePrefix(cp,writing,audit,owned,finish);status='HOLD_UNKNOWN_PREVIOUS_NATIVE_OUTCOME';break
            end
            if services>=o.MaxRootServices,break;end
            seconds=o.DaughterSeconds;if strcmp(item.kind,'parent'),seconds=o.ParentSeconds;end
            if left(work)<=seconds+o.FlightOptions.MaxWallSeconds+15,break;end
            child=childLimit(work,seconds);x=row.NEW_seed_state;integration=rebind(profile.Integration,child);
            fo=o.FlightOptions;fo.EventTimeTolerance=integration.EventTimeTolerance;fo.Limits=limits(child);
            map=PKFlightCheckedMap20261104(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.State.dy), ...
                HybridSimulator_v3(integration),policy,mapOptions(profile),fo,refs.SourceReferences);
            family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,x),x,q,p,struct('Symmetry','pronk','ClosureTolerance',profile.Acceptance.FullClosureTolerance));
            assert(isequal(family.CoordinateIndices(:).',[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL]) ...
                &&isequal(family.fullState(family.packState(x)),x),'PKPIPDaughters:Chart','Retain all four independent flight coordinates.');
            constraint=[];w=family.packState(x);
            if strcmp(item.kind,'daughter'),w=[w;E];constraint=struct('reference',[0;E;0;0;E],'normal',[1;0;0;0;0],'target',b);end
            residual=ConstrainedEnergyResidual_v3(family,1:4,constraint,ones(numel(w),1));
            seed=struct('state',x,'mode',q,'parameter',p,'return_policy',policy,'occurrence',1, ...
                'provenance',struct('kind','NEW analytic vertical parent or critical-kernel daughter predictor','queue_index',index,'StageA_reference',refs.CriticalReference));
            settings=struct('Residual',residual,'Coordinates',w,'AugmentedParameter',[p;E], ...
                'ReplayIntegration',replayOptions(profile.ReplayIntegration,profile.EffectiveReplayODE),'Acceptance',profile.Acceptance, ...
                'MaxReturnTime',profile.MaxReturnTime,'MaxCycleEvents',profile.MaxCycleEvents,'MaxSectionCrossings',profile.MaxSectionCrossings, ...
                'MaxWallSeconds',seconds,'SolverOptions',rootOptions(child,seconds,numel(w)),'TraceFailure',false);
            row.service_attempts{end+1,1}=struct('pid',B.capture.pid,'limits',limits(child),'coordinates',w,'constraint',constraint, ...
                'unknown_count',numel(w),'fixed_parent_energy',strcmp(item.kind,'parent'));
            audit.service_attempts=audit.service_attempts+1;services=services+1;audit.rows{index}=row;owned=savePrefix(cp,writing,audit,owned,finish);
            try
                [orbit,report]=PeriodicSolutionSolver_v3(seed,settings);
            catch problem
                row.native_exception_known=true;row.failure=failed(problem);row.status='NATIVE_SERVICE_EXCEPTION';
                audit.rows{index}=row;audit.cursor=index+1;audit.completed=audit.cursor>numel(queue);
                owned=savePrefix(cp,writing,audit,owned,finish);fprintf('PK15_PIP_STAGEB_CASE %s\n',jsonencode(rowSummary(row)));continue
            end
            row.native_returned=true;row.orbit=orbit;row.report=report;
            row.native_timely=left(child)>0&&left(work)>0;row.last_correction_flight_check=map.LastFlightCheck;
            audit.service_returns=audit.service_returns+1;audit.rows{index}=row;owned=savePrefix(cp,writing,audit,owned,finish);
            clear map family residual settings seed orbit report integration
        end
        % An interrupted postcheck resumes here without repeating its retained root.
        row.native_outcome_saved_before_checks=true;
        if row.native_timely&&isa(row.orbit,'HybridOrbit_v3')&&left(work)<=o.FlightOptions.MaxWallSeconds+5
            audit.rows{index}=row;owned=savePrefix(cp,writing,audit,owned,finish);break
        end
        try
            row.native_all_nine=isa(row.orbit,'HybridOrbit_v3')&&nine(row.report);row.classification=member(row.report,'classification',struct());
            if row.native_all_nine&&row.native_timely
                assert(left(work)>o.FlightOptions.MaxWallSeconds+5,'PKPIPDaughters:PostcheckFit');
                [actual,owner]=RecordedOrbitReplayProfile_v3(row.orbit,row.report);assert(owner.complete,'PKPIPDaughters:ReplayOwner','%s',owner.reason);
                checkLimit=childLimit(work,o.FlightOptions.MaxWallSeconds);fo=o.FlightOptions;fo.EventTimeTolerance=actual.EventTimeTolerance;fo.Limits=limits(checkLimit);
                row.flight=CheckC1PKOrbitFlights_v3(row.orbit,p,fo);row.flight_PASS=strcmp(row.flight.status,'PASS')&&row.flight.return_timely;
                expected='PK';if strcmp(item.kind,'parent'),expected='PIP';end
                row.target_classification_passed=strcmp(member(row.classification,'validated_gait_type',''),expected) ...
                    &&strcmp(member(row.classification,'canonical_point_label',''),expected) ...
                    &&isequal(member(row.classification,'canonical_label_qualified',false),true) ...
                    &&isequal(member(row.classification,'flight_count_certain',false),true)&&isequal(member(row.classification,'flight_count',NaN),1);
                row.metrics=metrics(row,origin,s);
                if row.flight_PASS&&row.target_classification_passed,row.status='NATIVE_TARGET_AND_CONDITIONAL_FLIGHT_PASS'; ...
                elseif strcmp(row.flight.status,'VIOLATION'),row.status='NATIVE_ADMITTED_FLIGHT_VIOLATION';else,row.status='NATIVE_ADMITTED_TARGET_OR_FLIGHT_UNASSESSED';end
            else,row.status='NATIVE_NOT_ADMITTED_OR_UNTIMELY';end
        catch problem,row.failure=failed(problem);row.status='POSTCHECK_UNASSESSED';end
        audit.rows{index}=row;audit.cursor=index+1;audit.completed=audit.cursor>numel(queue);verify(pins);audit.source_posthash=true;
        owned=savePrefix(cp,writing,audit,owned,finish);fprintf('PK15_PIP_STAGEB_CASE %s\n',jsonencode(rowSummary(row)));
    end
    if audit.completed,status='FINITE_STAGEB_QUEUE_COMPLETE';end
catch problem,failure=failed(problem);end
assert(strcmp(RoundSHA256_v3(cp),owned),'PKPIPDaughters:CheckpointCAS');z=load('-mat',cp,'audit');audit=z.audit;clear z
final=struct();if audit.completed,verify(pins);check(finish);freshLink(cp,file);final=reference(file);end
result=struct('status',status,'completed',audit.completed,'cursor',audit.cursor,'queue_count',numel(queue), ...
    'batch_service_attempts',services,'cumulative_service_attempts',audit.service_attempts,'cumulative_service_returns',audit.service_returns, ...
    'checkpoint_reference',reference(cp),'final_reference',final,'failure',failure,'new_P_edges',0,'new_M_relations',0, ...
    'parent_attachments_created',0,'return_timely',left(finish)>0,'own_process_exit_claimed',false);
fprintf('PK15_PIP_STAGEB_RETURN %s\n',jsonencode(result));
end
function m=metrics(row,origin,s)
o=row.orbit;x=o.initial_state;H=QuadrupedEnergy_v3.evaluate(x,o.initial_mode,o.parameter);b=row.b;
m=struct('raw_full13',x(2:14),'raw_full13_closure',row.report.full_closure_residual(2:14), ...
    'energy',H,'energy_minus_critical',H-origin.critical_energy,'period',o.period,'full_stride',o.stride_displacement, ...
    'period_minus_parent',o.period-origin.analytic_parent_period,'selector_dx_error',x(s.State.dx)-b, ...
    'kernel_ray_error',[],'energy_shift_over_b_squared',[],'raw_seed_difference',x-row.NEW_seed_state);
if b~=0,m.kernel_ray_error=x([s.State.dx,s.State.alphaBL,s.State.dalphaBL])/b-origin.kernel_dx_normalized;m.energy_shift_over_b_squared=(H-origin.critical_energy)/b^2;end
end
function out=rootOptions(l,seconds,n)
j=ValidSidedFiniteDifferenceJacobian_v3(struct('RelativeStep',1e-8,'DeadlineUnixSeconds',l.u,'DeadlineMonotonicNs',l.m));
out=struct('Algorithm','root-newton','MaxIterations',40,'MaxFunctionEvaluations',1000,'FunctionTolerance',1e-11, ...
    'ResidualAcceptanceTolerance',1e-10,'StepTolerance',1e-13,'OptimalityTolerance',1e-18,'ReuseJacobian',true, ...
    'InitialJacobian',[],'UseBroyden',true,'JacobianRefreshInterval',5,'Jacobian',j,'MaxWallSeconds',seconds,'StateScale',ones(n,1));
end
function out=replayOptions(p,e)
names={'RelTol','AbsTol','EventValueTolerance','EventTimeTolerance','SimultaneousTimeTolerance','MaxStep','ArmingTolerance'};
out=struct();for k=1:numel(names),out.(names{k})=p.(names{k});end;out.RelTol=e.RelTol;out.AbsTol=e.AbsTol;out.MaxStep=e.MaxStep;
end
function p=rebind(p,l),p.ODEOptions=odeset(p.ODEOptions,'OutputFcn',ownedCallback(l));end
function f=ownedCallback(l),f=@(varargin)ownedOutput(l);end
function stop=ownedOutput(l),check(l);stop=0;end
function o=mapOptions(p),o=struct('MaxReturnTime',p.MaxReturnTime,'MaxCycleEvents',p.MaxCycleEvents,'MaxSectionCrossings',p.MaxSectionCrossings);end
function o=limits(l),o=struct('deadline_unix_seconds',l.u,'deadline_monotonic_ns',l.m);end
function c=childLimit(p,seconds),assert(left(p)>seconds+1,'PKPIPDaughters:ChildFit');n=nowClock();c=struct('u',n.u+seconds,'m',n.m+seconds*1e9);end
function yes=nine(r)
names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
yes=isequal(member(r,'accepted',false),true)&&isfield(r,'acceptance_gates')&&all(isfield(r.acceptance_gates,names));if yes,yes=all(cellfun(@(n)isequal(r.acceptance_gates.(n),true),names));end
end
function s=rowSummary(r)
s=struct('queue_index',r.queue_index,'origin',r.origin,'kind',r.kind,'b',r.b,'native_returned',r.native_returned, ...
    'native_exception_known',r.native_exception_known, ...
    'native_timely',r.native_timely,'native_outcome_saved_before_checks',r.native_outcome_saved_before_checks, ...
    'native_all_nine',r.native_all_nine,'flight_status',member(r.flight,'status','UNASSESSED'), ...
    'flight_PASS',r.flight_PASS,'target_classification_passed',r.target_classification_passed,'status',r.status,'metrics',r.metrics,'failure',r.failure);
if r.native_returned,s.retained_status=member(r.report,'status','');s.retained_gates=member(r.report,'acceptance_gates',struct());if isa(r.orbit,'HybridOrbit_v3'),s.retained_native_ID=OrbitContentIdentity_v3(r.orbit);end;end
end
function sha=savePrefix(cp,writing,audit,previous,l)
check(l);assert(~isfile(writing),'PKPIPDaughters:Writing');if isempty(previous),assert(~isfile(cp),'PKPIPDaughters:FreshCheckpoint');else,assert(strcmp(RoundSHA256_v3(cp),previous),'PKPIPDaughters:CheckpointCAS');end
projection=project(audit);save(writing,'audit','projection','-v7');readback(writing,projection);check(l);
if ~isempty(previous),assert(strcmp(RoundSHA256_v3(cp),previous),'PKPIPDaughters:CheckpointCAS');end
flags=javaArray('java.nio.file.CopyOption',2);flags(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');flags(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');
javaMethod('move','java.nio.file.Files',java.io.File(writing).toPath(),java.io.File(cp).toPath(),flags);readback(cp,projection);sha=RoundSHA256_v3(cp);
end
function p=project(a),p=struct('configuration',a.configuration,'cursor',a.cursor,'service_attempts',a.service_attempts,'service_returns',a.service_returns,'completed',a.completed,'rows',{{}});for k=1:numel(a.rows),if isempty(a.rows{k}),p.rows{k,1}=[];else,p.rows{k,1}=rowSummary(a.rows{k});end;end;end
function readback(f,p),for pass=1:2,z=load('-mat',f,'audit','projection');assert(isequaln(z.projection,p)&&isequaln(project(z.audit),p),'PKPIPDaughters:Readback');end;end
function providers(refs)
names={'RunPK15hPIPDaughters20261104','PeriodicSolutionSolver_v3','EnergyFamilyResidual_v3','ConstrainedEnergyResidual_v3', ...
    'PeriodicOrbitResidual_v3','PKFlightCheckedMap20261104','CheckC1PKOrbitFlights_v3','CheckC1PKFlightInterval_v3', ...
    'AllFlightClearanceBounds_v3','RecordedOrbitReplayProfile_v3','RecordedReturnPolicy_v3','ValidSidedFiniteDifferenceJacobian_v3'};
paths=cellfun(@(r)r.file,refs,'UniformOutput',false);for k=1:numel(names),assert(any(strcmp(paths,which(names{k}))),'PKPIPDaughters:Provider','Missing resolved provider %s.',names{k});end
end
function verify(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKPIPDaughters:Changed','Changed authority/provider: %s.',r.file);end;end
function freshLink(a,b),assert(~isfile(b)&&~isfolder(b),'PKPIPDaughters:Fresh');javaMethod('createLink','java.nio.file.Files',java.io.File(b).toPath(),java.io.File(a).toPath());end
function r=reference(f),d=dir(f);r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',d.bytes);end
function v=member(s,k,d),v=d;if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);end;end
function e=failed(e),e=struct('identifier',e.identifier,'message',e.message);end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function n=nowClock(),n=struct('u',double(java.time.Instant.now().toEpochMilli())/1000,'m',double(java.lang.System.nanoTime()));end
function v=left(l),n=nowClock();v=min(l.u-n.u,(l.m-n.m)/1e9);end
function check(l),assert(left(l)>0,'PKPIPDaughters:Deadline','Local or original science deadline expired.');end
