function result=ExtendPK15hCurrentComponentView20261104(B,refs,o)
% Append saved conditional-flight seam authorities to one closed compact view.
% The base occurrences/contexts/held702 and historical tables remain literal.
rkeys={'BaseViewReference';'HistoricalMSidecarReference';'HighBoundaryStudies';'FreshCarriers';'SourceReferences'};keys={'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'};
assert(nargin==3&&isequal(sort(fieldnames(refs)),sort(rkeys))&&isequal(sort(fieldnames(o)),sort(keys))&&B.capture.pid==feature('getpid')&&o.MaxWallSeconds==900&&o.SaveMarginSeconds==60,'PKCurrentSuccessor:API','Use explicit compact base, sidecar, fresh carriers and fixed900/60 saved assembly.');
n=nowClock();assert(min(B.research_deadline_unix_seconds-n.u,(B.research_deadline_monotonic_ns-n.m)/1e9)>902,'PKCurrentSuccessor:Fit','The complete900/60 operation must fit unchanged original science clocks.');finish=struct('u',n.u+900,'m',n.m+900e9);work=struct('u',finish.u-60,'m',finish.m-60e9);
assert(strcmp(refs.BaseViewReference.sha256,'486faffa227c46c6fde1fde975fa572925c925175569a16f9a0c2b5ab1761562')&&iscell(refs.FreshCarriers)&&iscolumn(refs.FreshCarriers)&&numel(refs.FreshCarriers)==3,'PKCurrentSuccessor:BaseAndCarriers','Use the exact closed1136-occurrence base and all three actual successful fresh02/03/06 carriers.');
roles=cellfun(@(r)r.role,refs.FreshCarriers,'UniformOutput',false);required={'historical_refresh02';'historical_refresh03';'historical_refresh06'};assert(numel(unique(roles))==3&&all(ismember(required,roles)),'PKCurrentSuccessor:Roles','Each original historical-refresh case has one distinct actually closed fresh carrier.');
assert(iscell(refs.HighBoundaryStudies)&&isequal(size(refs.HighBoundaryStudies),[2,1]),'PKCurrentSuccessor:HighStudies','Pin the already executed positive/negative HIGH grazing studies in declared order.');
providers(refs.SourceReferences);inputs=[refs.SourceReferences;{refs.BaseViewReference;refs.HistoricalMSidecarReference};refs.HighBoundaryStudies];for k=1:3,r=refs.FreshCarriers{k};assert(isequal(sort(fieldnames(r)),sort({'role';'reference';'experiment_reference';'cold_result_reference'})),'PKCurrentSuccessor:CarrierReferenceFields','Keep the existing explicit role/carrier/experiment/cold-result reference contract.');inputs=[inputs;{r.reference;r.experiment_reference;r.cold_result_reference}];end
verify(inputs);out=literal(o.OutputFile);stage=[out,'.pending.mat'];assert(startsWith(out,[V3Root_v3(),filesep])&&endsWith(out,'.mat')&&~isfile(out)&&~isfolder(out)&&~isfile(stage),'PKCurrentSuccessor:Fresh','Preserve every prior plan and uncertain stage.');
z=load('-mat',refs.BaseViewReference.file,'component_plan','plan_digest');base=z.component_plan;assert(strcmp(C1ScientificDigest_v3(base),z.plan_digest)&&strcmp(base.schema,'C1-stored-component-graph-plan-v1')&&base.completed&&base.source_posthash&&base.active_source_occurrence_bijection_verified&&numel(base.nodes)==1136&&base.held_boundary.original_graph_global==702&&~base.held_boundary.source_invalidated&&~base.held_boundary.source_retired,'PKCurrentSuccessor:Base','Use the exact compact active base and preserve held702 as an unresolved obligation.');clear z
z=load('-mat',refs.HistoricalMSidecarReference.file,'overlay');side=z.overlay;clear z
assert(strcmp(side.schema,'PK15h-historical-generic-M-conditional-flight-sidecar-v1')&&side.completed&&side.source_posthash&&side.cursor==9&&isequal(side.configuration.selected_old_M_rows,[2;3;6;9;10;11;13;15])&&~side.historical_evidence_changed&&~side.historical_flags_changed&&side.root_calls==0&&side.new_P_edges==0&&side.new_M_relations==0&&side.qualification_calls==0,'PKCurrentSuccessor:Sidecar','Require the completed immutable current conditional-flight sidecar without promoting an older model epoch.');
queryRef=side.configuration.query_reference;assert(strcmp(queryRef.sha256,'c1be4c8bd75d167038e3e4442bcf796931b0e1004c3c315f5e729879338e7781'),'PKCurrentSuccessor:QueryReference','Use the exact literal old relation selector query.');verify({queryRef});z=load('-mat',queryRef.file,'query');query=z.query;clear z
assert(query.completed&&query.source_posthash&&sameRef(query.current_reference,refs.BaseViewReference)&&sameRef(query.old_graph_reference,base.parent_plan_reference),'PKCurrentSuccessor:QueryJoin','The old row numbers and endpoint selectors must refer to this exact compact base and its original graph.');
inputs=uniqueRefs([inputs;{queryRef;query.old_graph_reference};cellfun(@(c)struct('file',c.file,'sha256',c.sha256),base.source_catalog,'UniformOutput',false)]);verify(inputs);check(work);
nodes=base.nodes;points=base.view_index.points;catalogue=base.source_catalog;owners=base.view_index.metadata.source_owner_map;context=base.current_context;d=base.graph_discovery;parentCount=numel(nodes);oldMap=base.original_global_to_active;
whitelist=[9,10,11,13,15];supplementFacts=cell(5,1);operativeOldRows=zeros(0,1);relationContext=cell(0,1);
for k=1:numel(whitelist)
 oldRow=whitelist(k);at=find(cellfun(@(r)~isempty(r)&&r.old_M_row==oldRow,side.rows));assert(isscalar(at),'PKCurrentSuccessor:SidecarRow','Every whitelisted historical row needs its literal completed sidecar result.');r=side.rows{at};q=query.old_M{oldRow};e=q.evidence;
 assert(strcmp(q.kind,'GENERIC95E')&&q.old_relation_row==oldRow&&isequal(q.old_stored_orientation,base.historical_relation_tables.qualified_numerical_overlaps(oldRow,:))&&isequaln(r.original_evidence,e)&&r.finalized,'PKCurrentSuccessor:HistoricalProof','Keep each original finite-M proof and oriented original selector pair unchanged.');
 pair=oldMap(q.old_stored_orientation).';pair=pair(:).';eligible=r.current_M_flight_eligible&&r.six_current_flight_checks_PASS&&r.retained_validation_passed&&r.epoch.complete&&all(pair>0);
 fact=struct('old_M_row',oldRow,'original_stored_pair',q.old_stored_orientation,'active_pair',pair,'sidecar_reference',refs.HistoricalMSidecarReference,'sidecar_row',at,'sidecar_status',r.status,'current_conditional_flight_eligible',eligible,'original_evidence_unchanged',true,'active_M_row',0,'historical_epoch_or_all9_promoted',false);
 if eligible
  assert(strcmp(e.schema,'C1-qualified-finite-numerical-overlap-v1')&&e.qualified&&e.full_native_proof_validated&&all(cellfun(@(v)v.PASS&&strcmp(v.flight.status,'PASS')&&v.flight.return_timely,r.endpoint_rows))&&all(cellfun(@(v)v.PASS&&v.map_returned&&v.native_result_saved_before_check&&v.original_fine_comparison.passed&&strcmp(v.flight.status,'PASS')&&v.flight.return_timely,r.fine_rows(:))),'PKCurrentSuccessor:SixHistoricalChecks','Only actual six-PASS exact-current-epoch sidecar rows enter the operative graph.');
  for j=1:2,ep=q.endpoints{j};g=oldMap(ep.old_global);assert(g==ep.current_global&&g==pair(j)&&g>0&&g<=parentCount&&strcmp(nodes{g}.native_ID,ep.native_ID)&&nodes{g}.source_index==ep.source_index&&sameRef(catalogue{nodes{g}.source_number},ep.source_reference)&&context{g}.conditional_seed_flight_eligible,'PKCurrentSuccessor:HistoricalEndpoint','Use exact old-original-to-active occurrence selectors, never a NativeID bucket.');end
  assert(strcmp(nodes{pair(1)}.native_ID,e.left_native_ID)&&strcmp(nodes{pair(2)}.native_ID,e.right_native_ID),'PKCurrentSuccessor:HistoricalEndpointID','Unchanged old-M proof must bind both actual active endpoint NativeIDs.');
  assert(~any(all(d.qualified_numerical_overlaps==pair,2)),'PKCurrentSuccessor:HistoricalDuplicate','Do not silently append a duplicate operative M row.');
  d.qualified_numerical_overlaps(end+1,:)=pair;d.numerical_overlap_evidence{end+1,1}=e;fact.active_M_row=size(d.qualified_numerical_overlaps,1);operativeOldRows(end+1,1)=oldRow;
  d.numerical_overlap_transports{end+1,1}=struct('kind','historical_finite_M_with_current_conditional_flight_sidecar','old_graph_reference',query.old_graph_reference,'old_M_row',oldRow,'sidecar_reference',refs.HistoricalMSidecarReference,'sidecar_row',at,'left_node',pair(1),'right_node',pair(2),'original_evidence_unchanged',true);
  relationContext{end+1,1}=struct('M_row',fact.active_M_row,'kind','unchanged_historical_finite_M_conditionally_current','old_M_row',oldRow,'sidecar_reference',refs.HistoricalMSidecarReference,'sidecar_row',at,'current_all9_replayed',false);
 end
 supplementFacts{k}=fact;
end
clear side r q e
carrierFacts=cell(3,1);originalLinks=cell(0,1);
for k=1:3
 check(work);r=refs.FreshCarriers{k};caseRow=[2,3,6];oldRow=caseRow(strcmp(required,r.role));assert(isscalar(oldRow),'PKCurrentSuccessor:FreshRole','Bind each declared fresh role to its original historical M row.');q=query.old_M{oldRow};
 ix=BranchSolutionFile_v3.index(r.reference.file);meta=ix.metadata;assert(numel(ix.points)==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2&&isequal(meta.component_graph.qualified_numerical_overlaps,[2,3])&&numel(meta.component_graph.numerical_overlap_evidence)==1&&sameRef(meta.acquire_reference,r.experiment_reference)&&sameRef(meta.cold_result_reference,r.cold_result_reference),'PKCurrentSuccessor:FreshCarrier','Append only the full closed current P1-to2/M2-to3 carrier with NONEDGE target.');
 z=load('-mat',r.experiment_reference.file,'meeting');meeting=z.meeting;clear z;assert(strcmp(meeting.schema,'PK15h-current-owned-meeting-flight-overlay-v1')&&meeting.completed&&meeting.source_posthash&&meeting.six_current_flight_checks_PASS&&meeting.request.old_M_row==oldRow&&sameRef(meeting.request.query_reference,queryRef)&&sameRef(meeting.request.original_audit_reference,q.evidence.audit_reference)&&isequaln(meeting.request.original_evidence_unchanged,q.evidence),'PKCurrentSuccessor:FreshCaseAuthority','The new experiment must be the original-selector refresh of this exact old relation, not its already-matched candidate pair.');clear meeting
 [native,reports,md]=BranchSolutionFile_v3.loadSolutions(r.reference.file,1:3);[again,againReports,againMD]=BranchSolutionFile_v3.loadSolutions(r.reference.file,1:3);for j=1:3,same(public(native{j}),public(again{j}));same(reports{j},againReports{j});same(md{j},againMD{j});end;clear again againReports againMD
 e=meta.component_graph.numerical_overlap_evidence{1};C1FiniteNumericalOverlap_v3.validateRetained(e,native{2},native{3},reports{2},reports{3},native{1});z=load('-mat',r.cold_result_reference.file,'result');cold=z.result;clear z
 assert(cold.current_M_eligible&&cold.six_current_flight_checks_PASS&&cold.source_posthash&&cold.return_timely&&sameRef(cold.whole_flight_experiment_reference,r.experiment_reference)&&isequaln(cold.finite_numerical_overlap,e),'PKCurrentSuccessor:FreshCold','Preserve the actual independently cold-qualified current finite proof and six conditional-flight results.');
 [catalogue,sn]=addCatalogue(catalogue,r.reference,ix);offset=numel(nodes);globals=offset+(1:3);
 for j=1:3
  [node,point,owner]=projectNode(native{j},reports{j},ix.points{j},sn,j,numel(nodes)+1,r.reference,out);point.metadata.edge_enabled=j==2;if j==2,point.metadata.edge_from=globals(1);end
  nodes{end+1,1}=node;points{end+1,1}=point;if ~any(cellfun(@(v)strcmp(v.output_component_identity,owner.output_component_identity),owners)),owners{end+1,1}=owner;end
  context{end+1,1}=struct('kind','fresh_current_historical_refresh_carrier_occurrence','role',r.role,'old_M_row',oldRow,'carrier_index',j,'carrier_reference',r.reference,'own_trace_status','RETAINED_CURRENT_CONDITIONAL_OVERLAY','conditional_seed_flight_eligible',true,'recorded_all9',recordedAll9(reports{j}),'fresh_all9_status','ACCEPTED_REPORT_AND_COLD_AUTHORITY_RETAINED_NOT_REPLAYED_BY_ASSEMBLY','fresh_all9_replayed_by_this_operation',false,'original_experiment_reference',r.experiment_reference);
 end
 d.physical_edges(end+1,:)=globals(1:2);d.qualified_numerical_overlaps(end+1,:)=globals(2:3);d.numerical_overlap_evidence{end+1,1}=e;currentMRow=size(d.qualified_numerical_overlaps,1);
 d.numerical_overlap_transports{end+1,1}=struct('kind','inherited_qualified_numerical_overlap','input_request',struct('source_file',r.reference.file,'source_sha256',r.reference.sha256,'source_overlap_row',1),'left_node',globals(2),'right_node',globals(3),'original_evidence_unchanged',true);
 verify({meta.original_branch_reference});inputs=uniqueRefs([inputs;{meta.original_branch_reference}]);runIndex=BranchSolutionFile_v3.index(meta.original_branch_reference.file);source=runIndex.metadata.source_reference;sourceIndex=runIndex.metadata.source_indices(2);imported=md{1}.provenance.original_point_metadata;
 assert(strcmp(imported.provenance.kind,'imported nonedge initial pair')&&strcmp(imported.provenance.source_file,source.file)&&imported.provenance.source_index==sourceIndex&&isequaln(imported,runIndex.points{2}.metadata),'PKCurrentSuccessor:OriginalImport','Preserve the exact immediate Run import FILE/SHA/index chain.');
 old=lookup(base,source,sourceIndex);assert(isscalar(old),'PKCurrentSuccessor:SourceBase','Resolve the original source base through its declared literal catalogue selector.');[oldOrbit,oldReport]=loadSelected(source,sourceIndex);inputs=uniqueRefs([inputs;{source}]);[yes,proof]=fgExactE(native{1},oldOrbit{1},reports{1},oldReport{1});assert(yes,'PKCurrentSuccessor:SourceE','Require unchanged full-record/policy/section/cohort E for the imported original source.');d.exact_record_equalities(end+1,:)=[old,globals(1)];d.equality_evidence{end+1,1}=proof;
 originalLinks{end+1,1}=struct('role',r.role,'kind','literal_Run_import_base','base_global_index',old,'new_global_index',globals(1),'source_reference',source,'source_index',sourceIndex);
 % The old relation's literal target COPY is declared even when the original
 % inward-control file is not a base source. No generic fallback or ID search.
 targetEndpoint=q.endpoints{2};targetGlobal=oldMap(targetEndpoint.old_global);assert(targetGlobal>0&&targetGlobal==targetEndpoint.current_global&&targetGlobal<=parentCount&&nodes{targetGlobal}.source_index==targetEndpoint.source_index&&sameRef(catalogue{nodes{targetGlobal}.source_number},targetEndpoint.source_reference)&&strcmp(nodes{targetGlobal}.native_ID,targetEndpoint.native_ID)&&strcmp(targetEndpoint.native_ID,q.evidence.right_native_ID),'PKCurrentSuccessor:LiteralTargetCopy','Use the exact declared old-M target occurrence through original-to-active mapping.');
 [to,rr]=loadSelected(targetEndpoint.source_reference,targetEndpoint.source_index);inputs=uniqueRefs([inputs;{targetEndpoint.source_reference}]);[yes,proof]=fgExactE(native{3},to{1},reports{3},rr{1});assert(yes,'PKCurrentSuccessor:TargetE','The new target must equal the declared unchanged old target copy in full record, policy, section and symbolic cohort.');d.exact_record_equalities(end+1,:)=[targetGlobal,globals(3)];d.equality_evidence{end+1,1}=proof;
 originalLinks{end+1,1}=struct('role',r.role,'kind','literal_old_M_target_copy','base_global_index',targetGlobal,'new_global_index',globals(3),'source_reference',targetEndpoint.source_reference,'source_index',targetEndpoint.source_index,'old_graph_global',targetEndpoint.old_global,'old_M_row',oldRow);
 relationContext{end+1,1}=struct('M_row',currentMRow,'kind','fresh_current_owned_root_and_cold_qualified_M','old_historical_row_refreshed',oldRow,'carrier_reference',r.reference,'experiment_reference',r.experiment_reference,'cold_result_reference',r.cold_result_reference,'current_all9_replayed_by_assembly',false);
 carrierFacts{k}=struct('role',r.role,'old_M_row_refreshed',oldRow,'reference',r.reference,'global_indices',globals,'actual_P_orientation',globals(1:2),'current_finite_M',globals(2:3),'current_M_row',currentMRow,'literal_source_base_global',old,'literal_target_global',targetGlobal,'original_owner',md{2}.component_identity,'original_capture',e.earned_physical_edge.capture,'qualification_repeated',false);
 clear native reports md ix meta runIndex source oldOrbit oldReport cold e to rr q
end
same(base.nodes,nodes(1:parentCount));same(base.source_catalog,catalogue(1:numel(base.source_catalog)));same(base.view_index.points,points(1:parentCount));same(base.current_context,context(1:parentCount));
for name={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'},key=name{1};same(base.graph_discovery.(key),d.(key)(1:size(base.graph_discovery.(key),1),:));end
for name={'equality_evidence','qualified_alias_evidence','numerical_overlap_evidence','numerical_overlap_transports'},key=name{1};prior=base.graph_discovery.(key);same(prior,reshape(d.(key)(1:numel(prior)),size(prior)));end
N=numel(nodes);edges=[d.physical_edges;d.exact_record_equalities;d.qualified_record_aliases;d.qualified_numerical_overlaps];bins=conncomp(graph(edges(:,1),edges(:,2),[],N));componentCount=max(bins);template=base.view_index.metadata.component_graph;globalGraph=rfGraph(template,d,(1:N).',N,componentCount==1);globalMeta=base.view_index.metadata;globalMeta.component_graph=globalGraph;globalMeta.source_owner_map=owners;globalMeta.source_catalog_file=out;globalMeta.component_number=0;globalMeta.parent_current_view_reference=refs.BaseViewReference;
components=cell(componentCount,1);occurrence=cell(N,1);parentMap=zeros(parentCount,5);
for c=1:componentCount
 selected=find(bins==c).';selected=selected(:);map=zeros(N,1);map(selected)=1:numel(selected);lp=points(selected);localGraph=rfGraph(template,d,selected,N,true);
 for j=1:numel(selected),q=lp{j};q.index=j;q.order=j;q.metadata.order=j;q.solution_variable=sprintf('solution_%06d',j);q.report_variable=sprintf('report_%06d',j);if isfield(q.metadata,'edge_from'),q.metadata.edge_from=map(q.metadata.edge_from);assert(q.metadata.edge_from>0,'PKCurrentSuccessor:LocalP','Actual physical predecessors stay in their effective component.');end;lp{j}=q;g=selected(j);node=nodes{g};src=catalogue{node.source_number};occurrence{g}=struct('source_file',src.file,'source_sha256',src.sha256,'source_index',node.source_index,'global_index',g,'component_number',c,'component_index',j);if g<=parentCount,prior=base.occurrence_map{g};parentMap(g,:)=[g,prior.component_number,prior.component_index,c,j];end,end
 lm=globalMeta;lm.component_number=c;lm.component_graph=localGraph;lix=struct('storage_version',base.view_index.storage_version,'metadata',lm,'points',{lp},'edges',{edgeIndex(localGraph.original_explicit_edges,lp)});components{c}=struct('component_number',c,'global_indices',selected,'planned_materialization_index',lix,'materialization_completed_by_this_operation',false);
end
viewIndex=struct('storage_version',base.view_index.storage_version,'metadata',globalMeta,'points',{points},'edges',{edgeIndex(d.physical_edges,points)});same(base.view_index.edges,viewIndex.edges(1:numel(base.view_index.edges)));
oldTargetGlobals=base.active_to_original_or_appended(base.known_family_paths_and_obligations.target_catalog_active_globals);allRoles=[cellfun(@(v)struct('role',v.role),base.carrier_facts,'UniformOutput',false);refs.FreshCarriers];summary=routeSummary(d,base.historical_relation_tables,oldMap,oldTargetGlobals,allRoles,bins,nodes,base.held_boundary);
summary.historical_A_M_not_current=isempty(operativeOldRows);summary.unconditional_historical_epoch_promotion_performed=false;summary.conditional_historical_M_current_rows=operativeOldRows;summary.historical_A_remain_obligations=true;summary.other_historical_M_remain_obligations=true;
% Four named finite neighborhoods use explicit saved selectors. The two LONG
% selectors are studied source HEADS, not substituted native inward controls.
z=load('-mat',query.old_graph_reference.file,'component_plan');originalGraph=z.component_plan;clear z
neighborhoods=cell(4,1);shortRows=[3,2];shortNames={'SHORTpositive_retained_inward_control';'SHORTnegative_retained_inward_control'};
for k=1:2
 endpoint=query.old_M{shortRows(k)}.endpoints{2};oldGlobal=endpoint.old_global;active=oldMap(oldGlobal);assert(active>0&&active==endpoint.current_global&&strcmp(nodes{active}.native_ID,endpoint.native_ID)&&nodes{active}.source_index==endpoint.source_index&&sameRef(catalogue{nodes{active}.source_number},endpoint.source_reference),'PKCurrentSuccessor:ShortNeighborhood','Bind SHORT positive/negative to the actual declared oldM3/2 right-endpoint control copies.');
 neighborhoods{k}=struct('name',shortNames{k},'kind','literal_retained_inward_control_occurrence','old_M_row',shortRows(k),'old_M_side',2,'old_graph_global',oldGlobal,'active_global',active,'native_ID',nodes{active}.native_ID,'source_reference',endpoint.source_reference,'source_index',endpoint.source_index,'boundary_validation_performed_by_assembly',false,'physical_endpoint_closed',false);
end
studySHA={'6c2a8aa1cc21f1ad485f34e35d9d0423dd6c433a6eabdeb48d1a715126278278';'1b1bc56d58c6969a3964348fbda0dfea785f597c8f224561b5e7bbefe9f740b7'};longNames={'LONGpositive_studied_source_head_neighborhood';'LONGnegative_studied_source_head_neighborhood'};
for k=1:2
 studyRef=refs.HighBoundaryStudies{k};assert(strcmp(studyRef.sha256,studySHA{k}),'PKCurrentSuccessor:LongStudyPin','Use the exact declared already executed HIGH study, not a range or file-name guess.');z=load('-mat',studyRef.file,'study');study=z.study;clear z
 assert(study.completed&&study.source_posthash&&numel(study.source_pair)==2,'PKCurrentSuccessor:LongStudy','Use the literal closed study source pair and rank evidence only.');source=study.source_reference;sourceIndex=study.source_pair(2);oldGlobal=lookup(originalGraph,source,sourceIndex);assert(isscalar(oldGlobal),'PKCurrentSuccessor:LongOriginalSelector','Resolve the HIGH study source HEAD by exact original FILE/SHA/index.');active=oldMap(oldGlobal);
 assert(active>0&&active<=parentCount&&nodes{active}.source_index==sourceIndex&&sameRef(catalogue{nodes{active}.source_number},source)&&strcmp(nodes{active}.native_ID,originalGraph.nodes{oldGlobal}.native_ID),'PKCurrentSuccessor:LongActiveSelector','The studied source HEAD must retain its exact original-to-active occurrence map.');
 neighborhoods{k+2}=struct('name',longNames{k},'kind','already_studied_source_head_neighborhood','study_reference',studyRef,'study_source_pair',study.source_pair,'study_local_rank',study.local_rank,'old_graph_global',oldGlobal,'active_global',active,'native_ID',nodes{active}.native_ID,'source_reference',source,'source_index',sourceIndex,'independent_native_inward_control_substituted',false,'boundary_validation_performed_by_assembly',false,'physical_endpoint_closed',false);clear study
end
clear originalGraph
oldA=mapPairs(base.historical_relation_tables.qualified_record_aliases,oldMap);oldM=mapPairs(base.historical_relation_tables.qualified_numerical_overlaps,oldMap);G=graph(edges(:,1),edges(:,2),[],N);neighborhoodRoutes=cell(4,1);targets=base.known_family_paths_and_obligations.target_catalog_active_globals;
for k=1:4
 target=targets(k);endpoint=neighborhoods{k}.active_global;path=shortestpath(G,target,endpoint);status='NO_CURRENT_FINITE_TYPED_ROUTE';if ~isempty(path),status='CURRENT_FINITE_TYPED_ROUTE_EXISTS_NOT_CONTINUOUS_BRANCH_OR_ENDPOINT_PROOF';end
 neighborhoodRoutes{k}=struct('target_catalog_index',k,'target_global',target,'target_native_ID',nodes{target}.native_ID,'neighborhood',neighborhoods{k},'status',status,'current_typed_route',{typedRoute(path,d,oldA,oldM,false)},'continuous_branch_proved',false,'physical_endpoint_closed',false,'search_direction_exhausted',false);
end
summary.named_inward_neighborhood_routes=neighborhoodRoutes;summary.inward_neighborhood_scope='SHORT endpoints are exact retained control copies from queryoldM3/2 right endpoints. LONG endpoints are exact source_pair2 HEAD neighborhoods of the two bound executed HIGH studies. Existing local-rank evidence is referenced, with no new boundary validation, control substitution, endpoint closure or range-based inference.';

newOriginalMap=[base.original_global_to_active;(parentCount+(1:(N-parentCount))).'];newActiveMap=[base.active_to_original_or_appended;(numel(base.original_global_to_active)+(1:(N-parentCount))).'];
component_plan=base;component_plan.original_global_to_active=newOriginalMap;component_plan.active_to_original_or_appended=newActiveMap;component_plan.completed=false;component_plan.source_posthash=false;component_plan.parent_current_view_reference=refs.BaseViewReference;component_plan.nodes=nodes;component_plan.source_catalog=catalogue;component_plan.view_index=viewIndex;component_plan.graph_discovery=d;component_plan.components=components;component_plan.occurrence_map=occurrence;component_plan.current_context=context;component_plan.known_family_paths_and_obligations=summary;
component_plan.parent_current_view_scope=struct('reference',refs.BaseViewReference,'source_code',{base.source_code},'input_references',{base.input_references},'completion_scope',base.completion_scope,'known_family_paths_and_obligations',base.known_family_paths_and_obligations,'historical_A_M_promoted_to_current',base.historical_A_M_promoted_to_current);
component_plan=rmfield(component_plan,'historical_A_M_promoted_to_current');component_plan.current_relation_context=relationContext;component_plan.current_relation_context_scope='Only newly operative sidecar/fresh-carrier M rows are listed here; inherited current carriers remain bound by the literal base carrier_facts and parent view reference.';component_plan.current_conditional_historical_M_rows=operativeOldRows;component_plan.historical_relation_tables=base.historical_relation_tables;component_plan.held_boundary=base.held_boundary;
component_plan.successor_assembly=struct('schema','PK15h-current-component-successor-assembly-v1','base_reference',refs.BaseViewReference,'base_occurrences',parentCount,'added_occurrences',N-parentCount,'historical_sidecar_reference',refs.HistoricalMSidecarReference,'historical_sidecar_rows',{supplementFacts},'fresh_carrier_facts',{carrierFacts},'fresh_literal_occurrence_links',{originalLinks},'parent_to_current_component_map',parentMap,'parent_map_columns',{{'base_global';'base_component';'base_local';'current_component';'current_local'}},'base_nodes_catalogue_points_context_prefixes_literal',true,'base_held702_and_historical_tables_literal',true,'old_native_carriers_reloaded_as_whole_sources',0,'old1118_native_records_reloaded',0,'new_carrier_public_read_passes',2,'new_retained_validation_calls',3,'new_qualification_calls',0,'global_map_scope','Base original/active map prefixes remain literal; new carrier occurrences receive appended pre-projection bookkeeping slots, never remapped physical source indices.','root_ODE_replay_classifier_calls',0,'new_P_edges_earned',0,'new_M_relations_qualified',0,'old2_3_6_promoted_from_sidecar',false);
component_plan.completion_scope='Saved conditional-flight current-view successor only. Selected unchanged old finite M gain explicit current conditional-flight sidecar context; three fresh M retain their independently earned current root/P/fine/cold authority. No original flags, unconditional historical epochs, fresh all-nine assembly admission, parent/P1 attachments, endpoints, uniqueness or global search completion.';
component_plan.input_references=uniqueRefs(inputs);component_plan.source_code=refs.SourceReferences;component_plan.source_occurrence_bijection_verified=false;component_plan.active_source_occurrence_bijection_verified=true;component_plan.native_payload_copied=false;component_plan.fresh_all9_replayed_by_this_operation=false;component_plan.root_ODE_replay_calls=0;component_plan.new_P_edges_earned=0;component_plan.new_M_relations_qualified=0;component_plan.PIP_parent_attachments_created=0;component_plan.scientific_completion_claimed=false;component_plan.own_process_exit_claimed=false;component_plan.core29_export_performed=false;
same(base.nodes,component_plan.nodes(1:parentCount));same(base.current_context,component_plan.current_context(1:parentCount));same(base.held_boundary,component_plan.held_boundary);same(base.historical_relation_tables,component_plan.historical_relation_tables);verify(component_plan.input_references);check(work);component_plan.completed=true;component_plan.source_posthash=true;plan_digest=C1ScientificDigest_v3(component_plan);save(stage,'component_plan','plan_digest','-v7');z=load('-mat',stage,'component_plan','plan_digest');assert(strcmp(z.plan_digest,plan_digest)&&strcmp(C1ScientificDigest_v3(z.component_plan),plan_digest),'PKCurrentSuccessor:Readback','The whole compact successor must retain its complete typed digest.');clear z;verify(component_plan.input_references);check(finish);assert(~isfile(out),'PKCurrentSuccessor:FreshPublish','Preserve a concurrent output.');javaMethod('move','java.nio.file.Files',java.io.File(stage).toPath(),java.io.File(out).toPath(),javaArray('java.nio.file.CopyOption',0));
result=struct('completed',true,'source_posthash',true,'plan_reference',reference(out),'base_occurrences',parentCount,'added_occurrences',N-parentCount,'active_occurrences',N,'component_count',componentCount,'component_sizes',accumarray(bins(:),1),'current_M_count',size(d.qualified_numerical_overlaps,1),'conditional_historical_M_rows',operativeOldRows,'held_original_global',702,'family_summary',summary,'scientific_completion_claimed',false,'own_process_exit_claimed',false,'return_timely',left(finish)>0);fprintf('PK15_CURRENT_COMPONENT_SUCCESSOR_RETURN %s\n',jsonencode(result));
end
function [catalogue,sn]=addCatalogue(catalogue,ref,ix)
assert(~any(cellfun(@(c)sameRef(c,ref),catalogue)),'PKCurrentView:DistinctSource','Append each distinct frozen native source once.');
sn=numel(catalogue)+1;catalogue{sn,1}=struct('file',ref.file,'sha256',ref.sha256,'bytes',dirBytes(ref.file),'metadata',ix.metadata, ...
    'point_metadata',{cellfun(@(q)q.metadata,ix.points,'UniformOutput',false)},'original_edges',{ix.edges}, ...
    'stored_points',numel(ix.points),'stored_edges',numel(ix.edges),'source_public_readback_verified',false);
end
function [n,q,ownerRow]=projectNode(o,r,point,sn,si,globalIndex,source,out)
section=MatchingReturnSection_v3(o,o,{r,r});state=o.initial_state(:);state(1)=0;
n=struct('source_number',sn,'source_index',si,'point',point,'native_ID',OrbitContentIdentity_v3(o), ...
    'normalized_state',state,'initial_mode',o.initial_mode(:),'parameter',o.parameter(:),'period',o.period, ...
    'stride',o.stride_displacement(:),'complete_return_section',section.compatible);
owner=sprintf('source-%06d::%s',sn,char(point.component_identity));
ownerRow=struct('source_number',sn,'source_component_identity',char(point.component_identity),'output_component_identity',owner);
original=normalizedOriginalMetadata(point.metadata);
m=struct('component_identity',owner,'classification',char(point.classification),'nativeE',point.nativeE,'signedmeanU',point.signedmeanU, ...
    'order',globalIndex,'consolidation_point_schema','C1-consolidated-occurrence-v1','provenance',struct('source_file',source.file, ...
    'source_sha256',source.sha256,'source_index',si,'source_catalog_file',out,'source_catalog_entry',sn,'original_point_metadata',original,'qualification_flags_changed',false));
q=struct('index',globalIndex,'component_identity',owner,'order',globalIndex,'classification',m.classification,'nativeE',m.nativeE,'signedmeanU',m.signedmeanU, ...
    'provenance',m.provenance,'metadata',m,'solution_variable',sprintf('solution_%06d',globalIndex), ...
    'report_variable',sprintf('report_%06d',globalIndex),'whole_public_data_readback_verified',false);
end
function at=lookup(p,ref,index)
s=find(cellfun(@(c)sameRef(c,ref),p.source_catalog));assert(numel(s)<=1,'PKCurrentView:SourceUnique','Original FILE/SHA selects at most one catalog source.');
at=[];if isempty(s),return;end
at=find(cellfun(@(n)n.source_number==s&&n.source_index==index,p.nodes));
end
function [o,r]=loadSelected(ref,index),verify({ref});[o,r]=BranchSolutionFile_v3.loadSolutions(ref.file,index);end
function d=projectDiscovery(d,selected,n)
map=zeros(n,1);map(selected)=1:numel(selected);
fields={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};
ev={'','equality_evidence','qualified_alias_evidence','numerical_overlap_evidence'};
for k=1:4
    pairs=d.(fields{k});keep=ismember(pairs(:,1),selected)&ismember(pairs(:,2),selected);d.(fields{k})=reshape(map(pairs(keep,:)),[],2);
    if k>1,d.(ev{k})=d.(ev{k})(keep);end
    if k==4
        d.numerical_overlap_transports=d.numerical_overlap_transports(keep);
        for j=1:numel(d.numerical_overlap_transports),d.numerical_overlap_transports{j}.left_node=map(d.numerical_overlap_transports{j}.left_node);d.numerical_overlap_transports{j}.right_node=map(d.numerical_overlap_transports{j}.right_node);end
    end
end
end
function edges=edgeIndex(P,points)
edges=cell(size(P,1),1);for k=1:size(P,1),pair=P(k,:);assert(strcmp(points{pair(1)}.component_identity,points{pair(2)}.component_identity), ...
    'PKCurrentView:POwner','Every P keeps its actual same-owner orientation.');edges{k}=struct('from',pair(1),'to',pair(2),'component_identity',points{pair(2)}.component_identity);end
end
function out=routeSummary(d,historical,map,targetGlobals,carriers,bins,nodes,held)
N=numel(nodes);P=d.physical_edges;E=d.exact_record_equalities;M=d.qualified_numerical_overlaps;
current=[P;E;M];G=graph(current(:,1),current(:,2),[],N);oldM=mapPairs(historical.qualified_numerical_overlaps,map);oldA=mapPairs(historical.qualified_record_aliases,map);
augmented=[current;oldA.pairs;oldM.pairs];H=graph(augmented(:,1),augmented(:,2),[],N);targets=map(targetGlobals);
families=cell(2,1);labels={'SHORT';'LONG'};
for f=1:2
    pair=targets((f-1)*2+(1:2));path=shortestpath(G,pair(1),pair(2));legacyPath=shortestpath(H,pair(1),pair(2));
    currentRoute=typedRoute(path,d,oldA,oldM,false);legacyRoute=typedRoute(legacyPath,d,oldA,oldM,true);
    needed=[];for k=1:numel(legacyRoute),if strcmp(legacyRoute{k}.kind,'HISTORICAL_M_OBLIGATION'),needed(end+1)=legacyRoute{k}.original_relation_row;end;end %#ok<AGROW>
    status='NO_CURRENT_WITHIN_FAMILY_TYPED_ROUTE';if ~isempty(path),status='CURRENT_FINITE_TYPED_ROUTE_EXISTS_NOT_A_CONTINUOUS_BRANCH_CERTIFICATE';end
    if isempty(legacyPath)&&isempty(path),status='UNASSESSED_WITHIN_FAMILY_ROUTE_GAP_OR_UNLINKED_TARGET';end
    families{f}=struct('family',labels{f},'positive_target_global',pair(1),'negative_target_global',pair(2), ...
        'positive_component',bins(pair(1)),'negative_component',bins(pair(2)),'status',status, ...
        'current_typed_route',{currentRoute},'historical_augmented_route',{legacyRoute},'historical_M_rows_requiring_current_supplement',unique(needed), ...
        'continuous_PK_branch_proved',false,'PIP_parent_attachment_proved',false);
end
cross=cell(2,1);for signIndex=1:2
    pair=targets([signIndex,signIndex+2]);cross{signIndex}=struct('short_target',pair(1),'long_target',pair(2), ...
        'prospective_typed_route',{typedRoute(shortestpath(G,pair(1),pair(2)),d,oldA,oldM,false)}, ...
        'join_goal_authorized_by_anchor_labels',false,'distinct_family_labels_preserved',true);
end
incoming=accumarray(P(:,2),1,[N,1]);outgoing=accumarray(P(:,1),1,[N,1]);leaves=find(incoming>0&outgoing==0);frontiers=cell(numel(leaves),1);
for j=1:numel(leaves)
    i=leaves(j);n=nodes{i};isHeld=map(701)==i;
    frontiers{j}=struct('global_index',i,'source_number',n.source_number,'source_index',n.source_index,'native_ID',n.native_ID, ...
        'component',bins(i),'apex_dx',n.normalized_state(2),'apex_height',n.normalized_state(3),'period',n.period, ...
        'incoming_P_row',find(P(:,2)==i),'outgoing_P_rows',find(P(:,1)==i),'held701_to702_obligation',isHeld, ...
        'physical_endpoint_closed',false,'search_direction_exhausted',false,'scope','Directional P leaf of this saved graph only. No endpoint is inferred from degree, ranges or an omitted held node.');
end
out=struct('known_families',{families},'cross_family_prospective_observations',{cross},'directional_P_frontiers',{frontiers}, ...
    'zero_P_degree_seed_inventory',find(incoming+outgoing==0),'target_catalog_active_globals',targets,'retained_carrier_roles',{cellfun(@(r)r.role,carriers,'UniformOutput',false)}, ...
    'historical_M_never_identity',true,'historical_A_M_not_current',true,'held_boundary',held,'two_component_count_assumed',false, ...
    'scope','SHORT and LONG remain distinct known family labels. Within-family +/- routes and exact old-M obligations are reported dynamically. Cross-family paths are observations, not instructions to force a join; graph frontiers are not physical endpoints or completed searches.');
end
function out=mapPairs(P,map)
keep=map(P(:,1))>0&map(P(:,2))>0;out=struct('pairs',reshape(map(P(keep,:)),[],2),'original_rows',find(keep));
end
function route=typedRoute(path,d,oldA,oldM,allowHistorical)
route=cell(max(0,numel(path)-1),1);
for k=1:numel(route)
    pair=path(k:k+1);p=find(all(d.physical_edges==pair,2)|all(d.physical_edges==fliplr(pair),2));
    e=find(all(d.exact_record_equalities==pair,2)|all(d.exact_record_equalities==fliplr(pair),2));
    m=find(all(d.qualified_numerical_overlaps==pair,2)|all(d.qualified_numerical_overlaps==fliplr(pair),2));
    a=find(all(oldA.pairs==pair,2)|all(oldA.pairs==fliplr(pair),2));h=find(all(oldM.pairs==pair,2)|all(oldM.pairs==fliplr(pair),2));
    if ~isempty(p),kind='LITERAL_OR_RETAINED_OWNED_P';row=p(1);stored=d.physical_edges(row,:);original=0;
    elseif ~isempty(e),kind='VERIFIED_EXACT_RECORD_E';row=e(1);stored=d.exact_record_equalities(row,:);original=0;
    elseif ~isempty(m),kind='CURRENT_RETAINED_FINITE_M';row=m(1);stored=d.qualified_numerical_overlaps(row,:);original=0;
    elseif allowHistorical&&~isempty(a),kind='HISTORICAL_A_OBLIGATION';row=a(1);stored=oldA.pairs(row,:);original=oldA.original_rows(row);
    elseif allowHistorical&&~isempty(h),kind='HISTORICAL_M_OBLIGATION';row=h(1);stored=oldM.pairs(row,:);original=oldM.original_rows(row);
    else,error('PKCurrentView:TypedRoute','Every path step requires its actual retained relation selector.');end
    route{k}=struct('from',pair(1),'to',pair(2),'kind',kind,'relation_row',row,'stored_orientation',stored, ...
        'traversal_follows_stored_orientation',isequal(pair,stored),'original_relation_row',original,'identity_claimed',false);
end
end
function yes=recordedAll9(r)
names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
yes=isfield(r,'accepted')&&isequal(r.accepted,true)&&isfield(r,'acceptance_gates')&&all(isfield(r.acceptance_gates,names));
if yes,yes=all(cellfun(@(k)isequal(r.acceptance_gates.(k),true),names));end
end
function refs=uniqueRefs(refs)
keys=cellfun(@(r)[r.file,'|',r.sha256],refs,'UniformOutput',false);[~,at]=unique(keys,'stable');refs=refs(at);
end
function same(a,b),assert(isequaln(a,b),'PKCurrentView:Readback','Full declared public values differ.');end
function value=public(value)
if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
    out=struct('native_class',class(value));names=properties(value);for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
elseif isstruct(value),names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end;end
elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
end
end
function providers(refs)
assert(iscell(refs)&&iscolumn(refs),'PKCurrentView:Providers','Use a column-cell source tuple.');
names={'ExtendPK15hCurrentComponentView20261104','BuildPK15hCurrentComponentView20261104','BuildPK15hExactSeedFlightOverlay20261104','RetainPK15hCurrentOverlap20261104', ...
    'C1StoredComponentSource_v3','BranchSolutionFile_v3','C1FiniteNumericalOverlap_v3','MatchingReturnSection_v3','RecordedReturnPolicy_v3', ...
    'OrbitContentIdentity_v3','C1ScientificDigest_v3','HybridOrbit_v3','Trajectory_v3','RoundSHA256_v3','V3Path_v3','V3Root_v3'};
paths=cellfun(@(r)r.file,refs,'UniformOutput',false);for k=1:numel(names),assert(sum(strcmp(paths,which(names{k})))==1,'PKCurrentView:Provider','Pin %s.',names{k});end
donor=fullfile(V3Root_v3(),'Research_v3','C1','.work_pk30h_20261101','AppendPK30hClosedCarriersStoredGraph20261102.m');
assert(sum(strcmp(paths,donor))==1,'PKCurrentView:Donor','Pin the source-only known append/graph/E donor; never invoke its old grant worker.');
end
function verify(refs),for k=1:numel(refs),r=refs{k};info=dir(r.file);assert(isscalar(info)&&~info.isdir&&strcmp(literal(r.file),r.file) ...
    &&(~isfield(r,'bytes')||info.bytes==r.bytes)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKCurrentView:Changed','Changed immutable input: %s.',r.file);end;end
function yes=sameRef(a,b),yes=strcmp(a.file,b.file)&&strcmp(a.sha256,b.sha256);end
function r=reference(file),r=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',dirBytes(file));end
function n=dirBytes(file),d=dir(file);assert(isscalar(d),'PKCurrentView:File','Expected one source file.');n=d.bytes;end
function p=literal(p),p=char(java.io.File(char(p)).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(p)).getCanonicalPath())),'PKCurrentView:Alias','Hash/native read must address the same file.');end
function n=nowClock(),n=struct('u',double(java.time.Instant.now().toEpochMilli())/1000,'m',double(java.lang.System.nanoTime()));end
function v=left(l),n=nowClock();v=min(l.u-n.u,(l.m-n.m)/1e9);end
function check(l),assert(left(l)>0,'PKCurrentView:Deadline','Original operation/science clocks expired.');end

function yes=fgCohortEqual(a,b)
    names={'return_multiplicity','event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names','section_cluster_coincidence','section_coincident_cluster_indices'};
    required={'event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names'};yes=true;
    for k=1:numel(required),left=a.(required{k});right=b.(required{k});yes=yes&&~isempty(left)&&~isempty(right);if ischar(left)||isstring(left),yes=yes&&all(strlength(string(left))>0,'all');end;if ischar(right)||isstring(right),yes=yes&&all(strlength(string(right))>0,'all');end;end
    for k=1:numel(names),yes=yes&&strcmp(C1ScientificDigest_v3(a.(names{k})),C1ScientificDigest_v3(b.(names{k})));end
end

function [yes,e]=fgExactE(a,b,ra,rb)
    [yes,e]=rfExactE(a,b,ra,rb);if ~yes,return;end
    names={'return_multiplicity','event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names','section_cluster_coincidence','section_coincident_cluster_indices'};
    if ~fgCohortEqual(a,b),yes=false;e=struct();return;end
    e.symbolic_cluster_and_coincidence_cohort_literal_equal=true;e.symbolic_cohort_fields=names(:);e.absolute_event_time_equality_required=false;
end

function [yes,e]=rfExactE(a,b,ra,rb)
    e=struct();yes=false;if ~strcmp(OrbitContentIdentity_v3(a),OrbitContentIdentity_v3(b))||~isequaln(rfRecord(a),rfRecord(b)),return;end
    [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);if ~pa.complete||~pb.complete||~isequaln(pa.configuration,pb.configuration),return;end
    match=MatchingReturnSection_v3(a,b,{ra,rb});if ~match.compatible,return;end
    yes=true;e=struct('native_ID',OrbitContentIdentity_v3(a),'exact_state_mode_parameter_period_stride',true,'translation_gauge_normalized',false,'raw14_state_exact',true, ...
        'complete_policy_equal',true,'matching_return_section',match,'new_continuation_edge_created',false,'new_admission_claimed',false,'source_admission_epochs_unchanged',true);
end

function r=rfRecord(o)
    r=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement, ...
        'return_policy_name',o.return_policy_name,'section_chart',o.section_chart,'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature);
end

function g=rfGraph(template,d,selected,n,connected)
    map=zeros(n,1);map(selected)=1:numel(selected);g=template;g.nodes=numel(selected);
    fields={'original_explicit_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};actual={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};masks=cell(4,1);
    for k=1:4,p=d.(actual{k});mask=ismember(p(:,1),selected)&ismember(p(:,2),selected);masks{k}=mask;g.(fields{k})=reshape(map(p(mask,:)),[],2);end
    g.qualified_alias_evidence=d.qualified_alias_evidence(masks{3});g.numerical_overlap_evidence=d.numerical_overlap_evidence(masks{4});g.equality_evidence=d.equality_evidence(masks{2});
    g.effective_edges=[g.original_explicit_edges;g.exact_record_equalities;g.qualified_record_aliases;g.qualified_numerical_overlaps];g.connected=connected;g.isolated_record_catalogue=false;
end

function [original,kind]=normalizedOriginalMetadata(metadata)
% One-level flatten only for a direct known envelope. A Run import retains
% its ENTIRE immediate metadata; no provenance crawl or scientific edit.
assert(isstruct(metadata)&&isscalar(metadata),'C1Consolidate:PointMetadata', ...
    'Every immediate point metadata record must be one scalar struct.');
original=metadata;kind=1;
if ~isfield(metadata,'consolidation_point_schema'),return;end
assert(isequal(metadata.consolidation_point_schema,'C1-consolidated-occurrence-v1') ...
    &&isfield(metadata,'provenance')&&isstruct(metadata.provenance)&&isscalar(metadata.provenance), ...
    'C1Consolidate:MarkedMetadata','A marked point needs the exact known schema and scalar provenance.');
p=metadata.provenance;
pathText=@(x)ischar(x)&&isrow(x)&&~isempty(x);
positiveIndex=@(x)isnumeric(x)&&isreal(x)&&isscalar(x)&&isfinite(x)&&x>=1&&x==fix(x);
direct={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
imported={'kind','source_file','source_index','original_provenance'};
if isequal(sort(fieldnames(p)),sort(direct(:)))
    assert(pathText(p.source_file)&&pathText(p.source_catalog_file)&&positiveIndex(p.source_index)&&positiveIndex(p.source_catalog_entry) ...
        &&ischar(p.source_sha256)&&isrow(p.source_sha256)&&~isempty(regexp(p.source_sha256,'^[0-9a-f]{64}$','once')) ...
        &&isstruct(p.original_point_metadata)&&isscalar(p.original_point_metadata)&&isequal(p.qualification_flags_changed,false), ...
        'C1Consolidate:DirectMetadata','The direct consolidation envelope is malformed; retain it and refuse.');
    original=p.original_point_metadata;kind=2;
elseif isequal(sort(fieldnames(p)),sort(imported(:)))
    assert(isequal(p.kind,'imported nonedge initial pair')&&pathText(p.source_file)&&positiveIndex(p.source_index) ...
        &&isstruct(p.original_provenance)&&isscalar(p.original_provenance)&&isfield(metadata,'edge_enabled') ...
        &&isequal(metadata.edge_enabled,false)&&~isfield(metadata,'edge_from'), ...
        'C1Consolidate:ImportedMetadata','Only the exact Run imported-NONEDGE wrapper may preserve its entire immediate metadata.');
    kind=3;
else
    error('C1Consolidate:MarkedMetadata','Unknown marked provenance shape; no generic fallback or recursive flatten is permitted.');
end
end
