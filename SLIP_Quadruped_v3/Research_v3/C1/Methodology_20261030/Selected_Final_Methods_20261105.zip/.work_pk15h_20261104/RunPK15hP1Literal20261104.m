function result=RunPK15hP1Literal20261104(B,refs,o)
%RUNPK15HP1LITERAL20261104 Literal unchanged P1 states under a NEW native map.
% No root solve, correction, symmetry restriction, admission, P or M append.
% Native map output is durable BEFORE optional closure/reference/flight checks.
rkeys={'P1AuditReference';'ProfileReference';'SourceReferences'};
keys={'OutputFile';'ResumeReference';'MaxMapServices';'MapSeconds';'FlightOptions';'MaxWallSeconds';'SaveMarginSeconds'};
assert(nargin==3&&isequal(sort(fieldnames(refs)),sort(rkeys))&&isequal(sort(fieldnames(o)),sort(keys)),'PKP1Literal:API');
assert(B.capture.pid==feature('getpid')&&isequal(o.MapSeconds,60)&&iscell(refs.SourceReferences)&&iscolumn(refs.SourceReferences),'PKP1Literal:Budget');
validateattributes(o.MaxMapServices,{'double'},{'real','finite','scalar','integer','positive','<=',179});
validateattributes(o.MaxWallSeconds,{'double'},{'real','finite','scalar','positive','<=',7200});
validateattributes(o.SaveMarginSeconds,{'double'},{'real','finite','scalar','>=',120,'<',o.MaxWallSeconds/2});
assert(isstruct(o.FlightOptions)&&isscalar(o.FlightOptions)&&~isfield(o.FlightOptions,'Limits') ...
    &&isequal(o.FlightOptions.MaxWallSeconds,60),'PKP1Literal:FlightOptions');
n=nowClock();finish=struct('u',min(B.research_deadline_unix_seconds,n.u+o.MaxWallSeconds), ...
    'm',min(B.research_deadline_monotonic_ns,n.m+o.MaxWallSeconds*1e9));work=struct('u',finish.u-o.SaveMarginSeconds,'m',finish.m-o.SaveMarginSeconds*1e9);
providers(refs.SourceReferences);pins=[refs.SourceReferences;{refs.P1AuditReference;refs.ProfileReference}];verify(pins);check(work);
assert(strcmp(refs.P1AuditReference.sha256,'8cc5723c8ad866db3ee7f040794ae7fa7cc7be149c90d483cd75277d7b38989a') ...
    &&strcmp(refs.ProfileReference.sha256,'6c2a8aa1cc21f1ad485f34e35d9d0423dd6c433a6eabdeb48d1a715126278278'),'PKP1Literal:Authorities');
z=load('-mat',refs.P1AuditReference.file,'audit');old=z.audit;clear z
assert(old.complete&&old.source_code_posthash&&old.source_files_posthash,'PKP1Literal:OriginalAudit');
hit=find(cellfun(@(r)strcmp(r.label,'PK'),old.branches));assert(isscalar(hit),'PKP1Literal:OriginalPK');p1=old.branches{hit};clear old
assert(p1.scalar_complete&&isequal(size(p1.raw_results),[29,891])&&isequal(size(p1.native_initial_state),[14,891]),'PKP1Literal:OriginalShape');
source=p1.source;pins{end+1,1}=source;verify({source});z=load('-mat',source.file,'results');assert(isequaln(z.results,p1.raw_results),'PKP1Literal:OriginalRaw');clear z
eligible=find(p1.native_initial_geometry_valid&p1.initial_downward_apex&p1.energy_available);
invalid=find(~p1.native_initial_geometry_valid);
assert(isequal(eligible(:),(1:179).')&&isequal(invalid(:),(180:891).')&&~any(p1.mode_v3(:)), 'PKP1Literal:OriginalEligibility');
queue=[2;90;178;setdiff(eligible,[2;90;178],'stable')];
z=load('-mat',refs.ProfileReference.file,'study');study=z.study;clear z
assert(study.completed&&study.source_posthash&&study.native_all_nine&&study.native_report.accepted,'PKP1Literal:CurrentProfile');
r=study.native_report;[recorded,owner]=RecordedOrbitReplayProfile_v3(study.native_orbit,r);
assert(owner.complete&&all(isfield(r.effective_replay_ode,{'RelTol','AbsTol','MaxStep'})),'PKP1Literal:CurrentProfileOwner');
[policy,policyEvidence]=RecordedReturnPolicy_v3(r);
assert(policyEvidence.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'PKP1Literal:BL1');
profile=newReplayProfile(recorded,r.effective_replay_ode);
mapLimits=struct('MaxReturnTime',r.options.MaxReturnTime,'MaxCycleEvents',r.options.MaxCycleEvents,'MaxSectionCrossings',r.options.MaxSectionCrossings);
profileAuthority=struct('reference',refs.ProfileReference,'saved_owner',owner,'policy_configuration',policyEvidence.configuration, ...
    'effective_replay_ode',r.effective_replay_ode,'map_limits',mapLimits,'numeric_profile',profile, ...
    'scope','A declared NEW ode45 replay profile for literal P1 inputs. It does not own or validate the historical scheduled-v2 trajectory.');
clear study recorded r owner policyEvidence
file=canonical(o.OutputFile);cp=[file,'.checkpoint.mat'];writing=[cp,'.writing.mat'];
assert(startsWith(file,[V3Root_v3(),filesep])&&endsWith(file,'.mat')&&~isfile(file)&&~isfolder(file)&&~isfile(writing),'PKP1Literal:Fresh');
grant=struct('grant_id',B.grant_id,'start_utc',B.start_utc,'research_deadline_utc',B.research_deadline_utc,'deadline_utc',B.deadline_utc);
config=struct('references',refs,'source',source,'queue',queue,'fixed_grant',grant,'output_file',file, ...
    'map_seconds',o.MapSeconds,'flight_options',o.FlightOptions,'symmetry','none','map_profile_source','NEW current6c2 effective replay; identity section retraction; native section tolerances unchanged');
owned='';
if isempty(fieldnames(o.ResumeReference))
    assert(~isfile(cp)&&~isfolder(cp),'PKP1Literal:FreshCheckpoint');
    audit=struct('schema','PK15h-literal-P1-current-native-return-audit-v1','configuration',config,'profile_authority',profileAuthority, ...
        'cursor',1,'rows',{cell(179,1)},'all_original_columns',initialSummary(p1),'map_calls_invoked',0,'map_calls_returned',0, ...
        'completed',false,'source_posthash',false,'root_calls',0,'new_P_edges',0,'new_M_relations',0,'native_admissions',0, ...
        'original_columns',891,'original_geometry_eligible_columns',179,'retained_literal_initial_invalid_columns',712, ...
        'nearby_counterpart_search_performed',false,'nearby_counterpart_absence_claimed',false,'source_projections',0,'state_corrections',0, ...
        'scope','Literal unchanged original P1 inputs only. Finite or closed native returns are not PSS admissions, branch attachments or nearby-root absence proofs.');
    owned=savePrefix(cp,writing,audit,owned,finish);
else
    assert(strcmp(canonical(o.ResumeReference.file),cp),'PKP1Literal:ResumePath');verify({o.ResumeReference});
    z=load('-mat',cp,'audit');audit=z.audit;clear z;owned=o.ResumeReference.sha256;
    assert(strcmp(audit.schema,'PK15h-literal-P1-current-native-return-audit-v1')&&isequaln(audit.configuration,config) ...
        &&audit.cursor>=1&&audit.cursor<=180&&audit.completed==(audit.cursor==180),'PKP1Literal:ResumeConfig');
    verify({o.ResumeReference});
end
% This invocation's fresh rows remain provisional until its final guards.
audit.source_posthash=false;owned=savePrefix(cp,writing,audit,owned,finish);
services=0;status='BATCH_CAP_OR_CLOCK';failure=struct();schema=QuadrupedSchema_v3.shared();section=PoincareSection_v3.apex(schema.PhaseIndex,struct('ProjectionFunction',@(state,parameter)state(:)));
try
    while audit.cursor<=179
        at=audit.cursor;c=queue(at);
        if isempty(audit.rows{at})
            raw=p1.raw_results(:,c);x=LegacyStateAdapter_v3.toV3State([0;raw(1:13)]);
            [p,conversion]=LegacyParameterAdapter_v3.toV3(raw(23:29),'v2-exact');q=p1.mode_v3(:,c);
            assert(isequaln(LegacyStateAdapter_v3.fromV3State(x),[0;raw(1:13)]) ...
                &&isequaln(x,p1.native_initial_state(:,c))&&isequaln(p,p1.native_physical_parameter(:,c)), 'PKP1Literal:LosslessConversion');
            audit.rows{at}=struct('queue_index',at,'original_column',c,'literal_raw29',raw,'literal_state',x,'literal_mode',q,'physical_parameter',p, ...
                'parameter_conversion',conversion,'symmetry','none','source_projection_performed',false,'correction_performed',false, ...
                'preflight',struct(),'service_attempts',{{}},'map_returned',false,'native_exception_known',false,'native_timely',false, ...
                'canonical_return_state',[],'raw_return_state',[],'map_info',struct(),'native_outcome_saved_before_checks',false, ...
                'comparisons',struct(),'flight',struct(),'flight_PASS',false,'status','PREPARED','failure',struct());
            owned=savePrefix(cp,writing,audit,owned,finish);
        end
        row=audit.rows{at};
        if ~row.map_returned&&~row.native_exception_known
            if ~isempty(row.service_attempts)
                row.status='HOLD_UNKNOWN_PREVIOUS_MAP_OUTCOME';audit.rows{at}=row;owned=savePrefix(cp,writing,audit,owned,finish);status=row.status;break;
            end
            if services>=o.MaxMapServices||left(work)<=o.MapSeconds+60+15,break;end
            x=row.literal_state;q=row.literal_mode;p=row.physical_parameter;
            system=Quadrupedal_Dynamics_v3();flow=system.flow(0,x,q,p);physical=system.admissibilityReport(x,q,p,'accepted-state');
            row.preflight=struct('current_geometry_valid',physical.global_validity,'exact_apex',isequal(x(schema.State.dy),0),'on_native_section',section.isOnSection(x,p),'section_value',section.value(x,p),'section_ValueTolerance',section.ValueTolerance,'section_DerivativeTolerance',section.DerivativeTolerance,'section_retraction','identity; literal source and output are not snapped', ...
                'downward_apex',flow(schema.State.dy)<-1e-8,'all_flight',~any(q),'section_projection_identity',isequaln(section.project(x,p),x), ...
                'ambient_pack_fullState_roundtrip_exact',false);
            if row.preflight.current_geometry_valid&&row.preflight.on_native_section&&row.preflight.downward_apex&&row.preflight.all_flight&&row.preflight.section_projection_identity
                child=childLimit(work,o.MapSeconds);integration=profile;integration.ODEOptions=odeset(integration.ODEOptions,'OutputFcn',@(~,~,~)budgetOutput(child));
                map=PoincareMap_v3(system,section,HybridSimulator_v3(integration),policy,mapLimits);
                % Full ambient packing is only an identity check. An energy
                % family chart would add an unnecessary finite-inertia gate.
                problem=PeriodicOrbitResidual_v3(map,x);
                row.preflight.ambient_pack_fullState_roundtrip_exact=isequaln(problem.fullState(problem.packState(x)),x);
                assert(row.preflight.ambient_pack_fullState_roundtrip_exact,'PKP1Literal:AmbientIdentity');
                row.service_attempts{end+1}=struct('started',nowClock(),'limits',child,'actual_integration',integration,'return_map_limits',mapLimits);
                audit.map_calls_invoked=audit.map_calls_invoked+1;services=services+1;audit.rows{at}=row;owned=savePrefix(cp,writing,audit,owned,finish);
                try
                    [next,info]=map.evaluate(x,q,p);row.map_returned=true;row.canonical_return_state=next;row.raw_return_state=info.raw_return_state;row.map_info=info;
                    row.native_timely=left(child)>0&&left(work)>0;audit.map_calls_returned=audit.map_calls_returned+1;
                    audit.rows{at}=row;owned=savePrefix(cp,writing,audit,owned,finish);row.native_outcome_saved_before_checks=true;
                catch problem
                    row.native_exception_known=true;row.failure=failed(problem);row.status='LITERAL_NATIVE_MAP_EXCEPTION_NO_COUNTERPART_ABSENCE_CLAIM';
                    audit.rows{at}=row;owned=savePrefix(cp,writing,audit,owned,finish);
                end
                clear map problem integration next info
            else,row.native_exception_known=true;row.status='UNASSESSED_CURRENT_LITERAL_PREFLIGHT_UNSUPPORTED';end
        end
        if row.map_returned
            if left(work)<=60+10,audit.rows{at}=row;owned=savePrefix(cp,writing,audit,owned,finish);break;end
            % A resumed returned row was itself read from the durable prefix.
            row.native_outcome_saved_before_checks=true;
            try
                assert(isequaln(row.map_info.initial_state,row.literal_state)&&isequaln(row.map_info.initial_mode,row.literal_mode), 'PKP1Literal:LiteralInitialIdentity');
                row.comparisons=compare(row,p1,schema);fo=o.FlightOptions;fo.EventTimeTolerance=profile.EventTimeTolerance;
                fo.Limits=struct('deadline_unix_seconds',work.u,'deadline_monotonic_ns',work.m);
                row.flight=CheckC1PKOrbitFlights_v3(row.map_info,row.physical_parameter,fo);
                row.flight_PASS=strcmp(row.flight.status,'PASS')&&row.flight.return_timely;
                row.status='FINITE_LITERAL_OPEN_RETURN';if row.comparisons.literal_raw13_closed,row.status='FINITE_LITERAL_CLOSED_CANDIDATE_NO_ADMISSION';end
                if ~row.native_timely,row.status='LITERAL_NATIVE_RETURN_UNTIMELY_NO_ADMISSION';end
            catch problem,row.failure=failed(problem);row.status='UNASSESSED_LITERAL_RETURN_SUPPLEMENT';end
        end
        audit.rows{at}=row;audit.all_original_columns(c)=columnSummary(row,audit.all_original_columns(c));
        audit.cursor=at+1;audit.completed=audit.cursor==180;owned=savePrefix(cp,writing,audit,owned,finish);
        fprintf('PK15_P1_LITERAL_POINT %s\n',jsonencode(thin(row)));clear row x q p physical flow fo
    end
    verify(pins);audit.source_posthash=true;
catch problem,failure=failed(problem);end
owned=savePrefix(cp,writing,audit,owned,finish);verify(pins);check(finish);
if audit.completed
    assert(audit.source_posthash&&~isfile(file),'PKP1Literal:FreshFinal');javaMethod('move','java.nio.file.Files',java.io.File(cp).toPath(),java.io.File(file).toPath(),javaArray('java.nio.file.CopyOption',0));out=reference(file);status='COMPLETE_LITERAL_AUDIT_NO_ADMISSIONS';
else,out=reference(cp);end
result=struct('completed',audit.completed,'cursor',audit.cursor,'processed_columns',audit.cursor-1,'remaining_columns',180-audit.cursor, ...
    'map_services_this_call',services,'map_calls_invoked',audit.map_calls_invoked,'map_calls_returned',audit.map_calls_returned, ...
    'status',status,'audit_reference',out,'source_posthash',audit.source_posthash,'root_calls',0,'native_admissions',0, ...
    'retained_literal_initial_invalid_columns',712,'nearby_counterpart_absence_claimed',false,'new_P_edges',0,'new_M_relations',0, ...
    'return_timely',left(finish)>0,'own_process_exit_claimed',false,'failure',failure);
fprintf('PK15_P1_LITERAL_RETURN %s\n',jsonencode(result));
end
function p=newReplayProfile(recorded,e)
p=recorded;assert(isstruct(p.ODEOptions)&&isscalar(p.ODEOptions),'PKP1Literal:RecordedODEOptions');
solver=p.ODESolver;
if isstruct(solver)
    assert(isscalar(solver)&&strcmp(solver.diagnostic_kind,'runtime-function-descriptor')&&strcmp(solver.signature,'ode45') ...
        &&isequal(solver.requires_runtime_reconstruction,true),'PKP1Literal:KnownODE45');
else,assert(isa(solver,'function_handle')&&isequal(solver,@ode45),'PKP1Literal:KnownODE45');end
p.ODESolver=@ode45;p.RelTol=e.RelTol;p.AbsTol=e.AbsTol;p.MaxStep=e.MaxStep;
% This is an explicitly NEW callback, never execution of the saved descriptor.
p.ODEOptions=odeset(p.ODEOptions,'OutputFcn',[]);
end
function c=compare(row,p1,s)
x=row.literal_state;mi=row.map_info;raw=mi.raw_return_state;next=row.canonical_return_state;at=row.original_column;
scale=max([ones(13,1),abs(x(2:14)),abs(raw(2:14))],[],2);d=raw(2:14)-x(2:14);
c=struct('raw_full13_delta',d,'raw_full13_inf',norm(d,inf),'raw_full13_scaled_inf',norm(d./scale,inf), ...
    'canonical_full13_delta',next(2:14)-x(2:14),'actual_full_stride',mi.stride_displacement, ...
    'actual_stride_matches_raw_difference',isequaln(mi.stride_displacement,raw-x),'mode_closed',mi.discrete_closed, ...
    'native_map_conditions',mi.success&&mi.valid&&mi.integration_success&&mi.return_policy_accepted&&mi.cycle_complete&&mi.admissible, ...
    'literal_raw13_closed',false,'closure_criterion','scaled-inf raw13 <= 1e-8, native mode/map conditions and timely return; candidate only, not an unscaled all-nine admission', ...
    'actual_period',mi.period,'scheduled_period',p1.regulated_legacy_timings(9,at), ...
    'period_delta',mi.period-p1.regulated_legacy_timings(9,at),'period_tolerance',1e-10*max([1,abs(mi.period),abs(p1.regulated_legacy_timings(9,at))]), ...
    'scheduled_signed_stride_available',p1.scheduled_mean_available(at),'scheduled_signed_stride_delta',NaN, ...
    'full_scheduled_stride_comparison','UNASSESSED_REFERENCE_STORES_ONLY_SIGNED_X_STRIDE', ...
    'physical_event_counts',zeros(8,1),'native_physical_event_times',NaN(8,1),'scheduled_physical_event_times',NaN(8,1), ...
    'physical_event_time_delta',NaN(8,1),'physical_event_time_tolerance',1e-8*max(1,abs(p1.regulated_legacy_timings(9,at))), ...
    'one_each_of_eight_physical_events',false,'all_eight_event_times_match',false,'source_energy',p1.mechanical_energy(at), ...
    'initial_energy',QuadrupedEnergy_v3.evaluate(x,row.literal_mode,row.physical_parameter),'source_parameter_exact',isequaln(row.physical_parameter,p1.native_physical_parameter(:,at)), ...
    'raw_apex_dy',raw(s.State.dy),'autonomous_v3_admission_claimed',false);
c.literal_raw13_closed=row.native_timely&&c.raw_full13_scaled_inf<=1e-8&&c.mode_closed&&c.native_map_conditions;
if c.scheduled_signed_stride_available,c.scheduled_signed_stride_delta=mi.stride_displacement(1)-p1.scheduled_signed_stride(at);end
newIDs=LegacyEventAdapter_v3.toV3(1:8);c.scheduled_physical_event_times(newIDs)=p1.regulated_legacy_timings(1:8,at);
h=mi.event_history;for j=1:numel(h)
    id=h(j).guard_id;if isnumeric(id)&&isscalar(id)&&isfinite(id)&&id>=1&&id<=8&&id==fix(id)
        c.physical_event_counts(id)=c.physical_event_counts(id)+1;c.native_physical_event_times(id)=h(j).time-mi.initial_time;
    end
end
c.one_each_of_eight_physical_events=all(c.physical_event_counts==1);
if c.one_each_of_eight_physical_events
    c.physical_event_time_delta=c.native_physical_event_times-c.scheduled_physical_event_times;
    c.all_eight_event_times_match=all(abs(c.physical_event_time_delta)<=c.physical_event_time_tolerance);
end
end
function rows=initialSummary(p1)
prototype=struct('original_column',0,'original_geometry_eligible',false,'status','','literal_map_attempted',false, ...
    'native_returned',false,'flight_status','UNASSESSED','literal_raw13_closed',false,'nearby_counterpart_status','UNASSESSED_NOT_SEARCHED');
rows=repmat(prototype,891,1);for c=1:891,rows(c).original_column=c;rows(c).original_geometry_eligible=p1.native_initial_geometry_valid(c); ...
    rows(c).status='UNATTEMPTED_GEOMETRY_ELIGIBLE_LITERAL';if ~rows(c).original_geometry_eligible,rows(c).status='RETAINED_LITERAL_INITIAL_GEOMETRY_INVALID';end;end
end
function out=columnSummary(r,out),out.status=r.status;out.literal_map_attempted=~isempty(r.service_attempts);out.native_returned=r.map_returned;out.flight_status=member(r.flight,'status','UNASSESSED');out.literal_raw13_closed=member(r.comparisons,'literal_raw13_closed',false);end
function out=thin(r),out=struct('original_column',r.original_column,'status',r.status,'map_returned',r.map_returned,'native_timely',r.native_timely, ...
    'raw_full13_scaled_inf',member(r.comparisons,'raw_full13_scaled_inf',NaN),'period_delta',member(r.comparisons,'period_delta',NaN), ...
    'flight_status',member(r.flight,'status','UNASSESSED'),'flight_PASS',r.flight_PASS,'failure',r.failure);end
function sha=savePrefix(cp,writing,audit,previous,limit)
check(limit);assert(~isfile(writing),'PKP1Literal:Writing');if isempty(previous),assert(~isfile(cp),'PKP1Literal:FreshCheckpoint');else,assert(strcmp(RoundSHA256_v3(cp),previous),'PKP1Literal:CheckpointCAS');end
save(writing,'audit','-v7');z=load('-mat',writing,'audit');assert(isequaln(z.audit.configuration,audit.configuration)&&z.audit.source_posthash==audit.source_posthash&&z.audit.cursor==audit.cursor ...
    &&z.audit.completed==audit.completed&&isequaln(z.audit.all_original_columns,audit.all_original_columns),'PKP1Literal:Readback');
at=min(audit.cursor,179);if ~isempty(audit.rows{at})&&audit.rows{at}.map_returned
    x=audit.rows{at};y=z.audit.rows{at};assert(isequaln(x.raw_return_state,y.raw_return_state)&&isequaln(x.canonical_return_state,y.canonical_return_state) ...
        &&isequaln(x.map_info.trajectory.event_batches,y.map_info.trajectory.event_batches),'PKP1Literal:NativeReadback');end
clear z;check(limit);if ~isempty(previous),assert(strcmp(RoundSHA256_v3(cp),previous),'PKP1Literal:CheckpointCAS');end
opts=javaArray('java.nio.file.CopyOption',2);opts(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');opts(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');
javaMethod('move','java.nio.file.Files',java.io.File(writing).toPath(),java.io.File(cp).toPath(),opts);sha=RoundSHA256_v3(cp);
end
function providers(refs)
names={'RunPK15hP1Literal20261104','AuditC1P1v2Reference_v3','LegacyStateAdapter_v3','LegacyParameterAdapter_v3','LegacyEventAdapter_v3', ...
    'RecordedOrbitReplayProfile_v3','RecordedReturnPolicy_v3','PeriodicOrbitResidual_v3','PoincareMap_v3','PoincareSection_v3', ...
    'HybridSimulator_v3','Quadrupedal_Dynamics_v3','QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedAdmissibility_v3', ...
    'CheckC1PKOrbitFlights_v3','CheckC1PKFlightInterval_v3','AllFlightClearanceBounds_v3','RoundSHA256_v3'};
paths=cellfun(@(r)r.file,refs,'UniformOutput',false);for k=1:numel(names),assert(sum(strcmp(paths,which(names{k})))==1,'PKP1Literal:Provider','Pin resolved provider %s.',names{k});end
end
function verify(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&strcmp(canonical(r.file),r.file) ...
    &&(~isfield(r,'bytes')||d.bytes==r.bytes)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKP1Literal:Changed','Changed immutable input: %s.',r.file);end;end
function r=reference(f),d=dir(f);r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',d.bytes);end
function r=failed(e),r=struct('identifier',e.identifier,'message',e.message);end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function v=member(s,k,d),v=d;if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);end;end
function l=childLimit(p,seconds),assert(left(p)>seconds+1,'PKP1Literal:ChildFit');n=nowClock();l=struct('u',n.u+seconds,'m',n.m+seconds*1e9);end
function status=budgetOutput(l),check(l);status=0;end
function n=nowClock(),n=struct('u',double(java.time.Instant.now().toEpochMilli())/1000,'m',double(java.lang.System.nanoTime()));end
function v=left(l),n=nowClock();v=min(l.u-n.u,(l.m-n.m)/1e9);end
function check(l),assert(left(l)>0,'PKP1Literal:Deadline','Operation or original research deadline expired.');end
