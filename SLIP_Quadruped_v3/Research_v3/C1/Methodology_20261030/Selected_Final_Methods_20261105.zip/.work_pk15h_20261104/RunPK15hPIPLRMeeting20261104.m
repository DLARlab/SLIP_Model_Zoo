function result=RunPK15hPIPLRMeeting20261104(action,B,refs,o)
%RUNPK15HPIPLRMEETING20261104 Existing owned overlap plus actual flight data.
% Explicit case1 method successor: left-right8D+freeE, phase predictor OFF.
% acquire: one NEW experiment MAT retains the unchanged API6 audit and a
% separate meeting supplement. No historical file, P/M ledger or flag changes.
% cold: after an externally observed process exit, return existing finite
% qualification plus the six-flight overlay. The witnessed file is read-only.
assert(nargin==4&&any(strcmp(action,{'acquire','cold'}))&&B.capture.pid==feature('getpid'),'PKPIPLRMeeting:API','PIP LR meeting check failed: API.');
validateattributes(o.MaxWallSeconds,{'double'},{'real','finite','scalar','positive'});
validateattributes(o.SaveMarginSeconds,{'double'},{'real','finite','scalar','>=',60,'<',o.MaxWallSeconds/2});
n=nowClock();finish=struct('u',min(B.research_deadline_unix_seconds,n.u+o.MaxWallSeconds), ...
    'm',min(B.research_deadline_monotonic_ns,n.m+o.MaxWallSeconds*1e9));
work=struct('u',finish.u-o.SaveMarginSeconds,'m',finish.m-o.SaveMarginSeconds*1e9);
providers(refs.SourceReferences);verify(refs.SourceReferences);check(work);
if strcmp(action,'cold'),result=cold(B,refs,o,work,finish);return;end
rkeys={'PlanReference';'CaseIndex';'MethodReference';'SourceFlightReference';'SourceReferences'};
keys={'OutputFile';'BranchFile';'CheckpointFile';'ComponentIdentity';'FlightOptions';'FineReplaySeconds';'MaxWallSeconds';'SaveMarginSeconds'};
assert(isequal(sort(fieldnames(refs)),sort(rkeys))&&isequal(sort(fieldnames(o)),sort(keys)), 'PKPIPLRMeeting:Options','PIP LR meeting check failed: Options.');
assert(isequal(refs.CaseIndex,1),'PKPIPLRMeeting:Case','This declared method successor is only for actual failed case1.');
assert(o.MaxWallSeconds<=3000&&o.SaveMarginSeconds>=120&&isequal(o.FineReplaySeconds,120), 'PKPIPLRMeeting:Caps','PIP LR meeting check failed: Caps.');
assert(isstruct(o.FlightOptions)&&isscalar(o.FlightOptions)&&~isfield(o.FlightOptions,'Limits') ...
    &&isequal(o.FlightOptions.MaxWallSeconds,60),'PKPIPLRMeeting:FlightOptions','PIP LR meeting check failed: FlightOptions.');
assert(strcmp(refs.MethodReference.sha256,'39721fd90f9db049e3931429bb84ee61030e6c190006e084ffa5c9d40860282a') ...
    &&strcmp(refs.SourceFlightReference.sha256,'fe5f8a86d0209c3eae59234a9036aa332d273bc5935f0f5dccb47c7f43f830e3') ...
    &&strcmp(refs.PlanReference.sha256,'e160942be27a642483759cca821801d1d9ac044c6fedb10686459e5b7c409dd9'), 'PKPIPLRMeeting:Authorities','PIP LR meeting check failed: Authorities.');
pins=[refs.SourceReferences;{refs.PlanReference;refs.MethodReference;refs.SourceFlightReference}];verify(pins);
file=canonical(o.OutputFile);writing=[file,'.meeting-writing.mat'];
assert(startsWith(file,[V3Root_v3(),filesep])&&endsWith(file,'.mat')&&~isfile(file)&&~isfolder(file)&&~isfile(writing), 'PKPIPLRMeeting:Fresh','PIP LR meeting check failed: Fresh.');
z=load('-mat',refs.MethodReference.file,'plan');template=z.plan.association.overlap_options;clear z
assert(template.MaxWallSeconds==1800&&template.SaveMarginSeconds==60&&template.FineSeconds==120 ...
    &&template.RunOptions.MaxWallSeconds==360&&template.RunOptions.SaveMarginSeconds==60 ...
    &&template.RunOptions.TrialSeconds==180&&template.RunOptions.PhaseSeconds==30 ...
    &&template.RunOptions.IntegrationMaxStep==.001&&template.RunOptions.MinimumApexHeightRatio==.5 ...
    &&template.RunOptions.CaptureRadius==.02&&template.RunOptions.MaximumCorrectionStepRatio==.5 ...
    &&template.RunOptions.MaximumTurnDegrees==45&&strcmp(template.RunOptions.Algorithm,'root-newton') ...
    &&strcmp(template.Symmetry,'pronk')&&template.RunOptions.UsePhasePredictor&&~template.RunOptions.InPlace ...
    &&~isfield(template.RunOptions,'Budget')&&~isfield(template.RunOptions,'SourceContext'), 'PKPIPLRMeeting:MethodBasis','PIP LR meeting check failed: MethodBasis.');
assert(left(work)>1800+2*60+4*(o.FineReplaySeconds+60)+30, 'PKPIPLRMeeting:WholeFit','PIP LR meeting check failed: WholeFit.');
z=load('-mat',refs.PlanReference.file,'plan');plan=z.plan;clear z
assert(strcmp(plan.schema,'PK15h-saved-PK-daughter-owned-PAL-proposals-v1')&&plan.completed&&plan.source_posthash ...
    &&plan.new_P_edges==0&&plan.new_M_relations==0&&plan.PIP_parent_attachments_created==0&&numel(plan.targets)==4 ...
    &&strcmp(plan.references.StageBReference.sha256,'f2eb5682a9e963b01c9b0c7075bbc3d9f360c13d68bd72b84606c8365c881876') ...
    &&strcmp(plan.references.BulkReference.sha256,refs.SourceFlightReference.sha256),'PKPIPLRMeeting:Plan','PIP LR meeting check failed: Plan.');
verify(plan.references.SourceReferences);verify({plan.references.GraphReference;plan.references.BulkReference;plan.references.StageBReference});
t=plan.targets{refs.CaseIndex};assert(t.saved_target_and_conditional_flight_PASS&&t.catalog_index==refs.CaseIndex ...
    &&t.StageB_row==refs.CaseIndex+2&&~isempty(t.prospective_proposals),'PKPIPLRMeeting:PlannedTarget','PIP LR meeting check failed: PlannedTarget.');
proposal=t.prospective_proposals{1};sourceRef=proposal.source_reference;pair=proposal.source_pair(:).';targetRef=proposal.target_reference;targetIndex=proposal.target_index;
assert(proposal.prospective_only&&~proposal.target_is_root_seed&&proposal.both_literal_endpoints_bulk_PASS ...
    &&targetIndex==refs.CaseIndex&&strcmp(targetRef.file,plan.catalog_reference.file)&&strcmp(targetRef.sha256,plan.catalog_reference.sha256) ...
    &&strcmp(proposal.target_native_ID,t.native_ID),'PKPIPLRMeeting:LiteralSelectors','PIP LR meeting check failed: LiteralSelectors.');
assert(isequal(pair,[355,354])&&strcmp(sourceRef.sha256,'2ca5aa4a2e64ac80f2d2bb95d17379857bc38661a5f13a0bd0d63d34c0b06962') ...
    &&t.b==.02&&t.origin==1,'PKPIPLRMeeting:NoSelectorChange','Preserve the actual case1 best source and original short positive target.');
pins=[pins;{sourceRef;targetRef};plan.references.SourceReferences;{plan.references.GraphReference;plan.references.StageBReference}];verify(pins);
ix=BranchSolutionFile_v3.index(sourceRef.file);
[sources,sourceReports,metadata]=BranchSolutionFile_v3.loadSolutions(sourceRef.file,pair);
[targets,targetReports]=BranchSolutionFile_v3.loadSolutions(targetRef.file,targetIndex);target=targets{1};targetReport=targetReports{1};
forward=metadata{2}.edge_enabled&&isequal(metadata{2}.edge_from,pair(1));
reverse=metadata{1}.edge_enabled&&isequal(metadata{1}.edge_from,pair(2));
assert(xor(forward,reverse)&&strcmp(metadata{1}.component_identity,metadata{2}.component_identity), 'PKPIPLRMeeting:OwnedSourcePair','PIP LR meeting check failed: OwnedSourcePair.');
orientation=pair;if reverse,orientation=fliplr(pair);end
edge=find(cellfun(@(e)e.from==orientation(1)&&e.to==orientation(2),ix.edges));
assert(isscalar(edge)&&strcmp(ix.edges{edge}.component_identity,metadata{1}.component_identity) ...
    &&isequal(orientation,proposal.actual_stored_edge_orientation)&&strcmp(metadata{1}.component_identity,proposal.source_owner), 'PKPIPLRMeeting:OwnedSourceEdge','PIP LR meeting check failed: OwnedSourceEdge.');
sourceIDs=cellfun(@OrbitContentIdentity_v3,sources,'UniformOutput',false);
assert(isequaln(sourceIDs(:),proposal.source_native_ids(:))&&strcmp(OrbitContentIdentity_v3(target),t.native_ID),'PKPIPLRMeeting:NativeSelectors','PIP LR meeting check failed: NativeSelectors.');
sourceOwners=cell(2,1);for k=1:2,[~,sourceOwners{k}]=RecordedOrbitReplayProfile_v3(sources{k},sourceReports{k});assert(sourceOwners{k}.complete,'PKPIPLRMeeting:SourceOwner','PIP LR meeting check failed: SourceOwner.');end
[~,targetOwner]=RecordedOrbitReplayProfile_v3(target,targetReport);assert(targetOwner.complete,'PKPIPLRMeeting:TargetOwner','PIP LR meeting check failed: TargetOwner.');
sourceFlights=sourceFlightEvidence(refs.SourceFlightReference,sourceRef,pair,sourceIDs);
sourceChart=sourceChartEvidence(sources,sourceReports,sourceIDs,target);
assert(isequaln(sources{1}.parameter,sources{2}.parameter)&&isequaln(sources{2}.parameter,target.parameter) ...
    &&isequaln(sources{1}.initial_mode,sources{2}.initial_mode)&&isequaln(sources{2}.initial_mode,target.initial_mode),'PKPIPLRMeeting:LiteralPQ','PIP LR meeting check failed: LiteralPQ.');
baseline=struct('current_target_ID',t.native_ID,'target_period',target.period,'target_stride',target.stride_displacement, ...
    'StageB_row',t.StageB_row,'origin',t.origin,'b',t.b,'target_owner',targetOwner);
request=struct('plan_reference',refs.PlanReference,'case_index',refs.CaseIndex,'best_proposal',proposal, ...
    'source_reference',sourceRef,'source_pair',pair,'target_reference',targetRef,'target_index',targetIndex, ...
    'screen_geometry_is_prospective_only',true,'screen_geometry_passed_to_API6',false,'actual_geometry_owner','unchanged API6 recomputes the declared left-right8D plane, signed ds and InitialStep from literal native records', ...
    'declared_method_delta',struct('basis_reference',refs.MethodReference,'basis_symmetry','pronk','new_symmetry','left-right', ...
    'basis_UsePhasePredictor',true,'new_UsePhasePredictor',false,'donor_name','RunPK15hPIPMeeting20261104', ...
    'only_two_method_deltas_relative_to_e0',true,'existing_e0_run_overrides_retained',{{'MaximumStep=.08','MaxAccepted=1','MaxAttempts=1','ReusePreviousJacobian=false','fresh owner/checkpoint/outputs'}}, ...
    'reason','Actual prior case1 had zero Root attempts and C1Continuation:BaseRoundtrip in the restricted pronk chart. LR8+E9 retains the raw pitch/fore-hind coordinates; no projection or selector change.', ...
    'all_other_e0_numeric_capture_fine_physics_options_unchanged',true));
clear plan t ix sources sourceReports metadata targets targetReports target targetReport;verify(pins);
options=template;options.OutputFile=file;options.BranchFile=canonical(o.BranchFile);options.CheckpointFile=canonical(o.CheckpointFile);
options.SourceAuditReference=struct('file',refs.PlanReference.file,'sha256',refs.PlanReference.sha256);run=template.RunOptions;run.MaximumStep=.08;
% Explicit reviewed method successor. All other original397 settings stay put.
options.Symmetry='left-right';run.UsePhasePredictor=false;
run.ComponentIdentity=o.ComponentIdentity;run.CheckpointFile=options.CheckpointFile;run.MaxAccepted=1;run.MaxAttempts=1;run.ReusePreviousJacobian=false;
options.RunOptions=run;
meeting=struct('schema','PK15h-PIP-target-owned-meeting-flight-overlay-v1','configuration',struct('references',refs,'options',o), ...
    'request',request,'original_budget',B,'operation_finish',finish,'operation_work',work,'source_pair',pair, ...
    'actual_source_edge_orientation',orientation,'source_replay_owners',{sourceOwners},'source_conditional_flight_evidence',sourceFlights,'source_chart_evidence',sourceChart, ...
    'source_anchors_conditional_flight_PASS',true,'current_target_baseline',baseline, ...
    'acquire_invoked',true,'acquire_returned',false,'pre_supplement_acquisition_reference',struct(),'original_API6_flags',struct(), ...
    'endpoint_rows',{cell(2,1)},'fine_rows',{cell(2,2)},'completed',false,'source_posthash',false, ...
    'six_current_flight_checks_PASS',false,'current_M_eligible',false,'cold_qualification_performed',false, ...
    'new_M_relations',0,'extra_root_calls',0,'historical_flags_changed',false,'original_fine_flags_changed',false, ...
    'ordinary_P_current_flight_status','PROVISIONAL_UNTIL_SIX_CURRENT_FLIGHT_CHECKS_PASS', ...
    'status','ACQUIRE_INVOKED','failure',struct(), ...
    'scope','Finite owned numerical meeting only. Existing API6 may earn its P before this overlay; failed or unassessed flight supplements confer no current physical eligibility or M. Cold qualification needs an external actual process-exit witness. No PIP-parent attachment follows.');
apiSource=struct('file',sourceRef.file,'sha256',sourceRef.sha256);apiTarget=struct('file',targetRef.file,'sha256',targetRef.sha256);
% Planner numbers are not transported: API6 recomputes the actual LR8D plane.
audit=AcquireC1NumericalOverlap_v3(apiSource,pair,apiTarget,targetIndex,B,options);
meeting.acquire_returned=true;meeting.original_API6_flags=flags(audit);meeting.pre_supplement_acquisition_reference=reference(file);owned=meeting.pre_supplement_acquisition_reference.sha256;
owned=saveOwned(file,writing,audit,meeting,owned,finish);
try
    assert(audit.completed&&audit.source_posthash&&audit.ordinary_edge_earned&&audit.qualified_numerical_relation ...
        &&audit.fine_calls_returned==4&&isequal(audit.source_edge_orientation,orientation), 'PKPIPLRMeeting:AcquireNotQualified','PIP LR meeting check failed: AcquireNotQualified.');
    records={audit.candidate_orbit;audit.target_orbit};reports={audit.candidate_report;audit.target_report};
    assert(strcmp(OrbitContentIdentity_v3(records{2}),baseline.current_target_ID), 'PKPIPLRMeeting:TargetNativeID','PIP LR meeting check failed: TargetNativeID.');
    for side=1:2
        row=struct('native_ID',OrbitContentIdentity_v3(records{side}),'profile_owner',struct(), ...
            'flight',struct(),'PASS',false,'status','UNASSESSED','failure',struct());
        try
            [profile,row.profile_owner]=RecordedOrbitReplayProfile_v3(records{side},reports{side});
            assert(row.profile_owner.complete,'PKPIPLRMeeting:EndpointReplayOwner','PIP LR meeting check failed: EndpointReplayOwner.');
            fo=flightOptions(o.FlightOptions,profile.EventTimeTolerance,work);
            row.flight=CheckC1PKOrbitFlights_v3(records{side},records{side}.parameter,fo);
            row.PASS=strcmp(row.flight.status,'PASS')&&row.flight.return_timely;row.status=row.flight.status;
        catch problem,row.failure=failed(problem);end
        meeting.endpoint_rows{side}=row;owned=saveOwned(file,writing,audit,meeting,owned,finish);
    end
    steps=[.0005,.00025];
    for side=1:2
        for level=1:2
            assert(left(work)>o.FineReplaySeconds+60+10,'PKPIPLRMeeting:FineFit','PIP LR meeting check failed: FineFit.');
            original=records{side};r=reports{side};prior=audit.fines{side,level};
            [policy,pe]=RecordedReturnPolicy_v3(r);assert(pe.complete&&isa(policy,'ReturnPolicyBase_v3'),'PKPIPLRMeeting:FinePolicy','PIP LR meeting check failed: FinePolicy.');
            simulator=HybridSimulator_v3(struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001));
            integration=simulator.Options;integration.RelTol=1e-12;integration.AbsTol=1e-14;integration.MaxStep=steps(level);
            child=childLimit(work,o.FineReplaySeconds);integration.ODEOptions=odeset(integration.ODEOptions,'OutputFcn',@(~,~,~)budgetOutput(child));
            limits=struct('MaxReturnTime',r.options.MaxReturnTime,'MaxCycleEvents',r.options.MaxCycleEvents,'MaxSectionCrossings',r.options.MaxSectionCrossings);
            s=QuadrupedSchema_v3.shared();map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(integration),policy,limits);
            row=struct('side',side,'level',level,'MaxStep',steps(level),'source_native_ID',OrbitContentIdentity_v3(original), ...
                'integration',integration,'policy_configuration',pe.configuration,'map_limits',limits,'map_invoked',true,'map_returned',false, ...
                'native_timely',false,'canonical_return_state',[],'raw_return_state',[],'map_info',struct(),'native_result_saved_before_check',false, ...
                'original_fine_comparison',struct(),'flight',struct(),'PASS',false,'status','MAP_INVOKED','failure',struct());
            meeting.fine_rows{side,level}=row;owned=saveOwned(file,writing,audit,meeting,owned,finish);
            try
                [next,info]=map.evaluate(original.initial_state,original.initial_mode,original.parameter);
                row.map_returned=true;row.canonical_return_state=next;row.raw_return_state=info.raw_return_state;row.map_info=info;row.native_timely=left(child)>0&&left(work)>0;
                meeting.fine_rows{side,level}=row;owned=saveOwned(file,writing,audit,meeting,owned,finish);
                row.native_result_saved_before_check=true;
                row.original_fine_comparison=fineComparison(next,info,original,prior);
                fo=flightOptions(o.FlightOptions,integration.EventTimeTolerance,work);
                row.flight=CheckC1PKOrbitFlights_v3(info,original.parameter,fo);
                row.PASS=row.native_timely&&row.original_fine_comparison.passed&&strcmp(row.flight.status,'PASS')&&row.flight.return_timely;
                row.status=row.flight.status;if ~row.original_fine_comparison.passed,row.status='ORIGINAL_FINE_CORRESPONDENCE_NOT_MET';end
            catch problem,row.failure=failed(problem);row.status='UNASSESSED_NATIVE_OR_CHECK_EXCEPTION';end
            meeting.fine_rows{side,level}=row;owned=saveOwned(file,writing,audit,meeting,owned,finish);
            fprintf('PK15_PIP_LR_MEETING_FINE %s\n',jsonencode(thinFine(row)));
            clear original r policy simulator integration map next info fo row
        end
    end
    meeting.six_current_flight_checks_PASS=all(cellfun(@(r)r.PASS,meeting.endpoint_rows))&&all(cellfun(@(r)r.PASS,meeting.fine_rows(:)));
    meeting.ordinary_P_current_flight_status='UNASSESSED_OR_FAILED_CURRENT_FLIGHT_OVERLAY';
    if meeting.six_current_flight_checks_PASS,meeting.ordinary_P_current_flight_status='SIX_CURRENT_CONDITIONAL_FLIGHT_CHECKS_PASS';end
    meeting.completed=true;meeting.status='SUPPLEMENTS_COMPLETE_AWAIT_EXTERNAL_EXIT_AND_COLD_QUALIFICATION';
catch problem,meeting.failure=failed(problem);meeting.status='INCOMPLETE_OR_UNQUALIFIED_NO_CURRENT_M';end
verify(pins);meeting.source_posthash=true;owned=saveOwned(file,writing,audit,meeting,owned,finish);
result=struct('completed',meeting.completed,'source_posthash',meeting.source_posthash,'status',meeting.status, ...
    'original_API6_flags',meeting.original_API6_flags,'six_current_flight_checks_PASS',meeting.six_current_flight_checks_PASS, ...
    'current_M_eligible',false,'new_M_relations',0,'extra_root_calls',0,'audit_reference',reference(file), ...
    'own_process_exit_claimed',false,'return_timely',left(finish)>0,'failure',meeting.failure);
fprintf('PK15_PIP_LR_MEETING_RETURN %s\n',jsonencode(result));
end

function result=cold(B,refs,o,work,finish)
assert(isequal(sort(fieldnames(refs)),sort({'ExperimentReference';'SourceReferences'})) ...
    &&isequal(sort(fieldnames(o)),sort({'ExecutionWitness';'MaxWallSeconds';'SaveMarginSeconds'})) ...
    &&o.MaxWallSeconds<=900,'PKPIPLRMeeting:ColdOptions','PIP LR meeting check failed: ColdOptions.');
verify({refs.ExperimentReference});z=load('-mat',refs.ExperimentReference.file,'audit','meeting');a=z.audit;m=z.meeting;clear z
assert(strcmp(m.schema,'PK15h-PIP-target-owned-meeting-flight-overlay-v1')&&m.completed&&m.source_posthash ...
    &&m.six_current_flight_checks_PASS&&~m.current_M_eligible&&~m.cold_qualification_performed ...
    &&~m.historical_flags_changed&&~m.original_fine_flags_changed&&m.new_M_relations==0&&m.extra_root_calls==0, 'PKPIPLRMeeting:ColdOverlay','PIP LR meeting check failed: ColdOverlay.');
verify(m.configuration.references.SourceReferences);verify({m.configuration.references.PlanReference;m.configuration.references.MethodReference;m.configuration.references.SourceFlightReference;m.request.source_reference;m.request.target_reference});
assert(m.source_anchors_conditional_flight_PASS&&m.source_conditional_flight_evidence.complete,'PKPIPLRMeeting:ColdSourceFlight','PIP LR meeting check failed: ColdSourceFlight.');
assert(isequaln(flags(a),m.original_API6_flags)&&all(cellfun(@(r)r.PASS&&strcmp(r.flight.status,'PASS')&&r.flight.return_timely,m.endpoint_rows)) ...
    &&all(cellfun(@(r)r.PASS&&r.map_returned&&r.native_result_saved_before_check&&r.original_fine_comparison.passed ...
    &&strcmp(r.flight.status,'PASS')&&r.flight.return_timely,m.fine_rows(:))), 'PKPIPLRMeeting:RetainedOverlay','PIP LR meeting check failed: RetainedOverlay.');
leftSelector=struct('file',a.run_branch_reference.file,'sha256',a.run_branch_reference.sha256,'index',3,'native_ID',a.candidate_native_id);
rightSelector=struct('file',a.target_reference.file,'sha256',a.target_reference.sha256,'index',a.target_index,'native_ID',a.target_native_id);
proof=struct('schema','C1-finite-owned-PAL-numerical-overlap-proof-v1','audit_reference',refs.ExperimentReference, ...
    'execution_witness',o.ExecutionWitness,'left_selector',leftSelector,'right_selector',rightSelector, ...
    'validation_limits',struct('deadline_unix_seconds',work.u,'deadline_monotonic_ns',work.m));
e=C1FiniteNumericalOverlap_v3.qualify(a.candidate_orbit,a.target_orbit,a.candidate_report,a.target_report,proof);
verify(refs.SourceReferences);verify({refs.ExperimentReference});check(finish);
result=struct('schema','PK15h-cold-PIP-target-meeting-flight-eligibility-v1','current_M_eligible',e.qualified&&m.six_current_flight_checks_PASS, ...
    'finite_numerical_overlap',e,'whole_flight_experiment_reference',refs.ExperimentReference,'six_current_flight_checks_PASS',true, ...
    'new_M_relations',0,'new_P_edges_by_this_cold_call',0,'extra_root_calls',0,'source_posthash',true, ...
    'current_budget',B,'own_process_exit_claimed',false,'return_timely',left(finish)>0, ...
    'scope','Eligibility for a finite current numerical association only. No Manager mutation, M append, exact identity, global branch or P1-equivalence claim.');
end
function c=fineComparison(next,info,original,prior)
f=prior.fine;oldRaw=prior.evidence.trajectory.state(end,:).';raw=info.raw_return_state;
scale=max([ones(14,1),abs(next(:)),abs(f.return_state(:))],[],2);
rawScale=max([ones(14,1),abs(raw(:)),abs(oldRaw(:))],[],2);
ss=max([ones(size(info.stride_displacement)),abs(info.stride_displacement),abs(f.stride_displacement)],[],2);
c=struct('original_fine_qualified',prior.qualified,'literal_initial_state_exact',isequaln(info.initial_state,original.initial_state), ...
    'literal_initial_mode_exact',isequaln(info.initial_mode,original.initial_mode),'canonical_return_bitwise_equal',isequaln(next,f.return_state), ...
    'canonical_return_scaled_inf',norm((next(:)-f.return_state(:))./scale,inf),'raw_return_bitwise_equal',isequaln(raw,oldRaw), ...
    'raw_return_scaled_inf',norm((raw(:)-oldRaw(:))./rawScale,inf),'period_delta',info.period-f.period, ...
    'period_tolerance',1e-10*max([1,abs(info.period),abs(f.period)]),'stride_delta',info.stride_displacement-f.stride_displacement, ...
    'stride_tolerance',1e-10*ss,'mode_closed',info.discrete_closed,'event_signature_equal',isequaln(info.section_relative_event_signature,f.event_signature), ...
    'native_map_conditions',info.success&&info.valid&&info.integration_success&&info.return_policy_accepted&&info.cycle_complete&&info.admissible,'passed',false);
c.passed=c.original_fine_qualified&&c.literal_initial_state_exact&&c.literal_initial_mode_exact&&c.canonical_return_scaled_inf<=1e-10&&c.raw_return_scaled_inf<=1e-10 ...
    &&abs(c.period_delta)<=c.period_tolerance&&all(abs(c.stride_delta)<=c.stride_tolerance)&&c.mode_closed&&c.event_signature_equal&&c.native_map_conditions;
end
function e=sourceFlightEvidence(ref,source,pair,ids)
z=load('-mat',ref.file,'audit');a=z.audit;clear z
assert(strcmp(a.schema,'PK15h-literal-stored-orbit-flight-audit-v1')&&a.completed&&a.source_posthash ...
    &&numel(a.rows)==1118&&a.new_admissions==0&&a.new_P_edges==0&&a.new_M_relations==0,'PKPIPLRMeeting:BulkFlight','PIP LR meeting check failed: BulkFlight.');
g=find(cellfun(@(g)strcmp(g.source_reference.file,source.file)&&strcmp(g.source_reference.sha256,source.sha256),a.groups));
assert(isscalar(g)&&a.groups{g}.prehash_verified&&a.groups{g}.posthash_verified,'PKPIPLRMeeting:BulkSourcePosthash','PIP LR meeting check failed: BulkSourcePosthash.');
rows=cell(2,1);for k=1:2
    at=find(cellfun(@(r)strcmp(r.source_reference.file,source.file)&&strcmp(r.source_reference.sha256,source.sha256)&&r.source_index==pair(k),a.rows));
    assert(isscalar(at),'PKPIPLRMeeting:BulkSelector','PIP LR meeting check failed: BulkSelector.');r=a.rows{at};
    assert(strcmp(r.native_ID,ids{k})&&strcmp(r.actual_native_ID,ids{k})&&strcmp(r.status,'PASS')&&r.return_timely ...
        &&strcmp(r.checker_status,'PASS')&&r.checker_return_timely&&r.trajectory_profile_owner.complete,'PKPIPLRMeeting:BulkParentFlight','PIP LR meeting check failed: BulkParentFlight.');rows{k}=r;
end
e=struct('reference',ref,'complete',true,'source_group',a.groups{g},'rows',{rows}, ...
    'scope','Existing literal saved-trajectory conditional flight PASS only. No fresh all-nine admission, edge or M is transferred from this bulk overlay.');
end
function fo=flightOptions(fo,tol,work),assert(left(work)>fo.MaxWallSeconds+2,'PKPIPLRMeeting:FlightFit','PIP LR meeting check failed: FlightFit.');fo.EventTimeTolerance=tol;fo.Limits=struct('deadline_unix_seconds',work.u,'deadline_monotonic_ns',work.m);end
function out=flags(a),out=struct('completed',a.completed,'source_posthash',a.source_posthash,'ordinary_edge_earned',a.ordinary_edge_earned,'qualified_numerical_relation',a.qualified_numerical_relation,'fine_calls_attempted',a.fine_calls_attempted,'fine_calls_returned',a.fine_calls_returned,'status',a.status);end
function out=thinFine(r),out=struct('side',r.side,'level',r.level,'status',r.status,'map_returned',r.map_returned,'native_timely',r.native_timely,'PASS',r.PASS,'original_fine_comparison',r.original_fine_comparison,'failure',r.failure);end
function owned=saveOwned(file,writing,audit,meeting,previous,limit)
check(limit);assert(~isfile(writing)&&strcmp(RoundSHA256_v3(file),previous),'PKPIPLRMeeting:OwnedCAS','PIP LR meeting check failed: OwnedCAS.');
save(writing,'audit','meeting','-v7');checkSaved(writing,audit,meeting);check(limit);
assert(strcmp(RoundSHA256_v3(file),previous),'PKPIPLRMeeting:OwnedCAS','PIP LR meeting check failed: OwnedCAS.');
opts=javaArray('java.nio.file.CopyOption',2);opts(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');opts(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');
javaMethod('move','java.nio.file.Files',java.io.File(writing).toPath(),java.io.File(file).toPath(),opts);owned=RoundSHA256_v3(file);
end
function checkSaved(file,a,m)
z=load('-mat',file,'audit','meeting');assert(isequaln(flags(z.audit),flags(a))&&isequaln(z.meeting.original_API6_flags,m.original_API6_flags) ...
    &&isequaln(z.meeting.six_current_flight_checks_PASS,m.six_current_flight_checks_PASS)&&isequaln(z.meeting.status,m.status), 'PKPIPLRMeeting:Readback','PIP LR meeting check failed: Readback.');
if ~isempty(a.candidate_orbit),assert(strcmp(OrbitContentIdentity_v3(z.audit.candidate_orbit),OrbitContentIdentity_v3(a.candidate_orbit)),'PKPIPLRMeeting:ReadbackID','PIP LR meeting check failed: ReadbackID.');end
for k=1:numel(m.fine_rows),if ~isempty(m.fine_rows{k})&&m.fine_rows{k}.map_returned
    x=m.fine_rows{k};y=z.meeting.fine_rows{k};assert(isequaln(x.raw_return_state,y.raw_return_state)&&isequaln(x.canonical_return_state,y.canonical_return_state) ...
        &&isequaln(x.map_info.trajectory.event_batches,y.map_info.trajectory.event_batches) ...
        &&isequaln(thinFine(x),thinFine(y)),'PKPIPLRMeeting:FineReadback','PIP LR meeting check failed: FineReadback.');end;end
end
function e=sourceChartEvidence(orbits,reports,ids,target)
% Existing public LR chart must preserve BOTH original source raw states and
% the original target EXACTLY before any Root call. No manual retraction.
s=QuadrupedSchema_v3.shared();base=orbits{2};[policy,pe]=RecordedReturnPolicy_v3(reports{2});assert(pe.complete,'PKPIPLRMeeting:ChartPolicy','Require a complete actual source policy.');
map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(),policy);
family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,base.initial_state),base.initial_state,base.initial_mode,base.parameter,struct('Symmetry','left-right'));
assert(isequal(family.CoordinateIndices(:).',[2,3,5,6,7,8,11,12]),'PKPIPLRMeeting:LRCoordinates','Use all existing eight left/right state coordinates with free coupled E.');
records=[orbits;{target}];identities=[ids;{OrbitContentIdentity_v3(target)}];roles={'source_predecessor';'source_base';'target'};rows=cell(3,1);
for k=1:3
    x=records{k}.initial_state;u=family.packState(x);lift=family.fullState(u);
    rows{k}=struct('role',roles{k},'native_ID',identities{k},'packed_coordinates',u,'full14_pack_lift_delta',lift-x, ...
        'pack_lift_inf',norm(lift-x,inf),'pack_lift_exact',isequaln(lift,x));
    assert(rows{k}.pack_lift_exact,'PKPIPLRMeeting:ExactLRRoundtrip','The existing LR chart must lift each literal source/target unchanged; no Root or automatic fallback is permitted.');
    assert(strcmp(OrbitContentIdentity_v3(records{k}),identities{k}),'PKPIPLRMeeting:SourceMutation','Literal native records changed during a read-only chart check.');
end
e=struct('symmetry','left-right','coordinate_indices',family.CoordinateIndices,'source_and_target_rows',{rows}, ...
    'root_unknown_count',9,'state_unknown_count',8,'free_coupled_energy_unknown',true,'exact_original_roundtrips_verified',true, ...
    'existing_public_constructor_checks_passed',true,'NEW_restricted_root_hypothesis',true,'source_states_overwritten',false, ...
    'original_source_admission_transferred_to_restricted_root',false,'map_evaluations',0, ...
    'scope','All literal source and target states roundtrip exactly in the existing LR chart. Fresh admission/capture of the NEW nine-unknown coupled root remains mandatory.');
end
function providers(refs)
assert(iscell(refs)&&iscolumn(refs),'PKPIPLRMeeting:References','PIP LR meeting check failed: References.');
names={'RunPK15hPIPLRMeeting20261104','RunPK15hPIPMeeting20261104','RunPK15hCurrentMeeting20261104','PreparePK15hPIPTargets20261104','AcquireC1NumericalOverlap_v3','C1FiniteNumericalOverlap_v3','C1PlainFineQualificationReplay_v3', ...
    'RecordedOrbitReplayProfile_v3','RecordedReturnPolicy_v3','CheckC1PKOrbitFlights_v3','CheckC1PKFlightInterval_v3','AllFlightClearanceBounds_v3', ...
    'RunC1Continuation_v3','PeriodicSolutionSolver_v3','PeriodicOrbitResidual_v3','CompactResearchBranch_v3','ValidateStoredPeriodicOrbit_v3','AuditPK15hStoredFlights20261104', ...
    'BranchSolutionFile_v3','OrbitContentIdentity_v3','PoincareMap_v3','HybridSimulator_v3','EventDetector_v3','Quadrupedal_Dynamics_v3', ...
    'EnergyFamilyResidual_v3','QuadrupedPhysicalChart_v3','QuadrupedSchema_v3','RoundSHA256_v3'};
paths=cellfun(@(r)r.file,refs,'UniformOutput',false);for k=1:numel(names),assert(sum(strcmp(paths,which(names{k})))==1,'PKPIPLRMeeting:Provider','Pin resolved provider %s.',names{k});end
assert(nargin('AcquireC1NumericalOverlap_v3')==6,'PKPIPLRMeeting:PublicAPI','PIP LR meeting check failed: PublicAPI.');
end
function verify(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(strcmp(canonical(r.file),r.file)&&isscalar(d)&&~d.isdir ...
    &&(~isfield(r,'bytes')||d.bytes==r.bytes)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKPIPLRMeeting:Changed','Changed input: %s.',r.file);end;end
function l=childLimit(parent,seconds),n=nowClock();l=struct('u',min(parent.u,n.u+seconds),'m',min(parent.m,n.m+seconds*1e9));end
function status=budgetOutput(l),check(l);status=0;end
function r=reference(f),d=dir(f);r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',d.bytes);end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function r=failed(e),r=struct('identifier',e.identifier,'message',e.message);end
function n=nowClock(),n=struct('u',double(java.time.Instant.now().toEpochMilli())/1000,'m',double(java.lang.System.nanoTime()));end
function v=left(l),n=nowClock();v=min(l.u-n.u,(l.m-n.m)/1e9);end
function check(l),assert(left(l)>0,'PKPIPLRMeeting:Deadline','Current operation or original research deadline expired.');end
