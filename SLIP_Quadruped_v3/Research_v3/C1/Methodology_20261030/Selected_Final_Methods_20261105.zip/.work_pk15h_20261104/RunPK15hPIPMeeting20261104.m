function result=RunPK15hPIPMeeting20261104(action,B,refs,o)
%RUNPK15HPIPMEETING20261104 Existing owned overlap plus actual flight data.
% acquire: one NEW experiment MAT retains the unchanged API6 audit and a
% separate meeting supplement. No historical file, P/M ledger or flag changes.
% cold: after an externally observed process exit, return existing finite
% qualification plus the six-flight overlay. The witnessed file is read-only.
assert(nargin==4&&any(strcmp(action,{'acquire','cold'}))&&B.capture.pid==feature('getpid'),'PKPIPMeeting:API');
validateattributes(o.MaxWallSeconds,{'double'},{'real','finite','scalar','positive'});
validateattributes(o.SaveMarginSeconds,{'double'},{'real','finite','scalar','>=',60,'<',o.MaxWallSeconds/2});
n=nowClock();finish=struct('u',min(B.research_deadline_unix_seconds,n.u+o.MaxWallSeconds), ...
    'm',min(B.research_deadline_monotonic_ns,n.m+o.MaxWallSeconds*1e9));
work=struct('u',finish.u-o.SaveMarginSeconds,'m',finish.m-o.SaveMarginSeconds*1e9);
providers(refs.SourceReferences);verify(refs.SourceReferences);check(work);
if strcmp(action,'cold'),result=cold(B,refs,o,work,finish);return;end
rkeys={'PlanReference';'CaseIndex';'MethodReference';'SourceFlightReference';'SourceReferences'};
keys={'OutputFile';'BranchFile';'CheckpointFile';'ComponentIdentity';'FlightOptions';'FineReplaySeconds';'MaxWallSeconds';'SaveMarginSeconds'};
assert(isequal(sort(fieldnames(refs)),sort(rkeys))&&isequal(sort(fieldnames(o)),sort(keys)), 'PKPIPMeeting:Options');
validateattributes(refs.CaseIndex,{'double'},{'scalar','integer','>=',1,'<=',4});
assert(o.MaxWallSeconds<=3000&&o.SaveMarginSeconds>=120&&isequal(o.FineReplaySeconds,120), 'PKPIPMeeting:Caps');
assert(isstruct(o.FlightOptions)&&isscalar(o.FlightOptions)&&~isfield(o.FlightOptions,'Limits') ...
    &&isequal(o.FlightOptions.MaxWallSeconds,60),'PKPIPMeeting:FlightOptions');
assert(strcmp(refs.MethodReference.sha256,'39721fd90f9db049e3931429bb84ee61030e6c190006e084ffa5c9d40860282a') ...
    &&strcmp(refs.SourceFlightReference.sha256,'fe5f8a86d0209c3eae59234a9036aa332d273bc5935f0f5dccb47c7f43f830e3'), 'PKPIPMeeting:Authorities');
pins=[refs.SourceReferences;{refs.PlanReference;refs.MethodReference;refs.SourceFlightReference}];verify(pins);
file=canonical(o.OutputFile);writing=[file,'.meeting-writing.mat'];
assert(startsWith(file,[V3Root_v3(),filesep])&&endsWith(file,'.mat')&&~isfile(file)&&~isfolder(file)&&~isfile(writing), 'PKPIPMeeting:Fresh');
z=load('-mat',refs.MethodReference.file,'plan');template=z.plan.association.overlap_options;clear z
assert(template.MaxWallSeconds==1800&&template.SaveMarginSeconds==60&&template.FineSeconds==120 ...
    &&template.RunOptions.MaxWallSeconds==360&&template.RunOptions.SaveMarginSeconds==60 ...
    &&template.RunOptions.TrialSeconds==180&&template.RunOptions.PhaseSeconds==30 ...
    &&template.RunOptions.IntegrationMaxStep==.001&&template.RunOptions.MinimumApexHeightRatio==.5 ...
    &&template.RunOptions.CaptureRadius==.02&&template.RunOptions.MaximumCorrectionStepRatio==.5 ...
    &&template.RunOptions.MaximumTurnDegrees==45&&strcmp(template.RunOptions.Algorithm,'root-newton') ...
    &&strcmp(template.Symmetry,'pronk')&&template.RunOptions.UsePhasePredictor&&~template.RunOptions.InPlace ...
    &&~isfield(template.RunOptions,'Budget')&&~isfield(template.RunOptions,'SourceContext'), 'PKPIPMeeting:MethodBasis');
assert(left(work)>1800+2*60+4*(o.FineReplaySeconds+60)+30, 'PKPIPMeeting:WholeFit');
z=load('-mat',refs.PlanReference.file,'plan');plan=z.plan;clear z
assert(strcmp(plan.schema,'PK15h-saved-PK-daughter-owned-PAL-proposals-v1')&&plan.completed&&plan.source_posthash ...
    &&plan.new_P_edges==0&&plan.new_M_relations==0&&plan.PIP_parent_attachments_created==0&&numel(plan.targets)==4 ...
    &&strcmp(plan.references.StageBReference.sha256,'f2eb5682a9e963b01c9b0c7075bbc3d9f360c13d68bd72b84606c8365c881876') ...
    &&strcmp(plan.references.BulkReference.sha256,refs.SourceFlightReference.sha256),'PKPIPMeeting:Plan');
verify(plan.references.SourceReferences);verify({plan.references.GraphReference;plan.references.BulkReference;plan.references.StageBReference});
t=plan.targets{refs.CaseIndex};assert(t.saved_target_and_conditional_flight_PASS&&t.catalog_index==refs.CaseIndex ...
    &&t.StageB_row==refs.CaseIndex+2&&~isempty(t.prospective_proposals),'PKPIPMeeting:PlannedTarget');
proposal=t.prospective_proposals{1};sourceRef=proposal.source_reference;pair=proposal.source_pair(:).';targetRef=proposal.target_reference;targetIndex=proposal.target_index;
assert(proposal.prospective_only&&~proposal.target_is_root_seed&&proposal.both_literal_endpoints_bulk_PASS ...
    &&targetIndex==refs.CaseIndex&&strcmp(targetRef.file,plan.catalog_reference.file)&&strcmp(targetRef.sha256,plan.catalog_reference.sha256) ...
    &&strcmp(proposal.target_native_ID,t.native_ID),'PKPIPMeeting:LiteralSelectors');
pins=[pins;{sourceRef;targetRef};plan.references.SourceReferences;{plan.references.GraphReference;plan.references.StageBReference}];verify(pins);
ix=BranchSolutionFile_v3.index(sourceRef.file);
[sources,sourceReports,metadata]=BranchSolutionFile_v3.loadSolutions(sourceRef.file,pair);
[targets,targetReports]=BranchSolutionFile_v3.loadSolutions(targetRef.file,targetIndex);target=targets{1};targetReport=targetReports{1};
forward=metadata{2}.edge_enabled&&isequal(metadata{2}.edge_from,pair(1));
reverse=metadata{1}.edge_enabled&&isequal(metadata{1}.edge_from,pair(2));
assert(xor(forward,reverse)&&strcmp(metadata{1}.component_identity,metadata{2}.component_identity), 'PKPIPMeeting:OwnedSourcePair');
orientation=pair;if reverse,orientation=fliplr(pair);end
edge=find(cellfun(@(e)e.from==orientation(1)&&e.to==orientation(2),ix.edges));
assert(isscalar(edge)&&strcmp(ix.edges{edge}.component_identity,metadata{1}.component_identity) ...
    &&isequal(orientation,proposal.actual_stored_edge_orientation)&&strcmp(metadata{1}.component_identity,proposal.source_owner), 'PKPIPMeeting:OwnedSourceEdge');
sourceIDs=cellfun(@OrbitContentIdentity_v3,sources,'UniformOutput',false);
assert(isequaln(sourceIDs(:),proposal.source_native_ids(:))&&strcmp(OrbitContentIdentity_v3(target),t.native_ID),'PKPIPMeeting:NativeSelectors');
sourceOwners=cell(2,1);for k=1:2,[~,sourceOwners{k}]=RecordedOrbitReplayProfile_v3(sources{k},sourceReports{k});assert(sourceOwners{k}.complete,'PKPIPMeeting:SourceOwner');end
[~,targetOwner]=RecordedOrbitReplayProfile_v3(target,targetReport);assert(targetOwner.complete,'PKPIPMeeting:TargetOwner');
sourceFlights=sourceFlightEvidence(refs.SourceFlightReference,sourceRef,pair,sourceIDs);
assert(pronkExact(target),'PKPIPMeeting:TargetPronkChart','Retain the exact declared StageB target chart.');
sourceChart=sourceChartEvidence(sources,sourceReports,sourceIDs);
assert(isequaln(sources{1}.parameter,sources{2}.parameter)&&isequaln(sources{2}.parameter,target.parameter) ...
    &&isequaln(sources{1}.initial_mode,sources{2}.initial_mode)&&isequaln(sources{2}.initial_mode,target.initial_mode),'PKPIPMeeting:LiteralPQ');
baseline=struct('current_target_ID',t.native_ID,'target_period',target.period,'target_stride',target.stride_displacement, ...
    'StageB_row',t.StageB_row,'origin',t.origin,'b',t.b,'target_owner',targetOwner);
request=struct('plan_reference',refs.PlanReference,'case_index',refs.CaseIndex,'best_proposal',proposal, ...
    'source_reference',sourceRef,'source_pair',pair,'target_reference',targetRef,'target_index',targetIndex, ...
    'screen_geometry_is_prospective_only',true,'screen_geometry_passed_to_API6',false,'actual_geometry_owner','unchanged API6 recomputes the original397 pronk4D plane, signed ds and InitialStep from actual native records');
clear plan t ix sources sourceReports metadata targets targetReports target targetReport;verify(pins);
options=template;options.OutputFile=file;options.BranchFile=canonical(o.BranchFile);options.CheckpointFile=canonical(o.CheckpointFile);
options.SourceAuditReference=struct('file',refs.PlanReference.file,'sha256',refs.PlanReference.sha256);run=template.RunOptions;run.MaximumStep=.08;
run.ComponentIdentity=o.ComponentIdentity;run.CheckpointFile=options.CheckpointFile;run.MaxAccepted=1;run.MaxAttempts=1;run.ReusePreviousJacobian=false;
options.RunOptions=run;
meeting=struct('schema','PK15h-PIP-target-owned-meeting-flight-overlay-v1','configuration',struct('references',refs,'options',o), ...
    'request',request,'original_budget',B,'operation_finish',finish,'operation_work',work,'source_pair',pair, ...
    'actual_source_edge_orientation',orientation,'source_replay_owners',{sourceOwners},'source_conditional_flight_evidence',sourceFlights,'source_chart_evidence',sourceChart, ...
    'source_anchors_conditional_flight_PASS',true,'current_target_baseline',baseline, ...
    'acquire_invoked',true,'acquire_returned',false,'pre_supplement_acquisition_reference',struct(),'original_API6_flags',struct(), ...
    'endpoint_rows',{cell(2,1)},'fine_rows',{cell(2,2)},'completed',false,'source_posthash',false, ...
    'six_current_flight_checks_PASS',false,'current_M_eligible',false,'cold_qualification_performed',false, ...
    'new_M_relations',0,'extra_root_calls',0,'historical_flags_changed',false,'original_fine_flags_changed',false, ...
    'ordinary_P_current_flight_status','PROVISIONAL_UNTIL_SIX_CURRENT_FLIGHT_CHECKS_PASS', ...
    'status','ACQUIRE_INVOKED','failure',struct(), ...
    'scope','Finite owned numerical meeting only. Existing API6 may earn its P before this overlay; failed or unassessed flight supplements confer no current physical eligibility or M. Cold qualification needs an external actual process-exit witness. No PIP-parent attachment follows.');
apiSource=struct('file',sourceRef.file,'sha256',sourceRef.sha256);apiTarget=struct('file',targetRef.file,'sha256',targetRef.sha256);
% LR8D planner geometry is never copied into this original pronk4D method.
audit=AcquireC1NumericalOverlap_v3(apiSource,pair,apiTarget,targetIndex,B,options);
meeting.acquire_returned=true;meeting.original_API6_flags=flags(audit);meeting.pre_supplement_acquisition_reference=reference(file);owned=meeting.pre_supplement_acquisition_reference.sha256;
owned=saveOwned(file,writing,audit,meeting,owned,finish);
try
    assert(audit.completed&&audit.source_posthash&&audit.ordinary_edge_earned&&audit.qualified_numerical_relation ...
        &&audit.fine_calls_returned==4&&isequal(audit.source_edge_orientation,orientation), 'PKPIPMeeting:AcquireNotQualified');
    records={audit.candidate_orbit;audit.target_orbit};reports={audit.candidate_report;audit.target_report};
    assert(strcmp(OrbitContentIdentity_v3(records{2}),baseline.current_target_ID), 'PKPIPMeeting:TargetNativeID');
    for side=1:2
        row=struct('native_ID',OrbitContentIdentity_v3(records{side}),'profile_owner',struct(), ...
            'flight',struct(),'PASS',false,'status','UNASSESSED','failure',struct());
        try
            [profile,row.profile_owner]=RecordedOrbitReplayProfile_v3(records{side},reports{side});
            assert(row.profile_owner.complete,'PKPIPMeeting:EndpointReplayOwner');
            fo=flightOptions(o.FlightOptions,profile.EventTimeTolerance,work);
            row.flight=CheckC1PKOrbitFlights_v3(records{side},records{side}.parameter,fo);
            row.PASS=strcmp(row.flight.status,'PASS')&&row.flight.return_timely;row.status=row.flight.status;
        catch problem,row.failure=failed(problem);end
        meeting.endpoint_rows{side}=row;owned=saveOwned(file,writing,audit,meeting,owned,finish);
    end
    steps=[.0005,.00025];
    for side=1:2
        for level=1:2
            assert(left(work)>o.FineReplaySeconds+60+10,'PKPIPMeeting:FineFit');
            original=records{side};r=reports{side};prior=audit.fines{side,level};
            [policy,pe]=RecordedReturnPolicy_v3(r);assert(pe.complete&&isa(policy,'ReturnPolicyBase_v3'),'PKPIPMeeting:FinePolicy');
            simulator=HybridSimulator_v3(struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001));
            integration=simulator.Options;integration.RelTol=1e-12;integration.AbsTol=1e-14;integration.MaxStep=steps(level);
            child=childLimit(work,o.FineReplaySeconds);integration.ODEOptions=odeset(integration.ODEOptions,'OutputFcn',@(~,~,~)budgetOutput(child));
            limits=struct('MaxReturnTime',r.options.MaxReturnTime,'MaxCycleEvents',r.options.MaxCycleEvents,'MaxSectionCrossings',r.options.MaxSectionCrossings);
            s=QuadrupedSchema_v3.shared();map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(integration),policy,limits);
            row=struct('side',side,'level',level,'MaxStep',steps(level),'source_native_ID',OrbitContentIdentity_v3(original), ...
                'integration',integration,'policy_configuration',pe.configuration,'map_limits',limits,'map_invoked',true,'map_returned',false, ...
                'native_timely',false,'canonical_return_state',[],'raw_return_state',[],'map_info',struct(),'native_result_saved_before_check',false, ...
                'original_fine_comparison',struct(),'flight',struct(),'PASS',false,'status','MAP_INVOKED','failure',struct());
            meeting.fine_rows{side,level}=row;owned=saveOwned(file,writing,audit,meeting,owned,finish);
            try
                [next,info]=map.evaluate(original.initial_state,original.initial_mode,original.parameter);
                row.map_returned=true;row.canonical_return_state=next;row.raw_return_state=info.raw_return_state;row.map_info=info;row.native_timely=left(child)>0&&left(work)>0;
                meeting.fine_rows{side,level}=row;owned=saveOwned(file,writing,audit,meeting,owned,finish);
                row.native_result_saved_before_check=true;
                row.original_fine_comparison=fineComparison(next,info,original,prior);
                fo=flightOptions(o.FlightOptions,integration.EventTimeTolerance,work);
                row.flight=CheckC1PKOrbitFlights_v3(info,original.parameter,fo);
                row.PASS=row.native_timely&&row.original_fine_comparison.passed&&strcmp(row.flight.status,'PASS')&&row.flight.return_timely;
                row.status=row.flight.status;if ~row.original_fine_comparison.passed,row.status='ORIGINAL_FINE_CORRESPONDENCE_NOT_MET';end
            catch problem,row.failure=failed(problem);row.status='UNASSESSED_NATIVE_OR_CHECK_EXCEPTION';end
            meeting.fine_rows{side,level}=row;owned=saveOwned(file,writing,audit,meeting,owned,finish);
            fprintf('PK15_PIP_MEETING_FINE %s\n',jsonencode(thinFine(row)));
            clear original r policy simulator integration map next info fo row
        end
    end
    meeting.six_current_flight_checks_PASS=all(cellfun(@(r)r.PASS,meeting.endpoint_rows))&&all(cellfun(@(r)r.PASS,meeting.fine_rows(:)));
    meeting.ordinary_P_current_flight_status='UNASSESSED_OR_FAILED_CURRENT_FLIGHT_OVERLAY';
    if meeting.six_current_flight_checks_PASS,meeting.ordinary_P_current_flight_status='SIX_CURRENT_CONDITIONAL_FLIGHT_CHECKS_PASS';end
    meeting.completed=true;meeting.status='SUPPLEMENTS_COMPLETE_AWAIT_EXTERNAL_EXIT_AND_COLD_QUALIFICATION';
catch problem,meeting.failure=failed(problem);meeting.status='INCOMPLETE_OR_UNQUALIFIED_NO_CURRENT_M';end
verify(pins);meeting.source_posthash=true;owned=saveOwned(file,writing,audit,meeting,owned,finish);
result=struct('completed',meeting.completed,'source_posthash',meeting.source_posthash,'status',meeting.status, ...
    'original_API6_flags',meeting.original_API6_flags,'six_current_flight_checks_PASS',meeting.six_current_flight_checks_PASS, ...
    'current_M_eligible',false,'new_M_relations',0,'extra_root_calls',0,'audit_reference',reference(file), ...
    'own_process_exit_claimed',false,'return_timely',left(finish)>0,'failure',meeting.failure);
fprintf('PK15_PIP_MEETING_RETURN %s\n',jsonencode(result));
end

function result=cold(B,refs,o,work,finish)
assert(isequal(sort(fieldnames(refs)),sort({'ExperimentReference';'SourceReferences'})) ...
    &&isequal(sort(fieldnames(o)),sort({'ExecutionWitness';'MaxWallSeconds';'SaveMarginSeconds'})) ...
    &&o.MaxWallSeconds<=900,'PKPIPMeeting:ColdOptions');
verify({refs.ExperimentReference});z=load('-mat',refs.ExperimentReference.file,'audit','meeting');a=z.audit;m=z.meeting;clear z
assert(strcmp(m.schema,'PK15h-PIP-target-owned-meeting-flight-overlay-v1')&&m.completed&&m.source_posthash ...
    &&m.six_current_flight_checks_PASS&&~m.current_M_eligible&&~m.cold_qualification_performed ...
    &&~m.historical_flags_changed&&~m.original_fine_flags_changed&&m.new_M_relations==0&&m.extra_root_calls==0, 'PKPIPMeeting:ColdOverlay');
verify(m.configuration.references.SourceReferences);verify({m.configuration.references.PlanReference;m.configuration.references.MethodReference;m.configuration.references.SourceFlightReference;m.request.source_reference;m.request.target_reference});
assert(m.source_anchors_conditional_flight_PASS&&m.source_conditional_flight_evidence.complete,'PKPIPMeeting:ColdSourceFlight');
assert(isequaln(flags(a),m.original_API6_flags)&&all(cellfun(@(r)r.PASS&&strcmp(r.flight.status,'PASS')&&r.flight.return_timely,m.endpoint_rows)) ...
    &&all(cellfun(@(r)r.PASS&&r.map_returned&&r.native_result_saved_before_check&&r.original_fine_comparison.passed ...
    &&strcmp(r.flight.status,'PASS')&&r.flight.return_timely,m.fine_rows(:))), 'PKPIPMeeting:RetainedOverlay');
leftSelector=struct('file',a.run_branch_reference.file,'sha256',a.run_branch_reference.sha256,'index',3,'native_ID',a.candidate_native_id);
rightSelector=struct('file',a.target_reference.file,'sha256',a.target_reference.sha256,'index',a.target_index,'native_ID',a.target_native_id);
proof=struct('schema','C1-finite-owned-PAL-numerical-overlap-proof-v1','audit_reference',refs.ExperimentReference, ...
    'execution_witness',o.ExecutionWitness,'left_selector',leftSelector,'right_selector',rightSelector, ...
    'validation_limits',struct('deadline_unix_seconds',work.u,'deadline_monotonic_ns',work.m));
e=C1FiniteNumericalOverlap_v3.qualify(a.candidate_orbit,a.target_orbit,a.candidate_report,a.target_report,proof);
verify(refs.SourceReferences);verify({refs.ExperimentReference});check(finish);
result=struct('schema','PK15h-cold-PIP-target-meeting-flight-eligibility-v1','current_M_eligible',e.qualified&&m.six_current_flight_checks_PASS, ...
    'finite_numerical_overlap',e,'whole_flight_experiment_reference',refs.ExperimentReference,'six_current_flight_checks_PASS',true, ...
    'new_M_relations',0,'new_P_edges_by_this_cold_call',0,'extra_root_calls',0,'source_posthash',true, ...
    'current_budget',B,'own_process_exit_claimed',false,'return_timely',left(finish)>0, ...
    'scope','Eligibility for a finite current numerical association only. No Manager mutation, M append, exact identity, global branch or P1-equivalence claim.');
end
function c=fineComparison(next,info,original,prior)
f=prior.fine;oldRaw=prior.evidence.trajectory.state(end,:).';raw=info.raw_return_state;
scale=max([ones(14,1),abs(next(:)),abs(f.return_state(:))],[],2);
rawScale=max([ones(14,1),abs(raw(:)),abs(oldRaw(:))],[],2);
ss=max([ones(size(info.stride_displacement)),abs(info.stride_displacement),abs(f.stride_displacement)],[],2);
c=struct('original_fine_qualified',prior.qualified,'literal_initial_state_exact',isequaln(info.initial_state,original.initial_state), ...
    'literal_initial_mode_exact',isequaln(info.initial_mode,original.initial_mode),'canonical_return_bitwise_equal',isequaln(next,f.return_state), ...
    'canonical_return_scaled_inf',norm((next(:)-f.return_state(:))./scale,inf),'raw_return_bitwise_equal',isequaln(raw,oldRaw), ...
    'raw_return_scaled_inf',norm((raw(:)-oldRaw(:))./rawScale,inf),'period_delta',info.period-f.period, ...
    'period_tolerance',1e-10*max([1,abs(info.period),abs(f.period)]),'stride_delta',info.stride_displacement-f.stride_displacement, ...
    'stride_tolerance',1e-10*ss,'mode_closed',info.discrete_closed,'event_signature_equal',isequaln(info.section_relative_event_signature,f.event_signature), ...
    'native_map_conditions',info.success&&info.valid&&info.integration_success&&info.return_policy_accepted&&info.cycle_complete&&info.admissible,'passed',false);
c.passed=c.original_fine_qualified&&c.literal_initial_state_exact&&c.literal_initial_mode_exact&&c.canonical_return_scaled_inf<=1e-10&&c.raw_return_scaled_inf<=1e-10 ...
    &&abs(c.period_delta)<=c.period_tolerance&&all(abs(c.stride_delta)<=c.stride_tolerance)&&c.mode_closed&&c.event_signature_equal&&c.native_map_conditions;
end
function e=sourceFlightEvidence(ref,source,pair,ids)
z=load('-mat',ref.file,'audit');a=z.audit;clear z
assert(strcmp(a.schema,'PK15h-literal-stored-orbit-flight-audit-v1')&&a.completed&&a.source_posthash ...
    &&numel(a.rows)==1118&&a.new_admissions==0&&a.new_P_edges==0&&a.new_M_relations==0,'PKPIPMeeting:BulkFlight');
g=find(cellfun(@(g)strcmp(g.source_reference.file,source.file)&&strcmp(g.source_reference.sha256,source.sha256),a.groups));
assert(isscalar(g)&&a.groups{g}.prehash_verified&&a.groups{g}.posthash_verified,'PKPIPMeeting:BulkSourcePosthash');
rows=cell(2,1);for k=1:2
    at=find(cellfun(@(r)strcmp(r.source_reference.file,source.file)&&strcmp(r.source_reference.sha256,source.sha256)&&r.source_index==pair(k),a.rows));
    assert(isscalar(at),'PKPIPMeeting:BulkSelector');r=a.rows{at};
    assert(strcmp(r.native_ID,ids{k})&&strcmp(r.actual_native_ID,ids{k})&&strcmp(r.status,'PASS')&&r.return_timely ...
        &&strcmp(r.checker_status,'PASS')&&r.checker_return_timely&&r.trajectory_profile_owner.complete,'PKPIPMeeting:BulkParentFlight');rows{k}=r;
end
e=struct('reference',ref,'complete',true,'source_group',a.groups{g},'rows',{rows}, ...
    'scope','Existing literal saved-trajectory conditional flight PASS only. No fresh all-nine admission, edge or M is transferred from this bulk overlay.');
end
function fo=flightOptions(fo,tol,work),assert(left(work)>fo.MaxWallSeconds+2,'PKPIPMeeting:FlightFit');fo.EventTimeTolerance=tol;fo.Limits=struct('deadline_unix_seconds',work.u,'deadline_monotonic_ns',work.m);end
function out=flags(a),out=struct('completed',a.completed,'source_posthash',a.source_posthash,'ordinary_edge_earned',a.ordinary_edge_earned,'qualified_numerical_relation',a.qualified_numerical_relation,'fine_calls_attempted',a.fine_calls_attempted,'fine_calls_returned',a.fine_calls_returned,'status',a.status);end
function out=thinFine(r),out=struct('side',r.side,'level',r.level,'status',r.status,'map_returned',r.map_returned,'native_timely',r.native_timely,'PASS',r.PASS,'original_fine_comparison',r.original_fine_comparison,'failure',r.failure);end
function owned=saveOwned(file,writing,audit,meeting,previous,limit)
check(limit);assert(~isfile(writing)&&strcmp(RoundSHA256_v3(file),previous),'PKPIPMeeting:OwnedCAS');
save(writing,'audit','meeting','-v7');checkSaved(writing,audit,meeting);check(limit);
assert(strcmp(RoundSHA256_v3(file),previous),'PKPIPMeeting:OwnedCAS');
opts=javaArray('java.nio.file.CopyOption',2);opts(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');opts(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');
javaMethod('move','java.nio.file.Files',java.io.File(writing).toPath(),java.io.File(file).toPath(),opts);owned=RoundSHA256_v3(file);
end
function checkSaved(file,a,m)
z=load('-mat',file,'audit','meeting');assert(isequaln(flags(z.audit),flags(a))&&isequaln(z.meeting.original_API6_flags,m.original_API6_flags) ...
    &&isequaln(z.meeting.six_current_flight_checks_PASS,m.six_current_flight_checks_PASS)&&isequaln(z.meeting.status,m.status), 'PKPIPMeeting:Readback');
if ~isempty(a.candidate_orbit),assert(strcmp(OrbitContentIdentity_v3(z.audit.candidate_orbit),OrbitContentIdentity_v3(a.candidate_orbit)),'PKPIPMeeting:ReadbackID');end
for k=1:numel(m.fine_rows),if ~isempty(m.fine_rows{k})&&m.fine_rows{k}.map_returned
    x=m.fine_rows{k};y=z.meeting.fine_rows{k};assert(isequaln(x.raw_return_state,y.raw_return_state)&&isequaln(x.canonical_return_state,y.canonical_return_state) ...
        &&isequaln(x.map_info.trajectory.event_batches,y.map_info.trajectory.event_batches) ...
        &&isequaln(thinFine(x),thinFine(y)),'PKPIPMeeting:FineReadback');end;end
end
function yes=pronkExact(o)
s=QuadrupedSchema_v3.shared();x=o.initial_state(:);q=o.initial_mode(:);p=o.parameter(:);v=s.Parameter;
yes=~any(q)&&x(s.State.dy)==0&&all(x([s.State.phi,s.State.dphi])==0) ...
    &&all(x(s.Leg.AngleIndices)==x(s.State.alphaBL))&&all(x(s.Leg.RateIndices)==x(s.State.dalphaBL)) ...
    &&all(p([v.k_l_b,v.k_s_b,v.l_l_b,v.rsla_b])==p([v.k_l_f,v.k_s_f,v.l_l_f,v.rsla_f]))&&p(v.l_com)==.5&&all(isfinite([x;p]));
end
function e=sourceChartEvidence(orbits,reports,ids)
% Constructor checks are exactly the existing API6 family contract. Packing
% supplies a NEW restricted-root hypothesis; literal source objects stay put.
s=QuadrupedSchema_v3.shared();base=orbits{2};[policy,pe]=RecordedReturnPolicy_v3(reports{2});assert(pe.complete,'PKPIPMeeting:ChartPolicy');
map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(),policy);
family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,base.initial_state),base.initial_state,base.initial_mode,base.parameter,struct('Symmetry','pronk'));
assert(isequal(family.CoordinateIndices(:).',[2,3,7,8]),'PKPIPMeeting:PronkCoordinates');
rows=cell(2,1);for k=1:2
    x=orbits{k}.initial_state;u=family.packState(x);lift=family.fullState(u);
    rows{k}=struct('native_ID',ids{k},'packed_coordinates',u,'full14_pack_lift_delta',lift-x, ...
        'pack_lift_inf',norm(lift-x,inf),'pack_lift_exact',isequaln(lift,x));
    assert(strcmp(OrbitContentIdentity_v3(orbits{k}),ids{k}),'PKPIPMeeting:SourceMutation');
end
e=struct('symmetry','pronk','coordinate_indices',family.CoordinateIndices,'source_rows',{rows}, ...
    'existing_public_constructor_checks_passed',true,'NEW_restricted_root_hypothesis',true,'source_states_overwritten',false, ...
    'original_source_admission_transferred_to_restricted_root',false,'map_evaluations',0, ...
    'scope','Source pack/lift differences are explicit observations, not mutations or unchanged-source admissions. Only the later actual native PSS all-nine/capture controls may admit the NEW restricted root.');
end
function providers(refs)
assert(iscell(refs)&&iscolumn(refs),'PKPIPMeeting:References');
names={'RunPK15hPIPMeeting20261104','RunPK15hCurrentMeeting20261104','PreparePK15hPIPTargets20261104','AcquireC1NumericalOverlap_v3','C1FiniteNumericalOverlap_v3','C1PlainFineQualificationReplay_v3', ...
    'RecordedOrbitReplayProfile_v3','RecordedReturnPolicy_v3','CheckC1PKOrbitFlights_v3','CheckC1PKFlightInterval_v3','AllFlightClearanceBounds_v3', ...
    'RunC1Continuation_v3','PeriodicSolutionSolver_v3','PeriodicOrbitResidual_v3','CompactResearchBranch_v3','ValidateStoredPeriodicOrbit_v3','AuditPK15hStoredFlights20261104', ...
    'BranchSolutionFile_v3','OrbitContentIdentity_v3','PoincareMap_v3','HybridSimulator_v3','EventDetector_v3','Quadrupedal_Dynamics_v3', ...
    'EnergyFamilyResidual_v3','QuadrupedPhysicalChart_v3','QuadrupedSchema_v3','RoundSHA256_v3'};
paths=cellfun(@(r)r.file,refs,'UniformOutput',false);for k=1:numel(names),assert(sum(strcmp(paths,which(names{k})))==1,'PKPIPMeeting:Provider','Pin resolved provider %s.',names{k});end
assert(nargin('AcquireC1NumericalOverlap_v3')==6,'PKPIPMeeting:PublicAPI');
end
function verify(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(strcmp(canonical(r.file),r.file)&&isscalar(d)&&~d.isdir ...
    &&(~isfield(r,'bytes')||d.bytes==r.bytes)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKPIPMeeting:Changed','Changed input: %s.',r.file);end;end
function l=childLimit(parent,seconds),n=nowClock();l=struct('u',min(parent.u,n.u+seconds),'m',min(parent.m,n.m+seconds*1e9));end
function status=budgetOutput(l),check(l);status=0;end
function r=reference(f),d=dir(f);r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',d.bytes);end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function r=failed(e),r=struct('identifier',e.identifier,'message',e.message);end
function n=nowClock(),n=struct('u',double(java.time.Instant.now().toEpochMilli())/1000,'m',double(java.lang.System.nanoTime()));end
function v=left(l),n=nowClock();v=min(l.u-n.u,(l.m-n.m)/1e9);end
function check(l),assert(left(l)>0,'PKPIPMeeting:Deadline','Current operation or original research deadline expired.');end
