function result=RunPK15hP1PronkCounterparts20261104(B,refs,o)
% Three NEW exact-pronk4+freeE5 hypotheses; P1 contributes only vx/p/q.
% Current-model point admission/correspondence never proves component membership.
rkeys={'DispositionReference';'CurrentViewReference';'ProfileReference';'P1Reference';'SourceReferences'};
keys={'OutputFile';'ResumeReference';'MaxWallSeconds';'SaveMarginSeconds';'RootSeconds';'FineSeconds';'FlightOptions'};
assert(nargin==3&&isequal(sort(fieldnames(refs)),sort(rkeys))&&isequal(sort(fieldnames(o)),sort(keys))&&B.capture.pid==feature('getpid'), ...
 'PKP1PronkCounterpart:API','Use the explicit owned three-case interface.');
assert(o.MaxWallSeconds==1800&&o.SaveMarginSeconds==120&&o.RootSeconds==180&&o.FineSeconds==120&&o.FlightOptions.MaxWallSeconds==60 ...
 &&~isfield(o.FlightOptions,'Limits'),'PKP1PronkCounterpart:Caps','Keep root180, pointwhole60, fine120/finewhole30, resident1800/120.');
n=nowClock();assert(min(B.research_deadline_unix_seconds-n.u,(B.research_deadline_monotonic_ns-n.m)/1e9)>1802,'PKP1PronkCounterpart:Fit','The full pilot must fit both unchanged science clocks.');
finish=struct('u',n.u+1800,'m',n.m+1800e9);work=struct('u',finish.u-120,'m',finish.m-120e9);
providers(refs.SourceReferences);pins=[refs.SourceReferences;{refs.DispositionReference;refs.CurrentViewReference;refs.ProfileReference;refs.P1Reference}];verify(pins);
assert(strcmp(refs.DispositionReference.sha256,'129cfee7ae7f8a824501305bb674c518965441dfe07cb1b4d80afff256c68b95') ...
 &&strcmp(refs.CurrentViewReference.sha256,'486faffa227c46c6fde1fde975fa572925c925175569a16f9a0c2b5ab1761562') ...
 &&strcmp(refs.ProfileReference.sha256,'6c2a8aa1cc21f1ad485f34e35d9d0423dd6c433a6eabdeb48d1a715126278278') ...
 &&strcmp(refs.P1Reference.sha256,'8cc5723c8ad866db3ee7f040794ae7fa7cc7be149c90d483cd75277d7b38989a'), ...
 'PKP1PronkCounterpart:Authorities','Use the four actual closed input authorities.');
z=load('-mat',refs.DispositionReference.file,'disposition');d=z.disposition;clear z;assert(d.completed&&d.source_posthash&&d.cursor==180,'PKP1PronkCounterpart:Disposition','Require the complete179 literal-return table.');
z=load('-mat',refs.P1Reference.file,'audit');old=z.audit;hit=find(cellfun(@(r)strcmp(r.label,'PK'),old.branches));assert(isscalar(hit)&&old.complete&&old.source_code_posthash&&old.source_files_posthash,'PKP1PronkCounterpart:P1','Use the original complete P1 reference.');p1=old.branches{hit};clear z old
z=load('-mat',refs.CurrentViewReference.file,'component_plan');view=z.component_plan;clear z;assert(view.completed&&view.source_posthash,'PKP1PronkCounterpart:View','Use the exact closed current source view.');
fam=view.known_family_paths_and_obligations.known_families{1};assert(strcmp(fam.family,'SHORT')&&fam.positive_component==fam.negative_component,'PKP1PronkCounterpart:Short','Select only the declared actual SHORT component.');
short=view.components{fam.positive_component}.global_indices(:);physical=[10;10;20;20;1;1;0;0;2;.5];schema=QuadrupedSchema_v3.shared();
z=load('-mat',refs.ProfileReference.file,'study');study=z.study;r=study.native_report;
assert(study.completed&&study.source_posthash&&study.native_all_nine&&r.accepted,'PKP1PronkCounterpart:Profile','Use the existing strict native profile.');
[policy,pe]=RecordedReturnPolicy_v3(r);assert(pe.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3')&&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'PKP1PronkCounterpart:Policy','Keep the complete strict BL1 policy.');
profile=struct('Integration',r.integration,'ReplayIntegration',r.replay_integration,'EffectiveReplayODE',r.effective_replay_ode,'Acceptance',r.acceptance, ...
 'MaxReturnTime',r.options.MaxReturnTime,'MaxCycleEvents',r.options.MaxCycleEvents,'MaxSectionCrossings',r.options.MaxSectionCrossings);clear z study r
columns=[2;90;178];queue=cell(3,1);
for k=1:3
 at=find(cellfun(@(r)r.original_column==columns(k),d.rows));assert(isscalar(at),'PKP1PronkCounterpart:LiteralColumn','Use one exact original column.');literal=d.rows{at};
 assert(isequaln(literal.physical_parameter,physical)&&isequaln(literal.literal_state,p1.native_initial_state(:,columns(k)))&&isequaln(literal.literal_mode,p1.mode_v3(:,columns(k))), ...
  'PKP1PronkCounterpart:LiteralPq','The actual original x/p/q identities must match the independent reference.');
 pool=zeros(0,1);excluded=0;chartExcluded=0;
 for g=short(:).'
  node=view.nodes{g};x=node.normalized_state;pronk=isequaln(x([4,5,6]),zeros(3,1))&&isequaln(x([7,9,11,13]),repmat(x(7),4,1))&&isequaln(x([8,10,12,14]),repmat(x(8),4,1));if ~pronk,chartExcluded=chartExcluded+1;end
  if view.current_context{g}.conditional_seed_flight_eligible&&node.complete_return_section&&isequaln(node.parameter(:),physical)&&isequaln(node.initial_mode(:),literal.literal_mode(:))&&~any(node.initial_mode)&&pronk,pool(end+1,1)=g;else,excluded=excluded+1;end
 end
 chosen=0;distance=NaN;selector=struct();if ~isempty(pool)
  velocities=cellfun(@(v)v.normalized_state(2),view.nodes(pool));delta=abs(velocities-literal.literal_state(2));best=find(delta==min(delta));chosen=min(pool(best));node=view.nodes{chosen};cat=view.source_catalog{node.source_number};distance=abs(node.normalized_state(2)-literal.literal_state(2));selector=struct('file',cat.file,'sha256',cat.sha256,'index',node.source_index,'global_index',chosen,'native_ID',node.native_ID);
 end
 queue{k}=struct('original_column',columns(k),'target_signed_vx',literal.literal_state(2),'literal_state',literal.literal_state,'literal_mode',literal.literal_mode,'physical_parameter',physical, ...
  'P1_comparisons',literal.comparisons,'selected_seed',selector,'eligible_seed_count',numel(pool),'excluded_seed_count',excluded,'excluded_pronk_chart_seed_count',chartExcluded,'signed_vx_distance',distance, ...
  'selection_scope','Fixed SHORT same-p/q/allflight/conditional-flight/complete-section/exact upright-apex all-four-pronk pool, then signed-vx distance and lowest-global tie. Actual native BL1/report/pack-lift checks remain mandatory; no fallback. P1 raw state is never a Root initializer.');
end
clear d view short
file=canonical(o.OutputFile);cp=[file,'.checkpoint.mat'];writing=[cp,'.writing.mat'];assert(startsWith(file,[V3Root_v3(),filesep])&&~isfile(file)&&~isfile(writing),'PKP1PronkCounterpart:Fresh','Preserve all prior/pending outcomes.');
grant=struct('grant_id',B.grant_id,'start_utc',B.start_utc,'research_deadline_utc',B.research_deadline_utc,'deadline_utc',B.deadline_utc);config=struct('references',refs,'queue',{queue},'fixed_grant',grant,'output_file',file,'flight_options',o.FlightOptions);
owned='';if isempty(fieldnames(o.ResumeReference))
 assert(~isfile(cp),'PKP1PronkCounterpart:FreshPrefix','Do not replace an existing pilot prefix.');audit=struct('schema','PK15h-three-NEW-pronk-P1-counterpart-pilots-v1','configuration',config,'cursor',1,'rows',{cell(3,1)}, ...
  'completed',false,'source_posthash',false,'root_calls',0,'new_P_edges',0,'new_M_relations',0,'known_component_memberships_created',0,'scope','Three selected NEW exact-pronk chart hypotheses only; no LR absence, ambient regularity, or full P1-range result is claimed. Seed membership never transfers to solved points; literal P1 correspondence, current all-nine and branch membership are separate. Default existing PSS classification may use internal geometry ODE.');
 owned=savePrefix(cp,writing,audit,owned,finish);
else
 assert(strcmp(canonical(o.ResumeReference.file),cp),'PKP1PronkCounterpart:ResumePath','Resume only the exact owned prefix.');verify({o.ResumeReference});z=load('-mat',cp,'audit');audit=z.audit;clear z;owned=o.ResumeReference.sha256;
 assert(isequaln(audit.configuration,config)&&audit.cursor>=1&&audit.cursor<=4&&audit.completed==(audit.cursor==4),'PKP1PronkCounterpart:ResumeConfig','Resume the unchanged selected seeds and unfinished cursor.');
end
audit.source_posthash=false;owned=savePrefix(cp,writing,audit,owned,finish);status='PARTIAL_CAP';failure=struct();
try
 while audit.cursor<=3
  k=audit.cursor;item=queue{k};if isempty(audit.rows{k})
   audit.rows{k}=struct('original_column',item.original_column,'selection',item,'seed_reference',struct(),'seed_state',[],'source_capture',struct(),'root_attempts',{{}}, ...
    'native_returned',false,'native_exception_known',false,'native_timely',false,'orbit',[],'report',struct(),'native_saved_before_checks',false, ...
    'native_all_nine',false,'native_PK',false,'flight',struct(),'flight_PASS',false,'comparisons',struct(),'fines',{cell(2,1)},'current_counterpart_PASS',false,'known_component_membership_proved',false,'status','PREPARED','failure',struct());
   owned=savePrefix(cp,writing,audit,owned,finish);
  end
  row=audit.rows{k};if isempty(fieldnames(item.selected_seed)),row.status='UNASSESSED_NO_ELIGIBLE_DECLARED_SHORT_SEED';audit.rows{k}=row;audit.cursor=k+1;audit.completed=audit.cursor==4;owned=savePrefix(cp,writing,audit,owned,finish);continue;end
  try
  if ~row.native_returned&&~row.native_exception_known
   if ~isempty(row.root_attempts),row.status='HOLD_UNKNOWN_PREVIOUS_ROOT_OUTCOME';audit.rows{k}=row;status=row.status;break;end
   if left(work)<542,break;end
   sr=struct('file',item.selected_seed.file,'sha256',item.selected_seed.sha256);verify({sr});[a,ar,am]=BranchSolutionFile_v3.loadSolutions(sr.file,item.selected_seed.index);[b,br,bm]=BranchSolutionFile_v3.loadSolutions(sr.file,item.selected_seed.index);
   assert(isequaln(public(a{1}),public(b{1}))&&isequaln(ar,br)&&isequaln(am,bm),'PKP1PronkCounterpart:SeedRead2','The exact selected native anchor/report/metadata must read back unchanged.');
   anchor=a{1};[seedPolicy,se]=RecordedReturnPolicy_v3(ar{1});assert(nine(ar{1})&&se.complete&&isa(seedPolicy,'BLMarkedApexReturnPolicy_v3')&&isequaln(se.configuration,pe.configuration) ...
    &&strcmp(OrbitContentIdentity_v3(anchor),item.selected_seed.native_ID)&&isequaln(anchor.parameter(:),physical)&&isequaln(anchor.initial_mode(:),item.literal_mode(:)), ...
    'PKP1PronkCounterpart:SeedAuthority','Keep actual saved all-nine seed identity/p/q and complete strict BL1; no admission transfer.');
   x=anchor.initial_state;q=anchor.initial_mode;p=anchor.parameter;E=QuadrupedEnergy_v3.evaluate(x,q,p);child=childLimit(work,180);integration=rebind(profile.Integration,child);fo=o.FlightOptions;fo.EventTimeTolerance=integration.EventTimeTolerance;fo.Limits=limits(child);
   map=PKFlightCheckedMap20261104(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(schema.State.dy),HybridSimulator_v3(integration),policy,mapOptions(profile),fo,refs.SourceReferences);
   family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,x),x,q,p,struct('Symmetry','pronk','ClosureTolerance',profile.Acceptance.FullClosureTolerance));
   assert(isequal(family.CoordinateIndices(:).',[2,3,7,8])&&isequaln(family.fullState(family.packState(x)),x),'PKP1PronkCounterpart:LosslessPronk','Require exact full14 native pronk roundtrip; never project the anchor or retry another selector.');
   w=[family.packState(x);E];normal=zeros(5,1);normal(1)=1;constraint=struct('reference',zeros(5,1),'normal',normal,'target',item.target_signed_vx);residual=ConstrainedEnergyResidual_v3(family,1:4,constraint,ones(5,1));
   seed=struct('state',x,'mode',q,'parameter',p,'return_policy',policy,'occurrence',1,'provenance',struct('kind','NEW exact-pronk chart hypothesis from native SHORT seed; P1 vx selector only','source_reference',sr,'source_index',item.selected_seed.index,'original_P1_column',item.original_column));
   settings=struct('Residual',residual,'Coordinates',w,'AugmentedParameter',[p;E],'ReplayIntegration',replayOptions(profile.ReplayIntegration,profile.EffectiveReplayODE), ...
    'Acceptance',profile.Acceptance,'MaxReturnTime',profile.MaxReturnTime,'MaxCycleEvents',profile.MaxCycleEvents,'MaxSectionCrossings',profile.MaxSectionCrossings,'MaxWallSeconds',180,'SolverOptions',rootOptions(child,180,5),'TraceFailure',false);
   row.seed_reference=sr;row.seed_state=x;row.source_capture=am{1};row.root_attempts{1}=struct('limits',limits(child),'initial_coordinates',w,'constraint',constraint,'unknown_count',5,'active_state_coordinates',1:4,'energy_pivot_native_index',family.CoordinateIndices(family.EnergyPivot),'initial_energy_guess',E,'energy_is_free_solved_coordinate',true);audit.root_calls=audit.root_calls+1;audit.rows{k}=row;owned=savePrefix(cp,writing,audit,owned,finish);
   try,[row.orbit,row.report]=PeriodicSolutionSolver_v3(seed,settings);row.native_returned=true;row.native_timely=left(child)>0&&left(work)>0;catch problem,row.native_exception_known=true;row.failure=failed(problem);row.status='NATIVE_ROOT_EXCEPTION';end
   audit.rows{k}=row;owned=savePrefix(cp,writing,audit,owned,finish);verify({sr});clear a ar am b br bm anchor map family residual settings seed integration
  end
  row.native_saved_before_checks=true;row.native_all_nine=isa(row.orbit,'HybridOrbit_v3')&&nine(row.report);g=member(row.report,'classification',struct());row.native_PK=strcmp(member(g,'validated_gait_type',''),'PK')&&member(g,'canonical_label_qualified',false)&&member(g,'flight_count_certain',false)&&isequal(member(g,'flight_count',NaN),1);
  if row.native_all_nine&&row.native_timely
   if isempty(fieldnames(row.flight))
    if left(work)<362,break;end
    [actual,owner]=RecordedOrbitReplayProfile_v3(row.orbit,row.report);assert(owner.complete,'PKP1PronkCounterpart:ReplayOwner','The actual accepted orbit must own its replay profile.');fo=o.FlightOptions;fo.EventTimeTolerance=actual.EventTimeTolerance;fo.Limits=limits(childLimit(work,60));row.flight=CheckC1PKOrbitFlights_v3(row.orbit,physical,fo);row.flight_PASS=strcmp(row.flight.status,'PASS')&&row.flight.return_timely;row.comparisons=compareP1(row.orbit,item,p1,schema);audit.rows{k}=row;owned=savePrefix(cp,writing,audit,owned,finish);
   end
   for level=1:2
    fr=row.fines{level};if ~isempty(fr)&&fr.invoked&&~fr.returned&&~fr.exception_known,status='HOLD_UNKNOWN_PREVIOUS_FINE_OUTCOME';break;end
    if isempty(fr)
     if left(work)<152,status='PARTIAL_BEFORE_FINE';break;end
     child=childLimit(work,120);sim=HybridSimulator_v3(struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001));integ=sim.Options;steps=[.0005,.00025];integ.RelTol=1e-12;integ.AbsTol=1e-14;integ.MaxStep=steps(level);integ.ODEOptions=odeset(integ.ODEOptions,'OutputFcn',ownedCallback(child));
     fm=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(schema.State.dy),HybridSimulator_v3(integ),policy,mapOptions(profile));
     fr=struct('invoked',true,'returned',false,'exception_known',false,'timely',false,'integration',integ,'canonical_return',[],'raw_return',[],'map_info',struct(),'saved_before_check',false,'checked',false,'flight',struct(),'raw_full13_inf',NaN,'closure_scaled_inf',NaN,'period_delta',NaN,'stride_scaled_inf',NaN,'PASS',false,'failure',struct());row.fines{level}=fr;audit.rows{k}=row;owned=savePrefix(cp,writing,audit,owned,finish);
     try,[fr.canonical_return,fr.map_info]=fm.evaluate(row.orbit.initial_state,row.orbit.initial_mode,row.orbit.parameter);fr.raw_return=fr.map_info.raw_return_state;fr.returned=true;fr.timely=left(child)>0&&left(work)>0;catch problem,fr.exception_known=true;fr.failure=failed(problem);end
     row.fines{level}=fr;audit.rows{k}=row;owned=savePrefix(cp,writing,audit,owned,finish);clear fm sim
    end
    if fr.returned&&~fr.checked
     if left(work)<32,status='PARTIAL_BEFORE_FINE_CHECK';break;end
     fr.saved_before_check=true;fo=o.FlightOptions;fo.MaxWallSeconds=30;fo.EventTimeTolerance=fr.integration.EventTimeTolerance;fo.Limits=limits(childLimit(work,30));fr.flight=CheckC1PKOrbitFlights_v3(fr.map_info,physical,fo);
     scale=max([ones(13,1),abs(fr.raw_return(2:14)),abs(row.orbit.initial_state(2:14))],[],2);fr.raw_full13_inf=norm(fr.raw_return(2:14)-row.orbit.initial_state(2:14),inf);fr.closure_scaled_inf=norm((fr.raw_return(2:14)-row.orbit.initial_state(2:14))./scale,inf);fr.period_delta=fr.map_info.period-row.orbit.period;ss=max([ones(14,1),abs(fr.map_info.stride_displacement),abs(row.orbit.stride_displacement)],[],2);fr.stride_scaled_inf=norm((fr.map_info.stride_displacement-row.orbit.stride_displacement)./ss,inf);
     fr.PASS=fr.timely&&fr.map_info.success&&fr.map_info.valid&&fr.map_info.integration_success&&fr.map_info.return_policy_accepted&&fr.map_info.cycle_complete&&fr.map_info.admissible&&fr.map_info.discrete_closed ...
      &&isequaln(fr.map_info.initial_state,row.orbit.initial_state)&&isequaln(fr.map_info.initial_mode,row.orbit.initial_mode)&&fr.raw_full13_inf<=profile.Acceptance.FullClosureTolerance&&abs(fr.period_delta)<=1e-10*max(1,abs(row.orbit.period))&&fr.stride_scaled_inf<=1e-10 ...
      &&isequaln(fr.map_info.section_relative_event_signature,row.orbit.section_relative_event_signature)&&strcmp(fr.flight.status,'PASS')&&fr.flight.return_timely;fr.checked=true;
    end
    row.fines{level}=fr;audit.rows{k}=row;owned=savePrefix(cp,writing,audit,owned,finish);
   end
   if any(cellfun(@(v)isempty(v)||(~v.returned&&~v.exception_known)||(v.returned&&~v.checked),row.fines)),audit.rows{k}=row;break;end
   row.current_counterpart_PASS=row.native_PK&&row.flight_PASS&&all(cellfun(@(v)v.PASS,row.fines))&&row.comparisons.literal_raw13_E_T_8time_match;row.status='CURRENT_POINT_OR_FINE_QUALIFICATION_NOT_MET';if row.native_PK&&row.flight_PASS&&all(cellfun(@(v)v.PASS,row.fines)),row.status='CURRENT_ADMITTED_PK_POINT_P1_CORRESPONDENCE_NOT_MET';end;if row.current_counterpart_PASS,row.status='CURRENT_P1_COUNTERPART_FINITE_CHECKS_PASS';end
  else,row.status='NATIVE_NOT_ADMITTED_OR_UNTIMELY';end
  catch problem
   row.failure=failed(problem);row.status='UNASSESSED_CASE_PREFLIGHT_OR_POSTCHECK';
   pendingRoot=~row.native_returned&&~row.native_exception_known&&~isempty(row.root_attempts);pendingFine=any(cellfun(@(v)~isempty(v)&&v.invoked&&~v.returned&&~v.exception_known,row.fines));
   if pendingRoot||pendingFine,audit.rows{k}=row;status='HOLD_UNKNOWN_PREPARED_SERVICE';break;end
  end
  audit.rows{k}=row;audit.cursor=k+1;audit.completed=audit.cursor==4;owned=savePrefix(cp,writing,audit,owned,finish);fprintf('PK15_P1_PRONK_COUNTERPART_CASE %s\n',jsonencode(rowSummary(row)));
 end
catch problem,failure=failed(problem);end
verify(pins);for k=1:3,if ~isempty(audit.rows{k})&&~isempty(fieldnames(audit.rows{k}.seed_reference)),verify({audit.rows{k}.seed_reference});end;end;audit.source_posthash=true;owned=savePrefix(cp,writing,audit,owned,finish);out=reference(cp);
if audit.completed,assert(strcmp(RoundSHA256_v3(cp),owned),'PKP1PronkCounterpart:FinalCAS','The owned completed prefix changed.');javaMethod('move','java.nio.file.Files',java.io.File(cp).toPath(),java.io.File(file).toPath(),javaArray('java.nio.file.CopyOption',0));out=reference(file);end
if audit.completed,status='THREE_SELECTED_CASES_FINISHED';end
result=struct('completed',audit.completed,'cursor',audit.cursor,'source_posthash',audit.source_posthash,'rows',{cellfun(@safeSummary,audit.rows,'UniformOutput',false)},'root_calls',audit.root_calls,'new_P_edges',0,'new_M_relations',0,'known_component_memberships_created',0,'output_reference',out,'status',status,'failure',failure,'return_timely',left(finish)>0);fprintf('PK15_P1_PRONK_COUNTERPART_RETURN %s\n',jsonencode(result));
end
function c=compareP1(o,item,p1,s)
x=o.initial_state;y=item.literal_state;at=item.original_column;scale=max([ones(13,1),abs(x(2:14)),abs(y(2:14))],[],2);T=p1.regulated_legacy_timings(9,at);counts=zeros(8,1);times=NaN(8,1);scheduled=NaN(8,1);scheduled(LegacyEventAdapter_v3.toV3(1:8))=p1.regulated_legacy_timings(1:8,at);
for k=1:numel(o.event_history),v=o.event_history(k);id=v.guard_id;if isnumeric(id)&&isscalar(id)&&id>=1&&id<=8&&id==fix(id),counts(id)=counts(id)+1;times(id)=v.time-o.trajectory.time(1);end;end
E=QuadrupedEnergy_v3.evaluate(x,o.initial_mode,o.parameter);td=times-scheduled;
c=struct('raw_full13_delta',x(2:14)-y(2:14),'raw_full13_scaled_inf',norm((x(2:14)-y(2:14))./scale,inf),'energy',E,'P1_energy',item.P1_comparisons.initial_energy,'energy_delta',E-item.P1_comparisons.initial_energy, ...
 'period',o.period,'P1_period',T,'period_delta',o.period-T,'period_tolerance',1e-10*max([1,abs(T),abs(o.period)]),'physical_event_counts',counts,'physical_event_times',times,'P1_physical_event_times',scheduled,'physical_event_time_delta',td,'physical_event_time_tolerance',1e-8*max(1,abs(T)), ...
 'actual_full_stride',o.stride_displacement,'full_scheduled_stride_comparison','UNASSESSED_REFERENCE_STORES_ONLY_SIGNED_X_STRIDE','signed_X_stride_delta',NaN, ...
 'selector_vx_error',x(s.State.dx)-item.target_signed_vx,'literal_raw13_E_T_8time_match',false,'known_component_membership_proved',false);
if p1.scheduled_mean_available(at),c.signed_X_stride_delta=o.stride_displacement(1)-p1.scheduled_signed_stride(at);end
c.literal_raw13_E_T_8time_match=c.raw_full13_scaled_inf<=1e-8&&abs(c.energy_delta)<=1e-8&&abs(c.period_delta)<=c.period_tolerance&&all(counts==1)&&all(abs(td)<=c.physical_event_time_tolerance);
end
function out=rootOptions(l,seconds,n)
j=ValidSidedFiniteDifferenceJacobian_v3(struct('RelativeStep',1e-8,'DeadlineUnixSeconds',l.u,'DeadlineMonotonicNs',l.m));
out=struct('Algorithm','root-newton','MaxIterations',40,'MaxFunctionEvaluations',1000,'FunctionTolerance',1e-11, ...
 'ResidualAcceptanceTolerance',1e-10,'StepTolerance',1e-13,'OptimalityTolerance',1e-18,'ReuseJacobian',true,'InitialJacobian',[], ...
 'UseBroyden',true,'JacobianRefreshInterval',5,'Jacobian',j,'MaxWallSeconds',seconds,'StateScale',ones(n,1));
end
function out=replayOptions(p,e)
names={'RelTol','AbsTol','EventValueTolerance','EventTimeTolerance','SimultaneousTimeTolerance','MaxStep','ArmingTolerance'};out=struct();for k=1:numel(names),out.(names{k})=p.(names{k});end;out.RelTol=e.RelTol;out.AbsTol=e.AbsTol;out.MaxStep=e.MaxStep;
end
function p=rebind(p,l),p.ODEOptions=odeset(p.ODEOptions,'OutputFcn',ownedCallback(l));end
function f=ownedCallback(l),f=@(varargin)ownedOutput(l);end
function stop=ownedOutput(l),check(l);stop=0;end
function o=mapOptions(p),o=struct('MaxReturnTime',p.MaxReturnTime,'MaxCycleEvents',p.MaxCycleEvents,'MaxSectionCrossings',p.MaxSectionCrossings);end
function o=limits(l),o=struct('deadline_unix_seconds',l.u,'deadline_monotonic_ns',l.m);end
function c=childLimit(p,seconds),assert(left(p)>seconds+1,'PKP1PronkCounterpart:ChildFit','Keep the complete next child cap.');n=nowClock();c=struct('u',n.u+seconds,'m',n.m+seconds*1e9);end
function yes=nine(r)
names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};yes=isequal(member(r,'accepted',false),true)&&isfield(r,'acceptance_gates')&&all(isfield(r.acceptance_gates,names));if yes,yes=all(cellfun(@(n)isequal(r.acceptance_gates.(n),true),names));end
end
function s=safeSummary(r),if isempty(r),s=struct('status','UNATTEMPTED');else,s=rowSummary(r);end;end
function s=rowSummary(r)
s=struct('original_column',r.original_column,'selected_seed',r.selection.selected_seed,'eligible_seed_count',r.selection.eligible_seed_count,'excluded_seed_count',r.selection.excluded_seed_count,'excluded_pronk_chart_seed_count',r.selection.excluded_pronk_chart_seed_count, ...
 'root_attempts',numel(r.root_attempts),'native_returned',r.native_returned,'native_exception_known',r.native_exception_known,'native_timely',r.native_timely,'native_saved_before_checks',r.native_saved_before_checks, ...
 'native_all_nine',r.native_all_nine,'native_PK',r.native_PK,'flight_PASS',r.flight_PASS,'comparisons',r.comparisons,'current_counterpart_PASS',r.current_counterpart_PASS, ...
 'known_component_membership_proved',false,'status',r.status,'failure',r.failure,'fines',{cell(2,1)});
if r.native_returned,s.retained_status=member(r.report,'status','');s.retained_gates=member(r.report,'acceptance_gates',struct());if isa(r.orbit,'HybridOrbit_v3'),s.native_ID=OrbitContentIdentity_v3(r.orbit);s.state=r.orbit.initial_state;s.period=r.orbit.period;s.stride=r.orbit.stride_displacement;end;end
for k=1:2,v=r.fines{k};if ~isempty(v),s.fines{k}=rmfield(v,{'integration','map_info','flight'});end;end
end
function sha=savePrefix(cp,writing,audit,previous,l)
check(l);assert(~isfile(writing),'PKP1PronkCounterpart:Writing','Preserve a staged outcome.');if isempty(previous),assert(~isfile(cp),'PKP1PronkCounterpart:FreshCheckpoint','Preserve an existing prefix.');else,assert(strcmp(RoundSHA256_v3(cp),previous),'PKP1PronkCounterpart:CAS','Owned prefix changed.');end
projection=struct('configuration',audit.configuration,'cursor',audit.cursor,'completed',audit.completed,'source_posthash',audit.source_posthash,'root_calls',audit.root_calls,'rows',{cellfun(@safeSummary,audit.rows,'UniformOutput',false)});
save(writing,'audit','projection','-v7');z=load('-mat',writing,'audit','projection');observed=struct('configuration',z.audit.configuration,'cursor',z.audit.cursor,'completed',z.audit.completed,'source_posthash',z.audit.source_posthash,'root_calls',z.audit.root_calls,'rows',{cellfun(@safeSummary,z.audit.rows,'UniformOutput',false)});
assert(isequaln(z.projection,projection)&&isequaln(observed,projection),'PKP1PronkCounterpart:Readback','All retained outcomes/flags must survive native readback.');
for k=1:3,if isempty(audit.rows{k}),continue;end;for j=1:2,x=audit.rows{k}.fines{j};y=z.audit.rows{k}.fines{j};if isempty(x)||~x.returned,continue;end
 assert(isequaln(x.raw_return,y.raw_return)&&isequaln(x.canonical_return,y.canonical_return),'PKP1PronkCounterpart:RawReadback','Keep actual raw/canonical native results.');
 for name={'time','state','mode','event_history','event_batches'},assert(isequaln(x.map_info.trajectory.(name{1}),y.map_info.trajectory.(name{1})),'PKP1PronkCounterpart:TraceReadback','Keep every actual native trajectory/batch field.');end
end;end
clear z;check(l);if ~isempty(previous),assert(strcmp(RoundSHA256_v3(cp),previous),'PKP1PronkCounterpart:CAS','Owned prefix changed before publication.');end
flags=javaArray('java.nio.file.CopyOption',2);flags(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');flags(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');javaMethod('move','java.nio.file.Files',java.io.File(writing).toPath(),java.io.File(cp).toPath(),flags);sha=RoundSHA256_v3(cp);
end
function value=public(value)
if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3'),out=struct('native_class',class(value));names=properties(value);for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
elseif isstruct(value),names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end;end
elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end;end
end
function providers(refs)
names={'RunPK15hP1PronkCounterparts20261104','RunPK15hPIPDaughters20261104','PeriodicSolutionSolver_v3','EnergyFamilyResidual_v3','ConstrainedEnergyResidual_v3','PeriodicOrbitResidual_v3', ...
 'PKFlightCheckedMap20261104','ValidSidedFiniteDifferenceJacobian_v3','RecordedReturnPolicy_v3','RecordedOrbitReplayProfile_v3','BranchSolutionFile_v3','OrbitContentIdentity_v3', ...
 'LegacyEventAdapter_v3','QuadrupedSchema_v3','QuadrupedEnergy_v3','PoincareMap_v3','PoincareSection_v3','HybridSimulator_v3','Quadrupedal_Dynamics_v3','CheckC1PKOrbitFlights_v3','RoundSHA256_v3'};
paths=cellfun(@(r)r.file,refs,'UniformOutput',false);for k=1:numel(names),assert(sum(strcmp(paths,which(names{k})))==1,'PKP1PronkCounterpart:Provider','Pin resolved provider %s.',names{k});end
end
function verify(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&(~isfield(r,'bytes')||d.bytes==r.bytes)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKP1PronkCounterpart:Changed','Changed immutable input: %s.',r.file);end;end
function r=reference(f),d=dir(f);r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',d.bytes);end
function v=member(s,k,d),v=d;if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);end;end
function e=failed(e),e=struct('identifier',e.identifier,'message',e.message);end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function n=nowClock(),n=struct('u',double(java.time.Instant.now().toEpochMilli())/1000,'m',double(java.lang.System.nanoTime()));end
function v=left(l),n=nowClock();v=min(l.u-n.u,(l.m-n.m)/1e9);end
function check(l),assert(left(l)>0,'PKP1PronkCounterpart:Deadline','Local or original science clock expired.');end
