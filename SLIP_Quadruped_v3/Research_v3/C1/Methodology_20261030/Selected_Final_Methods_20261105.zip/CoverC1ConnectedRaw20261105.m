function coverage=CoverC1ConnectedRaw20261105(censusReference,coreReferences,options)
%COVERC1CONNECTEDRAW20261105 Storage coverage and uncovered native seeds.
% Literal Core29 comparison is a storage preservation test, not orbit identity,
% current admission, numerical continuation, qualification or reconciliation.
% Original graph/P headers stay literal in the receipt. Uncovered points and
% their actual physical predecessors may be stored with the existing essential
% projection. Unknown source/projection forms remain RAW_ONLY_HELD.
    entered=tic;startUTC=unixNow();K=EssentialBranchSolutionFile_v3;
    fields={'OutputDirectory','ReceiptFile','MaxWallSeconds','SaveMarginSeconds','MaximumFileBytes'};
    assert(isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort(fields(:))), ...
        'ConnectedCoverage:Options','Supply the exact bounded storage options.');o=options;
    validateattributes(o.MaxWallSeconds,{'double'},{'real','finite','scalar','positive','<=',1800});
    validateattributes(o.SaveMarginSeconds,{'double'},{'real','finite','scalar','>=',60,'<',o.MaxWallSeconds});
    validateattributes(o.MaximumFileBytes,{'double'},{'real','finite','positive','scalar'});
    censusReference=checked(censusReference);census=jsondecode(fileread(censusReference.file));
    assert(strcmp(census.schema,'C1-connected-raw-retirement-source-census-v1'), ...
        'ConnectedCoverage:Census','Use an explicit immutable closed source census.');
    sourceCount=census.total_files;validateattributes(sourceCount,{'double'},{'real','finite','scalar','integer','positive','<=',128});
    assert(iscell(coreReferences)&&isequal(size(coreReferences),[2,1]), ...
        'ConnectedCoverage:Cores','Supply the two current complete working-core references.');
    outputDirectory=canonical(o.OutputDirectory);receiptFile=canonical(o.ReceiptFile);
    assert(isfolder(outputDirectory)&&isfolder(fileparts(receiptFile))&&~isfile(receiptFile) ...
        &&~isfile([receiptFile,'.json'])&&~isfile([receiptFile,'.pending.mat']), ...
        'ConnectedCoverage:Fresh','Use fresh receipt paths and an existing output directory.');
    sources=cell(0,1);groups=asCells(census.cohorts);
    for j=1:numel(groups),files=asCells(groups{j}.files);for k=1:numel(files),sources{end+1,1}=refHeader(files{k});end,end
    assert(numel(sources)==sourceCount,'ConnectedCoverage:Census','Preserve every census entry.');
    methods={reference([mfilename('fullpath'),'.m']);reference(which('EssentialBranchSolutionFile_v3')); ...
        reference(which('BranchSolutionFile_v3'));reference(which('LoadC1WorkingSolutionCore29_v3')); ...
        reference(which('WriteBranchSolutionCore29_v3'));reference(which('OrbitContentIdentity_v3')); ...
        reference(which('RecordedReturnPolicy_v3'));reference(which('C1ScientificDigest_v3'));reference(which('RoundSHA256_v3')); ...
        reference(which('ProjectRecordedMethodDescriptors_v3'))};
    cores=cell(2,1);candidateIDs=cell(0,1);candidateLocations=zeros(0,2);
    for f=1:2
        coreReferences{f}=checked(coreReferences{f});guard(false);
        [sample,report,point]=LoadC1WorkingSolutionCore29_v3(coreReferences{f}.file,1,coreReferences{f}.sha256); %#ok<ASGLU>
        z=load(coreReferences{f}.file,'solution_core29','core_digest');c=z.solution_core29;
        assert(strcmp(C1ScientificDigest_v3(c),z.core_digest)&&strcmp(point.native_id,c.native_ids{1}), ...
            'ConnectedCoverage:Core','The public core reader and whole plain core must agree.');
        cores{f}=c;candidateIDs=[candidateIDs;c.native_ids]; %#ok<AGROW>
        candidateLocations=[candidateLocations;[repmat(f,c.point_count,1),(1:c.point_count).']]; %#ok<AGROW>
        clear sample report point z c
    end
    rows=cell(sourceCount,1);
    for f=1:sourceCount,rows{f}=struct('source_reference',sources{f},'status','NOT_ATTEMPTED','prepared',false, ...
        'returned',false,'raw_retirement_eligible',false,'failure',struct(),'source_metadata',struct(), ...
        'source_point_metadata',{cell(0,1)},'original_physical_edges',{cell(0,1)},'source_index_digest','', ...
        'point_coverage',{cell(0,1)},'source_acquisition_blocks',{cell(0,1)},'unmatched_acquisition_blocks',{cell(0,1)},'unmatched_output_reference',struct(),'unmatched_old_indices',zeros(0,1), ...
        'old_to_compact_index',zeros(0,1),'unmatched_projection_read2_verified',false);end
    coverage=struct('schema','C1-connected-raw-storage-coverage-v1','census_reference',censusReference, ...
        'core_references',{coreReferences},'source_code',{methods},'options',o,'rows',{rows}, ...
        'cursor',1,'source_file_count',sourceCount,'completed',false,'source_posthash',false, ...
        'all_sources_retirement_eligible',false,'all36_retirement_eligible',false,'source_read_block_size',8, ...
        'started_utc',stamp(),'finished_utc','','elapsed_seconds',0,'status','PREPARED', ...
        'new_roots_maps_replays_classifications',0,'new_admission_claimed',false,'new_P_E_A_M_claimed',false, ...
        'loss_disclosure','Dense trajectories/event-state traces, solver/FD/runtime graphs and detailed historical debug execution are deliberately unavailable after retirement. Complete original plain source metadata and physical P headers are retained literally here; their historical graph flags are not promoted.');
    publish();
    for f=1:sourceCount
        if remaining()<=2*o.SaveMarginSeconds+5,coverage.status='PARTIAL_STORAGE_CAP';break;end
        coverage.cursor=f;coverage.rows{f}.prepared=true;coverage.rows{f}.status='PREPARED_UNKNOWN_UNTIL_RETURN';publish();
        try
            source=checked(sources{f});
            if source.bytes==0
                coverage.rows{f}.status='EMPTY_BYTE_ARTIFACT_NO_NATIVE_PAYLOAD';coverage.rows{f}.returned=true;
                coverage.rows{f}.raw_retirement_eligible=true;coverage.cursor=f+1;publish();continue
            end
            guard(false);ix=BranchSolutionFile_v3.index(source.file);N=numel(ix.points);
            row=coverage.rows{f};row.source_metadata=ix.metadata;row.source_point_metadata=cellfun(@(p)p.metadata,ix.points,'UniformOutput',false);
            row.original_physical_edges=ix.edges;row.source_index_digest=C1ScientificDigest_v3(ix);
            pointRows=cell(N,1);unmatched=false(N,1);blockEnd=0;blockSaved=struct();readBlocks=cell(0,1);
            for k=1:N
                guard(false);p=ix.points{k};
                if k>blockEnd
                    clear blockSaved
                    blockEnd=min(k+7,N);variables=cell(2*(blockEnd-k+1),1);
                    for j=k:blockEnd,point=ix.points{j};at=2*(j-k)+1;variables{at}=point.solution_variable;variables{at+1}=point.report_variable;end
                    reading=tic;blockSaved=load(source.file,variables{:});readBlocks{end+1,1}=struct('first_index',k,'last_index',blockEnd,'acquisition_elapsed_seconds',toc(reading));
                end
                orbit=blockSaved.(p.solution_variable);report=blockSaved.(p.report_variable);
                assert(isa(orbit,'HybridOrbit_v3')&&isscalar(orbit)&&isstruct(report)&&isscalar(report), ...
                    'ConnectedCoverage:Native','Only literal native orbit/report pairs are handled.');
                id='';hit=[];
                if numel(orbit.initial_state)==14&&numel(orbit.initial_mode)==4&&numel(orbit.parameter)==10 ...
                        &&isscalar(orbit.period)&&numel(orbit.stride_displacement)==14
                    id=OrbitContentIdentity_v3(orbit);hit=find(strcmp(candidateIDs,id));
                end
                chosen=[];fact=[];
                try,fact=coreFact(orbit,report);catch,hit=[];end
                for h=hit(:).'
                    at=candidateLocations(h,:);if isequaln(fact,storedCoreFact(cores{at(1)},at(2))),chosen=at;break;end
                end
                pointRows{k}=struct('source_index',k,'native_id',id,'status','UNMATCHED_NATIVE_STATE_HELD', ...
                    'core_reference',struct(),'core_index',[],'compact_index',[],'recorded_method_descriptor_dispositions',{cell(0,1)});
                if isempty(chosen),unmatched(k)=true;
                else
                    pointRows{k}.status='LITERAL_CORE_VALUES_POLICY_SECTION_GATES_HEADS_MATCH';
                    pointRows{k}.core_reference=coreReferences{chosen(1)};pointRows{k}.core_index=chosen(2);
                end
                clear orbit report fact
            end
            clear blockSaved
            row.source_acquisition_blocks=readBlocks;
            % Include the entire actual predecessor chain of each uncovered
            % occurrence. It is never replaced by an inferred core edge.
            selected=unmatched;changed=true;
            while changed
                changed=false;
                for e=1:numel(ix.edges)
                    edge=ix.edges{e};if selected(edge.to)&&~selected(edge.from),selected(edge.from)=true;changed=true;end
                end
            end
            indices=find(selected);map=zeros(N,1);map(indices)=1:numel(indices);row.unmatched_old_indices=indices;row.old_to_compact_index=map;
            if ~isempty(indices)
                guard(false);[~,stem]=fileparts(source.file);output=fullfile(outputDirectory,sprintf('ConnectedSource_%02d_%s_Unmatched.mat',f,stem));
                assert(~isfile(output)&&~isfolder(output),'ConnectedCoverage:Fresh','Never overwrite a previous unknown compact output.');
                records=cell(numel(indices),1);physical=cell(0,1);header=struct('file',source.file,'sha256',source.sha256);blockEnd=0;blockSaved=struct();readBlocks=cell(0,1);
                for j=1:numel(indices)
                    guard(false);k=indices(j);p=ix.points{k};
                    if j>blockEnd
                        clear blockSaved
                        blockEnd=min(j+7,numel(indices));variables=cell(2*(blockEnd-j+1),1);
                        for at=j:blockEnd,point=ix.points{indices(at)};position=2*(at-j)+1;variables{position}=point.solution_variable;variables{position+1}=point.report_variable;end
                        reading=tic;blockSaved=load(source.file,variables{:});readBlocks{end+1,1}=struct('selected_original_indices',indices(j:blockEnd),'acquisition_elapsed_seconds',toc(reading));
                    end
                    orbit=blockSaved.(p.solution_variable);report=blockSaved.(p.report_variable);
                    m=struct('component_identity',p.component_identity,'order',p.order,'edge_enabled',false,'edge_from',[]);
                    for key={'classification','nativeE','signedmeanU'},if isfield(p,key{1}),m.(key{1})=p.(key{1});end,end
                    context=struct('role','historical-unknown','occurrence_id',sprintf('source-sha256:%s:index:%d',source.sha256,k), ...
                        'source_reference',header,'source_index',k,'expected_index',j);
                    incoming=find(cellfun(@(e)e.to==k,ix.edges));
                    if ~isempty(incoming)
                        assert(isscalar(incoming),'ConnectedCoverage:Physical','Actual P predecessor must be unique.');edge=ix.edges{incoming};a=map(edge.from);
                        assert(a>0&&a<j,'ConnectedCoverage:Ancestor','Every actual physical predecessor must be included.');
                        proof=struct('kind','historical_physical_edge','source_reference',header,'source_from',edge.from,'source_to',k, ...
                            'receipt_reference',header,'receipt_availability','historical_locator');
                        m.edge_enabled=true;m.edge_from=a;context.physical_edge_provenance=proof;
                        physical{end+1,1}=struct('from',a,'to',j,'component_identity',p.component_identity,'provenance',proof);
                    end
                    [report,methodEvidence]=ProjectRecordedMethodDescriptors_v3(report);
                    records{j}=K.project(orbit,report,m,context);pointRows{k}.compact_index=j;
                    pointRows{k}.recorded_method_descriptor_dispositions=methodEvidence;clear orbit report
                end
                clear blockSaved
                row.unmatched_acquisition_blocks=readBlocks;
                metadata=struct('schema','C1-essential-branch-graph-v1','role','uncovered-historical-native-states', ...
                    'displayname',sprintf('Uncovered source %02d',f),'physical_edges',{physical}, ...
                    'record_equalities',{cell(0,1)},'qualified_aliases',{cell(0,1)},'numerical_seams',{cell(0,1)}, ...
                    'source_versions',{{struct('file',methods{1}.file,'sha256',methods{1}.sha256)}});
                checked(source);guard(false);result=K.writeProjections(output,metadata,records,o.MaximumFileBytes);
                guard(true);assert(numel(result.points)==numel(indices),'ConnectedCoverage:Count','No uncovered occurrence may be dropped.');
                for j=1:numel(indices)
                    assert(isequaln(result.record_native_ids{j},records{j}.native_id),'ConnectedCoverage:NativeID','An uncovered occurrence NativeID changed.');
                    digest=lower(reshape(dec2hex(result.record_projection_digests(:,j),2).',1,[]));
                    assert(strcmp(digest,C1ScientificDigest_v3(records{j})),'ConnectedCoverage:Projection','An uncovered scientific projection changed.');
                end
                sample=unique([1;ceil(numel(indices)/2);numel(indices)]);[one,oneR,oneM]=K.loadSolutions(output,sample);[two,twoR,twoM]=K.loadSolutions(output,sample);
                for j=1:numel(sample)
                    k=sample(j);assert(isequaln(K.project(one{j},oneR{j},oneM{j},records{k}.context),records{k}) ...
                        &&isequaln(K.project(two{j},twoR{j},twoM{j},records{k}.context),records{k}), ...
                        'ConnectedCoverage:Read2','Independent native uncovered projections must preserve the literal retained source.');
                end
                row.unmatched_output_reference=reference(output);row.unmatched_projection_read2_verified=true;
                clear one oneR oneM two twoR twoM records result
            end
            row.point_coverage=pointRows;row.returned=true;row.status='ALL_SOURCE_OCCURRENCES_CORE_MATCHED_OR_COMPACTED';row.raw_retirement_eligible=true;
            coverage.rows{f}=row;publish();checked(source);
        catch problem
            coverage.rows{f}.status='RAW_ONLY_HELD_UNSUPPORTED_OR_STORAGE_FAILURE';
            coverage.rows{f}.failure=struct('identifier',problem.identifier,'message',problem.message);coverage.rows{f}.returned=true;
            coverage.rows{f}.raw_retirement_eligible=false;publish();
        end
        coverage.cursor=f+1;publish();
    end
    for f=1:sourceCount,checked(sources{f});end
    for f=1:2,checked(coreReferences{f});end
    checked(censusReference);for f=1:numel(methods),checked(methods{f});end
    coverage.source_posthash=true;coverage.completed=coverage.cursor==sourceCount+1;
    coverage.all_sources_retirement_eligible=coverage.completed&&all(cellfun(@(r)r.raw_retirement_eligible,coverage.rows));
    coverage.all36_retirement_eligible=sourceCount==36&&coverage.all_sources_retirement_eligible;
    if coverage.completed,coverage.status='COMPLETE_ALL_SOURCE_STORAGE_OBSERVATIONS';end
    coverage.finished_utc=stamp();coverage.elapsed_seconds=toc(entered);publish();
    fprintf('C1_CONNECTED_STORAGE_COVERAGE completed=%d eligible=%d held=%d\n',coverage.completed, ...
        sum(cellfun(@(r)r.raw_retirement_eligible,coverage.rows)),sum(cellfun(@(r)~r.raw_retirement_eligible,coverage.rows)));

    function left=remaining(),left=o.MaxWallSeconds-max(toc(entered),unixNow()-startUTC);end
    function guard(final)
        reserve=o.SaveMarginSeconds;if final,reserve=0;end
        assert(remaining()>reserve,'ConnectedCoverage:WallCap','The bounded pure-storage clock/reserve expired; preserve pending/unknown outcomes.');
    end
    function publish()
        guard(true);stage=[receiptFile,'.pending.mat'];assert(~isfile(stage),'ConnectedCoverage:Pending','Never overwrite unknown pending receipt.');
        save(stage,'coverage','-v7');z=load(stage,'coverage');assert(isequaln(z.coverage,coverage),'ConnectedCoverage:Receipt','Plain receipt readback changed.');
        [ok,msg]=movefile(stage,receiptFile,'f');assert(ok,'ConnectedCoverage:Publish','%s',msg);
        summary=rmfield(coverage,'rows');summary.rows=cellfun(@(r)struct('source_reference',r.source_reference,'status',r.status, ...
            'raw_retirement_eligible',r.raw_retirement_eligible,'failure',r.failure,'unmatched_output_reference',r.unmatched_output_reference, ...
            'covered_points',sum(cellfun(@(p)~isempty(p.core_index),r.point_coverage)),'unmatched_retained_occurrences',numel(r.unmatched_old_indices)),coverage.rows,'UniformOutput',false);
        stage=[receiptFile,'.json.pending'];assert(~isfile(stage),'ConnectedCoverage:Pending','Never overwrite unknown pending JSON.');
        text=jsonencode(summary);fid=fopen(stage,'w');assert(fid>=0,'ConnectedCoverage:Open','Cannot open summary stage.');c=onCleanup(@()fclose(fid));assert(fwrite(fid,text,'char')==numel(text),'ConnectedCoverage:Write','Short summary write.');clear c
        [ok,msg]=movefile(stage,[receiptFile,'.json'],'f');assert(ok,'ConnectedCoverage:Publish','%s',msg);
    end
end

function f=coreFact(o,r)
    [~,policy]=RecordedReturnPolicy_v3(r);assert(policy.complete,'ConnectedCoverage:Policy','Complete actual policy is required for core matching.');
    [primitive,classifier]=heads();saved=pick(r,{'schema_version','status','native_status','accepted','full_closure','full_closure_residual','acceptance_gates','classification','primitive'});
    if isfield(saved,'classification'),saved.classification=pick(saved.classification,classifier);end
    if isfield(saved,'primitive'),saved.primitive=pick(saved.primitive,primitive);end
    names={'return_policy','return_policy_name','return_multiplicity','candidate_section_count','candidate_apex_count','accepted_crossing_index','accepted_apex_index','section_relative_event_signature','cyclic_event_signature','primitive_cycle','gait_identification'};
    evidence=struct();for k=1:numel(names),evidence.(names{k})=o.(names{k});end
    evidence.primitive_cycle=pick(evidence.primitive_cycle,primitive);evidence.gait_identification=pick(evidence.gait_identification,classifier);
    f=struct('matrix',[o.initial_state;o.stride_displacement;o.period],'parameter',o.parameter,'mode',o.initial_mode, ...
        'policy_configuration',policy.configuration,'section',o.section_chart,'saved_report',saved,'orbit_heads',evidence);
end
function f=storedCoreFact(c,k)
    f=struct('matrix',c.solution_matrix(:,k),'parameter',c.parameters{k},'mode',c.modes{k}, ...
        'policy_configuration',c.policies{k}.configuration,'section',c.section_charts{k},'saved_report',c.saved_reports{k},'orbit_heads',c.orbit_evidence{k});
end
function [p,g]=heads()
    p={'status','reason','recorded_period','primitive_period','cover_count','drift','primitive_drift','closure_error','mode_closed','checked_cover_bound','state_tolerance','event_phase_tolerance','evidence_level','global_primitivity_proved','event_history_complete','proper_apex_count'};
    g={'contract_version','synchrony_predicate_version','label','alias','abbreviation','status','validated_gait_type','canonical_point_label','canonical_label_qualified','flight_count','flight_count_certain','primitive_flight_count','period_used','descriptive_only','isotropy_proved'};
end
function out=pick(value,allowed)
    assert(isstruct(value)&&isscalar(value),'ConnectedCoverage:Head','Historical heads require literal scalar structs.');out=struct();
    for name=fieldnames(value).',if ismember(name{1},allowed),out.(name{1})=value.(name{1});end,end
end
function cells=asCells(v)
    if iscell(v),cells=v(:);elseif isstruct(v),cells=num2cell(v(:));else,error('ConnectedCoverage:Schema','Expected literal struct/cell rows.');end
end
function r=refHeader(r),r=struct('file',r.file,'sha256',r.sha256,'bytes',r.bytes);end
function r=checked(r)
    assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256','bytes'})),'ConnectedCoverage:Reference','Supply actual FILE/SHA/bytes.');
    r.file=canonical(r.file);s=dir(r.file);assert(isscalar(s)&&~s.isdir&&s.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
        'ConnectedCoverage:Hash','Required immutable file changed: %s',r.file);
end
function r=reference(file)
    file=canonical(file);s=dir(file);assert(isscalar(s)&&~s.isdir,'ConnectedCoverage:Missing','Required source is missing.');r=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',s.bytes);
end
function file=canonical(file),file=char(java.io.File(char(file)).getCanonicalPath());end
function value=unixNow(),value=posixtime(datetime('now','TimeZone','UTC'));end
function value=stamp(),t=datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");value=char(t);end
