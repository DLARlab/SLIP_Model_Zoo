function evidence=PreserveC1ComponentRoleMetadata20261105(manifestReference,currentReference,outputFile,maxWallSeconds)
%PRESERVEC1COMPONENTROLEMETADATA20261105 Index-only historical role sidecar.
% Existing compact outputs and their acceptance/graph flags are unchanged.
% Only explicit known wrapper/control markers are interpreted. An absent
% marker gives no wrapper decision; saved native-report acceptance alone is
% not continuation-wrapper acceptance. No orbit or report variables load.
    entered=tic;u0=unixNow();
    validateattributes(maxWallSeconds,{'double'},{'real','finite','scalar','>',60,'<=',600});
    manifestReference=checked(manifestReference);currentReference=checked(currentReference);
    outputFile=canonical(outputFile);stage=[outputFile,'.pending.mat'];
    assert(isfolder(fileparts(outputFile))&&~isfile(outputFile)&&~isfile(stage), ...
        'RoleEvidence:Fresh','Use fresh owned output/stage paths in an existing directory.');
    methods={reference([mfilename('fullpath'),'.m']);reference(which('BranchSolutionFile_v3')); ...
        reference(which('EssentialBranchSolutionFile_v3'));reference(which('C1ScientificDigest_v3'));reference(which('RoundSHA256_v3'))};
    manifest=jsondecode(fileread(manifestReference.file));sources=asCells(manifest.source_references);
    assert(strcmp(manifest.schema,'C1-native-component-condensation-batch-v1')&&numel(sources)==43, ...
        'RoleEvidence:Roster','Bind the exact original43-source roster.');
    z=load(currentReference.file,'current');current=z.current;clear z
    assert(strcmp(current.schema,'C1-current-component-condensation-frontier-v1')&&current.source_posthash ...
        &&numel(current.rows)==43&&strcmp(C1ScientificDigest_v3(current.configuration),current.configuration_digest), ...
        'RoleEvidence:Map','Use an intact postguarded closed current map.');
    evidence=struct('schema','C1-component-known-role-metadata-sidecar-v1', ...
        'manifest_reference',manifestReference,'current_map_reference',currentReference, ...
        'source_methods',{methods},'rows',{cell(43,1)},'source_posthash',false, ...
        'orbit_variable_loads',0,'report_variable_loads',0,'new_scientific_services',0, ...
        'existing_outputs_rewritten',0,'historical_flags_changed',false, ...
        'scope','Literal known role/wrapper facts supplement prior compact labels. This is storage evidence, not admission, wrapper reconciliation, an edge, identity or branch-completion claim.', ...
        'prior_role_scope','A prior accepted label alone describes saved native-report acceptance; it cannot override explicit nonedge or wrapper-rejected metadata.', ...
        'unretained_metadata_scope','Large unrelated provenance is omitted; original point metadata digests remain literal and source-bound.');
    for j=1:43
        guard(false);source=checked(sources{j});row=current.rows{j};
        assert(isequaln(row.source_reference,source),'RoleEvidence:Occurrence','Current rows must bind the literal source roster by occurrence.');
        ix=BranchSolutionFile_v3.index(source.file);thin=[];out=struct();
        if row.storage_verified
            out=checked(row.output_reference);thin=EssentialBranchSolutionFile_v3.index(out.file);
            assert(numel(thin.points)==numel(ix.points)&&isequal(thin.edges,ix.edges), ...
                'RoleEvidence:StoredTopology','The verified compact output must retain the original occurrence count and literal P table.');
        end
        points=cell(numel(ix.points),1);known=0;mismatch=0;
        for k=1:numel(ix.points)
            md=ix.points{k}.metadata;[role,roleAssessment]=knownRole(md);facts=roleMetadataFacts(md);stored='NOT_STORAGE_VERIFIED';
            if ~isempty(thin),stored=thin.points{k}.provenance.role;end
            edge=find(cellfun(@(e)e.to==k,ix.edges));
            if ~isempty(role)
                known=known+1;
                assert(isempty(edge),'RoleEvidence:RoleEdge','An explicit control/isolated occurrence cannot own a physical predecessor.');
                if ~isempty(thin)&&~strcmp(stored,role),mismatch=mismatch+1;end
            end
            points{k}=struct('source_index',k,'source_metadata_digest',C1ScientificDigest_v3(md), ...
                'known_metadata_role',role,'known_role_assessed',~isempty(role),'role_interpretation',roleAssessment,'literal_role_facts',{facts}, ...
                'stored_role',stored,'role_mismatch',~isempty(thin)&&~isempty(role)&&~strcmp(stored,role), ...
                'physical_predecessor_edge_positions',edge(:).','scientific_flags_relabelled',false);
        end
        evidence.rows{j}=struct('source_reference',source,'storage_verified',row.storage_verified, ...
            'output_reference',out,'point_count',numel(ix.points),'known_marker_count',known, ...
            'stored_role_mismatch_count',mismatch,'points',{points});
        checked(source);if ~isempty(fieldnames(out)),checked(out);end
        clear ix thin points row
    end
    for k=1:numel(methods),checked(methods{k});end
    checked(manifestReference);checked(currentReference);guard(false);
    evidence.source_posthash=true;evidence.elapsed_seconds=toc(entered);
    C1ScientificDigest_v3(evidence);save(stage,'evidence','-v7');
    a=load(stage,'evidence');b=load(stage,'evidence');
    assert(isequaln(a.evidence,evidence)&&isequaln(b.evidence,evidence), ...
        'RoleEvidence:Read2','The plain role evidence changed on independent native reads.');
    d=dir(stage);assert(d.bytes<=8*1024^2,'RoleEvidence:Size','Keep the aggregate role sidecar at most8MiB; retain a larger stage for explicit review.');
    checked(currentReference);for k=1:numel(methods),checked(methods{k});end;guard(true);
    [ok,msg]=movefile(stage,outputFile);assert(ok,'RoleEvidence:Commit','%s',msg);
    fprintf('COMPONENT_ROLE_EVIDENCE_RETURN sources=43 known=%d mismatches=%d bytes=%d SHA=%s\n', ...
        sum(cellfun(@(r)r.known_marker_count,evidence.rows)),sum(cellfun(@(r)r.stored_role_mismatch_count,evidence.rows)),d.bytes,RoundSHA256_v3(outputFile));
    function guard(final)
        reserve=30;if final,reserve=0;end
        assert(max(toc(entered),unixNow()-u0)<maxWallSeconds-reserve,'RoleEvidence:Clock','Keep any incomplete output/stage and original authorities when the storage cap expires.');
    end
end

function facts=roleMetadataFacts(metadata)
    facts=cell(0,1);m=metadata;path='metadata';
    for depth=1:16
        assert(isstruct(m)&&isscalar(m),'RoleEvidence:RoleFacts','Role metadata envelopes must be scalar structures.');
        for key={'role','independent_NONEDGE_control'}
            name=key{1};if isfield(m,name),facts{end+1,1}=struct('field_path',[path,'.',name],'literal_value',m.(name));end
        end
        if ~isfield(m,'provenance')||~isstruct(m.provenance)||~isscalar(m.provenance),break;end
        p=m.provenance;
        for key={'kind','wrapper_accepted','committed','edge_claimed','historical_predictor','qualification_flags_changed'}
            name=key{1};if isfield(p,name),facts{end+1,1}=struct('field_path',[path,'.provenance.',name],'literal_value',p.(name));end
        end
        if ~isfield(p,'original_point_metadata'),break;end
        m=p.original_point_metadata;path=[path,'.provenance.original_point_metadata'];
        assert(depth<16,'RoleEvidence:RoleDepth','Known source metadata wrappers exceed the explicit bound.');
    end
end


function [role,assessment]=knownRole(metadata)
    role='';facts=cell(0,1);m=metadata;path='metadata';
    assessment=struct('status','NO_KNOWN_ROLE_MARKER','reason','','field_path','','actual_provenance_fields',{{}});
    for depth=1:16
        assert(isstruct(m)&&isscalar(m),'RoleEvidence:Metadata','Known role envelopes must be scalar structs.');
        for key={'role','independent_NONEDGE_control'}
            name=key{1};if isfield(m,name),facts{end+1,1}=struct('field_path',[path,'.',name],'literal_value',m.(name));end
        end
        if isfield(m,'independent_NONEDGE_control')
            assert(isequal(m.independent_NONEDGE_control,true),'RoleEvidence:Marker','Do not infer a role from a false/unknown declared control marker.');role='nonedge-control';break
        end
        if ~isfield(m,'provenance')||~isstruct(m.provenance)||~isscalar(m.provenance),break;end
        p=m.provenance;
        for key={'kind','wrapper_accepted','committed','edge_claimed','historical_predictor','qualification_flags_changed'}
            name=key{1};if isfield(p,name),facts{end+1,1}=struct('field_path',[path,'.provenance.',name],'literal_value',p.(name));end
        end
        if isfield(p,'kind')&&strcmp(p.kind,'imported nonedge initial pair'),role='nonedge-control';break;end
        if isfield(p,'kind')&&strcmp(p.kind,'native all-nine return rejected by continuation wrapper')
            assert(isequal(p.wrapper_accepted,false)&&isequal(p.edge_claimed,false),'RoleEvidence:Marker','Wrapper-rejected native records must retain literal false wrapper/edge flags.');role='isolated';break
        end
        if isfield(p,'historical_predictor')&&isequal(p.historical_predictor,true)&&isfield(p,'edge_claimed')&&isequal(p.edge_claimed,false),role='nonedge-control';break;end
        if ~isfield(p,'original_point_metadata'),break;end
        fields={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
        if ~isequal(sort(fieldnames(p)),sort(fields(:)))||~isequal(p.qualification_flags_changed,false)
            assessment=struct('status','UNASSESSED_UNSUPPORTED_PROVENANCE_ENVELOPE', ...
                'reason','No role is inferred through an unrecognized wrapper; literal flag paths and metadata digest are retained independently.', ...
                'field_path',[path,'.provenance'],'actual_provenance_fields',{fieldnames(p)});
            return
        end
        m=p.original_point_metadata;path=[path,'.provenance.original_point_metadata'];
        assert(depth<16,'RoleEvidence:Depth','The known provenance wrapper depth was exceeded.');
    end
    if ~isempty(role),assessment.status='KNOWN_LITERAL_METADATA_ROLE';end
end
function r=checked(r)
    assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256','bytes'})),'RoleEvidence:Reference','Use literal FILE/SHA/bytes.');
    r.file=canonical(r.file);s=dir(r.file);
    assert(isscalar(s)&&~s.isdir&&s.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
        'RoleEvidence:Hash','An immutable storage authority changed: %s.',r.file);
end
function r=reference(f)
    f=canonical(f);s=dir(f);assert(isscalar(s)&&~s.isdir,'RoleEvidence:Method','A storage provider is missing.');
    r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',s.bytes);
end
function c=asCells(x),if iscell(x),c=x(:);elseif isstruct(x),c=num2cell(x(:));else,error('RoleEvidence:Cells','Expected the literal cell/struct source roster.');end;end
function f=canonical(f),f=char(java.io.File(char(f)).getCanonicalPath());end
function u=unixNow(),u=posixtime(datetime('now','TimeZone','UTC'));end
