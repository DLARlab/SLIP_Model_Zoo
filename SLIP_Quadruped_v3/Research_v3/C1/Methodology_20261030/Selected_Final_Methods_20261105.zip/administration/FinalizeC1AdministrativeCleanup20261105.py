#!/usr/bin/env python3
"""Root-owned, post-close administrative cleanup; never parses a MAT payload.

Prepare only:  python FILE --authority ROOT_AUTHORITY.json
Root executes: python FILE --authority ROOT_AUTHORITY.json --execute

Authority JSON schema: V3-final-admin-cleanup-authority-v1
Required: all_owned_workers_closed=true, final_facts_and_smoke_passed=true,
proof_references=[{file,sha256,bytes},...], proof_roles={final_facts:FILE,
final_smoke:FILE}. These bind the actual final native MAT authorities. Optional
coverage_indexes=[{native_reference:{...},index_reference:{...}},...] enables
retirement of individual scientific sources only where the closed JSON index
explicitly marks that exact FILE/SHA/bytes eligible. Optional
protected_references=[...] adds immutable guards. Optional covered_stage_retirements
and covered_test_payloads contain {reference:{...},proof_references:[...],
custody_covered:true,no_unresolved_scientific_payload:true}. Root explicitly
supplies those exact-byte data-only stage/test-custody authorities; no filename
alone implies coverage.

Without --execute this prints a proposed count only. An existing ledger or
unknown stage refuses; interrupted cleanup needs explicit Root reconciliation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile

C1 = Path(__file__).resolve().parents[1]
AUDITS = C1 / "Audits"
INVENTORY = AUDITS / "V3_Final_Cleanup_Admin_Inventory_20261105.json"
LEDGER = AUDITS / "V3_Final_Cleanup_Ledger_20261105.json"
METHOD_ZIP = C1 / "Methodology_20261030/Selected_Final_Methods_20261105.zip"
LIVE = {
    "RunC1Continuation_v3.m", "ReadC1WorkingCoreSetSnapshot_v3.m",
    "PKFlightPointCheck_v3.m", "CheckC1PKOrbitFlights_v3.m",
    "CheckC1PKFlightInterval_v3.m", "AllFlightClearanceBounds_v3.m",
}
ACTION_KEYS = {"removed", "deleted", "deleted_sources", "deleted_raw_sources", "removed_sources", "removed_files", "retired", "retired_sources", "retired_files", "moved"}
SAFE_ACTION_FIELDS = {
    "file", "path", "relative_path", "sha256", "bytes", "from", "to",
    "classification", "reason", "condition", "loss_disclosure",
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def reference(path):
    path = Path(path).resolve()
    return {"file": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


def checked(ref):
    require(isinstance(ref, dict) and all(k in ref for k in ("file", "sha256", "bytes")),
            "Use exact FILE/SHA/bytes references.")
    path = Path(ref["file"])
    require(path.is_file() and str(path.resolve()) == ref["file"], f"Nonliteral/missing path: {path}")
    require(path.stat().st_size == ref["bytes"] and sha(path) == ref["sha256"], f"Header changed: {path}")
    return path


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def inside(path):
    path = Path(path).resolve()
    require(path.is_relative_to(C1), f"Outside C1 is never selected: {path}")
    require(not any(p in {".git", "Tests_v3", "CoreTests_v3"} for p in path.relative_to(C1).parts),
            f"Unrelated tests/Git are protected: {path}")
    return path


def ordinary_text(path):
    """Distinguish source preimages from opaque/binary beforeimages only."""
    if path.stat().st_size > 8 * 1024 * 1024:
        return False
    data = path.read_bytes()
    if b"\0" in data:
        return False
    try:
        data.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def atomic_json(path, value):
    stage = Path(str(path) + ".pending")
    require(not stage.exists(), f"Unknown stage must be reconciled: {stage}")
    data = (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    with stage.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    require(json.loads(stage.read_text()) == value, "Administrative JSON readback changed.")
    os.replace(stage, path)


def eligible_sources(authority, protected):
    allowed = {}
    summaries = []
    for pair in authority.get("coverage_indexes", []):
        native = checked(pair["native_reference"])
        index = checked(pair["index_reference"])
        protected.add(str(native))
        value = load(index)
        require(value.get("completed") is True and value.get("source_posthash") is True,
                f"Coverage index is not complete/postguarded: {index}")
        schema = value.get("schema")
        require(schema in {"C1-connected-raw-storage-coverage-v1", "C1-historical-essential-audit-facts-v1"},
                f"Unsupported retirement authority: {schema}")
        summaries.append({"native_reference": pair["native_reference"], "index_reference": pair["index_reference"],
                          "closed_metadata_index": value})
        for retained in value.get("core_references", []):
            protected.add(str(checked(retained)))
        for row in value["rows"]:
            retained = row.get("unmatched_output_reference", {})
            if retained:
                protected.add(str(checked(retained)))
            yes = row.get("raw_retirement_eligible") is True if schema.startswith("C1-connected") else row.get("retirement_eligible") is True
            if yes:
                ref = row["source_reference"]
                key = str(inside(ref["file"]))
                if key in allowed:
                    require(allowed[key] == ref, "Conflicting coverage for one literal file.")
                allowed[key] = ref
    return allowed, summaries


def compact_action(value):
    if isinstance(value, dict):
        return {k: compact_action(v) for k, v in value.items() if k in SAFE_ACTION_FIELDS}
    if isinstance(value, list):
        return [compact_action(v) for v in value]
    return value


def receipt_header(path):
    value = load(path)
    out = {"document_reference": reference(path), "schema": value.get("schema", ""),
           "executed_completed": value.get("completed") is True}
    for key in ("scope", "reason", "loss_disclosure", "started_utc", "finished_utc",
                "logical_bytes_removed", "logical_source_bytes_removed", "protected_posthash_verified",
                "full_sha_preflight_passed", "physical_reclaim_not_measured", "physical_space_reclaimed_not_measured",
                "source_pack", "archive_reference", "published_catalog_reference", "protected_authority_references"):
        if key in value:
            out[key] = value[key]
    # Only an actually completed receipt supplies historical actions. A plan
    # remains a document header and cannot be relabelled an executed deletion.
    if out["executed_completed"]:
        out["executed_actions"] = {k: compact_action(value[k]) for k in ACTION_KEYS if k in value}
    return out


def prepare(authority_file):
    inventory = load(INVENTORY)
    authority_ref = reference(authority_file)
    authority = load(checked(authority_ref))
    require(authority.get("schema") == "V3-final-admin-cleanup-authority-v1", "Unknown Root authority schema.")
    require(authority.get("all_owned_workers_closed") is True and authority.get("final_facts_and_smoke_passed") is True,
            "Root must provide actual closed-worker and passed-final-facts/smoke authority.")
    proof_refs = authority.get("proof_references", [])
    require(len(proof_refs) >= 2, "Bind actual final facts and final smoke native proof references.")
    proof_paths = {r["file"] for r in proof_refs}
    roles = authority.get("proof_roles", {})
    require(set(roles) == {"final_facts", "final_smoke"} and all(p in proof_paths and Path(p).suffix.lower() == ".mat" for p in roles.values()),
            "Explicitly bind final_facts and final_smoke to their native proof references.")
    protected = {str(checked(r)) for r in proof_refs + authority.get("protected_references", [])}
    protected.add(str(Path(authority_file).resolve()))
    protected_replacements = []
    old_p1_json = str(AUDITS / "P1_v2_Native_Reference_Audit.json")
    p1_transport = AUDITS / "P1_Reference_JSON_Transport_20261105.mat"
    for item in inventory["items"]:
        if item["classification"].startswith("KEEP_"):
            if item["file"] == old_p1_json and not Path(item["file"]).exists():
                require(p1_transport.is_file(), "The retired P1 JSON requires its actual native subset-transport proof.")
                replacement = reference(p1_transport)
                protected.add(replacement["file"])
                protected_replacements.append({"retired_file": item["file"], "native_transport_reference": replacement,
                                               "authority": "Root explicitly reported exact native subset PASS and retirement of the old JSON."})
                continue
            require(Path(item["file"]).is_file(), f"Requested protected file is missing; reconcile explicitly: {item['file']}")
            protected.add(item["file"])
    protected.update(str((C1 / name).resolve()) for name in LIVE)
    explicit_custody = {}
    for kind in ("covered_stage_retirements", "covered_test_payloads"):
        for entry in authority.get(kind, []):
            require(entry.get("custody_covered") is True and entry.get("no_unresolved_scientific_payload") is True,
                    "Root must explicitly establish exact stage/test custody without unresolved scientific payload.")
            ref = entry["reference"]
            path = inside(checked(ref))
            refs = entry.get("proof_references", [])
            require(refs, "An exact stage/test retirement must bind actual passed native proof references.")
            for evidence in refs:
                protected.add(str(checked(evidence)))
            if kind == "covered_stage_retirements":
                require(path.name.endswith((".pending.mat", ".thin.pending.mat", ".essential.pending.mat")),
                        "Only explicit derived projection stage names use the stage-custody exception.")
            else:
                require(path.parent == C1 / ".work_reusable_continuation_20261105/Validation"
                        and path.name in {"PublicBranch01.mat", "PublicBranch01_run_checkpoint.mat", "UnknownIntent.mat"},
                        "Only the three known bounded validation payloads use test-custody retirement.")
            key = str(path)
            require(key not in protected, "A current protected proof cannot also be an obsolete stage/test.")
            require(key not in explicit_custody, "List an explicit stage/test only once.")
            explicit_custody[key] = {"reference": ref, "kind": kind, "proof_references": refs}
    coverage_index_paths = {r["index_reference"]["file"] for r in authority.get("coverage_indexes", [])}
    # Future proof stores/mirrors not present in the old inventory are
    # protected automatically. Root may consolidate mirrors later by an
    # explicit distinct action; this executor never guesses new facts names.
    for path in AUDITS.iterdir():
        if path.is_file() and (path.suffix == ".mat" or "Facts" in path.name or "Smoke" in path.name):
            if str(path.resolve()) not in {r["file"] for r in inventory["items"]} and str(path.resolve()) not in explicit_custody and str(path.resolve()) not in coverage_index_paths:
                protected.add(str(path.resolve()))
    allowed, coverage_summaries = eligible_sources(authority, protected)
    for key, entry in explicit_custody.items():
        allowed[key] = entry["reference"]
    source_rows = inventory["selected_final_method_zip_proposal"]["members"]
    members = {r["member"]: Path(r["file"]).resolve() for r in source_rows}
    inventory_paths = {r["file"] for r in inventory["items"]}
    new_root_methods = [inside(p) for p in C1.glob("*.m")
                        if str(p.resolve()) not in inventory_paths and p.name not in LIVE
                        and str(p.resolve()) not in protected]
    for path in new_root_methods:
        members[path.name] = path
    for extra in (C1 / "AuditC1P1v2Reference_v3.m", C1 / ".work_pk15h_20261104/PKFlightCheckedMap20261104.m",
                  C1 / "CompleteRemaining53SnapshotBytes20261105.m", C1 / "PreserveSmallHistoricalAuditHolds20261105.m"):
        require(extra.is_file(), f"Required final scientific provider missing: {extra}")
        members[extra.relative_to(C1).as_posix()] = extra.resolve()
    members["administration/FinalizeC1AdministrativeCleanup20261105.py"] = Path(__file__).resolve()
    method_rows = []
    for name, path in members.items():
        inside(path)
        require(path.is_file(), f"Selected source missing: {path}")
        # Intentionally hash FINAL bytes now, including the final canonical
        # exporter; do not enforce a stale construction-version checksum.
        method_rows.append({"member": name, "reference": reference(path)})
    packed_paths = {r["reference"]["file"] for r in method_rows}
    candidates = {}
    held = []
    for item in inventory["items"]:
        path = inside(item["file"])
        if not path.is_file() or str(path) in protected:
            continue
        cls = item["classification"]
        work = any(p.startswith(".work") for p in path.relative_to(C1).parts)
        administrative = cls.startswith(("RETIRE_WORKDIR_", "RETIRE_OBSOLETE_LOOSE_", "RETIRE_NONESSENTIAL_LOG_", "MERGE_ADMIN_", "PACK_FINAL_METHOD_"))
        if not administrative and str(path) not in allowed:
            continue
        opaque = path.suffix.lower() == ".mat" or ("before" in path.name.lower() and not ordinary_text(path))
        if opaque and str(path) not in allowed:
            held.append({"file": str(path), "reason": "Scientific/opaque payload has no explicit completed native coverage; retained."})
            continue
        if str(path) in allowed:
            ref = allowed[str(path)]
            checked(ref)
        else:
            ref = reference(path)
        if cls.startswith("PACK_FINAL_METHOD_"):
            require(str(path) in packed_paths, "A selected final method must enter the lean pack before retirement.")
        candidates[str(path)] = {"reference": ref, "classification": cls, "reason": item["reason"], "work_file": work}
    # Catch construction files created after the inventory, but never infer
    # coverage for an opaque scientific source merely from its work folder.
    for workdir in C1.iterdir():
        if not workdir.is_dir() or not workdir.name.startswith(".work"):
            continue
        for path in workdir.rglob("*"):
            if not path.is_file():
                continue
            path = inside(path)
            key = str(path)
            if key in protected or key in candidates:
                continue
            opaque = path.suffix.lower() == ".mat" or not (ordinary_text(path) or path.suffix.lower() in {".png", ".jpg", ".jpeg", ".svg"})
            if opaque and key not in allowed:
                held.append({"file": key, "reason": "Opaque/scientific work payload lacks explicit completed native coverage; retained."})
                continue
            ref = allowed[key] if key in allowed else reference(path)
            checked(ref)
            candidates[key] = {"reference": ref, "classification": "POST_INVENTORY_CLOSED_WORK_FILE", "reason": "Root-authorized closed construction/test work; selected final source is packed once."}
    # Post-inventory final retention helpers are archived once before their
    # loose C1 entry points retire. The six runtime APIs/protected files win.
    for path in new_root_methods:
        key = str(path)
        require(key in packed_paths and key not in protected and path.name not in LIVE,
                "A newly discovered loose helper must enter the final source pack before retirement.")
        candidates[key] = {"reference": reference(path), "classification": "POST_INVENTORY_FINAL_ROOT_METHOD_PACKED",
                           "reason": "Final new C1 retention helper preserved byte-for-byte once in the lean method ZIP; not a seventh runtime API."}
    for key, entry in explicit_custody.items():
        require(key not in protected, "Explicit obsolete custody conflicts with a retained final proof.")
        candidates[key] = {"reference": entry["reference"], "classification": entry["kind"],
                           "reason": "Root supplied exact-byte passed-stage/test custody; no unresolved scientific payload.",
                           "proof_references": entry["proof_references"]}
    # Include new routine root logs and intermediate V3 admin documents only
    # after preserving their concise ledger headers, never new MAT proofs.
    documents = []
    for path in AUDITS.glob("V3_*.json"):
        if str(path.resolve()) in protected or path == LEDGER:
            continue
        value = load(path)
        if not isinstance(value, dict):
            continue
        documents.append(receipt_header(path))
        if "facts" not in value.get("schema", "").lower():
            candidates[str(path.resolve())] = {"reference": reference(path), "classification": "MERGED_ADMIN_DOCUMENT", "reason": "Concise actual action/loss/proof headers retained in the one final ledger."}
    for path in AUDITS.glob("*.log"):
        if str(path.resolve()) not in protected:
            candidates[str(path.resolve())] = {"reference": reference(path), "classification": "CLOSED_ROUTINE_LOG", "reason": "Root supplied all-consumer closure; final native audits and ledger retain outcomes."}
    for entry in coverage_summaries:
        index = entry["index_reference"]
        if index["file"] not in protected:
            candidates[index["file"]] = {"reference": index, "classification": "FINAL_NATIVE_METADATA_MIRROR_IN_LEDGER",
                                          "reason": "Complete closed metadata index copied into the one ledger; native MAT proof remains protected."}
    # Raw holds, protected proofs and unrelated files always win.
    for key in list(candidates):
        if key in protected:
            del candidates[key]
    guards = [reference(p) for p in sorted(protected) if Path(p).is_file()]
    return {"authority_reference": authority_ref, "root_authority": authority, "inventory_reference": reference(INVENTORY),
            "proof_references": proof_refs, "protected_references": guards, "protected_whitelist_replacements": protected_replacements,
            "historical_cleanup_receipts": documents,
            "selected_method_members": method_rows, "closed_coverage_indexes": coverage_summaries,
            "candidates": list(candidates.values()), "held": list({r["file"]: r for r in held}.values())}


def execute(plan):
    require(not LEDGER.exists() and not METHOD_ZIP.exists(), "Existing final ledger/ZIP requires Root reconciliation; never overwrite.")
    for row in plan["candidates"]:
        checked(row["reference"])
    for ref in plan["protected_references"]:
        checked(ref)
    stage = Path(str(METHOD_ZIP) + ".pending")
    require(not stage.exists(), "Unknown method ZIP stage is held.")
    with zipfile.ZipFile(stage, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for row in plan["selected_method_members"]:
            path = checked(row["reference"])
            archive.writestr(row["member"], path.read_bytes())
    with zipfile.ZipFile(stage) as archive:
        require(archive.testzip() is None, "Method ZIP integrity failed.")
        for row in plan["selected_method_members"]:
            require(hashlib.sha256(archive.read(row["member"])).hexdigest() == row["reference"]["sha256"], "Method archive readback changed.")
    for row in plan["selected_method_members"]:
        checked(row["reference"])
    os.replace(stage, METHOD_ZIP)
    ledger = {"schema": "V3-final-cleanup-ledger-20261105-v1", "completed": False,
              "authority_reference": plan["authority_reference"], "root_authority": plan["root_authority"],
              "inventory_reference": plan["inventory_reference"],
              "scope": "Administrative cleanup only. Historical native decisions and unknown/pending states are not upgraded.",
              "method_zip_reference": reference(METHOD_ZIP), "method_members": plan["selected_method_members"],
              "historical_cleanup_receipts": plan["historical_cleanup_receipts"],
              "closed_native_coverage_indexes": plan["closed_coverage_indexes"],
              "final_native_proof_references": plan["proof_references"], "protected_references": plan["protected_references"],
              "protected_whitelist_replacements": plan["protected_whitelist_replacements"],
              "held_sources": plan["held"], "planned_retirements": plan["candidates"], "removed": [], "pending_action": {},
              "loss_disclosure": ["Obsolete console/test/patch/launch/source-version detail is retired. Selected final methods are retained once.",
                                  "Scientific sources are excluded unless an explicit completed native coverage index marks their exact bytes eligible.",
                                  "Dense diagnostic/runtime detail omitted by earlier native projections remains omitted; no new scientific claim follows."],
              "physical_reclaim_not_measured": True}
    atomic_json(LEDGER, ledger)
    expected_ledger_sha = sha(LEDGER)
    for row in plan["candidates"]:
        checked(plan["authority_reference"])
        checked(ledger["method_zip_reference"])
        require(sha(LEDGER) == expected_ledger_sha, "Owned ledger changed; stop before unlink.")
        ref = row["reference"]
        path = inside(checked(ref))
        ledger["pending_action"] = row
        atomic_json(LEDGER, ledger)
        path.unlink()
        require(not path.exists(), f"Unlink did not retire the selected name: {path}")
        ledger["removed"].append(row)
        ledger["pending_action"] = {}
        atomic_json(LEDGER, ledger)
        expected_ledger_sha = sha(LEDGER)
    for ref in plan["protected_references"]:
        checked(ref)
    # Remove only empty private work directories. Nonempty raw holds survive.
    for workdir in C1.iterdir():
        if workdir.is_dir() and workdir.name.startswith(".work"):
            for directory in sorted((p for p in workdir.rglob("*") if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
                if not any(directory.iterdir()):
                    directory.rmdir()
            if not any(workdir.iterdir()):
                workdir.rmdir()
    ledger["completed"] = True
    ledger["logical_bytes_removed"] = sum(r["reference"]["bytes"] for r in ledger["removed"])
    ledger["protected_posthash_verified"] = True
    atomic_json(LEDGER, ledger)
    print(json.dumps({"completed": True, "ledger": reference(LEDGER), "method_zip": reference(METHOD_ZIP),
                      "retired_names": len(ledger["removed"]), "logical_bytes": ledger["logical_bytes_removed"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authority", required=True, type=Path)
    parser.add_argument("--execute", action="store_true", help="Root only, after actual final Native closures and review.")
    args = parser.parse_args()
    proposed = prepare(args.authority)
    if args.execute:
        execute(proposed)
    else:
        print(json.dumps({"execute": False, "candidate_count": len(proposed["candidates"]),
                          "candidate_logical_bytes": sum(r["reference"]["bytes"] for r in proposed["candidates"]),
                          "method_member_count": len(proposed["selected_method_members"]), "held": proposed["held"]}, indent=2))
