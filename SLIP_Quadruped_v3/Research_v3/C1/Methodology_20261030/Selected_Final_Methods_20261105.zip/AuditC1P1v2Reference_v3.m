function audit=AuditC1P1v2Reference_v3(options)
%AUDITC1P1V2REFERENCE_V3 Native scalar audit of all nine original P1 branches.
% Scheduled v2 means are optional reference data, never autonomous-v3 admission.
% The unchanged legacy API has no ODE deadline hook: optional calls are guarded
% before/after each call only, and a late call supplies no qualified mean value.
    if nargin<1,options=struct();end
    o=struct('MaxWallSeconds',1800,'ComputeScheduledReference',false);
    assert(isstruct(options)&&isscalar(options)&&all(ismember(fieldnames(options),fieldnames(o))),'P1Audit:Options');
    keys=fieldnames(options);for k=1:numel(keys),o.(keys{k})=options.(keys{k});end
    validateattributes(o.MaxWallSeconds,{'double'},{'real','scalar','finite','positive','<=',1800});
    assert(islogical(o.ComputeScheduledReference)&&isscalar(o.ComputeScheduledReference),'P1Audit:Options');
    root=fileparts(which('C1RunBudget_v3'));repo=fileparts(fileparts(fileparts(root)));
    legacy=fullfile(repo,'SLIP_Quadruped');budget=C1RunBudget_v3();
    deadlineUTC=min(budget.research_deadline_unix_seconds,nowUTC()+o.MaxWallSeconds);
    deadlineMono=min(budget.research_deadline_monotonic_ns,nano()+o.MaxWallSeconds*1e9);
    workUTC=deadlineUTC-20;workMono=deadlineMono-20e9;guard();
    oldPath=path;restore=onCleanup(@()path(oldPath));
    dynamicRoot=fullfile(legacy,'1_Dynamic_Frameworks','v2');
    managementRoot=fullfile(legacy,'4_Solution_Management');
    addpath(dynamicRoot,managementRoot,'-begin');
    expectedZero=fullfile(dynamicRoot,'Quadrupedal_ZeroFun_v2.m');
    expectedTiming=fullfile(managementRoot,'EventTimingRegulation.m');
    assert(strcmp(which('Quadrupedal_ZeroFun_v2'),expectedZero)&&strcmp(which('EventTimingRegulation'),expectedTiming),'P1Audit:Resolver');
    labels={'PK','BG','BE','FG','FE','HG','HE','GG','GE'};
    filenames={'PK_20_2.mat','BD1_20_2_BG.mat','BD1_20_2_BE.mat','BD1_20_2_FG.mat', ...
        'BD1_20_2_FE.mat','BD1_20_2_HG.mat','BD1_20_2_HE.mat','BD1_20_2_GG.mat','BD1_20_2_GE.mat'};
    roadmap=fullfile(legacy,'P1_Breaking_Symmetries_Leads_to_Diverse_Qudrupedal_Gaits','1_Roadmap');
    names={'AuditC1P1v2Reference_v3','C1RunBudget_v3','LegacyStateAdapter_v3','LegacyParameterAdapter_v3', ...
        'LegacyEventAdapter_v3','QuadrupedSchema_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3', ...
        'ContinuousDynamics_v3','QuadrupedAdmissibility_v3','ResetMap_v3','Quadrupedal_ZeroFun_v2','EventTimingRegulation'};
    code=struct();for k=1:numel(names)
        f=which(names{k});assert(~isempty(f),'P1Audit:Code');code.(names{k})=reference(f);
    end
    audit=struct('schema','C1-original-P1-v2-native-reference-audit-v1','options',o,'budget',budget, ...
        'source_code',code,'branches',{{}},'started_utc',stamp(),'completed_utc','', ...
        'all_nine_branches_scalar_complete',false,'scheduled_reference_complete',false, ...
        'source_code_posthash',false,'source_files_posthash',false,'MATLAB_path_restored',false, ...
        'v3_admission_claimed',false,'all_nine_gate_claimed',false,'branch_attachment_claimed',false, ...
        'scheduled_integration_clock_scope','Unmodified v2 API: before/after call checks; no internal ODE OutputFcn guard.', ...
        'mechanical_energy_policy','lossless state reorder, explicit v2-exact parameter semantics, right-limit scheduled initial mode', ...
        'critical_apex_references',struct('FG',5.91164915,'HE',6.13622288, ...
        'status','Provided refined reference apex velocities; no critical energy/mean inferred from nearby stored columns.'), ...
        'failure',struct());
    schema=QuadrupedSchema_v3.shared();oldTD=[1,3,5,7];oldLO=oldTD+1;
    newIDs=LegacyEventAdapter_v3.toV3(1:8);newLeg=schema.Event.LegIndices(newIDs(oldTD));
    try
        % Complete the inexpensive scalar baseline before attempting any ODE.
        for b=1:numel(labels)
            guard();file=fullfile(roadmap,filenames{b});r=reference(file);
            header=whos('-file',file);j=find(strcmp({header.name},'results'));
            assert(isscalar(j)&&strcmp(header(j).class,'double')&&numel(header(j).size)==2 ...
                &&header(j).size(1)==29&&header(j).size(2)>0&&~header(j).complex,'P1Audit:RawSchema');
            loaded=load(file,'results');raw=loaded.results;guard();assert(strcmp(RoundSHA256_v3(file),r.sha256),'P1Audit:SourceChanged');
            N=size(raw,2);row=emptyBranch(labels{b},r,N);row.saved_variable_metadata=header;
            row.raw_results=raw;row.stored_initial_dx=raw(1,:).';row.stored_initial_dy=raw(3,:).';row.stored_period=raw(22,:).';
            for c=1:N
                if remaining()<=0,break;end
                try
                    column=raw(:,c);assert(isreal(column)&&all(isfinite(column([1:24,26:29]))),'P1Audit:Finite');
                    X=column(1:13);E=column(14:22);pOld=column(23:29);
                    row.raw_column_finite(c)=all(isfinite(column));
                    assert(isfinite(E(9))&&E(9)>0,'P1Audit:Period');
                    E=EventTimingRegulation(E);row.regulated_legacy_timings(:,c)=E(:);
                    x=LegacyStateAdapter_v3.toV3State([0;X]);
                    assert(isequal(LegacyStateAdapter_v3.fromV3State(x),[0;X]),'P1Audit:LosslessState');
                    [p,conversion]=LegacyParameterAdapter_v3.toV3(pOld,'v2-exact');
                    next=E(E>0);probe=min(next)/2;q=false(4,1);
                    for leg=1:4
                        td=E(oldTD(leg));lo=E(oldLO(leg));
                        q(newLeg(leg))=(td<lo&&probe>td&&probe<lo)||(td>lo&&(probe<lo||probe>td));
                    end
                    row.initial_timing_boundary(c)=any(E(1:8)==0);row.mode_v3(:,c)=q;
                    row.native_initial_state(:,c)=x;row.native_physical_parameter(:,c)=p;
                    row.parameter_conversion{c}=conversion;
                    [energy,er]=QuadrupedEnergy_v3.evaluate(x,q,p);
                    row.mechanical_energy(c)=energy;row.energy_available(c)=isfinite(energy);
                    row.energy_conservation_applicable(c)=er.conservation_applicable;
                    f=ContinuousDynamics_v3(schema);flow=f.evaluate(0,x,q,p);
                    physical=f.admissibilityReport(x,q,p,'accepted-state');
                    row.native_initial_geometry_valid(c)=physical.global_validity;
                    row.initial_downward_apex(c)=abs(x(schema.State.dy))<=1e-8&&flow(schema.State.dy)<-1e-8;
                    row.initial_vertical_acceleration(c)=flow(schema.State.dy);
                    row.scalar_processed(c)=true;
                catch problem,row.scalar_failure{c}=failure(problem);row.scalar_processed(c)=true;
                end
            end
            row.scalar_complete=all(row.scalar_processed);audit.branches{end+1}=row;
            fprintf('P1 v2 %s scalar %d/%d energy %d\n',labels{b},sum(row.scalar_processed),N,sum(row.energy_available));
            if remaining()<=0,break;end
        end
        if o.ComputeScheduledReference
            for b=1:numel(audit.branches)
                row=audit.branches{b};raw=row.raw_results;
                for c=1:size(raw,2)
                    if remaining()<=0,break;end
                    row.scheduled_attempted(c)=true;started=nano();
                    try
                        guard();verifyCode();
                        [residual,T,Y,P]=Quadrupedal_ZeroFun_v2(raw(1:13,c),raw(14:22,c),raw(23:29,c),'skipSolve');
                        timely=remaining()>0;row.scheduled_timely(c)=timely;
                        assert(timely,'P1Audit:LateLegacyCall','The unmodified scheduled call returned after the work deadline.');
                        assert(isnumeric(Y)&&size(Y,2)==14&&~isempty(Y)&&all(isfinite(Y(:))) ...
                            &&isnumeric(T)&&numel(T)==size(Y,1)&&all(isfinite(T(:))) ...
                            &&numel(P)==16&&isfinite(P(9))&&P(9)>0,'P1Audit:ScheduledShape');
                        row.scheduled_terminal_time_error(c)=abs(T(end)-P(9));
                        assert(abs(T(1))<=1e-10&&row.scheduled_terminal_time_error(c)<=1e-9*max(1,P(9)),'P1Audit:ScheduledTime');
                        assert(isequal(P(1:9).',row.regulated_legacy_timings(:,c)),'P1Audit:ScheduleChanged');
                        row.scheduled_signed_stride(c)=Y(end,1)-Y(1,1);
                        row.scheduled_signed_mean_U(c)=row.scheduled_signed_stride(c)/P(9);
                        row.scheduled_period(c)=P(9);row.scheduled_mean_available(c)=true;
                        row.scheduled_full13_closure_inf(c)=norm(Y(end,2:14)-Y(1,2:14),Inf);
                        row.scheduled_zero_function_residual_inf(c)=norm(residual,Inf);
                        row.scheduled_terminal_dy(c)=Y(end,4);
                    catch problem,row.scheduled_failure{c}=failure(problem);
                    end
                    row.scheduled_elapsed_seconds(c)=(nano()-started)/1e9;
                end
                row.scheduled_complete=all(row.scheduled_attempted);audit.branches{b}=row;
                fprintf('P1 v2 %s scheduled %d/%d mean %d\n',row.label,sum(row.scheduled_attempted),size(raw,2),sum(row.scheduled_mean_available));
                if remaining()<=0,break;end
            end
        end
        verifyCode();audit.source_code_posthash=true;
        for b=1:numel(audit.branches)
            row=audit.branches{b};assert(strcmp(RoundSHA256_v3(row.source.file),row.source.sha256),'P1Audit:SourceChanged');
        end
        audit.source_files_posthash=true;
    catch problem,audit.failure=failure(problem);
    end
    clear restore;assert(strcmp(path,oldPath),'P1Audit:RestorePath');audit.MATLAB_path_restored=true;
    audit.all_nine_branches_scalar_complete=numel(audit.branches)==9&&all(cellfun(@(r)r.scalar_complete,audit.branches));
    audit.scheduled_reference_complete=o.ComputeScheduledReference&&numel(audit.branches)==9 ...
        &&all(cellfun(@(r)r.scheduled_complete,audit.branches));
    audit.native_energy_values_complete=numel(audit.branches)==9&&all(cellfun(@(r)all(r.energy_available),audit.branches));
    audit.scheduled_mean_values_complete=o.ComputeScheduledReference&&numel(audit.branches)==9 ...
        &&all(cellfun(@(r)all(r.scheduled_mean_available),audit.branches));
    for b=1:numel(audit.branches)
        row=audit.branches{b};eligible=row.energy_available&row.native_initial_geometry_valid&row.initial_downward_apex;
        row.ranges=struct('stored_initial_dx',bounds(row.stored_initial_dx), ...
            'stored_period',bounds(row.stored_period),'mechanical_energy',bounds(row.mechanical_energy(row.energy_available)), ...
            'initial_geometry_downward_apex_energy',bounds(row.mechanical_energy(eligible)), ...
            'scheduled_signed_mean_U',bounds(row.scheduled_signed_mean_U(row.scheduled_mean_available)));
        audit.branches{b}=row;
    end
    audit.completed_utc=stamp();audit.complete=audit.all_nine_branches_scalar_complete ...
        &&audit.native_energy_values_complete&&(~o.ComputeScheduledReference||audit.scheduled_mean_values_complete) ...
        &&audit.source_code_posthash&&audit.source_files_posthash&&audit.MATLAB_path_restored;
    assert(nowUTC()<deadlineUTC&&nano()<deadlineMono,'P1Audit:PublicationBudget');
    matFile=fullfile(root,'Audits','P1_v2_Native_Reference_Audit.mat');jsonFile=strrep(matFile,'.mat','.json');
    assert(~isfile(matFile)&&~isfile(jsonFile),'P1Audit:Existing','Use fresh output names; no original audit is overwritten.');
    save([matFile '.pending.mat'],'audit','-v7');saved=load([matFile '.pending.mat'],'audit');assert(isequaln(saved.audit,audit),'P1Audit:Readback');
    [ok,msg]=movefile([matFile '.pending.mat'],matFile);assert(ok,'P1Audit:Publish','%s',msg);
    plain=audit;for b=1:numel(plain.branches),plain.branches{b}=rmfield(plain.branches{b},{'raw_results','native_initial_state','native_physical_parameter','parameter_conversion'});end
    fid=fopen([jsonFile '.pending.json'],'w');assert(fid>=0,'P1Audit:JSON');cleanup=onCleanup(@()fclose(fid));
    fprintf(fid,'%s\n',jsonencode(plain,PrettyPrint=true));clear cleanup
    assert(isequaln(jsondecode(fileread([jsonFile '.pending.json'])),jsondecode(jsonencode(plain))),'P1Audit:JSONReadback');
    [ok,msg]=movefile([jsonFile '.pending.json'],jsonFile);assert(ok,'P1Audit:Publish','%s',msg);
    assert(nowUTC()<deadlineUTC&&nano()<deadlineMono,'P1Audit:PublicationBudget','Published files exist, but final publication returned after the original/local deadline.');
    function value=remaining(),value=min(workUTC-nowUTC(),(workMono-nano())/1e9);end
    function guard(),assert(remaining()>0,'P1Audit:Budget','Original research/local UTC or monotonic work deadline expired.');end
    function verifyCode()
        fields=fieldnames(code);for z=1:numel(fields)
            r=code.(fields{z});assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'P1Audit:CodeChanged');
        end
    end
end
function r=emptyBranch(label,source,N)
    r=struct('label',label,'source',source,'columns',(1:N).','source_variable','results', ...
        'original_validity_flags_available',false,'original_validity_flags_status','No documented flag rows in results29; other variables metadata only.', ...
        'initial_mode_convention','right-limit first positive smooth interval of regulated v2 schedule; original state is not projected or reset', ...
        'scalar_complete',false,'scheduled_complete',false,'raw_results',[], ...
        'native_initial_state',nan(14,N),'native_physical_parameter',nan(10,N),'parameter_conversion',{cell(N,1)}, ...
        'regulated_legacy_timings',nan(9,N),'mode_v3',false(4,N),'scalar_failure',{cell(N,1)},'scheduled_failure',{cell(N,1)});
    for key={'stored_initial_dx','stored_initial_dy','stored_period','mechanical_energy','initial_vertical_acceleration', ...
            'scheduled_signed_mean_U','scheduled_signed_stride','scheduled_period','scheduled_full13_closure_inf', ...
            'scheduled_zero_function_residual_inf','scheduled_terminal_dy','scheduled_terminal_time_error','scheduled_elapsed_seconds'}
        r.(key{1})=nan(N,1);
    end
    for key={'raw_column_finite','initial_timing_boundary','energy_available','energy_conservation_applicable', ...
            'native_initial_geometry_valid','initial_downward_apex','scalar_processed','scheduled_attempted', ...
            'scheduled_timely','scheduled_mean_available'}
        r.(key{1})=false(N,1);
    end
end
function out=bounds(v),v=v(isfinite(v));if isempty(v),out=[];else,out=[min(v),max(v)];end,end
function r=reference(file),d=dir(file);assert(isscalar(d)&&~d.isdir,'P1Audit:Missing');r=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',d.bytes);end
function out=failure(e),out=struct('identifier',e.identifier,'message',e.message);end
function t=nano(),t=double(java.lang.System.nanoTime);end
function t=nowUTC(),t=posixtime(datetime('now','TimeZone','UTC'));end
function t=stamp(),t=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end
