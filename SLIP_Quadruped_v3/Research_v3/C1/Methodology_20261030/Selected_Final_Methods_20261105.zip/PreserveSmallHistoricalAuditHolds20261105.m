function catalog=PreserveSmallHistoricalAuditHolds20261105(prefixReference,indices,maxWallSeconds)
% Exact byte custody for explicit small RAW_HELD rows of a closed catalog.
% Other outcomes stay literal. This does not validate/requalify stored science.
validateattributes(maxWallSeconds,{'double'},{'scalar','real','finite','>',120,'<=',1800});
validateattributes(indices,{'double'},{'vector','real','finite','integer','positive'});
assert(numel(indices)<=32&&numel(unique(indices))==numel(indices),'HeldBytes:Indices','Use at most32 explicit distinct held rows.');
timer=tic;u0=unixNow();method=ref([mfilename('fullpath'),'.m']);prefixReference=checkRef(prefixReference);
z=load(prefixReference.file,'catalog');catalog=z.catalog;clear z;N=numel(catalog.rows);
assert(strcmp(catalog.schema,'C1-historical-essential-audit-facts-v1')&&all(indices<=N),'HeldBytes:Catalog','Use exact existing historical-facts catalog membership.');
protected=setdiff(1:N,indices);originalRows=catalog.rows(protected);priorSHA=prefixReference.sha256;output=prefixReference.file;
assert(~isfile([output,'.heldbytes.pending.mat']),'HeldBytes:Stage','An unknown owned stage remains held.');
if ~isfield(catalog,'small_held_byte_custody'),catalog.small_held_byte_custody={};end
catalog.small_held_byte_custody{end+1,1}=struct('method_reference',method,'previous_reference',prefixReference, ...
 'indices',indices,'previous_held_outcomes',{catalog.rows(indices)},'scope','Entire original small MAT streams, not current scientific or loader validation.');
catalog.source_posthash=false;
for k=indices(:).'
 guard(60);r=catalog.rows{k};
 assert(startsWith(r.status,'RAW_HELD')&&~r.retirement_eligible,'HeldBytes:Held','Only explicit currently raw-held observations may be replaced.');
 source=r.source_reference;
 if ~isfield(source,'sha256')||isempty(source.sha256),source=r.inventory_reference;end
 source=checkRef(source);assert(source.bytes<=16*1024^2,'HeldBytes:Size','Keep larger original authorities outside this small custody route.');
 assert(strcmp(source.file,r.inventory_reference.file),'HeldBytes:Membership','A held source locator changed.');
 one=readBytes(source.file);two=readBytes(source.file);checkRef(source);
 assert(numel(one)==source.bytes&&isequal(one,two),'HeldBytes:Read2','Independent native source byte reads changed.');guard(30);
 r.source_reference=source;r.source_posthash=true;r.retirement_eligible=true;r.status='ESSENTIAL_FACTS_PROJECTED';
 r.primary_records={};r.selected_final_facts={};r.unknowns={};r.failure=struct();r.omissions={};
 r.facts=struct('schema','C1-exact-unvalidated-historical-MAT-byte-custody-v1','original_reference',source, ...
  'original_mat_file_bytes',one,'independent_native_fread_equal',true,'scientific_validation_performed',false, ...
  'scope','Restore exact bytes to MAT and verify original SHA/length before a suitable reader. Historical decisions/missingness are unchanged; no new admission, branch or current-runtime claim.');
 r.retention_schema='C1-exact-unvalidated-historical-MAT-byte-custody-v1';r.retention_scope=r.facts.scope;
 catalog.rows{k}=r;clear one two;persist();fprintf('SMALL_HELD_BYTES row=%d bytes=%d\n',k,source.bytes);
end
checkRef(method);guard(0);catalog.source_posthash=true;persist();
fprintf('SMALL_HELD_BYTES_RETURN eligible=%d held=%d seconds=%.6f\n',catalog.retirement_eligible_count,catalog.raw_held_count,toc(timer));
 function guard(reserve)
  assert(max(toc(timer),unixNow()-u0)<maxWallSeconds-reserve,'HeldBytes:Clock','The explicit saved-data clock expired; prior custody and originals remain.');
 end
 function persist()
  guard(0);assert(isequaln(catalog.rows(protected),originalRows),'HeldBytes:Unchanged','An unrelated literal outcome changed.');
  assert(strcmp(RoundSHA256_v3(output),priorSHA),'HeldBytes:CAS','The owned catalog changed.');
  catalog.retirement_eligible_count=sum(cellfun(@(r)r.retirement_eligible,catalog.rows));
  catalog.raw_held_count=sum(cellfun(@(r)startsWith(r.status,'RAW_HELD')||startsWith(r.status,'KEEP_ORIGINAL'),catalog.rows));
  stage=[output,'.heldbytes.pending.mat'];assert(~isfile(stage),'HeldBytes:Stage','An unknown native stage is held.');
  save(stage,'catalog','-v7');a=load(stage,'catalog');b=load(stage,'catalog');
  assert(isequaln(a.catalog,catalog)&&isequaln(b.catalog,catalog),'HeldBytes:AggregateRead2','Native independent aggregate/byte-vector read2 changed.');
  d=dir(stage);assert(d.bytes<=512*1024^2,'HeldBytes:AggregateSize','Keep originals and stage if complete custody exceeds512MiB.');guard(0);
  [ok,msg]=movefile(stage,output,'f');assert(ok,'HeldBytes:Publish','%s',msg);priorSHA=RoundSHA256_v3(output);
  index=rmfield(catalog,'rows');index.rows=cellfun(@(r)struct('inventory_reference',r.inventory_reference, ...
   'source_reference',r.source_reference,'status',r.status,'retirement_eligible',r.retirement_eligible, ...
   'source_posthash',r.source_posthash,'failure',r.failure,'unknowns',{r.unknowns}),catalog.rows,'UniformOutput',false);
  encoded=unicode2native(jsonencode(index),'UTF-8');jsonStage=[output,'.json.heldbytes.pending'];
  assert(~isfile(jsonStage),'HeldBytes:Stage','An unknown JSON stage is held.');fid=fopen(jsonStage,'w');
  assert(fid>=0,'HeldBytes:Open','Cannot create index stage.');closer=onCleanup(@()fclose(fid));
  assert(fwrite(fid,encoded,'uint8')==numel(encoded),'HeldBytes:Write','Short JSON index write.');clear closer
  [ok,msg]=movefile(jsonStage,[output,'.json'],'f');assert(ok,'HeldBytes:Publish','%s',msg);
 end
end
function bytes=readBytes(file)
fid=fopen(file,'r');assert(fid>=0,'HeldBytes:Open','Cannot open exact original.');closer=onCleanup(@()fclose(fid));bytes=fread(fid,Inf,'*uint8');clear closer
end
function r=checkRef(r)
d=dir(r.file);assert(isscalar(d)&&~d.isdir&&isfield(r,'sha256')&&~isempty(r.sha256)&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'HeldBytes:Hash','An exact observed input changed.');
end
function r=ref(file),d=dir(file);r=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',d.bytes);end
function u=unixNow(),u=posixtime(datetime('now','TimeZone','UTC'));end
