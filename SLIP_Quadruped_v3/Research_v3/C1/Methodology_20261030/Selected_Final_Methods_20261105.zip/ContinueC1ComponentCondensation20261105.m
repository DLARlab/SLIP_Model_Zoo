function current=ContinueC1ComponentCondensation20261105(sourceManifestReference,evidenceReferences,options)
%CONTINUEC1COMPONENTCONDENSATION20261105 Persistent pure-storage frontier.
% Existing passed files are seeded only by literal source FILE/SHA/bytes and
% independently verified receipts. Prepared unknown calls HOLD; they are not
% retried. Wall/service limits preserve the actual next unfinished cursor.
% No source/output deletion, Root, map, classifier or admission is performed.
    entered=tic;u0=unixNow();
    keys={'OutputDirectory','ReceiptFile','ResumeReference','MaxWallSeconds','SaveMarginSeconds', ...
        'PerFileMaxWallSeconds','MaximumFileBytes','MaxNewServices'};
    assert(isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort(keys(:))), ...
        'ComponentFrontier:Options','Supply the exact bounded storage options.');o=options;
    for key={'MaxWallSeconds','SaveMarginSeconds','PerFileMaxWallSeconds','MaximumFileBytes','MaxNewServices'}
        validateattributes(o.(key{1}),{'double'},{'real','finite','scalar','positive'});
    end
    assert(o.MaxWallSeconds<=1800&&o.SaveMarginSeconds>=60&&o.PerFileMaxWallSeconds>o.SaveMarginSeconds ...
        &&o.MaxNewServices==fix(o.MaxNewServices)&&o.MaxNewServices<=43, ...
        'ComponentFrontier:Bounds','Use a bounded1800s parent,60s reserve and at most43 new services.');
    sourceManifestReference=checked(sourceManifestReference);manifest=jsondecode(fileread(sourceManifestReference.file));
    assert(strcmp(manifest.schema,'C1-native-component-condensation-batch-v1')&&numel(manifest.source_references)==43, ...
        'ComponentFrontier:Manifest','Use the literal complete43-source reference roster.');
    sources=asCells(manifest.source_references);paths=cellfun(@(r)canonical(r.file),sources,'UniformOutput',false);
    assert(numel(unique(paths))==43,'ComponentFrontier:Sources','Each source occurs once.');
    assert(iscell(evidenceReferences)&&iscolumn(evidenceReferences)&&numel(evidenceReferences)>=2, ...
        'ComponentFrontier:Evidence','Supply the actual verified salvage/smoke authorities.');
    for k=1:numel(evidenceReferences),evidenceReferences{k}=checked(evidenceReferences{k});end
    methods={reference([mfilename('fullpath'),'.m']);reference(which('CondenseBranchFile_v3')); ...
        reference(which('ProjectRecordedMethodDescriptors_v3'));reference(which('EssentialBranchSolutionFile_v3')); ...
        reference(which('BranchSolutionFile_v3'));reference(which('C1ScientificDigest_v3'));reference(which('RoundSHA256_v3'))};
    outputDirectory=canonical(o.OutputDirectory);receiptFile=canonical(o.ReceiptFile);
    assert(isfolder(outputDirectory)&&isfolder(fileparts(receiptFile)),'ComponentFrontier:Directories','Supply existing owned output directories.');
    config=struct('schema','C1-component-storage-frontier-config-v1','source_manifest_reference',sourceManifestReference, ...
        'source_references',{sources},'evidence_references',{evidenceReferences},'output_directory',outputDirectory, ...
        'maximum_file_bytes',o.MaximumFileBytes,'projection_methods',{methods},'source_read_block_size',8);
    configDigest=C1ScientificDigest_v3(config);lastReceiptSHA='';
    if isempty(fieldnames(o.ResumeReference))
        assert(~isfile(receiptFile)&&~isfile([receiptFile,'.pending.mat'])&&~isfile([receiptFile,'.json']), ...
            'ComponentFrontier:Fresh','Use fresh receipt paths, or an explicit exact resume reference.');
        rows=cell(43,1);
        for k=1:43
            [~,name,ext]=fileparts(sources{k}.file);
            rows{k}=struct('source_reference',sources{k},'output_file',fullfile(outputDirectory,[name,ext]), ...
                'status','NOT_ATTEMPTED','storage_verified',false,'evidence_reference',struct(),'evidence_row',[], ...
                'output_reference',struct(),'receipt',struct(),'attempts',{cell(0,1)},'prepared_unknown',false, ...
                'native_returned',false,'native_exception_known',false,'failure',struct());
        end
        current=struct('schema','C1-current-component-condensation-frontier-v1','configuration',config,'configuration_digest',configDigest, ...
            'rows',{rows},'cursor',1,'completed',false,'all43_storage_verified',false,'source_posthash',false, ...
            'status','PREPARED','invocations',{cell(0,1)},'original_sources_removed',0,'new_scientific_services',0, ...
            'scope','Storage replacement map only. Saved scientific decisions remain historical. Unsupported or unknown payloads stay raw; no completed branch, new admission or graph relation is inferred.');
        seedEvidence();
    else
        resume=checked(o.ResumeReference);assert(strcmp(resume.file,receiptFile),'ComponentFrontier:Resume','Resume the exact owned receipt.');
        z=load(resume.file,'current');current=z.current;
        assert(strcmp(current.schema,'C1-current-component-condensation-frontier-v1')&&strcmp(current.configuration_digest,configDigest) ...
            &&isequaln(current.configuration,config)&&numel(current.rows)==43, ...
            'ComponentFrontier:ResumeEpoch','Resume only the same immutable source/method/projection epoch.');
        lastReceiptSHA=resume.sha256;
    end
    % Wall/service limits are per invocation and do not alter the data codec.
    invocation=struct('started_utc',stamp(),'limits',pickLimits(o),'resume_reference',o.ResumeReference, ...
        'services_started',0,'finished_utc','','status','RUNNING');
    current.invocations{end+1,1}=invocation;invocationIndex=numel(current.invocations);
    current.source_posthash=false;persist();services=0;
    while current.cursor<=43
        k=current.cursor;row=current.rows{k};
        if row.storage_verified
            checked(row.output_reference);current.cursor=k+1;continue
        end
        if row.prepared_unknown
            current.status='HOLD_UNKNOWN_PREPARED_STORAGE';break
        end
        if row.native_returned&&~row.native_exception_known
            current.status='HOLD_RETURNED_STORAGE_VERIFICATION_PENDING';break
        end
        if row.native_exception_known
            % The caller can fix that source separately and start a reviewed
            % successor epoch seeded by this map's actually passed records.
            current.cursor=k+1;continue
        end
        if services>=o.MaxNewServices,current.status='PARTIAL_SERVICE_CAP';break;end
        cap=o.PerFileMaxWallSeconds;
        if remaining()<=cap+o.SaveMarginSeconds+5,current.status='PARTIAL_WALL_CAP';break;end
        source=checked(row.source_reference);assert(~isfile(row.output_file)&&~isfolder(row.output_file), ...
            'ComponentFrontier:UnknownOutput','An existing unverified output is held, never overwritten or retried.');
        raw=BranchSolutionFile_v3.index(source.file);N=numel(raw.points);clear raw
        selected=zeros(0,1);if N>0,selected=unique([1;ceil(N/2);N]);end
        row.prepared_unknown=true;row.status='PREPARED_UNKNOWN_UNTIL_RETURN';
        row.attempts{end+1,1}=struct('prepared_utc',stamp(),'maximum_wall_seconds',cap,'selected_readback_indices',selected);
        current.rows{k}=row;services=services+1;current.invocations{invocationIndex}.services_started=services;persist();
        try
            child=struct('MaximumBytes',o.MaximumFileBytes,'MaxWallSeconds',cap, ...
                'SaveMarginSeconds',o.SaveMarginSeconds,'ReadbackIndices',selected);
            result=CondenseBranchFile_v3(source,row.output_file,child);
            % Preserve the actual return before any additional fallible guard.
            row.native_returned=true;row.prepared_unknown=false;row.receipt=result;
            row.output_reference=result.output_reference;row.status='RETURNED_VERIFICATION_PENDING';row.storage_verified=false;
            current.rows{k}=row;persist();
            assert(isfield(result,'source_read_block_size')&&result.source_read_block_size==8 ...
                &&result.source_posthash&&result.all_literal_core_values_verified ...
                &&result.all_saved_projection_digests_verified&&result.selected_independent_read2_verified, ...
                'ComponentFrontier:ReturnedContract','The actual returned storage proof must bind the block8 projection and all required checks.');
            checked(source);checked(row.output_reference);row.storage_verified=true;row.status='RETURNED_STORAGE_VERIFIED';
            current.rows{k}=row;persist();
        catch problem
            row=current.rows{k};row.prepared_unknown=false;row.native_exception_known=true;
            row.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);
            row.storage_verified=false;row.status='KNOWN_STORAGE_EXCEPTION_RAW_HELD';
            current.rows{k}=row;current.status='STOPPED_FOR_KNOWN_STORAGE_EXCEPTION';persist();
            current.cursor=k+1;break
        end
        current.cursor=k+1;persist();
    end
    for k=1:43
        row=current.rows{k};
        if row.storage_verified,checked(row.output_reference);end
        checked(row.source_reference);
    end
    checked(sourceManifestReference);for k=1:numel(evidenceReferences),checked(evidenceReferences{k});end
    for k=1:numel(methods),checked(methods{k});end
    current.source_posthash=true;current.completed=current.cursor==44;
    current.all43_storage_verified=current.completed&&all(cellfun(@(r)r.storage_verified,current.rows));
    if current.all43_storage_verified,current.status='COMPLETE43_VERIFIED_STORAGE_REPLACEMENTS';
    elseif current.completed,current.status='COMPLETE43_OBSERVATIONS_RAW_HELD_REMAIN';end
    current.invocations{invocationIndex}.finished_utc=stamp();current.invocations{invocationIndex}.status=current.status;
    current.last_elapsed_seconds=toc(entered);persist();
    fprintf('C1_STORAGE_FRONTIER_RETURN cursor=%d verified=%d all43=%d services=%d status=%s\n', ...
        current.cursor,sum(cellfun(@(r)r.storage_verified,current.rows)),current.all43_storage_verified,services,current.status);

    function seedEvidence()
        for e=1:numel(evidenceReferences)
            ref=evidenceReferences{e};vars=whos('-file',ref.file);names={vars.name};
            if any(strcmp(names,'receipt'))
                z=load(ref.file,'receipt');p=z.receipt;
                assert(strcmp(p.schema,'C1-known-clone-failure-storage-salvage-v1')&&p.completed&&p.source_posthash, ...
                    'ComponentFrontier:Salvage','Require the actual completed independent salvage.');
                for j=1:numel(p.rows)
                    r=p.rows{j};assert(r.storage_retirement_eligible&&r.source_posthash, ...
                        'ComponentFrontier:SalvageRow','A source must have actually passed salvage.');
                    installSeed(r.source_reference,r.output_reference,ref,j,'PASSED_EXISTING_CLONE_SALVAGE',r);
                end
            elseif any(strcmp(names,'summary'))
                z=load(ref.file,'summary');p=z.summary;
                assert(strcmp(p.schema,'C1-public-condensation-three-source-smoke-v1')&&p.completed&&p.source_posthash&&p.all3passed, ...
                    'ComponentFrontier:Smokes','Require all actual public smokes completed and passed.');
                for j=1:numel(p.rows)
                    r=p.rows{j};assert(r.passed&&r.returned&&r.receipt.source_posthash&&r.receipt.selected_independent_read2_verified, ...
                        'ComponentFrontier:SmokeRow','Require an actually returned and readback verified public export.');
                    installSeed(r.source_reference,r.receipt.output_reference,ref,j,'PASSED_EXISTING_PUBLIC_SMOKE',r.receipt);
                end
            elseif any(strcmp(names,'current'))
                z=load(ref.file,'current');p=z.current;
                assert(strcmp(p.schema,current.schema)&&p.source_posthash,'ComponentFrontier:PriorMap','Prior passed map rows require their actual postguard.');
                for j=1:numel(p.rows)
                    r=p.rows{j};if r.storage_verified,installSeed(r.source_reference,r.output_reference,ref,j,'PASSED_EXPLICIT_PRIOR_EPOCH',r);end
                end
            else,error('ComponentFrontier:EvidenceSchema','Unsupported passed-storage evidence schema.');end
        end
    end
    function installSeed(source,out,ref,index,status,proof)
        hits=find(cellfun(@(r)sameReference(r,source),sources));
        assert(isscalar(hits)&&~current.rows{hits}.storage_verified, ...
            'ComponentFrontier:SeedJoin','Use one unique literal FILE/SHA/bytes source, never NativeID/nearest-state matching.');
        checked(source);out=checked(out);EssentialBranchSolutionFile_v3.index(out.file);
        row=current.rows{hits};row.output_reference=out;row.output_file=out.file;row.evidence_reference=ref;
        row.evidence_row=index;row.receipt=proof;row.status=status;row.storage_verified=true;current.rows{hits}=row;
    end
    function persist()
        assert(remaining()>0,'ComponentFrontier:WallCap','The bounded storage clock expired; retain any prepared/returned prefix.');
        if isempty(lastReceiptSHA),assert(~isfile(receiptFile),'ComponentFrontier:CAS','A concurrent receipt appeared.');
        else,assert(isfile(receiptFile)&&strcmp(RoundSHA256_v3(receiptFile),lastReceiptSHA),'ComponentFrontier:CAS','The owned receipt changed.');end
        stage=[receiptFile,'.pending.mat'];assert(~isfile(stage),'ComponentFrontier:Pending','Unknown pending writes are held.');
        save(stage,'current','-v7');z=load(stage,'current');assert(isequaln(z.current,current),'ComponentFrontier:Readback','The plain current map changed.');
        [ok,msg]=movefile(stage,receiptFile,'f');assert(ok,'ComponentFrontier:Publish','%s',msg);lastReceiptSHA=RoundSHA256_v3(receiptFile);
        stage=[receiptFile,'.json.pending'];assert(~isfile(stage),'ComponentFrontier:Pending','Unknown pending JSON is held.');
        summary=rmfield(current,'rows');summary.rows=cellfun(@(r)struct('source_reference',r.source_reference,'status',r.status, ...
            'storage_verified',r.storage_verified,'output_reference',r.output_reference,'prepared_unknown',r.prepared_unknown,'failure',r.failure),current.rows,'UniformOutput',false);
        text=jsonencode(summary);fid=fopen(stage,'w');assert(fid>=0,'ComponentFrontier:Open','Cannot open JSON stage.');jsonCloser=onCleanup(@()fclose(fid));assert(fwrite(fid,text,'char')==numel(text),'ComponentFrontier:Write','Short JSON write.');clear jsonCloser
        [ok,msg]=movefile(stage,[receiptFile,'.json'],'f');assert(ok,'ComponentFrontier:Publish','%s',msg);
    end
    function left=remaining(),left=o.MaxWallSeconds-max(toc(entered),unixNow()-u0);end
end
function s=pickLimits(o),s=struct('MaxWallSeconds',o.MaxWallSeconds,'SaveMarginSeconds',o.SaveMarginSeconds,'PerFileMaxWallSeconds',o.PerFileMaxWallSeconds,'MaxNewServices',o.MaxNewServices);end
function yes=sameReference(a,b),yes=strcmp(canonical(a.file),canonical(b.file))&&strcmp(a.sha256,b.sha256)&&a.bytes==b.bytes;end
function v=asCells(v),if isstruct(v),v=num2cell(v(:));else,assert(iscell(v),'ComponentFrontier:Rows','Expected explicit row data.');v=v(:);end,end
function r=checked(r)
    assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256','bytes'})),'ComponentFrontier:Reference','Supply actual FILE/SHA/bytes.');
    r.file=canonical(r.file);s=dir(r.file);assert(isscalar(s)&&~s.isdir&&s.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
        'ComponentFrontier:Hash','Immutable storage input changed: %s',r.file);
end
function r=reference(f),f=canonical(f);s=dir(f);assert(isscalar(s)&&~s.isdir,'ComponentFrontier:Missing','Required method missing.');r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',s.bytes);end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function u=unixNow(),u=posixtime(datetime('now','TimeZone','UTC'));end
function v=stamp(),t=datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");v=char(t);end
