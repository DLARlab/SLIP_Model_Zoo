function adoption=AdoptC1StorageMethodSuccessor20261105(priorReference,auditFile,retryKnownIndices,maxWallSeconds)
%ADOPTC1STORAGEMETHODSUCCESSOR20261105 Explicit same-map data-codec adoption.
% Only CondenseBranchFile/ProjectRecordedMethodDescriptors may change. All
% previously verified rows and files remain exact; no source is reprojected.
% An explicitly listed known exception can become a new unattempted service
% only when it never returned and has no existing output. Unknowns stay held.
% ROOT owns idle-worker confirmation and reviews the successor source first.
    entered=tic;u0=unixNow();validateattributes(maxWallSeconds,{'double'},{'real','finite','scalar','>',60,'<=',600});
    priorReference=checked(priorReference);file=priorReference.file;auditFile=canonical(auditFile);
    assert(~strcmp(file,auditFile)&&isfolder(fileparts(auditFile))&&~isfile(auditFile), ...
        'StorageAdoption:Fresh','Use a fresh separate adoption audit.');
    assert(isnumeric(retryKnownIndices)&&isreal(retryKnownIndices)&&(isvector(retryKnownIndices)||isempty(retryKnownIndices)) ...
        &&all(isfinite(retryKnownIndices(:)))&&all(retryKnownIndices(:)==fix(retryKnownIndices(:))) ...
        &&all(retryKnownIndices(:)>=1&retryKnownIndices(:)<=43)&&numel(unique(retryKnownIndices))==numel(retryKnownIndices), ...
        'StorageAdoption:Retries','Declare exact unique known-held source indices.');
    z=load(file,'current');before=z.current;current=before;clear z
    assert(strcmp(before.schema,'C1-current-component-condensation-frontier-v1')&&before.source_posthash ...
        &&numel(before.rows)==43&&strcmp(C1ScientificDigest_v3(before.configuration),before.configuration_digest), ...
        'StorageAdoption:Prior','Require the intact postguarded actual current map.');
    oldMethods=before.configuration.projection_methods;newMethods=oldMethods;changes=cell(0,1);
    allowed={'CondenseBranchFile_v3','ProjectRecordedMethodDescriptors_v3'};
    for k=1:numel(oldMethods)
        r=oldMethods{k};[~,name,ext]=fileparts(r.file);assert(strcmp(ext,'.m'),'StorageAdoption:Method','Only literal MATLAB method references are supported.');
        now=reference(r.file);
        if ~strcmp(r.sha256,now.sha256)
            assert(ismember(name,allowed),'StorageAdoption:Epoch','An unrelated source changed: %s.',name);
            changes{end+1,1}=struct('name',name,'previous_reference',r,'new_reference',now);
            newMethods{k}=now;
        else,checked(r);end
    end
    assert(~isempty(changes),'StorageAdoption:NoChange','A successor requires an explicitly reviewed changed codec method.');
    verified=cellfun(@(r)r.storage_verified,before.rows);verifiedDigests=cell(43,1);
    for k=1:43
        guard();row=before.rows{k};checked(row.source_reference);
        if verified(k),checked(row.output_reference);verifiedDigests{k}=C1ScientificDigest_v3(row);end
    end
    retries=cell(numel(retryKnownIndices),1);
    for j=1:numel(retryKnownIndices)
        k=retryKnownIndices(j);row=before.rows{k};
        assert(~row.storage_verified&&row.native_exception_known&&~row.prepared_unknown&&~row.native_returned ...
            &&strcmp(row.status,'KNOWN_STORAGE_EXCEPTION_RAW_HELD')&&~isfile(row.output_file)&&~isfolder(row.output_file), ...
            'StorageAdoption:KnownOnly','Never reset an unknown/returned/verified service or an existing output.');
        retries{j}=struct('source_index',k,'literal_previous_outcome',row);
        if ~isfield(row,'method_successor_previous_outcomes'),row.method_successor_previous_outcomes=cell(0,1);end
        row.method_successor_previous_outcomes{end+1,1}=before.rows{k};
        row.native_exception_known=false;row.failure=struct();row.status='NOT_ATTEMPTED_EXPLICIT_METHOD_SUCCESSOR';
        current.rows{k}=row;
    end
    current.configuration.projection_methods=newMethods;current.configuration_digest=C1ScientificDigest_v3(current.configuration);
    pending=find(cellfun(@(r)~r.storage_verified&&~r.native_exception_known,current.rows),1);
    if isempty(pending),current.cursor=44;else,current.cursor=pending;end
    current.completed=false;current.all43_storage_verified=false;current.status='EXPLICIT_METHOD_SUCCESSOR_READY';
    record=struct('schema','C1-reviewed-storage-method-successor-v1','previous_map_reference',priorReference, ...
        'previous_configuration',before.configuration,'previous_configuration_digest',before.configuration_digest, ...
        'new_configuration_digest',current.configuration_digest,'changed_methods',{changes}, ...
        'explicit_known_retries',{retries},'previous_verified_source_count',sum(verified), ...
        'previous_verified_row_digests',{verifiedDigests},'previous_verified_rows_reprojected',0, ...
        'unknown_services_reset',0,'new_scientific_services',0,'prepared_utc',stamp());
    if ~isfield(current,'method_successor_adoptions'),current.method_successor_adoptions=cell(0,1);end
    current.method_successor_adoptions{end+1,1}=record;
    for k=find(verified).'
        assert(isequaln(current.rows{k},before.rows{k})&&strcmp(C1ScientificDigest_v3(current.rows{k}),verifiedDigests{k}), ...
            'StorageAdoption:Preserved','Every earlier verified record must remain exact.');
    end
    current.source_posthash=true;stage=[file,'.method-successor.pending.mat'];auditStage=[auditFile,'.pending.mat'];
    assert(~isfile(stage)&&~isfile(auditStage),'StorageAdoption:Pending','Hold existing unknown adoption stages.');
    guard();save(stage,'current','-v7');a=load(stage,'current');b=load(stage,'current');
    assert(isequaln(a.current,current)&&isequaln(b.current,current),'StorageAdoption:Read2','The owned successor map changed on native read2.');
    for k=1:numel(newMethods),checked(newMethods{k});end
    checked(priorReference);guard();[ok,msg]=movefile(stage,file,'f');assert(ok,'StorageAdoption:Commit','%s',msg);
    mirror=rmfield(current,'rows');mirror.rows=cellfun(@(r)struct('source_reference',r.source_reference,'status',r.status, ...
        'storage_verified',r.storage_verified,'output_reference',r.output_reference,'prepared_unknown',r.prepared_unknown,'failure',r.failure),current.rows,'UniformOutput',false);
    jsonStage=[file,'.json.method-successor.pending'];assert(~isfile(jsonStage),'StorageAdoption:Pending','Hold an unknown JSON successor stage.');
    text=jsonencode(mirror);fid=fopen(jsonStage,'w');assert(fid>=0,'StorageAdoption:Open','Cannot create JSON successor.');jsonCloser=onCleanup(@()fclose(fid));assert(fwrite(fid,text,'char')==numel(text),'StorageAdoption:Write','Short JSON successor write.');clear jsonCloser
    [ok,msg]=movefile(jsonStage,[file,'.json'],'f');assert(ok,'StorageAdoption:Mirror','%s',msg);
    adoption=record;adoption.new_map_reference=reference(file);adoption.committed=true;
    adoption.all_previous_verified_rows_preserved=true;adoption.elapsed_seconds=toc(entered);
    save(auditStage,'adoption','-v7');z=load(auditStage,'adoption');assert(isequaln(z.adoption,adoption),'StorageAdoption:Audit','The plain adoption audit changed.');
    [ok,msg]=movefile(auditStage,auditFile);assert(ok,'StorageAdoption:Audit','%s',msg);
    fprintf('STORAGE_METHOD_SUCCESSOR_ADOPTED preserved=%d retry=%s cursor=%d SHA=%s\n',sum(verified),mat2str(retryKnownIndices),current.cursor,adoption.new_map_reference.sha256);
    function guard(),assert(max(toc(entered),unixNow()-u0)<maxWallSeconds,'StorageAdoption:Clock','The bounded pure-data adoption cap expired; retain all stages.');end
end
function r=checked(r)
    assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256','bytes'})),'StorageAdoption:Reference','Use actual FILE/SHA/bytes.');
    r.file=canonical(r.file);s=dir(r.file);assert(isscalar(s)&&~s.isdir&&s.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
        'StorageAdoption:Hash','Immutable storage input changed: %s',r.file);
end
function r=reference(f),f=canonical(f);s=dir(f);assert(isscalar(s)&&~s.isdir,'StorageAdoption:Missing','Required method missing.');r=struct('file',f,'sha256',RoundSHA256_v3(f),'bytes',s.bytes);end
function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end
function u=unixNow(),u=posixtime(datetime('now','TimeZone','UTC'));end
function s=stamp(),s=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end
