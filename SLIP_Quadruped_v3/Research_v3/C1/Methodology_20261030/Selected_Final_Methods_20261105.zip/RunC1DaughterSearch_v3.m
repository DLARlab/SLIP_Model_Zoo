function summary=RunC1DaughterSearch_v3(sourceFile,sourceIndices,parentType,options)
%RUNC1DAUGHTERSEARCH_V3 Break the remaining synchronized pair of F or H.
% A finite odd-sector matrix supplies acquisition predictors only. Every
% retained daughter must pass the unchanged PeriodicSolutionSolver service.
% Parent proximity, selectors and label changes do not assert bifurcations.
    if nargin<4,options=struct();end
    o=struct('MaxWallSeconds',5400,'TrialSeconds',300, ...
        'Amplitudes',[.01,.003,.001,-.001,-.003,-.01], ...
        'ProbeSteps',[1e-4,1e-5],'MinimumOriginalSplit',1e-3, ...
        'MaximumParentDistance',.05,'MaximumModeDistance',.5, ...
        'DerivativeStep',1e-5,'Algorithm','newton','RunName','base', ...
        'DerivativeMethod','ordinary','InitialDamping',1e-6,'AcquisitionStrategy','odd-mode', ...
        'DirectRateAngleRatio',[]);
    assert(isstruct(options)&&isscalar(options),'C1Daughter:Options');
    names=fieldnames(options);
    assert(all(ismember(names,fieldnames(o))),'C1Daughter:Options');
    for k=1:numel(names),o.(names{k})=options.(names{k});end
    validateattributes(o.InitialDamping,{'double','single'}, ...
        {'real','scalar','finite','positive'},mfilename,'InitialDamping');
    o.InitialDamping=double(o.InitialDamping);
    assert(((ischar(o.RunName)&&isrow(o.RunName))||(isstring(o.RunName)&&isscalar(o.RunName)))&& ...
        ~isempty(regexp(char(o.RunName),'^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$','once')), ...
        'C1Daughter:RunName','RunName must be safe scalar filename text.');
    o.RunName=char(o.RunName);
    assert(((ischar(o.AcquisitionStrategy)&&isrow(o.AcquisitionStrategy))|| ...
        (isstring(o.AcquisitionStrategy)&&isscalar(o.AcquisitionStrategy)))&& ...
        any(strcmp(o.AcquisitionStrategy,{'odd-mode','direct-selector'})), ...
        'C1Daughter:AcquisitionStrategy','Use odd-mode or explicit direct-selector.');
    o.AcquisitionStrategy=char(o.AcquisitionStrategy);
    if strcmp(o.AcquisitionStrategy,'direct-selector')
        assert(isfield(options,'RunName')&&~strcmp(o.RunName,'base'), ...
            'C1Daughter:DirectRunName','A direct-selector experiment needs an explicit new non-base RunName.');
        assert(isfield(options,'DirectRateAngleRatio')&&isnumeric(o.DirectRateAngleRatio) ...
            &&isreal(o.DirectRateAngleRatio)&&isscalar(o.DirectRateAngleRatio)&&isfinite(o.DirectRateAngleRatio), ...
            'C1Daughter:DirectRatio','Supply the finite real rate/angle predictor ratio explicitly.');
        assert(isnumeric(o.Amplitudes)&&isreal(o.Amplitudes)&&isvector(o.Amplitudes) ...
            &&~isempty(o.Amplitudes)&&all(isfinite(o.Amplitudes))&&all(o.Amplitudes~=0), ...
            'C1Daughter:DirectAmplitudes','Direct selector amplitudes must be finite and nonzero.');
        o.Amplitudes=double(o.Amplitudes(:).');
        o.DirectRateAngleRatio=double(o.DirectRateAngleRatio);
    else
        assert(isempty(o.DirectRateAngleRatio),'C1Daughter:DirectRatio', ...
            'DirectRateAngleRatio is used only with direct-selector.');
    end
    assert(((ischar(o.DerivativeMethod)&&isrow(o.DerivativeMethod))|| ...
        (isstring(o.DerivativeMethod)&&isscalar(o.DerivativeMethod)))&& ...
        any(strcmp(o.DerivativeMethod,{'ordinary','valid-sided'})), ...
        'C1Daughter:DerivativeMethod','Use ordinary or valid-sided.');
    o.DerivativeMethod=char(o.DerivativeMethod);
    assert(~strcmp(o.DerivativeMethod,'valid-sided')||strcmp(o.Algorithm,'newton'), ...
        'C1Daughter:Algorithm','Valid-sided acquisition requires Newton; it is not a reliable fsolve derivative.');
    assert(any(strcmp(parentType,{'F','H'})),'C1Daughter:Parent');
    parentType=char(parentType);
    root=fileparts(mfilename('fullpath'));budget=C1RunBudget_v3();
    entered=double(java.lang.System.nanoTime);
    limit=min(budget.research_deadline_monotonic_ns,entered+o.MaxWallSeconds*1e9);
    pair=[1,2];original=[3,4];symmetry='hind-pair';
    if strcmp(parentType,'H'),pair=[3,4];original=[1,2];symmetry='fore-pair';end
    schema=QuadrupedSchema_v3.shared();angles=schema.Leg.AngleIndices(pair);
    rates=schema.Leg.RateIndices(pair);originalAngles=schema.Leg.AngleIndices(original);
    file=fullfile(root,'Audits',['Daughter_Search_' parentType '_' o.RunName '.mat']);
    jsonFile=[file(1:end-4),'.json'];
    identity=struct('source_file',sourceFile,'source_indices',sourceIndices, ...
        'parent_type',parentType,'options',o,'deadline',budget.research_deadline_utc);
    if isfile(file)
        saved=load(file,'summary');summary=saved.summary;
        assert(isequaln(summary.identity,identity),'C1Daughter:ResumeIdentity');
    else
        summary=struct('schema','C1-remaining-pair-search-v1','identity',identity, ...
            'parents',{{}},'attempts',{{}},'accepted_sources',{{}},'active_parent',struct(), ...
            'classical_derivative_claimed',false,'attachment_claimed',false, ...
            'started_utc',stamp(),'completed',false);
    end
    if ~isfield(summary,'pending_admission'),summary.pending_admission=struct();end
    assert(isstruct(summary.pending_admission)&&isscalar(summary.pending_admission), ...
        'C1Daughter:Pending','Pending native admission metadata must be a scalar structure.');
    summary.completed=false;summary.status='running';
    if hasNativePending(summary)
        summary.status='native_admission_pending';saveProgress('pending_requires_review');return
    end
    saveProgress('start');
    for sourceIndex=sourceIndices(:).'
        check();summary.active_parent=struct();stopAfterParent=false;
        [parent,oldReport,sourceMetadata]=BranchSolutionFile_v3.loadSolution(sourceFile,sourceIndex);
        marker=sprintf('parent_%06d',sourceIndex);
        if any(cellfun(@(p)strcmp(p.marker,marker),summary.parents)),continue;end
        item=struct('marker',marker,'source_index',sourceIndex,'status','running', ...
            'source_metadata',sourceMetadata,'failure',struct(),'probes',{{}}, ...
            'acquisition_strategy',o.AcquisitionStrategy,'parent_attachment_claimed',false);
        try
            [policy,pe]=RecordedReturnPolicy_v3(oldReport);
            assert(pe.complete,'C1Daughter:Policy','Complete stored policy required.');
            originalOrbit=parent;originalReport=oldReport;
            seed=seedOf(parent,policy,sourceIndex);
            [control,controlReport,controlRaw]=correct(seed,symmetry,[],[],o.DerivativeStep,o.Algorithm);
            item.control_native_all_nine=nine(controlRaw);item.control_timely_at_return=controlReport.within_original_clock;
            if item.control_native_all_nine
                holdNative(control,controlRaw,'parent-control',item);item.control_orbit=control;summary.active_parent=item;
                if ~item.control_timely_at_return,error('C1Daughter:ParentControlLate','The native all-nine parent control returned late; its payload is retained and no route is attempted.');end
            end
            item.control_report=compact(controlReport);
            if item.control_native_all_nine
                summary.active_parent=item;saveProgress('parent_control_retained');
                item.control_storage_timely=left()>0&&beforeDeadline(controlReport.acquisition_deadlines);summary.active_parent=item;
                if ~item.control_storage_timely,error('C1Daughter:ParentControlLate','Parent checkpoint storage exceeded the original clock; the native pending payload remains retained.');end
                controlHold=summary.pending_admission;clearNativePending('parent_control_checkpoint_confirmed');
                item.control_storage_timely=left()>0&&beforeDeadline(controlReport.acquisition_deadlines);summary.active_parent=item;
                if ~item.control_storage_timely
                    summary.pending_admission=controlHold;saveProgress('parent_control_late');
                    error('C1Daughter:ParentControlLate','Parent checkpoint confirmation was late; no daughter route is attempted.');
                end
            end
            assert(nine(controlReport),'C1Daughter:ParentAdmission');
            assert(isa(control,'HybridOrbit_v3')&&one(controlReport.classification), ...
                'C1Daughter:ParentC1');
            assert(strcmp(controlReport.classification.validated_gait_type,parentType), ...
                'C1Daughter:ParentClass');
            sourceChart=MatchingReturnSection_v3(originalOrbit,control,{originalReport,controlReport});
            capture=struct('source_file',sourceFile,'source_point',sourceIndex, ...
                'same_physical_parameter',isequal(control.parameter(:),originalOrbit.parameter(:)), ...
                'same_initial_mode',isequal(control.initial_mode(:),originalOrbit.initial_mode(:)), ...
                'same_chart',sourceChart.compatible, ...
                'scaled_full13_inf',norm((control.initial_state(2:end)-originalOrbit.initial_state(2:end))./ ...
                    max(1,abs(originalOrbit.initial_state(2:end))),Inf), ...
                'relative_period_change',relativeChange(control.period,originalOrbit.period), ...
                'relative_stride_change',relativeChange(control.stride_displacement,originalOrbit.stride_displacement), ...
                'capture_limit',.02,'passed',false,'formal_attachment_claimed',false);
            capture.passed=capture.same_physical_parameter&&capture.same_initial_mode&&capture.same_chart&& ...
                capture.scaled_full13_inf<=.02&&capture.relative_period_change<=.02&&capture.relative_stride_change<=.02;
            item.control_source_capture=capture;
            if ~capture.passed
                error('C1Daughter:ParentCapture', ...
                    'The accepted parent control left the original source neighborhood; no daughter probe was attempted.');
            end
            parent=control;oldReport=controlReport;
            originalSplit=diff(parent.initial_state(originalAngles));
            item.original_split=originalSplit;
            assert(abs(originalSplit)>=o.MinimumOriginalSplit,'C1Daughter:NearPK', ...
                'The original pair spread is too small for a secondary branch test.');
            seed=seedOf(parent,policy,sourceIndex);
            assert(~any(logical(seed.mode(pair))),'C1Daughter:PredictorStancePair', ...
                'Both raw predictor strategies require the remaining pair in swing; dependent stance rates are not projected.');
            if strcmp(o.AcquisitionStrategy,'direct-selector')
                ratio=o.DirectRateAngleRatio;item.rate_angle_ratio=ratio;
            else
                B=zeros(14,2);B(angles,1)=[1;-1]/2;B(rates,2)=[1;-1]/2;
                base=flow(seed.state,seed,policy);baseOdd=odd(base);
                for h=o.ProbeSteps
                    probe=struct('step',h,'matrix',NaN(2),'positive_matrix',NaN(2), ...
                        'negative_matrix',NaN(2),'full13_leakage',NaN, ...
                        'classical_derivative_claimed',false);
                    projected=zeros(2);positive=zeros(2);negative=zeros(2);D=zeros(14,2);DP=zeros(14,2);DM=zeros(14,2);
                    for j=1:2
                        xp=flow(seed.state+h*B(:,j),seed,policy);
                        xm=flow(seed.state-h*B(:,j),seed,policy);
                        positive(:,j)=(odd(xp)-baseOdd)/h;
                        negative(:,j)=(baseOdd-odd(xm))/h;
                        projected(:,j)=(odd(xp)-odd(xm))/(2*h);
                        D(:,j)=(xp-xm)/(2*h);
                        DP(:,j)=(xp-base)/h;DM(:,j)=(base-xm)/h;
                    end
                    probe.matrix=projected;probe.positive_matrix=positive;
                    probe.negative_matrix=negative;
                    probe.side_disagreement=norm(positive-negative,inf)/max(1,norm(projected,inf));
                    probe.full13_leakage=norm(D(2:end,:)-B(2:end,:)*projected,inf);
                    probe.full13_positive_matrix=DP(2:end,:);probe.full13_negative_matrix=DM(2:end,:);
                    probe.full13_central_matrix=D(2:end,:);
                    probe.full13_side_disagreement=norm(DP(2:end,:)-DM(2:end,:),inf)/max(1,norm(D(2:end,:),inf));
                    [V,L]=eig(projected);lambda=diag(L);[distance,j]=min(abs(lambda-1));
                    probe.eigenvalues=lambda;probe.distance_to_one=distance;
                    probe.selected_vector=V(:,j);probe.selected_eigenvalue=lambda(j);
                    probe.det_matrix_minus_identity=det(projected-eye(2));
                    item.probes{end+1}=probe;
                end
                last=item.probes{end};v=last.selected_vector;
                assert(abs(imag(last.selected_eigenvalue))<1e-7&& ...
                    norm(imag(v),inf)<1e-7&&abs(v(1))>1e-5, ...
                    'C1Daughter:ComplexOrRateMode');
                assert(last.distance_to_one<=o.MaximumModeDistance, ...
                    'C1Daughter:AwayFromUnitMode');
                ratio=real(v(2)/v(1));item.rate_angle_ratio=ratio;
            end
            summary.active_parent=item;saveProgress('parent_predictor');
            for amplitude=o.Amplitudes
                check();key=sprintf('%s_amplitude_%+.12g',marker,amplitude);
                if any(cellfun(@(a)strcmp(a.key,key),summary.attempts)),continue;end
                trial=struct('key',key,'parent_index',sourceIndex,'target',amplitude, ...
                    'status','running','accepted_G',false,'failure',struct(), ...
                    'native_all_nine',false,'native_timely_at_return',false,'route_candidate',false, ...
                    'storage_attempted',false,'storage_timely',[], ...
                    'storage_within_trial_clock',[], ...
                    'acquisition_predictor',struct('strategy',o.AcquisitionStrategy, ...
                    'rate_angle_ratio',ratio,'attachment_claimed',false));
                trialRecorded=false;trialSummaryIndex=[];acceptedSourceAdded=false;
                try
                    assert(~hasNativePending(summary),'C1Daughter:Pending','A pending native result must be resolved before another trial.');
                    predicted=seed;previous=diff(predicted.state(angles));
                    % diff([a,b]) is b-a; selector below explicitly uses a-b.
                    change=amplitude+previous;
                    predicted.state(angles)=predicted.state(angles)+[change;-change]/2;
                    predicted.state(rates)=predicted.state(rates)+ratio*[change;-change]/2;
                    predicted.provenance.parent_source=sourceMetadata.provenance;
                    predicted.provenance.predictor_only=true;
                    [daughter,report,rawReport]=correct(predicted,'none',angles,amplitude,o.DerivativeStep,o.Algorithm);
                    trial.native_all_nine=nine(rawReport);trial.native_timely_at_return=report.within_original_clock;
                    trial.predicted_state=predicted.state;trial.final_candidate=report.final_candidate;
                    if trial.native_all_nine,holdNative(daughter,rawReport,'daughter',trial);check();end
                    report.acquisition_predictor=trial.acquisition_predictor;
                    trial.report=compact(report);trial.status=report.status;
                    if nine(report)&&isa(daughter,'HybridOrbit_v3')
                        g=report.classification;trial.classification=g;
                        originalDaughter=diff(daughter.initial_state(originalAngles));
                        trial.original_split_retained=sign(originalDaughter)==sign(originalSplit)&& ...
                            abs(originalDaughter)>=.75*abs(originalSplit);
                        trial.parent_distance=norm((daughter.initial_state(2:end)-parent.initial_state(2:end))./ ...
                            max(1,abs(parent.initial_state(2:end))),inf);
                        trial.actual_amplitude=daughter.initial_state(angles(1))-daughter.initial_state(angles(2));
                        trial.relative_period_change=relativeChange(daughter.period,parent.period);
                        trial.relative_stride_change=relativeChange(daughter.stride_displacement,parent.stride_displacement);
                        trial.period_stride_capture=trial.relative_period_change<=.02&&trial.relative_stride_change<=.02;
                        chart=MatchingReturnSection_v3(parent,daughter,{oldReport,report});
                        trial.same_chart=chart.compatible;
                        trial.route_candidate=one(g)&&strcmp(g.validated_gait_type,'G')&& ...
                            trial.original_split_retained&&trial.parent_distance<=o.MaximumParentDistance&& ...
                            abs(trial.actual_amplitude-amplitude)<=1e-8&&chart.compatible&&trial.period_stride_capture&&trial.native_timely_at_return;
                        % Keep every independently admitted orbit, even when
                        % its observed class is outside the requested route.
                        suffix='';if isfield(budget,'result_suffix'),suffix=budget.result_suffix;end
                        destination=fullfile(root,'Results',['C1_G_from_' parentType suffix '.mat']);
                        metadata=struct('component_identity',['from_' parentType '_' o.RunName '_' marker], ...
                            'classification',char(g.canonical_point_label),'edge_enabled',false, ...
                            'nativeE',QuadrupedEnergy_v3.evaluate(daughter.initial_state,daughter.initial_mode,daughter.parameter), ...
                            'signedmeanU',daughter.stride_displacement(1)/daughter.period, ...
                            'provenance',struct('source_file',sourceFile,'parent_index',sourceIndex, ...
                                'signed_selector',amplitude,'acquisition_mode_only',true, ...
                                'parent_attachment_claimed',false,'route_eligible',false,'route_candidate',trial.route_candidate, ...
                                'route_eligibility_requires_timely_checkpoint',true, ...
                                'run_name',o.RunName,'derivative_method',o.DerivativeMethod, ...
                                'acquisition_predictor',trial.acquisition_predictor, ...
                                'relative_period_change',trial.relative_period_change, ...
                                'relative_stride_change',trial.relative_stride_change));
                        check();
                        if ~isfile(destination)
                            BranchSolutionFile_v3.initialize(destination,struct('kind','independent_signed_daughter_acquisitions', ...
                                'parent_family',parentType,'source_file',sourceFile));
                        end
                        trial.storage_attempted=true;
                        [~,point]=BranchSolutionFile_v3.append(destination,daughter,trial.report,metadata);
                        summary.pending_admission.saved_file=destination;summary.pending_admission.saved_point=point;
                        summary.pending_admission.stage='append_returned_readback_pending';saveProgress('daughter_append_returned');
                        [storedOrbit,storedReport,storedMetadata]=BranchSolutionFile_v3.loadSolution(destination,point);
                        assertNativePublicEqual(daughter,storedOrbit,0);
                        assert(isequaln(trial.report,storedReport)&&isequaln(metadata,storedMetadata), ...
                            'C1Daughter:StoredReadback','The compact report or point metadata differs after append.');
                        trial.saved_file=destination;trial.saved_point=point;
                        trial.storage_timely=left()>0;trial.storage_within_trial_clock=beforeDeadline(report.acquisition_deadlines);
                        summary.attempts{end+1}=trial;trialRecorded=true;trialSummaryIndex=numel(summary.attempts);
                        clearNativePending('daughter_append_readback_confirmed');
                        trial.storage_timely=trial.storage_timely&&left()>0;
                        trial.storage_within_trial_clock=trial.storage_within_trial_clock&&beforeDeadline(report.acquisition_deadlines);
                        trial.accepted_G=trial.route_candidate&&trial.native_timely_at_return&&trial.storage_timely&&trial.storage_within_trial_clock;
                        if trial.accepted_G
                            summary.accepted_sources{end+1}=struct('file',destination,'point',point, ...
                                'parent_index',sourceIndex,'amplitude',amplitude,'label',char(g.canonical_point_label), ...
                                'run_name',o.RunName,'storage_timely',trial.storage_timely, ...
                                'storage_within_trial_clock',trial.storage_within_trial_clock);
                            acceptedSourceAdded=true;
                        end
                    end
                catch problem
                    trial.status='exception';trial.failure=exception(problem);trial.accepted_G=false;
                end
                if trialRecorded,summary.attempts{trialSummaryIndex}=trial;else,summary.attempts{end+1}=trial;end
                saveProgress('attempt');
                if trial.native_all_nine&&trialRecorded&&isfield(trial,'saved_point')
                    checkpointTimely=left()>0;checkpointWithinTrial=beforeDeadline(report.acquisition_deadlines);
                    if ~checkpointTimely||~checkpointWithinTrial
                        trial.storage_timely=trial.storage_timely&&checkpointTimely;
                        trial.storage_within_trial_clock=trial.storage_within_trial_clock&&checkpointWithinTrial;
                        trial.accepted_G=false;
                        if acceptedSourceAdded,summary.accepted_sources(end)=[];end
                        summary.attempts{trialSummaryIndex}=trial;saveProgress('late_checkpoint_storage');
                    end
                end
                fprintf('C1 daughter %s parent %d A=%+.5g status=%s G=%d\n', ...
                    parentType,sourceIndex,amplitude,trial.status,trial.accepted_G);
                if hasNativePending(summary)
                    item.status='native_admission_pending';stopAfterParent=true;break
                elseif trial.native_all_nine&&(~trial.native_timely_at_return||~isequal(trial.storage_timely,true)||~isequal(trial.storage_within_trial_clock,true))
                    item.status='late_native_retained';stopAfterParent=true;break
                end
            end
            if ~stopAfterParent,item.status='searched';end
        catch problem
            if strcmp(problem.identifier,'C1Daughter:ParentControlLate')
                item.status='parent_control_late_native_retained';stopAfterParent=true;
            elseif strcmp(problem.identifier,'C1Daughter:ParentCapture')
                item.status='parent_control_left_source_neighborhood';
            else,item.status='parent_or_probe_failed';end
            item.failure=exception(problem);
        end
        summary.parents{end+1}=item;summary.active_parent=struct();saveProgress('parent');
        fprintf('C1 remaining-pair %s parent %d %s\n',parentType,sourceIndex,item.status);
        if hasNativePending(summary)||stopAfterParent
            summary.status=item.status;summary.completed=false;saveProgress('native_retained_stop');return
        end
    end
    summary.completed=true;summary.status='completed';summary.completed_utc=stamp();saveProgress('complete');

    function [orbit,report,rawReport]=correct(seed,symmetry,pair,target,step,algorithm)
        check();duration=min(o.TrialSeconds,left());
        localLimit=min(limit,double(java.lang.System.nanoTime)+duration*1e9);
        localUTC=min(budget.research_deadline_unix_seconds,nowUnix()+duration);
        deadlines=struct('deadline_unix_seconds',localUTC,'deadline_monotonic_ns',localLimit);
        globalLimit=limit;globalUTC=budget.research_deadline_unix_seconds;
        integration=struct('RelTol',1e-11,'AbsTol',1e-13,'MaxStep',.005, ...
            'ODEOptions',odeset('OutputFcn',@(~,~,~)daughterClockGuard(globalLimit,globalUTC,localLimit,localUTC)));
        map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(4), ...
            HybridSimulator_v3(integration),seed.return_policy, ...
            struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));
        family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,seed.state), ...
            seed.state,seed.mode,seed.parameter,struct('Symmetry',symmetry));
        u=family.packState(seed.state);E=QuadrupedEnergy_v3.evaluate(seed.state,seed.mode,seed.parameter);
        constraint=[];coordinates=u;
        if ~isempty(pair)
            [found,position]=ismember(pair,family.CoordinateIndices);assert(all(found),'C1Daughter:Selector');
            normal=zeros(numel(u)+1,1);normal(position)=[1;-1];
            constraint=struct('reference',zeros(size(normal)),'normal',normal,'target',target);
            coordinates=[u;E];
        end
        residual=ConstrainedEnergyResidual_v3(family,[],constraint,[]);
        if strcmp(o.DerivativeMethod,'valid-sided')
            jacobian=ValidSidedFiniteDifferenceJacobian_v3(struct('RelativeStep',step, ...
                'DeadlineUnixSeconds',localUTC,'DeadlineMonotonicNs',localLimit));
            derivativeScope='bounded valid-sided numerical acquisition at halvings 0:2; classical derivative not certified';
        else
            jacobian=FiniteDifferenceJacobian_v3(struct('RelativeStep',step, ...
                'Method','forward','FailurePolicy','error'));
            derivativeScope='ordinary forward finite differences; classical derivative not certified';
        end
        solver=struct('Algorithm',algorithm,'MaxIterations',40,'MaxFunctionEvaluations',3000, ...
            'InitialDamping',o.InitialDamping, ...
            'FunctionTolerance',1e-11,'ResidualAcceptanceTolerance',1e-10, ...
            'StepTolerance',1e-13,'OptimalityTolerance',1e-14,'UseBroyden',true, ...
            'JacobianRefreshInterval',5,'Jacobian',jacobian, ...
            'ProvideJacobianToFsolve',true);
        settings=struct('Symmetry',symmetry,'Residual',residual,'Coordinates',coordinates, ...
            'AugmentedParameter',[seed.parameter;E],'SolverOptions',solver,'MaxWallSeconds',duration);
        if ~isempty(constraint),settings.FamilyConstraint='amplitude';settings.Constraint=constraint;end
        [orbit,report]=PeriodicSolutionSolver_v3(seed,settings);
        rawReport=report;nativeReturnTimely=left()>0&&beforeDeadline(deadlines);
        report.acquisition_derivative_scope=derivativeScope;
        report.acquisition_derivative_method=o.DerivativeMethod;
        report.acquisition_relative_step=step;report.acquisition_deadlines=deadlines;
        report.delegated_residual_definition=struct('symmetry',symmetry,'coordinate_indices',family.CoordinateIndices, ...
            'energy_pivot',family.EnergyPivot,'constraint',constraint,'physical_parameters',seed.parameter);
        report.options.Residual=[];
        report.options_residual_runtime_object_omitted=true;
        report.within_original_clock=nativeReturnTimely; % Workflow evidence; native accepted/status/gates remain untouched.
    end
    function next=flow(x,seed,policy)
        check();integration=struct('RelTol',1e-11,'AbsTol',1e-13,'MaxStep',.005, ...
            'ODEOptions',odeset('OutputFcn',@(~,~,~)guard(limit,budget.research_deadline_unix_seconds)));
        map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(4), ...
            HybridSimulator_v3(integration),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));
        [next,info]=map.evaluate(x,seed.mode,seed.parameter);
        assert(info.success&&info.valid&&info.admissible&&info.discrete_closed,'C1Daughter:ProbeInvalid');
    end
    function value=odd(x)
        value=[x(angles(1))-x(angles(2));x(rates(1))-x(rates(2))];
    end
    function value=left()
        value=min((limit-double(java.lang.System.nanoTime))/1e9, ...
            budget.research_deadline_unix_seconds-posixtime(datetime('now','TimeZone','UTC')));
    end
    function check()
        assert(left()>2,'C1Daughter:Budget','Original research/local window expired.');
    end
    function status=guard(localLimit,localUTC)
        check();assert(double(java.lang.System.nanoTime)<localLimit&&nowUnix()<localUTC, ...
            'C1Daughter:TrialBudget');status=0;
    end
    function holdNative(nativeOrbit,nativeReport,kind,record)
        assert(~hasNativePending(summary)&&strcmp(class(nativeOrbit),'HybridOrbit_v3')&&isscalar(nativeOrbit)&&nine(nativeReport), ...
            'C1Daughter:Pending','One exact native all-nine payload must be retained before compaction.');
        summary.pending_admission=struct('orbit',nativeOrbit,'raw_report',nativeReport,'kind',kind, ...
            'record',record,'committed',false,'edge_claimed',false,'stage','before_compaction_or_storage');
        saveProgress('native_admission_pending');
    end
    function clearNativePending(phase)
        held=summary.pending_admission;summary.pending_admission=struct();
        try,saveProgress(phase);catch problem,summary.pending_admission=held;rethrow(problem);end
    end
    function saveProgress(phase)
        temporary=[file '.pending.mat']; % Keep a successfully written raw stage if strict readback/publication refuses.
        save(temporary,'summary','-v7');savedProgress=load(temporary,'summary');
        assert(isfield(savedProgress,'summary'),'C1Daughter:ProgressReadback','The checkpoint summary variable is absent.');
        [expected,restored]=checkpointCopies(summary,savedProgress.summary);assertNativePublicEqual(expected,restored,0);
        [ok,message]=movefile(temporary,file,'f');
        assert(ok,'C1Daughter:Progress','%s',message);
        status=conciseStatus(summary,o,parentType,phase);
        status.clock_remaining_seconds_at_snapshot=left();
        writeStatus(jsonFile,status);
    end
end
function seed=seedOf(orbit,policy,index)
    seed=struct('state',orbit.initial_state(:),'mode',orbit.initial_mode(:), ...
        'parameter',orbit.parameter(:),'return_policy',policy,'occurrence',orbit.return_multiplicity, ...
        'provenance',struct('kind','remaining-pair acquisition','source_index',index));
end
function result=compact(report)
    if isfield(report,'options') && isfield(report.options,'SolverOptions') && ...
            isfield(report.options.SolverOptions,'Jacobian')
        jacobian=report.options.SolverOptions.Jacobian;
        if any(strcmp(class(jacobian),{'FiniteDifferenceJacobian_v3','ValidSidedFiniteDifferenceJacobian_v3'}))
            keys={'Method';'RelativeStep';'MinimumStep';'MaximumStep';'CheckFinite';'FailurePolicy'};
            if strcmp(class(jacobian),'ValidSidedFiniteDifferenceJacobian_v3')
                keys=[keys;{'DeadlineUnixSeconds';'DeadlineMonotonicNs';'MaximumHalvings'}];
            end
            assert(isscalar(jacobian)&&isequal(sort(properties(jacobian)),sort(keys)), ...
                'C1Daughter:JacobianSettings','Only the complete known six- or nine-property Jacobian is serialized.');
            descriptor=struct('diagnostic_kind','runtime-object-descriptor', ...
                'source_class',class(jacobian),'requires_runtime_reconstruction',true, ...
                'settings',struct());
            for k=1:numel(keys),descriptor.settings.(keys{k})=jacobian.(keys{k});end
            report.options.SolverOptions.Jacobian=descriptor;
            report.options_jacobian_runtime_descriptor_saved=true;
        end
    end
    [value,~]=CompactResearchBranch_v3(struct('report',report));result=value.report;
end
function change=relativeChange(value,reference)
    change=Inf;
    if ~isnumeric(value)||~isnumeric(reference)||~isreal(value)||~isreal(reference)|| ...
            isempty(reference)||numel(value)~=numel(reference)|| ...
            any(~isfinite(value(:)))||any(~isfinite(reference(:))),return;end
    difference=norm(value(:)-reference(:),Inf);scale=norm(reference(:),Inf);
    if scale>0,change=difference/scale;
    elseif difference==0,change=0;end
end
function yes=beforeDeadline(deadline)
    yes=nowUnix()<deadline.deadline_unix_seconds&& ...
        double(java.lang.System.nanoTime)<deadline.deadline_monotonic_ns;
end
function value=nowUnix()
    value=posixtime(datetime('now','TimeZone','UTC'));
end
function out=conciseStatus(summary,o,parentType,phase)
    out=struct('schema','C1-daughter-search-status-v1','run_name',o.RunName, ...
        'parent_type',parentType,'derivative_method',o.DerivativeMethod, ...
        'acquisition_strategy',o.AcquisitionStrategy,'direct_rate_angle_ratio',o.DirectRateAngleRatio, ...
        'parent_requested_count',numel(summary.identity.source_indices), ...
        'parent_recorded_count',numel(summary.parents),'parent_searched_count',0, ...
        'parent_failed_count',0,'attempt_count',numel(summary.attempts), ...
        'accepted_G_count',numel(summary.accepted_sources),'timely_stored_G_count',0, ...
        'accepted_G',{summary.accepted_sources},'completed',summary.completed,'phase',phase, ...
        'pending_native_admission',hasNativePending(summary),'workflow_status',summary.status, ...
        'last_status','not_started','last_failure',struct(),'last_full_closure',[], ...
        'last_attempt_parent_index',[],'last_attempt_status','', ...
        'last_parent_status','','last_parent_failure',struct(), ...
        'started_utc',summary.started_utc,'updated_utc',stamp());
    for k=1:numel(summary.parents)
        out.parent_searched_count=out.parent_searched_count+strcmp(summary.parents{k}.status,'searched');
        out.parent_failed_count=out.parent_failed_count+any(strcmp(summary.parents{k}.status, ...
            {'parent_or_probe_failed','parent_control_left_source_neighborhood','parent_control_late_native_retained'}));
    end
    for k=1:numel(summary.accepted_sources)
        out.timely_stored_G_count=out.timely_stored_G_count+isequal(summary.accepted_sources{k}.storage_timely,true);
    end
    if ~isempty(summary.parents)
        row=summary.parents{end};out.last_status=row.status;out.last_failure=briefFailure(row.failure);
        out.last_parent_status=row.status;out.last_parent_failure=out.last_failure;
    end
    if ~isempty(summary.attempts)
        row=summary.attempts{end};out.last_status=row.status;out.last_failure=briefFailure(row.failure);
        out.last_attempt_status=row.status;out.last_attempt_parent_index=row.parent_index;
        if isfield(row,'report')
            if isfield(row.report,'full_closure')&&isnumeric(row.report.full_closure)&& ...
                    isreal(row.report.full_closure)&&isscalar(row.report.full_closure)
                value=row.report.full_closure;
                if isfinite(value),out.last_full_closure=value;
                else,out.last_full_closure=sprintf('%.17g',value);end
            end
            if isempty(fieldnames(out.last_failure))
                for name={'primary_failure','replay_failure','finalization_failure'}
                    if isfield(row.report,name{1})
                        out.last_failure=briefFailure(row.report.(name{1}));
                        if ~isempty(fieldnames(out.last_failure)),break;end
                    end
                end
            end
        end
    end
    if ~isempty(summary.parents)&&(strcmp(phase,'parent')|| ...
            (strcmp(phase,'complete')&&~isempty(fieldnames(out.last_parent_failure))))
        out.last_status=out.last_parent_status;out.last_failure=out.last_parent_failure;
    end
    out.active_parent_predictor=struct('saved',false);out.last_parent_predictor=struct('saved',false);
    if isfield(summary,'active_parent'),out.active_parent_predictor=predictorStatus(summary.active_parent);end
    if ~isempty(summary.parents),out.last_parent_predictor=predictorStatus(summary.parents{end});end
    if strcmp(phase,'parent_predictor')&&out.active_parent_predictor.saved,out.last_status=out.active_parent_predictor.status;end
end
function out=predictorStatus(p)
    out=struct('saved',isstruct(p)&&isscalar(p)&&~isempty(fieldnames(p)),'probes',{{}});if ~out.saved,return;end
    for key={'source_index','status','original_split','rate_angle_ratio'}
        if isfield(p,key{1}),out.(key{1})=statusValue(p.(key{1}));end
    end
    if isfield(p,'control_report')
        report=p.control_report;if isfield(report,'status'),out.control_status=report.status;end
        if isfield(report,'full_closure'),out.control_full_closure=statusValue(report.full_closure);end
    end
    if isfield(p,'probes'),for k=1:numel(p.probes)
        probe=p.probes{k};row=struct();
        for key={'step','distance_to_one','full13_leakage','side_disagreement','full13_side_disagreement'}
            if isfield(probe,key{1}),row.(key{1})=statusValue(probe.(key{1}));end
        end
        if isfield(probe,'selected_eigenvalue')
            row.lambda_real=statusValue(real(probe.selected_eigenvalue));row.lambda_imag=statusValue(imag(probe.selected_eigenvalue));
        end
        if isfield(probe,'matrix'),row.matrix_real=statusValue(real(probe.matrix));row.matrix_imag=statusValue(imag(probe.matrix));end
        out.probes{end+1,1}=row;
    end,end
end
function value=statusValue(value)
    if isnumeric(value)&&any(~isfinite(value(:)))
        value=arrayfun(@(x)sprintf('%.17g',x),value,'UniformOutput',false);
    end
end
function out=briefFailure(value)
    out=struct();
    if isstruct(value)&&isscalar(value)&&all(isfield(value,{'identifier','message'}))
        out=struct('identifier',value.identifier,'message',value.message);
    end
end
function writeStatus(file,value)
    stage=[tempname(fileparts(file)),'.json'];cleaner=onCleanup(@()removeStage(stage));
    fid=fopen(stage,'w');assert(fid>=0,'C1Daughter:StatusJSON');
    closer=onCleanup(@()fclose(fid));fprintf(fid,'%s\n',jsonencode(value));clear closer
    [ok,message]=movefile(stage,file,'f');assert(ok,'C1Daughter:StatusJSON','%s',message);clear cleaner
end
function removeStage(file)
    if isfile(file),delete(file);end
end
function yes=one(g)
    yes=isfield(g,'flight_count_certain')&&g.flight_count_certain&&g.flight_count==1&& ...
        strcmp(g.contract_version,'quadruped-gait-v3.5');
end
function yes=nine(report)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation', ...
        'unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    yes=report.accepted&&all(isfield(report.acceptance_gates,keys));
    if yes,yes=all(cellfun(@(k)isequal(report.acceptance_gates.(k),true),keys));end
end
function out=exception(problem)
    out=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);
end
function out=stamp()
    out=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
end

function yes=hasNativePending(summary)
    yes=isfield(summary,'pending_admission')&&isstruct(summary.pending_admission)&&~isempty(fieldnames(summary.pending_admission));
end
function [expected,restored]=checkpointCopies(expected,restored)
    assert(isstruct(expected)&&isscalar(expected)&&isstruct(restored)&&isscalar(restored)&&isequal(fieldnames(expected),fieldnames(restored)), ...
        'C1Daughter:ProgressReadback','Checkpoint summary fields differ.');
    if hasNativePending(expected)
        p=expected.pending_admission;r=restored.pending_admission;
        assert(isstruct(r)&&isscalar(r)&&isequal(fieldnames(p),fieldnames(r))&& ...
            isstruct(p.raw_report)&&isscalar(p.raw_report)&&isstruct(r.raw_report)&&isscalar(r.raw_report)&& ...
            isequal(fieldnames(p.raw_report),fieldnames(r.raw_report))&&nine(p.raw_report)&&nine(r.raw_report)&& ...
            isequaln(p.raw_report.acceptance_gates,r.raw_report.acceptance_gates), ...
            'C1Daughter:PendingReadback','The pending native report schema or acceptance gates differ.');
        for f={'accepted','status','native_status'}
            if isfield(p.raw_report,f{1}),assert(isequaln(p.raw_report.(f{1}),r.raw_report.(f{1})), ...
                    'C1Daughter:PendingReadback','A pending native status field differs.');end
        end
        assertNativePublicEqual(p.orbit,r.orbit,0);
        % Only comparison copies omit runtime handles; the raw saved payload is unchanged.
        expected.pending_admission=rmfield(p,{'orbit','raw_report'});restored.pending_admission=rmfield(r,{'orbit','raw_report'});
    end
end
function assertNativePublicEqual(a,b,depth)
    assert(depth<=128&&strcmp(class(a),class(b))&&isequal(size(a),size(b)), ...
        'C1Daughter:PublicReadback','Native/public class, shape or nesting differs.');
    if isnumeric(a)||islogical(a),assert(issparse(a)==issparse(b)&&isreal(a)==isreal(b)&&isequaln(a,b), ...
            'C1Daughter:PublicReadback','Public numeric values or storage type differ.');
    elseif ischar(a)||isstring(a),assert(isequaln(a,b),'C1Daughter:PublicReadback','Public text differs.');
    elseif iscell(a),for k=1:numel(a),assertNativePublicEqual(a{k},b{k},depth+1);end
    elseif isstruct(a),keys=fieldnames(a);assert(isequal(keys,fieldnames(b)),'C1Daughter:PublicReadback','Public structure fields differ.');
        for i=1:numel(a),for j=1:numel(keys),assertNativePublicEqual(a(i).(keys{j}),b(i).(keys{j}),depth+1);end,end
    else
        assert(any(strcmp(class(a),{'HybridOrbit_v3','Trajectory_v3'})),'C1Daughter:PublicReadback','Unsupported public object class.');
        keys=sort(properties(a));assert(isequal(keys,sort(properties(b))),'C1Daughter:PublicReadback','Public native properties differ.');
        for i=1:numel(a),for j=1:numel(keys),assertNativePublicEqual(a(i).(keys{j}),b(i).(keys{j}),depth+1);end,end
    end
end
function status=daughterClockGuard(globalLimit,globalUTC,localLimit,localUTC)
    remaining=min((globalLimit-double(java.lang.System.nanoTime))/1e9,globalUTC-nowUnix());
    assert(remaining>2,'C1Daughter:Budget','Original research/local window expired.');
    assert(double(java.lang.System.nanoTime)<localLimit&&nowUnix()<localUTC, ...
        'C1Daughter:TrialBudget','Original trial clock expired.');status=0;
end
