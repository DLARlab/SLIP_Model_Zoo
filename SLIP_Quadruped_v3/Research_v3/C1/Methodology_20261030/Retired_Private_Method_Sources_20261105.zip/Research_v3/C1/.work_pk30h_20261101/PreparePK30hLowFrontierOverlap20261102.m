function result=PreparePK30hLowFrontierOverlap20261102(B,bindings,options)
%PREPAREPK30HLOWFRONTIEROVERLAP20261102 One saved pair, one target branch.
% Target only selects a positive signed PAL plane. No new physics/replay or
% frontier retirement is authorized by this finite numerical plan.
    entryUTC=nowUTC();entryMono=nowMono();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort( ...
        {'SourceReference';'SourceClosureReference';'TargetReference';'TargetAuthorityReference'})) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&options.MaxWallSeconds==360&&options.SaveMarginSeconds==30&&B.capture.pid==feature('getpid'), ...
        'PKLowPlan:Inputs','Use the exact saved pair/target authorities and fixed new360/30 original-grant service.');
    assert(min(B.research_deadline_unix_seconds-entryUTC,(B.research_deadline_monotonic_ns-entryMono)/1e9)>362, ...
        'PKLowPlan:WholeFit','The complete new360/30 saved-data service must fit the unchanged original science clocks.');
    finish=struct('deadline_unix_seconds',entryUTC+360,'deadline_monotonic_ns',entryMono+360e9);work=struct('deadline_unix_seconds',finish.deadline_unix_seconds-30,'deadline_monotonic_ns',finish.deadline_monotonic_ns-30e9);
    sourceRef=bindings.SourceReference;targetRef=bindings.TargetReference;pair=[49,50];
    assert(strcmp(sourceRef.sha256,'a2f371cf68f3480dcf3a4b698e9243b5c9b5da988ffe5f19bf974974193e9a0f') ...
        &&strcmp(targetRef.sha256,'95fcae1ace29e0fdf1bcd42bd46a0b3c7d78b1c5b75e78c17ece73607d906a67'), ...
        'PKLowPlan:Generations','Use current closed LOW[49,50] against the exact grown0072Low generation, never a live path.');
    code=providers();refs=[struct2cell(bindings);code];verify(refs);check(work);
    closed=jsondecode(fileread(bindings.SourceClosureReference.file));closedRefs=closed.branch_references;if isstruct(closedRefs),closedRefs=num2cell(closedRefs(:));end
    assert(strcmp(closed.schema,'PK30h-continuation-window-external-closure-v1')&&closed.process.actual_tool_exit_observed&&closed.process.exit_code==0 ...
        &&closed.independent_post_guard.all_passed&&closed.independent_post_guard.process_absence_verified ...
        &&sum(cellfun(@(r)strcmp(r.file,sourceRef.file)&&strcmp(r.sha256,sourceRef.sha256),closedRefs))==1, ...
        'PKLowPlan:ClosedSource','Actual source tool exit/postguard and exact immutable branch generation remain separate facts.');
    output=literal(options.OutputFile);stage=[output,'.pending.mat'];failureFile=[output,'.failure.mat'];
    assert(startsWith(output,[literal(fullfile(N,'Audits')),filesep])&&all(cellfun(@(f)~isfile(f)&&~isfolder(f),{output;stage;failureFile})), ...
        'PKLowPlan:Fresh','Preserve any old/uncertain plan/stage/failure and use a fresh own output.');
    plan=struct('schema','PK30h-narrow-current-LOW-frontier-PAL-plan-v1','completed',false,'source_posthash',false,'bindings',bindings,'source_code',{code}, ...
        'original_budget',B,'operation_finish',finish,'operation_work',work,'source_pair',pair,'source_headers',{{}},'target_headers',{{}},'rows',{{}}, ...
        'exact_E_observations',{{}},'best_any_eligible',struct(),'best_with_next_owned_P',struct(),'input_references',{refs},'failure',struct(), ...
        'new_Root_Map_ODE_replay_fine_classifier_calls',0,'fresh_admission_claimed',false,'M_earned_by_this_plan',false,'frontier_retirement_authorized',false,'scientific_completion_claimed',false,'own_process_exit_claimed',false);
    result=struct('completed',false,'source_posthash',false,'plan_reference',struct(),'eligible_count',0,'exact_E_count',0,'stage_save_returned',false,'publication_returned',false,'failure',struct(),'own_process_exit_claimed',false);
    try
        sourceIx=BranchSolutionFile_v3.index(sourceRef.file);targetIx=BranchSolutionFile_v3.index(targetRef.file);
        assert(numel(sourceIx.points)>=50&&numel(targetIx.points)==54,'PKLowPlan:BoundedSource','Use only the two explicit current donor records and all54 actual grown-target occurrences.');
        sourceEdge=auEdge(sourceIx,49,50);plan.source_owned_edge=sourceEdge;source=acquire(sourceRef,pair,work);target=acquire(targetRef,1:54,work);
        sourceContexts=cell(2,1);targetContexts=cell(54,1);targetHeaders=cell(54,1);
        for k=1:2,sourceContexts{k}=context(source.orbits{k},source.reports{k});plan.source_headers{k,1}=header(source.orbits{k},source.reports{k},source.metadata{k},sourceRef,pair(k),sourceContexts{k});end
        for k=1:54,targetContexts{k}=context(target.orbits{k},target.reports{k});targetHeaders{k}=header(target.orbits{k},target.reports{k},target.metadata{k},targetRef,k,targetContexts{k});end
        plan.target_headers=targetHeaders;plan.public_acquisition=struct('source_calls',2,'source_indices',pair,'target_calls',2,'target_indices',1:54,'one_handle_witness_per_file',true,'full_public_report_metadata_digest_read2_verified',true,'native_cache_shared_across_passes',false,'maximum_native_group_records',54);
        ca=sourceContexts{1};cb=sourceContexts{2};base=source.orbits{2};ranking=zeros(0,4);rankingNext=zeros(0,4);
        for k=1:54
            check(work);ct=targetContexts{k};t=target.orbits{k};row=struct('target_reference',targetRef,'target_index',k,'target_native_id',OrbitContentIdentity_v3(t), ...
                'source_reference',sourceRef,'source_pair',pair,'source_native_ids',{{plan.source_headers{1}.native_id;plan.source_headers{2}.native_id}}, ...
                'geometry',struct(),'failure',struct(),'outgoing_owned_P',{{}},'incoming_owned_P',{{}},'eligible',false,'target_is_root_seed',false,'M_earned',false);
            try
                assert(ca.supported&&cb.supported&&ct.supported&&ca.cohort_supported&&cb.cohort_supported&&ct.cohort_supported ...
                    &&sameValue(ca.cohort,cb.cohort)&&sameValue(cb.cohort,ct.cohort)&&isequaln(ca.return_multiplicity,cb.return_multiplicity)&&isequaln(cb.return_multiplicity,ct.return_multiplicity), ...
                    'PKLowPlan:CohortMultiplicity','Require actual nonempty symbolic cohort and literal return multiplicity; no event-time equality or defaults-as-evidence.');
                g=screen(source,target,pair,k,sourceIx);
                if g.eligible
                    pred=base.initial_state;pred(g.coordinate_indices)=g.predictor_coordinates;pred([9,11,13])=pred(7);pred([10,12,14])=pred(8);
                    scale=max([ones(13,1),abs(pred(2:14)),abs(t.initial_state(2:14))],[],2);full13=norm((pred(2:14)-t.initial_state(2:14))./scale,Inf);
                    g.full13_predictor_target_scaled_inf=full13;g.PAL_normal=[g.tangent./g.scale;0];g.base_nativeE_index=sourceIx.points{50}.nativeE;
                    g.full13_scope='Separate full-state eligibility only; never feeds/renormalizes source4D scale, normal or signed ds.';g.eligible=full13<=.001;
                end
                row.geometry=g;row.eligible=g.eligible;
                if ~isempty(fieldnames(g.failure)),row.failure=g.failure;end
            catch problem,row.failure=fail(problem);end
            out=find(cellfun(@(e)e.from==k&&edgeOwner(targetIx,e),targetIx.edges));in=find(cellfun(@(e)e.to==k&&edgeOwner(targetIx,e),targetIx.edges));
            for j=out(:).',e=targetIx.edges{j};row.outgoing_owned_P{end+1,1}=neighbor(target,k,e.to,e,targetHeaders,source,pair);end
            for j=in(:).',e=targetIx.edges{j};row.incoming_owned_P{end+1,1}=struct('stored_edge',e,'neighbor_header',targetHeaders{e.from},'traversal_if_used',[k,e.from],'reversed_saved_P_direction',true,'automatic_reorientation_authorized',false);end
            if exactE(base,t,source.reports{2},target.reports{k},cb,ct)
                plan.exact_E_observations{end+1,1}=struct('source_head_header',plan.source_headers{2},'target_header',targetHeaders{k},'matching_original_sections',MatchingReturnSection_v3(base,t,{source.reports{2},target.reports{k}}), ...
                    'complete_original_context_equal',true,'raw_record_typed_digest',C1ScientificDigest_v3(auRecord(base)),'outgoing_owned_P',{row.outgoing_owned_P},'physical_edge_created',false,'new_admission_claimed',false,'frontier_retirement_authorized',false);
            end
            plan.rows{k,1}=row;
            if row.eligible,score=[row.geometry.full13_predictor_target_scaled_inf,row.geometry.predictor_distance,k,k];ranking(end+1,:)=score;if any(cellfun(@(n)n.context_compatible,row.outgoing_owned_P)),rankingNext(end+1,:)=score;end;end
        end
        if ~isempty(ranking),ranking=sortrows(ranking,[1,2,3]);plan.best_any_eligible=plan.rows{ranking(1,4)};end
        if ~isempty(rankingNext),rankingNext=sortrows(rankingNext,[1,2,3]);plan.best_with_next_owned_P=plan.rows{rankingNext(1,4)};end
        plan.eligible_count=size(ranking,1);plan.eligible_with_next_owned_P_count=size(rankingNext,1);plan.exact_E_count=numel(plan.exact_E_observations);
        plan.selection_rule='All54 targets, fixed donor49-to50 only. Positive signed4Dds1e-7..04 and predictor4Dnorm<=.001 plus separate full13scaledInf<=.001. Best full13,then4Ddistance,then literal targetindex. Best with actual full-context-compatible forward ownedP reported separately; no cosine gate/automatic flip/nearestspeed/samecomponent exclusion.';
        plan.scope='Saved recorded admission epochs only. Future generic publicAcquire/current literal-state fine profiles and actual cold P/M proof are separate work. No eligible bounded plane or nextP is not nonexistence, permanentblock, coverage exhaustion or frontier closure. Energy-pivot regularity remains UNASSESSED until actualRun.';
        verify(refs);check(work);plan.source_posthash=true;plan.completed=true;plan.elapsed_seconds=(nowMono()-entryMono)/1e9;plan_digest=C1ScientificDigest_v3(plan);save(stage,'plan','plan_digest','-v7');result.stage_save_returned=true;
        read2(stage,plan);verify(refs);check(finish);stageHash=RoundSHA256_v3(stage);assert(~isfile(output),'PKLowPlan:PublishFresh','Preserve a concurrent result.');javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());result.publication_returned=true;
        assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),stageHash)&&strcmp(RoundSHA256_v3(output),stageHash),'PKLowPlan:OwnStage','Unlink only the unchanged linked own stage.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());read2(output,plan);verify(refs);check(finish);
        result.completed=true;result.source_posthash=true;result.plan_reference=reference(output);result.eligible_count=plan.eligible_count;result.exact_E_count=plan.exact_E_count;result.best_any_eligible=smallBest(plan.best_any_eligible);result.best_with_next_owned_P=smallBest(plan.best_with_next_owned_P);
    catch problem
        result.failure=fail(problem);plan.completed=false;plan.failure=result.failure;if ~isfile(failureFile),plan_digest=C1ScientificDigest_v3(plan);operation_result=result;save(failureFile,'plan','plan_digest','operation_result','-v7');end
    end
    try,fprintf('PK30H_LOW_FRONTIER_PLAN_RETURN %s\n',jsonencode(result));catch,end
end
function d=acquire(r,indices,work)
    verify({r});first=cell(numel(indices),1);firstIDs=cell(numel(indices),1);
    for pass=1:2
        check(work);[orbits,reports,metadata]=BranchSolutionFile_v3.loadSolutions(r.file,indices);
        if pass==2,assert(~(kept==orbits{1}),'PKLowPlan:Independent','Two actual public acquisitions need independently deserialized native records.');end
        for k=1:numel(indices),digest=C1ScientificDigest_v3(struct('orbit',public(orbits{k}),'report',public(reports{k}),'metadata',metadata{k}));if pass==1,first{k}=digest;firstIDs{k}=OrbitContentIdentity_v3(orbits{k});else,assert(strcmp(first{k},digest)&&strcmp(firstIDs{k},OrbitContentIdentity_v3(orbits{k})),'PKLowPlan:Read2','Full public orbit/report/metadata values changed across independent source reads.');end;end
        if pass==1,kept=orbits{1};clear orbits reports metadata;end
    end
    verify({r});d=struct('indices',indices(:),'orbits',{orbits},'reports',{reports},'metadata',{metadata});
end
function c=context(o,r)
    token=o.event_cluster_signature;cohortSupported=((ischar(token)&&isrow(token))||(isstring(token)&&isscalar(token)))&&strlength(string(token))>0;
    cohort=struct('event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature,'event_cluster_members',{o.event_cluster_members},'event_cluster_names',{o.event_cluster_names},'section_cluster_coincidence',o.section_cluster_coincidence,'section_coincident_cluster_indices',o.section_coincident_cluster_indices);
    [~,p]=RecordedReturnPolicy_v3(r);c=struct('cohort',cohort,'cohort_supported',cohortSupported,'return_multiplicity',o.return_multiplicity,'complete_policy',p,'supported',admitted(r)&&p.complete,'recorded_admission_epoch_only',true);
end
function h=header(o,r,m,ref,index,c)
    h=struct('reference',ref,'index',index,'native_id',OrbitContentIdentity_v3(o),'native_class',class(o),'record',auRecord(o),'context',c,'metadata',m, ...
        'saved_admission',struct('accepted',member(r,'accepted',[]),'acceptance_gates',member(r,'acceptance_gates',struct()),'classification',auPick(member(r,'classification',struct()),{'contract_version','canonical_point_label','canonical_label_qualified','validated_gait_type','flight_count','flight_count_certain','primitive_flight_count','period_used','status'})), ...
        'record_typed_digest',C1ScientificDigest_v3(auRecord(o)),'fresh_admission_claimed',false);
end
function n=neighbor(target,index,next,e,headers,source,pair)
    [a,~,~]=get(source,pair(1));[b,~,~]=get(source,pair(2));[t,~,~]=get(target,index);[u,~,~]=get(target,next);
    scale=max([ones(13,1),abs(a.initial_state(2:14)),abs(b.initial_state(2:14)),abs(t.initial_state(2:14)),abs(u.initial_state(2:14))],[],2);
    incoming=(b.initial_state(2:14)-a.initial_state(2:14))./scale;outgoing=(u.initial_state(2:14)-t.initial_state(2:14))./scale;
    geometry=struct('status','UNASSESSED_UNRESOLVED_SECANT','raw_state_indices',2:14,'common_scale',scale,'source_incoming',incoming,'target_outgoing',outgoing,'cosine',[],'tangent_or_uniqueness_claimed',false);
    incomingNorm=norm(incoming);outgoingNorm=norm(outgoing);if isfinite(incomingNorm)&&isfinite(outgoingNorm)&&incomingNorm>0&&outgoingNorm>0,geometry.status='FINITE_SAVED_SECANT_OBSERVATION';geometry.cosine=dot(incoming,outgoing)/(incomingNorm*outgoingNorm);end
    ct=headers{index}.context;cn=headers{next}.context;compatible=ct.supported&&cn.supported&&ct.cohort_supported&&cn.cohort_supported&&sameValue(ct.cohort,cn.cohort)&&isequaln(ct.return_multiplicity,cn.return_multiplicity)&&isequaln(t.parameter,u.parameter)&&isequaln(t.initial_mode,u.initial_mode)&&sameValue(ct.complete_policy.configuration,cn.complete_policy.configuration);section=struct();
    if compatible,section=MatchingReturnSection_v3(t,u,{target.reports{index},target.reports{next}});compatible=section.compatible;end
    n=struct('stored_edge',e,'traversal',[index,next],'traversed_in_saved_P_direction',true,'neighbor_header',headers{next},'context_compatible',compatible,'matching_original_sections',section,'secant_geometry',geometry,'new_edge_created',false);
end
function yes=exactE(a,b,ra,rb,ca,cb)
    yes=strcmp(OrbitContentIdentity_v3(a),OrbitContentIdentity_v3(b))&&sameValue(auRecord(a),auRecord(b))&&ca.supported&&cb.supported&&ca.cohort_supported&&cb.cohort_supported&&sameValue(ca.cohort,cb.cohort)&&isequaln(ca.return_multiplicity,cb.return_multiplicity)&&ca.complete_policy.complete&&cb.complete_policy.complete&&sameValue(ca.complete_policy.configuration,cb.complete_policy.configuration);
    if yes,m=MatchingReturnSection_v3(a,b,{ra,rb});yes=m.compatible;end
end
function out=smallBest(row)
    out=struct();if isempty(fieldnames(row)),return;end;out=struct('source_reference',row.source_reference,'source_pair',row.source_pair,'source_native_ids',{row.source_native_ids},'target_reference',row.target_reference,'target_index',row.target_index,'target_native_id',row.target_native_id,'signed_step',row.geometry.requested_step,'predictor4D',row.geometry.predictor_distance,'full13',row.geometry.full13_predictor_target_scaled_inf,'outgoing_P_neighbors',cellfun(@(r)r.stored_edge.to,row.outgoing_owned_P));
end
function read2(file,expected),for pass=1:2,x=load(file,'plan','plan_digest');assert(strcmp(C1ScientificDigest_v3(x.plan),x.plan_digest)&&sameValue(expected,x.plan),'PKLowPlan:PlanRead2','Each complete plan read binds exact typed scalar/header/proposal values.');clear x;end;end
function yes=sameValue(a,b),yes=strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b));end
function f=fail(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKLowPlan:Changed','An immutable source, context authority or current recipe changed.');if isfield(r,'bytes'),d=dir(r.file);assert(isscalar(d)&&d.bytes==r.bytes,'PKLowPlan:Bytes','Preserve the actual whole-file byte header.');end;end;end
function r=reference(file),r=struct('file',literal(file),'sha256',RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKLowPlan:Alias','Hash and native reader must name the same literal file.');end
function check(l),assert(nowUTC()<l.deadline_unix_seconds&&nowMono()<l.deadline_monotonic_ns,'PKLowPlan:Clock','The original grant/service clocks expired; retain actual partial/published evidence.');end
function t=nowUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=nowMono(),t=double(java.lang.System.nanoTime());end
function refs=providers()
    names={'PreparePK30hLowFrontierOverlap20261102','BranchSolutionFile_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3','OrbitContentIdentity_v3','QuadrupedSchema_v3','GaitSemanticTable_v3','HybridOrbit_v3','Trajectory_v3','ReturnPolicyBase_v3','BLMarkedApexReturnPolicy_v3','EventCycleReturnPolicy_v3','IteratedReturnPolicy_v3','FirstReturnPolicy_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cellfun(@(n)reference(which(n)),names(:),'UniformOutput',false);refs{end+1,1}=reference(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end

function g=screen(source,target,pair,index,ix)
    g=struct('eligible',false,'source_pair',pair,'failure',struct(),'energy_chart_regularity','UNASSESSED_until_future_native_Run', ...
        'target_is_root_seed',false,'target_scope','Only selects the owned PAL plane.');
    try
        [a,ra,ma]=get(source,pair(1));[b,rb,mb]=get(source,pair(2));[t,rt,mt]=get(target,index);
        g.source_native_ids={OrbitContentIdentity_v3(a);OrbitContentIdentity_v3(b)};g.target_native_id=OrbitContentIdentity_v3(t);
        e=find(cellfun(@(z)isequal(sort([z.from,z.to]),sort(pair)),ix.edges));
        assert(isscalar(e)&&edgeOwner(ix,ix.edges{e})&&strcmp(ma.component_identity,mb.component_identity), ...
            'PKClosure:SourceEdge','Both explicit orientations must bind the same actual owned edge.');g.stored_edge=ix.edges{e};
        assert(admitted(ra)&&admitted(rb)&&admitted(rt),'PKClosure:Admission','Require literal saved current-contract one-flight PK/all9.');
        [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);[~,pt]=RecordedReturnPolicy_v3(rt);
        g.complete_policy_equal=pa.complete&&pb.complete&&pt.complete&&isequaln(pa.configuration,pb.configuration)&&isequaln(pb.configuration,pt.configuration);
        g.exact_pq=isequaln(a.parameter,b.parameter)&&isequaln(b.parameter,t.parameter)&&isequaln(a.initial_mode,b.initial_mode)&&isequaln(b.initial_mode,t.initial_mode);
        g.source_section=MatchingReturnSection_v3(a,b,{ra,rb});g.target_section=MatchingReturnSection_v3(b,t,{rb,rt});
        g.section_tokens_equal=isequaln(a.section_relative_event_signature,b.section_relative_event_signature)&&isequaln(b.section_relative_event_signature,t.section_relative_event_signature);
        g.cyclic_tokens_equal=isequaln(a.cyclic_event_signature,b.cyclic_event_signature)&&isequaln(b.cyclic_event_signature,t.cyclic_event_signature);
        assert(g.complete_policy_equal&&g.exact_pq&&g.source_section.compatible&&g.target_section.compatible ...
            &&g.section_tokens_equal&&g.cyclic_tokens_equal,'PKClosure:Contract','Exact saved policy/pq/marked-section/token contracts differ.');
        assert(~any(b.initial_mode)&&all(isfinite([a.initial_state(:);b.initial_state(:);t.initial_state(:)])), ...
            'PKClosure:FlightChart','Use actual all-flight raw states for the source-backed4D pronk calculation.');
        s=QuadrupedSchema_v3.shared();p=b.parameter(:);x=b.initial_state(:);parameter=s.Parameter;
        defects=[abs(x(s.State.dy)),norm(x([s.State.phi,s.State.dphi]),Inf), ...
            norm(x(s.Leg.AngleIndices)-x(s.State.alphaBL),Inf),norm(x(s.Leg.RateIndices)-x(s.State.dalphaBL),Inf), ...
            norm(p([parameter.k_l_b,parameter.k_s_b,parameter.l_l_b,parameter.rsla_b]) ...
                -p([parameter.k_l_f,parameter.k_s_f,parameter.l_l_f,parameter.rsla_f]),Inf),abs(p(parameter.l_com)-.5)];
        g.source_base_chart_defects=defects;
        assert(all(defects(1:4)<=1e-8)&&all(defects(5:6)<=1e-12), ...
            'PKClosure:PronkChart','The admitted base must satisfy the existing all-flight apex/pronk coordinate preconditions.');
        ids=[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL];
        assert(isequal(ids,[2,3,7,8]),'PKClosure:Coordinates','Retain the actual current four independent raw-coordinate indices.');
        ua=a.initial_state(ids);ua=ua(:);ub=b.initial_state(ids);ub=ub(:);ut=t.initial_state(ids);ut=ut(:);
        lift=b.initial_state(:);lift(ids)=ub;lift([9,11,13])=lift(7);lift([10,12,14])=lift(8);
        assert(isequaln(lift,b.initial_state(:)),'PKClosure:BaseLift','The unchanged admitted base must roundtrip exactly; no snap or projection.');
        scale=max([ones(4,1),abs(ua),abs(ub)],[],2);delta=(ub-ua)./scale;chord=norm(delta);
        assert(isfinite(chord)&&chord>1e-10,'PKClosure:Chord','Use a resolved actual preceding-pair chord.');tangent=delta/chord;
        ds=dot(tangent,(ut-ub)./scale);predictor=ub+scale.*(ds*tangent);
        g.coordinate_indices=ids;g.source_coordinates=[ua,ub];g.target_coordinates=ut;g.scale=scale;g.tangent=tangent;
        g.chord=chord;g.requested_step=ds;g.predictor_coordinates=predictor;g.predictor_distance=norm((ut-predictor)./scale);
        g.source_owner=ma.component_identity;g.target_owner=mt.component_identity;
        g.eligible=isfinite(ds)&&ds>=1e-7&&ds<=.04&&isfinite(g.predictor_distance)&&g.predictor_distance<=.001;
        g.scope='Run243-246 max1 preceding-pair scales and signed projection only; no abs(ds), automatic flip, target seed, Map or energy-pivot test.';
    catch e,g.failure=struct('identifier',e.identifier,'message',e.message);end
end

function [o,r,m]=get(d,index)
    k=find(d.indices==index);assert(isscalar(k),'PKClosure:SelectedIndex','One actual selected native view is required.');o=d.orbits{k};r=d.reports{k};m=d.metadata{k};
end

function yes=admitted(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    gates=member(r,'acceptance_gates',struct());g=member(r,'classification',struct());[~,version]=GaitSemanticTable_v3();
    yes=isequal(member(r,'accepted',false),true)&&all(isfield(gates,keys))&&strcmp(member(g,'contract_version',''),version) ...
        &&strcmp(member(g,'validated_gait_type',''),'PK')&&strcmp(member(g,'canonical_point_label',''),'PK') ...
        &&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1);
    for k=1:numel(keys),yes=yes&&isequal(member(gates,keys{k},false),true);end
end

function yes=edgeOwner(ix,e)
    yes=e.from>=1&&e.to>=1&&e.from<=numel(ix.points)&&e.to<=numel(ix.points) ...
        &&strcmp(ix.points{e.from}.component_identity,e.component_identity)&&strcmp(ix.points{e.to}.component_identity,e.component_identity);
end

function v=member(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end

function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end


function out=auRecord(o)
    out=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement, ...
        'return_policy_name',o.return_policy_name,'section_chart',o.section_chart,'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature);
end

function e=auEdge(ix,a,b)
    at=find(cellfun(@(e)e.from==a&&e.to==b,ix.edges));assert(isscalar(at),'PKPost:OwnedEdge','Use the actual one directed physical edge.');e=ix.edges{at};
    assert(strcmp(ix.points{a}.component_identity,e.component_identity)&&strcmp(ix.points{b}.component_identity,e.component_identity) ...
        &&isequal(ix.points{b}.metadata.edge_enabled,true)&&isequal(ix.points{b}.metadata.edge_from,a), ...
        'PKPost:OwnedEdgeOwner','Physical edge and same-owner predecessor metadata must agree.');
end


function out=auPick(s,names)
    out=struct();if ~isstruct(s)||~isscalar(s),out.unsupported_source_class=class(s);out.unsupported_source_size=size(s);return;end
    for k=1:numel(names),if isfield(s,names{k}),out.(names{k})=s.(names{k});end,end
end
