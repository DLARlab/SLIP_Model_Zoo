function RunPK30hPointAdmission01()
% Actual private four-point root-free admission experiment, not continuation.
V='/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3';addpath(V);V3AddPaths_v3(V);
N=fullfile(V,'Research_v3','C1');A=fullfile(N,'Audits');E=fullfile(N,'.work_pk30h_20261101','EventRestart_20261102');
addpath(fullfile(E,'Candidate'),'-begin');addpath(fullfile(E,'AdmissionCandidate'),'-begin');
fprintf('PK30H_FRESH_POINT_ADMISSION01_BEGIN pid=%d utc=%s\n',feature('getpid'),char(datetime('now','TimeZone','UTC','Format','yyyy-MM-dd HH:mm:ss')));
refs=cell(51,1);roles=cell(51,1);
roles{1}='gate';refs{1}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/.work_pk30h_20261101/EventRestart_20261102/AdmissionCandidate/ValidateStoredPeriodicOrbit_v3.m','sha256','7700a8a63f8f6c5700cdca173db7d623a98189f3e8a65569340b8c775639f2a9','bytes',34462);
roles{2}='source';refs{2}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/Components/C1_PK_Component_0061.mat','sha256','821ed8549ec94c7fdd28d5de37579762d0825e277a15be045472c365c01c9486','bytes',167886988);
roles{3}='green';refs{3}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/Audits/EventRestart_20261102_PrivateEarliestLifecycle01.mat','sha256','5d0b47500045534550f8fd822db49deca219d2ee6a0240431d614d045d78a45b','bytes',13238);
roles{4}='sourceplan';refs{4}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/Audits/PK30h_20261101_0061_FollowUp_Plan01.mat','sha256','fb9f2f8796d31f78a8afac425ab43f52935a9a06a74aa7be1960e987d81a31ef','bytes',26634);
roles{5}='budget';refs{5}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/Audits/PK30h_20261101_Sustained01_Plan.mat','sha256','38459ef421412b12dab9eb27afc39c8a77582bebf0ae44bbe25d3f9328c14fb2','bytes',5714);
roles{6}='PeriodicSolutionSolver_v3';refs{6}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/3_Numerical_Continuation/1_Root_Solving/PeriodicSolutionSolver_v3.m','sha256','9736edd09857c2f67ad0c2b61a5099ab82a221b81d36932866577b80de2492d0','bytes',32306);
roles{7}='PeriodicOrbitResidual_v3';refs{7}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/PeriodicOrbitResidual_v3.m','sha256','0da58152164156b56654bd9e2acc1a1bd650b8192e93fde6b291ea621cc8bd3d','bytes',14610);
roles{8}='EnergyFamilyResidual_v3';refs{8}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/EnergyFamilyResidual_v3.m','sha256','e948f36c41d9e60004b22e5b47826e4d60c8e8015c7a740ed88d1d3c443071f7','bytes',11977);
roles{9}='ConstrainedEnergyResidual_v3';refs{9}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/ConstrainedEnergyResidual_v3.m','sha256','fe268e02bbe2747ce341800bda1b4ec5d46a7233892d6b4ec2a79766b697508e','bytes',3922);
roles{10}='QuadrupedPhysicalChart_v3';refs{10}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/QuadrupedPhysicalChart_v3.m','sha256','4cae5dc8027bb2d8fa9063273bfa3b19067612c4b622df844971ae2bcc9de701','bytes',9036);
roles{11}='Quadrupedal_Dynamics_v3';refs{11}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/Quadrupedal_Dynamics_v3.m','sha256','dfd39a1c7ab2fa393f84adb43963c7d1448f4d5740a83828f4dfe9aaed01ee5d','bytes',16388);
roles{12}='QuadrupedEnergy_v3';refs{12}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/QuadrupedEnergy_v3.m','sha256','e7984e14fcb1e10f4704e9f912495eb86cd18c798fe8151a0c06161f9822e169','bytes',3161);
roles{13}='QuadrupedSchema_v3';refs{13}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Schema_v3/QuadrupedSchema_v3.m','sha256','966bfc51791dc0096a1c04c5ec698426df8cfbc18bb6be0fae78c776f94e98b5','bytes',11077);
roles{14}='HybridCycleData_v3';refs{14}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/HybridCycleData_v3.m','sha256','b0419cc58e03ba24fc409f56e37d5de607d3d3b32d90797601418e9ce636ec89','bytes',16228);
roles{15}='PrimitiveCycleCheck_v3';refs{15}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/PrimitiveCycleCheck_v3.m','sha256','4ea3628241a459f2237c115fb789fc300c2b1f77f8e24814003d8328e1e130a2','bytes',9763);
roles{16}='GaitIdentification_v3';refs{16}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/GaitIdentification_v3.m','sha256','fee53257025f5fd5ccbf662747ffe17d27e2e59c94c7e09f6802bfe2e14d22d8','bytes',27677);
roles{17}='GaitSemanticTable_v3';refs{17}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/GaitSemanticTable_v3.m','sha256','7054a9ee4cb1b71f2b403a65c0b644a202f1ea6d2f3f852b5268c22c80a0888d','bytes',1523);
roles{18}='RecordedReturnPolicy_v3';refs{18}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/RecordedReturnPolicy_v3.m','sha256','839cf5afd1eb75a3430a4bc57b122778c962596b50079de578d36d901aca330b','bytes',5132);
roles{19}='BLMarkedApexReturnPolicy_v3';refs{19}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/BLMarkedApexReturnPolicy_v3.m','sha256','d765d164b882b73367c6b711cb0c539b21d8033b70ccb0839cf69fd0859adb2a','bytes',6952);
roles{20}='IteratedReturnPolicy_v3';refs{20}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/IteratedReturnPolicy_v3.m','sha256','ec370077157f869fb96aeaa853a61dd1024d0261d005e4cfec95e09ba3e53951','bytes',1610);
roles{21}='EventCycleReturnPolicy_v3';refs{21}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/EventCycleReturnPolicy_v3.m','sha256','38179b0b9e5c6b5430f7a899056b43302f847f1b196565b343135c3bc1abb3ff','bytes',9666);
roles{22}='ReturnPolicyBase_v3';refs{22}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/ReturnPolicyBase_v3.m','sha256','7f8f778719362e4ddad95829aa64178e9105f447525eb40701c72a4ac8ab85b8','bytes',4943);
roles{23}='HybridOrbit_v3';refs{23}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/HybridOrbit_v3.m','sha256','bd73f9411bea2443a6af17d78bba41f4134772333ad3cb073f32d1d02250bf87','bytes',4270);
roles{24}='Trajectory_v3';refs{24}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Simulation_v3/Trajectory_v3.m','sha256','e963be3af5e49d856bd90d0b1c9d56ce9509ce5c72b4f3ebe991cd3ca7707f9c','bytes',15735);
roles{25}='RoundSHA256_v3';refs{25}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/RoundSHA256_v3.m','sha256','85c21249e7b5492f4c044062bc9f132e292a705cc0789b0dd4362c234453e572','bytes',524);
roles{26}='C1ScientificDigest_v3';refs{26}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/C1ScientificDigest_v3.m','sha256','0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3','bytes',3264);
roles{27}='BranchSolutionFile_v3';refs{27}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/BranchSolutionFile_v3.m','sha256','48ca4f75e2ba5967378cb94e7d617d84aaf387a7495a1492481fc6709ea45b1b','bytes',28330);
roles{28}='V3Root_v3';refs{28}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/V3Root_v3.m','sha256','82331888b04124ffd5dd1ee7737236963c41d4543e5d8c5be02dceeece94cccf','bytes',618);
roles{29}='V3Path_v3';refs{29}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/V3Path_v3.m','sha256','99ea86678b3b932beb0c90292d1924c57b2f7086cb841ff7877b0f94b7fe493b','bytes',2529);
roles{30}='private_EventDetector_v3';refs{30}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/.work_pk30h_20261101/EventRestart_20261102/Candidate/EventDetector_v3.m','sha256','a525242da9bc1b0fd966eaec73811779c0d3e2e4b3882f32bc8df69385413fe3','bytes',53800);
roles{31}='private_HybridSimulator_v3';refs{31}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/.work_pk30h_20261101/EventRestart_20261102/Candidate/HybridSimulator_v3.m','sha256','8f5f8247ea70c85fc8f2cd57a0d24b91771cbc95e06d5817b52415a176b9f267','bytes',41259);
roles{32}='private_GuardFunctions_v3';refs{32}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/.work_pk30h_20261101/EventRestart_20261102/Candidate/GuardFunctions_v3.m','sha256','23dfdd445e3fc0a535bbe84d4e001654776e5c8678bc46b803caa55019c0112b','bytes',6831);
roles{33}='private_PoincareSection_v3';refs{33}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/.work_pk30h_20261101/EventRestart_20261102/Candidate/PoincareSection_v3.m','sha256','6be1ea1fe1d5679c18fcfaf66244c658cc5e5ddfc4833e983bebcbe99665d7b9','bytes',8702);
roles{34}='private_PoincareMap_v3';refs{34}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Research_v3/C1/.work_pk30h_20261101/EventRestart_20261102/Candidate/PoincareMap_v3.m','sha256','b34464138b46ee1825334eb21708114a2471a31513f5b83e2c74ce6f9e5cc5cb','bytes',43148);
roles{35}='canonical_EventDetector_v3';refs{35}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Simulation_v3/EventDetector_v3.m','sha256','c1becd4b14d04e47134b7abca1499de7a3bedc56ea9266cd32ddb909610c6b99','bytes',33215);
roles{36}='canonical_HybridSimulator_v3';refs{36}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Simulation_v3/HybridSimulator_v3.m','sha256','e43429ed1328b2bb4fe6b2628c244341d787996168fd620fe67176b8b5220072','bytes',38662);
roles{37}='canonical_GuardFunctions_v3';refs{37}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/GuardFunctions_v3.m','sha256','4824d780d4e30249aae888f9ff8d71450e94d0abdd3ec2c9da92bf1d8e66ec80','bytes',6121);
roles{38}='canonical_PoincareSection_v3';refs{38}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/PoincareSection_v3.m','sha256','72806bf271bad9289b9d3a75a98eceb8661d30a3d7283724e623502a13a01e2e','bytes',7792);
roles{39}='canonical_PoincareMap_v3';refs{39}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/PoincareMap_v3.m','sha256','f643d2890a9acca9e9b8afed3d227079df298f0dbaacfc3f3ed5d3e9a3ac5528','bytes',42962);
roles{40}='locations';refs{40}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/Audits_v3/Folder_Organization/locations.json','sha256','33058007c05de3cb5e32719581c48e0e1b026b8088c511dcef780f3845877866','bytes',44104);

roles{41}='HybridSystemBase_v3';refs{41}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/HybridSystemBase_v3.m','sha256','0f99f6e7f06e375a13df411170bc075690c42abc12d5ae5ded69b39ca2ded46f','bytes',27287);
roles{42}='ContinuousDynamics_v3';refs{42}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/ContinuousDynamics_v3.m','sha256','f84f97312328d8d582ed57548a6b27535b776e6c4e332499fe65e0a160144195','bytes',19522);
roles{43}='ResetMap_v3';refs{43}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/ResetMap_v3.m','sha256','92a281dc5b2ccb92d740e89eb9b639f34c621d5d42dc810561af8d8bc59dd715','bytes',6934);
roles{44}='ModeTransition_v3';refs{44}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/ModeTransition_v3.m','sha256','07856a5220e842bdf6524adfd2d9a621e95fe995e310394680094b042c228832','bytes',5474);
roles{45}='QuadrupedAdmissibility_v3';refs{45}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Dynamics_v3/QuadrupedAdmissibility_v3.m','sha256','36890b0c3a8bd994560146b8a676375f5cf9b214c818503f47e66cd8c4072ca7','bytes',26600);
roles{46}='OrbitContentIdentity_v3';refs{46}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/OrbitContentIdentity_v3.m','sha256','b73c6490aedd99c335edb96e3385f2374f1328fcda6ea548b4d6f62611e9b0c2','bytes',796);
roles{47}='FirstReturnPolicy_v3';refs{47}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/FirstReturnPolicy_v3.m','sha256','511e0f2b5e80281bd807dae6c277627797525ca9369ca0e94c323144a7065ae9','bytes',751);
roles{48}='EventCluster_v3';refs{48}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Simulation_v3/EventCluster_v3.m','sha256','e3be57e25cddd85bb02c751462653c66748a60734e5f88940d9861d4f09f4cfc','bytes',23561);
roles{49}='SectionModeResolver_v3';refs{49}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/4_Solution_Management/SectionModeResolver_v3.m','sha256','b088aa9b9453e0f7f873060cb9c586a9ca6b95fd24eda5054d3e99b11c388b62','bytes',12902);
roles{50}='TouchdownDiagnostics_v3';refs{50}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/1_Dynamic_Frameworks/Simulation_v3/TouchdownDiagnostics_v3.m','sha256','df83b52e9dbbc7dbdbf4d9e57fe2468b115c9c72ba9474b9f4e6e3ef4d808349','bytes',2928);
roles{51}='AbsoluteRunBudget_v3';refs{51}=struct('file','/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3/3_Numerical_Continuation/1_Root_Solving/AbsoluteRunBudget_v3.m','sha256','18ee1c6f41de07af8a8b82327f1a2b93bfe865ce3afab9ed4d0e28d220e97e2d','bytes',2153);
checkReferences(refs);
for k=6:numel(refs)
 if startsWith(roles{k},'private_'),name=erase(roles{k},'private_');
 elseif startsWith(roles{k},'canonical_')||strcmp(roles{k},'locations'),continue;
 else,name=roles{k};end
 assert(strcmp(which(name),refs{k}.file),'PointAdmission:Provider','The exact reviewed engine/shared provider must resolve.');
end
assert(strcmp(which('ValidateStoredPeriodicOrbit_v3'),refs{1}.file),'PointAdmission:Gate','Use the reviewed proper API4 private gate.');
g=load(refs{3}.file,'audit');assert(strcmp(g.audit.schema,'event-restart-private-earliest-five-source-lifecycle-v1')&&g.audit.completed&&g.audit.source_posthash ...
 &&g.audit.restart_report.passed&&numel(g.audit.restart_report.rows)==29&&g.audit.lifecycle_report.passed&&numel(g.audit.lifecycle_report.rows)==7 ...
 &&g.audit.configuration_report.passed&&numel(g.audit.configuration_report.rows)==11&&g.audit.auxiliary_report.passed&&numel(g.audit.auxiliary_report.rows)==6 ...
 &&g.audit.default_commands_passed,'PointAdmission:RuntimeGreen','Require actual53/all four default commands under the final private engine.');
engineNames={'EventDetector_v3';'HybridSimulator_v3';'GuardFunctions_v3';'PoincareSection_v3';'PoincareMap_v3'};
for j=1:5,at=find(strcmp(roles,['private_',engineNames{j}]));assert(isscalar(at)&&strcmp(g.audit.source_references{j}.file,refs{at}.file) ...
 &&strcmp(g.audit.source_references{j}.sha256,refs{at}.sha256)&&g.audit.source_references{j}.bytes==refs{at}.bytes, ...
 'PointAdmission:ExactGreenTuple','The actual53 GREEN reference must bind this exact active final private five-file tuple.');end;clear g
z=load(refs{4}.file,'plan','plan_digest');assert(strcmp(C1ScientificDigest_v3(z.plan),z.plan_digest)&&z.plan.completed&&z.plan.source_posthash&&all(cellfun(@(r)r.context_eligible,z.plan.rows))&&all(cellfun(@(r)~r.execute,z.plan.pilot_queue)),'PointAdmission:SavedPlan','Both original saved contexts remain observations only, with no old ladder reset.');clear z
z=load(refs{5}.file,'plan');old=z.plan.original_budget;grant=struct('grant_id',old.grant_id,'start_utc',old.start_utc,'research_deadline_utc',old.research_deadline_utc,'deadline_utc',old.deadline_utc);B=AbsoluteRunBudget_v3(grant,old);clear z old
enteredUTC=nowUTC();enteredMono=nowMono();assert(min(B.research_deadline_unix_seconds-enteredUTC,(B.research_deadline_monotonic_ns-enteredMono)/1e9)>1202,'PointAdmission:Fit','The full1200/60 new operation must fit the unchanged original science grant.');
finish=struct('utc',enteredUTC+1200,'mono',enteredMono+1200e9);work=struct('utc',finish.utc-60,'mono',finish.mono-60e9);
out=fullfile(A,'PK30h_20261101_0061_FixedEngine_PointAdmission01.mat');stage=[out,'.pending.mat'];assert(~isfile(out)&&~isfile(stage)&&~isfile([stage,'.writing.mat']),'PointAdmission:Fresh','Keep all earlier source/gate results and stages.');
indices=[54;55;56;57];[sourceOrbits,sourceReports,sourceMetadata]=BranchSolutionFile_v3.loadSolutions(refs{2}.file,indices);
audit=struct('schema','PK30h-fresh-fixed-energy-point-admission-v1','input_references',{refs},'input_roles',{roles}, ...
 'source_reference',refs{2},'private_regression_reference',refs{3},'saved_frontier_plan_reference',refs{4},'original_budget',B, ...
 'operation_finish',finish,'operation_work',work,'rows',{cell(4,1)},'summaries',{cell(4,1)},'completed',false,'source_posthash',false, ...
 'all_current_all9_PK',false,'root_solver_calls',0,'correction_performed',false,'historical_P_requalified',false,'new_physical_edges_created',0, ...
 'profile_scope','Actual recorded source correction/replay values; only known ode45 and owned runtime OutputFcn are reconstructed. This differs from the matched-metrics fresh-default-event-threshold profile.', ...
 'family_scope','NEW full-state Symmetry none fixed-energy point contract, no old PAL plane; solved E is retained requested_energy crosschecked against final_coordinates(end), initial augmented p11 stays historical.', ...
 'provider_scope','Listed shared critical map/simulator providers union residual/admission/classifier providers; not a complete transitive execution trace.', ...
 'failure',struct());
ownedPrefixSHA='';
for k=1:4
 assert(min(work.utc-nowUTC(),(work.mono-nowMono())/1e9)>182,'PointAdmission:ChildFit','A complete180-second point admission must fit the explicit remaining work clocks.');
 o=sourceOrbits{k};r=sourceReports{k};cfg=struct('Energy',r.family_conditions.requested_energy,'Symmetry','none', ...
  'ActiveCoordinateIndices',[],'FamilyConstraint','fixed-energy','Constraint',[],'ResidualScale',[], ...
  'Integration',r.integration,'ReplayIntegration',r.replay_integration,'Acceptance',r.acceptance, ...
  'MaxReturnTime',r.options.MaxReturnTime,'MaxCycleEvents',r.options.MaxCycleEvents,'MaxSectionCrossings',r.options.MaxSectionCrossings,'MaxWallSeconds',180);
 row=struct('source_index',indices(k),'source_native_id',OrbitContentIdentity_v3(o),'source_metadata',sourceMetadata{k}, ...
  'configuration',cfg,'call_returned',false,'protocol_verified',false,'solution',[],'report',struct(),'evidence',struct(),'failure',struct());
 try
  [sol,rep,ev]=ValidateStoredPeriodicOrbit_v3(o,r,cfg,B);row.call_returned=true;row.solution=sol;row.report=rep;row.evidence=ev;
  assert(ev.root_solver_calls==0&&~ev.correction_performed&&~ev.historical_P_edges_requalified&&ev.new_physical_edges_created==0&&ev.source_posthash,'PointAdmission:RootFree','The gate performs point admission only and must preserve original source identity.');row.protocol_verified=true;
 catch problem,row.failure=struct('identifier',problem.identifier,'message',problem.message,'report',getReport(problem,'extended','hyperlinks','off'));end
 audit.rows{k}=row;audit.summaries{k}=rowSummary(row);ownedPrefixSHA=savePrefix(stage,audit,ownedPrefixSHA);fprintf('PK30H_FRESH_POINT_ADMISSION01_POINT %s\n',jsonencode(audit.summaries{k}));
end
checkReferences(refs);audit.source_posthash=true;audit.completed=all(cellfun(@(r)r.call_returned&&r.protocol_verified&&isempty(fieldnames(r.failure)),audit.rows));
audit.all_current_all9_PK=audit.completed&&all(cellfun(@(s)s.current_all9_PK,audit.summaries));
ownedPrefixSHA=savePrefix(stage,audit,ownedPrefixSHA);summary_digest=C1ScientificDigest_v3(audit.summaries);
assert(strcmp(RoundSHA256_v3(stage),ownedPrefixSHA),'PointAdmission:OwnedPrefix','Publish only this exact verified final owned prefix.');
for pass=1:2,verifySaved(stage,audit.summaries,summary_digest);end
assert(~isfile(out)&&min(finish.utc-nowUTC(),(finish.mono-nowMono())/1e9)>0,'PointAdmission:Publication','Publish only within this operation finish and to its fresh path.');
javaMethod('createLink','java.nio.file.Files',java.io.File(out).toPath(),java.io.File(stage).toPath());
assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(out).toPath(),java.io.File(stage).toPath()),'PointAdmission:OwnStage','Publish only the owned verified stage.');
javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());for pass=1:2,verifySaved(out,audit.summaries,summary_digest);end
checkReferences(refs);
fprintf('PK30H_FRESH_POINT_ADMISSION01_RETURN %s\n',jsonencode(struct('completed',audit.completed,'source_posthash',audit.source_posthash,'all_current_all9_PK',audit.all_current_all9_PK,'audit_file',out,'audit_sha256',RoundSHA256_v3(out),'root_solver_calls',0,'new_physical_edges_created',0)));
assert(audit.completed&&min(finish.utc-nowUTC(),(finish.mono-nowMono())/1e9)>0,'PointAdmission:Incomplete','Keep actual point failures; no automatic correction, new P edge or pilot release.');
end
function s=rowSummary(row)
s=struct('source_index',row.source_index,'source_native_id',row.source_native_id,'call_returned',row.call_returned,'protocol_verified',row.protocol_verified,'accepted',false,'current_all9_PK',false,'fresh_native_id','','record_bitwise_equal',false,'acceptance_gates',struct(),'classification',struct(),'caller_failure',row.failure,'gate_failure',struct());
if ~row.call_returned,return;end
r=row.report;e=row.evidence;s.accepted=r.accepted;s.current_all9_PK=e.fresh_current_all9_PK;s.fresh_native_id=e.fresh_native_id;s.record_bitwise_equal=e.fresh_record_bitwise_equal;s.acceptance_gates=r.acceptance_gates;
for key={'contract_version','canonical_point_label','canonical_label_qualified','validated_gait_type','flight_count','flight_count_certain'},if isfield(r.classification,key{1}),s.classification.(key{1})=r.classification.(key{1});end;end
s.original_record=e.original_record;s.energy_origin=e.energy_origin;s.gate_failure=e.failure;
s.full_closure=r.full_closure;s.full_closure_residual=r.full_closure_residual;s.family_conditions=r.family_conditions;
s.physical_inequalities=r.physical_inequalities;s.primitive=r.primitive;s.repeated_replay_difference=[];s.map_discrete_closed=[];s.map_admissible=[];
if isfield(r.independent_replay,'repeated_replay_difference'),s.repeated_replay_difference=r.independent_replay.repeated_replay_difference;end
if isfield(r.independent_replay,'map_info'),mi=r.independent_replay.map_info;if isfield(mi,'discrete_closed'),s.map_discrete_closed=mi.discrete_closed;end;if isfield(mi,'admissible'),s.map_admissible=mi.admissible;end;end
if ~isempty(row.solution),s.fresh_period=row.solution.period;s.fresh_stride=row.solution.stride_displacement;s.fresh_state=row.solution.initial_state;s.parameter=row.solution.parameter;s.mode=row.solution.initial_mode;
 assert(strcmp(OrbitContentIdentity_v3(row.solution),s.fresh_native_id),'PointAdmission:SavedID','The actual returned/saved fresh native record must bind its observed identity.');end
end
function verifySaved(file,expected,expectedDigest)
x=load(file,'audit','summary_digest');assert(strcmp(C1ScientificDigest_v3(x.audit.summaries),x.summary_digest)&&strcmp(x.summary_digest,expectedDigest)&&isequaln(x.audit.summaries,expected),'PointAdmission:SummaryRead2','Every independent read must preserve the complete declared plain summary.');
for k=1:4
 if isempty(x.audit.rows{k}),assert(isempty(expected{k}),'PointAdmission:PrefixMissing','A not-yet-attempted prefix row must remain explicitly empty.');continue;end
 assert(isequaln(rowSummary(x.audit.rows{k}),expected{k}),'PointAdmission:NativeRead2','Actual deserialized orbit/report/evidence and all numeric gate-input projection must match the observed summary; no whole-object losslessness claim.');
end
end
function observedSHA=savePrefix(stage,audit,previousSHA)
writing=[stage,'.writing.mat'];assert(~isfile(writing),'PointAdmission:WritingFresh','Retain an earlier interrupted owned prefix save.');
if isempty(previousSHA),assert(~isfile(stage),'PointAdmission:PrefixFresh','First owned prefix must be fresh.');
else,assert(isfile(stage)&&strcmp(RoundSHA256_v3(stage),previousSHA),'PointAdmission:PrefixChanged','Only the exact previous owned prefix may be replaced.');end
summary_digest=C1ScientificDigest_v3(audit.summaries);save(writing,'audit','summary_digest','-v7');
for pass=1:2,verifySaved(writing,audit.summaries,summary_digest);end
[ok,message]=movefile(writing,stage,'f');assert(ok,'PointAdmission:PrefixMove','%s',message);
verifySaved(stage,audit.summaries,summary_digest);observedSHA=RoundSHA256_v3(stage);
end
function checkReferences(refs)
for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PointAdmission:SourceChanged','An exact source/shared/engine/provider changed.');end
end
function t=nowUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=nowMono(),t=double(java.lang.System.nanoTime());end
