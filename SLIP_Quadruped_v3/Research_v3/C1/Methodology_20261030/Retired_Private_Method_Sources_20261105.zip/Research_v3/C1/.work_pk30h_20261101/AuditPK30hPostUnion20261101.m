function result=AuditPK30hPostUnion20261101(B,bindings,options)
%AUDITPK30HPOSTUNION20261101 Saved occurrence preservation and finite route audit.
% No continuation, flow, replay, classifier, source retirement or grant renewal.
    entryUTC=auUTC();entryMono=auNano();
    required={'EssentialReference';'ConsolidationReference';'OldCoreReference';'OldConsolidationReference'; ...
        'ClosedSourceCapsuleReference';'LegacyReference';'LocalGrazingReferences';'StorageClosureReference';'StorageProcessClosed';'StorageExitCode'};
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort(required)) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,1800)&&isequal(options.SaveMarginSeconds,60)&&B.capture.pid==feature('getpid') ...
        &&isequal(bindings.StorageProcessClosed,true),'PKPost:Inputs','Use actual closed storage custody and one original1800/60 saved-data audit.');
    validateattributes(bindings.StorageExitCode,{'numeric'},{'real','finite','scalar','integer'});
    finish=auLimit(min(B.deadline_unix_seconds,entryUTC+1800),min(B.deadline_monotonic_ns,entryMono+1800e9));
    work=auLimit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=auLiteral(options.OutputFile);stage=[output,'.pending.mat'];assert(~isfile(output)&&~isfile(stage),'PKPost:Fresh','Preserve earlier audit/stage and use a fresh path.');
    names={'AuditPK30hPostUnion20261101','BranchSolutionFile_v3','LoadC1SolutionCore29_v3','OrbitContentIdentity_v3', ...
        'RecordedReturnPolicy_v3','C1FiniteNumericalOverlap_v3','MatchingReturnSection_v3','QuadrupedSchema_v3','GaitSemanticTable_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Path_v3','V3Root_v3'};
    code=cellfun(@(n)auRef(which(n)),names(:),'UniformOutput',false);
    code{end+1,1}=auRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
    refs=[code;{bindings.EssentialReference;bindings.ConsolidationReference;bindings.OldCoreReference;bindings.OldConsolidationReference; ...
        bindings.ClosedSourceCapsuleReference;bindings.LegacyReference;bindings.StorageClosureReference};bindings.LocalGrazingReferences(:)];auVerify(refs);auCheck(work);
    assert(strcmp(bindings.OldCoreReference.sha256,'75dbd2012853aadbbec2fcee5b10560abad335b8c6bc383d4e4e43405479d6a9') ...
        &&strcmp(bindings.OldConsolidationReference.sha256,'96b18a0cfa2984b0ea71b96e6b062e2260e2e04ab4b3460a187e53b541a2c348') ...
        &&strcmp(bindings.ClosedSourceCapsuleReference.sha256,'1d6c0d2857c47dd30d2c018f2e137c288df4f534d00178be6e83bae348b1c697') ...
        &&strcmp(bindings.LegacyReference.sha256,'cb08770e36de5a8318620aed7f5fcaa4a3114bf8cb378d405ab3c14aaf374407'), ...
        'PKPost:Authorities','Bind the exact oldCore/retained old occurrence receipt/closed capsule/historical177 authorities.');
    audit=struct('schema','PK30h-post-union-saved-preservation-route-legacy-v1','input_references',{refs},'source_code',{code}, ...
        'bindings',bindings,'original_budget',B,'original_finish',finish,'old_core_mapping',struct(),'meeting',struct(),'legacy_inventory',struct(), ...
        'storage_flags',struct(),'component_inventory',{{}},'registered_endpoints',struct(),'zero_P_target_screen',struct(),'completed',false,'source_posthash',false,'failure',struct(),'root_ODE_map_replay_classifier_calls',0, ...
        'oldCore_retirement_authorized',false,'low_frontier_retirement_authorized',false,'legacy_retirement_authorized',false, ...
        'global_endpoint_or_uniqueness_claimed',false,'own_process_exit_claimed',false);auSave(stage,audit);
    try
        x=load(bindings.EssentialReference.file,'final_manifest');mf=x.final_manifest;
        x=load(bindings.ConsolidationReference.file,'receipt');receipt=x.receipt;
        assert(receipt.completed&&receipt.source_public_readback_verified&&receipt.source_hashes_verified_after_work ...
            &&mf.consolidation.returned&&isequaln(mf.consolidation.actual_receipt,receipt)&&mf.source_occurrence_bijection_verified, ...
            'PKPost:Union','Only actual completed public occurrence transport supports this saved audit; Core completion stays separate.');
        audit.storage_flags=struct('completed',mf.completed,'source_posthash',mf.source_posthash,'all_core_exports_completed',mf.all_core_exports_completed, ...
            'actual_storage_exit_code',bindings.StorageExitCode,'scope','A successful saved audit does not promote these actual storage/Core flags.');
        sourceRows=mf.configuration.SourceRows;roles=cellfun(@(r)r.role,sourceRows,'UniformOutput',false);
        for k=1:numel(sourceRows),refs{end+1,1}=sourceRows{k}.reference;end
        graphs=cell(numel(receipt.component_files),1);
        for k=1:numel(graphs)
            r=receipt.component_files{k};rr=struct('file',r.file,'sha256',r.sha256);auVerify({rr});refs{end+1,1}=rr;
            ix=BranchSolutionFile_v3.index(rr.file);at=find(cellfun(@(v)isequaln(v.reference,rr),mf.component_inventory));
            assert(isscalar(at)&&numel(mf.component_inventory{at}.native_headers)==numel(ix.points), ...
                'PKPost:Inventory','Use the exact actual stored inventory of this frozen union component.');
            ids=cellfun(@(h)h.native_id,mf.component_inventory{at}.native_headers,'UniformOutput',false);
            graphs{k}=struct('reference',rr,'index',ix,'native_ids',{ids});
        end
        auVerify(refs);audit.input_references=refs;auSave(stage,audit);auCheck(work);
        try,audit.old_core_mapping=auOldCore(bindings,receipt,graphs,work);catch e,audit.old_core_mapping=auUnresolved(e);end
        auSave(stage,audit);auCheck(work);
        try,audit.meeting=auMeeting(sourceRows,roles,receipt,graphs,bindings.LocalGrazingReferences,work);catch e,audit.meeting=auUnresolved(e);end
        auSave(stage,audit);auCheck(work);
        audit.component_inventory=auComponents(mf,receipt,graphs);auSave(stage,audit);auCheck(work);
        try,audit.registered_endpoints=auEndpoints(mf,sourceRows,roles,receipt,work);catch e,audit.registered_endpoints=auUnresolved(e);end
        auSave(stage,audit);auCheck(work);
        try,audit.zero_P_target_screen=auTargets(sourceRows,roles,receipt,graphs,work);catch e,audit.zero_P_target_screen=auUnresolved(e);end
        auSave(stage,audit);auCheck(work);
        try,audit.legacy_inventory=auLegacy(bindings.LegacyReference,mf.whole_native_id_union,work);catch e,audit.legacy_inventory=auUnresolved(e);end
        auSave(stage,audit);auVerify(refs);audit.source_posthash=true;audit.completed=true;
    catch e,audit.failure=auFailure(e);audit.input_references=refs;end
    auSave(stage,audit);auCheck(finish);
    sha=RoundSHA256_v3(stage);javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    a=load(output,'audit');b=load(output,'audit');auSame(audit,a.audit);auSame(audit,b.audit);
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),sha), ...
        'PKPost:OwnStage','Delete only the unchanged linked own plain audit stage.');delete(stage);auCheck(finish);
    result=struct('completed',audit.completed,'source_posthash',audit.source_posthash,'audit_reference',auRef(output), ...
        'actual_component_count',numel(audit.component_inventory),'component_P_E_A_M_counts',{cellfun(@(v)v.P_E_A_M_counts,audit.component_inventory,'UniformOutput',false)}, ...
        'registered_endpoint_status',auMember(audit.registered_endpoints,'status','UNAVAILABLE'), ...
        'zero_P_screen_status',auMember(audit.zero_P_target_screen,'status','UNAVAILABLE'),'current_PK_target_count',auMember(audit.zero_P_target_screen,'unique_current_PK_targets',[]), ...
        'prospective_Acquire_count',numel(auMember(audit.zero_P_target_screen,'prospective_Acquire_selectors',{})), ...
        'old_core_status',auMember(audit.old_core_mapping,'status','UNAVAILABLE'),'meeting_status',auMember(audit.meeting,'status','UNAVAILABLE'), ...
        'legacy_status',auMember(audit.legacy_inventory,'status','UNAVAILABLE'),'legacy_novel_supported_ID_count',auMember(audit.legacy_inventory,'novel_supported_ID_count',[]), ...
        'oldCore_retirement_authorized',false,'low_frontier_retirement_authorized',false,'legacy_retirement_authorized',false,'own_process_exit_claimed',false);
    try,fprintf('PK30H_POST_UNION_RETURN %s\n',jsonencode(result));catch,fprintf('PK30H_POST_UNION_RETURN {"optional_stdout_unavailable":true}\n');end
    assert(audit.completed&&audit.source_posthash,'PKPost:Incomplete','The decisive plain audit and actual failures remain retained.');
end

function out=auOldCore(bindings,receipt,graphs,clock)
    cap=jsondecode(fileread(bindings.ClosedSourceCapsuleReference.file));x=load(bindings.OldConsolidationReference.file,'receipt');old=x.receipt;
    assert(strcmp(cap.schema,'C1-primary-PK-closed-source-snapshot-capsule-v1')&&cap.source_point_count==494&&cap.physical_edge_count==476 ...
        &&cap.source_to_output_bijection_verified&&cap.all_source_physical_edges_transported&&cap.native_receipt_read2_verified ...
        &&cap.actual_source_acquisition_exit_observed&&cap.actual_source_acquisition_exit_code==0&&cap.custody_complete ...
        &&isequaln(cap.consolidation_receipt_reference,bindings.OldConsolidationReference)&&old.completed ...
        &&old.source_public_readback_verified&&old.source_hashes_verified_after_work&&old.stored_occurrences==494&&old.original_explicit_edges==476, ...
        'PKPost:OldPublication','The exact retained additive receipt/capsule supplies the old four-source occurrence authority.');
    oldOutput=find(cellfun(@(r)strcmp(r.file,cap.source_reference.file)&&strcmp(r.sha256,cap.source_reference.sha256),old.component_files));
    assert(isscalar(oldOutput)&&old.component_files{oldOutput}.points==494&&old.component_files{oldOutput}.explicit_edges==476 ...
        &&strcmp(cap.source_reference.sha256,'71697fdabed0491def7d45c69b2ac03dc0d7c52c179d40a63f65ba114d83bc7b'), ...
        'PKPost:OldTargetSHA','Bind the old map target FILE/SHA/INDEX through its registered output row, without reopening Raw04.');
    [~,~,~,view]=LoadC1SolutionCore29_v3(bindings.OldCoreReference.file,1,bindings.OldCoreReference.sha256);
    x=load(bindings.OldCoreReference.file,'solution_core29','core_digest');c=x.solution_core29;
    assert(strcmp(C1ScientificDigest_v3(c),x.core_digest)&&c.point_count==494&&numel(c.graph.physical_edges)==476, ...
        'PKPost:OldCore','Verify the entire unchanged typed oldCore payload/counts.');auSame(c.native_ids,view.native_ids);auSame(c.graph,view.typed_graph);
    ordered=cap.ordered_consolidation_source_references;if isstruct(ordered),ordered=num2cell(ordered(:));else,ordered=ordered(:);end
    assert(numel(ordered)==4&&numel(old.source_catalog)==4,'PKPost:OldFour','Use all four literal ordered original inputs.');
    for k=1:4,assert(strcmp(old.source_catalog{k}.file,ordered{k}.file)&&strcmp(old.source_catalog{k}.sha256,ordered{k}.sha256), ...
        'PKPost:OldFourOrder','Old source catalogue order must match the closed capsule exactly.');end
    maps=cell(494,1);oldOwnerMap=cell(0,1);sourceKeys=cell(494,1);targetKeys=cell(494,1);
    for k=1:494
        context=c.contexts{k};assert(context.expected_index==k&&context.source_index==k&&isequaln(context.source_reference,cap.source_reference),'PKPost:OldContext','Keep the actual expected old occurrence ordinal.');
        at=find(cellfun(@(m)strcmp(m.target_file,cap.source_reference.file)&&m.target_index==context.expected_index,old.occurrence_map));
        assert(isscalar(at),'PKPost:OldInverse','The exact oldRaw04 FILE/INDEX must invert uniquely through the SHA-bound old receipt.');m=old.occurrence_map{at};
        sr=struct('file',m.source_file,'sha256',m.source_sha256);catalogue=find(cellfun(@(s)strcmp(s.file,sr.file)&&strcmp(s.sha256,sr.sha256),old.source_catalog));
        assert(isscalar(catalogue)&&isequaln(sr,ordered{catalogue}), ...
            'PKPost:OldInverseSHA','Every inverse selector must belong to the exact old four-source FILE/SHA catalogue.');
        sourceOwner=old.source_catalog{catalogue}.point_metadata{m.source_index}.component_identity;oldOwner=c.point_metadata{k}.component_identity;
        hit=find(cellfun(@(v)v.source_number==catalogue&&strcmp(v.source_component_identity,sourceOwner),oldOwnerMap));
        if isempty(hit),oldOwnerMap{end+1,1}=struct('source_number',catalogue,'source_component_identity',sourceOwner,'output_component_identity',oldOwner);
        else,assert(isscalar(hit)&&strcmp(oldOwnerMap{hit}.output_component_identity,oldOwner),'PKPost:OldOwnerMap','Literal inverse selectors must yield one consistent old output owner.');end
        next=auMap(receipt,sr,m.source_index);maps{k}=struct('old_core_index',k,'historical_context',context,'old_raw04_reference',cap.source_reference, ...
            'old_raw04_index',context.expected_index,'original_source_reference',sr,'original_source_index',m.source_index, ...
            'old_source_number',catalogue,'original_source_owner',sourceOwner,'old_core_owner',oldOwner,'union_mapping',next);
        sourceKeys{k}=sprintf('%s|%s|%d',sr.file,sr.sha256,m.source_index);targetKeys{k}=sprintf('%s|%d',next.target_file,next.target_index);
    end
    assert(numel(unique(cellfun(@(m)m.output_component_identity,oldOwnerMap,'UniformOutput',false)))==numel(oldOwnerMap), ...
        'PKPost:OldOwnerBijection','The explicit observed old source-owner map must preserve distinct source owners.');
    assert(numel(unique(sourceKeys))==494&&numel(unique(targetKeys))==494,'PKPost:OldBijection','All494 old occurrences survive as distinct source/output occurrence selectors.');
    rows=cell(494,1);
    for g=1:numel(graphs)
        selected=find(cellfun(@(m)strcmp(m.union_mapping.target_file,graphs{g}.reference.file),maps));if isempty(selected),continue;end
        for first=1:16:numel(selected)
            block=selected(first:min(first+15,numel(selected)));indices=cellfun(@(m)m.union_mapping.target_index,maps(block));auCheck(clock);
            [os,rs]=BranchSolutionFile_v3.loadSolutions(graphs{g}.reference.file,indices);
            for j=1:numel(block)
            k=block(j);o=os{j};r=rs{j};[~,policy]=RecordedReturnPolicy_v3(r);e=c.orbit_evidence{k};kept=fieldnames(e);orbitSubset=struct();
            for z=1:numel(kept)
                key=kept{z};assert(isprop(o,key),'PKPost:OldEvidenceProperty','Every retained old orbit evidence property must remain available.');v=o.(key);
                if ismember(key,{'primitive_cycle','gait_identification'}),v=auHead(e.(key),v);end;orbitSubset.(key)=v;
            end
            reportSubset=auReportSubset(c.saved_reports{k},r);
            checks=struct('state14',auEqual(c.solution_matrix(1:14,k),o.initial_state),'stride14',auEqual(c.solution_matrix(15:28,k),o.stride_displacement), ...
                'period',auEqual(c.solution_matrix(29,k),o.period),'parameter',auEqual(c.parameters{k},o.parameter),'mode',auEqual(c.modes{k},o.initial_mode), ...
                'native_id',strcmp(c.native_ids{k},OrbitContentIdentity_v3(o)),'complete_policy',policy.complete&&auEqual(c.policies{k}.configuration,policy.configuration), ...
                'section_chart',auEqual(c.section_charts{k},o.section_chart),'retained_orbit_evidence',auEqual(e,orbitSubset), ...
                'declared_saved_report_projection',auEqual(c.saved_reports{k},reportSubset));
            rows{k}=struct('mapping',maps{k},'literal_equal',checks,'all_retained_values_equal',all(structfun(@(v)v,checks)), ...
                'old_saved_report_fields',{fieldnames(c.saved_reports{k})},'old_classifier_present',isfield(c.saved_reports{k},'classification'), ...
                'old_primitive_present',isfield(c.saved_reports{k},'primitive'),'union_full_report_fields',{fieldnames(r)}, ...
                'old_saved_report_digest',C1ScientificDigest_v3(c.saved_reports{k}),'union_full_report_digest',C1ScientificDigest_v3(r), ...
                'full_reports_equal_observed',auEqual(c.saved_reports{k},r),'old_core_trajectory_scope','UNAVAILABLE: no old full trajectory equality claimed.');
            end
            clear os rs o r orbitSubset reportSubset
        end
    end
    physical=cell(476,1);
    for k=1:476
        edge=c.graph.physical_edges{k};a=maps{edge.from};b=maps{edge.to};
        assert(isequaln(a.original_source_reference,b.original_source_reference)&&a.old_source_number==b.old_source_number, ...
            'PKPost:OldPhysicalSource','An original physical edge must stay inside its exact source/owner, not a nonphysical cross-file relation.');
        oldSource=old.source_catalog{a.old_source_number};hit=find(cellfun(@(e)e.from==a.original_source_index&&e.to==b.original_source_index,oldSource.original_edges));
        assert(isscalar(hit)&&strcmp(oldSource.original_edges{hit}.component_identity,a.original_source_owner) ...
            &&strcmp(a.original_source_owner,b.original_source_owner)&&strcmp(edge.component_identity,a.old_core_owner)&&strcmp(a.old_core_owner,b.old_core_owner), ...
            'PKPost:OldPhysicalOwner','Retained source/core P rows must preserve exact orientation and observed old source-owner mapping.');
        sourceEdge=oldSource.original_edges{hit};
        [g,from,to]=auSameComponent(graphs,a.union_mapping,b.union_mapping);ix=graphs{g}.index;hit=find(cellfun(@(e)e.from==from&&e.to==to,ix.edges));
        assert(isscalar(hit),'PKPost:NewPhysical','Every old oriented physical edge must survive as P, never E/A/M.');newEdge=ix.edges{hit};
        sourceNumber=find(cellfun(@(s)strcmp(s.file,a.original_source_reference.file)&&strcmp(s.sha256,a.original_source_reference.sha256),receipt.source_catalog));
        ownerRows=ix.metadata.source_owner_map;owner=find(cellfun(@(v)v.source_number==sourceNumber&&strcmp(v.source_component_identity,a.original_source_owner),ownerRows));
        assert(isscalar(owner)&&strcmp(ownerRows{owner}.output_component_identity,newEdge.component_identity) ...
            &&strcmp(ix.points{from}.component_identity,newEdge.component_identity)&&strcmp(ix.points{to}.component_identity,newEdge.component_identity), ...
            'PKPost:NewOwnerMap','Use explicit actual new source_owner_map; do not compare or strip owner prefixes.');
        physical{k}=struct('old_core_physical_row',k,'old_core_edge',edge,'original_source_reference',a.original_source_reference, ...
            'original_source_edge',sourceEdge, ...
            'observed_old_owner',a.old_core_owner,'original_source_owner',a.original_source_owner,'new_source_owner_map',ownerRows{owner}, ...
            'union_reference',graphs{g}.reference,'union_physical_row',hit,'union_edge',newEdge,'orientation_preserved',true);
    end
    verified=all(cellfun(@(r)r.all_retained_values_equal,rows));out=struct('status','UNRESOLVED','observations_completed',true, ...
        'old_core_reference',bindings.OldCoreReference,'old_raw04_reference',cap.source_reference,'old_receipt_reference',bindings.OldConsolidationReference, ...
        'capsule_reference',bindings.ClosedSourceCapsuleReference,'occurrence_count',494,'physical_edge_count',476,'rows',{rows},'physical_rows',{physical}, ...
        'observed_old_source_owner_map',{oldOwnerMap},'owner_map_scope','Exact old inverse-source metadata joined to oldCore literal owners; no prefix parsing or deleted Raw04 access.', ...
        'maximum_native_bulk_records',16,'all494_retained_projections_verified',verified,'all476_oriented_physical_edges_verified',true,'oldCore_retirement_authorized',false, ...
        'scope','Preservation of declared oldCore information and physical occurrences only; report/primitive/classifier omissions stay literal, no old trajectory or fresh admission claim.');
    if verified,out.status='VERIFIED_494_OCCURRENCES_476_ORIENTED_P';end
end

function out=auMeeting(rows,roles,receipt,graphs,grazing,clock)
    source=auRole(rows,roles,'latest0170');fork=auRole(rows,roles,'join_fork');target=auRole(rows,roles,'grown0072');retained=auRole(rows,roles,'retained_join');
    original17=auRole(rows,roles,'original0170');original72=auRole(rows,roles,'original0072');auCheck(clock);
    [a,ar]=BranchSolutionFile_v3.loadSolutions(source.file,16);[f,fr]=BranchSolutionFile_v3.loadSolutions(fork.file,[2;3]);
    [t,tr]=BranchSolutionFile_v3.loadSolutions(target.file,[53;54]);fi=BranchSolutionFile_v3.index(fork.file);ti=BranchSolutionFile_v3.index(target.file);
    ri=BranchSolutionFile_v3.index(retained.file);rg=ri.metadata.component_graph;
    assert(size(rg.qualified_numerical_overlaps,1)==1&&numel(rg.numerical_overlap_evidence)==1, ...
        'PKPost:NewM','Use the one actual retained new-join numerical row.');mpair=rg.qualified_numerical_overlaps(1,:);e=rg.numerical_overlap_evidence{1};
    assert(strcmp(e.schema,'C1-qualified-finite-numerical-overlap-v1')&&strcmp(e.left_selector.file,fork.file) ...
        &&strcmp(e.left_selector.sha256,fork.sha256)&&e.left_selector.index==3&&strcmp(e.right_selector.file,target.file) ...
        &&strcmp(e.right_selector.sha256,target.sha256)&&e.right_selector.index==54, ...
        'PKPost:NewSelectors','The unchanged cold proof must name actual fork3 and grown0072 terminal54.');
    C1FiniteNumericalOverlap_v3.validateRetained(e,f{2},t{2},fr{2},tr{2},f{1});
    importFlags=struct('full_native_orbit_equal',auEqual(public(a{1}),public(f{1})),'native_record_equal',auEqual(auRecord(a{1}),auRecord(f{1})), ...
        'native_id_equal',strcmp(OrbitContentIdentity_v3(a{1}),OrbitContentIdentity_v3(f{1})), ...
        'admission_policy_projection_equal',auEqual(auAdmission(ar{1}),auAdmission(fr{1})));
    importReport=struct('source_report_digest',C1ScientificDigest_v3(ar{1}),'fork_compacted_report_digest',C1ScientificDigest_v3(fr{1}), ...
        'full_reports_equal_observed',auEqual(ar{1},fr{1}),'comparison_scope','Report compaction differences are preserved; only declared admission/policy projection equality is required.');
    fedge=auEdge(fi,2,3);tedge=auEdge(ti,53,54);forkTerminal=~any(cellfun(@(p)p.from==3,fi.edges));targetTerminal=~any(cellfun(@(p)p.from==54,ti.edges));
    states=[f{1}.initial_state(2:14),f{2}.initial_state(2:14),t{1}.initial_state(2:14),t{2}.initial_state(2:14)];
    scale=max([ones(13,1),abs(states)],[],2);u=(states(:,2)-states(:,1))./scale;v=(states(:,4)-states(:,3))./scale;nu=norm(u);nv=norm(v);cosine=[];
    if isfinite(nu)&&isfinite(nv)&&nu>0&&nv>0,cosine=dot(u,v)/(nu*nv);end
    geometry=struct('raw_state_indices',2:14,'raw_states',states,'common_scale',scale,'fork_incoming_secant',u,'target_incoming_secant',v, ...
        'fork_secant_norm',nu,'target_secant_norm',nv,'cosine',cosine,'opposed_observed',~isempty(cosine)&&isfinite(cosine)&&cosine<0, ...
        'scope','Finite raw13 incoming secants with one common max1 scale; no classical tangent, local uniqueness or branch theorem.');
    sourceMap=auMap(receipt,source,16);forkParentMap=auMap(receipt,fork,2);forkHeadMap=auMap(receipt,fork,3);targetPrevMap=auMap(receipt,target,53);targetHeadMap=auMap(receipt,target,54);
    high17=auMap(receipt,original17,59);high72=auMap(receipt,original72,6);mleft=auMap(receipt,retained,mpair(1));mright=auMap(receipt,retained,mpair(2));
    route=struct('status','UNRESOLVED','original0170_high_selector',struct('reference',original17,'index',59,'study_pair',[55,59]), ...
        'original0072_high_selector',struct('reference',original72,'index',6,'study_pair',[5,6]), ...
        'source_to_union_maps',{{high17;high72;mleft;mright;sourceMap;forkParentMap;forkHeadMap;targetPrevMap;targetHeadMap}}, ...
        'local_grazing_study_references',{grazing},'boundary_physical_edges_added',false);
    sameFile=strcmp(high17.target_file,high72.target_file)&&strcmp(high17.target_file,mleft.target_file)&&strcmp(mleft.target_file,mright.target_file);
    if sameFile
        [g,l,r]=auSameComponent(graphs,mleft,mright);ix=graphs{g}.index;gg=ix.metadata.component_graph;
        at=find(gg.qualified_numerical_overlaps(:,1)==l&gg.qualified_numerical_overlaps(:,2)==r);
        assert(isscalar(at)&&auEqual(gg.numerical_overlap_evidence{at},e),'PKPost:MappedNewM','Keep the exact original newM evidence under actual union remapping.');
        leftPath=auPath(graphs{g},high17.target_index,l,at);rightPath=auPath(graphs{g},r,high72.target_index,at);
        route.union_reference=graphs{g}.reference;route.left_subpath=leftPath;route.right_subpath=rightPath;
        route.forced_newM_step=auStep(graphs{g},l,r,4,at);route.newM_evidence_unchanged=true;
        if strcmp(leftPath.status,'FOUND')&&strcmp(rightPath.status,'FOUND')
            route.status='FOUND_FINITE_TYPED_ROUTE_THROUGH_NEW_M';route.nodes=[leftPath.nodes,rightPath.nodes];
            route.simple_path_observed=numel(unique(route.nodes))==numel(route.nodes);
            route.steps=[leftPath.steps;{route.forced_newM_step};rightPath.steps];
        end
    else,route.reason='Mapped high endpoints and the newM are in different actual stored components.';end
    out=struct('status','UNRESOLVED','observations_completed',true,'source16_to_fork2',importFlags,'report_difference_observation',importReport, ...
        'actual_fork_physical_edge',struct('reference',fork,'row',fedge),'actual_target_physical_edge',struct('reference',target,'row',tedge), ...
        'fork3_no_outgoing_P',forkTerminal,'target54_no_outgoing_P',targetTerminal,'finite_secant_geometry',geometry,'typed_route',route, ...
        'newM_cold_evidence',e,'newM_retained_reference',retained,'finite_numerical_meeting_observed',false, ...
        'low_frontier_retirement_authorized',false,'global_endpoint_or_uniqueness_claimed',false,'classical_tangent_claimed',false);
    out.finite_numerical_meeting_observed=all(structfun(@(v)v,importFlags))&&forkTerminal&&targetTerminal&&geometry.opposed_observed ...
        &&strcmp(route.status,'FOUND_FINITE_TYPED_ROUTE_THROUGH_NEW_M');
    if out.finite_numerical_meeting_observed,out.status='FINITE_NUMERICAL_FRONT_MEETING_OBSERVED';end;auCheck(clock);
end
function path=auPath(g,a,b,excludedM)
    [tables,~]=auTables(g.index);path=struct('status','UNRESOLVED','start',a,'finish',b,'nodes',[],'steps',{{}}, ...
        'scope','Undirected stored route only; every P traversal direction/owner and E/A/M evidence remains explicit.');
    for level=1:4
        edges=zeros(0,2);
        for kind=1:level
            p=tables{kind};if kind==4,p(excludedM,:)=[];end;edges=[edges;p]; %#ok<AGROW>
        end
        nodes=shortestpath(graph(edges(:,1),edges(:,2),[],numel(g.index.points)),a,b);
        if isempty(nodes),continue;end
        path.status='FOUND';path.minimum_subpath_connectivity_layer=level;path.nodes=nodes;
        path.steps=cell(numel(nodes)-1,1);for k=1:numel(nodes)-1,item=auStep(g,nodes(k),nodes(k+1),0,0);item.path_maximum_relation_kind=level;
            for kind=1:level,eligible=item.relation_rows{kind};if kind==4,eligible=eligible(eligible~=excludedM);end
                if ~isempty(eligible),item.selected_kind=kind;item.selected_row=eligible(1);break;end
            end;path.steps{k}=item;end
        return
    end
end
function step=auStep(g,a,b,forcedKind,forcedRow)
    [tables,evidence]=auTables(g.index);labels={'P','E','A','M'};rows=cell(4,1);relations=cell(0,1);
    for kind=1:4
        p=tables{kind};rows{kind}=find((p(:,1)==a&p(:,2)==b)|(p(:,1)==b&p(:,2)==a));
        for j=rows{kind}(:).'
            from=p(j,1);to=p(j,2);owner='';if kind==1,owner=evidence{kind}{j}.component_identity;end
            relations{end+1,1}=struct('kind',labels{kind},'row',j,'stored_from',from,'stored_to',to,'path_from',a,'path_to',b, ...
                'traversed_in_saved_direction',from==a,'owner',owner,'from_native_id',g.native_ids{from},'to_native_id',g.native_ids{to},'evidence',evidence{kind}{j}); %#ok<AGROW>
        end
    end
    assert(~isempty(relations),'PKPost:PathStep','Every reported graph step needs actual typed relation evidence.');
    if forcedKind>0,assert(ismember(forcedRow,rows{forcedKind}),'PKPost:ForcedM','The explicitly forced newM row must be present at this exact mapped step.');end
    step=struct('path_from',a,'path_to',b,'relation_rows',{rows},'relations',{relations}, ...
        'parallel_relation_kinds_present',nnz(cellfun(@(r)~isempty(r),rows))>1,'forced_kind',forcedKind,'forced_row',forcedRow, ...
        'selected_kind',forcedKind,'selected_row',forcedRow,'scope','All parallel evidence is listed; selected_kind/row identifies the actual chosen typed traversal.');
end
function [tables,evidence]=auTables(ix)
    g=ix.metadata.component_graph;P=zeros(numel(ix.edges),2);for k=1:numel(ix.edges),P(k,:)=[ix.edges{k}.from,ix.edges{k}.to];end
    tables={P;g.exact_record_equalities;g.qualified_record_aliases;g.qualified_numerical_overlaps};
    evidence={ix.edges;g.equality_evidence;g.qualified_alias_evidence;g.numerical_overlap_evidence};
end
function e=auEdge(ix,a,b)
    at=find(cellfun(@(e)e.from==a&&e.to==b,ix.edges));assert(isscalar(at),'PKPost:OwnedEdge','Use the actual one directed physical edge.');e=ix.edges{at};
    assert(strcmp(ix.points{a}.component_identity,e.component_identity)&&strcmp(ix.points{b}.component_identity,e.component_identity) ...
        &&isequal(ix.points{b}.metadata.edge_enabled,true)&&isequal(ix.points{b}.metadata.edge_from,a), ...
        'PKPost:OwnedEdgeOwner','Physical edge and same-owner predecessor metadata must agree.');
end

function out=auLegacy(r,unionIDs,clock)
    info=dir(r.file);vars=whos('-file',r.file);out=struct('status','UNASSESSED_UNSUPPORTED_LEGACY_SCHEMA','observations_completed',true, ...
        'reference',r,'top_variables',{arrayfun(@(v)struct('name',v.name,'class',v.class,'size',v.size),vars,'UniformOutput',false)}, ...
        'rows',{{}},'novel_supported_ID_count',[],'retained_universe_expanded',false,'retirement_authorized',false);
    assert(isscalar(info)&&info.bytes==44967003,'PKPost:LegacyBytes','Use the exact44967003B historical177 native store.');
    if ~all(ismember({'solutions','branch'},{vars.name})),return;end
    x=load(r.file,'solutions','branch');
    if ~iscell(x.solutions)||numel(x.solutions)~=177||~isstruct(x.branch)||~isscalar(x.branch) ...
            ||~all(isfield(x.branch,{'records','components'}))||~isstruct(x.branch.records)||numel(x.branch.records)~=177 ...
            ||~isstruct(x.branch.components)||numel(x.branch.components)~=39,return;end
    out.status='HISTORICAL177_NATIVE_INVENTORY';out.branch_fields=fieldnames(x.branch);out.component_count=39;out.rows=cell(177,1);novel=cell(0,1);supported=0;
    for k=1:177
        auCheck(clock);o=x.solutions{k};rec=x.branch.records(k);
        row=struct('index',k,'native_class',class(o),'native_shape',size(o),'record_fields',{fieldnames(rec)}, ...
            'recorded_provenance',auPick(rec,{'solution_index','component_index','source_path','source_sha256','source_record_index', ...
                'source_group_key','period','signed_drift','energy','classification_label','physical_flight_count'}), ...
            'status','UNASSESSED_UNSUPPORTED_NATIVE_IDENTITY','failure',struct(),'current_admission_claimed',false);
        try
            assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&isnumeric(o.initial_state)&&numel(o.initial_state)==14 ...
                &&isnumeric(o.stride_displacement)&&isvector(o.stride_displacement)&&~isempty(o.stride_displacement) ...
                &&numel(o.parameter)==10&&numel(o.initial_mode)==4&&isscalar(o.period)&&o.period>0 ...
                &&all(isfinite([o.initial_state(:);o.stride_displacement(:);o.parameter(:);double(o.initial_mode(:));o.period])), ...
                'PKPost:LegacyIdentityShape','Only actual finite native identity-bearing records are supported; no constructor, replay or classifier substitutes.');
            id=OrbitContentIdentity_v3(o);matches=find(strcmp(unionIDs,id));row.native_id=id;row.union_unique_ID_matches=matches;
            row.status='SUPPORTED_HISTORICAL_NATIVE_ID';row.state_shape=size(o.initial_state);row.stride_shape=size(o.stride_displacement); ...
                row.current_matrix29_layout_supported=isequal(size(o.initial_state),[14,1])&&isequal(size(o.stride_displacement),[14,1]);row.return_policy_name_literal=o.return_policy_name;row.section_chart_fields=auFields(o.section_chart);
            row.saved_classifier_contract=auMember(o.gait_identification,'contract_version','UNAVAILABLE');row.saved_primitive_fields=auFields(o.primitive_cycle);
            row.period=o.period;row.stride=o.stride_displacement;row.parameter=o.parameter;row.mode=o.initial_mode;
            row.policy_report_scope='UNASSESSED historical complete policy/admission; supported bundle has no restored source reports.';
            row.native_ID_scope='Exact numerical record ID inventory only; an ID match alone does not prove current policy, cycle equivalence or admission.';
            if isempty(matches),novel{end+1,1}=id;row.retained_universe_status='NOVEL_SUPPORTED_NATIVE_RECORD_MUST_RETAIN';
            else,row.retained_universe_status='OBSERVED_NATIVE_ID_MATCH_ONLY';end;supported=supported+1;
        catch e,row.failure=auFailure(e);end
        out.rows{k}=row;
    end
    out.supported_native_ID_records=supported;out.novel_supported_ID_count=numel(unique(novel));out.retained_universe_expanded=~isempty(novel);
    out.scope='Historical dated177-record inventory. Novel supported native records enlarge retained inventory; unsupported/stale schema stays UNASSESSED, never nonexistent, retired or automatically replayed.';
end
function out=auComponents(mf,receipt,graphs)
    out=cell(numel(graphs),1);
    for k=1:numel(graphs)
        g=graphs{k};[tables,~]=auTables(g.index);maps=receipt.occurrence_map(cellfun(@(m)strcmp(m.target_file,g.reference.file),receipt.occurrence_map));
        at=find(cellfun(@(v)isequaln(v.reference,g.reference),mf.component_inventory));heads=mf.component_inventory{at}.native_headers;
        out{k}=struct('reference',g.reference,'occurrences',numel(g.index.points),'P_E_A_M_counts',cellfun(@(p)size(p,1),tables).', ...
            'source_occurrence_maps',{maps},'unique_native_ID_count',numel(unique(g.native_ids)), ...
            'saved_current_all9_PK_count',nnz(cellfun(@(h)h.current_all9_qualified_PK,heads)), ...
            'scope','ALL actual stored components. Separate0061 and zero-P components are not discharged by the primary/secondary meeting.');
    end
end
function out=auEndpoints(mf,rows,roles,receipt,clock)
    requests=cell(0,1);
    for k=1:numel(mf.historical_obligations)
        h=mf.historical_obligations{k}.literal;
        requests{end+1,1}=struct('id',h.id,'journal_row',h.journal_row,'reference',h.source_reference,'ordered_pair',h.pair, ...
            'literal_direction',auMember(h.historical_frontier_state,'direction',struct('status','UNAVAILABLE'))); %#ok<AGROW>
    end
    r=auRole(rows,roles,'original0061');
    for pair={[54,55],[56,57]},v=pair{1};requests{end+1,1}=struct('id',sprintf('explicit_original0061_%d_%d',v), ...
            'journal_row',[],'reference',r,'ordered_pair',v,'literal_direction',struct('status','EXPLICIT_ORDER_ONLY'));end
    files=unique(cellfun(@(q)q.reference.file,requests,'UniformOutput',false),'stable');result=cell(numel(requests),1);
    for f=1:numel(files)
        hit=find(cellfun(@(q)strcmp(q.reference.file,files{f}),requests));selected=[];
        for k=hit(:).',selected=[selected;requests{k}.ordered_pair(:)];end;selected=unique(selected,'stable'); %#ok<AGROW>
        ref=requests{hit(1)}.reference;auVerify({ref});auCheck(clock);ix=BranchSolutionFile_v3.index(ref.file);
        selectedHeaders=cell(numel(selected),1);
        for first=1:16:numel(selected)
            block=first:min(first+15,numel(selected));auCheck(clock);
            [os,rs,ms]=BranchSolutionFile_v3.loadSolutions(ref.file,selected(block));
            for j=1:numel(block),selectedHeaders{block(j)}=auEndpointHeader(os{j},rs{j},ms{j},ix.points{selected(block(j))});end
            clear os rs ms
        end
        for k=hit(:).'
            q=requests{k};assert(isequaln(q.reference,ref),'PKPost:EndpointGeneration','One endpoint path must retain one exact source generation.');headers=cell(2,1);mapped=cell(2,1);
            for j=1:2
                n=find(selected==q.ordered_pair(j));assert(isscalar(n),'PKPost:EndpointSelection','Retain the selected actual ordered endpoint.');
                headers{j}=selectedHeaders{n};mapped{j}=auMap(receipt,ref,q.ordered_pair(j));
            end
            edge=find(cellfun(@(e)isequal(sort([e.from,e.to]),sort(q.ordered_pair(:).')),ix.edges));
            result{k}=struct('request',q,'full_native_headers',{headers},'union_maps',{mapped},'actual_owned_physical_edge',struct());
            if isscalar(edge),result{k}.actual_owned_physical_edge=ix.edges{edge};end
        end
        clear selectedHeaders
    end
    out=struct('status','ALL_REGISTERED_ORDERED_PAIRS_OBSERVED','observations_completed',true,'rows',{result}, ...
        'explicit0061_pairs',[54,55;56,57],'scope','Literal selected endpoints and strict arithmeticH<.5L0 only; no fresh ddy, stop, classification or direction authorization.');
end
function h=auEndpointHeader(o,r,m,p)
    [~,policy]=RecordedReturnPolicy_v3(r);s=QuadrupedSchema_v3.shared();x=o.initial_state;par=o.parameter;
    height=struct('status','UNASSESSED_UNSUPPORTED_LENGTH','strict_less',[],'new_stop_authorized',false);
    Lb=par(s.Parameter.l_l_b);Lf=par(s.Parameter.l_l_f);
    if isfinite(Lb)&&Lb>0&&isequaln(Lb,Lf)
        height=struct('status','MEASURED_STRICT_LITERAL_HEIGHT','H',x(s.State.y),'L0',Lb,'threshold',.5*Lb,'ratio',x(s.State.y)/Lb, ...
            'strict_less',x(s.State.y)<.5*Lb,'new_stop_authorized',false,'scope','Recorded-section measurement; no fresh downward-flow derivative or admission is earned.');
    end
    cohort=struct('event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'members',{o.event_cluster_members},'names',{o.event_cluster_names},'center_times',o.event_cluster_center_times, ...
        'maximum_intra_cluster_spread',o.maximum_intra_cluster_spread,'minimum_intercluster_gap',o.minimum_intercluster_gap, ...
        'section_cluster_coincidence',o.section_cluster_coincidence,'section_coincident_cluster_indices',o.section_coincident_cluster_indices);
    h=struct('index',p.index,'native_id',OrbitContentIdentity_v3(o),'owner',m.component_identity,'state14',x,'parameter',par,'mode',o.initial_mode, ...
        'period',o.period,'stride14',o.stride_displacement,'policy',policy,'section',o.section_chart, ...
        'section_signature',o.section_relative_event_signature,'cyclic_signature',o.cyclic_event_signature,'saved_event_history',o.event_history, ...
        'saved_cohort',cohort,'raw_leg_angles',x(s.Leg.AngleIndices),'raw_leg_rates',x(s.Leg.RateIndices),'return_multiplicity',o.return_multiplicity, ...
        'saved_current_all9_PK',admitted(r),'classification',auPick(auMember(r,'classification',struct()),{'contract_version','status','validated_gait_type','canonical_point_label','canonical_label_qualified','flight_count','flight_count_certain','primitive_flight_count','period_used','descriptive_only','isotropy_proved'}),'acceptance_gates',auMember(r,'acceptance_gates',struct()), ...
        'strict_height_measurement',height,'cohort_scope','Literal saved properties; empty/default cohort headers establish no new validity.');
end
function out=auTargets(rows,roles,receipt,graphs,clock)
    names={'original0060';'original0064';'original0159'};targets=cell(0,1);inventory=cell(3,1);keys=cell(0,1);sourceContexts=cell(numel(graphs),1);
    for k=1:3
        r=auRole(rows,roles,names{k});ix=BranchSolutionFile_v3.index(r.file);assert(isempty(ix.edges),'PKPost:ZeroP','Only actual zero-P original stores enter this target-only screen.');
        heads=cell(numel(ix.points),1);
        for first=1:16:numel(ix.points)
            block=first:min(first+15,numel(ix.points));auCheck(clock);
            [os,rs,ms]=BranchSolutionFile_v3.loadSolutions(r.file,block);
            for j=1:numel(block)
                n=block(j);heads{n}=auEndpointHeader(os{j},rs{j},ms{j},ix.points{n});[~,policy]=RecordedReturnPolicy_v3(rs{j});
                if ~admitted(rs{j})||~policy.complete,heads{n}.screen_status='UNASSESSED_missing_current_PK_all9_or_complete_policy';continue;end
                [small,report,context]=auScreenView(os{j},rs{j});
                recordKey=C1ScientificDigest_v3(struct('record',auRecord(os{j}),'policy',policy.configuration));
                key=C1ScientificDigest_v3(struct('record_policy_digest',recordKey,'cohort',context.cohort,'return_multiplicity',context.return_multiplicity));
                at=find(strcmp(keys,key));selector=struct('reference',r,'index',n,'role',names{k});
                if isempty(at)
                    mapped=auMap(receipt,r,n);g=find(cellfun(@(v)strcmp(v.reference.file,mapped.target_file),graphs));
                    targets{end+1,1}=struct('selectors',{{selector}},'orbit',small,'report',report,'context',context,'metadata',struct('component_identity',ms{j}.component_identity),'point',struct('index',n), ...
                        'record_policy_digest',recordKey,'context_dedup_digest',key,'component',g,'rows',zeros(0,9),'failures',{{}},'best',struct());keys{end+1,1}=key; %#ok<AGROW>
                else,targets{at}.selectors{end+1,1}=selector;end
                heads{n}.screen_status='CURRENT_PK_TARGET_ONLY';
            end
            clear os rs ms small report context
        end
        inventory{k}=struct('role',names{k},'reference',r,'all_occurrences',numel(ix.points),'physical_edges',0,'headers',{heads});
    end
    if isempty(targets)
        out=struct('status','UNASSESSED_no_current_PK_supported_targets','observations_completed',true, ...
            'zero_P_source_inventory',{inventory},'unique_current_PK_targets',0,'source_contexts',{{}},'targets',{{}}, ...
            'prospective_Acquire_selectors',{{}},'maximum_proposals',2,'native_calls_authorized',false,'single_point_initializer_proposed',false, ...
            'scope','Actual current-PK/all9/policy support was absent; no source-pair scan or nonexistence inference. A single-point initializer needs a separate reviewed plan.');return
    end
    for g=1:numel(graphs)
        ix=graphs{g}.index;if isempty(ix.edges),continue;end
        selected=unique(cell2mat(cellfun(@(e)[e.from;e.to],ix.edges,'UniformOutput',false)),'stable');auCheck(clock);
        plainOrbits=cell(numel(selected),1);plainReports=plainOrbits;metadata=plainOrbits;contexts=plainOrbits;
        for first=1:16:numel(selected)
            block=first:min(first+15,numel(selected));[raw,rawReports,rawMetadata]=BranchSolutionFile_v3.loadSolutions(graphs{g}.reference.file,selected(block));
            for j=1:numel(block)
                [plainOrbits{block(j)},plainReports{block(j)},contexts{block(j)}]=auScreenView(raw{j},rawReports{j});metadata{block(j)}=struct('component_identity',rawMetadata{j}.component_identity);
            end
            clear raw rawReports rawMetadata
        end
        cache=struct('indices',selected,'orbits',{plainOrbits},'reports',{plainReports},'metadata',{metadata});
        sourceContexts{g}=struct('reference',graphs{g}.reference,'indices',selected,'point_contexts',{contexts},'maximum_native_bulk_records',16);
        for t=1:numel(targets)
            if targets{t}.component==g,continue;end
            z=targets{t};one=struct('indices',z.point.index,'orbits',{{z.orbit}},'reports',{{z.report}},'metadata',{{z.metadata}});
            for e=1:numel(ix.edges)
                edge=ix.edges{e};pairs=[edge.from,edge.to;edge.to,edge.from];
                for orientation=1:2
                    auCheck(clock);full13=[];
                    try
                        ai=find(selected==pairs(orientation,1));bi=find(selected==pairs(orientation,2));ca=contexts{ai};cb=contexts{bi};ct=z.context;
                        assert(ca.cohort_supported&&cb.cohort_supported&&ct.cohort_supported&&auEqual(ca.cohort,cb.cohort)&&auEqual(cb.cohort,ct.cohort) ...
                            &&isequaln(ca.return_multiplicity,cb.return_multiplicity)&&isequaln(cb.return_multiplicity,ct.return_multiplicity), ...
                            'PKPost:CohortMultiplicity','Require actual nonempty symbolic cohort/multiplicity compatibility; no event-time equality or defaults-as-evidence.');
                        candidate=screen(cache,one,pairs(orientation,:),z.point.index,ix);
                    catch err,candidate=struct('eligible',false,'failure',auFailure(err));end
                    if candidate.eligible
                        base=plainOrbits{bi};pred=base.initial_state;pred(candidate.coordinate_indices)=candidate.predictor_coordinates;
                        pred([9,11,13])=pred(7);pred([10,12,14])=pred(8);scale=max([ones(13,1),abs(pred(2:14)),abs(z.orbit.initial_state(2:14))],[],2);
                        full13=norm((pred(2:14)-z.orbit.initial_state(2:14))./scale,Inf);candidate.full13_predictor_target_scaled_inf=full13;
                        candidate.PAL_normal=[candidate.tangent./candidate.scale;0];candidate.base_nativeE_index=ix.points{pairs(orientation,2)}.nativeE;
                        candidate.full13_scope='Separate prospective full-state eligibility observation only; never feeds or renormalizes the Run4D scale/normal/ds.';
                        candidate.eligible=full13<=.001;
                    end
                    targets{t}.rows(end+1,:)=[g,pairs(orientation,:),orientation,double(candidate.eligible),auMember(candidate,'requested_step',NaN), ...
                        auMember(candidate,'predictor_distance',NaN),auEmpty(full13),double(isempty(fieldnames(candidate.failure)))];
                    targets{t}.failures{end+1,1}=auMember(candidate.failure,'identifier','');
                    if candidate.eligible
                        best=targets{t}.best;
                        score=[full13,candidate.predictor_distance,g,e,orientation];
                        if isempty(fieldnames(best))||auLexLess(score,best.score)
                            targets{t}.best=struct('score',score,'source_reference',graphs{g}.reference,'source_pair',pairs(orientation,:), ...
                                'target_selectors',{z.selectors},'geometry',candidate,'actual_stored_edge',edge,'target_is_root_seed',false);
                        end
                    end
                end
            end
        end
    end
    observed=cell(numel(targets),1);rank=zeros(0,6);
    for t=1:numel(targets)
        z=targets{t};observed{t}=struct('target_selectors',{z.selectors},'target_native_id',OrbitContentIdentity_v3(z.orbit), ...
            'record_policy_digest',z.record_policy_digest,'context_dedup_digest',z.context_dedup_digest, ...
            'compact_screen_rows',z.rows,'failure_identifiers',{z.failures},'best',z.best);
        if ~isempty(fieldnames(z.best)),rank(end+1,:)=[z.best.score,t];end %#ok<AGROW>
    end
    proposals=cell(0,1);if ~isempty(rank),rank=sortrows(rank,1:5);for k=1:min(2,size(rank,1)),proposals{k,1}=observed{rank(k,6)}.best;end,end
    out=struct('status','BOUNDED_TARGET_ONLY_SCREEN_COMPLETED','observations_completed',true,'zero_P_source_inventory',{inventory}, ...
        'unique_current_PK_targets',numel(targets),'source_contexts',{sourceContexts},'targets',{observed},'screen_columns',{{'source_component';'source_from';'source_to';'orientation';'eligible';'signed_ds';'predictor4D_norm';'predictor_full13_scaled_inf';'context_checks_no_exception'}}, ...
        'prospective_Acquire_selectors',{proposals},'maximum_proposals',2,'maximum_native_bulk_records',16,'native_calls_authorized',false,'single_point_initializer_proposed',false, ...
        'scope','Full record/policy/section context, existing signed4D PAL donor(.04/.001), full13 predictor check<=.001. No speed/NID-nearest ranking, target seeding, arbitrary edge import, Root/Map call, energy-pivot or nonexistence claim.');
end
function [small,report,context]=auScreenView(o,r)
    small=auRecord(o);small.return_policy=o.return_policy;small.return_multiplicity=o.return_multiplicity;
    cohort=struct('event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'event_cluster_members',{o.event_cluster_members},'event_cluster_names',{o.event_cluster_names}, ...
        'section_cluster_coincidence',o.section_cluster_coincidence,'section_coincident_cluster_indices',o.section_coincident_cluster_indices);
    token=o.event_cluster_signature;cohortSupported=((ischar(token)&&isrow(token))||(isstring(token)&&isscalar(token)))&&strlength(string(token))>0;
    [~,policy]=RecordedReturnPolicy_v3(r);report=auPick(r,{'accepted','acceptance_gates','full_closure'});
    report.classification=auPick(auMember(r,'classification',struct()),{'contract_version','canonical_point_label','canonical_label_qualified','validated_gait_type','flight_count','flight_count_certain'});
    report.options=struct('Residual',[]);
    if policy.complete
        report.correction_return_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',policy.configuration.source_class,'settings',policy.configuration.settings);
        [~,back]=RecordedReturnPolicy_v3(report);assert(back.complete&&auEqual(back.configuration,policy.configuration),'PKPost:ScreenPolicyView','The small actual screen context must roundtrip every recorded policy setting.');
    end
    assert(strcmp(OrbitContentIdentity_v3(o),OrbitContentIdentity_v3(small)),'PKPost:ScreenRecordView','The named literal screen view must retain the native identity-bearing values.');
    context=struct('native_id',OrbitContentIdentity_v3(o),'parameter',o.parameter,'mode',o.initial_mode,'section',o.section_chart, ...
        'complete_policy',policy,'cohort',cohort,'cohort_supported',cohortSupported,'return_multiplicity',o.return_multiplicity, ...
        'saved_current_all9_PK',admitted(r),'scope','Named small literal record/policy/admission/cohort view for pure screening; no native reports/trajectories retained in the candidate table.');
end
function yes=auLexLess(a,b),k=find(a~=b,1);yes=~isempty(k)&&a(k)<b(k);end
function v=auEmpty(x),if isempty(x),v=NaN;else,v=x;end,end

function r=auRole(rows,roles,name)
    at=find(strcmp(roles,name));assert(isscalar(at),'PKPost:Role','One explicit immutable source role is required.');r=rows{at}.reference;
end
function m=auMap(receipt,r,index)
    at=find(cellfun(@(m)strcmp(m.source_file,r.file)&&strcmp(m.source_sha256,r.sha256)&&m.source_index==index,receipt.occurrence_map));
    assert(isscalar(at),'PKPost:OccurrenceMap','Exact source FILE/SHA/INDEX must map uniquely; NativeID-nearest matching is forbidden.');m=receipt.occurrence_map{at};
end
function [g,a,b]=auSameComponent(graphs,left,right)
    assert(strcmp(left.target_file,right.target_file),'PKPost:SameComponent','The two mapped occurrences must share one actual component.');
    g=find(cellfun(@(v)strcmp(v.reference.file,left.target_file),graphs));assert(isscalar(g),'PKPost:GraphReference','One actual frozen component graph is required.');a=left.target_index;b=right.target_index;
end
function out=auReportSubset(template,full)
    assert(isstruct(template)&&isscalar(template)&&isstruct(full)&&isscalar(full),'PKPost:ReportShape','Compare only the old declared saved scalar report projection.');out=struct();
    for name=fieldnames(template).'
        key=name{1};assert(isfield(full,key),'PKPost:RetainedReportField','A declared old retained report field is missing from the actual union report.');v=full.(key);
        if ismember(key,{'classification','primitive'}),v=auHead(template.(key),v);end;out.(key)=v;
    end
end
function out=auHead(template,full)
    assert(isstruct(template)&&isscalar(template),'PKPost:RetainedHead','The old retained head must keep its actual scalar struct shape.');out=struct();names=fieldnames(template);
    if isempty(names),return;end
    assert(isstruct(full)&&isscalar(full)&&all(isfield(full,names)),'PKPost:RetainedHeadFields','Only actual fields retained by the old projection are compared.');
    for k=1:numel(names),out.(names{k})=full.(names{k});end
end
function out=auAdmission(r)
    out=auPick(r,{'accepted','acceptance_gates','full_closure'});g=auMember(r,'classification',struct());
    out.classification=auPick(g,{'contract_version','canonical_point_label','canonical_label_qualified','validated_gait_type','flight_count','flight_count_certain'});
    [~,policy]=RecordedReturnPolicy_v3(r);out.complete_policy=policy.complete;out.policy_configuration=policy.configuration;
end
function out=auRecord(o)
    out=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement, ...
        'return_policy_name',o.return_policy_name,'section_chart',o.section_chart,'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature);
end
function out=auPick(s,names)
    out=struct();if ~isstruct(s)||~isscalar(s),out.unsupported_source_class=class(s);out.unsupported_source_size=size(s);return;end
    for k=1:numel(names),if isfield(s,names{k}),out.(names{k})=s.(names{k});end,end
end
function out=auFields(s),if isstruct(s),out=fieldnames(s);else,out={['UNSUPPORTED_',class(s)]};end,end
function v=auMember(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end
function yes=auEqual(a,b),yes=strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b));end
function auSame(a,b),assert(auEqual(a,b),'PKPost:Typed','Complete declared typed values differ.');end
function auSave(file,audit),save(file,'audit','-v7');x=load(file,'audit');auSame(audit,x.audit);end
function f=auFailure(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function out=auUnresolved(e),out=struct('status','UNRESOLVED','observations_completed',false,'failure',auFailure(e));end
function auVerify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,auLiteral(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKPost:Changed','A consumed immutable input/source changed.');end,end
function r=auRef(file),r=struct('file',auLiteral(file),'sha256',RoundSHA256_v3(file));end
function p=auLiteral(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKPost:Alias','Hash and native read must address the same literal file.');end
function l=auLimit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function auCheck(l),assert(auUTC()<l.deadline_unix_seconds&&auNano()<l.deadline_monotonic_ns,'PKPost:Clock','Original1800/60 saved-data clock expired.');end
function t=auUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=auNano(),t=double(java.lang.System.nanoTime());end
function g=screen(source,target,pair,index,ix)
    g=struct('eligible',false,'source_pair',pair,'failure',struct(),'energy_chart_regularity','UNASSESSED_until_future_native_Run', ...
        'target_is_root_seed',false,'target_scope','Only selects the owned PAL plane.');
    try
        [a,ra,ma]=get(source,pair(1));[b,rb,mb]=get(source,pair(2));[t,rt,mt]=get(target,index);
        g.source_native_ids={OrbitContentIdentity_v3(a);OrbitContentIdentity_v3(b)};g.target_native_id=OrbitContentIdentity_v3(t);
        e=find(cellfun(@(z)isequal(sort([z.from,z.to]),sort(pair)),ix.edges));
        assert(isscalar(e)&&edgeOwner(ix,ix.edges{e})&&strcmp(ma.component_identity,mb.component_identity), ...
            'PKClosure:SourceEdge','Both explicit orientations must bind the same actual owned edge.');g.stored_edge=ix.edges{e};
        assert(admitted(ra)&&admitted(rb)&&admitted(rt),'PKClosure:Admission','Require literal saved current-contract one-flight PK/all9.');
        [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);[~,pt]=RecordedReturnPolicy_v3(rt);
        g.complete_policy_equal=pa.complete&&pb.complete&&pt.complete&&isequaln(pa.configuration,pb.configuration)&&isequaln(pb.configuration,pt.configuration);
        g.exact_pq=isequaln(a.parameter,b.parameter)&&isequaln(b.parameter,t.parameter)&&isequaln(a.initial_mode,b.initial_mode)&&isequaln(b.initial_mode,t.initial_mode);
        g.source_section=MatchingReturnSection_v3(a,b,{ra,rb});g.target_section=MatchingReturnSection_v3(b,t,{rb,rt});
        g.section_tokens_equal=isequaln(a.section_relative_event_signature,b.section_relative_event_signature)&&isequaln(b.section_relative_event_signature,t.section_relative_event_signature);
        g.cyclic_tokens_equal=isequaln(a.cyclic_event_signature,b.cyclic_event_signature)&&isequaln(b.cyclic_event_signature,t.cyclic_event_signature);
        assert(g.complete_policy_equal&&g.exact_pq&&g.source_section.compatible&&g.target_section.compatible ...
            &&g.section_tokens_equal&&g.cyclic_tokens_equal,'PKClosure:Contract','Exact saved policy/pq/marked-section/token contracts differ.');
        assert(~any(b.initial_mode)&&all(isfinite([a.initial_state(:);b.initial_state(:);t.initial_state(:)])), ...
            'PKClosure:FlightChart','Use actual all-flight raw states for the source-backed4D pronk calculation.');
        s=QuadrupedSchema_v3.shared();p=b.parameter(:);x=b.initial_state(:);parameter=s.Parameter;
        defects=[abs(x(s.State.dy)),norm(x([s.State.phi,s.State.dphi]),Inf), ...
            norm(x(s.Leg.AngleIndices)-x(s.State.alphaBL),Inf),norm(x(s.Leg.RateIndices)-x(s.State.dalphaBL),Inf), ...
            norm(p([parameter.k_l_b,parameter.k_s_b,parameter.l_l_b,parameter.rsla_b]) ...
                -p([parameter.k_l_f,parameter.k_s_f,parameter.l_l_f,parameter.rsla_f]),Inf),abs(p(parameter.l_com)-.5)];
        g.source_base_chart_defects=defects;
        assert(all(defects(1:4)<=1e-8)&&all(defects(5:6)<=1e-12), ...
            'PKClosure:PronkChart','The admitted base must satisfy the existing all-flight apex/pronk coordinate preconditions.');
        ids=[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL];
        assert(isequal(ids,[2,3,7,8]),'PKClosure:Coordinates','Retain the actual current four independent raw-coordinate indices.');
        ua=a.initial_state(ids);ua=ua(:);ub=b.initial_state(ids);ub=ub(:);ut=t.initial_state(ids);ut=ut(:);
        lift=b.initial_state(:);lift(ids)=ub;lift([9,11,13])=lift(7);lift([10,12,14])=lift(8);
        assert(isequaln(lift,b.initial_state(:)),'PKClosure:BaseLift','The unchanged admitted base must roundtrip exactly; no snap or projection.');
        scale=max([ones(4,1),abs(ua),abs(ub)],[],2);delta=(ub-ua)./scale;chord=norm(delta);
        assert(isfinite(chord)&&chord>1e-10,'PKClosure:Chord','Use a resolved actual preceding-pair chord.');tangent=delta/chord;
        ds=dot(tangent,(ut-ub)./scale);predictor=ub+scale.*(ds*tangent);
        g.coordinate_indices=ids;g.source_coordinates=[ua,ub];g.target_coordinates=ut;g.scale=scale;g.tangent=tangent;
        g.chord=chord;g.requested_step=ds;g.predictor_coordinates=predictor;g.predictor_distance=norm((ut-predictor)./scale);
        g.source_owner=ma.component_identity;g.target_owner=mt.component_identity;
        g.eligible=isfinite(ds)&&ds>=1e-7&&ds<=.04&&isfinite(g.predictor_distance)&&g.predictor_distance<=.001;
        g.scope='Run243-246 max1 preceding-pair scales and signed projection only; no abs(ds), automatic flip, target seed, Map or energy-pivot test.';
    catch e,g.failure=struct('identifier',e.identifier,'message',e.message);end
end
function [o,r,m]=get(d,index)
    k=find(d.indices==index);assert(isscalar(k),'PKClosure:SelectedIndex','One actual selected native view is required.');o=d.orbits{k};r=d.reports{k};m=d.metadata{k};
end
function yes=admitted(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    gates=member(r,'acceptance_gates',struct());g=member(r,'classification',struct());[~,version]=GaitSemanticTable_v3();
    yes=isequal(member(r,'accepted',false),true)&&all(isfield(gates,keys))&&strcmp(member(g,'contract_version',''),version) ...
        &&strcmp(member(g,'validated_gait_type',''),'PK')&&strcmp(member(g,'canonical_point_label',''),'PK') ...
        &&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1);
    for k=1:numel(keys),yes=yes&&isequal(member(gates,keys{k},false),true);end
end
function yes=edgeOwner(ix,e)
    yes=e.from>=1&&e.to>=1&&e.from<=numel(ix.points)&&e.to<=numel(ix.points) ...
        &&strcmp(ix.points{e.from}.component_identity,e.component_identity)&&strcmp(ix.points{e.to}.component_identity,e.component_identity);
end
function v=member(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
