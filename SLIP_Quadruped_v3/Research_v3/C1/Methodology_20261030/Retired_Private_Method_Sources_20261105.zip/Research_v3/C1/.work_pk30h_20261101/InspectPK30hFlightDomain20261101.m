function result=InspectPK30hFlightDomain20261101(budget,options)
%INSPECTPK30HFLIGHTDOMAIN20261101 Saved-flight conditional bounds, no replay.
    entryUTC=utc();entryMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(nargin==2&&isstruct(options)&&isscalar(options) ...
        &&isequal(sort(fieldnames(options)),sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,600)&&isequal(options.SaveMarginSeconds,60), ...
        'PKDomain:Options','Use one fresh output and the reviewed600/60 allowance.');
    assert(budget.capture.pid==feature('getpid'),'PKDomain:Budget','Recalibrate the original grant in this process.');
    finish=lim(min(budget.research_deadline_unix_seconds,entryUTC+600), ...
        min(budget.research_deadline_monotonic_ns,entryMono+600e9));
    work=lim(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=literal(options.OutputFile);stage=[output,'.pending.mat'];
    assert(startsWith(output,[literal(fullfile(N,'Audits')),filesep])&&~isfile(output)&&~isfile(stage), ...
        'PKDomain:Fresh','Preserve any earlier or uncertain publication.');
    names={'InspectPK30hFlightDomain20261101','AllFlightClearanceBounds_v3','QuadrupedSchema_v3', ...
        'BranchSolutionFile_v3','OrbitContentIdentity_v3','RecordedReturnPolicy_v3','C1ScientificDigest_v3', ...
        'RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cellfun(@(n)ref(which(n)),names(:),'UniformOutput',false);
    refs{end+1}=ref(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
    assert(strcmp(RoundSHA256_v3(which('AllFlightClearanceBounds_v3')), ...
        'dc22c3874c345366e138aa7c684fa7fe102b3adde87ef855e3313ea6e82e5620'),'PKDomain:Helper','Keep the reviewed helper.');
    controls=struct('file',fullfile(N,'Connected_PK_PK30h_20261101','C1_PK_PrimaryBoundary_Inward_Controls.mat'), ...
        'sha256','813c2c1463fd490ad0da7e2929a10f2ec1eae0c455a8a8681c1a18cae8de42dc');
    grazing=struct('file',fullfile(N,'Audits','PK30h_20261101_Secondary0072_FlightGrazing.mat'), ...
        'sha256','b2f97bc1b11e6e6fc067b764ed0da9cd18a8560f53aa0bc750046fbb9ed5a3dd');
    survey=struct('file',fullfile(N,'Audits','PK30h_20261101_Finite13_Coverage.mat'), ...
        'sha256','0f051fd35c122e57373c22de80a867aeaf42899a2829ba1d119fb5f3b91937c7');
    core=struct('file',fullfile(N,'Compact_Exports_20261030','C1_PK_Connected04_Core29_Loading_20261101.mat'), ...
        'sha256','75dbd2012853aadbbec2fcee5b10560abad335b8c6bc383d4e4e43405479d6a9');
    acquisition={struct('file',fullfile(N,'Audits','PK30h_20261101_Overlap_negative_primary.mat'), ...
        'sha256','f054271ca3e255f2d65f39a521f430decf432fb8fc26e11becabd631d5686d79'); ...
        struct('file',fullfile(N,'Audits','PK30h_20261101_Overlap_positive_primary.mat'), ...
        'sha256','1d41ac65c49cc78a28bfb345dcfca3e20d3b0a3d459125ce6cc0095c13f8419f')};
    forks={struct('file',fullfile(N,'Connected_PK_PK30h_20261101','C1_PK_Overlap_negative_primary.mat'), ...
        'sha256','f2c77a0bd8865873e8ee9779ddb6568c82a8ac7b6e0206d9eb5f8b6cb736f7ff'); ...
        struct('file',fullfile(N,'Connected_PK_PK30h_20261101','C1_PK_Overlap_positive_primary.mat'), ...
        'sha256','606e88ca6d8d63bd45fdd2ba7a4be6b6adcc28736ecb4da780d7f72e8ab1ebb7')};
    refs=[refs;{controls;grazing;survey;core};acquisition;forks];verify(refs);check(work);
    audit=struct('schema','PK30h-saved-flight-domain-and-route-observations-v1', ...
        'input_references',{refs},'original_budget',budget,'original_finish',finish,'options',options, ...
        'known_cases',{{}},'saved_flights',{{}},'saved_observations',struct(), ...
        'helper_calls_attempted',0,'helper_calls_returned',0,'source_posthash',false,'completed',false, ...
        'failure',struct(),'root_ODE_map_classifier_replay_calls',0,'new_admission_claimed',false, ...
        'formal_continuous_coverage_claimed',false,'absence_of_earlier_touchdown_claimed',false, ...
        'arithmetic_cushion_scope','1e-11 is an explicit conditional TOTAL scalar-expression error bound in guard-length units, not a proved floating-point error estimate.');
    custody(stage,audit);
    try
        s=QuadrupedSchema_v3.shared();[orbits,reports]=BranchSolutionFile_v3.loadSolutions(controls.file,[1;2]);
        for k=1:2
            o=orbits{k};assert(isa(o.trajectory,'Trajectory_v3'),'PKDomain:Trajectory','Use the actual saved native trajectory.');
            tol=actualTolerance(o);[flights,receipt]=nativeFlights(o,s);
            [~,policy]=RecordedReturnPolicy_v3(reports{k});assert(policy.complete,'PKDomain:Policy','Retain complete actual policy.');
            for n=1:2
                f=flights{n};f.label=sprintf('primary_control_%d_%s',k,f.phase);
                f.source_reference=controls;f.source_index=k;f.native_id=OrbitContentIdentity_v3(o);
                f.extraction_receipt=receipt;f.recorded_policy=policy.configuration;
                f.SwingPenetrationTolerance=tol;[f,audit]=evaluate(f,audit,work);
                audit.saved_flights{end+1,1}=f;custody(stage,audit);check(work);show(f);
            end
        end
        % Known formulas use schema-valid explicit synthetic data only.
        p=orbits{1}.parameter;p([s.Parameter.k_s_b,s.Parameter.k_s_f])=0;
        p([s.Parameter.l_l_b,s.Parameter.l_l_f])=1;p([s.Parameter.rsla_b,s.Parameter.rsla_f])=0;
        x=zeros(14,1);x(s.State.y)=2;q=false(4,1);
        cases={make('ks0_clear',x,q,p,.1,0,'COND_CONSERVATIVE_NUMERICAL_NONPENETRATION'); ...
            make('initial_violation',set(x,s.State.y,.5),q,p,.1,0,'COND_CONSERVATIVE_NUMERICAL_VIOLATION'); ...
            make('zero_endpoint_tol0',set(set(x,s.State.y,1),s.State.dy,1),q,p,.1,0,'UNRESOLVED'); ...
            make('cell_depth_cap',set(set(x,s.State.y,1),s.State.dy,1),q,p,.1,0,'UNRESOLVED')};
        z=set(x,s.State.y,3);z(s.State.dphi)=.1;z(s.Leg.AngleIndices)=[.01;-.02;.03;-.04];
        z(s.Leg.RateIndices)=[.1;-.2;.3;-.4];
        cases{end+1,1}=make('literal_nonzero_pitchrate',z,q,p,.1,0,'COND_CONSERVATIVE_NUMERICAL_NONPENETRATION');
        pOsc=p;pOsc([s.Parameter.k_s_b,s.Parameter.k_s_f])=1;
        cases{end+1,1}=make('positive_ks_oscillator',set(z,s.State.dphi,0),q,pOsc,.1,0,'COND_CONSERVATIVE_NUMERICAL_NONPENETRATION');
        cases{end+1,1}=make('expired_deadline',x,q,p,.1,0,'UNRESOLVED');
        cases{end+1,1}=make('nonallflight_refusal',x,logical([1;0;0;0]),p,.1,0,'ERROR_FlightBounds:Mode');
        for k=1:numel(cases)
            [f,audit]=evaluate(cases{k},audit,work);
            audit.known_cases{end+1,1}=f;custody(stage,audit);check(work);
            assert(strcmp(f.observed_status,f.expected_status),'PKDomain:KnownCase','Known case %s differed: %s.',f.label,f.observed_status);show(f);
        end
        saved=load(grazing.file,'study');g=saved.study;
        assert(g.completed&&g.source_posthash,'PKDomain:Grazing','Use the closed saved grazing observations.');
        tol=actualTolerance(g.native_orbit);
        assert(isequal(tol,g.original_swing_penetration_tolerance), ...
            'PKDomain:Tolerance','The saved study and actually returned native physical tolerances must agree.');
        rows={g.boundary};for k=1:numel(g.stencil),if isfield(g.stencil{k},'final_flight'),rows{end+1}=g.stencil{k};end,end %#ok<AGROW>
        for k=1:numel(rows)
            ff=rows{k}.final_flight;
            f=make(sprintf('grazing_saved_final_%d',k),ff.raw_liftoff_state,false(4,1),ff.parameter,ff.duration,tol,'');
            f.source_reference=grazing;f.historical_final_flight=struct('row_number',k, ...
                'completed',ff.completed,'continuous_coverage_claimed',ff.continuous_coverage_claimed, ...
                'raw_pitch_and_rate',ff.raw_pitch_and_rate,'minimum_observed_guard_per_leg',ff.minimum_observed_guard_per_leg);
            [f,audit]=evaluate(f,audit,work);audit.saved_flights{end+1,1}=f;custody(stage,audit);check(work);show(f);
        end
        % Saved Survey extraction is observational and cannot invalidate the
        % already retained flight results if an optional field is absent.
        try,audit.saved_observations=savedSurvey(survey,core,acquisition,forks);catch e,audit.saved_observations=struct('status','UNASSESSED','failure',failure(e));end
        custody(stage,audit);check(work);
        try
            fprintf('PK_DOMAIN_SAVED_ROUTE %s\n',jsonencode(audit.saved_observations.route_summary));
            fprintf('PK_DOMAIN_HISTORICAL_HEADERS %s\n',jsonencode(audit.saved_observations.historical_headers));
            fprintf('PK_DOMAIN_NATIVE_HEADERS %s\n',jsonencode(audit.saved_observations.inventory_headers));
        catch,end
        verify(refs);audit.source_posthash=true;audit.completed=true;
    catch e,audit.failure=failure(e);try,verify(refs);audit.source_posthash=true;catch,end
    end
    custody(stage,audit);check(finish);
    assert(audit.completed&&audit.source_posthash,'PKDomain:Incomplete','Retain pending results: %s',jsonencode(audit.failure));
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    back=load(output,'audit');assert(strcmp(C1ScientificDigest_v3(audit),C1ScientificDigest_v3(back.audit)), ...
        'PKDomain:InstalledReadback','Retain complete installed plain results.');delete(stage);check(finish);
    result=struct('completed',true,'source_posthash',true,'audit_reference',ref(output), ...
        'helper_calls_attempted',audit.helper_calls_attempted,'helper_calls_returned',audit.helper_calls_returned, ...
        'root_ODE_map_classifier_replay_calls',0,'new_admission_claimed',false,'formal_continuous_coverage_claimed',false);
    fprintf('PK_DOMAIN_RETURN %s\n',jsonencode(result));
end
function [f,a]=evaluate(f,a,parent)
    check(parent);o=struct('SwingPenetrationTolerance',f.SwingPenetrationTolerance,'ArithmeticCushion',1e-11, ...
        'Limits',parent,'MaxWallSeconds',10);
    if strcmp(f.label,'cell_depth_cap'),o.MaxCells=4;o.MaxDepth=0;end
    if strcmp(f.label,'expired_deadline'),o.Limits=lim(utc()-1,nano()-1e9);end
    f.options=o;f.result=struct();f.failure=struct();call=tic;
    a.helper_calls_attempted=a.helper_calls_attempted+1;
    try
        f.result=AllFlightClearanceBounds_v3(f.initial_state,f.initial_mode,f.parameter,f.duration,o);
        a.helper_calls_returned=a.helper_calls_returned+1;f.observed_status=f.result.status;
    catch e,f.failure=failure(e);f.observed_status=['ERROR_',e.identifier];end
    f.elapsed_seconds=toc(call);
end
function show(f)
    try,fprintf('PK_DOMAIN_FLIGHT %s\n',jsonencode(struct('label',f.label,'status',f.observed_status,'seconds',f.elapsed_seconds)));catch,end
end
function f=make(label,x,q,p,T,tol,expected)
    f=struct('label',label,'initial_state',x,'initial_mode',q,'parameter',p,'duration',T, ...
        'SwingPenetrationTolerance',tol,'expected_status',expected);
end
function [F,r]=nativeFlights(o,s)
    t0=o.trajectory.time(1);b=o.trajectory.event_batches;
    assert(numel(b)==2&&all(isfield(b,{'time','event_ids','mode_before','mode_after','state_after'})), ...
        'PKDomain:Cohorts','Require exactly the actual TD and LO atomic batches.');
    ids=cell(2,1);for k=1:2,ids{k}=cellfun(@(x)s.eventId(x),b(k).event_ids);end
    assert(isequal(sort(ids{1}(:)),s.Event.IDs(s.Event.IsTouchdown).') ...
        &&isequal(sort(ids{2}(:)),s.Event.IDs(~s.Event.IsTouchdown).') ...
        &&~any(o.initial_mode)&&~any(b(1).mode_before)&&all(b(1).mode_after) ...
        &&all(b(2).mode_before)&&~any(b(2).mode_after),'PKDomain:Cohorts','Use atomic all-leg TD then all-leg LO, never an intermediate reset.');
    T1=b(1).time-t0;T2=o.period-(b(2).time-t0);
    assert(T1>0&&T2>0&&b(2).time>b(1).time,'PKDomain:Durations','Require positive actual native flight durations.');
    F={make('',o.initial_state,o.initial_mode,o.parameter,T1,NaN,'');make('',b(2).state_after,b(2).mode_after,o.parameter,T2,NaN,'')};
    F{1}.phase='first';F{2}.phase='final';
    r=struct('trajectory_initial_time',t0,'period',o.period,'actual_batches',b, ...
        'first_interval',[t0,b(1).time],'final_interval',[b(2).time,t0+o.period], ...
        'final_state_source','Atomic last LO batch.state_after, with literal raw pitch and rates retained.');
end
function t=actualTolerance(o)
    assert(isfield(o.minimum_physical_margins,'active_tolerances') ...
        &&isfield(o.minimum_physical_margins.active_tolerances,'swing_penetration'), ...
        'PKDomain:Tolerance','Use the tolerance observed in the saved native orbit.');
    t=o.minimum_physical_margins.active_tolerances.swing_penetration;
    validateattributes(t,{'double'},{'real','finite','scalar','nonnegative'});
end
function o=savedSurvey(r,coreReference,acquisition,forks)
    z=load(r.file,'audit');a=z.audit;
    assert(a.completed&&a.source_posthash&&isempty(a.jobs),'PKDomain:Survey','Use the closed observation-only Survey.');
    z=load(coreReference.file,'solution_core29','core_digest');c=z.solution_core29;
    assert(strcmp(C1ScientificDigest_v3(c),z.core_digest),'PKDomain:CoreDigest','Bind the complete unchanged plain Core.');
    o=extractSavedFacts(a,c);p=a.queue{1}.planning.core;rel=p.endpoint_relation;
    o.physical_route_rows=cell(0,1);o.source_fork_attachments=cell(2,1);
    assert(rel.minimum_connectivity_layer==2&&~rel.ambiguous_parallel_relation_types, ...
        'PKDomain:Route','Check the actual unique P+E endpoint route, not overall component counts.');
    for k=1:numel(rel.steps)
        step=rel.steps{k};assert(all(ismember(step.relation_kinds,{'physical_edges','record_equalities'})), ...
            'PKDomain:RouteKinds','No alias or numerical link is silently promoted.');
        for n=step.relation_rows{1}(:).'
            e=c.graph.physical_edges{n};u=e.from;v=e.to;
            assert(isequal(sort([u,v]),sort([step.from,step.to])) ...
                &&strcmp(c.point_metadata{u}.component_identity,e.component_identity) ...
                &&strcmp(c.point_metadata{v}.component_identity,e.component_identity) ...
                &&isequal(c.point_metadata{v}.edge_from,u)&&isequal(c.point_metadata{v}.edge_enabled,true), ...
                'PKDomain:PhysicalRow','Preserve actual physical owner/predecessor and traversal orientation.');
            o.physical_route_rows{end+1,1}=struct('path_step',k,'physical_row',n,'saved_from',u,'saved_to',v, ...
                'path_from',step.from,'path_to',step.to,'traversed_in_saved_direction',u==step.from, ...
                'owner',e.component_identity,'from_native_id',c.native_ids{u},'to_native_id',c.native_ids{v});
        end
    end
    for k=1:2
        endpoint=p.association_source_bases{k};assert(isscalar(endpoint.core_occurrence_matches), ...
            'PKDomain:Endpoint','Retain unique actual endpoint occurrence selectors.');
        z=load(acquisition{k}.file,'audit');x=z.audit;[os,rs,ms]=BranchSolutionFile_v3.loadSolutions(forks{k}.file,[2;3]);
        assert(x.completed&&x.source_posthash&&x.ordinary_edge_earned&&x.qualified_numerical_relation ...
            &&isequaln(x.run_branch_reference,forks{k})&&strcmp(x.source_native_ids{2},endpoint.native_id) ...
            &&isequaln(x.source_reference,endpoint.original_source_reference) ...
            &&isequal(x.source_pair,endpoint.original_source_pair) ...
            &&strcmp(OrbitContentIdentity_v3(os{1}),endpoint.native_id) ...
            &&strcmp(OrbitContentIdentity_v3(os{2}),x.candidate_native_id) ...
            &&isequal(ms{2}.edge_enabled,true)&&isequal(ms{2}.edge_from,2) ...
            &&strcmp(ms{1}.component_identity,ms{2}.component_identity), ...
            'PKDomain:SourceAttachment','The actual source import and earned2-to3 edge must attach to the selected endpoint.');
        index=endpoint.core_occurrence_matches;
        native=struct('initial_state',os{1}.initial_state,'parameter',os{1}.parameter,'initial_mode',os{1}.initial_mode, ...
            'period',os{1}.period,'stride',os{1}.stride_displacement);
        [~,policy]=RecordedReturnPolicy_v3(rs{1});assert(policy.complete,'PKDomain:Policy','Bind complete actual native policy.');
        match=struct('state',isequaln(native.initial_state,c.solution_matrix(1:14,index)), ...
            'parameter',isequaln(native.parameter,c.parameters{index}),'mode',isequaln(native.initial_mode,c.modes{index}), ...
            'period',isequaln(native.period,c.solution_matrix(29,index)),'stride',isequaln(native.stride,c.solution_matrix(15:28,index)), ...
            'policy',isequaln(policy.configuration,c.policies{index}.configuration), ...
            'section_signature',isequaln(os{1}.section_relative_event_signature,c.orbit_evidence{index}.section_relative_event_signature), ...
            'cyclic_signature',isequaln(os{1}.cyclic_event_signature,c.orbit_evidence{index}.cyclic_event_signature));
        o.source_fork_attachments{k}=struct('core_occurrence',index,'core_context',c.contexts{index}, ...
            'association_reference',acquisition{k},'fork_reference',forks{k},'actual_import_index',2,'actual_child_index',3, ...
            'source_native_id',endpoint.native_id,'candidate_native_id',x.candidate_native_id, ...
            'literal_core_native_comparisons',match,'owned_edge_verified',true);
    end
    estate=true;
    for k=1:numel(o.E_rows)
        e=o.E_rows{k};keys={'state','stride','T','p','q','E','complete_policy','section_tokens','event_tokens','native_id'};
        estate=estate&&isempty(e.unavailable_comparisons)&&all(cellfun(@(f)isfield(e.literal_equal,f)&&e.literal_equal.(f),keys)) ...
            &&e.saved_from_id_matches_core&&e.saved_to_id_matches_core;
    end
    imports=all(cellfun(@(x)all(structfun(@(v)isequal(v,true),x.literal_core_native_comparisons)),o.source_fork_attachments));
    o.route_summary=struct('minimum_connectivity_layer',rel.minimum_connectivity_layer,'endpoint_occurrences',rel.path([1,end]), ...
        'ordered_core_path',rel.path,'physical_step_count',numel(o.physical_route_rows),'exact_step_count',numel(o.E_rows), ...
        'all_E_literal_complete_value_comparisons_passed',estate,'actual_source_imports_full_values_match',imports, ...
        'source_owned_edges_verified',true,'old_M_required_for_selected_route',false, ...
        'single_owner_directed_trace_claimed',false,'global_endpoint_claimed',false, ...
        'scope','Finite saved P+E route and actual new earned fork edges; boundary-control associations remain numerical.');
end
function x=set(x,k,v),x(k)=v;end
function custody(file,audit),save(file,'audit','-v7');b=load(file,'audit');assert(strcmp(C1ScientificDigest_v3(audit),C1ScientificDigest_v3(b.audit)),'PKDomain:Readback','Retain complete plain results.');end
function f=failure(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function verify(rs),for k=1:numel(rs),assert(strcmp(RoundSHA256_v3(rs{k}.file),rs{k}.sha256)&&strcmp(rs{k}.file,literal(rs{k}.file)),'PKDomain:Changed','Fixed authority changed.');end,end
function r=ref(f),r=struct('file',literal(f),'sha256',RoundSHA256_v3(f));end
function p=literal(f),p=char(java.io.File(f).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(f)).getCanonicalPath())),'PKDomain:Alias','Hash and native load must address identical bytes.');end
function l=lim(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKDomain:Clock','Original600/60 bound expired.');end
function t=utc(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=nano(),t=double(java.lang.System.nanoTime());end

function o=extractSavedFacts(audit,c)
% SOURCE-ONLY integration draft; caller binds Survey audit0f051/Core75db bytes
% and typed digests. No loads, policy constructors, model calls or fresh gates.
% All returned comparisons are literal saved-data observations, not equivalence
% certificates. Inventory coordinate slots2/3/7/8 are Schema_v3 dx/y/alphaBL/dalphaBL.
    o=struct('status','UNAVAILABLE_SURVEY_FIELDS','endpoints',{{}},'route_header',struct(), ...
        'ordered_route',{{}},'E_rows',{{}},'historical_headers',{{}},'inventory_headers',{{}}, ...
        'scope','Saved Survey/Core fields only; no new admission, endpoint, physical arc or GUI claim.');
    if ~isstruct(audit)||~isscalar(audit)||~isfield(audit,'queue')||~iscell(audit.queue),return,end
    Q=audit.queue;planning=[];
    if ~isempty(Q)&&isstruct(Q{1})&&isscalar(Q{1})&&isfield(Q{1},'planning')
        p=Q{1}.planning;if isstruct(p)&&isscalar(p)&&isfield(p,'core'),planning=p.core;end
    end
    if isstruct(planning)&&isscalar(planning)
        if isfield(planning,'association_source_bases')&&iscell(planning.association_source_bases)
            for k=1:numel(planning.association_source_bases)
                e=svPick(planning.association_source_bases{k},{'association_audit_reference','original_source_reference', ...
                    'original_source_pair','native_id','core_occurrence_matches','physical_bins','physical_exact_bins', ...
                    'physical_exact_alias_bins','all_layer_bins'});e.selector_order=k;o.endpoints{end+1,1}=e;
            end
        end
        if isfield(planning,'endpoint_relation')
            r=planning.endpoint_relation;
            o.route_header=svPick(r,{'status','minimum_connectivity_layer','path','scope','physical_arc_across_nonphysical_links_claimed', ...
                'ambiguous_parallel_relation_types'});
            if isstruct(r)&&isscalar(r)&&isfield(r,'steps')&&iscell(r.steps)
                for k=1:numel(r.steps)
                    step=svPick(r.steps{k},{'from','to','relation_kinds','relation_rows','physical_chord_assigned'});
                    step.saved_step_order=k;step.row_table_order={'physical_edges','record_equalities','qualified_aliases','numerical_seams'};
                    o.ordered_route{end+1,1}=step;
                    if isfield(step,'relation_rows')&&iscell(step.relation_rows)&&numel(step.relation_rows)>=2
                        for index=step.relation_rows{2}(:).'
                            z=struct('saved_step_order',k,'record_equality_row',index,'status','UNAVAILABLE_CORE_E_ROW');
                            if isstruct(c)&&isscalar(c)&&isfield(c,'graph')&&isstruct(c.graph)&&isscalar(c.graph) ...
                                    &&isfield(c.graph,'record_equalities')&&iscell(c.graph.record_equalities) ...
                                    &&isnumeric(index)&&isscalar(index)&&isfinite(index)&&index==fix(index)&&index>=1&&index<=numel(c.graph.record_equalities)
                                z=svECheck(c.graph.record_equalities{index},c);z.saved_step_order=k;z.record_equality_row=index;
                            end
                            o.E_rows{end+1,1}=z;
                        end
                    end
                end
            end
        end
    else
        o.route_header=struct('status','UNAVAILABLE_audit_queue1_planning_core');
    end
    for k=1:numel(Q)
        q=Q{k};
        if isstruct(q)&&isscalar(q)&&isfield(q,'role')&&strcmp(q.role,'historical_frontier_obligation')
            h=svPick(q,{'id','historical_status','role','source_reference','pair','execute','journal_row','history_locator'});h.queue_index=k;
            if isfield(q,'historical_frontier_state')
                h.literal_frontier_headers=svPick(q.historical_frontier_state,{'status','last_stop_reason','strategy_index','step', ...
                    'derivative_index','consecutive_no_growth','run_count','total_new_points','last_dispatched_sequence', ...
                    'last_accepted_index','last_accepted_energy','last_accepted_signed_apex_dx'});
                f=q.historical_frontier_state;
                if isstruct(f)&&isscalar(f)&&isfield(f,'obstruction'),h.obstruction_header=svPick(f.obstruction,{'status','physical_endpoint_claimed'});end
            else,h.literal_frontier_headers=struct('status','UNAVAILABLE_historical_frontier_state');end
            o.historical_headers{end+1,1}=h;
        end
    end
    if isfield(audit,'inventory')&&iscell(audit.inventory)
        for k=1:numel(audit.inventory)
            r=audit.inventory{k};h=svPick(r,{'id','historical_status','source_reference','source_pair','execute_requested'});
            h.inventory_index=k;h.role='UNAVAILABLE_unique_queue_id_join';matches=[];
            if isfield(h,'id')
                for j=1:numel(Q)
                    q=Q{j};if isstruct(q)&&isscalar(q)&&isfield(q,'id')&&strcmp(q.id,h.id),matches(end+1)=j;end
                end
            end
            if isscalar(matches)&&isfield(Q{matches},'role'),h.role=Q{matches}.role;h.queue_index=matches;end
            h.points=cell(0,1);
            if isstruct(r)&&isscalar(r)&&isfield(r,'rows')&&iscell(r.rows)
                for j=1:numel(r.rows),h.points{end+1,1}=svInventoryPoint(r.rows{j});end
            else,h.rows_status='UNAVAILABLE_inventory_rows';end
            o.inventory_headers{end+1,1}=h;
        end
    end
    o.historical_header_count=numel(o.historical_headers);o.expected_historical_header_count=13;
    o.inventory_header_count=numel(o.inventory_headers);o.expected_inventory_header_count=17;
    o.status='SAVED_FIELD_EXTRACTION_RETURNED';
end

function out=svInventoryPoint(r)
    out=svPick(r,{'native_id','owner','literal_metadata_order','period','stride','historical_classification_header'});
    out.E_status='UNAVAILABLE_literal_metadata_nativeE';
    if isstruct(r)&&isscalar(r)&&isfield(r,'metadata')&&isstruct(r.metadata)&&isscalar(r.metadata) ...
            &&isfield(r.metadata,'nativeE')&&isnumeric(r.metadata.nativeE)&&isreal(r.metadata.nativeE) ...
            &&isscalar(r.metadata.nativeE)&&isfinite(r.metadata.nativeE)
        out.E=r.metadata.nativeE;out.E_status='LITERAL_metadata_nativeE';
    end
    if isstruct(r)&&isscalar(r)&&isfield(r,'state')&&isnumeric(r.state)&&isvector(r.state)&&numel(r.state)==14
        out.dx=r.state(2);out.h=r.state(3);out.alphaBL=r.state(7);out.omegaBL=r.state(8);
    else,out.coordinate_status='UNAVAILABLE_literal_state14';end
    if isstruct(r)&&isscalar(r)&&isfield(r,'complete_policy')
        p=r.complete_policy;out.policy=svPick(p,{'complete','reason','source_path'});
        if isstruct(p)&&isscalar(p)&&isfield(p,'configuration'),out.policy.configuration_header=svPick(p.configuration,{'source_class'});
        else,out.policy.configuration_header=struct('status','UNAVAILABLE_configuration');end
    else,out.policy=struct('status','UNAVAILABLE_complete_policy');end
end

function p=svCorePoint(c,index)
    p=struct('index',index,'status','UNAVAILABLE_CORE_SELECTOR');
    if ~isstruct(c)||~isscalar(c)||~isfield(c,'solution_matrix')||~isnumeric(c.solution_matrix) ...
            ||~isequal(size(c.solution_matrix,1),29)||~isnumeric(index)||~isscalar(index)||~isfinite(index) ...
            ||index~=fix(index)||index<1||index>size(c.solution_matrix,2),return,end
    p.status='LITERAL_CORE_ARRAYS';p.state=c.solution_matrix(1:14,index);p.stride=c.solution_matrix(15:28,index);p.T=c.solution_matrix(29,index);
    fields={'native_ids','parameters','modes','policies','section_charts','contexts'};
    labels={'native_id','p','q','complete_policy','section','context'};p.unavailable_fields=cell(0,1);
    for k=1:numel(fields)
        if isfield(c,fields{k})&&iscell(c.(fields{k}))&&numel(c.(fields{k}))>=index
            values=c.(fields{k});p.(labels{k})=values{index};
        else,p.unavailable_fields{end+1,1}=fields{k};end
    end
    if isfield(c,'native_energy')&&isnumeric(c.native_energy)&&numel(c.native_energy)>=index,p.E=c.native_energy(index);
    else,p.unavailable_fields{end+1,1}='native_energy';end
    if isfield(p,'section')
        p.section_tokens=svPick(p.section,{'id','geometry','crossing_orientation','boundary_ownership','translational_gauge','BL_touchdowns_per_return'});
    end
    if isfield(c,'orbit_evidence')&&iscell(c.orbit_evidence)&&numel(c.orbit_evidence)>=index
        p.event_tokens=svPick(c.orbit_evidence{index},{'section_relative_event_signature','cyclic_event_signature', ...
            'return_policy_name','return_multiplicity'});
    end
end

function out=svECheck(e,c)
    out=svPick(e,{'from','to','from_native_id','to_native_id','receipt_reference'});
    out.status='UNAVAILABLE_CORE_E_ENDPOINTS';out.scope='Literal saved E row/arrays only; no physical arc or fresh equivalence certificate.';
    if ~isfield(out,'from')||~isfield(out,'to'),return,end
    out.from_core=svCorePoint(c,out.from);out.to_core=svCorePoint(c,out.to);
    a=out.from_core;b=out.to_core;out.literal_equal=struct();out.unavailable_comparisons=cell(0,1);
    for name={'state','stride','T','p','q','E','complete_policy','section_tokens','event_tokens','native_id'}
        key=name{1};
        available=isfield(a,key)&&isfield(b,key);
        if available&&ismember(key,{'section_tokens','event_tokens'})
            available=isempty(a.(key).unavailable_fields)&&isempty(b.(key).unavailable_fields);
        end
        if available,out.literal_equal.(key)=isequaln(a.(key),b.(key));
        else,out.unavailable_comparisons{end+1,1}=key;end
    end
    if isfield(a,'native_id')&&isfield(out,'from_native_id'),out.saved_from_id_matches_core=isequaln(out.from_native_id,a.native_id);end
    if isfield(b,'native_id')&&isfield(out,'to_native_id'),out.saved_to_id_matches_core=isequaln(out.to_native_id,b.native_id);end
    out.evidence_native_ids=cell(0,1);out.evidence_native_id_scan_status='UNAVAILABLE_scalar_evidence';
    out.evidence_native_id_scan_scope='Only saved scalar-field/cell text matching exact NativeID syntax; no ID inferred.';
    if isstruct(e)&&isscalar(e)&&isfield(e,'evidence')
        out.evidence=svPick(e.evidence,{'schema','scalars','original_fines','scope'});
        if isstruct(e.evidence)&&isscalar(e.evidence)&&isfield(e.evidence,'scalars')&&isstruct(e.evidence.scalars)&&isscalar(e.evidence.scalars)
            scalars=e.evidence.scalars;names=fieldnames(scalars);out.evidence_native_id_scan_status='SCANNED_LITERAL_SCALAR_FIELDS';
            for k=1:numel(names)
                v=scalars.(names{k});if ~iscell(v),v={v};end
                for j=1:numel(v)
                    id=v{j};text=(ischar(id)&&isrow(id))||(isstring(id)&&isscalar(id));
                    if ~text||isempty(regexp(char(id),'^native-orbit-record:sha256:[0-9a-f]{64}$','once')),continue,end
                    z=struct('field',names{k},'element',j,'saved_native_id',id,'matches_core_from','UNAVAILABLE','matches_core_to','UNAVAILABLE');
                    if isfield(a,'native_id'),z.matches_core_from=isequaln(id,a.native_id);end
                    if isfield(b,'native_id'),z.matches_core_to=isequaln(id,b.native_id);end
                    out.evidence_native_ids{end+1,1}=z;
                end
            end
        end
    else,out.evidence=struct('status','UNAVAILABLE_evidence');end
    out.translation_normalization_status='UNASSESSED_no_supported_literal_gauge';
    if isfield(a,'state')&&isfield(b,'state')&&isfield(a,'section')&&isfield(b,'section') ...
            &&isstruct(a.section)&&isscalar(a.section)&&isstruct(b.section)&&isscalar(b.section) ...
            &&isfield(a.section,'translational_gauge')&&isfield(b.section,'translational_gauge') ...
            &&(ischar(a.section.translational_gauge)||(isstring(a.section.translational_gauge)&&isscalar(a.section.translational_gauge))) ...
            &&(ischar(b.section.translational_gauge)||(isstring(b.section.translational_gauge)&&isscalar(b.section.translational_gauge))) ...
            &&strcmp(a.section.translational_gauge,'x=0')&&strcmp(b.section.translational_gauge,'x=0')
        out.from_state_x0=a.state;out.to_state_x0=b.state;out.from_state_x0(1)=0;out.to_state_x0(1)=0;
        out.x0_states_literal_equal=isequaln(out.from_state_x0,out.to_state_x0);out.translation_normalization_status='APPLIED_ONLY_LITERAL_x=0_CHARTS_originals_retained';
    end
    if strcmp(a.status,'LITERAL_CORE_ARRAYS')&&strcmp(b.status,'LITERAL_CORE_ARRAYS'),out.status='SAVED_E_POINT_COMPARISONS_RETURNED';end
end

function out=svPick(s,names)
    out=struct();out.unavailable_fields=cell(0,1);
    for k=1:numel(names)
        if isstruct(s)&&isscalar(s)&&isfield(s,names{k}),out.(names{k})=s.(names{k});
        else,out.unavailable_fields{end+1,1}=names{k};end
    end
end
