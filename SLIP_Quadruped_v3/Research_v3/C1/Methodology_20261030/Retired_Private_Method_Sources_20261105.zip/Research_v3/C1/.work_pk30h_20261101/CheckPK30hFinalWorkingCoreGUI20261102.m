% PURE DATA FINALIZATION: fixed original hard deadline22:29:07; science cutoff20:29:07 unchanged. No Root/ODE/map/replay/classifier/admission.
function out=CheckPK30hFinalWorkingCoreGUI20261102(B,b)
% One genuine fresh-process public saved-reader + visible GUI callback check.
% No root, ODE, replay, classifier, new admission or actual pointer action.
V=V3Root_v3();N=fullfile(V,'Research_v3','C1');A=fullfile(N,'Audits');
keys={'GraphReference';'GraphClosureReference';'ManifestReference';'CoreClosureReference';'CoreReferences';'MethodRows';'BudgetReference'};
assert(nargin==2&&isstruct(b)&&isscalar(b)&&isequal(sort(fieldnames(b)),sort(keys))&&iscell(b.CoreReferences)&&iscolumn(b.CoreReferences)&&~isempty(b.CoreReferences)&&isstruct(b.MethodRows),'PKFinalCold:Inputs','Use only explicit actual graph, successful export closure, manifest, core and canonical method references.');
t=clocks();assert(B.capture.pid==feature('getpid')&&strcmp(B.grant_id,'20261101_PK_30h')&&strcmp(B.start_utc,'2026-11-01T16:29:07Z')&&strcmp(B.research_deadline_utc,'2026-11-02T20:29:07Z')&&strcmp(B.deadline_utc,'2026-11-02T22:29:07Z')&&min(B.deadline_unix_seconds-t.utc,(B.deadline_monotonic_ns-t.mono)/1e9)>602,'PKFinalCold:WholeFit','Full600/60 fresh saved-data/GUI operation must fit the unchanged original HARD finalization clocks.');
finish=struct('utc',t.utc+600,'mono',t.mono+600e9);work=struct('utc',finish.utc-60,'mono',finish.mono-60e9);
refs=[{b.GraphReference;b.GraphClosureReference;b.ManifestReference;b.CoreClosureReference;b.BudgetReference};b.CoreReferences];
for k=1:numel(b.MethodRows),r=b.MethodRows(k);assert(strcmp(which(r.name),r.file),'PKFinalCold:Provider','Use the exact canonical installed GUI/public reader/runtime providers.');refs{end+1,1}=r;end
guard(refs);audit=fullfile(A,'PK30h_20261102_FinalEligibleCoreSet01_FreshReaderGUI01.mat');png=fullfile(A,'PK30h_20261102_FinalEligibleCoreSet01_FreshReaderGUI01.png');fresh({audit;[audit,'.pending.mat'];png});
originalFolder=pwd;originalPath=path;fig=[];h=[];cleanup=onCleanup(@finishGUI);
out=struct('schema','PK30h-final-eligible-cores-fresh-reader-visible-GUI-v1','completed',false,'source_posthash',false,'input_references',{refs},'original_budget',B,'operation_finish',finish,'current_pid',feature('getpid'),'writer_pid',[],'fresh_process_after_writer_verified',false,'fresh_process_cold_reader_verified',false,'same_writer_process_readback_claimed',false,'reader_completed',false,'reader_rows',{{}},'representative_current_P_terminal_heads',{{}},'gui_callbacks_completed',false,'gui_figure_closed',false,'entry_folder','','thin_record_count',0,'hydrated_indices_before',[],'hydrated_indices_after',[],'rendered_physical_edge_count',0,'axes_pixel_bounds',[],'axes_position_verified',false,'folder_dropdown_order_verified',false,'startup_from_pwd_verified',false,'screenshot',struct('requested',true,'returned',false),'failure',struct(),'actual_mouse_or_hover_checked',false,'numerical_replay_performed',false,'Root_ODE_map_replay_classifier_calls',0,'fresh_admission_claimed',false,'source_retirement_authorized',false,'own_process_exit_claimed',false);
try
 check(work);closed=jsondecode(fileread(b.CoreClosureReference.file));
 assert(strcmp(closed.schema,'PK30h-final-working-core-set-external-closure-v1')&&strcmp(closed.manifest_reference.file,b.ManifestReference.file)&&strcmp(closed.manifest_reference.sha256,b.ManifestReference.sha256)&&strcmp(closed.graph_reference.file,b.GraphReference.file)&&strcmp(closed.graph_reference.sha256,b.GraphReference.sha256)&&strcmp(closed.graph_external_closure_reference.file,b.GraphClosureReference.file)&&strcmp(closed.graph_external_closure_reference.sha256,b.GraphClosureReference.sha256)&&closed.process.actual_tool_exit_observed&&closed.process.exit_code==0&&closed.independent_post_guard.all_passed&&closed.all_owned_native_workers_closed,'PKFinalCold:ExportClosure','Require actual successful exporter exit, independent postguards, closed workers and exact manifest/graph joins.');
 writerPID=closed.process.native_pid;validateattributes(writerPID,{'numeric'},{'real','finite','scalar','integer','positive'});assert(feature('getpid')~=writerPID,'PKFinalCold:WriterPID','The public reader/GUI check must run in a genuinely fresh process after the exporter closed.');out.writer_pid=writerPID;
 graphClosed=jsondecode(fileread(b.GraphClosureReference.file));assert(strcmp(graphClosed.schema,'PK30h-eligible-stored-graph-external-closure-v1')&&strcmp(graphClosed.graph_reference.file,b.GraphReference.file)&&strcmp(graphClosed.graph_reference.sha256,b.GraphReference.sha256)&&graphClosed.process.actual_tool_exit_observed&&graphClosed.process.exit_code==0&&graphClosed.independent_post_guard.all_passed,'PKFinalCold:GraphClosure','Bind the actual closed eligible graph.');
 x=load('-mat',b.GraphReference.file,'component_plan','plan_digest');p=x.component_plan;assert(strcmp(C1ScientificDigest_v3(p),x.plan_digest)&&p.completed&&p.source_posthash&&p.active_source_occurrence_bijection_verified,'PKFinalCold:Graph','Use actual immutable current eligible graph records and selectors.');clear x
 x=load('-mat',b.ManifestReference.file,'manifest','manifest_digest');m=x.manifest;assert(strcmp(C1ScientificDigest_v3(m),x.manifest_digest)&&strcmp(m.schema,'PK30h-final-eligible-working-core-set-v1')&&m.completed&&m.source_posthash&&isempty(fieldnames(m.pending_call))&&feature('getpid')~=m.original_budget.capture.pid&&feature('getpid')~=writerPID&&strcmp(m.plan_reference.sha256,b.GraphReference.sha256)&&strcmp(m.graph_external_closure_reference.sha256,b.GraphClosureReference.sha256),'PKFinalCold:Manifest','Use complete actual immutable export results in a separate new native process.');clear x
 componentCount=numel(p.components);assert(m.component_count==componentCount&&numel(m.core_rows)==componentCount&&numel(b.CoreReferences)==componentCount&&m.whole_occurrence_count==numel(p.nodes),'PKFinalCold:Counts','Use all actual dynamic final components and global occurrences.');
 named=closed.core_references;if isstruct(named),named=num2cell(named(:));else,named=named(:);end;assert(numel(named)==componentCount,'PKFinalCold:ClosedCoreCount','The Root closure must name every actual final core.');
 heads=m.representative_current_P_terminal_heads;headGlobals=cellfun(@(r)r.global_index,heads);assert(~isempty(headGlobals),'PKFinalCold:Heads','Preserve actual current-P terminal selectors.');
 for k=1:numel(heads),r=heads{k};n=p.nodes{r.global_index};catalogue=p.source_catalog{n.source_number};assert(n.source_index==r.source_index&&strcmp(n.native_ID,r.native_ID)&&strcmp(catalogue.file,r.reference.file)&&strcmp(catalogue.sha256,r.reference.sha256),'PKFinalCold:HeadSelector','Every current-P terminal must bind its literal graph source/index/NativeID.');end
 out.representative_current_P_terminal_heads=heads;out.fresh_process_after_writer_verified=true;observedGlobals=zeros(0,1);
 for component=1:componentCount
  check(work);r=b.CoreReferences{component};row=m.core_rows{component};selected=p.components{component}.global_indices(:);count=numel(selected);
  assert(strcmp(r.file,row.core_reference.file)&&strcmp(r.sha256,row.core_reference.sha256)&&r.bytes==row.core_reference.bytes&&sum(cellfun(@(q)strcmp(q.file,r.file)&&strcmp(q.sha256,r.sha256)&&q.bytes==r.bytes,named))==1&&row.actual_helper_returned&&row.reader_completed,'PKFinalCold:CoreJoin','Every public cold read must bind one actual successful whole-component export and Root closure header.');same(selected,row.global_indices(:));
  x=load('-mat',r.file,'solution_core29','core_digest');core=x.solution_core29;assert(strcmp(C1ScientificDigest_v3(core),x.core_digest)&&core.point_count==count&&isequal(size(core.solution_matrix),[29,count]),'PKFinalCold:CoreDigest','Verify the exact complete29-row working payload.');clear x
  tests=unique([1;count;find(ismember(selected,headGlobals))],'stable');expected=p.components{component}.planned_materialization_index.metadata.component_graph;
  for index=tests(:).'
   check(work);globalIndex=selected(index);node=p.nodes{globalIndex};[o,report,point,view]=LoadC1WorkingSolutionCore29_v3(r.file,index,r.sha256);
   same([o.initial_state;o.stride_displacement;o.period],core.solution_matrix(:,index));same(o.parameter,core.parameters{index});same(o.initial_mode,core.modes{index});same(o.initial_state(2:14),node.normalized_state(2:14));same(o.stride_displacement(:),node.stride);same(o.period,node.period);same(o.parameter(:),node.parameter);same(o.initial_mode(:),node.initial_mode);
   assert(strcmp(OrbitContentIdentity_v3(o),node.native_ID)&&strcmp(point.native_id,node.native_ID)&&strcmp(core.native_ids{index},node.native_ID)&&point.context.expected_index==index&&point.context.source_index==globalIndex&&strcmp(point.context.source_reference.file,b.GraphReference.file)&&strcmp(point.context.source_reference.sha256,b.GraphReference.sha256)&&strcmp(view.source_reference.sha256,b.GraphReference.sha256)&&view.external_binding_checked&&point.external_binding_checked&&point.requires_fresh_replay&&~point.fresh_admission_claimed&&report.core29_view.saved_decisions_are_historical&&~report.core29_view.fresh_all_nine_admission_claimed&&isempty(o.trajectory),'PKFinalCold:NativeABI','Public fresh reconstruction must preserve exact NativeID/local/global/source context and historical/no-trajectory ABI.');
   fields={'physical_edges','record_equalities','qualified_aliases','numerical_seams'};actual={'original_explicit_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};counts=zeros(1,4);
   for kind=1:4,rows=view.typed_graph.(fields{kind});pairs=zeros(numel(rows),2);for j=1:numel(rows),pairs(j,:)=[rows{j}.from,rows{j}.to];end;same(pairs,expected.(actual{kind}));counts(kind)=size(pairs,1);end
   out.reader_rows{end+1,1}=struct('core_reference',r,'component_number',component,'index',index,'global_index',globalIndex,'point_count',count,'native_ID',point.native_id,'matrix29',core.solution_matrix(:,index),'parameter',o.parameter,'mode',o.initial_mode,'context',point.context,'typed_graph_counts',counts,'is_current_P_terminal',ismember(globalIndex,headGlobals),'graph13_state_and_full_stride_pq_T_literal',true,'raw14_bound_by_exact_core_matrix',true,'NativeID_translation_gauge_normalized',true,'graph_translation_coordinate_differs_after_its_normalization',~strcmp(C1ScientificDigest_v3(o.initial_state(1)),C1ScientificDigest_v3(node.normalized_state(1))));
   observedGlobals(end+1,1)=globalIndex;clear o report point view
  end
  clear core
 end
 assert(all(ismember(headGlobals,observedGlobals)),'PKFinalCold:AllCurrentHeads','The fresh public reader must cover every actual current-P terminal across all final component files.');out.reader_completed=true;out.fresh_process_cold_reader_verified=true;
 guiRef=b.CoreReferences{1};file=guiRef.file;packed=load('-mat',file,'solution_core29','core_digest');core=packed.solution_core29;assert(strcmp(C1ScientificDigest_v3(core),packed.core_digest),'PKFinalCold:GUIInput','Use first actual complete final component without a legacy point-count assumption.');count=core.point_count;clear packed
 cd(fileparts(file));out.entry_folder=pwd;
 [fig,c,h]=SLIP_Quadruped_GUI_v3(struct('Visible','on','StartTimers',false));drawnow;
 assert(strcmp(c.Folder,out.entry_folder)&&strcmp(c.Root,V)&&strcmp(pwd,out.entry_folder), ...
  'PKWorkingGUI:StartupFolder','The cold GUI must start from actual pwd rather than the GUI .m directory.');
 assert(h.SelectFolder.Layout.Column==1&&h.File.Layout.Column==2&&isequal(h.SelectFolder.Parent,h.File.Parent), ...
  'PKWorkingGUI:Layout','Data Info must place Select Folder before the dataset dropdown.');
 out.startup_from_pwd_verified=true;out.folder_dropdown_order_verified=true;
 check(work);h.Callbacks.LoadDataset(file);drawnow;
 assert(numel(c.Datasets)==1&&c.SelectedDataset==1&&c.SelectedIndex==1&&strcmp(c.Datasets(1).source,file), ...
  'PKWorkingGUI:PlotCallback','LoadDataset callback must load and plot the actual working dataset.');
 records=c.Datasets(1).solutions;assert(numel(records)==count,'PKWorkingGUI:ThinCount','Every occurrence must have its own thin display record.');
 hydrated=false(1,count);
 for k=1:count
  r=records{k};p=r.provenance.core29;hydrated(k)=p.hydrated;
  same(r.initial_state,core.solution_matrix(1:14,k));same(r.parameter,core.parameters{k});same(r.initial_mode,core.modes{k});
  assert(strcmp(p.reader,'LoadC1WorkingSolutionCore29_v3')&&strcmp(p.sha256,guiRef.sha256) ...
   &&strcmp(p.native_id,core.native_ids{k})&&~p.fresh_admission_claimed&&p.saved_decisions_are_historical, ...
   'PKWorkingGUI:ThinIdentity','Every thin record must retain exact literal values, identity and explicit working-reader provenance.');
 end
 assert(isequal(find(hydrated),1),'PKWorkingGUI:InitialHydration','Initial GUI acquisition must hydrate only the first selected occurrence.');
 out.thin_record_count=count;out.hydrated_indices_before=find(hydrated);
 first=c.selected();same([first.orbit.initial_state;first.orbit.stride_displacement;first.orbit.period],core.solution_matrix(:,1));
 assert(strcmp(OrbitContentIdentity_v3(first.orbit),core.native_ids{1}),'PKWorkingGUI:InitialNative','First native hydration changed identity.');
 h.Index.Value=count;check(work);h.Callbacks.SelectIndex();drawnow;
 last=c.selected();assert(c.SelectedIndex==count&&strcmp(last.provenance.core29.reader,'LoadC1WorkingSolutionCore29_v3') ...
  &&last.provenance.core29.hydrated&&strcmp(OrbitContentIdentity_v3(last.orbit),core.native_ids{count}), ...
  'PKWorkingGUI:LazySelection','Index callback must hydrate and select the last actual working occurrence.');
 same([last.orbit.initial_state;last.orbit.stride_displacement;last.orbit.period],core.solution_matrix(:,count));
 hydrated=cellfun(@(r)r.provenance.core29.hydrated,c.Datasets(1).solutions);assert(isequal(find(hydrated),[1,count]), ...
  'PKWorkingGUI:LazyCount','Only the two requested occurrences should be hydrated.');out.hydrated_indices_after=find(hydrated);
 out.selected_native_ids={core.native_ids{1};core.native_ids{count}};
 lines=findall(h.StateAxes,'Tag','OrderedContinuationComponent');rendered=zeros(0,2);
 for k=1:numel(lines)
  row=lines(k);indices=row.UserData.indices;
  assert(strcmp(row.LineStyle,'-')&&row.LineWidth==2&&row.UserData.dataset==1&&numel(indices)>=2, ...
   'PKWorkingGUI:Lines','Physical branches must render as declared width-two solid lines.');
  rendered=[rendered;[indices(1:end-1).',indices(2:end).']]; %#ok<AGROW>
 end
 physical=zeros(numel(core.graph.physical_edges),2);
 for k=1:numel(core.graph.physical_edges),e=core.graph.physical_edges{k};physical(k,:)=[e.from,e.to];end
 assert(~isempty(physical)&&isequal(sortrows(rendered),sortrows(physical)),'PKWorkingGUI:TypedLines','Every rendered line edge must equal one saved typedP edge; E/A/M do not create physical display lines.');
 out.rendered_physical_edge_count=size(rendered,1);out.nonphysical_relation_counts=[numel(core.graph.record_equalities),numel(core.graph.qualified_aliases),numel(core.graph.numerical_seams)];
 assert(isgraphics(fig)&&isgraphics(h.StateAxes)&&strcmp(fig.Visible,'on')&&strcmp(h.StateAxes.Visible,'on') ...
  &&strcmp(h.PlotTabs.SelectedTab.Title,'State Plot'),'PKWorkingGUI:StateAxes','The selected visible State Plot must contain a valid visible state axes.');
 drawnow;bounds=getpixelposition(h.StateAxes,true);figureSize=fig.Position(3:4);
 assert(all(isfinite(bounds))&&all(bounds(3:4)>50)&&all(bounds(1:2)>=0) ...
  &&all(bounds(1:2)+bounds(3:4)<=figureSize+2),'PKWorkingGUI:AxesBounds','Native rendered axes bounds must be positive and lie inside this figure.');
 out.axes_pixel_bounds=bounds;out.figure_position=fig.Position;out.axes_position_verified=true;
 try
  check(work);exportapp(fig,png);d=dir(png);assert(isscalar(d)&&d.bytes>0,'PKWorkingGUI:PNG','PNG export returned no bytes.');
  out.screenshot=struct('requested',true,'returned',true,'reference',ref(png,RoundSHA256_v3(png),d.bytes), ...
   'scope','Native visible-uifigure export after actual GUI callbacks; human display visibility and actual pointer/hover actions remain untested.');
 catch captureFailure
  out.screenshot=struct('requested',true,'returned',false,'failure_identifier',captureFailure.identifier,'failure_message',captureFailure.message);
 end
 out.gui_callbacks_completed=true;guard(refs);check(work);out.source_posthash=true;
catch failure
 out.failure=struct('identifier',failure.identifier,'message',failure.message,'report',getReport(failure,'extended','hyperlinks','off'));
end
figureToCheck=fig;finishGUI();out.gui_figure_closed=isempty(figureToCheck)||~isgraphics(figureToCheck);clear figureToCheck cleanup
out.completed=out.reader_completed&&out.fresh_process_after_writer_verified&&out.fresh_process_cold_reader_verified&&out.gui_callbacks_completed&&out.gui_figure_closed&&out.screenshot.returned&&out.source_posthash;
out.scope='Fresh-process public reads of first/last/all actual currentP heads in both final whole cores, then visible native GUI callbacks on first actual component. Matrix29/pq/T/fullstride/NativeID literal checks; graph state2:14 excludes only its explicitly normalized translation coordinate, while exact core matrix29 comparison binds raw14 and NativeID is translation-gauge normalized. No actual pointer/hover, root/ODE/replay/classifier/admission, global completion or retirement claim.';
check(finish);gui_check=out;gui_check_digest=C1ScientificDigest_v3(gui_check);stage=[audit,'.pending.mat'];save(stage,'gui_check','gui_check_digest','-v7');expected=struct('gui_check',gui_check,'gui_check_digest',gui_check_digest);read2(stage,expected);publish(stage,audit);read2(audit,expected);guard(refs);check(finish);
fprintf('PK30H_FINAL_FRESH_READER_GUI_RETURN %s\n',jsonencode(struct('completed',out.completed,'source_posthash',out.source_posthash,'fresh_process_after_writer_verified',out.fresh_process_after_writer_verified,'fresh_process_cold_reader_verified',out.fresh_process_cold_reader_verified,'reader_rows',numel(out.reader_rows),'GUI_records',out.thin_record_count,'GUI_rendered_P',out.rendered_physical_edge_count,'GUI_closed',out.gui_figure_closed,'screenshot',out.screenshot,'audit_reference',ref(audit,RoundSHA256_v3(audit),dirBytes(audit)),'failure',out.failure)));
assert(out.completed,'PKFinalCold:Incomplete','Preserve the exact actual reader/GUI prefix audit and any screenshot.');
 function finishGUI()
  if ~isempty(fig)&&isgraphics(fig),if ~isempty(h)&&isfield(h,'Callbacks'),h.Callbacks.Close();else,delete(fig);end,end
  fig=[];cd(originalFolder);path(originalPath);
 end
end
function r=ref(file,sha,bytes),r=struct('file',file,'sha256',sha,'bytes',bytes);end
function guard(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKWorkingGUI:Guard','An exact immutable input changed: %s',r.file);end,end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'PKWorkingGUI:Fresh','Preserve existing output: %s',paths{k});end,end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKWorkingGUI:TypedEquality','Literal class/shape/raw bits differ.');end
function read2(file,expected),for pass=1:2,x=load('-mat',file);names=fieldnames(expected);assert(isequal(sort(fieldnames(x)),sort(names)),'PKWorkingGUI:Variables','Exact saved variables differ.');for k=1:numel(names),same(x.(names{k}),expected.(names{k}));end;end,end
function publish(stage,file),fresh({file});javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath()),'PKWorkingGUI:Publication','Publish the owned stage only.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());end
function t=clocks(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime()));end
function check(limit),t=clocks();assert(min(limit.utc-t.utc,(limit.mono-t.mono)/1e9)>0,'PKWorkingGUI:Deadline','The unchanged bounded operation deadline elapsed.');end
function n=dirBytes(file),d=dir(file);assert(isscalar(d)&&~d.isdir,'PKFinalEvidence:File','Require one actual saved file.');n=d.bytes;end
