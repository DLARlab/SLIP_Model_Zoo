function result=ColdIntegratePK30hFiniteOverlap20261101(acquireRef,witness,raw03Ref,budget,options)
%COLDINTEGRATEPK30HFINITEOVERLAP20261101 Stored-evidence integration only.
% One fresh generic Consolidate dispatch, then mixed retained generic/GateB
% transport. No Root, map, replay or classifier is invoked. Original proof
% indices stay immutable; occurrence bookkeeping uses actual receipt maps.
    entryUTC=utc();entryMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'OutputAuditFile';'FixtureDirectory'})),'PKCold:Options','Supply only two fresh owned paths.');
    assert(budget.capture.pid==feature('getpid'),'PKCold:Budget','Calibrate the unchanged original grant in this process.');
    finish=limit(min(budget.deadline_unix_seconds,entryUTC+900),min(budget.deadline_monotonic_ns,entryMono+900e9));
    work=limit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=literal(options.OutputAuditFile);stage=[output,'.pending.mat'];folder=literal(options.FixtureDirectory);
    assert(startsWith(output,[literal(fullfile(N,'Audits')),filesep]) ...
        &&startsWith(folder,[literal(fullfile(N,'.work_pk30h_20261101')),filesep]), ...
        'PKCold:Paths','Keep the audit and owned small fixtures in the declared V3 work area.');
    assert(~isfile(output)&&~isfile(stage)&&~isfolder(folder)&&~isfile(folder), ...
        'PKCold:Fresh','Retain any previous output or pending custody.');
    code=providers();verifyAll([code;{acquireRef;raw03Ref}]);
    assert(strcmp(witness.schema,'C1-external-native-process-exit-witness-v1') ...
        &&isequal(witness.actual_process_exit_observed,true)&&witness.exit_code==0 ...
        &&isequal(witness.source_posthash_verified,true)&&isequaln(witness.audit_reference,acquireRef), ...
        'PKCold:ExternalExit','Actual producer exit0/postguards must be supplied externally, not inferred from its own completion.');
    validateattributes(witness.process_session_id,{'numeric'},{'scalar','finite','integer','positive'});
    validateattributes(witness.child_pid,{'numeric'},{'scalar','finite','integer','positive'});
    loaded=load(acquireRef.file,'audit');a=loaded.audit;
    assert(strcmp(a.schema,'C1-finite-owned-PAL-numerical-overlap-experiment-v1') ...
        &&a.completed&&a.source_posthash&&a.ordinary_edge_earned&&a.qualified_numerical_relation, ...
        'PKCold:Acquire','Use one actually closed successful finite experiment.');
    verify(a.run_branch_reference);verify(a.target_reference);
    assert(~strcmp(a.run_branch_reference.file,a.target_reference.file), ...
        'PKCold:Sources','Fresh source branch and literal target authority must be distinct.');
    [ok,message]=mkdir(folder);assert(ok,'PKCold:Directory','%s',message);
    audit=struct('schema','PK30h-finite-overlap-cold-integration-v1','producer_reference',ref(which(mfilename)), ...
        'acquire_reference',acquireRef,'external_execution_witness',witness,'raw03_reference',raw03Ref, ...
        'source_code',{code},'original_budget',budget,'original_finish',finish,'options',options, ...
        'fresh_consolidate_attempted',false,'fresh_consolidate_returned',false,'fresh_receipt',struct(), ...
        'fresh_retained_reference',struct(),'fresh_original_occurrence_map',{{}},'new_evidence',struct(), ...
        'new_retained_validated',false,'old_extraction',struct(),'old_retained_reference',struct(), ...
        'mixed_consolidate_attempted',false,'mixed_consolidate_returned',false,'mixed_receipt',struct(), ...
        'fresh_output_accounting',struct(),'mixed_output_accounting',struct(), ...
        'full_native_record_readback_verified',false,'literal_evidence_transport_verified',false, ...
        'root_calls',0,'map_calls',0,'replay_calls',0,'classifier_calls',0, ...
        'source_posthash',false,'completed',false,'failure',struct(), ...
        'own_process_exit_claimed',false,'new_scientific_edge_created',false, ...
        'scope','Finite stored-evidence qualification/transport only. Physical edges, exact equalities, aliases and numerical links retain separate meanings.', ...
        'provider_test_scope','Fresh generic qualification and inherited generic+old GateB transport; not the two-provider array for simultaneous explicit fresh old+new proof requests.');
    inputs={acquireRef;raw03Ref;a.run_branch_reference;a.target_reference};
    try
        check(work);
        left=selector(a.run_branch_reference,3,a.candidate_native_id);
        right=selector(a.target_reference,a.target_index,a.target_native_id);
        proof=struct('schema','C1-finite-owned-PAL-numerical-overlap-proof-v1','audit_reference',acquireRef, ...
            'execution_witness',witness,'left_selector',left,'right_selector',right,'validation_limits',work);
        request=struct('left_file',left.file,'left_index',left.index, ...
            'right_file',right.file,'right_index',right.index,'proof',proof);
        freshDirectory=fullfile(folder,'Fresh');freshReceiptFile=fullfile(folder,'Fresh_Receipt.mat');
        co=consolidateOptions(work);co.NumericalOverlapPairs={request};
        fprintf('PK_COLD_BEFORE_FRESH_CONSOLIDATE\n');audit.fresh_consolidate_attempted=true;
        fresh=ConsolidateC1ConnectedComponents_v3({a.run_branch_reference.file;a.target_reference.file}, ...
            freshDirectory,freshReceiptFile,co);
        audit.fresh_consolidate_returned=true;audit.fresh_receipt=fresh;checkpoint(stage,audit);
        fprintf('PK_COLD_AFTER_FRESH_CONSOLIDATE\n');
        assertReceipt(fresh);verifyProvider(fresh);
        audit.fresh_output_accounting=verifyTransport(fresh,work);
        maps={mapped(fresh,a.run_branch_reference,2);mapped(fresh,a.run_branch_reference,3); ...
            mapped(fresh,a.target_reference,a.target_index)};
        assert(strcmp(maps{1}.target_file,maps{2}.target_file)&&strcmp(maps{2}.target_file,maps{3}.target_file) ...
            &&numel(unique(cellfun(@(m)m.target_index,maps)))==3, ...
            'PKCold:NewComponent','The actual parent, left and target must be three occurrences of one retained component.');
        newRef=ref(maps{1}.target_file);ix=BranchSolutionFile_v3.index(newRef.file);
        audit.fresh_retained_reference=newRef;audit.fresh_original_occurrence_map=maps;
        audit.fresh_retained_point_count=numel(ix.points);checkpoint(stage,audit);
        assert(numel(ix.points)==3,'PKCold:UnexpectedEquality','Retain/report all actual fresh outputs; do not prune an unexpected extra connected occurrence to force a three-record fixture.');
        selected=cellfun(@(m)m.target_index,maps);[o,r]=BranchSolutionFile_v3.loadSolutions(newRef.file,selected);
        incoming=find(cellfun(@(e)e.to==selected(2),ix.edges));
        assert(isscalar(incoming)&&ix.edges{incoming}.from==selected(1), ...
            'PKCold:NewPhysical','The actual retained parent must reach the left occurrence by its physical edge.');
        g=ix.metadata.component_graph;at=find(g.qualified_numerical_overlaps(:,1)==selected(2) ...
            &g.qualified_numerical_overlaps(:,2)==selected(3));
        assert(isscalar(at),'PKCold:NewNumerical','Locate the actual oriented qualified numerical row.');
        e=g.numerical_overlap_evidence{at};audit.new_evidence=e;checkpoint(stage,audit);
        C1FiniteNumericalOverlap_v3.validateRetained(e,o{2},o{3},r{2},r{3},o{1});
        audit.new_retained_validated=true;
        [oldRef,extraction]=extractOld(raw03Ref,fullfile(folder,'Old_GateB_Retained3.mat'),work);
        audit.old_extraction=extraction;audit.old_retained_reference=oldRef;checkpoint(stage,audit);
        inputs=[inputs;{newRef;oldRef;ref(freshReceiptFile)}];
        mixedDirectory=fullfile(folder,'Mixed');mixedReceiptFile=fullfile(folder,'Mixed_Receipt.mat');
        fprintf('PK_COLD_BEFORE_MIXED_CONSOLIDATE\n');audit.mixed_consolidate_attempted=true;
        mixed=ConsolidateC1ConnectedComponents_v3({newRef.file;oldRef.file},mixedDirectory,mixedReceiptFile,consolidateOptions(work));
        audit.mixed_consolidate_returned=true;audit.mixed_receipt=mixed;checkpoint(stage,audit);
        fprintf('PK_COLD_AFTER_MIXED_CONSOLIDATE\n');
        assertReceipt(mixed);verifyProvider(mixed);audit.mixed_output_accounting=verifyTransport(mixed,work);
        assert(mixed.stored_occurrences==6&&mixed.original_explicit_edges==2 ...
            &&mixed.qualified_numerical_overlaps==2&&mixed.qualified_record_aliases==0, ...
            'PKCold:MixedCounts','Two retained three-record inputs must preserve two separate physical and two numerical rows.');
        mn={mapped(mixed,newRef,selected(1));mapped(mixed,newRef,selected(2));mapped(mixed,newRef,selected(3))};
        mo={mapped(mixed,oldRef,1);mapped(mixed,oldRef,2);mapped(mixed,oldRef,3)};
        actualNew=retainedEvidence(mn,work);actualOld=retainedEvidence(mo,work);
        same(e,actualNew);same(extraction.original_evidence,actualOld);
        [no,nr]=BranchSolutionFile_v3.loadSolutions(mn{1}.target_file,cellfun(@(m)m.target_index,mn));
        C1FiniteNumericalOverlap_v3.validateRetained(actualNew,no{2},no{3},nr{2},nr{3},no{1});
        audit.literal_evidence_transport_verified=true;audit.full_native_record_readback_verified=true;
        inputs{end+1,1}=ref(mixedReceiptFile);verifyAll([code;inputs]);
        audit.source_posthash=true;audit.completed=true;
    catch problem
        audit.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);
    end
    checkpoint(stage,audit);check(finish);
    assert(audit.completed&&audit.source_posthash,'PKCold:Incomplete','Retain the native pending audit and all small fixtures: %s',jsonencode(audit.failure));
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    back=load(output,'audit');same(audit,back.audit);delete(stage);check(finish);
    result=struct('completed',audit.completed,'source_posthash',audit.source_posthash,'audit_reference',ref(output), ...
        'fresh_retained_reference',audit.fresh_retained_reference,'old_retained_reference',audit.old_retained_reference, ...
        'fresh_graph_counts',audit.fresh_output_accounting,'mixed_graph_counts',audit.mixed_output_accounting, ...
        'fresh_qualifier_provider_count',numel(audit.fresh_receipt.numerical_overlap_qualification_source), ...
        'mixed_qualifier_provider_count',numel(audit.mixed_receipt.numerical_overlap_qualification_source), ...
        'root_map_replay_classifier_calls',0,'own_process_exit_claimed',false);
    fprintf('PK_COLD_FINITE_INTEGRATION_RETURN %s\n',jsonencode(result));
end

function [out,receipt]=extractOld(source,file,clock)
    check(clock);verify(source);ix=BranchSolutionFile_v3.index(source.file);g=ix.metadata.component_graph;
    assert(size(g.qualified_numerical_overlaps,1)==1&&numel(g.numerical_overlap_evidence)==1, ...
        'PKCold:OldRow','The actual frozen Raw03 graph must identify its one retained old numerical row.');
    pair=g.qualified_numerical_overlaps(1,:);e=g.numerical_overlap_evidence{1};
    assert(strcmp(e.schema,'C1-qualified-PK-numerical-overlap-v1'),'PKCold:OldSchema','Keep the actual old GateB retained contract.');
    incoming=find(cellfun(@(x)x.to==pair(1),ix.edges));assert(isscalar(incoming),'PKCold:OldParent','Use one actual incoming physical edge.');
    edge=ix.edges{incoming};indices=[edge.from,pair];assert(numel(unique(indices))==3, ...
        'PKCold:OldOccurrences','The actual parent/left/right must be distinct source occurrences.');
    assert(strcmp(ix.points{edge.from}.component_identity,ix.points{pair(1)}.component_identity), ...
        'PKCold:OldOwner','The actual physical predecessor shares its original left owner.');
    [o,r,m]=BranchSolutionFile_v3.loadSolutions(source.file,indices);
    ids=cellfun(@OrbitContentIdentity_v3,o,'UniformOutput',false);
    assert(strcmp(ids{1},e.earned_physical_edge.from_native_ID)&&strcmp(ids{2},e.left_native_ID) ...
        &&strcmp(ids{3},e.right_native_ID),'PKCold:OldIDs','Actual selected NativeIDs must bind the immutable old evidence.');
    points=cell(3,1);owner='PK30h_Cold_OldGateB_PhysicalChain';
    for k=1:3
        % A fresh unmarked bookkeeping envelope avoids pretending a changed
        % provenance is the strict known consolidation/import envelope.
        points{k}=struct('component_identity',owner,'classification',m{k}.classification, ...
            'nativeE',m{k}.nativeE,'signedmeanU',m{k}.signedmeanU,'order',k,'edge_enabled',k==2, ...
            'provenance',struct('kind','cold historical retained-record extraction', ...
                'source_reference',source,'source_index',indices(k),'source_index_order',ix.points{indices(k)}.order, ...
                'original_point_metadata',m{k},'native_id',ids{k},'scientific_flags_changed',false));
        if k==2,points{k}.edge_from=1;end
    end
    graphFragment=struct('qualified_numerical_overlaps',[2,3],'numerical_overlap_evidence',{{e}});
    BranchSolutionFile_v3.initialize(file,struct('schema','PK30h-cold-retained-three-record-extraction-v1', ...
        'source_reference',source,'component_graph',graphFragment, ...
        'graph_scope','Numerical-evidence fragment for the existing Consolidate intake, not a complete component_graph schema; physical edge is native index1-to2.', ...
        'new_scientific_edge_created',false));
    BranchSolutionFile_v3.appendBatch(file,o,r,points);
    for pass=1:2
        [back,br,bm]=BranchSolutionFile_v3.loadSolutions(file,1:3);
        for k=1:3
            same(public(o{k}),public(back{k}));same(r{k},br{k});same(points{k},bm{k});
            same(m{k},bm{k}.provenance.original_point_metadata);
            assert(strcmp(OrbitContentIdentity_v3(back{k}),ids{k}),'PKCold:OldRead2','Actual full record identity differs.');
            samePolicy(r{k},br{k});
        end
    end
    newIndex=BranchSolutionFile_v3.index(file);
    assert(numel(newIndex.edges)==1&&newIndex.edges{1}.from==1&&newIndex.edges{1}.to==2 ...
        &&~points{1}.edge_enabled&&~points{3}.edge_enabled,'PKCold:OldEdges','Only the actual original P edge is remapped1-to2.');
    same(e,newIndex.metadata.component_graph.numerical_overlap_evidence{1});verify(source);out=ref(file);
    receipt=struct('source_reference',source,'source_indices',indices,'target_reference',out,'target_indices',[1,2,3], ...
        'source_physical_edge',edge,'target_physical_edge',[1,2],'source_numerical_row',pair,'target_numerical_row',[2,3], ...
        'native_ids',{ids},'original_metadata',{m},'original_evidence',e,'native_read_passes',2, ...
        'full_native_records_reports_policies_preserved',true,'bookkeeping_only_transport',true, ...
        'metadata_transport_scope','Fresh unmarked owner/order/predecessor envelope. Every original point metadata field/class/shape/value is retained literally in original_point_metadata and this extraction receipt; no same-level layout equality is claimed.', ...
        'original_proof_indices_unchanged',true,'old_raw_audit_reopened',false,'fresh_admission_claimed',false);
    check(clock);
end

function summary=verifyTransport(receipt,clock)
    assertReceipt(receipt);maps=receipt.occurrence_map;expected=0;destinationKeys=cell(numel(maps),1);
    for k=1:numel(receipt.source_catalog)
        check(clock);source=receipt.source_catalog{k};expected=expected+source.stored_points;
        r=struct('file',source.file,'sha256',source.sha256);verify(r);
        count=source.stored_points;[o,reports,metadata]=BranchSolutionFile_v3.loadSolutions(source.file,1:count);
        assert(source.source_public_readback_verified,'PKCold:SourceReadback','The public producer must confirm its native source readback.');
        for n=1:count
            m=mapped(receipt,r,n);row=find(cellfun(@(x)isequaln(x,m),maps));assert(isscalar(row),'PKCold:Bijection','Duplicate source occurrence mapping.');
            destinationKeys{row}=sprintf('%s#%d',m.target_file,m.target_index);
        end
        targets=unique(cellfun(@(x)x.target_file,maps,'UniformOutput',false));
        for t=1:numel(targets)
            selected=find(cellfun(@(m)strcmp(m.source_file,source.file)&&strcmp(m.source_sha256,source.sha256) ...
                &&strcmp(m.target_file,targets{t}),maps));
            if isempty(selected),continue;end
            to=cellfun(@(m)m.target_index,maps(selected));
            outputIndex=BranchSolutionFile_v3.index(targets{t});owners=outputIndex.metadata.source_owner_map;
            for pass=1:2
                [back,br,bm]=BranchSolutionFile_v3.loadSolutions(targets{t},to);
                for n=1:numel(selected)
                    original=maps{selected(n)}.source_index;
                    same(public(o{original}),public(back{n}));same(reports{original},br{n});samePolicy(reports{original},br{n});
                    assert(strcmp(OrbitContentIdentity_v3(o{original}),OrbitContentIdentity_v3(back{n})), ...
                        'PKCold:OutputIDs','Every actual output retains its original NativeID.');
                    same(metadata{original},source.point_metadata{original});
                    p=bm{n}.provenance;
                    assert(strcmp(p.source_file,source.file)&&strcmp(p.source_sha256,source.sha256) ...
                        &&p.source_index==original&&strcmp(p.source_catalog_file,receipt.receipt_file) ...
                        &&p.source_catalog_entry==k&&bm{n}.order==to(n) ...
                        &&strcmp(bm{n}.component_identity,outputIndex.points{to(n)}.component_identity), ...
                        'PKCold:OutputProvenance','Actual output bookkeeping must bind its exact source/catalogue occurrence.');
                    owner=find(cellfun(@(x)x.source_number==k ...
                        &&strcmp(x.source_component_identity,metadata{original}.component_identity) ...
                        &&strcmp(x.output_component_identity,bm{n}.component_identity),owners));
                    assert(isscalar(owner),'PKCold:OutputOwner','The immediate source owner must map uniquely to the actual output owner.');
                    % original_point_metadata may have been flattened once;
                    % the immediate catalogue, not that older snapshot, binds
                    % this transport's source owner and original metadata.
                end
            end
        end
    end
    assert(expected==numel(maps)&&numel(unique(destinationKeys))==expected ...
        &&all(~cellfun(@isempty,destinationKeys)),'PKCold:Bijection','Every original occurrence maps once to one unique output occurrence.');
    rows=receipt.component_files;assert(isempty(fieldnames(receipt.isolated_records_file)), ...
        'PKCold:Catalogue','PackIsolatedRecords=false retains every true isolated component as its own output.');
    counts=zeros(1,4);components=zeros(1,4);points=0;
    for k=1:numel(rows)
        check(clock);row=rows{k};verify(struct('file',row.file,'sha256',row.sha256));ix=BranchSolutionFile_v3.index(row.file);
        g=ix.metadata.component_graph;n=numel(ix.points);P=zeros(numel(ix.edges),2);
        for t=1:numel(ix.edges),P(t,:)=[ix.edges{t}.from,ix.edges{t}.to];end
        E=g.exact_record_equalities;A=g.qualified_record_aliases;M=g.qualified_numerical_overlaps;
        counts=counts+[size(P,1),size(E,1),size(A,1),size(M,1)];points=points+n;
        layers={P;[P;E];[P;E;A];[P;E;A;M]};
        for level=1:4,x=layers{level};bins=conncomp(graph(x(:,1),x(:,2),[],n));components(level)=components(level)+max(bins);end
        assert(~g.numerical_adjacencies_are_identity_quotients&&~g.numerical_adjacencies_are_physical_edges, ...
            'PKCold:Semantics','A numerical adjacency is neither physical nor an identity quotient.');
    end
    assert(points==expected&&counts(1)==receipt.original_explicit_edges&&counts(2)==receipt.exact_record_equalities ...
        &&counts(3)==receipt.qualified_record_aliases&&counts(4)==receipt.qualified_numerical_overlaps ...
        &&components(4)==receipt.connected_components,'PKCold:GraphCounts','Actual output typed graphs and receipt disagree.');
    summary=struct('occurrences',points,'P_E_A_M_counts',counts,'physical_physicalExact_physicalExactAlias_all_component_counts',components, ...
        'output_files',numel(rows),'source_occurrence_bijection_verified',true,'independent_public_read_passes',2, ...
        'scope','Undirected stored connectivity per typed layer; no reverse Run authorization, pairwise identity, physical/global endpoint or analytic bifurcation claim.');
end
function e=retainedEvidence(maps,clock)
    check(clock);assert(strcmp(maps{1}.target_file,maps{2}.target_file)&&strcmp(maps{2}.target_file,maps{3}.target_file), ...
        'PKCold:RetainedComponent','The actual parent/left/right stay together.');
    ix=BranchSolutionFile_v3.index(maps{1}.target_file);p=cellfun(@(m)m.target_index,maps);
    incoming=find(cellfun(@(x)x.to==p(2),ix.edges));
    assert(isscalar(incoming)&&ix.edges{incoming}.from==p(1),'PKCold:RetainedPhysical','Retain the actual physical predecessor.');
    g=ix.metadata.component_graph;at=find(g.qualified_numerical_overlaps(:,1)==p(2)&g.qualified_numerical_overlaps(:,2)==p(3));
    assert(isscalar(at),'PKCold:RetainedNumerical','Retain one oriented numerical evidence row.');e=g.numerical_overlap_evidence{at};
end
function m=mapped(receipt,source,index)
    at=find(cellfun(@(m)strcmp(m.source_file,source.file)&&strcmp(m.source_sha256,source.sha256) ...
        &&m.source_index==index,receipt.occurrence_map));assert(isscalar(at),'PKCold:Occurrence','Bind exactly one original file/SHA/index occurrence.');m=receipt.occurrence_map{at};
end
function assertReceipt(r)
    assert(strcmp(r.schema,'C1-connected-component-consolidation-v1')&&r.completed ...
        &&r.source_public_readback_verified&&r.source_hashes_verified_after_work&&isempty(fieldnames(r.failure)) ...
        &&r.new_root_solves==0&&r.new_integrations==0&&r.new_classifications==0&&r.source_files_deleted==0 ...
        &&~r.qualification_flags_changed,'PKCold:Receipt','The actual completed zero-service public receipt is required.');
end
function verifyProvider(r)
    p=r.numerical_overlap_qualification_source;
    assert(isstruct(p)&&isscalar(p)&&strcmp(p.file,which('C1FiniteNumericalOverlap_v3')) ...
        &&strcmp(p.sha256,RoundSHA256_v3(p.file)),'PKCold:Provider','This fresh/inherited generic path has exactly one external generic qualifier provider; old GateB validation is local.');
end
function o=consolidateOptions(clock)
    check(clock);o=struct('Budget',clock,'MaxWallSeconds',min(clock.deadline_unix_seconds-utc(), ...
        (clock.deadline_monotonic_ns-nano())/1e9),'PackIsolatedRecords',false,'ResumeReceipt',false);
end
function checkpoint(file,audit)
    save(file,'audit','-v7');back=load(file,'audit');same(audit,back.audit);
end
function samePolicy(a,b)
    [~,x]=RecordedReturnPolicy_v3(a);[~,y]=RecordedReturnPolicy_v3(b);
    assert(x.complete&&y.complete,'PKCold:Policy','Actual recorded policies must be complete.');same(x.configuration,y.configuration);
end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKCold:TypedReadback','Complete declared typed values differ.');end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
function refs=providers()
    names={'ColdIntegratePK30hFiniteOverlap20261101','ConsolidateC1ConnectedComponents_v3', ...
        'C1FiniteNumericalOverlap_v3','AcquireC1NumericalOverlap_v3','BranchSolutionFile_v3', ...
        'HybridOrbit_v3','Trajectory_v3','OrbitContentIdentity_v3','RecordedReturnPolicy_v3', ...
        'MatchingReturnSection_v3','QuadrupedEnergy_v3','QuadrupedSchema_v3','GaitSemanticTable_v3', ...
        'C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cell(numel(names),1);for k=1:numel(names),refs{k}=ref(which(names{k}));end
    refs{end+1,1}=ref(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function s=selector(r,index,id),s=struct('file',r.file,'sha256',r.sha256,'index',index,'native_ID',id);end
function verifyAll(refs),for k=1:numel(refs),verify(refs{k});end,end
function verify(r),assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKCold:Source','Immutable literal source changed.');end
function r=ref(file),r=struct('file',literal(file),'sha256',RoundSHA256_v3(file));end
function p=literal(file)
    p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())), ...
        'PKCold:Path','Hash and native reads must address the same literal file.');
end
function l=limit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKCold:Clock','The original900/60 cold integration clock expired.');end
function v=utc(),v=posixtime(datetime('now','TimeZone','UTC'));end
function v=nano(),v=double(java.lang.System.nanoTime());end
