function result=ScoutPK30h0061FlightStationarity20261102(B,bindings,options)
% Fixed literal states only: bracket/fzero roots of swing clearance rates.
% No ODE, Flow, Guard, Map, projection, saved-state correction or admission.
    entered=struct('u',sfUTC(),'m',sfNano());
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&all(isfield(bindings, ...
        {'AuditReference','BudgetReference','CallerReference','SourceReferences'})) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort( ...
        {'OutputFile';'MaxWallSeconds';'SaveMarginSeconds';'GridIntervals';'RootTolX'; ...
        'RootResidualTolerance';'RootDedupSeconds';'BoundaryExclusionSeconds';'MaxRootIterations';'MaxRootEvaluations'})), ...
        'PKStationary:Inputs','Supply explicit immutable sources, fixed scan and local window.');
    assert(isequal(options.MaxWallSeconds,300)&&isequal(options.SaveMarginSeconds,60) ...
        &&B.capture.pid==feature('getpid')&&strcmp(B.grant_id,'20261101_PK_30h') ...
        &&strcmp(B.research_deadline_utc,'2026-11-02T20:29:07Z')&&strcmp(B.deadline_utc,'2026-11-02T22:29:07Z'), ...
        'PKStationary:Grant','Only the original fixed science/final epochs and local300/60 are authorized.');
    validateattributes(options.GridIntervals,{'double'},{'scalar','integer','>=',2,'<=',16384});
    for key={'RootTolX','RootResidualTolerance','RootDedupSeconds','BoundaryExclusionSeconds'}
        validateattributes(options.(key{1}),{'double'},{'real','finite','positive','scalar'});
    end
    for key={'MaxRootIterations','MaxRootEvaluations'}
        validateattributes(options.(key{1}),{'double'},{'scalar','integer','positive','<=',1000});
    end
    assert(B.research_deadline_unix_seconds-entered.u>302&&(B.research_deadline_monotonic_ns-entered.m)/1e9>302, ...
        'PKStationary:WholeFit','The entire original300/60 local window must fit after preflight.');
    finish=struct('u',entered.u+300,'m',entered.m+300e9);work=struct('u',finish.u-60,'m',finish.m-60e9);
    refs=[{bindings.AuditReference;bindings.BudgetReference;bindings.CallerReference};bindings.SourceReferences(:)];sfVerify(refs);
    assert(strcmp(bindings.AuditReference.sha256,'ec1254c0c03d0f02b42ad3c83a94725e8d823692a44c50af01f4493433bb8548') ...
        &&bindings.AuditReference.bytes==522366&&strcmp(bindings.BudgetReference.sha256, ...
        '38459ef421412b12dab9eb27afc39c8a77582bebf0ae44bbe25d3f9328c14fb2'), ...
        'PKStationary:Authorities','Only the exact closed native saved-HIGH audit and original plan are consumed.');
    output=sfLiteral(options.OutputFile);[folder,name]=fileparts(output);jsonFile=fullfile(folder,[name,'.json']);
    stage=[output,'.pending.mat'];jsonStage=[jsonFile,'.pending.json'];
    paths={output;jsonFile;stage;jsonStage};assert(isfolder(folder)&&all(cellfun(@(f)~isfile(f)&&~isfolder(f),paths)), ...
        'PKStationary:Fresh','Keep prior outputs/stages; refuse unchanged-path retries.');
    a=load(bindings.AuditReference.file,'audit','audit_digest');b=load(bindings.AuditReference.file,'audit','audit_digest');
    assert(strcmp(a.audit_digest,b.audit_digest)&&strcmp(C1ScientificDigest_v3(a.audit),a.audit_digest) ...
        &&strcmp(C1ScientificDigest_v3(b.audit),b.audit_digest),'PKStationary:InputRead2','Two native input reads must verify the scientific digest.');
    saved=a.audit;clear a b
    assert(strcmp(saved.schema,'PK30h-0061-high-saved-geometry-v1')&&saved.completed&&saved.source_posthash ...
        &&isequal(saved.head_indices,[5,6])&&numel(saved.selected_native_records)==5&&numel(saved.runs)==2, ...
        'PKStationary:SavedScope','Require the actual complete retained two-run HIGH audit.');
    counts=cellfun(@(r)numel(r.attempts),saved.runs);assert(isequal(counts(:),[10;1]),'PKStationary:Attempts','Retain all10current+1pilot attempts.');
    audit=struct('schema','PK30h-0061-fixed-flight-stationarity-v1','completed',false,'source_posthash',false, ...
        'input_native_digest',savedDigest(saved),'bindings',bindings,'original_budget',B,'options',options, ...
        'matlab_version',version,'local_finish',finish,'input_native_reads_verified',2,'cases',{{}},'failure',struct(), ...
        'flow_ODE_Guard_Map_replay_admission_calls',0,'saved_state_corrections',0,'optimizer_calls',0, ...
        'new_admission_claimed',false,'physical_endpoint_claimed',false,'continuous_nonpenetration_certificate_claimed',false, ...
        'own_process_exit_claimed',false,'scope','Fixed literal accepted heads5/6 and all11 retained converged phase candidates; first/final open flights only.');
    cases=cell(0,1);s=QuadrupedSchema_v3.shared();
    try
        for k=1:numel(saved.selected_native_records)
            r=saved.selected_native_records{k};if ~ismember(r.index,[5,6]),continue;end
            sfCheck(work);c=struct('kind','literal-accepted-native-head','locator',sprintf('audit.selected_native_records{%d}',k), ...
                'native_index',r.index,'native_id',r.native_id,'saved_settings',r.report_settings,'flights',{{}},'failure',struct());
            try
                e=cellfun(@(v)v.values,r.events,'UniformOutput',false);ids=cellfun(@(v)v.guard_id,e);times=cellfun(@(v)v.time,e);
                assert(numel(e)==8&&isequal(sort(ids(:)),(1:8).')&&all(isfinite(times)), ...
                    'PKStationary:Events','Require the literal complete native8-event PK history.');
                td=find(ismember(ids,s.Event.IDs(s.Event.IsTouchdown)));lo=find(ismember(ids,s.Event.IDs(~s.Event.IsTouchdown)));
                [~,j]=sort(times(td));tdFirst=td(j(1));[~,j]=sort(times(lo));loLast=lo(j(end));
                t0=r.saved_cluster_report.initial_time;assert(isscalar(t0)&&isfinite(t0)&&r.period>0&&times(tdFirst)>t0 ...
                    &&times(loLast)>times(tdFirst)&&times(loLast)<t0+r.period,'PKStationary:NativeTimes','Use saved initial_time, event times and period, never a reconstructed time origin.');
                first=sfFlight(r.state14,r.mode,r.parameter,t0,times(tdFirst)-t0,e{tdFirst}.state_before, ...
                    'initial-flight','native.state14 -> first saved TD_pre',options,work,s);
                last=sfFlight(e{loLast}.state_after,e{loLast}.mode_after,r.parameter,times(loLast), ...
                    t0+r.period-times(loLast),[],'final-flight','last saved LO+ -> saved initial_time+period; terminal raw state not retained',options,work,s);
                c.saved_TD_event=e{tdFirst};c.saved_LO_event=e{loLast};c.flights={first;last};
            catch problem,c.failure=sfFailure(problem);end
            cases{end+1,1}=c; %#ok<AGROW>
        end
        for run=1:numel(saved.runs)
            rows=saved.runs{run}.attempts;
            for k=1:numel(rows)
                sfCheck(work);r=rows{k};c=struct('kind','literal-converged-forced-phase-candidate', ...
                    'locator',sprintf('audit.runs{%d}.attempts{%d}',run,k),'run_locator',saved.runs{run}.locator, ...
                    'attempt_ordinal',r.attempt_ordinal,'literal_attempt',r.literal_attempt,'phase_root',r.phase_root,'flights',{{}},'failure',struct());
                try
                    root=r.phase_root.values;v=r.saved_phase_evaluation.values;p=r.actual_saved_source_record.parameter;
                    assert(isfield(root,'converged')&&isequal(root.converged,true)&&v.acquisition_evaluation_completed, ...
                        'PKStationary:Converged','Only literally retained converged and evaluated phase candidates are scanned.');
                    X=v.phase_endpoint_states;tau=v.phase_durations;
                    assert(isa(X,'double')&&isreal(X)&&isequal(size(X),[14,6])&&all(isfinite(X(:))) ...
                        &&isa(tau,'double')&&numel(tau)==3&&all(isfinite(tau))&&all(tau>0) ...
                        &&iscell(v.phase_geometry)&&numel(v.phase_geometry)==3,'PKStationary:PhaseShape','Require the literal six saved columns and all three local durations.');
                    tau=tau(:);g1=v.phase_geometry{1};g3=v.phase_geometry{3};
                    assert(isequal(g1.time_interval,[0,tau(1)])&&isequal(g3.time_interval,[sum(tau(1:2)),sum(tau)]), ...
                        'PKStationary:PhaseTimes','Saved geometry intervals must bind the exact producer phase-duration coordinates.');
                    first=sfFlight(X(:,1),g1.mode,p,g1.time_interval(1),tau(1),X(:,2), ...
                        'initial-flight','phase_endpoint_states(:,1) -> (:,2)',options,work,s);
                    last=sfFlight(X(:,5),g3.mode,p,g3.time_interval(1),tau(3),X(:,6), ...
                        'final-flight','actual saved LO+ phase_endpoint_states(:,5) -> (:,6)',options,work,s);
                    c.saved_phase_evaluation=r.saved_phase_evaluation;c.flights={first;last};
                catch problem,c.failure=sfFailure(problem);end
                cases{end+1,1}=c; %#ok<AGROW>
            end
        end
        audit.cases=cases;assert(numel(cases)==13,'PKStationary:CaseCount','Exactly2accepted heads and11phase candidates must be represented.');
        sfVerify(refs);sfCheck(work);audit.source_posthash=true;audit.completed=true;
    catch problem,audit.cases=cases;audit.failure=sfFailure(problem);end
    audit.elapsed_seconds=(sfNano()-entered.m)/1e9;
    audit.coverage_limitations={'Finite grid finds sign-changing rate roots and literal exact grid zeros only.'; ...
        'Even-multiplicity rate roots between grid points, two roots in one cell, near-zero nonzero grid values and roots within the declared boundary exclusion can be missed.'; ...
        'No continuous inequality certificate, endpoint solve, continuation boundary, historical false-admission or fresh admission is established.'; ...
        'Stored endpoint facts and algebraically propagated endpoint values stay distinct; the input native MAT is numeric authority.'};
    audit.json_scope='Secondary plain metadata; native MAT scientific digest binds raw numeric classes, shapes and bits.';
    audit_digest=C1ScientificDigest_v3(audit);save(stage,'audit','audit_digest','-v7');sfRead2(stage,audit_digest);
    fid=fopen(jsonStage,'w');assert(fid>=0,'PKStationary:JSONOpen','Create only the fresh owned JSON stage.');
    fwrite(fid,unicode2native(jsonencode(audit),'UTF-8'),'uint8');assert(fclose(fid)==0,'PKStationary:JSONClose','Retain partial metadata on write/close failure.');
    sfVerify(refs);sfCheck(finish);
    for pair={{stage,output},{jsonStage,jsonFile}}
        files=pair{1};sha=RoundSHA256_v3(files{1});javaMethod('createLink','java.nio.file.Files',java.io.File(files{2}).toPath(),java.io.File(files{1}).toPath());
        assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(files{2}).toPath(),java.io.File(files{1}).toPath()) ...
            &&strcmp(RoundSHA256_v3(files{1}),sha),'PKStationary:Publication','Only an unchanged linked own stage may be removed.');
        javaMethod('delete','java.nio.file.Files',java.io.File(files{1}).toPath());
    end
    sfRead2(output,audit_digest);sfVerify(refs);sfCheck(finish);
    result=struct('completed',audit.completed,'source_posthash',audit.source_posthash,'audit_reference',sfRef(output), ...
        'json_reference',sfRef(jsonFile),'case_count',numel(cases),'failure',audit.failure,'own_process_exit_claimed',false);
    fprintf('PK30H_FLIGHT_STATIONARITY_RETURN %s\n',jsonencode(result));
end

function out=sfFlight(x,q,p,t0,T,storedEnd,label,locator,o,limit,s)
    out=struct('label',label,'literal_locator',locator,'literal_start_state14',x,'literal_mode',q,'literal_parameter',p, ...
        'absolute_start_time',t0,'local_duration',T,'stored_end_state14',storedEnd,'status','UNASSESSED_PRECONDITIONS', ...
        'precondition_failure',struct(),'legs',{{}},'endpoint_facts',struct());
    try
        assert(isa(x,'double')&&isreal(x)&&~issparse(x)&&isequal(size(x),[14,1])&&all(isfinite(x)) ...
            &&isa(p,'double')&&isreal(p)&&~issparse(p)&&isequal(size(p),[10,1]),'PKStationary:LiteralShape','Require unchanged raw double column state/parameter.');
        s.validateState(x);s.validateParameter(p);s.validateMode(q);a=s.expandParameters(p);
        assert(isequal(size(q),[4,1])&&~any(q)&&x(s.State.dphi)==0&&all(a.k_s>0) ...
            &&all(isfinite(sqrt(a.k_s./a.l_0.^2)))&&isscalar(t0)&&isfinite(t0)&&isscalar(T)&&isfinite(T)&&T>2*o.BoundaryExclusionSeconds, ...
            'PKStationary:ExactFlight','Require literal all-flight, exact dphi=0, positive per-leg ks/L and a nonempty open interval; no snap or rotating approximation.');
        out.status='EXACT_ALGEBRA_PRECONDITIONS_VALIDATED';
        out.exact_constant_phi=x(s.State.phi);out.per_leg_rest_angles=a.rsla;out.per_leg_lengths=a.l_0;out.per_leg_ks=a.k_s;
        pi=s.Parameter;
        out.common_PK_annotation=struct('upright',x(s.State.phi)==0,'centered_COM',p(s.Parameter.l_com)==.5, ...
            'literal_common_parameters',isequal(p([pi.k_l_b,pi.k_s_b,pi.l_l_b,pi.rsla_b]),p([pi.k_l_f,pi.k_s_f,pi.l_l_f,pi.rsla_f])), ...
            'literal_common_angles',all(x(s.Leg.AngleIndices)==x(s.Leg.AngleIndices(1))), ...
            'literal_common_rates',all(x(s.Leg.RateIndices)==x(s.Leg.RateIndices(1))), ...
            'annotation_is_precondition',false);
        left=sfPoint(0,x,a,s);right=sfPoint(T,x,a,s);
        out.endpoint_facts=struct('analytic_start',left,'analytic_end',right,'literal_saved_end',storedEnd, ...
            'literal_saved_end_status','UNASSESSED_NOT_RETAINED','analytic_minus_literal_end',[], ...
            'intended_boundaries_excluded_from_stationary_roots',true,'saved_state_corrected',false);
        if ~isempty(storedEnd)
            assert(isa(storedEnd,'double')&&isreal(storedEnd)&&isequal(size(storedEnd),[14,1])&&all(isfinite(storedEnd)), ...
                'PKStationary:SavedEnd','Retain only a literal raw14 saved endpoint.');
            out.endpoint_facts.literal_saved_end_status='LITERAL_SAVED_ENDPOINT';
            out.endpoint_facts.analytic_minus_literal_end=right.state14-storedEnd;
        end
        times=linspace(0,T,o.GridIntervals+1);legs=cell(4,1);
        for leg=1:4
            sfCheck(limit);rates=zeros(size(times));for j=1:numel(times),v=sfPoint(times(j),x,a,s);rates(j)=v.gdot(leg);end
            brackets=zeros(0,2);exact=find(rates==0);exact=exact(exact>1&exact<numel(times));
            for j=1:numel(times)-1
                if (rates(j)<0&&rates(j+1)>0)||(rates(j)>0&&rates(j+1)<0),brackets(end+1,:)=[times(j),times(j+1)];end %#ok<AGROW>
            end
            attempts=cell(numel(exact)+size(brackets,1),1);roots=cell(0,1);keptTimes=zeros(0,1);
            for j=1:numel(attempts)
                sfCheck(limit);attempt=struct('method','','bracket',[],'local_time',[],'exitflag',[],'residual',[], ...
                    'output',struct(),'status','UNASSESSED','failure',struct());
                try
                    if j<=numel(exact)
                        t=times(exact(j));attempt.method='literal-exact-grid-zero';attempt.exitflag=1;attempt.residual=rates(exact(j));
                    else
                        bracket=brackets(j-numel(exact),:);attempt.method='fzero-sign-bracket';attempt.bracket=bracket;
                        rootOptions=optimset('Display','off','TolX',o.RootTolX,'MaxIter',o.MaxRootIterations,'MaxFunEvals',o.MaxRootEvaluations);
                        [t,fval,flag,rootOutput]=fzero(@rate,bracket,rootOptions);
                        attempt.exitflag=flag;attempt.residual=fval;attempt.output=rootOutput;
                    end
                    attempt.local_time=t;value=sfPoint(t,x,a,s);
                    if attempt.exitflag<=0||~isfinite(t)||abs(value.gdot(leg))>o.RootResidualTolerance
                        attempt.status='FAILED_ROOT_OR_RESIDUAL';
                    elseif t<=o.BoundaryExclusionSeconds||t>=T-o.BoundaryExclusionSeconds
                        attempt.status='EXCLUDED_BOUNDARY_NEIGHBORHOOD';
                    elseif any(abs(keptTimes-t)<=o.RootDedupSeconds)
                        attempt.status='DEDUPLICATED';
                    else
                        attempt.status='RETAINED_INTERIOR_STATIONARY_ROOT';keptTimes(end+1,1)=t;
                        roots{end+1,1}=struct('local_time',t,'absolute_time',t0+t,'leg_index',leg,'leg_name',s.Leg.Names{leg}, ...
                            'g',value.g(leg),'gdot',value.gdot(leg),'gddot',value.gddot(leg),'strict_local_minimum_by_gddot',value.gddot(leg)>0, ...
                            'raw_local_state',value,'discovery_method',attempt.method,'bracket',attempt.bracket); %#ok<AGROW>
                    end
                catch problem
                    if strcmp(problem.identifier,'PKStationary:Clock'),rethrow(problem);end
                    attempt.status='ROOT_CALL_FAILED';attempt.failure=sfFailure(problem);
                end
                attempts{j}=attempt;
            end
            statuses=cellfun(@(v)v.status,attempts,'UniformOutput',false);
            legs{leg}=struct('leg_index',leg,'leg_name',s.Leg.Names{leg},'grid_intervals',o.GridIntervals,'grid_definition','linspace(0,local_duration,GridIntervals+1)', ...
                'grid_point_count',numel(times),'grid_finite_rate_count',sum(isfinite(rates)),'sign_change_brackets',brackets,'exact_interior_grid_zero_indices',exact,'attempt_count',numel(attempts), ...
                'sign_change_bracket_count',size(brackets,1),'exact_interior_grid_zero_count',numel(exact), ...
                'failed_root_count',sum(strcmp(statuses,'FAILED_ROOT_OR_RESIDUAL')|strcmp(statuses,'ROOT_CALL_FAILED')), ...
                'boundary_excluded_count',sum(strcmp(statuses,'EXCLUDED_BOUNDARY_NEIGHBORHOOD')), ...
                'deduplicated_count',sum(strcmp(statuses,'DEDUPLICATED')), ...
                'retained_root_count',numel(roots),'attempts',{attempts},'stationary_roots',{roots},'all_rate_roots_found_claimed',false);
        end
        out.legs=legs;out.status='FINITE_FIXED_LITERAL_ROOT_SCAN_COMPLETED';
    catch problem
        if strcmp(problem.identifier,'PKStationary:Clock'),rethrow(problem);end
        if strcmp(out.status,'EXACT_ALGEBRA_PRECONDITIONS_VALIDATED'),out.status='UNASSESSED_SCAN_INCOMPLETE';end
        out.precondition_failure=sfFailure(problem);
    end
    function v=rate(t),sfCheck(limit);value=sfPoint(t,x,a,s);v=value.gdot(leg);end
end
function v=sfPoint(t,x,a,s)
    st=s.State;w=sqrt(a.k_s./a.l_0.^2);A=x(s.Leg.AngleIndices)-a.rsla;B=x(s.Leg.RateIndices)./w;
    alpha=a.rsla+A.*cos(w*t)+B.*sin(w*t);adot=-A.*w.*sin(w*t)+B.*w.*cos(w*t);addot=-w.^2.*(alpha-a.rsla);
    state=x;state(st.x)=x(st.x)+x(st.dx)*t;state(st.y)=x(st.y)+x(st.dy)*t-t^2/2;state(st.dy)=x(st.dy)-t;
    state(s.Leg.AngleIndices)=alpha;state(s.Leg.RateIndices)=adot;theta=x(st.phi)+alpha;
    g=state(st.y)+a.s*sin(x(st.phi))-a.l_0.*cos(theta);
    gd=state(st.dy)+a.l_0.*sin(theta).*adot;
    gdd=-1+a.l_0.*(cos(theta).*adot.^2+sin(theta).*addot);
    v=struct('local_time',t,'state14',state,'raw_phi',x(st.phi),'raw_alpha',alpha,'raw_theta',theta, ...
        'alpha_rate',adot,'alpha_acceleration',addot,'g',g,'gdot',gd,'gddot',gdd);
    assert(all(isfinite([state;g;gd;gdd])),'PKStationary:NonfiniteAlgebra','Fixed literal algebra must remain finite.');
end
function d=savedDigest(a),d=C1ScientificDigest_v3(a);end
function f=sfFailure(p),f=struct('identifier',p.identifier,'message',p.message,'stack',p.stack);end
function sfRead2(file,digest),for pass=1:2,a=load(file,'audit','audit_digest');assert(strcmp(a.audit_digest,digest)&&strcmp(C1ScientificDigest_v3(a.audit),digest),'PKStationary:Read2','Both actual native reads must preserve the scientific digest.');end,end
function sfVerify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,sfLiteral(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKStationary:Changed','An immutable source changed.');if isfield(r,'bytes'),d=dir(r.file);assert(isscalar(d)&&d.bytes==r.bytes,'PKStationary:Bytes','A source changed byte count.');end,end,end
function r=sfRef(file),d=dir(file);r=struct('file',sfLiteral(file),'sha256',RoundSHA256_v3(file),'bytes',d.bytes);end
function f=sfLiteral(v),f=char(java.io.File(v).getCanonicalPath());assert(strcmp(f,char(java.io.File(V3Path_v3(v)).getCanonicalPath())),'PKStationary:Alias','Use one literal path for hash/read/write.');end
function sfCheck(l),assert(sfUTC()<l.u&&sfNano()<l.m,'PKStationary:Clock','The unchanged original/local clock expired; retain actual outputs/stages.');end
function t=sfUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=sfNano(),t=double(java.lang.System.nanoTime());end
