function comparison=CompareEventRestartReplayEpochs20261102(old,new)
%COMPAREEVENTRESTARTREPLAYEPOCHS20261102 Explicit matched native observations.
% Bit parity is reported separately from a fixed numerical comparison. The
% comparison neither replaces nine-gate admission nor requalifies history.
    assert(old.completed&&new.completed&&old.source_posthash&&new.source_posthash ...
        &&numel(old.rows)==6&&numel(new.rows)==6,'EventReplayCompare:Incomplete');
    assert(strcmp(C1ScientificDigest_v3(old.profile),C1ScientificDigest_v3(new.profile)) ...
        &&strcmp(C1ScientificDigest_v3(old.map_limits),C1ScientificDigest_v3(new.map_limits)) ...
        &&strcmp(C1ScientificDigest_v3(old.source_references),C1ScientificDigest_v3(new.source_references)) ...
        &&strcmp(C1ScientificDigest_v3(old.shared_source_references),C1ScientificDigest_v3(new.shared_source_references)), ...
        'EventReplayCompare:UnmatchedProfile','Inputs and explicit profiles must match, not just labels.');
    tolerance=1e-8;rows=cell(6,1);
    for k=1:6
        a=old.rows{k};b=new.rows{k};assert(strcmp(a.label,b.label)&&isequal(a.nominal,b.nominal),'EventReplayCompare:Selector');
        keys={'literal_initial_state','literal_initial_mode','literal_parameter','declared_raw_offset','actual_raw_offset','source_header'};
        for j=1:numel(keys)
            assert(strcmp(C1ScientificDigest_v3(a.(keys{j})),C1ScientificDigest_v3(b.(keys{j}))), ...
                'EventReplayCompare:LiteralInput','Each full raw input/header/declared offset must match exactly.');
        end
        row=struct('label',a.label,'nominal',a.nominal,'literal_inputs_exact_bits',true, ...
            'old_status',a.status,'new_status',b.status,'old_map_completed',a.map_completed,'new_map_completed',b.map_completed, ...
            'both_maps_and_metrics_returned',false,'bitwise_physics_unchanged',false, ...
            'within_declared_comparison_tolerance',false,'old_failure',a.failure,'new_failure',b.failure);
        needed={'return_state','raw_return_state','period','full_stride_displacement','raw_replay_digest', ...
            'physical_event_digest','maximum_energy_variation','maximum_stance_constraint'};
        if a.map_completed&&b.map_completed&&all(isfield(a,needed))&&all(isfield(b,needed))
            row.both_maps_and_metrics_returned=true;
            row.period_difference=b.period-a.period;row.return_state_difference=b.return_state-a.return_state;
            row.raw_return_state_difference=b.raw_return_state-a.raw_return_state;
            row.stride_difference=b.full_stride_displacement-a.full_stride_displacement;
            row.event_ids_equal=isequaln(a.event_ids,b.event_ids);row.batch_sizes_equal=isequaln(a.event_batch_sizes,b.event_batch_sizes);
            row.event_signature_equal=isequaln(a.event_signature,b.event_signature);row.cohort_signature_equal=isequaln(a.cohort_signature,b.cohort_signature);
            row.native_id_equal=strcmp(a.replay_native_id,b.replay_native_id);
            row.period_exact_bits=exact(a.period,b.period);row.return_state_exact_bits=exact(a.return_state,b.return_state);
            row.raw_return_state_exact_bits=exact(a.raw_return_state,b.raw_return_state);
            row.stride_exact_bits=exact(a.full_stride_displacement,b.full_stride_displacement);
            row.physical_event_records_exact_bits=strcmp(a.physical_event_digest,b.physical_event_digest);
            row.bitwise_physics_unchanged=strcmp(a.raw_replay_digest,b.raw_replay_digest)&&row.physical_event_records_exact_bits;
            row.event_times_difference=[];eventTimesWithin=false;
            if isequal(size(a.event_times),size(b.event_times))
                row.event_times_difference=b.event_times-a.event_times;eventTimesWithin=within(a.event_times,b.event_times,tolerance);
            end
            row.within_declared_comparison_tolerance=within(a.period,b.period,tolerance) ...
                &&within(a.return_state,b.return_state,tolerance)&&within(a.raw_return_state,b.raw_return_state,tolerance) ...
                &&within(a.full_stride_displacement,b.full_stride_displacement,tolerance)&&eventTimesWithin ...
                &&row.event_ids_equal&&row.batch_sizes_equal&&row.event_signature_equal&&row.cohort_signature_equal;
            row.old_nominal_metric_conditions_passed=a.nominal_metric_conditions_passed;
            row.new_nominal_metric_conditions_passed=b.nominal_metric_conditions_passed;
            row.old_full13_norm=a.full13_norm;row.new_full13_norm=b.full13_norm;
            row.old_maximum_energy_variation=a.maximum_energy_variation;row.new_maximum_energy_variation=b.maximum_energy_variation;
            row.old_maximum_stance_constraint=a.maximum_stance_constraint;row.new_maximum_stance_constraint=b.maximum_stance_constraint;
            row.old_minimum_physical_margins=a.minimum_physical_margins;row.new_minimum_physical_margins=b.minimum_physical_margins;
            row.old_right_continuous_section=a.right_continuous_section;row.new_right_continuous_section=b.right_continuous_section;
        end
        rows{k}=row;
    end
    nominal=rows(1:5);
    comparison=struct('schema','event-restart-matched-replay-comparison-v1','rows',{rows}, ...
        'all_literal_inputs_exact_bits',true,'all_nominal_bitwise_physics_unchanged',all(cellfun(@(r)r.bitwise_physics_unchanged,nominal)), ...
        'all_nominal_within_declared_comparison_tolerance',all(cellfun(@(r)r.within_declared_comparison_tolerance,nominal)), ...
        'comparison_tolerance',tolerance,'comparison_formula','Per scalar: abs(new-old)<=1e-8*max(1,abs(old),abs(new)); event/order/cohort/batch identities must agree.', ...
        'old_all_nominal_metric_conditions_passed',old.all_nominal_metric_conditions_passed, ...
        'new_all_nominal_metric_conditions_passed',new.all_nominal_metric_conditions_passed,'completed',true, ...
        'scope','Only these five nominal seeds and one declared raw additive native-map probe. Numerical comparison, identity parity and explicit replay metrics are separate from fresh all9 admission and historical validity.');
    C1ScientificDigest_v3(comparison);
end
function yes=exact(a,b),yes=strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b));end
function yes=within(a,b,tol)
    yes=isnumeric(a)&&isnumeric(b)&&isequal(size(a),size(b))&&all(isfinite(a(:)))&&all(isfinite(b(:)));
    if yes,scale=max([ones(numel(a),1),abs(a(:)),abs(b(:))],[],2);yes=all(abs(b(:)-a(:))<=tol*scale);end
end
