function out=CheckPK30hDefaultStrictWriter20261102()
% Default strict-format smoke; raw connectivity is acquired, never assumed.
V='/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3';N=fullfile(V,'Research_v3','C1');A=fullfile(N,'Audits');
refs={ref(fullfile(N,'Components','C1_PK_Component_0060.mat'),'cd75c52e77a16082bdc9f2688626a9ebfbd0f2b6131d8d3e205ea9e18bcbb559',19159730); ...
 ref(fullfile(A,'PK30h_20261101_StoredGraph01.mat'),'86beef51cc7d0ec9cb23ffb1b63b3a0b61596c7ea15ebb8511d5b4e319b51e83',10370104); ...
 ref(fullfile(A,'PK30h_20261101_StoredGraph01_External_Closure.json'),'54a5888081315f74af1376acf66929939a5fcb6be4824c62b4699d22b207dadb',41442); ...
 ref('/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped/P1_Breaking_Symmetries_Leads_to_Diverse_Qudrupedal_Gaits/1_Roadmap/PK_20_2.mat','45835bb5024b1dc9b875c7b8f7b205769f537a4ff4144c763058537f44dbf401',110861); ...
 ref(fullfile(V,'4_Solution_Management','WriteBranchSolutionCore29_v3.m'),'3878b93aafde117bd4df74f11f6061e17757857c9f099b2efcee0021493ab4e6',40594); ...
 ref(fullfile(V,'4_Solution_Management','C1StoredComponentSource_v3.m'),'1154c75dbdaffe05fccd623d6d79ee1b2b4b8a47d878d2ae3795367ba6cb56d4',11185); ...
 ref(fullfile(V,'4_Solution_Management','LoadC1SolutionCore29_v3.m'),'79e879e565c1a6d6dd6112f327635f85efb5f3a2329cbec7588adf6a197a81a6',14300); ...
 ref(fullfile(V,'4_Solution_Management','BranchSolutionFile_v3.m'),'48ca4f75e2ba5967378cb94e7d617d84aaf387a7495a1492481fc6709ea45b1b',28330); ...
 ref(fullfile(A,'PK30h_20261101_Sustained01_Plan.mat'),'38459ef421412b12dab9eb27afc39c8a77582bebf0ae44bbe25d3f9328c14fb2',5714)};
guard(refs);assert(strcmp(which('WriteBranchSolutionCore29_v3'),refs{5}.file)&&strcmp(which('LoadC1SolutionCore29_v3'),refs{7}.file),'PKStrictSmoke:Canonical','Use the actual installed canonical APIs.');
x=load('-mat',refs{9}.file,'plan');old=x.plan.original_budget;grant=struct('grant_id',old.grant_id,'start_utc',old.start_utc,'research_deadline_utc',old.research_deadline_utc,'deadline_utc',old.deadline_utc);B=AbsoluteRunBudget_v3(grant,old);clear x old
entered=clocks();assert(min(B.research_deadline_unix_seconds-entered.utc,(B.research_deadline_monotonic_ns-entered.mono)/1e9)>362,'PKStrictSmoke:Fit','The360/30 operation must fit the unchanged grant.');
finish=struct('utc',entered.utc+360,'mono',entered.mono+360e9);work=struct('deadline_unix_seconds',finish.utc-30,'deadline_monotonic_ns',finish.mono-30e9);
core=fullfile(A,'PK30h_20261102_DefaultStrictWriter01_Core29.mat');writerAudit=fullfile(A,'PK30h_20261102_DefaultStrictWriter01_Writer.mat');
audit=fullfile(A,'PK30h_20261102_DefaultStrictWriter01.mat');fresh({core;[core,'.pending.mat'];writerAudit;[writerAudit,'.pending.mat'];audit;[audit,'.pending.mat']});
out=struct('schema','PK30h-default-strict-core29-smoke-v1','completed',false,'source_posthash',false,'input_references',{refs}, ...
 'original_budget',B,'operation_finish',finish,'raw_source_point_count',0,'selected_raw_indices',[], ...
 'raw_connectivity_acquired',false,'graphplan_connectivity_substituted',false,'writer_actual_returned',false, ...
 'literal_identity_matrix_checks',{{}},'failure',struct(),'fresh_admission_claimed',false,'own_process_exit_claimed',false);
try
 closure=jsondecode(fileread(refs{3}.file));assert(closure.process.actual_tool_exit_observed&&closure.process.exit_code==0 ...
  &&closure.independent_post_guard.all_passed&&strcmp(closure.graph_reference.sha256,refs{2}.sha256), ...
  'PKStrictSmoke:HistoricalAuthority','Retain successful graph provenance as opaque writer authority; it does not supply raw0060 connectivity.');
 ix=BranchSolutionFile_v3.index(refs{1}.file);count=numel(ix.points);assert(count==3,'PKStrictSmoke:ActualRawCount','Acquire the actual3point raw source index.');
 pairs=zeros(0,2);for k=1:numel(ix.edges),e=ix.edges{k};pairs(end+1,:)=[e.from,e.to];end %#ok<AGROW>
 if isfield(ix.metadata,'component_graph')
  g=ix.metadata.component_graph;
  for name={'exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'}
   if isfield(g,name{1}),pairs=[pairs;g.(name{1})];end %#ok<AGROW>
  end
 end
 adjacency=eye(count)>0;
 for k=1:size(pairs,1),a=pairs(k,1);b=pairs(k,2);assert(a>=1&&a<=count&&b>=1&&b<=count&&a~=b,'PKStrictSmoke:RawRelations','Use actual bounded raw relations.');adjacency(a,b)=true;adjacency(b,a)=true;end
 % Independent Boolean transitive closure, rather than the writer's union-find.
 for k=1:count,adjacency=adjacency|(adjacency(:,k)&adjacency(k,:));end
 [~,seed]=max(sum(adjacency,2));selected=find(adjacency(seed,:));selected=selected(:);out.raw_source_point_count=count;
 out.selected_raw_indices=selected;out.raw_relation_pairs=pairs;out.raw_connectivity_acquired=true;out.raw_index_digest=C1ScientificDigest_v3(ix);
 opts=struct('Budget',work,'MaxWallSeconds',240,'SaveMarginSeconds',30, ...
  'SourceAuditReference',two(refs{2}),'SourceClosureReference',two(refs{3}),'AuditFile',writerAudit);
 assert(~isfield(opts,'WorkingStorage'),'PKStrictSmoke:Default','Exercise the default strict writer without any working override.');
 receipt=WriteBranchSolutionCore29_v3(two(refs{1}),double(seed),core,two(refs{4}),opts);out.writer_actual_returned=true;
 assert(receipt.completed&&receipt.source_posthash&&receipt.final_return_timely&&receipt.audit_publication_returned ...
  &&receipt.source_passes_completed==2&&receipt.retained_projection_read2&&receipt.all_native_ids_and_policies_verified ...
  &&receipt.stage_native_read2&&receipt.installed_native_read2&&receipt.loader_smoke_returned ...
  &&~receipt.working_storage_enabled&&receipt.strict_target_met&&receipt.maximum_core_bytes==554305 ...
  &&receipt.core_bytes<=554305&&isequal(receipt.source_indices(:),selected)&&receipt.point_count==numel(selected), ...
  'PKStrictSmoke:ActualWriter','Default strict export must preserve the actual raw component and all original checks.');
 names=whos('-file',core);assert(isequal(sort({names.name}),{'core_digest','solution_core29'}),'PKStrictSmoke:TwoVariables','Default strict writer must not add working-format variables.');
 [native,~,~]=BranchSolutionFile_v3.loadSolutions(refs{1}.file,selected);sha=RoundSHA256_v3(core);
 for k=unique([1,numel(selected)])
  [o,report,point,view]=LoadC1SolutionCore29_v3(core,k,sha);expected=native{k};
  same([o.initial_state;o.stride_displacement;o.period],[expected.initial_state;expected.stride_displacement;expected.period]);
  same(o.parameter,expected.parameter);same(o.initial_mode,expected.initial_mode);
  assert(strcmp(OrbitContentIdentity_v3(o),OrbitContentIdentity_v3(expected))&&strcmp(point.native_id,OrbitContentIdentity_v3(expected)) ...
   &&~report.core29_view.fresh_all_nine_admission_claimed&&~isfield(view,'working_storage'), ...
   'PKStrictSmoke:LiteralNative','First/last strict loaded identities and literal matrix/p/q must match the actual raw occurrences.');
  out.literal_identity_matrix_checks{end+1,1}=struct('core_index',k,'raw_index',selected(k),'native_id',point.native_id,'passed',true);
 end
 clear native o report point view expected
 out.writer_actual_receipt=receipt;out.core_reference=ref(core,sha,receipt.core_bytes);
 d=dir(writerAudit);out.writer_audit_reference=ref(writerAudit,RoundSHA256_v3(writerAudit),d.bytes);
 guard(refs);check(finish);out.source_posthash=true;out.completed=true;
catch failure
 out.failure=struct('identifier',failure.identifier,'message',failure.message,'report',getReport(failure,'extended','hyperlinks','off'));
end
out.scope='Default strict storage API smoke using actual raw0060 connectivity. It neither imports GraphPlan component1 equalities nor performs numerical replay, new admission or own-process-exit verification.';
check(finish);strict_smoke=out;strict_smoke_digest=C1ScientificDigest_v3(strict_smoke);stage=[audit,'.pending.mat'];
save(stage,'strict_smoke','strict_smoke_digest','-v7');expected=struct('strict_smoke',strict_smoke,'strict_smoke_digest',strict_smoke_digest);read2(stage,expected);publish(stage,audit);read2(audit,expected);
fprintf('PK30H_DEFAULT_STRICT_WRITER_RETURN %s\n',jsonencode(struct('completed',out.completed,'source_posthash',out.source_posthash,'raw_source_points',out.raw_source_point_count,'selected_raw_indices',out.selected_raw_indices,'audit',audit,'audit_sha256',RoundSHA256_v3(audit),'failure',out.failure)));
check(finish);assert(out.completed,'PKStrictSmoke:Incomplete','Keep the actual writer/audit and any retained stages for reconciliation.');
end
function r=ref(file,sha,bytes),r=struct('file',file,'sha256',sha,'bytes',bytes);end
function r=two(r),r=rmfield(r,'bytes');end
function guard(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKStrictSmoke:Guard','An exact immutable input changed: %s',r.file);end,end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'PKStrictSmoke:Fresh','Preserve existing output: %s',paths{k});end,end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKStrictSmoke:TypedEquality','Literal class/shape/raw bits differ.');end
function read2(file,expected),for pass=1:2,x=load('-mat',file);names=fieldnames(expected);assert(isequal(sort(fieldnames(x)),sort(names)),'PKStrictSmoke:Variables','Exact saved variables differ.');for k=1:numel(names),same(x.(names{k}),expected.(names{k}));end;end,end
function publish(stage,file),fresh({file});javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath()),'PKStrictSmoke:Publication','Publish the owned stage only.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());end
function t=clocks(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime()));end
function check(limit),t=clocks();assert(min(limit.utc-t.utc,(limit.mono-t.mono)/1e9)>0,'PKStrictSmoke:Deadline','The unchanged bounded operation deadline elapsed.');end
