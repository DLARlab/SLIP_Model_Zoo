function out=PromotePK30hWorkingCore03_20261102()
% One additive, bounded packaging operation. No map, correction or admission.
V='/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3';
N=fullfile(V,'Research_v3','C1');A=fullfile(N,'Audits');
D=fullfile(N,'Compact_Exports_20261030','PK30h_20261101_StoredCoreSet01');
refs={ref(fullfile(D,'C1_PK_Component_0003_Core29.mat.pending.mat'),'6f57fec69e3a0368f75dab2a0661156fc0a5671eb536840f97340008e67228c3',912287); ...
 ref(fullfile(A,'PK30h_20261101_StoredCoreSet01_Component_0003.mat'),'66f868543c3a85639ee0eba6e0c30fd1f5ca3f7eaa804a4d50c12679f8634e0e',962358); ...
 ref(fullfile(A,'PK30h_20261101_StoredCoreSet01_External_Closure.json'),'fe9e15559351c33261ef1f68d18cf2daea43c9dc77f4bf9dae51d00aa10a85bf',26569); ...
 ref(fullfile(A,'PK30h_20261101_StoredGraph01.mat'),'86beef51cc7d0ec9cb23ffb1b63b3a0b61596c7ea15ebb8511d5b4e319b51e83',10370104); ...
 ref('/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped/P1_Breaking_Symmetries_Leads_to_Diverse_Qudrupedal_Gaits/1_Roadmap/PK_20_2.mat','45835bb5024b1dc9b875c7b8f7b205769f537a4ff4144c763058537f44dbf401',110861); ...
 ref(fullfile(V,'4_Solution_Management','LoadC1WorkingSolutionCore29_v3.m'),'b0680eb630641cdeb092edcf659892112a39e5cb0f8bcd1cbd03b0a71259e69b',16892); ...
 ref(fullfile(V,'4_Solution_Management','LoadC1SolutionCore29_v3.m'),'79e879e565c1a6d6dd6112f327635f85efb5f3a2329cbec7588adf6a197a81a6',14300); ...
 ref(fullfile(A,'PK30h_20261101_Sustained01_Plan.mat'),'38459ef421412b12dab9eb27afc39c8a77582bebf0ae44bbe25d3f9328c14fb2',5714); ...
 ref(fullfile(A,'PK30h_20261102_Working_Core_Source_Adoption.json'),'8f874be8dee9e23674ee8b3a687401650e78e1e125ae0481df7feaa3c67a466b',3720)};
% The source-adoption SHA above must match Root's exact receipt before release.
guard(refs);assert(strcmp(which('LoadC1WorkingSolutionCore29_v3'),refs{6}.file) ...
 &&strcmp(which('LoadC1SolutionCore29_v3'),refs{7}.file),'PKWorking:CanonicalReader','Use the installed canonical readers, without private shadows.');
x=load('-mat',refs{8}.file,'plan');old=x.plan.original_budget;
grant=struct('grant_id',old.grant_id,'start_utc',old.start_utc,'research_deadline_utc',old.research_deadline_utc,'deadline_utc',old.deadline_utc);
B=AbsoluteRunBudget_v3(grant,old);clear x old
t=clocks();assert(min(B.research_deadline_unix_seconds-t.utc,(B.research_deadline_monotonic_ns-t.mono)/1e9)>362,'PKWorking:Fit','The whole360/30 operation must fit the unchanged science grant.');
finish=struct('utc',t.utc+360,'mono',t.mono+360e9);work=struct('utc',finish.utc-30,'mono',finish.mono-30e9);
output=fullfile(D,'C1_PK_Component_0003_WorkingCore29.mat');stage=[output,'.pending.mat'];
audit=fullfile(A,'PK30h_20261102_WorkingCore03_Promotion01.mat');auditStage=[audit,'.pending.mat'];
negative={fullfile(D,'C1_PK_Component_0003_WorkingCore29.negative_digest.mat');fullfile(D,'C1_PK_Component_0003_WorkingCore29.negative_ceiling.mat')};
fresh([{output;stage;audit;auditStage};negative]);
out=struct('schema','PK30h-working-core29-promotion-check-v1','completed',false,'source_posthash',false, ...
 'input_references',{refs},'original_budget',B,'operation_finish',finish,'operation_work',work, ...
 'original_failure_preserved',false,'old_stage_full_native_loads',0,'whole_payload_typed_equal',false, ...
 'all_literal_native_ids_preserved',false,'all_literal_matrix_bits_preserved',false, ...
 'stage_native_read2',false,'installed_native_read2',false,'representative_native_indices',[1;472], ...
 'representative_native_ids',{{}},'negative_checks',{{}},'owned_temporaries',{{}},'output_reference',[], ...
 'failure',struct(),'fresh_admission_claimed',false,'scientific_completion_claimed',false,'own_process_exit_claimed',false);
try
 check(work);closure=jsondecode(fileread(refs{3}.file));
 assert(strcmp(closure.schema,'PK30h-direct-core-set-external-closure-v1')&&closure.process.actual_tool_exit_observed ...
  &&closure.process.exit_code==1&&closure.independent_post_guard.all_passed ...
  &&closure.root_external_inputs_unchanged_after_work&&~closure.native_flags_preserved.completed ...
  &&~closure.native_flags_preserved.source_posthash&&closure.native_flags_preserved.third_component.points==472 ...
  &&strcmp(closure.native_flags_preserved.third_component.failure_identifier,'BranchCore29:FiveTimes'), ...
  'PKWorking:HistoricalClosure','Retain the actual closed incomplete export; no old completion flag may be promoted.');
 x=load('-mat',refs{2}.file,'receipt');r=x.receipt;clear x
 assert(~r.completed&&~r.source_posthash&&r.source_passes_completed==2&&r.retained_projection_read2 ...
  &&r.all_native_ids_and_policies_verified&&r.stage_save_returned&&~r.stage_native_read2&&~r.publication_returned ...
  &&r.point_count==472&&r.core_bytes==912287&&r.maximum_core_bytes==554305 ...
  &&strcmp(r.core_sha256,refs{1}.sha256)&&strcmp(r.failure.identifier,'BranchCore29:FiveTimes'), ...
  'PKWorking:HistoricalReceipt','The exact failed audit must confirm both source passes and only the known size boundary.');
 out.original_failure_preserved=true;out.original_failure_identifier=r.failure.identifier;
 x=load('-mat',refs{4}.file,'component_plan','plan_digest');p=x.component_plan;
 assert(strcmp(C1ScientificDigest_v3(p),x.plan_digest)&&p.completed&&p.source_posthash ...
  &&numel(p.nodes)==1036&&numel(p.components)==6,'PKWorking:GraphPlan','Use the exact successful graph-only plan.');
 selected=p.components{3}.global_indices(:);assert(numel(selected)==472&&isequal(selected,r.source_indices(:)),'PKWorking:Component','Retain the entire declared component.');
 names=whos('-file',refs{1}.file);assert(isequal(sort({names.name}),{'core_digest','solution_core29'}),'PKWorking:OldVariables','The immutable old stage must retain its exact two-variable format.');
 check(work);a=load('-mat',refs{1}.file,'solution_core29','core_digest');out.old_stage_full_native_loads=1;
 check(work);b=load('-mat',refs{1}.file,'solution_core29','core_digest');out.old_stage_full_native_loads=2;
 same(a,b);same(a.solution_core29.native_ids,b.solution_core29.native_ids);same(a.solution_core29.solution_matrix,b.solution_core29.solution_matrix);
 c=a.solution_core29;assert(strcmp(C1ScientificDigest_v3(c),a.core_digest)&&strcmp(a.core_digest,b.core_digest), ...
  'PKWorking:OldDigest','Both complete independently loaded old payloads must retain the whole typed digest.');
 assert(c.point_count==472&&isequal(size(c.solution_matrix),[29,472])&&c.original_v2_bytes==110861 ...
  &&c.maximum_core_bytes==554305&&strcmp(c.original_v2_reference.file,refs{5}.file) ...
  &&strcmp(c.original_v2_reference.sha256,refs{5}.sha256)&&strcmp(c.source_reference.sha256,refs{4}.sha256), ...
  'PKWorking:OriginalTarget','Retain the actual whole-v2 reference, original strict target and graph-plan source.');
 for k=1:472
  assert(strcmp(c.native_ids{k},p.nodes{selected(k)}.native_ID)&&c.contexts{k}.source_index==selected(k), ...
   'PKWorking:LiteralNativeIDs','Every literal NativeID/source occurrence must match the graph plan.');
 end
 for k=1:numel(c.runtime_methods)
  m=c.runtime_methods{k};file=which(m.name);d=dir(file);refs{end+1,1}=ref(file,m.sha256,d.bytes); %#ok<AGROW>
 end
 refs{end+1,1}=ref(fullfile(V,c.runtime_environment.locations_map_relative_path),c.runtime_environment.locations_map_sha256,44104);
 guard(refs);out.input_references=refs;out.whole_payload_typed_equal=true;
 out.all_literal_native_ids_preserved=true;out.all_literal_matrix_bits_preserved=true;out.core_digest=a.core_digest;
 out.native_ids_digest=C1ScientificDigest_v3(c.native_ids);out.solution_matrix_digest=C1ScientificDigest_v3(c.solution_matrix);
 solution_core29=c;core_digest=a.core_digest;clear a b p x r c
 working_storage=struct('schema','C1-necessary-data-working-core29-v1','core_digest',core_digest, ...
  'maximum_file_bytes',2*1024^2,'strict_target_bytes',554305, ...
  'reason','Preserve all472 occurrences and the complete required policy/section, graph and primitive/classifier heads of one connected component.', ...
  'reader_method',struct('name','LoadC1WorkingSolutionCore29_v3','sha256',refs{6}.sha256), ...
  'scope','Necessary complete-data working storage; the original strict5x target is unchanged. No new admission, branch completion or publication-size success is claimed.');
 working_storage_digest=C1ScientificDigest_v3(working_storage);check(work);
 save(stage,'solution_core29','core_digest','working_storage','working_storage_digest','-v7');
 expected=struct('solution_core29',solution_core29,'core_digest',core_digest,'working_storage',working_storage,'working_storage_digest',working_storage_digest);
 read2(stage,expected);out.stage_native_read2=true;d=dir(stage);sha=RoundSHA256_v3(stage);
 assert(d.bytes<=2*1024^2&&d.bytes>554305,'PKWorking:MeasuredCeiling','Report the original strict target as unmet while meeting the explicit working ceiling.');
 for k=[1,472]
  check(work);[o,report,point,view]=LoadC1WorkingSolutionCore29_v3(stage,k,sha);
  same([o.initial_state;o.stride_displacement;o.period],solution_core29.solution_matrix(:,k));
  assert(strcmp(point.native_id,solution_core29.native_ids{k})&&strcmp(OrbitContentIdentity_v3(o),point.native_id) ...
   &&~report.core29_view.fresh_all_nine_admission_claimed&&~view.working_storage.strict_target_met ...
   &&view.working_storage.actual_file_bytes==d.bytes&&view.working_storage.strict_target_bytes==554305, ...
   'PKWorking:NativeRepresentative','Representative native reconstructions must retain literal values and explicit historical/working scope.');
  out.representative_native_ids{end+1,1}=point.native_id;
 end
 out.negative_checks{end+1,1}=expect(@()LoadC1SolutionCore29_v3(stage,1,sha),'C1Core29:Variables');
 savedHeader=working_storage;savedDigest=working_storage_digest;
 working_storage_digest=repmat('0',1,64);assert(~strcmp(working_storage_digest,savedDigest),'PKWorking:BadDigestFixture','Use a genuinely different digest.');
 check(work);save(negative{1},'solution_core29','core_digest','working_storage','working_storage_digest','-v7');
 q=owned(negative{1});out.owned_temporaries{end+1,1}=q;
 out.negative_checks{end+1,1}=expect(@()LoadC1WorkingSolutionCore29_v3(q.file,1,q.sha256),'C1WorkingCore29:HeaderDigest');
 removeOwned(q);out.owned_temporaries{end}.removed=true;
 working_storage=savedHeader;working_storage.maximum_file_bytes=554305;working_storage_digest=C1ScientificDigest_v3(working_storage);
 check(work);save(negative{2},'solution_core29','core_digest','working_storage','working_storage_digest','-v7');
 q=owned(negative{2});out.owned_temporaries{end+1,1}=q;
 out.negative_checks{end+1,1}=expect(@()LoadC1WorkingSolutionCore29_v3(q.file,1,q.sha256),'C1WorkingCore29:FileCap');
 removeOwned(q);out.owned_temporaries{end}.removed=true;
 working_storage=savedHeader;working_storage_digest=savedDigest;clear o report point view savedHeader savedDigest q
 check(work);guard(refs);assert(strcmp(RoundSHA256_v3(stage),sha),'PKWorking:StageChanged','Publish only the verified working stage.');
 publish(stage,output);read2(output,expected);out.installed_native_read2=true;
 out.output_reference=owned(output);assert(strcmp(out.output_reference.sha256,sha),'PKWorking:PublishedSHA','Installed bytes differ.');
 out.output_reference=rmfield(out.output_reference,'removed');out.actual_file_bytes=d.bytes;
 out.maximum_working_bytes=2*1024^2;out.original_strict_target_bytes=554305;out.strict_target_met=false;
 guard(refs);check(finish);out.source_posthash=true;out.completed=true;
catch failure
 out.failure=struct('identifier',failure.identifier,'message',failure.message,'report',getReport(failure,'extended','hyperlinks','off'));
end
out.scope='Packaging/native reconstruction checks only; original failed flags unchanged. No new numerical admission, continuation edge, branch completion or own-process-exit claim.';
out.audit_completion_scope='Checks completed before audit publication; caller/Root independently witnesses actual process return, final deadline and exit.';
check(finish);promotion=out;promotion_digest=C1ScientificDigest_v3(promotion);
save(auditStage,'promotion','promotion_digest','-v7');read2(auditStage,struct('promotion',promotion,'promotion_digest',promotion_digest));
publish(auditStage,audit);read2(audit,struct('promotion',promotion,'promotion_digest',promotion_digest));
fprintf('PK30H_WORKING_CORE03_RETURN %s\n',jsonencode(struct('completed',out.completed,'source_posthash',out.source_posthash,'audit',audit,'audit_sha256',RoundSHA256_v3(audit),'output_reference',out.output_reference,'failure',out.failure)));
check(finish);assert(out.completed,'PKWorking:Incomplete','Preserve the exact audit and any retained owned stages; no automatic retry.');
end
function r=ref(file,sha,bytes),r=struct('file',file,'sha256',sha,'bytes',bytes);end
function guard(refs)
for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKWorking:SourceGuard','An exact immutable input changed: %s',r.file);end
end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'PKWorking:Fresh','Preserve existing owned output: %s',paths{k});end,end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKWorking:TypedEquality','Complete retained class/shape/field order/raw bits changed.');end
function read2(file,expected)
for pass=1:2
 x=load('-mat',file);names=fieldnames(expected);assert(isequal(sort(fieldnames(x)),sort(names)),'PKWorking:Variables','Exact saved variables differ.');
 for k=1:numel(names),same(x.(names{k}),expected.(names{k}));end
end
end
function row=expect(action,identifier)
observed='';try,action();catch failure,observed=failure.identifier;end
assert(strcmp(observed,identifier),'PKWorking:ExpectedRejection','Expected %s, observed %s.',identifier,observed);row=struct('expected_identifier',identifier,'observed_identifier',observed,'passed',true);
end
function q=owned(file),d=dir(file);q=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',d.bytes,'removed',false);end
function removeOwned(q),guard({q});delete(q.file);assert(~isfile(q.file),'PKWorking:TemporaryRemoval','Owned negative fixture remains.');end
function publish(stage,file)
fresh({file});javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());
assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath()),'PKWorking:PublicationIdentity','Publish exactly the owned stage.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());
end
function t=clocks(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime()));end
function check(limit),t=clocks();assert(min(limit.utc-t.utc,(limit.mono-t.mono)/1e9)>0,'PKWorking:Deadline','The original bounded operation deadline elapsed.');end
