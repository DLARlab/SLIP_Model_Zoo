function result=FinalizePK30hUnion20261101(B,cfg,recovery)
%FINALIZEPK30HUNION20261101 Frozen stored union, essential evidence and resume data.
% No tracing, grant renewal, scientific qualification or source retirement.
% Caller owns external closed-worker verification and the explicitly matched
% whole-v2 reference. The original historical journal is retained, never loaded.
    if nargin<3,recovery=[];end;recovering=~isempty(recovery);
    enteredUTC=pkUTC();enteredMono=pkNano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    required={'Generation','SourceRows','ProofRows','CohortRows','HistoricalDispositionRows', ...
        'SurveyReference','DomainReference','HistoricalJournalReference','OriginalV2Reference','MatchedPhysicalParameter', ...
        'ClosureReferences','AllOwnedNativeWorkersClosed','UnionDirectory','ConsolidationReceiptFile', ...
        'EssentialAuditFile','CoreDirectory','ResumeDirectory','CampaignFile','MaxWallSeconds', ...
        'SaveMarginSeconds','ConsolidateSeconds','CoreSeconds','CoreSaveMarginSeconds'};
    assert((nargin==2||nargin==3)&&isstruct(cfg)&&isscalar(cfg)&&isequal(sort(fieldnames(cfg)),sort(required(:))), ...
        'PKFinal:Config','Supply the explicit closed generation, retained mappings, fresh paths and fixed caps.');
    assert(B.capture.pid==feature('getpid')&&isequal(cfg.AllOwnedNativeWorkersClosed,true), ...
        'PKFinal:Closed','Caller supplies actual closed-worker custody and this-process original-grant calibration.');
    assert(ischar(cfg.Generation)&&~isempty(regexp(cfg.Generation,'^[A-Za-z0-9_]+$','once')), ...
        'PKFinal:Generation','Use one literal generation label.');
    for key={'MaxWallSeconds','SaveMarginSeconds','ConsolidateSeconds','CoreSeconds','CoreSaveMarginSeconds'}
        validateattributes(cfg.(key{1}),{'double'},{'real','finite','scalar','positive'});
    end
    assert(cfg.SaveMarginSeconds<cfg.MaxWallSeconds&&cfg.CoreSaveMarginSeconds<cfg.CoreSeconds, ...
        'PKFinal:Caps','Save allocations belong to the original fixed total caps.');
    if recovering
        pkRecoveryContract(recovery);processCap=recovery.MaxWallSeconds;processSave=recovery.SaveMarginSeconds;
    else,processCap=cfg.MaxWallSeconds;processSave=cfg.SaveMarginSeconds;end
    finish=pkLimit(min(B.deadline_unix_seconds,enteredUTC+processCap),min(B.deadline_monotonic_ns,enteredMono+processCap*1e9));
    work=pkLimit(finish.deadline_unix_seconds-processSave,finish.deadline_monotonic_ns-processSave*1e9);
    baseline={'original0060';'original0061';'original0062';'original0064';'original0072';'original0159';'original0170'; ...
        'raw03';'grown0062';'grown0072';'grown0170';'recovered0062';'retained_negative';'retained_positive';'retained_secondary';'retained_low';'latest0170'};
    assert(iscell(cfg.SourceRows)&&iscolumn(cfg.SourceRows)&&numel(cfg.SourceRows)>=17 ...
        &&iscell(cfg.ProofRows)&&iscolumn(cfg.ProofRows)&&numel(cfg.ProofRows)>=5 ...
        &&iscell(cfg.CohortRows)&&iscolumn(cfg.CohortRows)&&~isempty(cfg.CohortRows)&&iscell(cfg.ClosureReferences)&&~isempty(cfg.ClosureReferences), ...
        'PKFinal:Rows','Keep17 baseline source roles, all declared proof rows and explicit closed-cohort/closure rows.');
    roles=cellfun(@(r)r.role,cfg.SourceRows,'UniformOutput',false);assert(numel(unique(roles))==numel(roles)&&all(ismember(baseline,roles)), ...
        'PKFinal:Roles','Baseline source roles are explicit and unique; extra actual closed join rows may be added.');
    refs=cellfun(@(r)r.reference,cfg.SourceRows,'UniformOutput',false);files=cellfun(@(r)r.file,refs,'UniformOutput',false);
    assert(numel(unique(files))==numel(files),'PKFinal:SourceGeneration','One path has one frozen generation; conflicting or duplicate generations require reconciliation.');
    code=pkProviders();refs=[refs;{cfg.SurveyReference;cfg.DomainReference;cfg.HistoricalJournalReference;cfg.OriginalV2Reference};cfg.ClosureReferences(:);code];
    for k=1:numel(cfg.CohortRows),refs=[refs;{cfg.CohortRows{k}.checkpoint_reference;cfg.CohortRows{k}.closure_reference}];end %#ok<AGROW>
    pkVerify(refs);C1ScientificDigest_v3(cfg);pkCheck(work);
    expectedV2=fullfile(fileparts(V3Root_v3()),'SLIP_Quadruped','P1_Breaking_Symmetries_Leads_to_Diverse_Qudrupedal_Gaits','1_Roadmap','PK_20_2.mat');
    originalInfo=dir(cfg.OriginalV2Reference.file);
    assert(strcmp(cfg.OriginalV2Reference.file,expectedV2)&&strcmp(cfg.OriginalV2Reference.sha256, ...
        '45835bb5024b1dc9b875c7b8f7b205769f537a4ff4144c763058537f44dbf401')&&isscalar(originalInfo)&&originalInfo.bytes==110861, ...
        'PKFinal:MatchedWholeV2','Use the reviewed WHOLE110861B original;554305B is the resulting5x cap, never an original bytecount.');
    schema=QuadrupedSchema_v3.shared();matchedP=schema.validateParameter(cfg.MatchedPhysicalParameter);
    for k=1:7
        at=find(strcmp(roles,baseline{k}));assert(strcmp(cfg.SourceRows{at}.reference.file,fullfile(N,'Components',['C1_PK_Component_',baseline{k}(9:end),'.mat'])), ...
            'PKFinal:OriginalStore','Bind each actual original store path by authority role, without class inference from its name.');
    end
    unionDir=pkLiteral(cfg.UnionDirectory);coreDir=pkLiteral(cfg.CoreDirectory);resumeDir=pkLiteral(cfg.ResumeDirectory);
    receiptFile=pkLiteral(cfg.ConsolidationReceiptFile);
    if recovering
        output=pkLiteral(recovery.OutputFile);campaign=pkLiteral(recovery.CampaignFile);stage=[output,'.pending.mat'];
        assert(isfolder(unionDir)&&isfile(receiptFile)&&strcmp(receiptFile,recovery.FailedConsolidationReference.file) ...
            &&~strcmp(output,pkLiteral(cfg.EssentialAuditFile))&&~strcmp(campaign,pkLiteral(cfg.CampaignFile)), ...
            'PKFinal:RecoveryPaths','Only the exact old union/receipt are reused; failed Essential/Campaign remain immutable.');
        paths={coreDir;resumeDir;output;stage;campaign;[campaign,'.pending.txt']};
    else
        output=pkLiteral(cfg.EssentialAuditFile);stage=[output,'.pending.mat'];campaign=pkLiteral(cfg.CampaignFile);
        paths={unionDir;coreDir;resumeDir;output;stage;receiptFile;campaign;[campaign,'.pending.txt']};
    end
    assert(numel(unique(paths))==numel(paths)&&all(cellfun(@(f)startsWith(f,[pkLiteral(N),filesep])&&~isfile(f)&&~isfolder(f),paths)), ...
        'PKFinal:Fresh','Use distinct fresh owned paths; preserve all prior partial union/Core/evidence/resume files.');
    mf=struct('schema','PK30h-final-union-essential-resume-manifest-v1','generation',cfg.Generation,'configuration',cfg, ...
        'original_budget',B,'original_finish',finish,'input_references',{refs},'source_code',{code}, ...
        'original_catalogues',{{}},'historical_obligations',{{}},'closed_cohorts',{{}},'resume_queue',{{}}, ...
        'proof_headers',{{}},'consolidation',struct(),'component_inventory',{{}},'core_rows',{{}}, ...
        'whole_native_id_union',{{}},'source_occurrence_map',{{}},'source_occurrence_bijection_verified',false, ...
        'all_original_occurrences_verified',false,'all_core_exports_completed',false,'essential_read2_verified',false, ...
        'consolidate_calls_invoked',0,'consolidate_calls_returned',0,'core_calls_invoked',0,'core_calls_returned',0, ...
        'pending_native_call',struct(),'completed',false,'source_posthash',false,'failure',struct(), ...
        'historical_journal_loaded',false,'historical_journal_duplicated',false,'new_admission_claimed',false, ...
        'future_grant_authorized',false,'future_queue_executed',false,'source_retirement_authorized',false, ...
        'root_ODE_map_classifier_replay_calls',0,'own_process_exit_claimed',false);
    if recovering
        [mf,essential_evidence,refs,priorConsoBudget]=pkRecover(recovery,B,cfg,refs,code,finish,work);
    else,essential_evidence=cell(0,1);priorConsoBudget=struct();end
    pkCheckpoint(stage,mf,essential_evidence);
    try
        if ~recovering
        x=load(cfg.SurveyReference.file,'audit');survey=x.audit;assert(survey.completed&&survey.source_posthash&&isempty(survey.jobs), ...
            'PKFinal:Survey','Use the exact completed saved observation-only Survey.');
        x=load(cfg.DomainReference.file,'audit');domain=x.audit;assert(domain.completed&&domain.source_posthash, ...
            'PKFinal:Domain','Use the completed saved Domain authority; its scientific flags remain literal.');
        mf.domain_observation_authority=struct('reference',cfg.DomainReference,'completed',domain.completed,'source_posthash',domain.source_posthash);clear x domain
        assert(iscell(cfg.HistoricalDispositionRows)&&numel(cfg.HistoricalDispositionRows)==13&&numel(survey.queue)>=13, ...
            'PKFinal:Historical','Map exactly13 literal historical rows without resetting their status or ladder.');
        for k=1:13
            q=survey.queue{k};d=cfg.HistoricalDispositionRows{k};
            assert(strcmp(q.role,'historical_frontier_obligation')&&q.journal_row==k&&strcmp(d.frontier_id,q.id)&&d.journal_row==k ...
                &&isequaln(q.journal_reference,cfg.HistoricalJournalReference)&&isequaln(q.history_locator.journal_reference,cfg.HistoricalJournalReference), ...
                'PKFinal:HistoricalJoin','Exact original journal SHA/id/row/ordered pair/history authority must join.');
            assert(ismember(d.disposition,{'OPEN','HOLD','EXPLICIT_OUTWARD_TRANSFER','LOCAL_DECLARED_CHART_BOUNDARY','REQUESTED_APEX_STOP'}), ...
                'PKFinal:Disposition','New resume disposition is separate from literal historical scientific/scheduler status.');
            if strcmp(d.disposition,'EXPLICIT_OUTWARD_TRANSFER')
                pkVerify({d.transfer_reference});refs{end+1,1}=d.transfer_reference;
            elseif ismember(d.disposition,{'LOCAL_DECLARED_CHART_BOUNDARY','REQUESTED_APEX_STOP'})
                basis=d.disposition_basis;pkVerify({d.disposition_reference});refs{end+1,1}=d.disposition_reference;
                assert(strcmp(basis.schema,'PK30h-explicit-local-frontier-disposition-v1')&&strcmp(basis.frontier_id,q.id) ...
                    &&basis.journal_row==k&&strcmp(basis.disposition,d.disposition)&&isequaln(basis.historical_source_reference,q.source_reference) ...
                    &&isequaln(basis.historical_ordered_pair,q.pair)&&isequal(basis.externally_verified,true) ...
                    &&isequal(basis.global_endpoint_claimed,false)&&ischar(basis.scope)&&~isempty(basis.scope), ...
                    'PKFinal:DispositionBasis','Bind caller-verified local/requested evidence to the exact historical obligation without an endpoint upgrade.');
                if strcmp(d.disposition,'LOCAL_DECLARED_CHART_BOUNDARY')
                    assert(isequal(basis.declared_chart_boundary_observed,true)&&strcmp(basis.scientific_scope,'local_declared_chart_only'), ...
                        'PKFinal:LocalBoundary','This typed disposition is limited to the declared chart and pinned observed evidence.');
                else
                    assert(isequal(basis.strict_requested_stop_observed,true)&&strcmp(basis.scientific_scope,'requested_policy_only'), ...
                        'PKFinal:RequestedStop','A strict requested-policy stop is distinct from a mathematical or global endpoint.');
                end
            end
            literal=pkPick(q,{'id','historical_status','role','source_reference','pair','journal_reference','journal_row', ...
                'historical_frontier_state','history_locator','historical_scheduler_policy','historical_policy_scope'});
            mf.historical_obligations{k}=struct('literal',literal,'new_disposition',d,'actual_successor_context',struct(), ...
                'history_scope','The single unchanged original journal remains authority; no history payload is loaded, copied, or replaced by this header.');
        end
        for k=1:7
            at=find(strcmp(roles,baseline{k}));r=cfg.SourceRows{at}.reference;pkCheck(work);ix=BranchSolutionFile_v3.index(r.file);
            headers=cell(numel(ix.points),1);
            for first=1:16:numel(ix.points)
                block=first:min(first+15,numel(ix.points));pkCheck(work);[os,rs]=BranchSolutionFile_v3.loadSolutions(r.file,block);
                for j=1:numel(block),headers{block(j)}=pkInventory(os{j},rs{j},ix.points{block(j)});end
                clear os rs
            end
            mf.original_catalogues{k}=struct('role',baseline{k},'reference',r,'all_occurrences',(1:numel(ix.points)).', ...
                'native_headers',{headers},'physical_edge_count',numel(ix.edges),'coverage_scope','ALL literal stored occurrences; unsupported/current-contract decisions are explicit, never inferred from filename.');
            clear os rs headers
        end
        kinds=cellfun(@(p)p.kind,cfg.ProofRows,'UniformOutput',false);
        assert(nnz(strcmp(kinds,'oldGateB'))==1&&nnz(strcmp(kinds,'generic'))>=4, ...
            'PKFinal:ProofKinds','Keep oldGateB and all four generic finite proofs, plus any explicitly supplied later generic proof.');
        for k=1:numel(cfg.ProofRows)
            p=cfg.ProofRows{k};at=find(strcmp(roles,p.source_role));assert(isscalar(at),'PKFinal:ProofSource','Proof source must be one frozen union input role.');
            r=cfg.SourceRows{at}.reference;[essential_evidence{k},h]=pkProof(r,p.kind,p.role,work);mf.proof_headers{k}=h;
            pkCheckpoint(stage,mf,essential_evidence);pkCheck(work);
        end
        end
        % Full proof triples are durable: loaded unchanged in recovery, never reacquired.
        if recovering,childCap=recovery.ConsolidateSeconds;childBudget=priorConsoBudget;
        else,childCap=cfg.ConsolidateSeconds;childBudget=work;end
        mf.pending_native_call=struct('kind','Consolidate','index',mf.consolidate_calls_invoked+1,'MaxWallSeconds',childCap,'parent_work_limits',work,'actual_child_budget',childBudget);
        mf.consolidation=struct('prepared',true,'invoked',false,'returned',false);pkCheckpoint(stage,mf,essential_evidence);pkFit(work,childCap,2);pkFit(childBudget,childCap,2);
        co=struct('Budget',childBudget,'MaxWallSeconds',childCap,'PackIsolatedRecords',false);if recovering,co.ResumeReceipt=true;end
        mf.consolidate_calls_invoked=mf.consolidate_calls_invoked+1;mf.consolidation.invoked=true;
        if recovering
            nativeProblem=[];
            try
                union=ConsolidateC1ConnectedComponents_v3(files,unionDir,receiptFile,co);
                mf.consolidate_calls_returned=mf.consolidate_calls_returned+1;
                mf.consolidation.returned=true;mf.consolidation.actual_receipt=union;
            catch nativeProblem,mf.consolidation.native_exception=pkFailure(nativeProblem);end
            [observation,immutableRefs]=pkRecoveryReceipt(recovery,receiptFile);mf.recovery.receipt_outcome=observation;refs=[refs;immutableRefs];
            pkCheckpoint(stage,mf,essential_evidence);
            if ~isempty(nativeProblem),rethrow(nativeProblem);end
            assert(observation.original_failed_receipt_preimage_verified,'PKFinal:RecoveryReceipt','Actual successful resume must retain the exact old failed receipt preimage.');
        else
            union=ConsolidateC1ConnectedComponents_v3(files,unionDir,receiptFile,co);
            mf.consolidate_calls_returned=mf.consolidate_calls_returned+1;
            mf.consolidation.returned=true;mf.consolidation.actual_receipt=union;
        end
        pkCheckpoint(stage,mf,essential_evidence);mf.pending_native_call=struct();pkCheck(work);
        assert(union.completed&&union.source_public_readback_verified&&union.source_hashes_verified_after_work ...
            &&union.source_files_deleted==0&&~union.qualification_flags_changed&&isempty(fieldnames(union.failure)) ...
            &&isempty(fieldnames(union.isolated_records_file))&&numel(union.occurrence_map)==union.stored_occurrences, ...
            'PKFinal:Union','Every original occurrence must survive the typed public union with no source deletion or semantic upgrade.');
        mf.source_occurrence_map=union.occurrence_map;pkMapBijection(union,cfg.SourceRows);mf.source_occurrence_bijection_verified=true;
        refs{end+1,1}=pkRef(receiptFile);componentIDs=cell(numel(union.component_files),1);
        for k=1:numel(union.component_files)
            r=union.component_files{k};br=struct('file',r.file,'sha256',r.sha256);refs{end+1,1}=br;pkCheck(work);
            ix=BranchSolutionFile_v3.index(br.file);headers=cell(numel(ix.points),1);
            for first=1:16:numel(ix.points)
                block=first:min(first+15,numel(ix.points));pkCheck(work);[os,rs]=BranchSolutionFile_v3.loadSolutions(br.file,block);
                for j=1:numel(block),headers{block(j)}=pkInventory(os{j},rs{j},ix.points{block(j)});end
                clear os rs
            end
            componentIDs{k}=cellfun(@(h)h.native_id,headers,'UniformOutput',false);
            mf.component_inventory{k}=struct('reference',br,'all_occurrences',(1:numel(ix.points)).','native_headers',{headers}, ...
                'typed_counts',[numel(ix.edges),size(ix.metadata.component_graph.exact_record_equalities,1), ...
                    size(ix.metadata.component_graph.qualified_record_aliases,1),size(ix.metadata.component_graph.qualified_numerical_overlaps,1)], ...
                'isolated',numel(ix.points)==1&&isempty(ix.edges)&&isempty(ix.metadata.component_graph.effective_edges), ...
                'all_layer_component_scope','Actual Consolidate component; P/E/A/M retain separate semantics.');clear os rs headers
        end
        mf.whole_native_id_union=unique(vertcat(componentIDs{:}),'stable');pkOriginalIDs(mf,union,componentIDs);mf.all_original_occurrences_verified=true;
        % Consolidate's public inherited validators checked the unchanged old
        % GateB and generic evidence without reopening archived raw proofs.
        for k=1:numel(essential_evidence)
            pkProofMap(mf.proof_headers{k},essential_evidence{k},union,work);mf.proof_headers{k}.public_union_retained_validation_verified=true;
        end
        javaMethod('createDirectory','java.nio.file.Files',java.io.File(resumeDir).toPath(),javaArray('java.nio.file.attribute.FileAttribute',0));
        for k=1:numel(cfg.CohortRows)
            [h,q,r]=pkResume(cfg.CohortRows{k},cfg.SourceRows,roles,resumeDir,cfg.Generation,k,work);
            mf.closed_cohorts{k}=h;mf.resume_queue{k,1}=q;refs{end+1,1}=r;pkCheckpoint(stage,mf,essential_evidence);pkCheck(work);
        end
        assert(iscell(mf.resume_queue)&&iscolumn(mf.resume_queue)&&~isempty(mf.resume_queue), ...
            'PKFinal:ResumeQueueShape','The existing Queue API requires one nonempty column cell of future jobs.');
        for k=1:13
            d=cfg.HistoricalDispositionRows{k};
            if ~isempty(d.successor_cohort_role)
                at=find(cellfun(@(c)strcmp(c.role,d.successor_cohort_role),mf.closed_cohorts));
                assert(isscalar(at),'PKFinal:Successor','A named historical successor must join one actual closed current cohort.');
                mf.historical_obligations{k}.actual_successor_context=mf.closed_cohorts{at};
            else,assert(~strcmp(d.disposition,'EXPLICIT_OUTWARD_TRANSFER'),'PKFinal:TransferContext','Explicit transfer requires an actual supplied successor context.');end
        end
        mf.core_source_closure_scope='Writer receives opaque external INPUT closure provenance; the same-worker union has no independent process-exit witness yet.';
        javaMethod('createDirectory','java.nio.file.Files',java.io.File(coreDir).toPath(),javaArray('java.nio.file.attribute.FileAttribute',0));
        for k=1:numel(union.component_files)
            br=mf.component_inventory{k}.reference;coreFile=fullfile(coreDir,sprintf('Core29_Component_%04d.mat',k));auditFile=fullfile(coreDir,sprintf('Core29_Component_%04d_Transport.mat',k));
            mf.core_rows{k}=struct('source_reference',br,'output_file',coreFile,'audit_file',auditFile,'prepared',true,'invoked',false,'returned',false,'completed',false,'failure',struct());
            mf.pending_native_call=struct('kind','CoreWriter','index',k,'MaxWallSeconds',cfg.CoreSeconds,'SaveMarginSeconds',cfg.CoreSaveMarginSeconds,'parent_work_limits',work);
            pkCheckpoint(stage,mf,essential_evidence);pkFit(work,cfg.CoreSeconds,2);
            assert(all(cellfun(@(h)isequaln(h.parameter(:),matchedP(:)),mf.component_inventory{k}.native_headers)), ...
                'PKFinal:MatchedPhysicalParameter','The actual full physical parameters must match the declared principal parameter before using the matched v2 cap.');
            wo=struct('Budget',work,'MaxWallSeconds',cfg.CoreSeconds,'SaveMarginSeconds',cfg.CoreSaveMarginSeconds, ...
                'SourceAuditReference',pkRef(receiptFile),'SourceClosureReference',cfg.ClosureReferences{1},'AuditFile',auditFile);
            mf.core_calls_invoked=mf.core_calls_invoked+1;mf.core_rows{k}.invoked=true;
            try
                returned=WriteBranchSolutionCore29_v3(br,1,coreFile,cfg.OriginalV2Reference,wo);
                mf.core_calls_returned=mf.core_calls_returned+1;
                mf.core_rows{k}.returned=true;mf.core_rows{k}.actual_receipt=returned;pkCheckpoint(stage,mf,essential_evidence);pkCheck(work);
                assert(returned.completed&&returned.source_posthash&&returned.retained_projection_read2&&returned.all_native_ids_and_policies_verified ...
                    &&returned.stage_save_returned&&returned.stage_native_read2&&returned.publication_returned&&returned.installed_native_read2 ...
                    &&returned.loader_smoke_returned&&returned.audit_publication_returned&&returned.final_return_timely ...
                    &&returned.core_bytes<=returned.maximum_core_bytes&&~returned.new_admission_claimed, ...
                    'PKFinal:Core','All actual whole-Core/header/readback/publication/cap flags must pass.');
                n=numel(mf.component_inventory{k}.native_headers);
                assert(returned.point_count==n&&returned.source_point_count==n&&isequal(returned.source_indices,(1:n).') ...
                    &&isequal(returned.occurrence_map,[(1:n).',(1:n).'])&&returned.original_v2_bytes==110861 ...
                    &&returned.maximum_core_bytes==554305&&returned.core_bytes<=554305, ...
                    'PKFinal:WholeComponent','Export the whole actual component with required heads before measuring the single reviewed whole-v2 cap.');
                mf.core_rows{k}.completed=true;refs{end+1,1}=pkRef(coreFile);refs{end+1,1}=pkRef(auditFile);
            catch err
                mf.core_rows{k}.failure=pkFailure(err);mf.all_core_exports_completed=false;
                mf.core_rows{k}.retained_stage=pkExisting([coreFile,'.pending.mat']);mf.core_rows{k}.retained_output=pkExisting(coreFile);mf.core_rows{k}.retained_audit=pkExisting(auditFile);
                pkCheckpoint(stage,mf,essential_evidence);break
            end
            mf.pending_native_call=struct();pkCheckpoint(stage,mf,essential_evidence);
        end
        mf.all_core_exports_completed=numel(mf.core_rows)==numel(union.component_files)&&all(cellfun(@(r)r.completed,mf.core_rows));
        pkVerify(refs);if recovering,mf.recovery.active_input_references=refs;else,mf.input_references=refs;end;mf.source_posthash=true;
        mf.completed=mf.source_occurrence_bijection_verified&&mf.all_original_occurrences_verified&&mf.all_core_exports_completed;
        mf.scope='Finite saved union and required headers only. No global endpoint/completeness, new admission, automatic grant renewal, failed-ladder reset, numerical-seam direction transfer or source retirement is claimed.';
    catch err,mf.failure=pkFailure(err);if recovering,mf.recovery.active_input_references=refs;else,mf.input_references=refs;end;end
    pkCheckpoint(stage,mf,essential_evidence);pkCheck(finish);
    % Audit read2 compares all native proof public values and every plain field.
    [a,b]=pkRead2(stage);pkSame(mf,a.final_manifest);pkSame(mf,b.final_manifest);pkSame(public(essential_evidence),public(a.essential_evidence));pkSame(public(essential_evidence),public(b.essential_evidence));
    mf.essential_read2_verified=true;pkCheckpoint(stage,mf,essential_evidence);pkCheck(finish);
    stageSHA=RoundSHA256_v3(stage);javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    [a,b]=pkRead2(output);pkSame(mf,a.final_manifest);pkSame(mf,b.final_manifest);pkSame(public(essential_evidence),public(a.essential_evidence));pkSame(public(essential_evidence),public(b.essential_evidence));
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),stageSHA), ...
        'PKFinal:OwnStage','Unlink only this unchanged linked essential audit stage.');delete(stage);pkCheck(finish);
    auditRef=pkRef(output);pkCampaign(campaign,mf,auditRef);pkVerify(refs);pkCheck(finish);
    result=struct('completed',mf.completed,'source_posthash',mf.source_posthash,'essential_audit_reference',auditRef,'campaign_reference',pkRef(campaign), ...
        'input_count',numel(cfg.SourceRows),'source_occurrences',numel(mf.source_occurrence_map),'unique_native_ids',numel(mf.whole_native_id_union), ...
        'proof_triples',numel(essential_evidence),'historical_obligations',13,'resume_queue_count',numel(mf.resume_queue), ...
        'core_calls_invoked',mf.core_calls_invoked,'core_calls_returned',mf.core_calls_returned,'all_core_exports_completed',mf.all_core_exports_completed, ...
        'future_grant_authorized',false,'future_queue_executed',false,'source_retirement_authorized',false,'own_process_exit_claimed',false);
    fprintf('PK30H_FINAL_UNION_RETURN %s\n',jsonencode(result));
    assert(mf.completed&&mf.source_posthash,'PKFinal:Incomplete','Actual essential audit and partial outputs retained; unresolved union/Core results cannot authorize retirement.');
end


function pkRecoveryContract(r)
    fields={'schema';'FailedEssentialReference';'FailedConsolidationReference';'ClosedWorkerWitness';'SameHostClockWitness'; ...
        'SourceEpochTransitions';'ActiveConsolidationReference';'OutputFile';'CampaignFile';'MaxWallSeconds';'SaveMarginSeconds';'ConsolidateSeconds'};
    assert(isstruct(r)&&isscalar(r)&&isequal(sort(fieldnames(r)),sort(fields))&&strcmp(r.schema,'PK30h-closed-consolidation-recovery-v1'), ...
        'PKFinal:RecoveryContract','Use only the explicit failed-in-Conso recovery contract; no general restart or automatic retry.');
    for name={'MaxWallSeconds','SaveMarginSeconds','ConsolidateSeconds'},validateattributes(r.(name{1}),{'double'},{'real','finite','scalar','positive'});end
    assert(r.SaveMarginSeconds<r.MaxWallSeconds&&iscell(r.SourceEpochTransitions)&&iscolumn(r.SourceEpochTransitions), ...
        'PKFinal:RecoveryCaps','One separately authorized process cap and explicit source epoch map are required.');
end
function [mf,evidence,refs,priorBudget]=pkRecover(r,B,cfg,currentRefs,code,finish,work)
    pkVerify({r.FailedEssentialReference;r.FailedConsolidationReference;r.ActiveConsolidationReference;r.ClosedWorkerWitness.authority_reference;r.SameHostClockWitness.authority_reference});
    assert(strcmp(r.FailedEssentialReference.file,pkLiteral(cfg.EssentialAuditFile)) ...
        &&strcmp(r.FailedConsolidationReference.file,pkLiteral(cfg.ConsolidationReceiptFile)) ...
        &&pkReferenceEqual(r.ActiveConsolidationReference,pkRef(which('ConsolidateC1ConnectedComponents_v3'))), ...
        'PKFinal:RecoveryBindings','Bind the exact failed outputs and separately reviewed current active consolidator.');
    [a,b]=pkRead2(r.FailedEssentialReference.file);mf=a.final_manifest;evidence=a.essential_evidence;
    pkSame(mf,b.final_manifest);pkSame(public(evidence),public(b.essential_evidence));clear a b
    saved=load(r.FailedConsolidationReference.file,'receipt');prior=saved.receipt;clear saved
    assert(strcmp(mf.schema,'PK30h-final-union-essential-resume-manifest-v1')&&~isfield(mf,'recovery')&&isequaln(mf.configuration,cfg) ...
        &&~mf.completed&&~isempty(fieldnames(mf.failure))&&mf.essential_read2_verified&&numel(mf.original_catalogues)==7 ...
        &&numel(cfg.ProofRows)==6&&numel(mf.proof_headers)==6&&numel(evidence)==6 ...
        &&mf.consolidate_calls_invoked==1&&mf.consolidate_calls_returned==0&&mf.consolidation.prepared&&mf.consolidation.invoked&&~mf.consolidation.returned ...
        &&strcmp(mf.pending_native_call.kind,'Consolidate')&&mf.pending_native_call.MaxWallSeconds==cfg.ConsolidateSeconds ...
        &&isempty(mf.component_inventory)&&isempty(mf.closed_cohorts)&&isempty(mf.resume_queue)&&isempty(mf.core_rows) ...
        &&mf.core_calls_invoked==0&&mf.core_calls_returned==0&&~mf.source_occurrence_bijection_verified, ...
        'PKFinal:RecoveryStage','Only this first actual failed in-flight-Conso checkpoint with all six saved proof triples/no postunion calls is supported.');
    for k=1:6
        h=mf.proof_headers{k};v=evidence{k};
        assert(strcmp(h.role,v.role)&&strcmp(h.kind,v.kind)&&isequaln(h.source_reference,v.source_reference) ...
            &&isequaln(h.source_indices,v.source_indices)&&strcmp(h.evidence_digest,C1ScientificDigest_v3(v.evidence)) ...
            &&strcmp(h.full_native_public_digest,C1ScientificDigest_v3(public(v))), ...
            'PKFinal:RecoveryProofBytes','Retain the exact saved native proof triples/digests; do not reacquire or requalify them.');
    end
    priorBudget=prior.budget;expected=pkLimit(mf.original_finish.deadline_unix_seconds-cfg.SaveMarginSeconds,mf.original_finish.deadline_monotonic_ns-cfg.SaveMarginSeconds*1e9);
    assert(strcmp(prior.schema,'C1-connected-component-consolidation-v1')&&~prior.completed&&strcmp(prior.output_directory,pkLiteral(cfg.UnionDirectory)) ...
        &&isequaln(priorBudget,mf.pending_native_call.parent_work_limits)&&isequaln(priorBudget,expected) ...
        &&~isempty(prior.component_files)&&numel(prior.component_files)<prior.output_files&&isempty(fieldnames(prior.isolated_records_file)), ...
        'PKFinal:RecoveryPrefix','Only an incomplete actual committed component prefix with the exact prior parent-WORK budget can resume.');
    for k=1:numel(prior.component_files)
        row=prior.component_files{k};pkVerify({struct('file',row.file,'sha256',row.sha256)});
        assert(isequal(row.whole_public_data_readback_verified,true),'PKFinal:RecoveryPrefixReadback','Every registered prefix row needs its actual completed public readback.');
    end
    w=r.ClosedWorkerWitness;payload=jsondecode(fileread(w.authority_reference.file));pkSame(payload,w.authority_payload);
    needed={'schema','operation','session_id','native_pid','native_start_utc','actual_exit_code','actual_exit_observed_utc', ...
        'native_engine_absence_observed','native_engine_absence_observed_utc','all_owned_native_workers_closed','owned_native_worker_scope', ...
        'external_input_posthash_verified','external_input_posthash_count','native_budget_capture_authority_reference','references','input_postguard','grant','Native_stdout_result', ...
        'scientific_completion_claimed','source_retirement_authorized'};
    assert(isstruct(payload)&&isscalar(payload)&&all(isfield(payload,needed))&&strcmp(payload.schema,'PK30h-external-native-storage-closure-v1') ...
        &&strcmp(payload.operation,'Union01')&&payload.session_id==54897&&payload.native_pid==mf.original_budget.capture.pid ...
        &&strcmp(payload.native_start_utc,'2026-11-02 03:44:56 UTC') ...
        &&payload.native_engine_absence_observed&&payload.all_owned_native_workers_closed&&ischar(payload.owned_native_worker_scope)&&~isempty(payload.owned_native_worker_scope) ...
        &&payload.external_input_posthash_verified&&payload.external_input_posthash_count==130 ...
        &&pkReferenceEqual(payload.native_budget_capture_authority_reference,r.FailedEssentialReference) ...
        &&isequal(payload.scientific_completion_claimed,false)&&isequal(payload.source_retirement_authorized,false), ...
        'PKFinal:RecoveryClosure','The exact decoded ROOT closure supplies actual campaign-owned exit/absence/130-input postguard facts; no future-exit self-certification.');
    validateattributes(payload.actual_exit_code,{'numeric'},{'real','finite','scalar','integer'});
    assert(ischar(payload.actual_exit_observed_utc)&&~isempty(payload.actual_exit_observed_utc) ...
        &&ischar(payload.native_engine_absence_observed_utc)&&~isempty(payload.native_engine_absence_observed_utc), ...
        'PKFinal:RecoveryClosureTimes','Use actual external observed exit/engine-absence times.');
    declared=payload.references;keys={'config','essential','consolidation','launcher','finalizer_source','consolidator_source','log'};
    assert(all(isfield(declared,keys))&&pkReferenceEqual(declared.essential,r.FailedEssentialReference)&&pkReferenceEqual(declared.consolidation,r.FailedConsolidationReference), ...
        'PKFinal:RecoveryClosureReferences','The ROOT closure must bind the exact failed Essential/receipt and original config/source/launcher/log facts.');
    pkVerify({declared.config});saved=load(declared.config.file,'cfg','cfg_digest');assert(strcmp(C1ScientificDigest_v3(saved.cfg),saved.cfg_digest),'PKFinal:RecoveryConfigDigest','Verify the original frozen configuration typed digest.');
    originalCfg=saved.cfg;originalCfg.AllOwnedNativeWorkersClosed=true;pkSame(originalCfg,cfg);clear saved originalCfg
    assert(any(cellfun(@(v)pkReferenceEqual(v,declared.finalizer_source),mf.source_code)) ...
        &&any(cellfun(@(v)pkReferenceEqual(v,declared.consolidator_source),mf.source_code)), ...
        'PKFinal:RecoveryOldSources','Closure source references must be literal original mf source-code rows, not new active provider assertions.');
    pg=payload.input_postguard;assert(pg.all_passed&&pg.count==130&&isfield(pg,'checked_utc')&&isfield(pg,'rows'), ...
        'PKFinal:Recovery130','Bind the complete historical130 check-time rows without rehashing replaced historical live paths.');
    guardRows=pg.rows;if isstruct(guardRows),guardRows=num2cell(guardRows(:));end
    assert(iscell(guardRows)&&numel(guardRows)==130,'PKFinal:Recovery130Rows','Exactly130 actual historical postguard rows are required.');
    for k=1:130
        v=guardRows{k};assert(all(isfield(v,{'file','sha256','bytes','actual_sha256','actual_bytes','pass'}))&&isequal(v.pass,true) ...
            &&strcmp(v.sha256,v.actual_sha256)&&isequal(v.bytes,v.actual_bytes),'PKFinal:Recovery130Row','A check-time external postguard row must record exact expected/actual bytes and SHA.');
    end
    grantKeys={'grant_id','start_utc','research_deadline_utc','deadline_utc'};
    for k=1:4,key=grantKeys{k};assert(strcmp(B.(key),mf.original_budget.(key)),'PKFinal:RecoveryGrant','New process calibration must preserve all four original grant labels.');end
    for k=2:4,key=grantKeys{k};assert(strcmp(payload.grant.(key),mf.original_budget.(key)),'PKFinal:RecoveryClosureGrant','ROOT closure and original native grant UTC labels must agree exactly.');end
    cw=r.SameHostClockWitness;clockPayload=jsondecode(fileread(cw.authority_reference.file));pkSame(clockPayload,cw.authority_payload);
    assert(strcmp(clockPayload.schema,'PK30h-same-host-clock-authority-v1')&&isequal(clockPayload.same_host_and_boot_confirmed,true) ...
        &&isequal(clockPayload.maximum_skew_seconds,1)&&pkReferenceEqual(clockPayload.prior_storage_closure_reference,w.authority_reference), ...
        'PKFinal:RecoveryClockAuthority','The distinct decoded external same-host/boot authority must bind this actual closed old process and declared1-second bound.');
    assert(strcmp(cw.schema,'PK30h-same-host-prior-work-clock-v1')&&isequal(cw.same_host_and_boot_confirmed,true) ...
        &&cw.prior_process_pid==mf.original_budget.capture.pid&&isequaln(cw.prior_budget_capture,mf.original_budget.capture) ...
        &&isequaln(cw.prior_work_limits,priorBudget)&&isequal(cw.maximum_skew_seconds,1), ...
        'PKFinal:RecoveryClockWitness','Supply distinct external same-host/boot authority and literal old capture/WORK, with a declared1-second native skew bound.');
    anchorSkew=abs((B.capture.utc_unix_seconds-mf.original_budget.capture.utc_unix_seconds) ...
        -(B.capture.monotonic_ns-mf.original_budget.capture.monotonic_ns)/1e9);
    nowUTC=pkUTC();nowMono=pkNano();deadlineSkew=abs((priorBudget.deadline_unix_seconds-nowUTC)-(priorBudget.deadline_monotonic_ns-nowMono)/1e9);
    assert(anchorSkew<=cw.maximum_skew_seconds&&deadlineSkew<=cw.maximum_skew_seconds, ...
        'PKFinal:RecoveryClockSkew','Same-host old/new native clock disagreement exceeded1second: anchor=%.17g deadline=%.17g.',anchorSkew,deadlineSkew);
    pkFit(priorBudget,r.ConsolidateSeconds,2);pkFit(work,r.ConsolidateSeconds,2);
    originalRefs=[mf.input_references(:);mf.source_code(:);{declared.finalizer_source;declared.consolidator_source}];
    assert(~any(cellfun(@(v)strcmp(v.file,r.FailedConsolidationReference.file),[originalRefs;currentRefs])), ...
        'PKFinal:RecoveryMutableReference','The intentionally mutable failed receipt path must never enter unchanged active historical verification.');
    [historicalResolved,epochRefs]=pkRecoveryEpoch(originalRefs,r.SourceEpochTransitions,r.ActiveConsolidationReference);
    refs=[currentRefs;historicalResolved;epochRefs;{r.FailedEssentialReference;w.authority_reference;cw.authority_reference;declared.config}];pkVerify(refs);
    history=struct('failed_essential_reference',r.FailedEssentialReference,'failed_consolidation_reference',r.FailedConsolidationReference, ...
        'failed_manifest_typed_digest',C1ScientificDigest_v3(mf),'failed_manifest_source_posthash_literal',mf.source_posthash, ...
        'original_failure',mf.failure,'original_pending_native_call',mf.pending_native_call,'original_consolidation',mf.consolidation, ...
        'original_invoked',mf.consolidate_calls_invoked,'original_returned',mf.consolidate_calls_returned,'failed_essential_read2_verified_literal',mf.essential_read2_verified, ...
        'external_closure_witness',w,'external130postguard_is_distinct_from_failed_native_source_posthash',true, ...
        'same_host_clock_witness',cw,'actual_anchor_skew_seconds',anchorSkew,'actual_deadline_skew_seconds',deadlineSkew, ...
        'prior_consolidation_budget',priorBudget,'source_epoch_transitions',{r.SourceEpochTransitions},'active_source_code',{code}, ...
        'active_input_references',{refs},'process_budget',B,'process_finish',finish,'process_work',work,'process_configuration',r, ...
        'receipt_outcome',struct(),'old_manifest_configuration_source_lists_and_grant_fields_preserved_literal',true,'automatic_retry_authorized',false);
    % Original input/source lists, configuration, original_budget/original_finish
    % remain literal. Only derived current-attempt fields advance in this new audit.
    mf.recovery=history;mf.failure=struct();mf.pending_native_call=struct();mf.consolidation=struct();mf.completed=false;mf.source_posthash=false;mf.essential_read2_verified=false;pkCheck(work);
end
function [resolved,refs]=pkRecoveryEpoch(original,rows,active)
    resolved=cell(size(original));refs=cell(0,1);used=false(numel(rows),1);
    for k=1:numel(rows)
        row=rows{k};assert(isstruct(row)&&isscalar(row)&&isequal(sort(fieldnames(row)),sort({'historical_reference';'retained_preimage_reference';'active_reference';'adoption_reference'})) ...
            &&strcmp(row.historical_reference.sha256,row.retained_preimage_reference.sha256)&&~strcmp(row.historical_reference.file,row.retained_preimage_reference.file) ...
            &&strcmp(row.historical_reference.file,row.active_reference.file)&&~strcmp(row.historical_reference.sha256,row.active_reference.sha256), ...
            'PKFinal:RecoveryEpoch','Only a literal same-path reviewed provider replacement may redirect an old source pin to its exact retained-byte preimage.');
        refs=[refs;{row.retained_preimage_reference;row.active_reference;row.adoption_reference}]; %#ok<AGROW>
    end
    for k=1:numel(original)
        hits=find(cellfun(@(v)pkReferenceEqual(v.historical_reference,original{k}),rows));
        assert(numel(hits)<=1,'PKFinal:RecoveryEpochUnique','Each historical source reference has at most one explicit reviewed epoch transition.');
        if isempty(hits),resolved{k}=original{k};else
            row=rows{hits};resolved{k}=row.retained_preimage_reference;used(hits)=true;
            if isfield(row.historical_reference,'bytes'),resolved{k}.bytes=row.historical_reference.bytes;end
            if isfield(original{k},'bytes')
                assert(~isfield(row.historical_reference,'bytes')||isequaln(original{k}.bytes,row.historical_reference.bytes), ...
                    'PKFinal:RecoveryEpochBytes','Literal historical byte headers must agree before checking the exact retained preimage.');
                resolved{k}.bytes=original{k}.bytes;
            end
        end
    end
    assert(all(used)&&any(cellfun(@(v)pkReferenceEqual(v.active_reference,active),rows)), ...
        'PKFinal:RecoveryEpochActive','Every epoch map row must be consumed, and the separately pinned active consolidator must be an explicit mapped successor.');pkVerify([resolved;refs]);
end
function yes=pkReferenceEqual(a,b)
    yes=isstruct(a)&&isscalar(a)&&isstruct(b)&&isscalar(b)&&all(isfield(a,{'file','sha256'}))&&all(isfield(b,{'file','sha256'})) ...
        &&strcmp(a.file,b.file)&&strcmp(a.sha256,b.sha256);
end
function [observation,refs]=pkRecoveryReceipt(r,file)
    refs=cell(0,1);observation=struct('current_receipt_reference',struct(),'current_receipt_native_read_returned',false, ...
        'original_failed_receipt_reference',r.FailedConsolidationReference,'original_failed_receipt_preimage_verified',false, ...
        'actual_matching_preimage_references',{{}},'observation_failure',struct(),'scope','Actual mutable output/preimage observation only; no native completion or future process-exit claim.');
    try
        observation.current_receipt_reference=pkExisting(file);saved=load(file,'receipt');observation.current_receipt_native_read_returned=true;
        history=pkMember(saved.receipt,'resume_history',cell(0,1));
        for k=1:numel(history)
            v=history{k};ref=pkMember(v,'original_receipt_preimage',struct());
            if isfield(ref,'sha256')&&strcmp(ref.sha256,r.FailedConsolidationReference.sha256)
                pkVerify({ref});refs{end+1,1}=ref;observation.actual_matching_preimage_references{end+1,1}=ref; %#ok<AGROW>
            end
        end
        observation.original_failed_receipt_preimage_verified=~isempty(refs);
    catch e,observation.observation_failure=pkFailure(e);end
end

function [row,h]=pkProof(r,kind,role,clock)
    pkCheck(clock);ix=BranchSolutionFile_v3.index(r.file);g=ix.metadata.component_graph;
    if strcmp(kind,'oldGateB'),schema='C1-qualified-PK-numerical-overlap-v1';else
        assert(strcmp(kind,'generic'),'PKFinal:ProofKind','Only actual oldGateB or generic retained schemas are supported.');schema='C1-qualified-finite-numerical-overlap-v1';
    end
    at=find(cellfun(@(e)strcmp(e.schema,schema),g.numerical_overlap_evidence));
    assert(isscalar(at)&&size(g.qualified_numerical_overlaps,1)==numel(g.numerical_overlap_evidence), ...
        'PKFinal:ProofRow','One explicitly typed retained numerical row must identify the actual source occurrences.');
    pair=g.qualified_numerical_overlaps(at,:);e=g.numerical_overlap_evidence{at};incoming=find(cellfun(@(x)x.to==pair(1),ix.edges));
    assert(isscalar(incoming),'PKFinal:ProofParent','The retained left occurrence needs its actual unique incoming physical edge.');
    edge=ix.edges{incoming};indices=[edge.from,pair];assert(numel(unique(indices))==3 ...
        &&strcmp(ix.points{edge.from}.component_identity,ix.points{pair(1)}.component_identity), ...
        'PKFinal:ProofOwner','Keep the actual distinct same-owner physical parent and both numerical endpoints.');
    [os,rs,ms]=BranchSolutionFile_v3.loadSolutions(r.file,indices);ids=cellfun(@OrbitContentIdentity_v3,os,'UniformOutput',false);
    assert(e.qualified&&e.full_native_proof_validated&&strcmp(ids{1},e.earned_physical_edge.from_native_ID) ...
        &&strcmp(ids{2},e.left_native_ID)&&strcmp(ids{3},e.right_native_ID), ...
        'PKFinal:ProofIDs','Literal full native parent/left/right records must match the unchanged earned proof.');
    if strcmp(kind,'generic'),C1FiniteNumericalOverlap_v3.validateRetained(e,os{2},os{3},rs{2},rs{3},os{1});end
    row=struct('role',role,'kind',kind,'source_reference',r,'source_indices',indices,'source_physical_edge',edge, ...
        'source_numerical_row',pair,'native_ids',{ids},'orbits',{os},'reports',{rs},'original_point_metadata',{ms},'evidence',e, ...
        'scope','Full literal records/reports/classifier/evidence retained; no fresh raw qualification, replay, identity or admission.');
    h=struct('role',role,'kind',kind,'source_reference',r,'source_indices',indices,'native_ids',{ids}, ...
        'evidence_digest',C1ScientificDigest_v3(e),'evidence_schema',e.schema,'original_selectors',{{e.left_selector;e.right_selector}}, ...
        'original_fine_headers',{{e.left_original_fines;e.right_original_fines}},'execution_witness',e.execution_witness, ...
        'full_native_public_digest',C1ScientificDigest_v3(public(row)),'public_union_retained_validation_verified',false);
end
function pkProofMap(h,original,receipt,clock)
    maps=cell(3,1);for k=1:3,maps{k}=pkMapped(receipt,h.source_reference,h.source_indices(k));end
    assert(strcmp(maps{1}.target_file,maps{2}.target_file)&&strcmp(maps{2}.target_file,maps{3}.target_file), ...
        'PKFinal:ProofComponent','An actual retained parent/left/right triple must stay in one union component.');
    indices=cellfun(@(m)m.target_index,maps);file=maps{1}.target_file;ix=BranchSolutionFile_v3.index(file);g=ix.metadata.component_graph;
    assert(any(cellfun(@(e)e.from==indices(1)&&e.to==indices(2),ix.edges)), ...
        'PKFinal:ProofPhysical','The actual source P edge must survive without changing orientation.');
    at=find(g.qualified_numerical_overlaps(:,1)==indices(2)&g.qualified_numerical_overlaps(:,2)==indices(3));
    assert(isscalar(at),'PKFinal:ProofNumerical','The exact oriented numerical row must survive as numerical adjacency.');
    e=g.numerical_overlap_evidence{at};pkSame(original.evidence,e);[os,rs]=BranchSolutionFile_v3.loadSolutions(file,indices);
    for k=1:3,pkSame(public(original.orbits{k}),public(os{k}));pkSame(original.reports{k},rs{k});end
    if strcmp(h.kind,'generic'),C1FiniteNumericalOverlap_v3.validateRetained(e,os{2},os{3},rs{2},rs{3},os{1});end
    pkCheck(clock);
end
function h=pkInventory(o,r,p)
    classFields={'contract_version','synchrony_predicate_version','label','alias','abbreviation','status','validated_gait_type', ...
        'canonical_point_label','canonical_label_qualified','flight_count','flight_count_certain','primitive_flight_count','period_used','descriptive_only','isotropy_proved'};
    primitiveFields={'status','reason','recorded_period','primitive_period','cover_count','drift','primitive_drift','closure_error', ...
        'mode_closed','checked_cover_bound','state_tolerance','event_phase_tolerance','evidence_level','global_primitivity_proved','event_history_complete','proper_apex_count'};
    gates=pkMember(r,'acceptance_gates',struct());g=pkMember(r,'classification',struct());[~,version]=GaitSemanticTable_v3();
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations', ...
        'family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    all9=all(isfield(gates,keys));for k=1:numel(keys),all9=all9&&isequal(pkMember(gates,keys{k},[]),true);end
    current=strcmp(pkMember(g,'contract_version',''),version);accepted=pkMember(r,'accepted',[]);
    qualifiedPK=current&&isequal(accepted,true)&&all9&&strcmp(pkMember(g,'validated_gait_type',''),'PK') ...
        &&strcmp(pkMember(g,'canonical_point_label',''),'PK')&&isequal(pkMember(g,'canonical_label_qualified',false),true) ...
        &&isequal(pkMember(g,'flight_count_certain',false),true)&&isequal(pkMember(g,'flight_count',NaN),1);
    [~,policy]=RecordedReturnPolicy_v3(r);supportedBL=policy.complete&&strcmp(policy.configuration.source_class,'BLMarkedApexReturnPolicy_v3');
    h=struct('index',p.index,'owner',p.component_identity,'native_id',OrbitContentIdentity_v3(o),'saved_metadata_class',p.classification, ...
        'nativeE_index',p.nativeE,'signed_meanU_index',p.signedmeanU,'parameter',o.parameter,'mode',o.initial_mode, ...
        'accepted_present',isfield(r,'accepted'),'accepted_literal_value',accepted,'all9_keys_present',all(isfield(gates,keys)), ...
        'all9_literal_passed',all9,'acceptance_gates',gates,'classifier_head',pkPick(g,classFields), ...
        'primitive_head',pkPick(pkMember(r,'primitive',struct()),primitiveFields),'native_classifier_head',pkPick(o.gait_identification,classFields), ...
        'native_primitive_head',pkPick(o.primitive_cycle,primitiveFields),'current_contract',current,'current_all9_qualified_PK',qualifiedPK, ...
        'complete_recorded_policy',policy,'supported_complete_BL_policy',supportedBL, ...
        'scope','Actual saved headers only; absence/unsupported fields remain explicit. No new classifier or admissibility call.');
end
function pkMapBijection(receipt,rows)
    maps=receipt.occurrence_map;sourceKeys=cell(numel(maps),1);targetKeys=cell(numel(maps),1);
    assert(numel(receipt.source_catalog)==numel(rows),'PKFinal:SourceCount','Every explicit source needs one complete catalogue entry.');
    for k=1:numel(rows)
        r=rows{k}.reference;c=receipt.source_catalog{k};assert(strcmp(c.file,r.file)&&strcmp(c.sha256,r.sha256)&&c.source_public_readback_verified, ...
            'PKFinal:SourceCatalogue','Actual source order/generation and whole-public readback must match.');
        for j=1:c.stored_points,pkMapped(receipt,r,j);end
    end
    for k=1:numel(maps)
        m=maps{k};sourceKeys{k}=sprintf('%s|%s|%d',m.source_file,m.source_sha256,m.source_index);targetKeys{k}=sprintf('%s|%d',m.target_file,m.target_index);
    end
    assert(numel(unique(sourceKeys))==receipt.stored_occurrences&&numel(unique(targetKeys))==receipt.stored_occurrences, ...
        'PKFinal:Bijection','Every input occurrence must map once to a distinct retained output occurrence.');
end
function pkOriginalIDs(mf,receipt,componentIDs)
    componentFiles=cellfun(@(r)r.file,receipt.component_files,'UniformOutput',false);
    for k=1:7
        c=mf.original_catalogues{k};
        for j=1:numel(c.native_headers)
            m=pkMapped(receipt,c.reference,j);at=find(strcmp(componentFiles,m.target_file));
            assert(isscalar(at)&&strcmp(componentIDs{at}{m.target_index},c.native_headers{j}.native_id), ...
                'PKFinal:OriginalIDUnion','ALL original occurrences, including middle occurrences, must retain their actual NativeIDs.');
        end
    end
end
function m=pkMapped(receipt,r,index)
    at=find(cellfun(@(m)strcmp(m.source_file,r.file)&&strcmp(m.source_sha256,r.sha256)&&m.source_index==index,receipt.occurrence_map));
    assert(isscalar(at),'PKFinal:Occurrence','An exact source file/SHA/index must have one actual union destination.');m=receipt.occurrence_map{at};
end
function [h,q,newRef]=pkResume(c,sourceRows,roles,folder,generation,ordinal,clock)
    pkCheck(clock);at=find(strcmp(roles,c.source_role));assert(isscalar(at)&&isequal(c.external_exit_zero_and_postchecks_confirmed,true) ...
        &&isequal(c.returned_persistence_completion_confirmed,true),'PKFinal:ClosedCohort','Caller supplies independently closed actual0/postguards/returned persistence facts.');
    source=sourceRows{at}.reference;pkVerify({source;c.checkpoint_reference;c.closure_reference});x=load(c.checkpoint_reference.file,'summary');cp=x.summary;
    ix=BranchSolutionFile_v3.index(source.file);pair=cp.current_pair(:).';edge=find(cellfun(@(e)isequal([e.from,e.to],pair),ix.edges));
    assert(strcmp(cp.output_file,source.file)&&cp.final_output_count==numel(ix.points)&&isscalar(edge)&&cp.source_posthash ...
        &&isempty(cp.pending_batch)&&isempty(fieldnames(cp.pending_admission))&&~cp.batch_flush_attempted, ...
        'PKFinal:CurrentPair','Bind the clean actual current checkpoint and its ordered physical source pair.');
    [os,rs,ms]=BranchSolutionFile_v3.loadSolutions(source.file,pair);ids=cellfun(@OrbitContentIdentity_v3,os,'UniformOutput',false);
    for k=1:2
        [~,policy]=RecordedReturnPolicy_v3(rs{k});assert(policy.complete&&isequaln(policy.configuration,cp.configuration.policy_configuration), ...
            'PKFinal:ResumePolicy','Keep the exact captured complete return policy on both current anchors.');
    end
    assert(strcmp(ms{1}.component_identity,ms{2}.component_identity)&&strcmp(ms{2}.component_identity,cp.configuration.component_identity), ...
        'PKFinal:ResumeOwner','The actual current pair has one captured physical owner.');
    assert(ischar(c.role)&&~isempty(regexp(c.role,'^[A-Za-z0-9_]+$','once')),'PKFinal:ResumeRole','Use a literal fresh cohort role.');
    file=fullfile(folder,['Resume_',c.role,'.mat']);owner=['PK30h_',generation,'_',c.role,'_future_pair'];points=cell(2,1);
    for k=1:2
        points{k}=struct('component_identity',owner,'classification',ms{k}.classification,'nativeE',ms{k}.nativeE, ...
            'signedmeanU',ms{k}.signedmeanU,'order',k,'edge_enabled',k==2, ...
            'provenance',struct('kind','literal actual physical pair for separately authorized future-grant adoption', ...
                'source_reference',source,'source_index',pair(k),'original_point_metadata',ms{k},'native_id',ids{k}, ...
                'current_checkpoint_reference',c.checkpoint_reference,'external_closure_reference',c.closure_reference,'new_admission_claimed',false));
        if k==2,points{k}.edge_from=1;end
    end
    BranchSolutionFile_v3.initialize(file,struct('schema','PK30h-future-grant-resume-pair-v1','source_reference',source, ...
        'source_pair',pair,'current_checkpoint_reference',c.checkpoint_reference,'physical_edge_scope','Actual original pair remapped1-to2, not a new corrected edge.'));
    BranchSolutionFile_v3.appendBatch(file,os,rs,points);
    for pass=1:2
        [back,br,bm]=BranchSolutionFile_v3.loadSolutions(file,[1;2]);
        for k=1:2,pkSame(public(os{k}),public(back{k}));pkSame(rs{k},br{k});pkSame(points{k},bm{k});end
    end
    newRef=pkRef(file);o=c.queue_job.options;assert(~isfield(o,'Budget')&&~isfield(o,'SourceContext'), ...
        'PKFinal:FutureOptions','Existing Queue supplies a separately authorized future B/context, never a saved runtime budget or context.');
    assert(isfield(cp,'controller_context')&&isfield(cp,'next_step')&&isfield(cp,'next_derivative_index'), ...
        'PKFinal:SavedController','An unbound old controller cannot silently reset a failed radius/method ladder.');
    ctx=cp.controller_context;expanded=cell(0,1);
    pairs={'DerivativeMethod','derivative_method';'FiniteDifferenceSteps','finite_difference_steps'; ...
        'UsePhasePredictor','phase_predictor';'PhaseSeconds','phase_seconds';'AdaptiveStep','adaptive_step'; ...
        'MinimumStep','minimum_step';'MaximumStep','maximum_step';'MaximumCorrectionStepRatio','maximum_correction_step_ratio'; ...
        'MaximumTurnDegrees','maximum_turn_degrees';'CorrectorInitializer','corrector_initializer';'Algorithm','algorithm'};
    for j=1:size(pairs,1)
        key=pairs{j,1};saved=ctx.(pairs{j,2});
        if isfield(o,key),pkSame(o.(key),saved);else,o.(key)=saved;expanded{end+1,1}=key;end
    end
    pkSame(cp.integration_profile,ctx.integration_profile);
    if isfield(o,'IntegrationMaxStep'),pkSame(o.IntegrationMaxStep,ctx.integration_profile.MaxStep);
    else,o.IntegrationMaxStep=ctx.integration_profile.MaxStep;expanded{end+1,1}='IntegrationMaxStep';end
    expected=pkControllerContext(o,struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',o.IntegrationMaxStep));pkSame(expected,ctx);
    validateattributes(cp.next_step,{'numeric'},{'real','finite','scalar','positive','>=',o.MinimumStep,'<=',o.MaximumStep});
    validateattributes(cp.next_derivative_index,{'numeric'},{'real','finite','scalar','integer','>=',1,'<=',numel(o.FiniteDifferenceSteps)});
    controllerPatch=struct('original_queue_initial_step',pkMember(o,'InitialStep',[]), ...
        'original_queue_initial_derivative_index',pkMember(o,'InitialDerivativeIndex',[]), ...
        'actual_saved_next_step',cp.next_step,'actual_saved_next_derivative_index',cp.next_derivative_index, ...
        'omitted_queue_options_expanded_from_actual_CP',{expanded},'exact_context_verified',true,'reset_performed',false);
    o.InitialStep=cp.next_step;o.InitialDerivativeIndex=cp.next_derivative_index;
    o.InPlace=false;o.ComponentIdentity=owner;o.CheckpointFile=fullfile(folder,['Future_',c.role,'_Checkpoint.mat']);
    q=struct('id',sprintf('%s_future_%03d_%s',generation,ordinal,c.role),'historical_status',c.queue_job.historical_status, ...
        'execute',false,'source_reference',newRef,'pair',[1,2],'output_file',fullfile(folder,['Future_',c.role,'.mat']), ...
        'symmetry',cp.configuration.symmetry,'options',o,'role','explicit_future_grant_fresh_fork_not_authorized', ...
        'future_grant_authorized',false,'historical_checkpoint_reference',c.checkpoint_reference, ...
        'scope','READY Queue data only. Future human authorization supplies B and execute=true. Old CP/history/failed ladder remain literal; no automatic renewal or replay.');
    h=struct('role',c.role,'source_reference',source,'current_pair',pair,'native_ids',{ids},'physical_edge',ix.edges{edge}, ...
        'checkpoint_reference',c.checkpoint_reference,'closure_reference',c.closure_reference,'configuration',cp.configuration, ...
        'stored_persistence_completion_confirmed',cp.persistence_completion_confirmed, ...
        'actual_returned_persistence_completion_confirmed',c.returned_persistence_completion_confirmed, ...
        'pending_batch_empty',true,'pending_admission_empty',true,'batch_flush_attempted',cp.batch_flush_attempted, ...
        'future_pair_reference',newRef,'future_pair',[1,2],'future_native_ids',{ids},'native_public_read2_verified',true, ...
        'future_options_declared_patches',{{'InPlace=false';'ComponentIdentity=new owner';'CheckpointFile=fresh future CP';'InitialStep=actual CP next_step';'InitialDerivativeIndex=actual CP next_derivative_index'}}, ...
        'controller_transport',controllerPatch,'actual_controller_context',ctx, ...
        'future_grant_authorized',false,'outward_direction_transfer_claimed',false);
    pkCheck(clock);
end
function c=pkControllerContext(o,integration)
    c=struct('policy_version','phase-or-native-effort-radius-v1','target_iterations',25, ...
        'flat_turn_degrees',5,'sharp_turn_degrees',60, ...
        'derivative_method',o.DerivativeMethod,'finite_difference_steps',o.FiniteDifferenceSteps, ...
        'integration_profile',integration,'phase_predictor',o.UsePhasePredictor,'phase_seconds',o.PhaseSeconds, ...
        'adaptive_step',o.AdaptiveStep,'minimum_step',o.MinimumStep,'maximum_step',o.MaximumStep, ...
        'maximum_correction_step_ratio',o.MaximumCorrectionStepRatio,'maximum_turn_degrees',o.MaximumTurnDegrees, ...
        'corrector_initializer',o.CorrectorInitializer,'algorithm',o.Algorithm);
end
function pkCampaign(file,mf,auditRef)
    stage=[file,'.pending.txt'];
    text=sprintf('# PK30h campaign: %s\n\nEssential native manifest: `%s`\nSHA256: `%s`\n\n',mf.generation,auditRef.file,auditRef.sha256);
    text=[text,sprintf('Completed: %d. Core exports completed: %d. Original occurrence coverage verified: %d.\n\n',mf.completed,mf.all_core_exports_completed,mf.all_original_occurrences_verified)];
    text=[text,sprintf('The original historical journal remains unchanged at `%s` (SHA256 `%s`). All13 statuses, ordered pairs and history locators remain literal.\n\n',mf.configuration.HistoricalJournalReference.file,mf.configuration.HistoricalJournalReference.sha256)];
    for k=1:numel(mf.historical_obligations)
        h=mf.historical_obligations{k};text=[text,sprintf('- Row%d `%s`: historical `%s`; new disposition `%s`.\n',k,h.literal.id,h.literal.historical_status,h.new_disposition.disposition)]; %#ok<AGROW>
    end
    text=[text,sprintf('\nResume Queue data is in the essential native manifest. Entries are execute=false and require a separately authorized future grant/fresh fork. Old CPs/history are preserved; no failed-ladder reset, automatic renewal or source retirement is authorized.\n')];
    text=[text,sprintf('\nP/E/A/M remain physical edges, exact-record storage equalities, qualified aliases and numerical seams. Stored union connectivity is not a global endpoint, unique family, P1 equivalence or outward-direction transfer theorem.\n')];
    javaMethod('createFile','java.nio.file.Files',java.io.File(stage).toPath(),javaArray('java.nio.file.attribute.FileAttribute',0));
    fid=fopen(stage,'w');assert(fid>=0,'PKFinal:Campaign','Open only the newly created own Campaign stage.');closer=onCleanup(@()fclose(fid));
    bytes=unicode2native(text,'UTF-8');assert(fwrite(fid,bytes,'uint8')==numel(bytes),'PKFinal:CampaignWrite','The full Campaign text must be written.');clear closer
    assert(strcmp(fileread(stage),text),'PKFinal:CampaignReadback','The complete owned Campaign text must read back unchanged.');sha=RoundSHA256_v3(stage);
    javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),sha), ...
        'PKFinal:CampaignStage','Delete only the unchanged linked own canonical Campaign stage.');delete(stage);
end
function refs=pkProviders()
    names={'FinalizePK30hUnion20261101','ConsolidateC1ConnectedComponents_v3','WriteBranchSolutionCore29_v3', ...
        'LoadC1SolutionCore29_v3','BranchSolutionFile_v3','C1FiniteNumericalOverlap_v3','QualifyC1PKNumericalOverlap_v3', ...
        'RecordedReturnPolicy_v3','GaitSemanticTable_v3','OrbitContentIdentity_v3','C1ScientificDigest_v3', ...
        'RunC1ContinuationQueue_v3','RunC1Continuation_v3','QuadrupedSchema_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cellfun(@(n)pkRef(which(n)),names(:),'UniformOutput',false);refs{end+1,1}=pkRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function pkCheckpoint(file,mf,evidence)
    final_manifest=mf;essential_evidence=evidence;manifest_digest=C1ScientificDigest_v3(mf);evidence_digest=C1ScientificDigest_v3(public(evidence)); %#ok<NASGU>
    save(file,'final_manifest','essential_evidence','manifest_digest','evidence_digest','-v7');
    x=load(file,'final_manifest','essential_evidence','manifest_digest','evidence_digest');
    pkSame(mf,x.final_manifest);pkSame(public(evidence),public(x.essential_evidence));
    assert(strcmp(manifest_digest,x.manifest_digest)&&strcmp(evidence_digest,x.evidence_digest),'PKFinal:CheckpointDigest','Complete native essential checkpoint digests must agree.');
end
function [a,b]=pkRead2(file)
    a=load(file,'final_manifest','essential_evidence','manifest_digest','evidence_digest');b=load(file,'final_manifest','essential_evidence','manifest_digest','evidence_digest');
    for x={a,b}
        assert(strcmp(C1ScientificDigest_v3(x{1}.final_manifest),x{1}.manifest_digest) ...
            &&strcmp(C1ScientificDigest_v3(public(x{1}.essential_evidence)),x{1}.evidence_digest), ...
            'PKFinal:EssentialRead2','Each independent native essential read must verify all manifest/proof values.');
    end
end
function r=pkExisting(file),r=struct();if isfile(file),r=pkRef(file);info=dir(file);r.bytes=info.bytes;end,end
function v=pkPick(s,keys)
    if ~isstruct(s)||~isscalar(s),v=struct('status','UNSUPPORTED_NONSCALAR_OR_NONSTRUCT','native_class',class(s),'shape',size(s));return;end
    v=struct();for k=1:numel(keys),if isfield(s,keys{k}),v.(keys{k})=s.(keys{k});end,end
end
function v=pkMember(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end
function pkSame(a,b)
    % The unchanged digest first rejects unsupported/sparse/object values and
    % excessive depth in a. Only byte-identical class/shape/plain serialization
    % can skip the second walk; every mismatch uses the original b digest.
    digestA=C1ScientificDigest_v3(a);
    if strcmp(class(a),class(b))&&isequal(size(a),size(b))&&pkPlainSupported(b,0)
        try,if isequal(getByteStreamFromArray(a),getByteStreamFromArray(b)),return;end;catch,end
    end
    assert(strcmp(digestA,C1ScientificDigest_v3(b)),'PKFinal:Typed','Complete declared typed values differ.');
end
function yes=pkPlainSupported(v,depth)
    yes=depth<=128&&~issparse(v);if ~yes,return;end
    if isnumeric(v),yes=any(strcmp(class(v),{'double','single','int8','uint8','int16','uint16','int32','uint32','int64','uint64'}));
    elseif islogical(v)||ischar(v)||isstring(v),return;
    elseif iscell(v),for k=1:numel(v),if ~pkPlainSupported(v{k},depth+1),yes=false;return;end,end
    elseif isstruct(v),names=fieldnames(v);for k=1:numel(v),for j=1:numel(names),if ~pkPlainSupported(v(k).(names{j}),depth+1),yes=false;return;end,end,end
    else,yes=false;end
end
function pkVerify(refs)
    for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,pkLiteral(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
        'PKFinal:Changed','One consumed immutable source/closure/reference changed.');
        if isfield(r,'bytes')
            validateattributes(r.bytes,{'numeric'},{'real','finite','scalar','integer','nonnegative','<=',flintmax});actual=dir(r.file);
            assert(isscalar(actual)&&~actual.isdir&&double(actual.bytes)==double(r.bytes), ...
                'PKFinal:ReferenceBytes','A consumed live file or resolved preimage differs from its literal declared byte count.');
        end
    end
end
function r=pkRef(file),r=struct('file',pkLiteral(file),'sha256',RoundSHA256_v3(file));end
function p=pkLiteral(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKFinal:Alias','Native read/hash must address the same literal path.');end
function f=pkFailure(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function l=pkLimit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function pkCheck(l),assert(pkLeft(l)>0,'PKFinal:Clock','The original parent UTC/JVM clock expired; preserve all actual partial outputs.');end
function pkFit(l,cap,extra),assert(pkLeft(l)>cap+extra,'PKFinal:WholeFit','The full declared native service must fit after the durable prepared checkpoint.');end
function t=pkLeft(l),t=min(l.deadline_unix_seconds-pkUTC(),(l.deadline_monotonic_ns-pkNano())/1e9);end
function t=pkUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=pkNano(),t=double(java.lang.System.nanoTime());end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
