function result=PreparePK30hFrontierClosure20261101(B,options)
%PREPAREPK30HFRONTIERCLOSURE20261101 Bounded saved-state planning, no science service.
    enteredUTC=utc();enteredMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(nargin==2&&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'}))&&isequal(options.MaxWallSeconds,600)&&isequal(options.SaveMarginSeconds,60), ...
        'PKClosure:Options','Use one explicit fresh plan and fixed600/60.');
    assert(B.capture.pid==feature('getpid'),'PKClosure:Budget','Caller calibrates the original grant in this process.');
    finish=lim(min(B.research_deadline_unix_seconds,enteredUTC+600),min(B.research_deadline_monotonic_ns,enteredMono+600e9));
    work=lim(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    file=literal(options.OutputFile);stage=[file,'.pending.mat'];[~,tag,ext]=fileparts(file);
    assert(strcmp(ext,'.mat')&&~isempty(regexp(tag,'^[A-Za-z0-9_]+$','once')) ...
        &&startsWith(file,[literal(fullfile(N,'Audits')),filesep])&&~isfile(file)&&~isfile(stage), ...
        'PKClosure:Fresh','Retain prior plan/stage and use a literal fresh audit MAT.');
    domain=pin(fullfile(N,'Audits','PK30h_20261101_FlightDomain_And_PrimaryRoute.mat'),'5df3268211f06f02258f44ed46cb4622bb8d408c0df33a799b6034470432cd6d');
    survey=pin(fullfile(N,'Audits','PK30h_20261101_Finite13_Coverage.mat'),'0f051fd35c122e57373c22de80a867aeaf42899a2829ba1d119fb5f3b91937c7');
    config=pin(fullfile(N,'Audits','PK30h_20261101_QuietEpoch_Config.mat'),'0c9a86f5d4bae2d8e610e75d57a342eea9cc0469ec6127db8ff6216b9a7f51f0');
    sustained=pin(fullfile(N,'Audits','PK30h_20261101_ProductionSustained01.mat'),'7bc349e102f0cf960bae0ebf8a849a1de65c1bf245dc3228fe88547bddbb224a');
    original=pin(fullfile(N,'Audits','PK30h_20261101_Sustained01_Plan.mat'),'38459ef421412b12dab9eb27afc39c8a77582bebf0ae44bbe25d3f9328c14fb2');
    recovered=pin(fullfile(N,'Audits','PK30h_20261101_Regular_Reconciliation.mat'),'3172e34dc927d857a45c8bcb15939802eb7abe6c449a397efd28aaf436fb58e0');
    recoveredBranch=pin(fullfile(N,'Connected_PK_PK30h_20261101','C1_PK_0062_RegularRecovered.mat'),'c2f4fa0a6bde174b9496ebe327b95e35b2cd6f83b62243aafa38198c12a30ce9');
    campaign=pin(fullfile(N,'Audits','PK30h_20261101_Campaign.mat'),'1ec74f424a23a0e6fd46e4d3c5ebbf81fde8d4fc39e8dcfe68e0019cb2406525');
    catalogue={pin(fullfile(N,'Components','C1_PK_Component_0060.mat'),'cd75c52e77a16082bdc9f2688626a9ebfbd0f2b6131d8d3e205ea9e18bcbb559'); ...
        pin(fullfile(N,'Components','C1_PK_Component_0064.mat'),'966f91ca2be0d21561ee2013e5f2823b6e85c60a24a0abc592d5cbc92a4a3226'); ...
        pin(fullfile(N,'Components','C1_PK_Component_0159.mat'),'482fc1e18e9b1e347512243b8942412ab2da9b4bb616cc7bcc2a367f62c658de')};
    names={'PreparePK30hFrontierClosure20261101','BranchSolutionFile_v3','OrbitContentIdentity_v3','RecordedReturnPolicy_v3', ...
        'MatchingReturnSection_v3','QuadrupedSchema_v3','EnergyFamilyResidual_v3','QuadrupedPhysicalChart_v3','GaitSemanticTable_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Path_v3','V3Root_v3', ...
        'RunC1Continuation_v3','AcquireC1NumericalOverlap_v3','RunC1ContinuationQueue_v3','CoordinatePK30hQuietEpoch20261101','HybridSimulator_v3'};
    code=cellfun(@(n)reference(which(n)),names(:),'UniformOutput',false);
    code{end+1}=reference(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
    refs=[{domain;survey;config;sustained;original;recovered;recoveredBranch;campaign};catalogue;code];verify(refs);check(work);
    assert(strcmp(RoundSHA256_v3(which('HybridSimulator_v3')),'5010b8b7b34554c1a37527c5bf1a2d18375f586cc380b0c7617967d910b64c75'), ...
        'PKClosure:SimulatorSource','Protect the unchanged canonical simulator; never invoke it here.');
    plan=struct('schema','PK30h-frontier-closure-plan-v1','original_budget',B,'options',options,'original_finish',finish, ...
        'input_references',{refs},'source_code',{code},'historical_headers',{{}},'closed_cohorts',{{}},'native_intake',{{}}, ...
        'catalogues',{{}},'candidates',{{}},'association',struct('selected',false,'status','UNASSESSED'), ...
        'pilot_queue',{{}},'completed',false,'source_posthash',false,'failure',struct(), ...
        'public_bulk_calls_attempted',0,'public_bulk_calls_returned',0,'root_map_classifier_ODE_replay_calls',0, ...
        'fresh_admission_claimed',false,'finite_retained_coverage_claimed',false,'global_connection_or_absence_claimed',false);
    try
        x=load(original.file,'plan');old=x.plan;grant(B,old.original_budget);plan.original_plan_reference=original;clear x old
        x=load(domain.file,'audit');D=x.audit;assert(D.completed&&D.source_posthash,'PKClosure:Domain','Require completed saved Domain authority.');grant(B,D.original_budget);
        assert(isfield(D.saved_observations,'historical_headers')&&numel(D.saved_observations.historical_headers)==13, ...
            'PKClosure:Historical','Retain the literal13 Domain historical headers without relabelling.');
        plan.historical_headers=D.saved_observations.historical_headers;clear x D
        x=load(survey.file,'audit');S=x.audit;assert(S.completed&&S.source_posthash&&isempty(S.jobs),'PKClosure:Survey','Require the saved observation-only Survey.');
        x=load(config.file,'config');C=x.config;assert(C.completed&&C.source_posthash,'PKClosure:Config','Require the immutable completed QuietConfig.');grant(B,C.original_budget);
        x=load(sustained.file,'audit');A=x.audit;assert(A.completed&&A.source_posthash&&A.all_requested_jobs_returned ...
            &&numel(A.jobs)==3&&isempty(fieldnames(A.failure)),'PKClosure:Sustained','Require all three closed committed grown outputs.');grant(B,A.budget);
        jobs=cell(3,1);numbers={'0062','0072','0170'};
        for k=1:3
            [jobs{k},r]=closedJob(A,S,N,numbers{k});refs=[refs;r];plan.closed_cohorts{k}=jobs{k}.header; %#ok<AGROW>
        end
        assert(isequal(jobs{1}.pair,[53,54])&&isequal(jobs{3}.pair,[53,54]), ...
            'PKClosure:CurrentPairs','Use the actual current0062 and0170 pairs53/54.');
        baseU=jobs{1}.index.points{54}.signedmeanU;targetIndex=jobs{2}.index;
        rankRows=zeros(0,2);
        for k=1:numel(targetIndex.points)
            u=targetIndex.points{k}.signedmeanU;if isfinite(baseU)&&isfinite(u),rankRows(end+1,:)=[abs(u-baseU),k];end %#ok<AGROW>
        end
        rankRows=sortrows(rankRows,[1,2]);rankRows=rankRows(1:min(8,size(rankRows,1)),:);short=rankRows(:,2);
        plan.shortlist=struct('source0062_base_index',54,'source0062_base_index_meanU',baseU,'target_indices',short, ...
            'metadata_distances',rankRows(:,1),'order','abs(index.signedmeanU-baseU), then literal target index', ...
            'pool','All finite actual grown0072 index occurrences; metadata ranking is selection only.', ...
            'maximum_targets',8,'orientations',[53,54;54,53],'unselected_targets_scope','UNASSESSED; no nearest-native or disconnection claim.');
        chosenIndices={[53;54];short;[53;54]};cache=cell(3,1);
        for k=1:3
            check(work);plan.public_bulk_calls_attempted=plan.public_bulk_calls_attempted+1;
            [os,rs,ms]=BranchSolutionFile_v3.loadSolutions(jobs{k}.reference.file,chosenIndices{k});
            plan.public_bulk_calls_returned=plan.public_bulk_calls_returned+1;
            cache{k}=struct('indices',chosenIndices{k},'orbits',{os},'reports',{rs},'metadata',{ms});
            hs=cell(numel(os),1);for j=1:numel(os),hs{j}=header(os{j},rs{j},ms{j},jobs{k}.index.points{chosenIndices{k}(j)});end
            plan.native_intake{k}=struct('source_reference',jobs{k}.reference,'selected_indices',chosenIndices{k},'headers',{hs}, ...
                'public_bulk_calls',1,'scope','One native public intake, not independent read2 or a new admission.');
            if k~=2
                assert(all(cellfun(@(h)h.saved_current_all9_PK&&h.policy.complete,hs)) ...
                    &&isequaln(hs{1}.policy.configuration,jobs{k}.policy_configuration) ...
                    &&isequaln(hs{2}.policy.configuration,jobs{k}.policy_configuration), ...
                    'PKClosure:CapturedPolicy','Both source anchors must retain the actual captured current PK/policy.');
            end
        end
        pairs=[53,54;54,53];scores=zeros(0,4);
        for rank=1:numel(short)
            for orientation=1:2
                check(work);g=screen(cache{1},cache{2},pairs(orientation,:),short(rank),jobs{1}.index);
                g.target_index=short(rank);g.metadata_rank=rank;g.orientation_rank=orientation;plan.candidates{end+1,1}=g;
                if g.eligible,scores(end+1,:)=[g.predictor_distance,rank,orientation,numel(plan.candidates)];end %#ok<AGROW>
            end
        end
        at=find(cellfun(@(j)strcmp(j.id,'negative-primary'),C.association_jobs));
        assert(isscalar(at)&&isfield(C.association_jobs{at},'overlap_options'),'PKClosure:Clone','Clone actual Config negative-primary overlap options, never defaults.');
        template=C.association_jobs{at}.overlap_options;plan.association_options_basis=struct('config_reference',config,'job_id','negative-primary','original_options',template);
        outbase=fullfile(N,'Connected_PK_PK30h_20261101',[tag,'_0062To0072']);pilotbase=fullfile(N,'Connected_PK_PK30h_20261101',[tag,'_0170Pilot']);
        future={ [outbase,'.mat'];[outbase,'_Checkpoint.mat'];[pilotbase,'.mat'];[pilotbase,'_Checkpoint.mat']; ...
            fullfile(N,'Audits',[tag,'_0062To0072_Acquisition.mat']);[outbase,'_isolated.mat'];[pilotbase,'_isolated.mat']};
        for k=1:numel(future),assert(~isfile(future{k})&&~isfile([future{k},'.pending.mat']),'PKClosure:FutureFresh','Do not replace an earlier future job or stage.');end
        plan.future_output_paths=future;
        if isempty(scores)
            plan.association=struct('selected',false,'status','UNASSESSED_no_eligible_pair_in_declared_shortlist', ...
                'scope','No disconnection, nonexistence, or coverage conclusion.');
        else
            scores=sortrows(scores,[1,2,3]);selected=plan.candidates{scores(1,4)};o=template;
            o.OutputFile=future{5};o.BranchFile=future{1};o.CheckpointFile=future{2};o.SourceAuditReference=struct();
            run=o.RunOptions;run.ComponentIdentity=[tag,'_0062To0072'];run.MaxAccepted=1;run.MaxAttempts=1;run.ReusePreviousJacobian=false;
            run.InitialStep=selected.requested_step;run.CheckpointFile=future{2};o.RunOptions=run;
            plan.association=struct('selected',true,'status','one_eligible0062_to0072_PAL_plane_selected', ...
                'source_reference',jobs{1}.reference,'source_pair',selected.source_pair,'source_native_ids',{selected.source_native_ids}, ...
                'target_reference',jobs{2}.reference,'target_index',selected.target_index,'target_native_id',selected.target_native_id, ...
                'selected_geometry',selected,'overlap_options',o,'source_audit_binding','Caller fills published PlanRef only after plan publication.', ...
                'context_scope','Plain source/index/NativeID/header locator only; Acquire must perform real future public native adoption.');
        end
        prior=jobs{3}.queue;pilot=prior;run=prior.options;
        assert(strcmp(run.Algorithm,'root-newton')&&run.UsePhasePredictor,'PKClosure:PilotBase','Keep the captured phase/root family.');
        patches=struct('InitialStep',.04,'MaximumStep',.08,'MaxAccepted',8,'MaxAttempts',16,'MaxWallSeconds',1200, ...
            'TrialSeconds',180,'PhaseSeconds',30,'BatchSize',4,'SaveMarginSeconds',60,'ReusePreviousJacobian',false, ...
            'InPlace',false,'CheckpointFile',future{4},'ComponentIdentity',[tag,'_0170Pilot']);
        for key=fieldnames(patches).',run.(key{1})=patches.(key{1});end
        pilot.id=[prior.id,'::',tag,'_0170Pilot'];pilot.source_reference=jobs{3}.reference;pilot.pair=[53,54];pilot.output_file=future{3};pilot.options=run;
        pilot.execute=true;pilot.role='fresh0170_current_pair_pilot';plan.pilot_queue={pilot};
        plan.pilot_options_basis=struct('prior_queue_job',prior,'declared_patches',patches,'scope','Only listed patches replace actual prior Queue options. No execution in this helper.');
        x=load(recovered.file,'audit');R=x.audit;rx=BranchSolutionFile_v3.index(recoveredBranch.file);
        assert(R.edge_committed&&R.native_read2_verified&&R.source_posthash&&isequaln(R.branch_reference,recoveredBranch) ...
            &&any(cellfun(@(e)e.from==2&&e.to==3,rx.edges)),'PKClosure:Recovered','Keep the separate actual recovered2-to3 successor.');
        plan.recovered0062_successor=struct('audit_reference',recovered,'branch_reference',recoveredBranch,'pair',[2,3], ...
            'original_source_reference',R.source_reference,'original_source_pair',R.source_pair,'fresh_admission_claimed',false, ...
            'scope','Separate recovered historical admission successor, not a relabelled original frontier.');clear x R rx
        x=load(campaign.file,'state');item=x.state.runs{1}.cases{1};orb=item.orbit;report=item.report;isTraj=isa(orb.trajectory,'Trajectory_v3');
        tmode=orb.trajectory.mode;hasAccepted=isstruct(report)&&isscalar(report)&&isfield(report,'accepted');accepted=[];if hasAccepted,accepted=report.accepted;end
        truth=struct('orbit_is_HybridOrbit_v3',isa(orb,'HybridOrbit_v3'),'report_has_accepted',hasAccepted, ...
            'report_accepted_literal_true',hasAccepted&&isequal(accepted,true),'trajectory_is_Trajectory_v3',isTraj,'mode_isnumeric',isnumeric(tmode));
        plan.held_L37_header=struct('campaign_reference',campaign,'case_locator','state.runs{1}.cases{1}', ...
            'orbit_class',class(orb),'report_accepted_present',hasAccepted,'report_accepted_value',accepted,'trajectory_class',class(orb.trajectory), ...
            'trajectory_mode_class',class(tmode),'trajectory_mode_isnumeric',isnumeric(tmode),'trajectory_mode_islogical',islogical(tmode), ...
            'trajectory_mode_size',size(tmode),'TestL37_conjuncts',truth,'TestL37_all_conjuncts',all(structfun(@(v)v,truth)), ...
            'scope','Literal held-row predicate inspection only. Historical flags/selectors and simulator source are unchanged.');clear x item orb report tmode
        surveyIDs=cell(0,1);
        for k=1:numel(S.inventory),for j=1:numel(S.inventory{k}.rows),surveyIDs{end+1,1}=S.inventory{k}.rows{j}.native_id;end,end %#ok<AGROW>
        for k=1:3
            check(work);ix=BranchSolutionFile_v3.index(catalogue{k}.file);n=numel(ix.points);assert(n>0,'PKClosure:Catalogue','Use a nonempty actual retained index.');
            degree=zeros(n,1);for j=1:numel(ix.edges),e=ix.edges{j};assert(edgeOwner(ix,e),'PKClosure:CatalogueOwner','Retain actual consistent-owner edges.');degree(e.from)=degree(e.from)+1;degree(e.to)=degree(e.to)+1;end
            selected=unique([1;n;find(degree==1)],'stable');selected=selected(1:min(6,numel(selected)));
            plan.public_bulk_calls_attempted=plan.public_bulk_calls_attempted+1;
            [os,rs,ms]=BranchSolutionFile_v3.loadSolutions(catalogue{k}.file,selected);
            plan.public_bulk_calls_returned=plan.public_bulk_calls_returned+1;
            hs=cell(numel(selected),1);
            for j=1:numel(selected),hs{j}=header(os{j},rs{j},ms{j},ix.points{selected(j)});hs{j}.exact_ID_in_loaded_Survey_inventory=any(strcmp(surveyIDs,hs{j}.native_id));end
            owners=unique(cellfun(@(z)z.component_identity,ix.points,'UniformOutput',false));classes=unique(cellfun(@(z)z.classification,ix.points,'UniformOutput',false));
            plan.catalogues{k}=struct('reference',catalogue{k},'point_count',n,'physical_edge_count',numel(ix.edges), ...
                'metadata_owner_values',{owners},'metadata_class_values',{classes},'degree_leaf_count',sum(degree==1),'selected_indices',selected, ...
                'selection','first,last,then increasing actual degree1 index; stable unique, cap6','native_headers',{hs},'public_bulk_calls',1, ...
                'Core_ID_comparison','UNASSESSED_Core_not_loaded','unselected_native_coverage','UNASSESSED', ...
                'scope','Catalogue metadata is accounted; selected NativeID matches do not establish whole-store coverage or classify by filename.');
        end
        verify(refs);plan.input_references=refs;plan.source_posthash=true;plan.completed=true;
        plan.scope='Finite next-action plan only. No global family completion/absence, native acquisition, energy-pivot regularity or event-domain validity is earned.';
    catch e,plan.failure=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);plan.input_references=refs;end
    check(work);C1ScientificDigest_v3(plan);save(stage,'plan','-v7');a=load(stage,'plan');b=load(stage,'plan');same(plan,a.plan);same(plan,b.plan);
    assert(plan.completed&&plan.source_posthash,'PKClosure:Incomplete','Preserve the plain pending plan: %s',jsonencode(plan.failure));
    check(finish);stageSHA=RoundSHA256_v3(stage);assert(~isfile(file),'PKClosure:PublishFresh','Retain any actual concurrent final.');
    javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath()) ...
        &&strcmp(RoundSHA256_v3(stage),stageSHA),'PKClosure:OwnStage','Remove only the unchanged linked own stage.');
    delete(stage);a=load(file,'plan');b=load(file,'plan');same(plan,a.plan);same(plan,b.plan);verify(refs);check(finish);
    result=struct('completed',true,'source_posthash',true,'plan_reference',reference(file),'selected_association',plan.association.selected, ...
        'pilot_queue_count',1,'catalogue_count',3,'public_bulk_calls',plan.public_bulk_calls_returned, ...
        'options',options,'pilot_patches',plan.pilot_options_basis.declared_patches,'selection_scope',plan.shortlist, ...
        'root_map_classifier_ODE_replay_calls',0,'fresh_admission_claimed',false,'finite_retained_coverage_claimed',false);
    if plan.association.selected
        g=plan.association.selected_geometry;
        result.selected_geometry=struct('source_pair',g.source_pair,'source_native_ids',{g.source_native_ids}, ...
            'target_index',g.target_index,'target_native_id',g.target_native_id,'requested_step',g.requested_step, ...
            'predictor_distance',g.predictor_distance,'eligible',g.eligible,'target_is_root_seed',false);
    end
    result.held_L37_header=plan.held_L37_header;result.catalogue_summaries=catalogueSummary(plan.catalogues);
    % Optional stdout cannot invalidate a complete durable plan.
    try
        text=jsonencode(result);
        if numel(unicode2native(text,'UTF-8'))>24000
            text=jsonencode(struct('completed',true,'source_posthash',true,'plan_reference',reference(file), ...
                'selected_association',plan.association.selected,'catalogue_count',3,'pilot_queue_count',1, ...
                'omitted_fields',{{'geometry','fixture_header','catalogue_summaries'}}, ...
                'scope','Complete literal values remain in the published native plan.'));
        end
        fprintf('PK30H_FRONTIER_CLOSURE_PLAN_RETURN %s\n',text);
    catch
        fprintf('PK30H_FRONTIER_CLOSURE_PLAN_RETURN {"completed":true,"source_posthash":true,"optional_output_unavailable":true}\n');
    end
end

function [d,refs]=closedJob(A,S,N,number)
    source=fullfile(N,'Components',['C1_PK_Component_',number,'.mat']);
    q=find(cellfun(@(x)strcmp(x.source_reference.file,source),A.queue));assert(isscalar(q),'PKClosure:Job','Require one declared original source job.');queued=A.queue{q};
    j=find(cellfun(@(x)strcmp(x.id,queued.id),A.jobs));assert(isscalar(j),'PKClosure:Job','Require one actual returned job.');r=A.jobs{j};
    refs={r.output_reference;r.checkpoint_reference};verify(refs);x=load(r.checkpoint_reference.file,'summary');s=x.summary;
    at=find(cellfun(@(x)strcmp(x.id,['current_pair_observation::',queued.id]),S.queue));assert(isscalar(at),'PKClosure:SurveyJoin','Require the exact saved current-pair role.');v=S.queue{at};
    assert(r.persistence_completion_confirmed&&r.pending_count==0&&isempty(s.pending_batch)&&isempty(fieldnames(s.pending_admission)) ...
        &&~s.batch_flush_attempted&&strcmp(r.output_reference.file,queued.output_file)&&strcmp(s.output_file,queued.output_file) ...
        &&isequaln(s.configuration.source_reference,queued.source_reference)&&isequal(s.configuration.source_indices(:),queued.pair(:)) ...
        &&isequaln(v.source_reference,r.output_reference)&&isequaln(v.checkpoint_reference,r.checkpoint_reference) ...
        &&isequal(v.pair(:),s.current_pair(:)),'PKClosure:ClosedCP','Full immutable current checkpoint/Survey/Sustained joins must agree.');
    ix=BranchSolutionFile_v3.index(r.output_reference.file);pair=s.current_pair(:).';
    e=find(cellfun(@(z)isequal([z.from,z.to],pair),ix.edges));
    assert(isscalar(e)&&numel(ix.points)==s.final_output_count&&edgeOwner(ix,ix.edges{e}) ...
        &&strcmp(ix.edges{e}.component_identity,s.configuration.component_identity),'PKClosure:PhysicalPair','Use one actual current owned physical edge.');
    h=struct('job_id',r.id,'output_reference',r.output_reference,'checkpoint_reference',r.checkpoint_reference,'current_pair',pair, ...
        'stored_edge',ix.edges{e},'final_output_count',s.final_output_count,'returned_persistence_completion_confirmed',r.persistence_completion_confirmed, ...
        'checkpoint_provisional_persistence_completion_confirmed',s.persistence_completion_confirmed,'configuration',s.configuration, ...
        'scope','No old input source is reinterpreted as the grown output; original source refs remain historical metadata.');
    d=struct('reference',r.output_reference,'pair',pair,'index',ix,'queue',queued,'policy_configuration',s.configuration.policy_configuration,'header',h);
end
function h=header(o,r,m,p)
    [~,policy]=RecordedReturnPolicy_v3(r);g=member(r,'classification',struct());
    events=o.event_history;eventIDs=[];eventTimes=[];historyAvailable=isstruct(events)&&all(isfield(events,{'is_stop','guard_id','time'}));
    if historyAvailable
        events=events(~[events.is_stop]);s=QuadrupedSchema_v3.shared();eventIDs=zeros(numel(events),1);eventTimes=eventIDs;
        for k=1:numel(events),eventIDs(k)=s.eventId(events(k).guard_id);eventTimes(k)=events(k).time;end
    end
    h=struct('index',p.index,'native_id',OrbitContentIdentity_v3(o),'owner',m.component_identity, ...
        'state',o.initial_state,'parameter',o.parameter,'mode',o.initial_mode,'period',o.period,'stride',o.stride_displacement, ...
        'native_energy_index',p.nativeE,'signed_meanU_index',p.signedmeanU,'policy',policy,'classification',g, ...
        'acceptance_gates',member(r,'acceptance_gates',struct()),'section',o.section_chart, ...
        'section_signature',o.section_relative_event_signature,'cyclic_signature',o.cyclic_event_signature, ...
        'return_multiplicity',o.return_multiplicity,'event_history_available',historyAvailable, ...
        'event_guard_ids',eventIDs,'event_times',eventTimes, ...
        'saved_current_all9_PK',admitted(r),'fresh_admission_claimed',false);C1ScientificDigest_v3(h);
end
function rows=catalogueSummary(catalogues)
    rows=cell(numel(catalogues),1);
    for k=1:numel(catalogues)
        c=catalogues{k};points=cell(numel(c.native_headers),1);
        for j=1:numel(points)
            h=c.native_headers{j};policy=struct('complete',h.policy.complete,'reason',h.policy.reason);
            if h.policy.complete,policy.configuration_digest=C1ScientificDigest_v3(h.policy.configuration);end
            points{j}=struct('index',h.index,'native_id',h.native_id,'owner',h.owner, ...
                'saved_current_all9_PK',h.saved_current_all9_PK,'gait',member(h.classification,'validated_gait_type','UNASSESSED'), ...
                'canonical_label_qualified',member(h.classification,'canonical_label_qualified',false), ...
                'flight_count',member(h.classification,'flight_count',NaN),'flight_count_certain',member(h.classification,'flight_count_certain',false), ...
                'initial_state',h.state,'parameter',h.parameter,'mode',h.mode,'period',h.period, ...
                'policy',policy,'return_multiplicity',h.return_multiplicity,'event_history_available',h.event_history_available, ...
                'event_guard_ids',h.event_guard_ids,'event_times',h.event_times, ...
                'exact_ID_in_loaded_Survey_inventory',h.exact_ID_in_loaded_Survey_inventory);
        end
        rows{k}=struct('reference',c.reference,'point_count',c.point_count,'physical_edge_count',c.physical_edge_count, ...
            'metadata_owner_values',{c.metadata_owner_values},'metadata_class_values',{c.metadata_class_values}, ...
            'selected_indices',c.selected_indices,'selected_headers',{points}, ...
            'unselected_native_coverage',c.unselected_native_coverage,'scope',c.scope);
    end
end
function g=screen(source,target,pair,index,ix)
    g=struct('eligible',false,'source_pair',pair,'failure',struct(),'energy_chart_regularity','UNASSESSED_until_future_native_Run', ...
        'target_is_root_seed',false,'target_scope','Only selects the owned PAL plane.');
    try
        [a,ra,ma]=get(source,pair(1));[b,rb,mb]=get(source,pair(2));[t,rt,mt]=get(target,index);
        g.source_native_ids={OrbitContentIdentity_v3(a);OrbitContentIdentity_v3(b)};g.target_native_id=OrbitContentIdentity_v3(t);
        e=find(cellfun(@(z)isequal(sort([z.from,z.to]),sort(pair)),ix.edges));
        assert(isscalar(e)&&edgeOwner(ix,ix.edges{e})&&strcmp(ma.component_identity,mb.component_identity), ...
            'PKClosure:SourceEdge','Both explicit orientations must bind the same actual owned edge.');g.stored_edge=ix.edges{e};
        assert(admitted(ra)&&admitted(rb)&&admitted(rt),'PKClosure:Admission','Require literal saved current-contract one-flight PK/all9.');
        [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);[~,pt]=RecordedReturnPolicy_v3(rt);
        g.complete_policy_equal=pa.complete&&pb.complete&&pt.complete&&isequaln(pa.configuration,pb.configuration)&&isequaln(pb.configuration,pt.configuration);
        g.exact_pq=isequaln(a.parameter,b.parameter)&&isequaln(b.parameter,t.parameter)&&isequaln(a.initial_mode,b.initial_mode)&&isequaln(b.initial_mode,t.initial_mode);
        g.source_section=MatchingReturnSection_v3(a,b,{ra,rb});g.target_section=MatchingReturnSection_v3(b,t,{rb,rt});
        g.section_tokens_equal=isequaln(a.section_relative_event_signature,b.section_relative_event_signature)&&isequaln(b.section_relative_event_signature,t.section_relative_event_signature);
        g.cyclic_tokens_equal=isequaln(a.cyclic_event_signature,b.cyclic_event_signature)&&isequaln(b.cyclic_event_signature,t.cyclic_event_signature);
        assert(g.complete_policy_equal&&g.exact_pq&&g.source_section.compatible&&g.target_section.compatible ...
            &&g.section_tokens_equal&&g.cyclic_tokens_equal,'PKClosure:Contract','Exact saved policy/pq/marked-section/token contracts differ.');
        assert(~any(b.initial_mode)&&all(isfinite([a.initial_state(:);b.initial_state(:);t.initial_state(:)])), ...
            'PKClosure:FlightChart','Use actual all-flight raw states for the source-backed4D pronk calculation.');
        s=QuadrupedSchema_v3.shared();p=b.parameter(:);x=b.initial_state(:);parameter=s.Parameter;
        defects=[abs(x(s.State.dy)),norm(x([s.State.phi,s.State.dphi]),Inf), ...
            norm(x(s.Leg.AngleIndices)-x(s.State.alphaBL),Inf),norm(x(s.Leg.RateIndices)-x(s.State.dalphaBL),Inf), ...
            norm(p([parameter.k_l_b,parameter.k_s_b,parameter.l_l_b,parameter.rsla_b]) ...
                -p([parameter.k_l_f,parameter.k_s_f,parameter.l_l_f,parameter.rsla_f]),Inf),abs(p(parameter.l_com)-.5)];
        g.source_base_chart_defects=defects;
        assert(all(defects(1:4)<=1e-8)&&all(defects(5:6)<=1e-12), ...
            'PKClosure:PronkChart','The admitted base must satisfy the existing all-flight apex/pronk coordinate preconditions.');
        ids=[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL];
        assert(isequal(ids,[2,3,7,8]),'PKClosure:Coordinates','Retain the actual current four independent raw-coordinate indices.');
        ua=a.initial_state(ids);ua=ua(:);ub=b.initial_state(ids);ub=ub(:);ut=t.initial_state(ids);ut=ut(:);
        lift=b.initial_state(:);lift(ids)=ub;lift([9,11,13])=lift(7);lift([10,12,14])=lift(8);
        assert(isequaln(lift,b.initial_state(:)),'PKClosure:BaseLift','The unchanged admitted base must roundtrip exactly; no snap or projection.');
        scale=max([ones(4,1),abs(ua),abs(ub)],[],2);delta=(ub-ua)./scale;chord=norm(delta);
        assert(isfinite(chord)&&chord>1e-10,'PKClosure:Chord','Use a resolved actual preceding-pair chord.');tangent=delta/chord;
        ds=dot(tangent,(ut-ub)./scale);predictor=ub+scale.*(ds*tangent);
        g.coordinate_indices=ids;g.source_coordinates=[ua,ub];g.target_coordinates=ut;g.scale=scale;g.tangent=tangent;
        g.chord=chord;g.requested_step=ds;g.predictor_coordinates=predictor;g.predictor_distance=norm((ut-predictor)./scale);
        g.source_owner=ma.component_identity;g.target_owner=mt.component_identity;
        g.eligible=isfinite(ds)&&ds>=1e-7&&ds<=.04&&isfinite(g.predictor_distance)&&g.predictor_distance<=.001;
        g.scope='Run243-246 max1 preceding-pair scales and signed projection only; no abs(ds), automatic flip, target seed, Map or energy-pivot test.';
    catch e,g.failure=struct('identifier',e.identifier,'message',e.message);end
end
function [o,r,m]=get(d,index)
    k=find(d.indices==index);assert(isscalar(k),'PKClosure:SelectedIndex','One actual selected native view is required.');o=d.orbits{k};r=d.reports{k};m=d.metadata{k};
end
function yes=admitted(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    gates=member(r,'acceptance_gates',struct());g=member(r,'classification',struct());[~,version]=GaitSemanticTable_v3();
    yes=isequal(member(r,'accepted',false),true)&&all(isfield(gates,keys))&&strcmp(member(g,'contract_version',''),version) ...
        &&strcmp(member(g,'validated_gait_type',''),'PK')&&strcmp(member(g,'canonical_point_label',''),'PK') ...
        &&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1);
    for k=1:numel(keys),yes=yes&&isequal(member(gates,keys{k},false),true);end
end
function yes=edgeOwner(ix,e)
    yes=e.from>=1&&e.to>=1&&e.from<=numel(ix.points)&&e.to<=numel(ix.points) ...
        &&strcmp(ix.points{e.from}.component_identity,e.component_identity)&&strcmp(ix.points{e.to}.component_identity,e.component_identity);
end
function grant(B,old)
    for k={'grant_id','start_utc','research_deadline_utc','deadline_utc'},assert(strcmp(B.(k{1}),old.(k{1})),'PKClosure:Grant','Do not replace or renew the original38459 grant.');end
end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKClosure:Read2','Whole plain plan must agree on native readback.');end
function verify(refs)
    for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKClosure:Changed','An actual consumed input/source changed.');end
end
function r=pin(file,sha),r=struct('file',literal(file),'sha256',sha);end
function r=reference(file),r=pin(file,RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKClosure:Alias','Hash/load must address the same literal path.');end
function v=member(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end
function l=lim(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKClosure:Clock','Original600/60 planning window expired.');end
function x=utc(),x=double(java.time.Instant.now().toEpochMilli())/1000;end
function x=nano(),x=double(java.lang.System.nanoTime());end
