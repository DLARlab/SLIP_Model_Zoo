function report=ReplayEventRestartNativeInputs20261102(work)
%REPLAYEVENTRESTARTNATIVEINPUTS20261102 Literal saved seeds, no correction.
% Nominal replay/explicit metrics are NOT the nine-gate admission service.
% Both engine epochs must invoke this same source and declared profile in
% separate native sessions. No chart reconstruction or symmetry snapping.
    timer=tic;started=stamp();
    V=V3Root_v3();N=fullfile(V,'Research_v3','C1');W=fileparts(mfilename('fullpath'));
    pk=fullfile(N,'Components','C1_PK_Component_0061.mat');
    archived=fullfile(W,'ReplaySources','GenericG_StrictService.mat');
    exported=fullfile(V,'P1_Single_Flight_Phase_Continua','Bifurcation_Audits', ...
        'Strict_Contact_Results','Validated_Generic_Principal_Points','C1_G_10_20_2.mat');
    refs={reference(pk);reference(archived);reference(exported)};
    expected={'821ed8549ec94c7fdd28d5de37579762d0825e277a15be045472c365c01c9486'; ...
        '0e8e12ee0717c0d4ec2bf32e55c8f55073a698cba53fe22151c021e4830505ed'; ...
        'd4d37aa3db32c34298b8e6db13a756e46fba3f6995087f185434545f15e785bb'};
    for k=1:3,assert(strcmp(refs{k}.sha256,expected{k}),'EventNativeReplay:InputHash');end
    names={'EventDetector_v3','HybridSimulator_v3','GuardFunctions_v3','PoincareSection_v3','PoincareMap_v3'};
    code=cellfun(@(n)reference(which(n)),names(:),'UniformOutput',false);
    sharedNames={'Quadrupedal_Dynamics_v3','QuadrupedSchema_v3','HybridSystemBase_v3','ContinuousDynamics_v3', ...
        'ResetMap_v3','ModeTransition_v3','QuadrupedAdmissibility_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3', ...
        'RecordedReturnPolicy_v3','OrbitContentIdentity_v3','C1ScientificDigest_v3','BranchSolutionFile_v3', ...
        'BLMarkedApexReturnPolicy_v3','FirstReturnPolicy_v3','ReturnPolicyBase_v3','EventCluster_v3','SectionModeResolver_v3', ...
        'Trajectory_v3','TouchdownDiagnostics_v3','V3Root_v3','V3Path_v3','RoundSHA256_v3'};
    sharedCode=cellfun(@(n)reference(which(n)),sharedNames(:),'UniformOutput',false);
    check(work);indices=[54;55;56;57];
    [orbits,reports]=BranchSolutionFile_v3.loadSolutions(pk,indices);
    [again,againReports]=BranchSolutionFile_v3.loadSolutions(pk,indices);
    headers=cell(4,1);
    for k=1:4
        headers{k}=sourceHeader(orbits{k},reports{k});other=sourceHeader(again{k},againReports{k});
        assert(strcmp(C1ScientificDigest_v3(headers{k}),C1ScientificDigest_v3(other)), ...
            'EventNativeReplay:Read2','Raw full seed/policy/admission headers must agree across independent native reads.');
        assert(strcmp(member(headers{k}.classification,'validated_gait_type',''),'PK'), ...
            'EventNativeReplay:SavedPK','The four literal source headers must be the saved PK records.');
    end
    g=load(archived,'solution','report');gg=load(archived,'solution','report');
    gh=sourceHeader(g.solution,g.report);gh2=sourceHeader(gg.solution,gg.report);
    assert(strcmp(C1ScientificDigest_v3(gh),C1ScientificDigest_v3(gh2)),'EventNativeReplay:Read2');
    e=load(exported,'solutions','summary');ee=load(exported,'solutions','summary');
    assert(iscell(e.solutions)&&numel(e.solutions)==1&&iscell(ee.solutions)&&numel(ee.solutions)==1 ...
        &&isa(e.solutions{1}.orbit,'HybridOrbit_v3')&&isa(ee.solutions{1}.orbit,'HybridOrbit_v3'),'EventNativeReplay:ExportSchema');
    eh=rawHeader(e.solutions{1}.orbit);eh2=rawHeader(ee.solutions{1}.orbit);
    assert(strcmp(C1ScientificDigest_v3(eh),C1ScientificDigest_v3(eh2)),'EventNativeReplay:ExportRead2');
    rawGEqual=strcmp(C1ScientificDigest_v3(rawHeader(g.solution)),C1ScientificDigest_v3(eh));
    provenance=member(member(e.summary,'provenance',struct()),'original_native_service',struct());
    provenance2=member(member(ee.summary,'provenance',struct()),'original_native_service',struct());
    provenanceEqual=isequaln(provenance,provenance2)&&strcmp(member(provenance,'sha256',''),refs{2}.sha256);
    gExportBinding=struct('raw14_mode_parameter_period_stride_section_exact_bits',rawGEqual, ...
        'source_provenance_sha_matches_archived_service',provenanceEqual, ...
        'exported_point_identity_claimed',rawGEqual&&provenanceEqual, ...
        'archived_native_id',gh.native_id,'exported_native_id',eh.native_id);
    label='archived-G-control';if gExportBinding.exported_point_identity_claimed,label='exported-G-exact-archived-control';end
    defaults=EventDetector_v3();settings=defaults.Options;
    settings.RelTol=1e-13;settings.AbsTol=1e-15;settings.MaxStep=.0005;
    settings.ODEOptions=odeset('OutputFcn',@(~,~,~)budgetOutput(work));settings.FailurePolicy='return';
    profile=settings;profile=rmfield(profile,{'ODESolver','ODEOptions'});profile.ODESolver='ode45';
    profile.ODEOptions=struct('OutputFcn','fixed-native-budget-check-only');
    profile.event_threshold_scope='Current detector defaults, including ArmingTolerance1e-9. Historical saved PK replay used different event thresholds; this is an explicitly fresh matched profile.';
    assert(settings.ArmingTolerance==1e-9&&settings.SimultaneousTimeTolerance==1e-8 ...
        &&settings.EventValueTolerance==1e-8&&settings.EventTimeTolerance==1e-10);
    limits=struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64);
    seeds=cell(6,1);
    for k=1:4,seeds{k}=struct('label',sprintf('PK0061_%d_nominal',indices(k)), ...
            'source_reference',refs{1},'source_index',indices(k),'orbit',orbits{k},'report',reports{k},'header',headers{k}, ...
            'state',orbits{k}.initial_state,'nominal',true,'declared_raw_offset',zeros(14,1));end
    seeds{5}=struct('label',label,'source_reference',refs{2},'source_index',1,'orbit',g.solution, ...
        'report',g.report,'header',gh,'state',g.solution.initial_state,'nominal',true,'declared_raw_offset',zeros(14,1));
    seeds{6}=seeds{1};seeds{6}.label='PK0061_54_raw_BL_angle_plus_1e-7';seeds{6}.nominal=false;
    seeds{6}.declared_raw_offset(7)=1e-7;seeds{6}.state(7)=seeds{6}.state(7)+1e-7;
    rows=cell(0,1);budgetRefusal=false;
    for k=1:numel(seeds)
        if ~hasBudget(work),budgetRefusal=true;break;end
        rows{end+1,1}=oneReplay(seeds{k},settings,limits,work); %#ok<AGROW>
        r=rows{end};fprintf('EVENT_RESTART_NATIVE_REPLAY_POINT %s\n',jsonencode(struct( ...
            'label',r.label,'status',r.status,'map_completed',r.map_completed, ...
            'nominal_metric_conditions_passed',member(r,'nominal_metric_conditions_passed',false),'seconds',r.seconds)));
        if ~hasBudget(work),budgetRefusal=true;break;end
    end
    for k=1:3,assert(strcmp(RoundSHA256_v3(refs{k}.file),refs{k}.sha256));end
    for k=1:numel(code),assert(strcmp(RoundSHA256_v3(code{k}.file),code{k}.sha256));end
    for k=1:numel(sharedCode),assert(strcmp(RoundSHA256_v3(sharedCode{k}.file),sharedCode{k}.sha256));end
    nominal=rows(cellfun(@(r)r.nominal,rows));budgetRefusal=budgetRefusal||~hasBudget(work);
    report=struct('schema','event-restart-literal-native-matched-replay-v1','started_utc',started,'ended_utc',stamp(), ...
        'source_references',{refs},'engine_source_references',{code},'shared_source_references',{sharedCode},'profile',profile,'map_limits',limits, ...
        'generic_export_binding',gExportBinding,'rows',{rows},'completed',numel(rows)==6&&~budgetRefusal,'budget_refusal',budgetRefusal,'source_posthash',true, ...
        'all_nominal_maps_returned',numel(nominal)==5&&all(cellfun(@(r)r.map_completed,nominal)), ...
        'all_nominal_metric_conditions_passed',numel(nominal)==5&&all(cellfun(@(r)member(r,'nominal_metric_conditions_passed',false),nominal)), ...
        'periodic_root_correction_optimizer_classifier_new_admission_calls',0,'seconds',toc(timer), ...
        'scope','Fresh fixed-state map/physics metrics only; saved all9 flags describe their old source epoch. Neither nominal replay nor the off-family raw additive probe is fresh nine-gate admission, a classical derivative, branch ancestry, or historical falseacceptance proof.');
    C1ScientificDigest_v3(report);
end

function row=oneReplay(seed,settings,limits,work)
    timer=tic;x=seed.state;q=seed.orbit.initial_mode;p=seed.orbit.parameter;
    row=struct('label',seed.label,'nominal',seed.nominal,'source_reference',seed.source_reference,'source_index',seed.source_index, ...
        'source_header',seed.header,'literal_initial_state',x,'literal_initial_mode',q,'literal_parameter',p, ...
        'declared_raw_offset',seed.declared_raw_offset,'actual_raw_offset',x-seed.orbit.initial_state, ...
        'status','running','map_completed',false,'initial_projection_exact',false,'failure',struct(),'seconds',NaN);
    phase='setup';
    try
        check(work);schema=QuadrupedSchema_v3.shared();system=Quadrupedal_Dynamics_v3();
        section=PoincareSection_v3.apex(schema.PhaseIndex);projected=section.project(x,p);
        row.initial_projection_delta=projected-x;row.initial_projection_exact=strcmp(C1ScientificDigest_v3(projected),C1ScientificDigest_v3(x));
        assert(row.initial_projection_exact,'EventNativeReplay:ProjectionChangesLiteralSeed', ...
            'UNASSESSED: an initial projection would change the literal full14 source state.');
        [policy,evidence]=RecordedReturnPolicy_v3(seed.report);
        assert(evidence.complete&&isequaln(evidence.configuration,seed.header.recorded_policy.configuration),'EventNativeReplay:Policy');
        row.actual_complete_policy=evidence;simulator=HybridSimulator_v3(settings);
        map=PoincareMap_v3(system,section,simulator,policy,limits);phase='native-map';
        [next,info]=map.evaluate(x,q,p);row.map_completed=true;
        row.actual_initial_state_exact=strcmp(C1ScientificDigest_v3(info.initial_state),C1ScientificDigest_v3(x));
        assert(row.actual_initial_state_exact&&isequaln(info.initial_mode,q),'EventNativeReplay:ChangedLiteralInput');
        row.return_state=next;row.raw_return_state=info.raw_return_state;row.period=info.period;
        row.full_stride_displacement=info.stride_displacement;row.final_mode=info.final_mode;
        delta=next-x;row.full13_residual=delta(2:end);row.full13_norm=norm(row.full13_residual,inf);
        row.map_flags=struct('success',info.success,'valid',info.valid,'admissible',info.admissible, ...
            'integration_success',info.integration_success,'return_policy_accepted',info.return_policy_accepted, ...
            'cycle_complete',info.cycle_complete,'mode_closed',info.discrete_closed);
        row.event_history=eventProjection(info.event_history);row.event_ids=[info.event_history.guard_id];
        row.event_times=[info.event_history.time];row.event_count=numel(info.event_history);
        row.event_signature=info.section_relative_event_signature;row.cohort_signature=info.event_cluster_signature;
        row.cohort_members=info.event_cluster_members;row.cohort_center_times=info.event_cluster_center_times;
        row.event_batches=batchProjection(info.trajectory.event_batches);
        row.event_batch_sizes=arrayfun(@(b)numel(b.event_ids),info.trajectory.event_batches).';
        row.section_chart=info.section_chart;row.return_multiplicity=info.return_multiplicity;
        row.minimum_physical_margins=info.minimum_physical_margins;row.minimum_guard_transversality=info.minimum_guard_transversality;
        row.section_transversality=info.section_transversality;row.section_coincident_events=eventProjection(info.section_coincident_events);
        row.right_continuous_section=strcmp(string(member(info.section_chart,'boundary_ownership','')),"post-reset/right-continuous") ...
            &&isequaln(info.final_mode(:),member(info.section_chart,'contact_mode',[])) ...
            &&isequaln(info.final_mode(:),info.trajectory.termination_mode(:));
        row.arming_restart_diagnostics=cellfun(@(r)member(r,'arming_restart_diagnostics',cell(0,1)),info.phase_results,'UniformOutput',false);
        row.physical_event_digest=C1ScientificDigest_v3(struct('events',{row.event_history},'batches',{row.event_batches}));
        fresh=HybridOrbit_v3(struct('initial_state',x,'initial_mode',q,'parameter',p,'period',info.period, ...
            'stride_displacement',info.stride_displacement,'return_policy_name',policy.Name));
        row.replay_native_id=OrbitContentIdentity_v3(fresh);
        row.raw_replay_digest=C1ScientificDigest_v3(struct('initial_state',x,'mode',q,'parameter',p, ...
            'return_state',next,'raw_return_state',info.raw_return_state,'period',info.period,'stride',info.stride_displacement));
        row.saved_comparison=struct('period_difference',info.period-seed.orbit.period, ...
            'stride_difference',info.stride_displacement-seed.orbit.stride_displacement, ...
            'period_exact_bits',strcmp(C1ScientificDigest_v3(info.period),C1ScientificDigest_v3(seed.orbit.period)), ...
            'stride_exact_bits',strcmp(C1ScientificDigest_v3(info.stride_displacement),C1ScientificDigest_v3(seed.orbit.stride_displacement)), ...
            'native_id_equal',strcmp(row.replay_native_id,seed.header.native_id));
        phase='all-sample-physics-metrics';tr=info.trajectory;n=numel(tr.time);Q=modeRows(tr.mode,n);
        E0=QuadrupedEnergy_v3.evaluate(x,q,p);minimumE=Inf;maximumE=-Inf;maximumVariation=-Inf;maximumConstraint=-Inf;
        energyWorst=struct();constraintWorst=struct();
        for j=1:n
            if mod(j-1,128)==0,check(work);end
            state=tr.state(j,:).';mode=Q(j,:).';E=QuadrupedEnergy_v3.evaluate(state,mode,p);
            chart=QuadrupedPhysicalChart_v3.report(state,mode,p);variation=abs(E-E0);
            minimumE=min(minimumE,E);maximumE=max(maximumE,E);
            if variation>maximumVariation,maximumVariation=variation;energyWorst=struct('index',j,'time',tr.time(j),'state',state,'mode',mode,'energy',E);end
            if chart.maximum_constraint_residual>maximumConstraint
                maximumConstraint=chart.maximum_constraint_residual;constraintWorst=struct('index',j,'time',tr.time(j),'state',state,'mode',mode,'constraint_residual',maximumConstraint);
            end
        end
        row.sample_count=n;row.native_initial_energy=E0;row.energy_range=[minimumE,maximumE];
        row.maximum_energy_variation=maximumVariation;row.maximum_stance_constraint=maximumConstraint;
        row.energy_worst_sample=energyWorst;row.constraint_worst_sample=constraintWorst;
        flags=struct2cell(row.map_flags);basic=all(cellfun(@(v)isequal(v,true),flags));
        row.nominal_metric_conditions_passed=seed.nominal&&basic&&row.full13_norm<=1e-8 ...
            &&maximumVariation<=1e-8&&maximumConstraint<=1e-8&&row.right_continuous_section;
        row.status='native-map-and-metrics-returned';check(work);
    catch exception
        row.status='recorded-native-failure';if strcmp(exception.identifier,'EventNativeReplay:ProjectionChangesLiteralSeed'),row.status='UNASSESSED_projection_changes_seed';end
        row.failure=exceptionData(exception);row.failure.phase=phase;
    end
    row.seconds=toc(timer);C1ScientificDigest_v3(row);
end

function h=sourceHeader(o,r)
    h=rawHeader(o);[~,e]=RecordedReturnPolicy_v3(r);assert(e.complete,'EventNativeReplay:IncompleteSavedPolicy');
    gates=member(r,'acceptance_gates',struct());names={'full_closure','mode_closure','target_energy','trajectory_energy_variation', ...
        'unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    assert(isequal(member(r,'accepted',false),true)&&all(isfield(gates,names)),'EventNativeReplay:SavedAdmission');
    for k=1:numel(names),assert(isequal(gates.(names{k}),true),'EventNativeReplay:SavedAdmission');end
    h.recorded_policy=e;h.old_saved_accepted=true;h.old_saved_acceptance_gates=gates;
    h.classification=selected(member(r,'classification',struct()),{'contract_version','validated_gait_type','canonical_point_label','flight_count','flight_count_certain'});
end
function h=rawHeader(o)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&isequal(size(o.initial_state),[14,1])&&isequal(size(o.parameter),[10,1]) ...
        &&isequal(size(o.initial_mode),[4,1])&&isequal(size(o.stride_displacement),[14,1]),'EventNativeReplay:LiteralShape');
    h=struct('native_id',OrbitContentIdentity_v3(o),'initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter, ...
        'period',o.period,'stride',o.stride_displacement,'section_chart',o.section_chart,'return_policy_name',o.return_policy_name);
end
function out=eventProjection(events)
    out=cell(numel(events),1);keys={'time','guard_id','guard_name','type','state_before','state_after','mode_before','mode_after','value','directional_derivative','is_stop'};
    for k=1:numel(events),out{k}=selected(events(k),keys);out{k}.event_batch_index=member(member(events(k),'metadata',struct()),'event_batch_index',[]);end
end
function out=batchProjection(batches)
    out=cell(numel(batches),1);keys={'time','event_ids','event_names','state_before','state_after','mode_before','mode_after','semantics'};
    for k=1:numel(batches),out{k}=selected(batches(k),keys);out{k}.reset_checks=selected(batches(k).batch_info, ...
            {'atomic','commutativity_checked','reset_order_commutes','transition_order_commutes','independent_rate_projection_verified','commutativity_error'});end
end
function Q=modeRows(q,n)
    if iscell(q),assert(numel(q)==n);Q=cell2mat(cellfun(@(v)v(:).',q(:),'UniformOutput',false));else,Q=q;end
    assert(isequal(size(Q),[n,4])&&all(ismember(Q(:),[0,1])),'EventNativeReplay:TrajectoryMode');
end
function r=reference(file)
    assert(strcmp(char(java.io.File(file).getCanonicalPath()),char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'EventNativeReplay:Alias');
    d=dir(file);assert(isscalar(d));r=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',d.bytes);
end
function out=selected(v,keys)
    out=struct();if ~isstruct(v)||~isscalar(v),return;end
    for k=1:numel(keys),if isfield(v,keys{k}),out.(keys{k})=v.(keys{k});end,end
end
function out=member(v,key,fallback),out=fallback;if isstruct(v)&&isscalar(v)&&isfield(v,key),out=v.(key);end,end
function out=exceptionData(e)
    causes=cell(size(e.cause));for k=1:numel(causes),causes{k}=exceptionData(e.cause{k});end
    out=struct('identifier',e.identifier,'message',e.message,'stack',e.stack,'causes',{causes});
end
function yes=hasBudget(w),yes=posixtime(datetime('now','TimeZone','UTC'))<w.deadline_unix_seconds&&double(java.lang.System.nanoTime())<w.deadline_monotonic_ns;end
function check(w)
    assert(hasBudget(w), ...
        'EventNativeReplay:Budget','Original/local native science budget expired. Preserve partial observations.');
end
function status=budgetOutput(w),check(w);status=0;end
function value=stamp(),value=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end
