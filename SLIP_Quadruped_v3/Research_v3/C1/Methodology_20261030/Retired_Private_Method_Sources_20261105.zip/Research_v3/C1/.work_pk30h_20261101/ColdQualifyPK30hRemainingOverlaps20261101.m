function result=ColdQualifyPK30hRemainingOverlaps20261101(acquireRefs,witnesses,budget,options)
%COLDQUALIFYPK30HREMAININGOVERLAPS20261101 Two selected stored proofs only.
% The original selectors remain literal. New three-record files transport
% actual predecessor/left/right records and evidence; they earn no admission.
    entryUTC=utc();entryMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(iscell(acquireRefs)&&isequal(size(acquireRefs),[2,1]) ...
        &&iscell(witnesses)&&isequal(size(witnesses),[2,1]), ...
        'PKRemainingCold:Inputs','Supply exactly the two closed positive/secondary proofs.');
    assert(isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'OutputAuditFile';'FixtureDirectory'})),'PKRemainingCold:Options','Supply two fresh owned paths.');
    assert(budget.capture.pid==feature('getpid'),'PKRemainingCold:Budget','Calibrate the original UTC grant in this process.');
    finish=limit(min(budget.deadline_unix_seconds,entryUTC+900),min(budget.deadline_monotonic_ns,entryMono+900e9));
    work=limit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=literal(options.OutputAuditFile);stage=[output,'.pending.mat'];folder=literal(options.FixtureDirectory);
    assert(startsWith(output,[literal(fullfile(N,'Audits')),filesep]) ...
        &&startsWith(folder,[literal(fullfile(N,'.work_pk30h_20261101')),filesep]) ...
        &&~isfile(output)&&~isfile(stage)&&~isfolder(folder)&&~isfile(folder), ...
        'PKRemainingCold:Fresh','Use fresh owned paths; preserve uncertain prior publication.');
    code=providers();inputs=[code;acquireRefs];verifyAll(inputs);names={'positive_primary';'secondary'};
    expected={'1d41ac65c49cc78a28bfb345dcfca3e20d3b0a3d459125ce6cc0095c13f8419f'; ...
        '5f9ae7f1da85ae07e0120ac46f135b7bac9182f4ced0c54d46b300fd21e50715'};
    for k=1:2
        assert(strcmp(acquireRefs{k}.sha256,expected{k}), ...
            'PKRemainingCold:Identity','Keep the two declared closed positive/secondary audits in explicit order.');
        w=witnesses{k};assert(strcmp(w.schema,'C1-external-native-process-exit-witness-v1') ...
            &&isequal(w.actual_process_exit_observed,true)&&w.exit_code==0 ...
            &&isequal(w.source_posthash_verified,true)&&isequaln(w.audit_reference,acquireRefs{k}), ...
            'PKRemainingCold:Witness','Actual process exit0 and external postguards must be supplied independently.');
        validateattributes(w.process_session_id,{'numeric'},{'real','finite','scalar','integer','positive'});
        validateattributes(w.child_pid,{'numeric'},{'real','finite','scalar','integer','positive'});
    end
    [ok,message]=mkdir(folder);assert(ok,'PKRemainingCold:Directory','%s',message);
    audit=struct('schema','PK30h-selected-finite-overlap-cold-qualification-v1', ...
        'source_code',{code},'acquire_references',{acquireRefs},'external_witnesses',{witnesses}, ...
        'original_budget',budget,'original_finish',finish,'options',options,'rows',{cell(2,1)}, ...
        'qualifier_calls_attempted',0,'qualifier_calls_returned',0,'source_posthash',false, ...
        'completed',false,'failure',struct(),'root_map_replay_classifier_calls',0, ...
        'new_admission_claimed',false,'new_scientific_edge_created',false,'own_process_exit_claimed',false);
    checkpoint(stage,audit);
    try
        for k=1:2
            check(work);loaded=load(acquireRefs{k}.file,'audit');a=loaded.audit;
            assert(strcmp(a.schema,'C1-finite-owned-PAL-numerical-overlap-experiment-v1') ...
                &&a.completed&&a.source_posthash&&a.ordinary_edge_earned&&a.qualified_numerical_relation ...
                &&a.fine_calls_attempted==4&&a.fine_calls_returned==4&&isempty(fieldnames(a.failure)), ...
                'PKRemainingCold:Acquire','Use actual completed qualified finite experiments.');
            rowInputs=[a.source_code;{a.run_branch_reference;a.run_checkpoint_reference;a.target_reference;a.source_reference}];
            inputs=[inputs;rowInputs];verifyAll(rowInputs); %#ok<AGROW>
            [leftPair,leftReports,leftMetadata]=BranchSolutionFile_v3.loadSolutions(a.run_branch_reference.file,[2;3]);
            [target,targetReports,targetMetadata]=BranchSolutionFile_v3.loadSolutions(a.target_reference.file,a.target_index);
            left=struct('file',a.run_branch_reference.file,'sha256',a.run_branch_reference.sha256, ...
                'index',3,'native_ID',OrbitContentIdentity_v3(leftPair{2}));
            right=struct('file',a.target_reference.file,'sha256',a.target_reference.sha256, ...
                'index',a.target_index,'native_ID',OrbitContentIdentity_v3(target{1}));
            proof=struct('schema','C1-finite-owned-PAL-numerical-overlap-proof-v1', ...
                'audit_reference',acquireRefs{k},'execution_witness',witnesses{k}, ...
                'left_selector',left,'right_selector',right,'validation_limits',work);
            row=struct('name',names{k},'acquire_reference',acquireRefs{k},'original_proof',proof, ...
                'qualified',false,'evidence',struct(),'retained_reference',struct(), ...
                'full_native_read2_verified',false,'complete_policy_read2_verified',false);
            audit.rows{k}=row;checkpoint(stage,audit);
            fprintf('PK_REMAINING_COLD_QUALIFY_BEGIN %s\n',names{k});
            audit.qualifier_calls_attempted=audit.qualifier_calls_attempted+1;
            e=C1FiniteNumericalOverlap_v3.qualify(leftPair{2},target{1},leftReports{2},targetReports{1},proof);
            audit.qualifier_calls_returned=audit.qualifier_calls_returned+1;row.evidence=e;row.qualified=true;
            audit.rows{k}=row;checkpoint(stage,audit);check(work);
            % The earned proof is already durable before transport bookkeeping.
            file=fullfile(folder,['Retained_',names{k},'.mat']);
            os={leftPair{1};leftPair{2};target{1}};rs={leftReports{1};leftReports{2};targetReports{1}};
            original={leftMetadata{1};leftMetadata{2};targetMetadata{1}};ms=cell(3,1);
            sourceRefs={a.run_branch_reference;a.run_branch_reference;a.target_reference};sourceIndices=[2,3,a.target_index];
            for n=1:3
                m=original{n};owner=['PK30h_ColdRetained_',names{k},'_source'];order=n;
                if n==3,owner=['PK30h_ColdRetained_',names{k},'_target'];order=1;end
                ms{n}=struct('component_identity',owner,'classification',m.classification, ...
                    'nativeE',m.nativeE,'signedmeanU',m.signedmeanU,'order',order,'edge_enabled',n==2, ...
                    'provenance',struct('kind','literal retained finite-proof record transport', ...
                        'source_reference',sourceRefs{n},'source_index',sourceIndices(n), ...
                        'original_point_metadata',m,'native_id',OrbitContentIdentity_v3(os{n}), ...
                        'fresh_admission_claimed',false,'original_scientific_flags_changed',false));
                if n==2,ms{n}.edge_from=1;end
            end
            fragment=struct('qualified_numerical_overlaps',[2,3],'numerical_overlap_evidence',{{e}});
            BranchSolutionFile_v3.initialize(file,struct('schema','PK30h-selected-retained-finite-three-records-v1', ...
                'acquire_reference',acquireRefs{k},'component_graph',fragment, ...
                'new_scientific_edge_created',false,'physical_edge_scope','Actual earned predecessor2-to3 remapped1-to2; target remains NONEDGE.'));
            BranchSolutionFile_v3.appendBatch(file,os,rs,ms);
            for pass=1:2
                [back,br,bm]=BranchSolutionFile_v3.loadSolutions(file,1:3);
                for n=1:3
                    same(public(os{n}),public(back{n}));same(rs{n},br{n});same(ms{n},bm{n});
                    same(original{n},bm{n}.provenance.original_point_metadata);
                    assert(strcmp(OrbitContentIdentity_v3(back{n}),OrbitContentIdentity_v3(os{n})), ...
                        'PKRemainingCold:NativeID','Every transported full record must retain its actual NativeID.');
                    samePolicy(rs{n},br{n});
                end
            end
            ix=BranchSolutionFile_v3.index(file);
            assert(numel(ix.points)==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2 ...
                &&~bm{1}.edge_enabled&&bm{2}.edge_enabled&&~bm{3}.edge_enabled, ...
                'PKRemainingCold:Graph','Only the actual earned predecessor edge is remapped.');
            same(e,ix.metadata.component_graph.numerical_overlap_evidence{1});
            C1FiniteNumericalOverlap_v3.validateRetained(e,back{2},back{3},br{2},br{3},back{1});
            row.retained_reference=ref(file);row.original_point_metadata=original;row.source_indices=sourceIndices;
            row.original_physical_edge=[2,3];row.retained_physical_edge=[1,2];row.retained_numerical_row=[2,3];
            row.full_native_read2_verified=true;row.complete_policy_read2_verified=true;
            audit.rows{k}=row;inputs{end+1,1}=row.retained_reference;checkpoint(stage,audit);check(work);
            fprintf('PK_REMAINING_COLD_QUALIFY_RETURN %s\n',jsonencode(struct('name',names{k},'qualified',true, ...
                'retained_reference',row.retained_reference,'full_native_read2_verified',true)));
        end
        verifyAll(inputs);audit.source_posthash=true;audit.completed=true;
    catch exception
        audit.failure=struct('identifier',exception.identifier,'message',exception.message,'stack',exception.stack);
    end
    checkpoint(stage,audit);check(finish);
    assert(audit.completed&&audit.source_posthash,'PKRemainingCold:Incomplete', ...
        'Retain partial qualification evidence and exact fixtures: %s',jsonencode(audit.failure));
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    back=load(output,'audit');same(audit,back.audit);delete(stage);check(finish);
    result=struct('completed',true,'source_posthash',true,'audit_reference',ref(output), ...
        'retained_references',{{audit.rows{1}.retained_reference;audit.rows{2}.retained_reference}}, ...
        'qualifier_calls_attempted',audit.qualifier_calls_attempted,'qualifier_calls_returned',audit.qualifier_calls_returned, ...
        'root_map_replay_classifier_calls',0,'own_process_exit_claimed',false);
    fprintf('PK_REMAINING_COLD_RETURN %s\n',jsonencode(result));
end
function refs=providers()
    names={'ColdQualifyPK30hRemainingOverlaps20261101','C1FiniteNumericalOverlap_v3','AcquireC1NumericalOverlap_v3', ...
        'BranchSolutionFile_v3','HybridOrbit_v3','Trajectory_v3','RecordedReturnPolicy_v3', ...
        'OrbitContentIdentity_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cell(numel(names),1);for k=1:numel(names),refs{k}=ref(which(names{k}));end
    refs{end+1,1}=ref(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function samePolicy(a,b)
    [~,x]=RecordedReturnPolicy_v3(a);[~,y]=RecordedReturnPolicy_v3(b);
    assert(x.complete&&y.complete,'PKRemainingCold:Policy','Require complete actual recorded policy settings.');same(x.configuration,y.configuration);
end
function checkpoint(file,audit),save(file,'audit','-v7');back=load(file,'audit');same(audit,back.audit);end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKRemainingCold:Readback','Complete declared typed values differ.');end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
function verifyAll(refs),for k=1:numel(refs),verify(refs{k});end,end
function verify(r),assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKRemainingCold:Source','Immutable literal authority changed.');end
function r=ref(file),r=struct('file',literal(file),'sha256',RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKRemainingCold:Alias','Hash and native read must address the same file.');end
function l=limit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKRemainingCold:Clock','Original900/60 clock expired.');end
function v=utc(),v=posixtime(datetime('now','TimeZone','UTC'));end
function v=nano(),v=double(java.lang.System.nanoTime());end
