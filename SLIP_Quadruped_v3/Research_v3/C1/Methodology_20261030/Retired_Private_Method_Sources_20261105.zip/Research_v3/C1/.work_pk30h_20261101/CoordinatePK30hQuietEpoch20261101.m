function result=CoordinatePK30hQuietEpoch20261101(mode,sustainedAuditRef,budget)
%COORDINATEPK30HQUIETEPOCH20261101 Explicit finite experiments, one per process.
% prepare performs stored intake/constructor arithmetic only. Each overlap:
% job mode offers ONE actual owned pair to Acquire; its target is not a seed.
% All process exits/postguards remain external facts, never stored assertions.
    entryUTC=utc();entryMono=nano();mode=char(mode);V=V3Root_v3();N=fullfile(V,'Research_v3','C1');
    assert(budget.capture.pid==feature('getpid'),'PKQuiet:Budget','Use this process calibration of the original grant.');
    assert(nargin('RunC1PKFlightGrazingStudy_v3')==3&&nargin('AcquireC1NumericalOverlap_v3')==6 ...
        &&nargin('ReconcilePK30hRegular20261101')==0,'PKQuiet:Parse','Required worker interfaces differ.');
    classes={'SynchronousPKPhaseResidual_v3','SynchronousPKFlightGrazingResidual_v3','C1FiniteNumericalOverlap_v3'};
    for k=1:numel(classes),assert(~isempty(meta.class.fromName(classes{k})),'PKQuiet:Parse','Class %s is unavailable.',classes{k});end
    configFile=fullfile(N,'Audits','PK30h_20261101_QuietEpoch_Config.mat');
    if strcmp(mode,'prepare')
        result=prepare(N,configFile,sustainedAuditRef,budget,entryUTC,entryMono);return
    end
    verify(sustainedAuditRef);assert(isfile(configFile),'PKQuiet:Config','Prepare one closed immutable native config first.');
    configRef=ref(configFile);loaded=load(configFile,'config');c=loaded.config;
    assert(c.completed&&c.source_posthash&&isequaln(c.sustained_audit_reference,sustainedAuditRef), ...
        'PKQuiet:Config','The exact prepared sustained generation is required.');
    for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'}
        assert(strcmp(c.original_budget.(key{1}),budget.(key{1})),'PKQuiet:Grant','Do not renew or replace the original grant.');
    end
    verifyCode(c.source_code);verifyAll([c.input_references;{configRef}]);
    if strcmp(mode,'grazing')
        requireFit(budget,900);
        context=c.grazing_context;
        o=struct('OutputFile',fullfile(N,'Audits','PK30h_20261101_Secondary0072_FlightGrazing.mat'), ...
            'PhaseSeconds',240,'NativeSeconds',300,'MaxWallSeconds',900,'StencilOffset',1e-6);
        s=RunC1PKFlightGrazingStudy_v3(context,budget,o);
        result=struct('mode',mode,'completed',s.completed,'source_posthash',s.source_posthash, ...
            'native_all_nine',s.native_all_nine,'output_reference',ref(o.OutputFile));
    elseif strcmp(mode,'reconcile')
        requireFit(budget,300);
        a=ReconcilePK30hRegular20261101();
        result=struct('mode',mode,'completed',a.source_posthash&&a.native_read2_verified, ...
            'source_posthash',a.source_posthash,'native_read2_verified',a.native_read2_verified, ...
            'edge_committed',a.edge_committed,'audit_reference',ref(fullfile(N,'Audits','PK30h_20261101_Regular_Reconciliation.mat')), ...
            'branch_reference',a.branch_reference,'fresh_admission_claimed',false, ...
            'scope','New capture/storage observation of the historical pending admission; original failed flags remain literal.');
    elseif startsWith(mode,'overlap:')
        name=extractAfter(mode,'overlap:');at=find(cellfun(@(j)strcmp(j.id,name),c.association_jobs));
        assert(isscalar(at),'PKQuiet:Job','Name one prepared association job explicitly.');j=c.association_jobs{at};
        if ~j.selected
            result=struct('mode',mode,'completed',true,'status','UNASSESSED_no_eligible_declared_shortlist_pair', ...
                'root_calls',0,'selected',false,'config_reference',configRef);
        else
            requireFit(budget,1800);
            o=j.overlap_options;o.SourceAuditReference=configRef;
            a=AcquireC1NumericalOverlap_v3(j.source_reference,j.source_pair,j.target_reference,j.target_index,budget,o);
            result=struct('mode',mode,'completed',a.completed,'status',a.status,'source_posthash',a.source_posthash, ...
                'ordinary_edge_earned',a.ordinary_edge_earned,'qualified_numerical_relation',a.qualified_numerical_relation, ...
                'fine_calls_attempted',a.fine_calls_attempted,'fine_calls_returned',a.fine_calls_returned, ...
                'output_reference',ref(o.OutputFile));
        end
    else,error('PKQuiet:Mode','Use prepare, grazing, reconcile, or overlap:<declared-job>.');end
    verifyCode(c.source_code);verifyAll([c.input_references;{configRef}]);
    fprintf('PK_QUIET_MODE_RETURN %s\n',jsonencode(result));
end

function result=prepare(N,file,sustainedRef,budget,entryUTC,entryMono)
    finish=limit(min(budget.research_deadline_unix_seconds,entryUTC+600), ...
        min(budget.research_deadline_monotonic_ns,entryMono+600e9));
    work=limit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    stage=[file,'.pending.mat'];assert(~isfile(file)&&~isfile(stage),'PKQuiet:Fresh','Retain prior config or pending custody.');
    code=providers();verifyCode(code);verify(sustainedRef);
    loaded=load(sustainedRef.file,'audit');a=loaded.audit;
    assert(strcmp(a.schema,'resident-native-frontier-queue-v1')&&a.completed&&a.source_posthash ...
        &&a.all_requested_jobs_returned&&numel(a.jobs)==3&&isempty(fieldnames(a.failure)), ...
        'PKQuiet:Sustained','Only the completed, externally closed three-job sustained audit may be supplied.');
    raw03=authority(fullfile(N,'Connected_PK_PKConnected03_20261029','C1_PK_Component_0001.mat'), ...
        '2ca5aa4a2e64ac80f2d2bb95d17379857bc38661a5f13a0bd0d63d34c0b06962');
    old62=authority(fullfile(N,'Components','C1_PK_Component_0062.mat'), ...
        '11f897b8cdedf7e39ad4b43abcdba6af25a81406461e68ceef482de8e9a63437');
    old72=authority(fullfile(N,'Components','C1_PK_Component_0072.mat'), ...
        'f2f62cc9de65cb39cece67a1de60ca058db0be8863b87e229c1440a12e939ec7');
    controls={authority(fullfile(N,'Audits','PK30h_20261101_PrimaryNegative_Boundary01.mat'), ...
        'f12b3979e095fecb6921f861b68c2125b30d05c0206673b28a434887f9ca6ac0'); ...
        authority(fullfile(N,'Audits','PK30h_20261101_PrimaryPositive_Boundary01.mat'), ...
        '9ef0da5c7de933b932c2fbce21d3685ccc78475dd53bb6043d233e1c6f82e363')};
    refs=[{sustainedRef;raw03;old62;old72};controls];verifyAll(refs);
    c=struct('schema','PK30h-explicit-quiet-epoch-config-v1','original_budget',budget, ...
        'sustained_audit_reference',sustainedRef,'source_code',{code},'input_references',{refs}, ...
        'historical_contexts',struct('grown0062_original_pair',[59,60],'grown0072_original_pair',[151,152], ...
            'regular_pending0062_pair',[63,64],'grazing0072_pair',[5,6]), ...
        'last_saved_attempts',{{}},'boundary_control_transport',struct(),'association_jobs',{{}}, ...
        'selection_intake',{{}},'root_map_classifier_ode_calls',0,'fresh_admission_claimed',false, ...
        'search_completion_claimed',false,'source_posthash',false,'completed',false,'failure',struct(), ...
        'external_closure_scope','Caller supplies the exact closed Queue authority after actual exit and postguards. Stored complete/sourcepost flags do not establish process exit.', ...
        'selection_scope','Eight metadata-ranked combinations PER obligation, at most24 total/72 selected occurrences before deduplication. Other pairs remain UNASSESSED. No nearest-orbit or global-absence claim.');
    try
        % All three actual checkpoint histories are retained, even though only
        % the two declared secondary jobs participate in that association.
        closedIndexes=cell(3,1);
        for k=1:3
            check(work);j=a.jobs{k};assert(all(isfield(j,{'id','checkpoint_reference','output_reference', ...
                'pending_count','persistence_completion_confirmed','seconds'}))&&j.pending_count==0 ...
                &&j.persistence_completion_confirmed,'PKQuiet:Pending','Every requested job must have returned with committed custody.');
            verify(j.checkpoint_reference);verify(j.output_reference);
            refs=[refs;{j.checkpoint_reference;j.output_reference}]; %#ok<AGROW>
            saved=load(j.checkpoint_reference.file,'summary');s=saved.summary;
            q=find(cellfun(@(p)strcmp(p.id,j.id),a.queue));
            assert(isscalar(q),'PKQuiet:Checkpoint','Each returned checkpoint needs one original Queue job.');queued=a.queue{q};
            verify(queued.source_reference);refs=[refs;{queued.source_reference}]; %#ok<AGROW>
            assert(isempty(s.pending_batch)&&isempty(fieldnames(s.pending_admission))&&~s.batch_flush_attempted, ...
                'PKQuiet:Pending','Pending or uncertain commit requires reconciliation before another solve.');
            assert(queued.execute&&strcmp(s.output_file,j.output_reference.file)&&strcmp(queued.output_file,s.output_file) ...
                &&strcmp(s.configuration.source_file,queued.source_reference.file) ...
                &&isequaln(s.configuration.source_reference,queued.source_reference) ...
                &&isequal(s.configuration.source_indices(:),queued.pair(:))&&s.final_output_count>=2, ...
                'PKQuiet:Checkpoint','The checkpoint must bind its exact Queue source, original pair and returned output.');
            closedIndexes{k}=BranchSolutionFile_v3.index(j.output_reference.file);
            assert(numel(closedIndexes{k}.points)==s.final_output_count ...
                &&any(cellfun(@(e)isequal([e.from,e.to],s.current_pair(:).'),closedIndexes{k}.edges)) ...
                &&all(cellfun(@(p)strcmp(p.component_identity,s.configuration.component_identity),closedIndexes{k}.points(s.current_pair))), ...
                'PKQuiet:CurrentPair','The exact closed checkpoint current pair must be a committed physical edge.');
            c.last_saved_attempts{end+1,1}=attemptMetrics(j,s);
            fprintf('PK_QUIET_ATTEMPT_METRICS %s\n',jsonencode(metricSummary(c.last_saved_attempts{end})));
        end
        grown={grownJob(a,'PK_file_0003_graph_0001_leaf_000003',old62,[59,60]); ...
            grownJob(a,'PK_file_0005_graph_0001_leaf_000045',old72,[151,152])};
        branch=fullfile(N,'Connected_PK_PK30h_20261101','C1_PK_PrimaryBoundary_Inward_Controls.mat');
        [transport,cache]=transportControls(branch,controls,raw03,work);
        c.boundary_control_transport=transport;refs=[refs;{transport.branch_reference}];
        sourceRefs={raw03;grown{1}.output_reference;grown{2}.output_reference;transport.branch_reference};
        indexes=cell(4,1);check(work);indexes{1}=BranchSolutionFile_v3.index(raw03.file);
        for k=1:2
            slot=find(cellfun(@(j)strcmp(j.id,grown{k}.id),a.jobs));indexes{k+1}=closedIndexes{slot};
        end
        indexes{4}=cache.index;
        specs={struct('id','negative-primary','priority',1,'source_slots',1,'target_slots',4,'target_indices',1); ...
            struct('id','positive-primary','priority',2,'source_slots',1,'target_slots',4,'target_indices',2); ...
            struct('id','secondary','priority',3,'source_slots',[2,3],'target_slots',[3,2],'target_indices',[])};
        short=cell(3,1);selected=cell(4,1);for k=1:4,selected{k}=zeros(0,1);end
        for k=1:3
            [short{k},scope]=metadataShortlist(specs{k},indexes,8);specs{k}.metadata_selection=scope;
            for n=1:numel(short{k})
                r=short{k}{n};selected{r.source_slot}=[selected{r.source_slot};r.pair(:)]; %#ok<AGROW>
                selected{r.target_slot}=[selected{r.target_slot};r.target_index]; %#ok<AGROW>
            end
        end
        % Exactly one selected bulk intake per original/grown source file.
        % Control transport's second independent read supplies its target view.
        data=cell(4,1);data{4}=cache;
        for k=1:3
            check(work);indices=unique(selected{k},'stable');call=tic;
            [o,r,m]=BranchSolutionFile_v3.loadSolutions(sourceRefs{k}.file,indices);
            data{k}=struct('indices',indices,'orbits',{o},'reports',{r},'metadata',{m});
            headers=cell(numel(indices),1);
            for n=1:numel(indices),headers{n}=pointHeader(o{n},r{n},m{n},indexes{k}.points{indices(n)});end
            c.selection_intake{end+1,1}=struct('reference',sourceRefs{k},'indices',indices, ...
                'public_bulk_calls',1,'seconds',toc(call),'headers',{headers}, ...
                'scope','One selected native view; not independent deserialization/read2.');
        end
        for k=1:3
            job=specs{k};job.shortlist=cell(size(short{k}));eligible=[];scores=[];
            for n=1:numel(short{k})
                check(work);r=short{k}{n};r.geometry=screen(r,indexes,data);
                job.shortlist{n}=r;
                if r.geometry.eligible,eligible(end+1)=n;scores(end+1)=r.geometry.predictor_target_scaled_distance;end %#ok<AGROW>
            end
            job.selected=false;job.selection_status='UNASSESSED_no_eligible_pair_in_declared_metadata_shortlist';
            if ~isempty(eligible)
                [~,p]=min(scores);chosen=job.shortlist{eligible(p)};job.selected=true;
                job.selection_status='one_eligible_pair_selected_by_declared_4D_predictor_distance';
                job.source_reference=sourceRefs{chosen.source_slot};job.source_pair=chosen.pair;
                job.target_reference=sourceRefs{chosen.target_slot};job.target_index=chosen.target_index;
                job.selected_shortlist_rank=eligible(p);job.selected_geometry=chosen.geometry;
                job.overlap_options=overlapOptions(N,job.id);
            end
            c.association_jobs{end+1,1}=job;
            fprintf('PK_QUIET_ASSOCIATION %s\n',jsonencode(jobSummary(job)));
        end
        c.grazing_context=struct('source_reference',old72,'source_pair',[5,6], ...
            'frontier_id','PK_file_0005_graph_0001_leaf_000006');
        c.regular_pending_context=struct('source_reference',old62,'source_pair',[63,64], ...
            'scope','Only the existing zero-root Reconcile worker restores the historical admission.');
        c.input_references=refs;verifyCode(code);verifyAll(refs);c.source_posthash=true;c.completed=true;
    catch problem
        c.input_references=refs;c.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);
    end
    config=c;save(stage,'config','-v7');back=load(stage,'config');same(config,back.config);check(finish);
    assert(config.completed&&config.source_posthash,'PKQuiet:Prepare','Retain failed config stage: %s',jsonencode(config.failure));
    publish(stage,file);check(finish);result=struct('mode','prepare','completed',true,'source_posthash',true, ...
        'root_map_classifier_ode_calls',0,'config_reference',ref(file),'jobs',{cellfun(@jobSummary,c.association_jobs,'UniformOutput',false)}, ...
        'attempt_metric_groups',numel(c.last_saved_attempts),'external_actual_exit_claimed',false);
    fprintf('PK_QUIET_MODE_RETURN %s\n',jsonencode(result));
end

function j=grownJob(a,id,original,pair)
    at=find(cellfun(@(x)strcmp(x.id,id),a.jobs));q=find(cellfun(@(x)strcmp(x.id,id),a.queue));
    assert(isscalar(at)&&isscalar(q),'PKQuiet:Job','Each declared job must be unique.');j=a.jobs{at};source=a.queue{q};
    assert(isequaln(source.source_reference,original)&&isequal(source.pair(:).',pair) ...
        &&strcmp(j.output_reference.file,source.output_file),'PKQuiet:Job','Do not conflate grown low pairs with old regular/grazing contexts.');
end

function [transport,cache]=transportControls(file,refs,raw03,clock)
    assert(~isfile(file)&&~isfile([file,'.pending.mat']),'PKQuiet:ControlFresh','Retain earlier control transport.');
    os=cell(2,1);rs=cell(2,1);ms=cell(2,1);observations=cell(2,1);pairs={[484,485];[288,481]};
    for k=1:2
        check(clock);verify(refs{k});loaded=load(refs{k}.file,'study');s=loaded.study;
        assert(strcmp(s.schema,'C1-PK-local-clearance-boundary-study-v1')&&s.completed&&s.source_posthash ...
            &&s.native_all_nine&&s.native_PK_qualified&&s.native_phase_consistent ...
            &&~s.edge_committed&&~s.global_endpoint_claimed&&isequaln(s.source_reference,raw03) ...
            &&isequal(s.source_pair(:).',pairs{k}),'PKQuiet:Control','Preserve the exact local boundary control authority and flags.');
        os{k}=s.native_orbit;original=s.native_report;assert(admitted(original),'PKQuiet:Control','Saved historical native admission is required.');
        rs{k}=compactReport(original);[~,before]=RecordedReturnPolicy_v3(original);[~,after]=RecordedReturnPolicy_v3(rs{k});
        assert(before.complete&&after.complete&&isequaln(before.configuration,after.configuration), ...
            'PKQuiet:ControlPolicy','The entire recorded policy must survive plain report transport.');
        e=QuadrupedEnergy_v3.evaluate(os{k}.initial_state,os{k}.initial_mode,os{k}.parameter);
        id=OrbitContentIdentity_v3(os{k});
        ms{k}=struct('component_identity',sprintf('PK30h_historical_primary_boundary_control_%d',k), ...
            'order',1,'classification',rs{k}.classification.canonical_point_label,'nativeE',e, ...
            'signedmeanU',os{k}.stride_displacement(1)/os{k}.period,'edge_enabled',false, ...
            'provenance',struct('kind','exact historical inward control NONEDGE transport', ...
                'audit_reference',refs{k},'original_source_reference',raw03,'original_source_pair',pairs{k}, ...
                'native_id',id,'fresh_admission_claimed',false,'historical_flags_upgraded',false));
        observations{k}=struct('audit_reference',refs{k},'native_id',id,'source_pair',pairs{k}, ...
            'original_flags',struct('completed',s.completed,'source_posthash',s.source_posthash, ...
                'native_all_nine',s.native_all_nine,'native_PK_qualified',s.native_PK_qualified, ...
                'native_phase_consistent',s.native_phase_consistent,'edge_committed',s.edge_committed, ...
                'global_endpoint_claimed',s.global_endpoint_claimed), ...
            'report_transport_scope','Complete historical report remains in source audit. Known residual runtime object omitted, full policy/Jacobian described, nested diagnostic traces use unchanged CompactResearchBranch contract. Admission/gates/classification flags are preserved, not re-evaluated.');
    end
    BranchSolutionFile_v3.initialize(file,struct('schema','PK30h-historical-inward-NONEDGE-controls-v1', ...
        'source_audits',{refs},'fresh_admission_claimed',false));
    BranchSolutionFile_v3.appendBatch(file,os,rs,ms);
    for pass=1:2
        [x,r,m]=BranchSolutionFile_v3.loadSolutions(file,[1;2]);
        for k=1:2
            same(public(os{k}),public(x{k}));same(rs{k},r{k});same(ms{k},m{k});
            assert(strcmp(OrbitContentIdentity_v3(x{k}),observations{k}.native_id),'PKQuiet:ControlIdentity','Historical NativeID differs.');
            [~,p]=RecordedReturnPolicy_v3(r{k});[~,b]=RecordedReturnPolicy_v3(rs{k});
            assert(p.complete&&b.complete&&isequaln(p.configuration,b.configuration),'PKQuiet:ControlPolicy','Complete policy readback differs.');
        end
    end
    ix=BranchSolutionFile_v3.index(file);assert(isempty(ix.edges),'PKQuiet:ControlEdges','Historical control transport creates no edge.');
    cache=struct('indices',[1;2],'orbits',{x},'reports',{r},'metadata',{m},'index',ix);
    transport=struct('branch_reference',ref(file),'controls',{observations},'public_native_read_passes',2, ...
        'raw_public_values_equal',true,'native_ids_equal',true,'complete_policies_equal',true, ...
        'physical_edges',0,'fresh_admission_claimed',false);check(clock);
end

function [rows,scope]=metadataShortlist(spec,indexes,count)
    table=zeros(0,8);excluded=0;unknown=0;total=0;
    for side=1:numel(spec.source_slots)
        a=spec.source_slots(side);b=spec.target_slots(min(side,numel(spec.target_slots)));
        source=indexes{a};target=indexes{b};targets=spec.target_indices;
        if isempty(targets),targets=incidentIndices(target);end
        for n=1:numel(source.edges)
            edge=source.edges{n};
            if ~edgeOwner(source,edge),excluded=excluded+1;continue;end
            for direction=1:2
                pair=[edge.from,edge.to];if direction==2,pair=fliplr(pair);end
                base=source.points{pair(2)};
                for t=targets(:).'
                    total=total+1;other=target.points{t};
                    values=[base.nativeE,base.signedmeanU,other.nativeE,other.signedmeanU];
                    if ~all(isfinite(values)),unknown=unknown+1;continue;end
                    scales=max([ones(1,2);abs(values(1:2));abs(values(3:4))],[],1);
                    distance=norm((values(1:2)-values(3:4))./scales);
                    table(end+1,:)=[distance,a,pair,b,t,edge.from,edge.to]; %#ok<AGROW>
                end
            end
        end
    end
    table=sortrows(table,1:8);table=table(1:min(count,size(table,1)),:);rows=cell(size(table,1),1);
    for n=1:numel(rows)
        x=table(n,:);rows{n}=struct('rank',n,'metadata_distance',x(1),'source_slot',x(2), ...
            'pair',x(3:4),'target_slot',x(5),'target_index',x(6),'physical_edge',x(7:8));
    end
    scope=struct('candidate_combinations',total,'excluded_inconsistent_edges',excluded,'unknown_scalar_combinations',unknown, ...
        'shortlisted',numel(rows),'unselected_combinations_UNASSESSED',total-unknown-numel(rows), ...
        'method','index E/signed meanU Euclidean distance; max1 per-coordinate scales; lexicographic source/pair/target/edge tie break', ...
        'source_edge_orientation','Both explicit orientations are separate candidates. Physical-edge direction remains recorded.', ...
        'target_scope','Secondary targets are physically incident consistent-owner occurrences; primary targets are declared historical NONEDGE controls.', ...
        'global_coverage_or_absence_claimed',false);
end

function g=screen(row,indexes,data)
    g=struct('eligible',false,'failure',struct(),'native_scalar_index_match',false, ...
        'requested_step',NaN,'predictor_target_scaled_distance',NaN,'target_lift_exact',false);
    try
        [a,ra,ma]=get(data{row.source_slot},row.pair(1));[b,rb,mb]=get(data{row.source_slot},row.pair(2));
        [t,rt,mt]=get(data{row.target_slot},row.target_index);
        g.source_native_ids={OrbitContentIdentity_v3(a);OrbitContentIdentity_v3(b)};g.target_native_id=OrbitContentIdentity_v3(t);
        g.source_owner=ma.component_identity;g.target_owner=mt.component_identity;
        assert(strcmp(ma.component_identity,mb.component_identity),'PKQuiet:Owner','Source pair owners differ.');
        source=indexes{row.source_slot};edge=struct('from',row.physical_edge(1),'to',row.physical_edge(2), ...
            'component_identity',ma.component_identity);
        assert(edgeOwner(source,edge)&&any(cellfun(@(e)isequaln(e,edge),source.edges)), ...
            'PKQuiet:Edge','The supplied initializer order must refer to an actual stored physical edge.');
        os={a;b;t};rs={ra;rb;rt};points={source.points{row.pair(1)};source.points{row.pair(2)};indexes{row.target_slot}.points{row.target_index}};
        scalarDelta=zeros(3,2);scalarMatch=true;
        for k=1:3
            e=QuadrupedEnergy_v3.evaluate(os{k}.initial_state,os{k}.initial_mode,os{k}.parameter);
            u=os{k}.stride_displacement(1)/os{k}.period;scalarDelta(k,:)=[e-points{k}.nativeE,u-points{k}.signedmeanU];
            scalarMatch=scalarMatch&&isequal(e,points{k}.nativeE)&&isequal(u,points{k}.signedmeanU);
            assert(admitted(rs{k}),'PKQuiet:Admission','Every selected record requires literal saved current one-flight PK/all-nine.');
        end
        g.native_scalar_index_delta=scalarDelta;g.native_scalar_index_match=scalarMatch;
        assert(scalarMatch,'PKQuiet:IndexScalars','Native E/meanU disagrees with the metadata shortlist; no reranking.');
        [policy,pb]=RecordedReturnPolicy_v3(rb);[~,pa]=RecordedReturnPolicy_v3(ra);[~,pt]=RecordedReturnPolicy_v3(rt);
        g.complete_policy_equal=pa.complete&&pb.complete&&pt.complete&&isequaln(pa.configuration,pb.configuration)&&isequaln(pb.configuration,pt.configuration);
        g.exact_pq=isequal(a.parameter,b.parameter)&&isequal(b.parameter,t.parameter) ...
            &&isequal(a.initial_mode,b.initial_mode)&&isequal(b.initial_mode,t.initial_mode);
        g.pair_section=MatchingReturnSection_v3(a,b,{ra,rb});g.target_section=MatchingReturnSection_v3(b,t,{rb,rt});
        g.section_tokens_equal=isequal(a.section_relative_event_signature,b.section_relative_event_signature) ...
            &&isequal(b.section_relative_event_signature,t.section_relative_event_signature);
        g.cyclic_tokens_equal=isequal(a.cyclic_event_signature,b.cyclic_event_signature)&&isequal(b.cyclic_event_signature,t.cyclic_event_signature);
        assert(g.complete_policy_equal&&g.exact_pq&&g.pair_section.compatible&&g.target_section.compatible ...
            &&g.section_tokens_equal&&g.cyclic_tokens_equal,'PKQuiet:Contract','Saved parameter/mode/policy/section/tokens differ.');
        s=QuadrupedSchema_v3.shared();map=PoincareMap_v3(Quadrupedal_Dynamics_v3(), ...
            PoincareSection_v3.apex(s.PhaseIndex),HybridSimulator_v3(),policy);
        f=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,b.initial_state),b.initial_state,b.initial_mode,b.parameter,struct('Symmetry','pronk'));
        assert(isequal(f.CoordinateIndices(:).',[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL]), ...
            'PKQuiet:Chart','Use the actual Run four-state synchronous chart.');
        ua=f.packState(a.initial_state);ub=f.packState(b.initial_state);ut=f.packState(t.initial_state);
        assert(isequal(f.fullState(ub),b.initial_state),'PKQuiet:Base','The actual Root base must roundtrip exactly.');
        scale=max([ones(size(ub)),abs(ua),abs(ub)],[],2);delta=(ub-ua)./scale;chord=norm(delta);
        assert(isfinite(chord)&&chord>1e-10,'PKQuiet:Chord','Source chord is unresolved.');tangent=delta/chord;
        ds=dot(tangent,(ut-ub)./scale);predictor=ub+scale.*(ds*tangent);
        g.chord=chord;g.scale=scale;g.tangent=tangent;g.requested_step=ds;
        g.source_coordinates=[ua,ub];g.target_coordinates=ut;g.predictor_coordinates=predictor;
        g.target_lift_delta=f.fullState(ut)-t.initial_state;g.target_lift_exact=isequal(f.fullState(ut),t.initial_state);
        g.predictor_target_scaled_distance=norm((ut-predictor)./scale);
        g.base_target_full13_scaled_inf=norm((b.initial_state(2:14)-t.initial_state(2:14)) ...
            ./max([ones(13,1),abs(b.initial_state(2:14)),abs(t.initial_state(2:14))],[],2),Inf);
        g.eligible=isfinite(ds)&&ds>1e-8&&ds>=1e-7&&ds<=.04;
        g.scope='Constructor-only Run geometry, zero map/root calls. Target selects the PAL plane only; lift mismatch is observed and is not alone a veto.';
    catch problem,g.failure=struct('identifier',problem.identifier,'message',problem.message);end
end

function h=pointHeader(o,r,m,p)
    [~,policy]=RecordedReturnPolicy_v3(r);h=struct('index',p.index,'order_from_index',p.order, ...
        'native_id',OrbitContentIdentity_v3(o),'owner',m.component_identity,'state',o.initial_state, ...
        'mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride',o.stride_displacement, ...
        'index_energy',p.nativeE,'index_signed_meanU',p.signedmeanU,'policy',policy, ...
        'section',o.section_chart,'section_signature',o.section_relative_event_signature,'cyclic_signature',o.cyclic_event_signature, ...
        'saved_current_all9_PK',admitted(r),'fresh_admission_claimed',false);
end
function [o,r,m]=get(d,index)
    at=find(d.indices==index);assert(isscalar(at),'PKQuiet:Intake','Requested occurrence must have one native selected view.');
    o=d.orbits{at};r=d.reports{at};m=d.metadata{at};
end
function yes=edgeOwner(ix,e)
    yes=e.from>=1&&e.to>=1&&e.from<=numel(ix.points)&&e.to<=numel(ix.points) ...
        &&strcmp(ix.points{e.from}.component_identity,e.component_identity)&&strcmp(ix.points{e.to}.component_identity,e.component_identity);
end
function indices=incidentIndices(ix)
    indices=[];for k=1:numel(ix.edges),e=ix.edges{k};if edgeOwner(ix,e),indices=[indices;e.from;e.to];end,end %#ok<AGROW>
    indices=unique(indices,'stable');
end
function o=overlapOptions(N,name)
    tag=strrep(name,'-','_');base=fullfile(N,'Connected_PK_PK30h_20261101',['C1_PK_Overlap_',tag]);
    run=struct('MaxWallSeconds',360,'TrialSeconds',180,'SaveMarginSeconds',60,'MaxAccepted',1,'MaxAttempts',1, ...
        'MinimumStep',1e-7,'MaximumStep',.04,'CaptureRadius',.02,'ReusePreviousJacobian',false, ...
        'MaximumCorrectionStepRatio',.5,'MaximumTurnDegrees',45,'UsePhasePredictor',true,'PhaseSeconds',30, ...
        'InPlace',false,'ComponentIdentity',['PK30h_Overlap_',tag],'Algorithm','root-newton', ...
        'AllowedClasses',{{'PK'}},'IntegrationMaxStep',.001,'CorrectorInitializer','base', ...
        'DerivativeMethod','valid-sided','FiniteDifferenceSteps',1e-8,'InitialDerivativeIndex',1, ...
        'BatchSize',1,'TraceFailure',true,'AdaptiveStep',false,'MinimumApexHeightRatio',.5);
    o=struct('OutputFile',fullfile(N,'Audits',['PK30h_20261101_Overlap_',tag,'.mat']), ...
        'BranchFile',[base,'.mat'],'CheckpointFile',[base,'_Checkpoint.mat'],'SourceAuditReference',struct(), ...
        'RunOptions',run,'Symmetry','pronk','MaximumPALStep',.04,'FineSeconds',120, ...
        'MaxWallSeconds',1800,'SaveMarginSeconds',60);
end
function group=attemptMetrics(j,s)
    rows=cell(0,1);first=max(1,numel(s.attempts)-7);
    for k=first:numel(s.attempts)
        x=s.attempts{k};phase=member(x,'phase_acquisition',struct());root=member(phase,'root',struct());
        controller=member(x,'step_controller',struct());capture=member(x,'capture',struct());publications=cell(0,1);
        nativeIterations=member(controller,'native_root_iterations',[]);nativeIterationScope='saved step controller';
        if isempty(nativeIterations)
            matches=find(cellfun(@(p)p.attempt==x.attempt,s.failed_root_journals));
            if isscalar(matches)
                savedRoot=member(s.failed_root_journals{matches}.native_report,'solver',struct());
                nativeIterations=member(member(savedRoot,'output',struct()),'iterations',[]);
                nativeIterationScope='saved failed native root journal';
            else,nativeIterationScope='UNASSESSED_no_unique_recorded_native_iteration_count';end
        end
        for n=1:numel(s.batch_publications)
            p=s.batch_publications{n};if ismember(x.attempt,p.attempts),publications{end+1,1}=p;end %#ok<AGROW>
        end
        rows{end+1,1}=struct('attempt',x.attempt,'status',x.status,'requested_radius',x.step, ...
            'phase_completed',member(phase,'completed',false),'phase_seconds',member(phase,'seconds',[]), ...
            'phase_iterations',member(member(root,'output',struct()),'iterations',[]), ...
            'phase_function_count',member(member(root,'output',struct()),'funcCount',[]), ...
            'native_iterations',nativeIterations,'native_iteration_scope',nativeIterationScope, ...
            'correction_step_ratio',member(capture,'correction_step_ratio',[]),'turn_degrees',member(capture,'turn_degrees',[]), ...
            'selected_next_radius',member(controller,'selected_radius',[]),'step_controller',controller, ...
            'capture',capture,'all_nine',member(x,'all_nine',false),'timely',member(x,'timely',false), ...
            'edge_committed',member(x,'edge_committed',false),'native_seconds',member(x,'native_service_seconds',[]), ...
            'pending_seconds',member(x,'pending_custody_seconds',[]),'pending_timely',member(x,'pending_custody_timely',[]), ...
            'batch_publications',{publications},'attempt_seconds_before_final_checkpoint',member(x,'attempt_seconds_before_final_checkpoint',[]), ...
            'scope','Empty optional metrics are UNASSESSED. Batch times are shared, not allocated per point; attempt seconds exclude final checkpoint.'); %#ok<AGROW>
    end
    group=struct('id',j.id,'checkpoint_reference',j.checkpoint_reference,'output_reference',j.output_reference, ...
        'returned_whole_job_seconds',j.seconds,'returned_persistence_completion_confirmed',j.persistence_completion_confirmed, ...
        'checkpoint_provisional_persistence_completion_confirmed',s.persistence_completion_confirmed, ...
        'status',s.status,'last_attempts',{rows},'future_008_step_executed',false);
end
function g=metricSummary(group)
    g=group;rows=group.last_attempts;
    for k=1:numel(rows)
        r=rows{k};r=rmfield(r,{'step_controller','capture','batch_publications'});
        r.publication_seconds=cellfun(@(p)p.seconds,rows{k}.batch_publications,'UniformOutput',false);
        r.publication_read2=cellfun(@(p)p.installed_read2_verified,rows{k}.batch_publications,'UniformOutput',false);
        r.publication_timely=cellfun(@(p)p.timely,rows{k}.batch_publications,'UniformOutput',false);
        r.publication_scope='Actual shared batch seconds; no per-point allocation.';g.last_attempts{k}=r;
    end
end
function r=compactReport(r)
    [~,e]=RecordedReturnPolicy_v3(r);assert(e.complete,'PKQuiet:Policy','Require complete actual policy.');
    r.correction_return_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',e.configuration.source_class,'settings',e.configuration.settings);
    r.options.Residual=[];r.options_residual_runtime_object_omitted=true;
    j=r.options.SolverOptions.Jacobian;settings=struct();names=properties(j);
    for k=1:numel(names),settings.(names{k})=j.(names{k});end
    r.options.SolverOptions.Jacobian=struct('diagnostic_kind','runtime-object-descriptor','source_class',class(j),'settings',settings);
    holder=CompactResearchBranch_v3(struct('report',r));r=holder.report;C1ScientificDigest_v3(r);
end
function yes=admitted(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations', ...
        'family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    gates=member(r,'acceptance_gates',struct());g=member(r,'classification',struct());[~,version]=GaitSemanticTable_v3();
    yes=isequal(member(r,'accepted',false),true)&&all(isfield(gates,keys)) ...
        &&strcmp(member(g,'contract_version',''),version)&&strcmp(member(g,'validated_gait_type',''),'PK') ...
        &&strcmp(member(g,'canonical_point_label',''),'PK')&&isequal(member(g,'canonical_label_qualified',false),true) ...
        &&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1);
    for k=1:numel(keys),yes=yes&&isequal(member(gates,keys{k},false),true);end
end
function s=jobSummary(j)
    s=struct('id',j.id,'priority',j.priority,'selected',j.selected,'status',j.selection_status, ...
        'metadata_selection',j.metadata_selection,'native_screened',numel(j.shortlist));
    if j.selected,s.source_reference=j.source_reference;s.source_pair=j.source_pair;s.target_reference=j.target_reference; ...
            s.target_index=j.target_index;s.requested_step=j.selected_geometry.requested_step; ...
            s.predictor_target_scaled_distance=j.selected_geometry.predictor_target_scaled_distance;end
end
function refs=providers()
    names={'CoordinatePK30hQuietEpoch20261101','RunC1ContinuationQueue_v3','RunC1Continuation_v3', ...
        'RunC1PKFlightGrazingStudy_v3','SynchronousPKPhaseResidual_v3','SynchronousPKFlightGrazingResidual_v3', ...
        'AcquireC1NumericalOverlap_v3','C1FiniteNumericalOverlap_v3','ReconcilePK30hRegular20261101', ...
        'BranchSolutionFile_v3','HybridOrbit_v3','Trajectory_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3', ...
        'OrbitContentIdentity_v3','EnergyFamilyResidual_v3','PeriodicOrbitResidual_v3','PoincareMap_v3', ...
        'PoincareSection_v3','HybridSimulator_v3','Quadrupedal_Dynamics_v3','QuadrupedEnergy_v3','QuadrupedSchema_v3', ...
        'GaitSemanticTable_v3','CompactResearchBranch_v3','C1ScientificDigest_v3','V3Root_v3','V3Path_v3','RoundSHA256_v3', ...
        'RootSolver_v3','PeriodicSolutionSolver_v3','ContinuousDynamics_v3','EventDetector_v3','GuardFunctions_v3', ...
        'ResetMap_v3','ModeTransition_v3','ConstrainedEnergyResidual_v3','ValidSidedFiniteDifferenceJacobian_v3', ...
        'FiniteDifferenceJacobian_v3','PrimitiveCycleCheck_v3','C1PlainFineQualificationReplay_v3', ...
        'HybridCycleData_v3','GaitIdentification_v3','QuadrupedPhysicalChart_v3'};
    refs=cell(numel(names),1);for k=1:numel(names),refs{k}=ref(which(names{k}));end
    refs{end+1,1}=ref(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKQuiet:Readback','Complete declared typed values changed.');end
function verifyAll(refs),for k=1:numel(refs),verify(refs{k});end,end
function verifyCode(refs)
    verifyAll(refs);
    for k=1:numel(refs)
        [~,name,ext]=fileparts(refs{k}.file);
        if strcmp(ext,'.m'),assert(strcmp(literal(which(name)),refs{k}.file),'PKQuiet:Resolver','Current provider resolution differs from the prepared epoch.');end
    end
end
function verify(r)
    assert(isequal(sort(fieldnames(r)),sort({'file';'sha256'}))&&strcmp(r.file,literal(r.file)) ...
        &&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKQuiet:Source','Literal immutable file generation differs.');
end
function r=authority(file,sha),r=struct('file',literal(file),'sha256',sha);end
function r=ref(file),if ~isfile(file)&&isfile([file,'.m']),file=[file,'.m'];end;r=authority(file,RoundSHA256_v3(file));end
function path=literal(file)
    path=char(java.io.File(file).getCanonicalPath());mapped=char(java.io.File(V3Path_v3(file)).getCanonicalPath());
    assert(strcmp(path,mapped),'PKQuiet:Path','Hash and native load must address the same literal path.');
end
function publish(stage,file)
    javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());delete(stage);
end
function v=member(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end
function l=limit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKQuiet:Clock','The original bounded clock expired.');end
function requireFit(b,s),assert(b.research_deadline_unix_seconds-utc()>s+2 ...
    &&(b.research_deadline_monotonic_ns-nano())/1e9>s+2,'PKQuiet:WholeFit','The complete unchanged helper allowance must fit the original science deadline.');end
function t=utc(),t=posixtime(datetime('now','TimeZone','UTC'));end
function t=nano(),t=double(java.lang.System.nanoTime());end
