function result=AuditPK30h0072LiteralFlightClearance20261102(B,bindings,options)
% Literal historical records only; no correction, snapping, ODE or admission.
% The copied exact flight scout finds finite stationary roots. An interior
% negative native guard is a witness, without any all-root/global-min claim.
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort( ...
        {'SourceReference';'BoundaryReference';'BudgetReference';'CallerReference';'SourceReferences'})) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort( ...
        {'OutputFile';'MaxWallSeconds';'SaveMarginSeconds';'GridIntervals';'RootTolX';'RootResidualTolerance'; ...
        'RootDedupSeconds';'BoundaryExclusionSeconds';'MaxRootIterations';'MaxRootEvaluations'})), ...
        'PK0072Guard:Inputs','Use the explicit fixed data/method inputs and finite native scalar-root scan.');
    assert(strcmp(B.grant_id,'20261101_PK_30h')&&B.capture.pid==feature('getpid') ...
        &&strcmp(B.research_deadline_utc,'2026-11-02T20:29:07Z')&&strcmp(B.deadline_utc,'2026-11-02T22:29:07Z') ...
        &&options.MaxWallSeconds==360&&options.SaveMarginSeconds==60&&options.GridIntervals==512, ...
        'PK0072Guard:Grant','Retain the original native budget and fixed360/60 operation,512-cell finite scan.');
    for name={'RootTolX','RootResidualTolerance','RootDedupSeconds','BoundaryExclusionSeconds'}
        validateattributes(options.(name{1}),{'double'},{'real','finite','scalar','positive'});
    end
    for name={'MaxRootIterations','MaxRootEvaluations'},validateattributes(options.(name{1}),{'double'},{'real','finite','scalar','integer','positive','<=',1000});end
    entered=struct('u',sfUTC(),'m',sfNano());assert(min(B.research_deadline_unix_seconds-entered.u,(B.research_deadline_monotonic_ns-entered.m)/1e9)>362, ...
        'PK0072Guard:WholeFit','The full360/60 local operation must fit the original science clocks.');
    finish=struct('u',entered.u+360,'m',entered.m+360e9);work=struct('u',finish.u-60,'m',finish.m-60e9);
    refs=[{bindings.SourceReference;bindings.BoundaryReference;bindings.BudgetReference;bindings.CallerReference};bindings.SourceReferences(:)];sfVerify(refs);
    output=sfLiteral(options.OutputFile);[folder,name]=fileparts(output);jsonFile=fullfile(folder,[name,'.json']);stage=[output,'.pending.mat'];jsonStage=[jsonFile,'.pending.json'];
    assert(all(cellfun(@(f)~isfile(f)&&~isfolder(f),{output;stage;jsonFile;jsonStage})),'PK0072Guard:Fresh','Keep previous finals/stages; no automatic retry.');
    assert(strcmp(bindings.SourceReference.sha256,'f2f62cc9de65cb39cece67a1de60ca058db0be8863b87e229c1440a12e939ec7') ...
        &&bindings.SourceReference.bytes==399887943,'PK0072Guard:OriginalSource','Only the exact original0072 generation is consumed.');
    a=load('-mat',bindings.BoundaryReference.file,'study');b=load('-mat',bindings.BoundaryReference.file,'study');
    boundary=a.study;assert(boundary.completed&&boundary.source_posthash&&boundary.first_flight_local_regularity ...
        &&boundary.native_all_nine&&boundary.native_PK_qualified&&boundary.native_phase_consistent ...
        &&boundary.native_inward_clearance.completed&&boundary.native_inward_clearance.positive_interior_gap ...
        &&isequal(boundary.boundary.coordinates,b.study.boundary.coordinates) ...
        &&strcmp(C1ScientificDigest_v3(boundary.local_rank),C1ScientificDigest_v3(b.study.local_rank)), ...
        'PK0072Guard:ActualBoundary','Use the closed independently solved positive local9root and actual admitted inward control.');
    criticalTime=boundary.boundary.coordinates(9);boundaryProjection=struct('reference',bindings.BoundaryReference, ...
        'schema',boundary.schema,'literal_coordinates',boundary.boundary.coordinates, ...
        'physical_residual',boundary.boundary.info.physical_residual,'critical_time',criticalTime, ...
        'literal_parameter',boundary.source_core{1}.parameter, ...
        'native_inward_clearance',boundary.native_inward_clearance.status, ...
        'scope','Time is a probe of each independent OLD raw state. No orbit identity or validity is inferred from apexdx ordering.');clear a b boundary
    indices=[5;6;13;130];ix=BranchSolutionFile_v3.index(bindings.SourceReference.file);
    assert(numel(ix.points)==152&&all(indices<=numel(ix.points)),'PK0072Guard:Index','Use actual original152-point index and declared four selectors.');
    sources=cell(4,1);digests=cell(4,1);witness=[];
    for pass=1:2
        sfCheck(work);[orbits,reports,metadata]=BranchSolutionFile_v3.loadSolutions(bindings.SourceReference.file,indices);
        assert(numel(orbits)==4&&numel(reports)==4&&numel(metadata)==4,'PK0072Guard:SelectedCount','Every selected native original record must be returned.');
        if pass==2,assert(~(witness==orbits{1}),'PK0072Guard:IndependentHandles','Two public reads must deserialize independently.');end
        for k=1:4
            p=sourceProjection(orbits{k},reports{k},metadata{k},ix,indices(k));digest=C1ScientificDigest_v3(p);
            if pass==1,sources{k}=p;digests{k}=digest;else,assert(strcmp(digest,digests{k}),'PK0072Guard:TwoPass','Literal source record/policy/history/flags changed between independent native reads.');end
        end
        if pass==1,witness=orbits{1};end
        clear orbits reports metadata p
    end
    clear witness
    s=QuadrupedSchema_v3.shared();flow=ContinuousDynamics_v3(s);guards=GuardFunctions_v3(s);physical=QuadrupedAdmissibility_v3(s);
    tol=physical.SwingPenetrationTolerance;assert(tol==1e-8,'PK0072Guard:OriginalTolerance','Retain the actual physical swing-penetration tolerance.');
    audit=struct('schema','PK30h-old0072-literal-firstflight-guard-witness-v1','completed',false,'source_posthash',false, ...
        'bindings',bindings,'input_references',{refs},'original_budget',B,'options',options,'local_finish',finish, ...
        'boundary_probe',boundaryProjection,'source_selected_indices',indices,'source_native_reads',2, ...
        'independent_handle_witness',true,'literal_source_digests',{digests},'physical_swing_tolerance',tol, ...
        'arithmetic_cushion_diagnostic',1e-11,'rows',{cell(4,1)},'current_guard_failure_mask',false(4,1), ...
        'all_recorded_states_assessed',false,'rows_assessed',0,'failure',struct(), ...
        'coupled_root_calls',0,'ODE_Map_replay_admission_calls',0,'state_modifications',0, ...
        'historical_accepted_classification_P_M_flags_changed',false,'global_minimum_or_full_stationary_coverage_claimed',false, ...
        'scope','A concrete strictly interior negative guard is an observed inconsistency with the saved all-flight interval. Lack of a found violation does not qualify an old orbit or certify clearance.');
    try
        for k=1:4
            sfCheck(work);raw=sources{k};row=struct('source_key',struct('reference',bindings.SourceReference,'index',indices(k),'native_id',raw.native_id), ...
                'literal_source',raw,'source_two_pass_verified',true,'status','UNASSESSED','assessed',false, ...
                'first_flight',struct(),'boundary_time_probe',struct(),'stationary_probes',{{}},'violation_witnesses',{{}}, ...
                'current_guard_failure',false,'failure',struct());
            try
                x=raw.state14;p=raw.parameter;q=raw.mode;
                s.validateState(x);s.validateParameter(p);s.validateMode(q);expanded=s.expandParameters(p);
                assert(isequal(size(x),[14,1])&&isequal(size(p),[10,1])&&isequal(size(q),[4,1]) ...
                    &&all(isfinite([x;p]))&&~any(q)&&all(x([s.State.phi,s.State.dphi,s.State.dy])==0) ...
                    &&all(x(s.Leg.AngleIndices)==x(s.State.alphaBL))&&all(x(s.Leg.RateIndices)==x(s.State.dalphaBL)) ...
                    &&all(expanded.k_s>0)&&raw.recorded_policy.complete, ...
                    'PK0072Guard:ExactRawChart','Literal all-flight upright apex/synchronous raw chart and complete policy are required; never snap or infer.');
                h=raw.event_history;assert(isstruct(h)&&all(isfield(h,{'is_stop','guard_id','time','state_before','mode_before'})), ...
                    'PK0072Guard:ActualHistory','Use the actual native saved event history.');
                physicalRows=find(~[h.is_stop]);ids=zeros(numel(physicalRows),1);times=ids;
                for j=1:numel(physicalRows),e=h(physicalRows(j));ids(j)=s.eventId(e.guard_id);times(j)=e.time;end
                assert(numel(ids)==8&&isequal(sort(ids),(1:8).')&&all(isfinite(times)), ...
                    'PK0072Guard:ActualEvents','Require actual fourTD/fourLO saved physical events.');
                td=ismember(ids,s.Event.IDs(s.Event.IsTouchdown));first=min(times(td));at=find(td&times==first,1);event=h(physicalRows(at));
                t0=raw.trajectory_initial_time;duration=first-t0;
                assert(isfinite(t0)&&isfinite(duration)&&duration>2*options.BoundaryExclusionSeconds&&first<t0+raw.period ...
                    &&min(times)==first&&~any(event.mode_before),'PK0072Guard:OwnFirstTD','Use the raw saved all-flight interval from its own actual initial time to first physicalTD.');
                row.first_flight=struct('initial_time',t0,'first_TD_absolute_time',first,'duration',duration, ...
                    'first_TD_event_history_ordinal',physicalRows(at),'first_TD_event',event, ...
                    'saved_initial_state',x,'saved_mode',q,'saved_parameter',p, ...
                    'no_projection',true,'firstflight_all_swing_claim_checked_from_initial_and_first_physical_event',true, ...
                    'same_parameter_as_boundary_time_donor',isequal(p,boundaryProjection.literal_parameter));
                if criticalTime>0&&criticalTime<duration
                    row.boundary_time_probe=probe(criticalTime,x,q,p,t0,duration,expanded,s,flow,guards,tol,work,'independent_boundary_time');
                    if row.boundary_time_probe.violation_observed,row.violation_witnesses{end+1,1}=row.boundary_time_probe;row.current_guard_failure=true;end
                else,row.boundary_time_probe=struct('status','UNASSESSED_BOUNDARY_TIME_OUTSIDE_OWN_OPEN_FLIGHT','time',criticalTime,'duration',duration);end
                scan=sfFlight(x,q,p,t0,duration,event.state_before,'literal-old-initial-flight','raw old source state -> actual own first savedTD',options,work,s);
                row.finite_stationary_scan=scan;
                assert(strcmp(scan.status,'FINITE_FIXED_LITERAL_ROOT_SCAN_COMPLETED'),'PK0072Guard:Scan','Preserve any incomplete finite root scan as UNASSESSED.');
                for leg=1:4
                    roots=scan.legs{leg}.stationary_roots;assert(iscell(roots),'PK0072Guard:ProducerSchema','Use literal cell-of-struct scout roots.');
                    for j=1:numel(roots)
                        t=roots{j}.local_time;v=probe(t,x,q,p,t0,duration,expanded,s,flow,guards,tol,work,'same-old-state-fzero-stationary');
                        v.found_root_leg=leg;v.found_root_record=roots{j};row.stationary_probes{end+1,1}=v;
                        if v.violation_observed,row.violation_witnesses{end+1,1}=v;row.current_guard_failure=true;end
                    end
                end
                row.current_guard_failure=~isempty(row.violation_witnesses);row.assessed=true;
                if row.current_guard_failure,row.status='LITERAL_OLD_OPEN_FLIGHT_NEGATIVE_GUARD_OBSERVED';else,row.status='NO_NEGATIVE_GUARD_FOUND_IN_FINITE_CHECK_NOT_A_QUALIFICATION';end
            catch failure
                row.failure=sfFailure(failure);
                if row.current_guard_failure,row.status='LITERAL_OLD_NEGATIVE_GUARD_OBSERVED_FINITE_SCAN_UNRESOLVED';else,row.status='UNASSESSED_LITERAL_OLD_FLIGHT';end
            end
            audit.rows{k}=row;audit.current_guard_failure_mask(k)=row.current_guard_failure;
            audit.rows_assessed=audit.rows_assessed+double(row.assessed);
        end
        audit.all_recorded_states_assessed=audit.rows_assessed==4;sfVerify(refs);sfCheck(work);audit.source_posthash=true;audit.completed=true;
    catch failure,audit.failure=sfFailure(failure);end
    audit.elapsed_seconds=(sfNano()-entered.m)/1e9;
    audit.numeric_scope='Native double algebra and native Guard/Lie/Flow comparisons, not validated interval arithmetic. A separate1e-11 margin diagnostic is retained.';
    audit_digest=C1ScientificDigest_v3(audit);save(stage,'audit','audit_digest','-v7');sfRead2(stage,audit_digest);
    fid=fopen(jsonStage,'w');assert(fid>=0,'PK0072Guard:JSON','Create only a fresh own metadata stage.');fwrite(fid,unicode2native(jsonencode(audit),'UTF-8'),'uint8');assert(fclose(fid)==0,'PK0072Guard:JSONClose','Own metadata stage close failed.');
    sfVerify(refs);sfCheck(finish);
    for pair={{stage,output},{jsonStage,jsonFile}}
        p=pair{1};sha=RoundSHA256_v3(p{1});javaMethod('createLink','java.nio.file.Files',java.io.File(p{2}).toPath(),java.io.File(p{1}).toPath());
        assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(p{2}).toPath(),java.io.File(p{1}).toPath())&&strcmp(RoundSHA256_v3(p{1}),sha),'PK0072Guard:Publish','Publish only the unchanged own stage.');javaMethod('delete','java.nio.file.Files',java.io.File(p{1}).toPath());
    end
    sfRead2(output,audit_digest);sfVerify(refs);sfCheck(finish);
    result=struct('completed',audit.completed,'source_posthash',audit.source_posthash,'all_recorded_states_assessed',audit.all_recorded_states_assessed, ...
        'rows_assessed',audit.rows_assessed,'indices',indices,'native_ids',{cellfun(@(r)r.native_id,sources,'UniformOutput',false)}, ...
        'current_guard_failure_mask',audit.current_guard_failure_mask,'audit_reference',sfRef(output),'json_reference',sfRef(jsonFile), ...
        'failure',audit.failure,'historical_flags_changed',false,'own_process_exit_claimed',false);
    fprintf('PK30H_OLD0072_LITERAL_GUARD_RETURN %s\n',jsonencode(result));
end
function out=sourceProjection(o,r,m,ix,index)
    [~,policy]=RecordedReturnPolicy_v3(r);
    assert(isa(o,'HybridOrbit_v3')&&numel(o.initial_state)==14&&numel(o.parameter)==10&&numel(o.initial_mode)==4 ...
        &&isa(o.trajectory,'Trajectory_v3')&&~isempty(o.trajectory.time),'PK0072Guard:NativeRecord','Use actual native orbit/trajectory values.');
    out=struct('index',index,'native_id',OrbitContentIdentity_v3(o),'state14',o.initial_state,'parameter',o.parameter,'mode',o.initial_mode, ...
        'period',o.period,'stride14',o.stride_displacement,'section',o.section_chart,'return_policy_name',o.return_policy_name, ...
        'return_multiplicity',o.return_multiplicity,'section_signature',o.section_relative_event_signature, ...
        'cyclic_signature',o.cyclic_event_signature,'recorded_policy',policy,'trajectory_initial_time',o.trajectory.time(1), ...
        'event_history',o.event_history,'historical_accepted_present',isfield(r,'accepted'),'historical_accepted',member(r,'accepted',[]), ...
        'historical_acceptance_gates',member(r,'acceptance_gates',struct()),'historical_classification',member(r,'classification',struct()), ...
        'source_point_header',ix.points{index},'source_metadata_owner',member(m,'component_identity',''), ...
        'source_incoming_P',{ix.edges(cellfun(@(e)e.to==index,ix.edges))}, ...
        'source_outgoing_P',{ix.edges(cellfun(@(e)e.from==index,ix.edges))},'source_relation_membership',relations(ix,index));
end
function out=relations(ix,index)
    out=struct('component_graph_present',false,'rows',{{}},'scope','Only relations literally stored in the original0072 file; external carriers retain their separate authorities.');
    if ~isfield(ix.metadata,'component_graph'),return;end
    out.component_graph_present=true;g=ix.metadata.component_graph;
    for name={'exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'}
        row=struct('name',name{1},'present',isfield(g,name{1}),'pairs',zeros(0,2));
        if row.present,p=g.(name{1});assert(isnumeric(p)&&size(p,2)==2,'PK0072Guard:Relations','Literal relation pairs need the original bounded shape.');row.pairs=p(any(p==index,2),:);end
        out.rows{end+1,1}=row;
    end
end
function v=member(s,key,fallback),if isstruct(s)&&isscalar(s)&&isfield(s,key),v=s.(key);else,v=fallback;end,end
function out=probe(t,x,q,p,t0,T,expanded,s,flow,guards,tol,limit,kind)
    sfCheck(limit);assert(isfinite(t)&&t>0&&t<T,'PK0072Guard:OpenFlight','Witness time must be strictly inside the actual saved flight.');
    v=sfPoint(t,x,expanded,s);analyticFlow=zeros(14,1);analyticFlow(s.State.x)=x(s.State.dx);analyticFlow(s.State.y)=v.state14(s.State.dy);analyticFlow(s.State.dy)=-1;
    analyticFlow(s.Leg.AngleIndices)=v.alpha_rate;analyticFlow(s.Leg.RateIndices)=v.alpha_acceleration;
    nativeFlow=flow.evaluate(t0+t,v.state14,q,p);nativeGuard=guards.legValues(v.state14,p);nativeLie=guards.legLieDerivatives(v.state14,nativeFlow,p);
    errors=[norm(nativeFlow-analyticFlow,Inf),norm(nativeGuard-v.g,Inf),norm(nativeLie-v.gdot,Inf)];
    consistent=all(isfinite(errors))&&all(errors<=1e-11);
    out=struct('kind',kind,'status','NATIVE_ALGEBRA_GUARD_LIE_OBSERVED','local_time',t,'absolute_time',t0+t,'own_open_flight_duration',T, ...
        'analytic',v,'analytic_flow',analyticFlow,'native_flow',nativeFlow,'native_guard',nativeGuard,'native_Lie',nativeLie, ...
        'consistency_errors_flow_guard_Lie_inf',errors,'consistent_with_native',consistent,'physical_tolerance',tol, ...
        'guard_minus_negative_tolerance',nativeGuard+tol,'violation_legs',find(nativeGuard< -tol), ...
        'negative_beyond_1e11_cushion_legs',find(nativeGuard< -tol-1e-11), ...
        'violation_observed',consistent&&any(nativeGuard< -tol),'continuous_minimum_claimed',false);
end

function out=sfFlight(x,q,p,t0,T,storedEnd,label,locator,o,limit,s)
    out=struct('label',label,'literal_locator',locator,'literal_start_state14',x,'literal_mode',q,'literal_parameter',p, ...
        'absolute_start_time',t0,'local_duration',T,'stored_end_state14',storedEnd,'status','UNASSESSED_PRECONDITIONS', ...
        'precondition_failure',struct(),'legs',{{}},'endpoint_facts',struct());
    try
        assert(isa(x,'double')&&isreal(x)&&~issparse(x)&&isequal(size(x),[14,1])&&all(isfinite(x)) ...
            &&isa(p,'double')&&isreal(p)&&~issparse(p)&&isequal(size(p),[10,1]),'PKStationary:LiteralShape','Require unchanged raw double column state/parameter.');
        s.validateState(x);s.validateParameter(p);s.validateMode(q);a=s.expandParameters(p);
        assert(isequal(size(q),[4,1])&&~any(q)&&x(s.State.dphi)==0&&all(a.k_s>0) ...
            &&all(isfinite(sqrt(a.k_s./a.l_0.^2)))&&isscalar(t0)&&isfinite(t0)&&isscalar(T)&&isfinite(T)&&T>2*o.BoundaryExclusionSeconds, ...
            'PKStationary:ExactFlight','Require literal all-flight, exact dphi=0, positive per-leg ks/L and a nonempty open interval; no snap or rotating approximation.');
        out.status='EXACT_ALGEBRA_PRECONDITIONS_VALIDATED';
        out.exact_constant_phi=x(s.State.phi);out.per_leg_rest_angles=a.rsla;out.per_leg_lengths=a.l_0;out.per_leg_ks=a.k_s;
        pi=s.Parameter;
        out.common_PK_annotation=struct('upright',x(s.State.phi)==0,'centered_COM',p(s.Parameter.l_com)==.5, ...
            'literal_common_parameters',isequal(p([pi.k_l_b,pi.k_s_b,pi.l_l_b,pi.rsla_b]),p([pi.k_l_f,pi.k_s_f,pi.l_l_f,pi.rsla_f])), ...
            'literal_common_angles',all(x(s.Leg.AngleIndices)==x(s.Leg.AngleIndices(1))), ...
            'literal_common_rates',all(x(s.Leg.RateIndices)==x(s.Leg.RateIndices(1))), ...
            'annotation_is_precondition',false);
        left=sfPoint(0,x,a,s);right=sfPoint(T,x,a,s);
        out.endpoint_facts=struct('analytic_start',left,'analytic_end',right,'literal_saved_end',storedEnd, ...
            'literal_saved_end_status','UNASSESSED_NOT_RETAINED','analytic_minus_literal_end',[], ...
            'intended_boundaries_excluded_from_stationary_roots',true,'saved_state_corrected',false);
        if ~isempty(storedEnd)
            assert(isa(storedEnd,'double')&&isreal(storedEnd)&&isequal(size(storedEnd),[14,1])&&all(isfinite(storedEnd)), ...
                'PKStationary:SavedEnd','Retain only a literal raw14 saved endpoint.');
            out.endpoint_facts.literal_saved_end_status='LITERAL_SAVED_ENDPOINT';
            out.endpoint_facts.analytic_minus_literal_end=right.state14-storedEnd;
        end
        times=linspace(0,T,o.GridIntervals+1);legs=cell(4,1);
        for leg=1:4
            sfCheck(limit);rates=zeros(size(times));for j=1:numel(times),v=sfPoint(times(j),x,a,s);rates(j)=v.gdot(leg);end
            brackets=zeros(0,2);exact=find(rates==0);exact=exact(exact>1&exact<numel(times));
            for j=1:numel(times)-1
                if (rates(j)<0&&rates(j+1)>0)||(rates(j)>0&&rates(j+1)<0),brackets(end+1,:)=[times(j),times(j+1)];end %#ok<AGROW>
            end
            attempts=cell(numel(exact)+size(brackets,1),1);roots=cell(0,1);keptTimes=zeros(0,1);
            for j=1:numel(attempts)
                sfCheck(limit);attempt=struct('method','','bracket',[],'local_time',[],'exitflag',[],'residual',[], ...
                    'output',struct(),'status','UNASSESSED','failure',struct());
                try
                    if j<=numel(exact)
                        t=times(exact(j));attempt.method='literal-exact-grid-zero';attempt.exitflag=1;attempt.residual=rates(exact(j));
                    else
                        bracket=brackets(j-numel(exact),:);attempt.method='fzero-sign-bracket';attempt.bracket=bracket;
                        rootOptions=optimset('Display','off','TolX',o.RootTolX,'MaxIter',o.MaxRootIterations,'MaxFunEvals',o.MaxRootEvaluations);
                        [t,fval,flag,rootOutput]=fzero(@rate,bracket,rootOptions);
                        attempt.exitflag=flag;attempt.residual=fval;attempt.output=rootOutput;
                    end
                    attempt.local_time=t;value=sfPoint(t,x,a,s);
                    if attempt.exitflag<=0||~isfinite(t)||abs(value.gdot(leg))>o.RootResidualTolerance
                        attempt.status='FAILED_ROOT_OR_RESIDUAL';
                    elseif t<=o.BoundaryExclusionSeconds||t>=T-o.BoundaryExclusionSeconds
                        attempt.status='EXCLUDED_BOUNDARY_NEIGHBORHOOD';
                    elseif any(abs(keptTimes-t)<=o.RootDedupSeconds)
                        attempt.status='DEDUPLICATED';
                    else
                        attempt.status='RETAINED_INTERIOR_STATIONARY_ROOT';keptTimes(end+1,1)=t;
                        roots{end+1,1}=struct('local_time',t,'absolute_time',t0+t,'leg_index',leg,'leg_name',s.Leg.Names{leg}, ...
                            'g',value.g(leg),'gdot',value.gdot(leg),'gddot',value.gddot(leg),'strict_local_minimum_by_gddot',value.gddot(leg)>0, ...
                            'raw_local_state',value,'discovery_method',attempt.method,'bracket',attempt.bracket); %#ok<AGROW>
                    end
                catch problem
                    if strcmp(problem.identifier,'PKStationary:Clock'),rethrow(problem);end
                    attempt.status='ROOT_CALL_FAILED';attempt.failure=sfFailure(problem);
                end
                attempts{j}=attempt;
            end
            statuses=cellfun(@(v)v.status,attempts,'UniformOutput',false);
            legs{leg}=struct('leg_index',leg,'leg_name',s.Leg.Names{leg},'grid_intervals',o.GridIntervals,'grid_definition','linspace(0,local_duration,GridIntervals+1)', ...
                'grid_point_count',numel(times),'grid_finite_rate_count',sum(isfinite(rates)),'sign_change_brackets',brackets,'exact_interior_grid_zero_indices',exact,'attempt_count',numel(attempts), ...
                'sign_change_bracket_count',size(brackets,1),'exact_interior_grid_zero_count',numel(exact), ...
                'failed_root_count',sum(strcmp(statuses,'FAILED_ROOT_OR_RESIDUAL')|strcmp(statuses,'ROOT_CALL_FAILED')), ...
                'boundary_excluded_count',sum(strcmp(statuses,'EXCLUDED_BOUNDARY_NEIGHBORHOOD')), ...
                'deduplicated_count',sum(strcmp(statuses,'DEDUPLICATED')), ...
                'retained_root_count',numel(roots),'attempts',{attempts},'stationary_roots',{roots},'all_rate_roots_found_claimed',false);
        end
        out.legs=legs;out.status='FINITE_FIXED_LITERAL_ROOT_SCAN_COMPLETED';
    catch problem
        if strcmp(problem.identifier,'PKStationary:Clock'),rethrow(problem);end
        if strcmp(out.status,'EXACT_ALGEBRA_PRECONDITIONS_VALIDATED'),out.status='UNASSESSED_SCAN_INCOMPLETE';end
        out.precondition_failure=sfFailure(problem);
    end
    function v=rate(t),sfCheck(limit);value=sfPoint(t,x,a,s);v=value.gdot(leg);end
end
function v=sfPoint(t,x,a,s)
    st=s.State;w=sqrt(a.k_s./a.l_0.^2);A=x(s.Leg.AngleIndices)-a.rsla;B=x(s.Leg.RateIndices)./w;
    alpha=a.rsla+A.*cos(w*t)+B.*sin(w*t);adot=-A.*w.*sin(w*t)+B.*w.*cos(w*t);addot=-w.^2.*(alpha-a.rsla);
    state=x;state(st.x)=x(st.x)+x(st.dx)*t;state(st.y)=x(st.y)+x(st.dy)*t-t^2/2;state(st.dy)=x(st.dy)-t;
    state(s.Leg.AngleIndices)=alpha;state(s.Leg.RateIndices)=adot;theta=x(st.phi)+alpha;
    g=state(st.y)+a.s*sin(x(st.phi))-a.l_0.*cos(theta);
    gd=state(st.dy)+a.l_0.*sin(theta).*adot;
    gdd=-1+a.l_0.*(cos(theta).*adot.^2+sin(theta).*addot);
    v=struct('local_time',t,'state14',state,'raw_phi',x(st.phi),'raw_alpha',alpha,'raw_theta',theta, ...
        'alpha_rate',adot,'alpha_acceleration',addot,'g',g,'gdot',gd,'gddot',gdd);
    assert(all(isfinite([state;g;gd;gdd])),'PKStationary:NonfiniteAlgebra','Fixed literal algebra must remain finite.');
end
function d=savedDigest(a),d=C1ScientificDigest_v3(a);end
function f=sfFailure(p),f=struct('identifier',p.identifier,'message',p.message,'stack',p.stack);end
function sfRead2(file,digest),for pass=1:2,a=load(file,'audit','audit_digest');assert(strcmp(a.audit_digest,digest)&&strcmp(C1ScientificDigest_v3(a.audit),digest),'PKStationary:Read2','Both actual native reads must preserve the scientific digest.');end,end
function sfVerify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,sfLiteral(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKStationary:Changed','An immutable source changed.');if isfield(r,'bytes'),d=dir(r.file);assert(isscalar(d)&&d.bytes==r.bytes,'PKStationary:Bytes','A source changed byte count.');end,end,end
function r=sfRef(file),d=dir(file);r=struct('file',sfLiteral(file),'sha256',RoundSHA256_v3(file),'bytes',d.bytes);end
function f=sfLiteral(v),f=char(java.io.File(v).getCanonicalPath());assert(strcmp(f,char(java.io.File(V3Path_v3(v)).getCanonicalPath())),'PKStationary:Alias','Use one literal path for hash/read/write.');end
function sfCheck(l),assert(sfUTC()<l.u&&sfNano()<l.m,'PKStationary:Clock','The unchanged original/local clock expired; retain actual outputs/stages.');end
function t=sfUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=sfNano(),t=double(java.lang.System.nanoTime());end
