function out=InspectPK30hCoreStageSize20261102(B,bindings,options)
%INSPECTPK30HCORESTAGESIZE20261102 Size measurements of one retained plain stage.
% No loader reconstruction, flow, Root, acceptance or scientific qualification.
% Isolated v7 sizes include their own headers/zlib and are NOT additive size
% predictions. The unchanged original stage, required heads and cap are kept.
    enteredUTC=csUTC();enteredMono=csNano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)), ...
        sort({'StageReference';'OriginalV2Reference';'ClosureReference'}))&&isstruct(options)&&isscalar(options) ...
        &&isequal(sort(fieldnames(options)),sort({'TemporaryDirectory';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,300)&&isequal(options.SaveMarginSeconds,60)&&B.capture.pid==feature('getpid'), ...
        'PKStageSize:Inputs','Use exact closed immutable stage/baseline/closure pins and one original300/60 diagnostic window.');
    assert(min(B.research_deadline_unix_seconds-enteredUTC,(B.research_deadline_monotonic_ns-enteredMono)/1e9)>302, ...
        'PKStageSize:WholeFit','The full300-second census must fit the unchanged original science grant.');
    finish=struct('u',enteredUTC+300,'m',enteredMono+300e9);work=struct('u',finish.u-60,'m',finish.m-60e9);
    stage=csLiteral(bindings.StageReference.file);v2=csLiteral(bindings.OriginalV2Reference.file);
    expected=fullfile(N,'Compact_Exports_20261030','PK30h_20261101_StoredCoreSet01','C1_PK_Component_0003_Core29.mat.pending.mat');
    assert(strcmp(stage,expected)&&strcmp(bindings.StageReference.sha256,'6f57fec69e3a0368f75dab2a0661156fc0a5671eb536840f97340008e67228c3') ...
        &&strcmp(bindings.OriginalV2Reference.sha256,'45835bb5024b1dc9b875c7b8f7b205769f537a4ff4144c763058537f44dbf401'), ...
        'PKStageSize:Authority','Inspect only the actual retained component3 stage and matched WHOLE original v2 baseline.');
    tempDir=csLiteral(options.TemporaryDirectory);tempFile=fullfile(tempDir,'field.mat');
    temporaryRoot=csLiteral(tempdir());
    assert(strcmp(fileparts(tempDir),temporaryRoot)&&startsWith(tempDir,[temporaryRoot,filesep,'PK30h_StageSize_'])&&isfolder(fileparts(tempDir)) ...
        &&~isfile(tempDir)&&~isfolder(tempDir),'PKStageSize:FreshTemp','Use a fresh task-owned direct child of MATLAB tempdir, never Drive-backed project storage or recursive cleanup.');
    names={'InspectPK30hCoreStageSize20261102','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3', ...
        'LoadC1SolutionCore29_v3','WriteBranchSolutionCore29_v3'};
    code=cellfun(@(n)csRef(which(n)),names(:),'UniformOutput',false);
    code{end+1,1}=csRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
    refs=[code;{bindings.StageReference;bindings.OriginalV2Reference;bindings.ClosureReference}];csVerify(refs);csCheck(work);
    assert(strcmp(RoundSHA256_v3(which('WriteBranchSolutionCore29_v3')),'3ac76a0b3c9852d00c4e7955489097a12f8ac8b1d12a2b85089fb0cc9116c0e7') ...
        &&strcmp(RoundSHA256_v3(which('LoadC1SolutionCore29_v3')),'79e879e565c1a6d6dd6112f327635f85efb5f3a2329cbec7588adf6a197a81a6'), ...
        'PKStageSize:Producer','Preserve the exact reviewed Writer/Loader; they are hashed only, never invoked by this census.');
    out=struct('schema','PK30h-retained-core-stage-size-census-v1','completed',false,'source_posthash',false, ...
        'bindings',bindings,'source_code',{code},'load_returned',false(1,2),'whole_digest_verified',false(1,2), ...
        'core_digest','','point_count',[],'matrix_shape',[],'stage_bytes',[],'original_v2_bytes',[],'whole_cap_bytes',[], ...
        'stage_to_original_ratio',[],'actual_stage_meets_cap',[],'top_field_whos',{{}},'measurements',{{}}, ...
        'temporary_directory',tempDir,'temporary_file',tempFile,'temporary_directory_created',false,'temporary_directory_removed',false, ...
        'save_returned_count',0,'unlink_returned_count',0,'failure',struct(),'own_process_exit_claimed',false, ...
        'scope','Saved plain size measurements only; no cap relaxation, dropped heads, split component, replay, admission, source retirement or native process-exit certification.');
    links=javaArray('java.nio.file.LinkOption',1);links(1)=javaMethod('valueOf','java.nio.file.LinkOption','NOFOLLOW_LINKS');
    try
        variables=whos('-file',stage);assert(isequal(sort({variables.name}),{'core_digest','solution_core29'}), ...
            'PKStageSize:Variables','The retained stage has exactly the declared core and digest variables.');
        for pass=1:2
            csCheck(work);saved=load(stage,'solution_core29','core_digest');out.load_returned(pass)=true;
            c=saved.solution_core29;actualDigest=C1ScientificDigest_v3(c);
            assert(strcmp(actualDigest,saved.core_digest),'PKStageSize:Digest','Each independent native read must verify the whole plain typed core digest.');
            if pass==1,out.core_digest=saved.core_digest;else,assert(strcmp(saved.core_digest,out.core_digest),'PKStageSize:Read2','Both native reads must retain the identical whole typed core.');end
            out.whole_digest_verified(pass)=true;clear saved
            if pass==1,clear c;end
        end
    keys={'schema','layout','point_count','solution_matrix','parameters','modes','native_ids','point_metadata','contexts', ...
        'policies','section_charts','orbit_evidence','saved_reports','native_energy','signed_mean_U','graph', ...
        'source_projection_digests','source_reference','qualification_reference','qualification_closure', ...
        'writer_audit_reference','original_v2_reference','original_v2_bytes','maximum_core_bytes','runtime_methods','runtime_environment', ...
        'producer_reference','historical_audit_scope','replay_scope'};
        assert(isstruct(c)&&isscalar(c)&&isequal(sort(fieldnames(c)),sort(keys(:))) ...
            &&strcmp(c.schema,'C1-self-contained-solution-core29-v1')&&c.point_count==472&&isequal(size(c.solution_matrix),[29,472]) ...
            &&c.original_v2_bytes==110861&&c.maximum_core_bytes==554305, ...
            'PKStageSize:Schema','Measure the literal472-point29-field stage under its unchanged original110861B/5x contract.');
        info=dir(stage);original=dir(v2);assert(isscalar(info)&&info.bytes==912287&&isscalar(original)&&original.bytes==110861, ...
            'PKStageSize:Bytes','Native measured file bytes must equal the actual closed stage and matched full original.');
        out.point_count=c.point_count;out.matrix_shape=size(c.solution_matrix);out.stage_bytes=info.bytes;out.original_v2_bytes=original.bytes;
        out.whole_cap_bytes=c.maximum_core_bytes;out.stage_to_original_ratio=double(info.bytes)/double(original.bytes);out.actual_stage_meets_cap=info.bytes<=c.maximum_core_bytes;
        [primitive,classifier]=heads();out.required_primitive_fields=primitive;out.required_classifier_fields=classifier;
        descriptors=cell(0,1);out.top_field_whos=cell(numel(keys),1);
        for k=1:numel(keys)
            value=c.(keys{k});header=whos('value');out.top_field_whos{k}=struct('field',keys{k},'class',header.class,'shape',header.size,'logical_bytes',header.bytes);
            descriptors{end+1,1}=struct('kind',1,'name',keys{k},'path',keys{k},'present_count',1,'required_count',1); %#ok<AGROW>
        end
        graphKeys={'schema';'role';'displayname';'physical_edges';'record_equalities';'qualified_aliases';'numerical_seams';'source_versions'};
        assert(isstruct(c.graph)&&isscalar(c.graph)&&isequal(sort(fieldnames(c.graph)),sort(graphKeys)), ...
            'PKStageSize:Graph','Inventory the exact unchanged eight-key typed graph.');
        for k=1:numel(graphKeys),descriptors{end+1,1}=struct('kind',2,'name',graphKeys{k},'path',['graph.',graphKeys{k}],'present_count',1,'required_count',1);end %#ok<AGROW>
        sets={evidenceNames(),{'schema_version','status','native_status','accepted','full_closure','full_closure_residual','acceptance_gates','classification','primitive'}};
        arrays={'orbit_evidence','saved_reports'};
        for setNumber=1:2
            sourceRows=c.(arrays{setNumber});assert(iscell(sourceRows)&&numel(sourceRows)==472,'PKStageSize:Rows','Count only the actual472 saved occurrence rows.');
            for k=1:numel(sets{setNumber})
                name=sets{setNumber}{k};present=nnz(cellfun(@(r)isstruct(r)&&isscalar(r)&&isfield(r,name),sourceRows));
                descriptors{end+1,1}=struct('kind',setNumber+2,'name',name,'path',[arrays{setNumber},'.',name,'(:)'], ...
                    'present_count',present,'required_count',472); %#ok<AGROW>
            end
        end
        assert(numel(descriptors)==57,'PKStageSize:Bound','Measure only29top+8graph+11evidence+9report descriptors.');out.measurements=cell(numel(descriptors),1);
        for k=1:numel(descriptors)
            d=descriptors{k};out.measurements{k}=struct('path',d.path,'present_count',d.present_count,'required_count',d.required_count, ...
                'class','','shape',[],'logical_bytes',[],'isolated_v7_bytes',[],'file_sha256','','save_returned',false,'unlink_returned',false,'status','PREPARED_NOT_INVOKED');
        end
        javaMethod('createDirectory','java.nio.file.Files',java.io.File(tempDir).toPath(),javaArray('java.nio.file.attribute.FileAttribute',0));out.temporary_directory_created=true;
        directoryKey=csKey(tempDir,false,links);
        for k=1:numel(descriptors)
            csCheck(work);d=descriptors{k};row=out.measurements{k};
            if d.present_count~=d.required_count,out.measurements{k}.status='UNASSESSED_NOT_ALL_ROWS_PRESENT';continue;end
            if d.kind==1,value=c.(d.name);elseif d.kind==2,value=c.graph.(d.name);
            else
                sourceRows=c.(arrays{d.kind-2});value=cell(472,1);for j=1:472,value{j}=sourceRows{j}.(d.name);end
            end
            header=whos('value');row.class=header.class;row.shape=header.size;row.logical_bytes=header.bytes;out.measurements{k}=row;
            assert(~javaMethod('exists','java.nio.file.Files',java.io.File(tempFile).toPath(),links), ...
                'PKStageSize:TempAbsent','The one owned temporary file must be absent before every independent save.');
            save(tempFile,'value','-v7');out.measurements{k}.save_returned=true;out.save_returned_count=out.save_returned_count+1;out.measurements{k}.status='ACTUAL_SAVE_RETURNED_VERIFICATION_PENDING';
            fileKey=csKey(tempFile,true,links);fileInfo=dir(tempFile);fileHash=RoundSHA256_v3(tempFile);
            out.measurements{k}.isolated_v7_bytes=fileInfo.bytes;out.measurements{k}.file_sha256=fileHash;out.measurements{k}.status='SAVED_VERIFIED_UNLINK_PENDING';
            csCheck(work);assert(strcmp(csKey(tempFile,true,links),fileKey)&&strcmp(RoundSHA256_v3(tempFile),fileHash), ...
                'PKStageSize:OwnFile','Delete only the same exact regular owned temporary file, with unchanged fileKey/fullSHA.');
            javaMethod('delete','java.nio.file.Files',java.io.File(tempFile).toPath());out.measurements{k}.unlink_returned=true;out.unlink_returned_count=out.unlink_returned_count+1;out.measurements{k}.status='ACTUAL_UNLINK_RETURNED_ABSENCE_PENDING';
            assert(~javaMethod('exists','java.nio.file.Files',java.io.File(tempFile).toPath(),links),'PKStageSize:Unlink','Record actual canonical absence after the exact own-file unlink.');
            out.measurements{k}.status='MEASURED_AND_OWN_FILE_REMOVED';clear value sourceRows
        end
        csCheck(work);assert(strcmp(csKey(tempDir,false,links),directoryKey),'PKStageSize:OwnDirectory','Remove only the unchanged own directory; Java delete refuses a nonempty one.');
        javaMethod('delete','java.nio.file.Files',java.io.File(tempDir).toPath());out.temporary_directory_removed=true;
        csVerify(refs);csCheck(finish);out.source_posthash=true;out.completed=true;
    catch problem
        out.failure=struct('identifier',problem.identifier,'message',problem.message);
        % Do not clean uncertain files/directories or alter the retained stage.
    end
    out.elapsed_seconds=(csNano()-enteredMono)/1e9;out.original_limits=struct('MaxWallSeconds',300,'SaveMarginSeconds',60);
    out.compression_scope='Actual isolated v7 measurements include per-file headers/compression context. Their sum is not a prediction of whole-file recompression; no values, heads or relation evidence were omitted.';
    printed=out;encoded=jsonencode(printed);
    if numel(encoded)>30000
        fullDigest=C1ScientificDigest_v3(out);printed.top_field_whos=struct('status','OMITTED_STDOUT_LIMIT','count',numel(out.top_field_whos),'full_result_typed_digest',fullDigest);encoded=jsonencode(printed);
    end
    if numel(encoded)>30000
        fullDigest=C1ScientificDigest_v3(out);compact=struct('status','PARALLEL_COLUMNS_STDOUT_LIMIT','full_result_typed_digest',fullDigest);
        columns={'path','present_count','required_count','class','shape','logical_bytes','isolated_v7_bytes','file_sha256','save_returned','unlink_returned','status'};
        for k=1:numel(columns),name=columns{k};compact.(name)=cellfun(@(r)r.(name),out.measurements,'UniformOutput',false);end
        printed.measurements=compact;encoded=jsonencode(printed);
    end
    assert(numel(encoded)<=30000,'PKStageSize:Stdout','Retain all measured rows and actual cleanup/partial flags in bounded metadata stdout.');
    fprintf('PK30H_CORE_STAGE_SIZE_ACTUAL_RETURN %s\n',encoded);
end

function key=csKey(file,regular,links)
    path=java.io.File(file).toPath();assert(~javaMethod('isSymbolicLink','java.nio.file.Files',path), ...
        'PKStageSize:Symlink','An owned temporary path must never be a symbolic link.');
    attrs=javaMethod('readAttributes','java.nio.file.Files',path,'basic:*',links);nativeKey=attrs.get('fileKey');
    assert(~isempty(nativeKey)&&((regular&&javaMethod('isRegularFile','java.nio.file.Files',path,links)) ...
        ||(~regular&&javaMethod('isDirectory','java.nio.file.Files',path,links))), ...
        'PKStageSize:FileKind','Require the actual regular file or directory and a stable native fileKey.');key=char(nativeKey.toString());
end
function csVerify(refs)
    for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,csLiteral(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
            'PKStageSize:Changed','A consumed immutable stage/baseline/closure or source recipe changed.');
        if isfield(r,'bytes'),d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes,'PKStageSize:ReferenceBytes','Retain every declared actual whole-file byte count.');end
    end
end
function r=csRef(file),r=struct('file',csLiteral(file),'sha256',RoundSHA256_v3(file));end
function file=csLiteral(value),file=char(java.io.File(value).getCanonicalPath());assert(strcmp(file,char(java.io.File(V3Path_v3(value)).getCanonicalPath())),'PKStageSize:Alias','Hash/native I/O must use the same literal path.');end
function csCheck(l),assert(csUTC()<l.u&&csNano()<l.m,'PKStageSize:Clock','Original300/60 UTC/JVM diagnostic window expired; preserve actual partial files and counters.');end
function t=csUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=csNano(),t=double(java.lang.System.nanoTime());end
function [p,g]=heads()
    p={'status','reason','recorded_period','primitive_period','cover_count','drift','primitive_drift','closure_error','mode_closed','checked_cover_bound','state_tolerance','event_phase_tolerance','evidence_level','global_primitivity_proved','event_history_complete','proper_apex_count'};
    g={'contract_version','synchrony_predicate_version','label','alias','abbreviation','status','validated_gait_type','canonical_point_label','canonical_label_qualified','flight_count','flight_count_certain','primitive_flight_count','period_used','descriptive_only','isotropy_proved'};
end
function keys=evidenceNames()
    keys={'return_policy','return_policy_name','return_multiplicity','candidate_section_count','candidate_apex_count','accepted_crossing_index','accepted_apex_index','section_relative_event_signature','cyclic_event_signature','primitive_cycle','gait_identification'};
end
