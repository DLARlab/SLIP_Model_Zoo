function result=PreparePK30h0170To0072Join20261101(extensionQueueRef,B,options)
%PREPAREPK30H0170TO0072JOIN20261101 One bounded target-only PAL screen.
% No Run, Root, Map, classifier, ODE, replay or fresh admission is performed.
    enteredUTC=utc();enteredMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(nargin==3&&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'}))&&isequal(options.MaxWallSeconds,600)&&isequal(options.SaveMarginSeconds,60), ...
        'PKJoinPlan:Options','Use one explicit fresh plan and fixed600/60.');
    assert(B.capture.pid==feature('getpid'),'PKJoinPlan:Budget','Caller calibrates the original grant in this process.');
    finish=lim(min(B.research_deadline_unix_seconds,enteredUTC+600),min(B.research_deadline_monotonic_ns,enteredMono+600e9));
    work=lim(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    file=literal(options.OutputFile);stage=[file,'.pending.mat'];[~,tag,ext]=fileparts(file);
    assert(strcmp(ext,'.mat')&&strcmp(tag,'PK30h_20261101_0170To0072_JoinPlan') ...
        &&strcmp(file,fullfile(literal(fullfile(N,'Audits')),[tag,'.mat']))&&~isfile(file)&&~isfile(stage), ...
        'PKJoinPlan:Fresh','Retain prior plan/stage and use the declared fresh audit MAT.');
    expectedQueue=pin(fullfile(N,'Audits','PK30h_20261101_0170Radius008_Extension01.mat'),'8b11d57832ce90512cec731c058f6751bec081d38157bbcf15c320ea1c85e5c7');
    assert(isequaln(orderfields(extensionQueueRef),orderfields(expectedQueue)), ...
        'PKJoinPlan:Extension','Use the exact closed six-point extension audit reference.');
    oldPlanRef=pin(fullfile(N,'Audits','PK30h_20261101_FrontierClosure_Plan.mat'),'acfd62c53b48f175344651bb1cbb6b351c30301dade7c0be6225f2a379e1b821');
    sustainedRef=pin(fullfile(N,'Audits','PK30h_20261101_ProductionSustained01.mat'),'7bc349e102f0cf960bae0ebf8a849a1de65c1bf245dc3228fe88547bddbb224a');
    targetRef=pin(fullfile(N,'Connected_PK_PK30h_20261101','C1_PK_0072_Low.mat'),'95fcae1ace29e0fdf1bcd42bd46a0b3c7d78b1c5b75e78c17ece73607d906a67');
    targetCPRef=pin(fullfile(N,'Audits','PK30h_20261101_0072_Low_Checkpoint.mat'),'b2359de2d37b829b1443808400307658c79bef73992c9b529a295232de02f54b');
    names={'PreparePK30h0170To0072Join20261101','BranchSolutionFile_v3','OrbitContentIdentity_v3','RecordedReturnPolicy_v3', ...
        'MatchingReturnSection_v3','QuadrupedSchema_v3','GaitSemanticTable_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Path_v3','V3Root_v3', ...
        'RunC1Continuation_v3','RunC1ContinuationQueue_v3','AcquireC1NumericalOverlap_v3','HybridSimulator_v3'};
    code=cellfun(@(n)reference(which(n)),names(:),'UniformOutput',false);
    code{end+1}=reference(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
    refs=[{extensionQueueRef;oldPlanRef;sustainedRef;targetRef;targetCPRef};code];verify(refs);check(work);
    % Current provider references bind this invocation; old Plan source tuples
    % remain historical options authority, with no claimed source-epoch equality.
    plan=struct('schema','PK30h-0170-to0072-terminal-join-plan-v1','original_budget',B,'options',options,'original_finish',finish, ...
        'input_references',{refs},'source_code',{code},'extension_queue_reference',extensionQueueRef,'options_authority_reference',oldPlanRef, ...
        'source_context',struct(),'target_context',struct(),'terminal_walk',struct(),'native_intake',{{}},'candidates',{{}}, ...
        'association',struct('selected',false,'status','UNASSESSED'),'completed',false,'source_posthash',false,'failure',struct(), ...
        'public_bulk_calls_attempted',0,'public_bulk_calls_returned',0,'root_map_classifier_ODE_replay_calls',0, ...
        'fresh_admission_claimed',false,'global_connection_or_absence_claimed',false);
    try
        x=load(oldPlanRef.file,'plan');old=x.plan;
        assert(old.completed&&old.source_posthash&&numel(old.pilot_queue)==1&&old.association.selected, ...
            'PKJoinPlan:OptionsAuthority','Require the exact completed saved Plan with its original proposed options.');grant(B,old.original_budget);
        assert(isfield(old.association,'overlap_options'),'PKJoinPlan:OptionsAuthority','Do not invent missing overlap options.');
        template=old.association.overlap_options;
        x=load(extensionQueueRef.file,'audit');A=x.audit;grant(B,A.budget);closedAudit(A);
        assert(numel(A.queue)==1&&numel(A.jobs)==1&&A.queue{1}.execute, ...
            'PKJoinPlan:ExtensionJob','Require exactly the one returned extension job.');
        q=A.queue{1};r=A.jobs{1};basis=old.pilot_queue{1};expected=basis.options;expected.MaxAccepted=6;expected.MaxAttempts=12;
        assert(strcmp(q.id,basis.id)&&isequaln(q.source_reference,basis.source_reference)&&isequal(q.pair(:),basis.pair(:)) ...
            &&strcmp(q.source_reference.sha256,'d41b420cf67df9c249b5744a0235947d06c7c3dd15bd27dc96d50bf42ef115f0') ...
            &&strcmp(q.output_file,basis.output_file)&&strcmp(q.symmetry,basis.symmetry) ...
            &&isequaln(orderfields(q.options),orderfields(expected)), ...
            'PKJoinPlan:ExtensionOptions','Retain the exact old pilot birth authority and only the executed six/twelve cap changes.');
        assert(strcmp(r.output_reference.sha256,'21611b1a7bcf44c66a9f66819a5fe88fad087fe4e2021cc40b8e5cff5985b506') ...
            &&strcmp(r.checkpoint_reference.sha256,'f275b8cc87c719e89bbf925408fe0fd7682baa6da7ed7f65d927c74ba1d34d18'), ...
            'PKJoinPlan:ExtensionGeneration','Bind the actual closed current output/checkpoint generation.');
        [source,extra]=closedContext(q,r,true);refs=[refs;extra];plan.source_context=source.header;
        assert(q.options.MaximumStep==.08&&strcmp(q.options.Algorithm,'root-newton')&&q.options.UsePhasePredictor ...
            &&~q.options.ReusePreviousJacobian&&q.options.IntegrationMaxStep==.001, ...
            'PKJoinPlan:SourceController','Keep the actual .08/root-newton/phase/no-native-warm context.');
        x=load(sustainedRef.file,'audit');S=x.audit;grant(B,S.budget);closedAudit(S);
        at=find(cellfun(@(z)strcmp(z.output_file,targetRef.file),S.queue));assert(isscalar(at),'PKJoinPlan:TargetJob','Use one actual grown0072Low job.');tq=S.queue{at};
        at=find(cellfun(@(z)strcmp(z.id,tq.id),S.jobs));assert(isscalar(at),'PKJoinPlan:TargetReturn','Use the unique actual returned target job.');tr=S.jobs{at};
        assert(isequaln(tr.output_reference,targetRef)&&isequaln(tr.checkpoint_reference,targetCPRef), ...
            'PKJoinPlan:TargetGeneration','Frozen target branch/checkpoint must match the closed actual Queue.');
        [target,extra]=closedContext(tq,tr,false);refs=[refs;extra];plan.target_context=target.header;
        assert(target.pair(2)==54,'PKJoinPlan:Terminal','Bind terminal54 through the actual target checkpoint, not an inferred count.');
        walk=terminalWalk(target.index,54,target.owner,8);plan.terminal_walk=walk;
        pairs=[source.pair;fliplr(source.pair)];selected={source.pair(:);walk.nodes(:)};jobs={source;target};cache=cell(2,1);
        for k=1:2
            check(work);plan.public_bulk_calls_attempted=plan.public_bulk_calls_attempted+1;
            [os,rs,ms]=BranchSolutionFile_v3.loadSolutions(jobs{k}.reference.file,selected{k});
            plan.public_bulk_calls_returned=plan.public_bulk_calls_returned+1;
            assert(numel(os)==numel(selected{k})&&numel(rs)==numel(os)&&numel(ms)==numel(os), ...
                'PKJoinPlan:BulkShape','Every declared occurrence needs its actual public native view.');
            cache{k}=struct('indices',selected{k},'orbits',{os},'reports',{rs},'metadata',{ms});hs=cell(numel(os),1);
            for j=1:numel(os)
                p=jobs{k}.index.points{selected{k}(j)};hs{j}=header(os{j},rs{j},ms{j},p);
                assert(strcmp(hs{j}.owner,jobs{k}.owner),'PKJoinPlan:SelectedOwner','Every selected occurrence retains the declared actual owner.');
                hs{j}.literal_point_metadata=ms{j};hs{j}.actual_index_record=p;
            end
            plan.native_intake{k}=struct('source_reference',jobs{k}.reference,'selected_indices',selected{k},'headers',{hs}, ...
                'public_bulk_calls',1,'scope','Literal native selected records; no independent read2 or new admission.');
        end
        scores=zeros(0,4);
        for rank=1:numel(walk.nodes)
            for orientation=1:2
                check(work);g=screen(cache{1},cache{2},pairs(orientation,:),walk.nodes(rank),source.index);
                g.target_index=walk.nodes(rank);g.target_order=rank;g.orientation_rank=orientation;plan.candidates{end+1,1}=g;
                if g.eligible,scores(end+1,:)=[g.predictor_distance,rank,orientation,numel(plan.candidates)];end %#ok<AGROW>
            end
        end
        plan.selection_rule=struct('target_order',walk.nodes(:).','orientations',pairs,'minimum_step',1e-7,'maximum_step',.08, ...
            'maximum_predictor_distance',.001,'ranking','Eligible predictor_distance, then declared terminal-to-ancestor target order, then explicit orientation order', ...
            'unselected_scope','All other target occurrences and source pairs are UNASSESSED; no coverage, nearest-root or absence claim.');
        base=fullfile(N,'Connected_PK_PK30h_20261101','C1_PK_0170To0072_Join01');
        future=struct('branch',[base,'.mat'],'checkpoint',fullfile(N,'Audits','PK30h_20261101_0170To0072_Join01_Checkpoint.mat'), ...
            'acquisition',fullfile(N,'Audits','PK30h_20261101_0170To0072_Join01_Acquisition.mat'),'isolated',[base,'_isolated.mat']);
        paths=struct2cell(future);for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k})&&~isfile([paths{k},'.pending.mat']), ...
            'PKJoinPlan:FutureFresh','Reserve only distinct fresh derived branch/checkpoint/acquisition/isolated paths.');end
        assert(numel(unique(paths))==numel(paths),'PKJoinPlan:FutureDistinct','Future output paths must be distinct.');plan.future_output_paths=future;
        plan.options_basis=struct('authority_reference',oldPlanRef,'original_overlap_options',template, ...
            'scope','Saved Plan.association.overlap_options supplies all unchanged tolerances, service, family and gates; old source tuples are historical authority only.');
        if isempty(scores)
            plan.association=struct('selected',false,'status','UNASSESSED_no_eligible_pair_in_declared_terminal_neighborhood', ...
                'scope','Finite screen refusal only; no disconnection, endpoint, nonexistence or global coverage conclusion.');
        else
            scores=sortrows(scores,[1,2,3]);g=plan.candidates{scores(1,4)};o=template;run=o.RunOptions;
            assert(strcmp(o.Symmetry,'pronk')&&strcmp(run.Algorithm,'root-newton')&&run.UsePhasePredictor ...
                &&run.IntegrationMaxStep==.001&&run.MinimumStep==1e-7&&~run.ReusePreviousJacobian ...
                &&run.MaxWallSeconds==360&&run.TrialSeconds==180&&run.PhaseSeconds==30&&o.FineSeconds==120 ...
                &&o.MaxWallSeconds==1800&&o.SaveMarginSeconds==60,'PKJoinPlan:OptionsContract','Retain the existing ordinary correction/four-fine service exactly.');
            o.OutputFile=future.acquisition;o.BranchFile=future.branch;o.CheckpointFile=future.checkpoint;o.SourceAuditReference=struct();o.MaximumPALStep=.08;
            run.ComponentIdentity='PK30h_20261101_0170To0072_Join01';run.MaxAccepted=1;run.MaxAttempts=1;run.ReusePreviousJacobian=false;
            run.MaximumStep=.08;run.InitialStep=g.requested_step;run.CheckpointFile=future.checkpoint;o.RunOptions=run;
            plan.association=struct('selected',true,'status','one_eligible0170_to0072_owned_PAL_plane_selected', ...
                'source_reference',source.reference,'source_pair',g.source_pair,'source_native_ids',{g.source_native_ids}, ...
                'target_reference',target.reference,'target_index',g.target_index,'target_native_id',g.target_native_id, ...
                'selected_geometry',g,'overlap_options',o,'source_audit_binding','Caller fills exact published PlanRef only after publication.', ...
                'context_scope','One proposed future Acquire only; no target seed, root call or numerical relation is earned by this plan.');
        end
        verify(refs);check(work);plan.input_references=refs;plan.source_posthash=true;plan.completed=true;
        plan.scope='Bounded source/current-edge to target-only terminal-neighborhood screen. Both explicit source-edge orientations are observations, not automatic retries; no physics service or connection is earned.';
    catch e,plan.failure=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);plan.input_references=refs;end
    % Raw plan custody precedes every optional output and fallible digest check.
    save(stage,'plan','-v7');a=load(stage,'plan');b=load(stage,'plan');same(plan,a.plan);same(plan,b.plan);
    assert(plan.completed&&plan.source_posthash,'PKJoinPlan:Incomplete','Retain the native pending plan: %s',jsonencode(plan.failure));
    check(finish);stageSHA=RoundSHA256_v3(stage);assert(~isfile(file),'PKJoinPlan:PublishFresh','Retain any actual concurrent final.');
    javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath()) ...
        &&strcmp(RoundSHA256_v3(stage),stageSHA),'PKJoinPlan:OwnStage','Remove only the unchanged linked own stage.');
    delete(stage);a=load(file,'plan');b=load(file,'plan');same(plan,a.plan);same(plan,b.plan);verify(refs);check(finish);
    result=struct('completed',true,'source_posthash',true,'plan_reference',reference(file),'selected_association',plan.association.selected, ...
        'candidate_count',numel(plan.candidates),'selection_scope',plan.selection_rule,'public_bulk_calls',plan.public_bulk_calls_returned, ...
        'root_map_classifier_ODE_replay_calls',0,'fresh_admission_claimed',false,'source_current_pair',plan.source_context.current_pair, ...
        'target_terminal_walk',plan.terminal_walk.nodes,'future_output_paths',plan.future_output_paths);
    if plan.association.selected
        g=plan.association.selected_geometry;result.selected_geometry=struct('source_pair',g.source_pair,'source_native_ids',{g.source_native_ids}, ...
            'target_index',g.target_index,'target_native_id',g.target_native_id,'requested_step',g.requested_step, ...
            'predictor_distance',g.predictor_distance,'eligible',g.eligible,'target_is_root_seed',false);
    end
    % Optional output cannot invalidate an already verified durable plan.
    try,fprintf('PK30H_0170_TO0072_JOIN_PLAN_RETURN %s\n',jsonencode(result));
    catch,fprintf('PK30H_0170_TO0072_JOIN_PLAN_RETURN {"completed":true,"source_posthash":true,"optional_output_unavailable":true}\n');end
end
function closedAudit(A)
    assert(strcmp(A.schema,'resident-native-frontier-queue-v1')&&A.completed&&A.source_posthash&&A.all_requested_jobs_returned ...
        &&isempty(fieldnames(A.failure)),'PKJoinPlan:ClosedQueue','Require the actual completed clean returned Queue; actual process exit remains external.');
end
function [d,refs]=closedContext(q,r,requireController)
    refs={q.source_reference;r.output_reference;r.checkpoint_reference};verify(refs);x=load(r.checkpoint_reference.file,'summary');s=x.summary;
    assert(strcmp(q.id,r.id)&&q.execute&&r.persistence_completion_confirmed&&r.pending_count==0 ...
        &&isempty(s.pending_batch)&&isempty(fieldnames(s.pending_admission))&&~s.batch_flush_attempted ...
        &&strcmp(r.status,s.status)&&strcmp(r.output_reference.file,q.output_file)&&strcmp(s.output_file,q.output_file) ...
        &&strcmp(r.checkpoint_reference.file,q.options.CheckpointFile)&&isequaln(s.configuration.source_reference,q.source_reference) ...
        &&strcmp(s.configuration.source_file,q.source_reference.file)&&isequal(s.configuration.source_indices(:),q.pair(:)) ...
        &&strcmp(s.configuration.component_identity,q.options.ComponentIdentity)&&strcmp(s.configuration.symmetry,q.symmetry), ...
        'PKJoinPlan:ClosedCP','Returned Queue, birth source and current clean checkpoint must join exactly.');
    controller=member(s,'controller_context',struct());
    if requireController
        assert(isfield(s,'controller_context')&&controller.maximum_step==q.options.MaximumStep ...
            &&controller.phase_predictor==q.options.UsePhasePredictor&&strcmp(controller.algorithm,q.options.Algorithm), ...
            'PKJoinPlan:ControllerContext','The current extension checkpoint must retain its declared controller.');
    end
    ix=BranchSolutionFile_v3.index(r.output_reference.file);pair=s.current_pair(:).';
    validateattributes(pair,{'numeric'},{'real','finite','integer','positive','vector','numel',2,'<=',numel(ix.points)});
    e=find(cellfun(@(z)isequal([z.from,z.to],pair),ix.edges));owner=s.configuration.component_identity;
    assert(isscalar(e)&&numel(ix.points)==s.final_output_count&&edgeOwner(ix,ix.edges{e}) ...
        &&strcmp(ix.edges{e}.component_identity,owner),'PKJoinPlan:PhysicalPair','Use the actual directed same-owner current physical edge.');
    h=struct('job_id',r.id,'queue_job',q,'returned_job',r,'output_reference',r.output_reference, ...
        'checkpoint_reference',r.checkpoint_reference,'current_pair',pair,'stored_edge',ix.edges{e},'final_output_count',s.final_output_count, ...
        'returned_persistence_completion_confirmed',r.persistence_completion_confirmed, ...
        'checkpoint_provisional_persistence_completion_confirmed',s.persistence_completion_confirmed,'configuration',s.configuration, ...
        'controller_context',controller,'controller_context_present',isfield(s,'controller_context'), ...
        'scope','Stored provisional persistence flag is literal and distinct from returned Queue persistence; absent historical controller metadata stays UNASSESSED; no process exit is inferred.');
    d=struct('reference',r.output_reference,'pair',pair,'owner',owner,'index',ix,'header',h);
end
function w=terminalWalk(ix,terminal,owner,maximum)
    assert(terminal>=1&&terminal<=numel(ix.points)&&strcmp(ix.points{terminal}.component_identity,owner), ...
        'PKJoinPlan:TerminalOwner','The declared terminal must be an actual occurrence of this owner.');
    outgoing=find(cellfun(@(e)e.from==terminal&&strcmp(e.component_identity,owner),ix.edges));
    assert(isempty(outgoing),'PKJoinPlan:TerminalOutgoing','The frozen terminal may not have an unassessed outgoing owned physical edge.');
    nodes=terminal;edges=cell(0,1);reason='declared_maximum_nodes_reached';
    while numel(nodes)<maximum
        incoming=find(cellfun(@(e)e.to==nodes(end)&&strcmp(e.component_identity,owner),ix.edges));
        if isempty(incoming),reason='no_actual_incoming_owned_physical_edge';break;end
        assert(isscalar(incoming)&&edgeOwner(ix,ix.edges{incoming}),'PKJoinPlan:UniqueIncoming','Walk only a unique actual consistent-owner incoming physical edge.');
        e=ix.edges{incoming};assert(~ismember(e.from,nodes),'PKJoinPlan:Cycle','Do not repeat a node in the declared finite predecessor walk.');
        edges{end+1,1}=e;nodes(end+1)=e.from; %#ok<AGROW>
    end
    assert(~isempty(edges),'PKJoinPlan:IncidentTarget','Terminal neighborhood must contain an actual physical incident edge.');
    w=struct('terminal',terminal,'owner',owner,'maximum_nodes',maximum,'nodes',nodes,'incoming_edges',{edges},'stop_reason',reason, ...
        'order','Terminal first, then unique actual incoming same-owner P predecessor; no numerical/exact/alias traversal.', ...
        'unselected_scope','All other occurrences UNASSESSED. Reversed traversal does not authorize reverse Run execution.');
end

function h=header(o,r,m,p)
    [~,policy]=RecordedReturnPolicy_v3(r);g=member(r,'classification',struct());
    events=o.event_history;eventIDs=[];eventTimes=[];historyAvailable=isstruct(events)&&all(isfield(events,{'is_stop','guard_id','time'}));
    if historyAvailable
        events=events(~[events.is_stop]);s=QuadrupedSchema_v3.shared();eventIDs=zeros(numel(events),1);eventTimes=eventIDs;
        for k=1:numel(events),eventIDs(k)=s.eventId(events(k).guard_id);eventTimes(k)=events(k).time;end
    end
    h=struct('index',p.index,'native_id',OrbitContentIdentity_v3(o),'owner',m.component_identity, ...
        'state',o.initial_state,'parameter',o.parameter,'mode',o.initial_mode,'period',o.period,'stride',o.stride_displacement, ...
        'native_energy_index',p.nativeE,'signed_meanU_index',p.signedmeanU,'policy',policy,'classification',g, ...
        'acceptance_gates',member(r,'acceptance_gates',struct()),'section',o.section_chart, ...
        'section_signature',o.section_relative_event_signature,'cyclic_signature',o.cyclic_event_signature, ...
        'return_multiplicity',o.return_multiplicity,'event_history_available',historyAvailable, ...
        'event_guard_ids',eventIDs,'event_times',eventTimes, ...
        'saved_current_all9_PK',admitted(r),'fresh_admission_claimed',false);C1ScientificDigest_v3(h);
end
function g=screen(source,target,pair,index,ix)
    g=struct('eligible',false,'source_pair',pair,'failure',struct(),'energy_chart_regularity','UNASSESSED_until_future_native_Run', ...
        'target_is_root_seed',false,'target_scope','Only selects the owned PAL plane.');
    try
        [a,ra,ma]=get(source,pair(1));[b,rb,mb]=get(source,pair(2));[t,rt,mt]=get(target,index);
        g.source_native_ids={OrbitContentIdentity_v3(a);OrbitContentIdentity_v3(b)};g.target_native_id=OrbitContentIdentity_v3(t);
        e=find(cellfun(@(z)isequal(sort([z.from,z.to]),sort(pair)),ix.edges));
        assert(isscalar(e)&&edgeOwner(ix,ix.edges{e})&&strcmp(ma.component_identity,mb.component_identity), ...
            'PKClosure:SourceEdge','Both explicit orientations must bind the same actual owned edge.');g.stored_edge=ix.edges{e};
        assert(admitted(ra)&&admitted(rb)&&admitted(rt),'PKClosure:Admission','Require literal saved current-contract one-flight PK/all9.');
        [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);[~,pt]=RecordedReturnPolicy_v3(rt);
        g.complete_policy_equal=pa.complete&&pb.complete&&pt.complete&&isequaln(pa.configuration,pb.configuration)&&isequaln(pb.configuration,pt.configuration);
        g.exact_pq=isequaln(a.parameter,b.parameter)&&isequaln(b.parameter,t.parameter)&&isequaln(a.initial_mode,b.initial_mode)&&isequaln(b.initial_mode,t.initial_mode);
        g.source_section=MatchingReturnSection_v3(a,b,{ra,rb});g.target_section=MatchingReturnSection_v3(b,t,{rb,rt});
        g.section_tokens_equal=isequaln(a.section_relative_event_signature,b.section_relative_event_signature)&&isequaln(b.section_relative_event_signature,t.section_relative_event_signature);
        g.cyclic_tokens_equal=isequaln(a.cyclic_event_signature,b.cyclic_event_signature)&&isequaln(b.cyclic_event_signature,t.cyclic_event_signature);
        assert(g.complete_policy_equal&&g.exact_pq&&g.source_section.compatible&&g.target_section.compatible ...
            &&g.section_tokens_equal&&g.cyclic_tokens_equal,'PKClosure:Contract','Exact saved policy/pq/marked-section/token contracts differ.');
        assert(~any(b.initial_mode)&&all(isfinite([a.initial_state(:);b.initial_state(:);t.initial_state(:)])), ...
            'PKClosure:FlightChart','Use actual all-flight raw states for the source-backed4D pronk calculation.');
        s=QuadrupedSchema_v3.shared();p=b.parameter(:);x=b.initial_state(:);parameter=s.Parameter;
        defects=[abs(x(s.State.dy)),norm(x([s.State.phi,s.State.dphi]),Inf), ...
            norm(x(s.Leg.AngleIndices)-x(s.State.alphaBL),Inf),norm(x(s.Leg.RateIndices)-x(s.State.dalphaBL),Inf), ...
            norm(p([parameter.k_l_b,parameter.k_s_b,parameter.l_l_b,parameter.rsla_b]) ...
                -p([parameter.k_l_f,parameter.k_s_f,parameter.l_l_f,parameter.rsla_f]),Inf),abs(p(parameter.l_com)-.5)];
        g.source_base_chart_defects=defects;
        assert(all(defects(1:4)<=1e-8)&&all(defects(5:6)<=1e-12), ...
            'PKClosure:PronkChart','The admitted base must satisfy the existing all-flight apex/pronk coordinate preconditions.');
        ids=[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL];
        assert(isequal(ids,[2,3,7,8]),'PKClosure:Coordinates','Retain the actual current four independent raw-coordinate indices.');
        ua=a.initial_state(ids);ua=ua(:);ub=b.initial_state(ids);ub=ub(:);ut=t.initial_state(ids);ut=ut(:);
        lift=b.initial_state(:);lift(ids)=ub;lift([9,11,13])=lift(7);lift([10,12,14])=lift(8);
        assert(isequaln(lift,b.initial_state(:)),'PKClosure:BaseLift','The unchanged admitted base must roundtrip exactly; no snap or projection.');
        scale=max([ones(4,1),abs(ua),abs(ub)],[],2);delta=(ub-ua)./scale;chord=norm(delta);
        assert(isfinite(chord)&&chord>1e-10,'PKClosure:Chord','Use a resolved actual preceding-pair chord.');tangent=delta/chord;
        ds=dot(tangent,(ut-ub)./scale);predictor=ub+scale.*(ds*tangent);
        g.coordinate_indices=ids;g.source_coordinates=[ua,ub];g.target_coordinates=ut;g.scale=scale;g.tangent=tangent;
        g.chord=chord;g.requested_step=ds;g.predictor_coordinates=predictor;g.predictor_distance=norm((ut-predictor)./scale);
        g.source_owner=ma.component_identity;g.target_owner=mt.component_identity;
        g.eligible=isfinite(ds)&&ds>=1e-7&&ds<=.08&&isfinite(g.predictor_distance)&&g.predictor_distance<=.001;
        g.scope='Run243-246 max1 preceding-pair scales and signed projection only; no abs(ds), automatic flip, target seed, Map or energy-pivot test.';
    catch e,g.failure=struct('identifier',e.identifier,'message',e.message);end
end
function [o,r,m]=get(d,index)
    k=find(d.indices==index);assert(isscalar(k),'PKClosure:SelectedIndex','One actual selected native view is required.');o=d.orbits{k};r=d.reports{k};m=d.metadata{k};
end
function yes=admitted(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    gates=member(r,'acceptance_gates',struct());g=member(r,'classification',struct());[~,version]=GaitSemanticTable_v3();
    yes=isequal(member(r,'accepted',false),true)&&all(isfield(gates,keys))&&strcmp(member(g,'contract_version',''),version) ...
        &&strcmp(member(g,'validated_gait_type',''),'PK')&&strcmp(member(g,'canonical_point_label',''),'PK') ...
        &&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1);
    for k=1:numel(keys),yes=yes&&isequal(member(gates,keys{k},false),true);end
end
function yes=edgeOwner(ix,e)
    yes=e.from>=1&&e.to>=1&&e.from<=numel(ix.points)&&e.to<=numel(ix.points) ...
        &&strcmp(ix.points{e.from}.component_identity,e.component_identity)&&strcmp(ix.points{e.to}.component_identity,e.component_identity);
end
function grant(B,old)
    for k={'grant_id','start_utc','research_deadline_utc','deadline_utc'},assert(strcmp(B.(k{1}),old.(k{1})),'PKClosure:Grant','Do not replace or renew the original38459 grant.');end
end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKClosure:Read2','Whole plain plan must agree on native readback.');end
function verify(refs)
    for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKClosure:Changed','An actual consumed input/source changed.');end
end
function r=pin(file,sha),r=struct('file',literal(file),'sha256',sha);end
function r=reference(file),r=pin(file,RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKClosure:Alias','Hash/load must address the same literal path.');end
function v=member(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end
function l=lim(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKClosure:Clock','Original600/60 planning window expired.');end
function x=utc(),x=double(java.time.Instant.now().toEpochMilli())/1000;end
function x=nano(),x=double(java.lang.System.nanoTime());end
