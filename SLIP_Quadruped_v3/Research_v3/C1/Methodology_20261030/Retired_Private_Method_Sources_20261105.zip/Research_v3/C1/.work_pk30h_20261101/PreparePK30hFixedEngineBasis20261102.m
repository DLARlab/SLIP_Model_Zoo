function result=PreparePK30hFixedEngineBasis20261102(B,bindings,options)
%PREPAREPK30HFIXEDENGINEBASIS20261102 Transport historical P, current points.
% No Root/flow/replay/classifier calls. All point admission is immutable prior
% evidence. Copied historical P is NOT newly earned or requalified under this
% engine, and the absent old PAL plane is not reconstructed. Execute=false jobs
% merely prepare an explicit new engine/owner registration for unchanged Run.
    needed={'SourceReference';'PlanReference';'AdmissionReference';'AdoptionReference';'CanonicalSuiteReference'};
    okeys={'OutputFile';'BasisDirectory';'Generation';'MaxWallSeconds';'SaveMarginSeconds'};
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort(needed)) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort(okeys)) ...
        &&options.MaxWallSeconds==600&&options.SaveMarginSeconds==60&&B.capture.pid==feature('getpid'), ...
        'PKBasis:Inputs','Use immutable actual point/plan/adoption bindings and a new600/60 saved-data operation.');
    assert(ischar(options.Generation)&&~isempty(regexp(options.Generation,'^[A-Za-z0-9_]+$','once')), ...
        'PKBasis:Generation','Use one explicit fresh engine-registration generation.');
    start=bpClock();assert(min(B.research_deadline_unix_seconds-start.u,(B.research_deadline_monotonic_ns-start.m)/1e9)>602, ...
        'PKBasis:WholeFit','The complete600/60 preparation must fit unchanged original science clocks.');
    finish=struct('u',start.u+600,'m',start.m+600e9);work=struct('u',finish.u-60,'m',finish.m-60e9);
    N=fullfile(V3Root_v3(),'Research_v3','C1');out=bpPath(options.OutputFile);stage=[out,'.pending.mat'];writing=[stage,'.writing.mat'];basisDir=bpPath(options.BasisDirectory);
    assert(startsWith(out,[bpPath(fullfile(N,'Audits')),filesep])&&startsWith(basisDir,[bpPath(fullfile(N,'Results')),filesep]) ...
        &&~isfile(out)&&~isfile(stage)&&~isfile(writing)&&~isfile(basisDir)&&~isfolder(basisDir), ...
        'PKBasis:Fresh','Preserve every prior source/basis/plan/stage and prepare only fresh task-owned paths.');
    names={'PreparePK30hFixedEngineBasis20261102','BranchSolutionFile_v3','CompactResearchBranch_v3','RunC1ContinuationQueue_v3', ...
        'RunC1Continuation_v3','RecordedReturnPolicy_v3','MatchingReturnSection_v3','OrbitContentIdentity_v3','QuadrupedSchema_v3', ...
        'GaitSemanticTable_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3','AbsoluteRunBudget_v3'};
    code=cellfun(@(s)bpRef(which(s)),names(:),'UniformOutput',false);code{end+1,1}=bpRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
    refs=[code;{bindings.SourceReference;bindings.PlanReference;bindings.AdmissionReference;bindings.AdoptionReference;bindings.CanonicalSuiteReference}];bpVerify(refs);bpCheck(work);
    a=load(bindings.AdmissionReference.file,'audit','summary_digest');admission=a.audit;
    assert(strcmp(admission.schema,'PK30h-fresh-fixed-energy-point-admission-v1')&&admission.completed&&admission.source_posthash ...
        &&admission.all_current_all9_PK&&admission.root_solver_calls==0&&~admission.correction_performed&&~admission.historical_P_requalified ...
        &&strcmp(C1ScientificDigest_v3(admission.summaries),a.summary_digest)&&numel(admission.rows)==4 ...
        &&bpEqualRef(admission.source_reference,bindings.SourceReference), ...
        'PKBasis:ActualAdmission','Use actual closed four-point all9 PK admission, not nominal metrics or an upgraded old flag.');clear a
    x=load(bindings.PlanReference.file,'plan','plan_digest');oldPlan=x.plan;
    assert(strcmp(C1ScientificDigest_v3(oldPlan),x.plan_digest)&&oldPlan.completed&&oldPlan.source_posthash ...
        &&numel(oldPlan.rows)==2&&all(cellfun(@(v)v.context_eligible,oldPlan.rows)) ...
        &&all(cellfun(@(j)~j.execute,oldPlan.pilot_queue))&&bpEqualRef(oldPlan.bindings.SourceReference,bindings.SourceReference), ...
        'PKBasis:OriginalPlan','Preserve exact original history, own radius and declared captured numerical profile.');clear x
    adoption=jsondecode(fileread(bindings.AdoptionReference.file));
    assert(strcmp(adoption.schema,'PK30h-event-restart-tested-source-adoption-v1')&&adoption.installed_bytes_equal_reviewed_private_bytes ...
        &&~adoption.public_PSS_changed&&~adoption.runtime11_core_loader_changed&&~adoption.historical_source_proof_native_flag_rewritten, ...
        'PKBasis:Adoption','Use exact tested canonical source transport, never rewrite old scientific or budget flags.');
    transitions=bpCells(adoption.transitions);evidenceRefs=bpCells(adoption.actual_native_evidence_references);
    assert(any(cellfun(@(v)bpEqualRef(v,bindings.AdmissionReference),evidenceRefs)), ...
        'PKBasis:AdoptionAdmission','The actual adoption must bind this exact four-point admission authority.');
    c=load(bindings.CanonicalSuiteReference.file,'audit');suite=c.audit;
    assert(strcmp(suite.schema,'event-restart-canonical-53-suite-v1')&&suite.completed&&suite.source_posthash&&suite.default_commands_passed ...
        &&suite.case_count==53&&suite.canonical_body_bytes_match_tested_private_epoch&&bpEqualRef(suite.adoption_receipt_reference,bindings.AdoptionReference), ...
        'PKBasis:CanonicalSuite','Actual public-path53/default runtime closure is separate from the immutable adoption receipt pending flag.');
    for j=1:5
        canonical=suite.engine_source_references{j};at=find(cellfun(@(v)bpEqualRef(v.active_reference,canonical),transitions));
        assert(isscalar(at),'PKBasis:CanonicalTuple','The actual canonical suite must bind the exact installed five-file adoption tuple.');
        refs{end+1,1}=canonical;
    end
    clear c suite
    epochRows=cell(0,1);
    for k=1:numel(admission.input_references)
        historical=admission.input_references{k};role=admission.input_roles{k};
        if startsWith(role,'canonical_')
            at=find(cellfun(@(v)isfield(v,'retained_beforeimage_reference')&&bpEqualRef(v.historical_destination_reference,historical),transitions));
            assert(isscalar(at),'PKBasis:HistoricalEpoch','Every superseded historical canonical reference requires its exact adoption/preimage transition.');
            row=transitions{at};assert(strcmp(row.retained_beforeimage_reference.sha256,historical.sha256), ...
                'PKBasis:Preimage','Retain literal old canonical SHA at its exact named beforeimage, never require it at the replaced live path.');
            refs{end+1,1}=row.retained_beforeimage_reference;epochRows{end+1,1}=row;
        elseif startsWith(role,'private_')||strcmp(role,'gate')
            at=find(cellfun(@(v)bpEqualRef(v.private_source_reference,historical),transitions));
            assert(isscalar(at),'PKBasis:CurrentEpoch','Every admitted private engine/validator reference needs its exact source-identical canonical transition.');
            row=transitions{at};[~,name]=fileparts(row.active_reference.file);
            assert(strcmp(row.active_reference.sha256,historical.sha256)&&strcmp(which(name),row.active_reference.file), ...
                'PKBasis:SourceIdentical','Current canonical implementation must resolve to the exact admitted source bytes.');
            refs{end+1,1}=row.active_reference;epochRows{end+1,1}=row;
        else
            refs{end+1,1}=historical;
        end
    end
    bpVerify(refs);ix=BranchSolutionFile_v3.index(bindings.SourceReference.file);indices=[54;55;56;57];
    [oldOrbits,oldReports,oldMetadata]=BranchSolutionFile_v3.loadSolutions(bindings.SourceReference.file,indices);
    fresh=cell(4,1);reports=cell(4,1);joins=cell(4,1);
    for k=1:4
        bpCheck(work);row=admission.rows{k};o=oldOrbits{k};v=row.solution;
        assert(row.source_index==indices(k)&&row.call_returned&&row.protocol_verified&&isempty(fieldnames(row.failure)) ...
            &&row.evidence.completed&&row.evidence.source_posthash&&row.evidence.fresh_record_bitwise_equal&&row.evidence.fresh_current_all9_PK ...
            &&admitted(row.report)&&strcmp(OrbitContentIdentity_v3(o),row.source_native_id)&&strcmp(OrbitContentIdentity_v3(v),row.source_native_id), ...
            'PKBasis:CurrentPoint','All four literal original points must have current all9 qualified PK admission and exact native identity.');
        assert(isequaln(o.initial_state,v.initial_state)&&isequaln(o.initial_mode,v.initial_mode)&&isequaln(o.parameter,v.parameter) ...
            &&isequaln(o.period,v.period)&&isequaln(o.stride_displacement,v.stride_displacement)&&isequaln(o.section_chart,v.section_chart) ...
            &&isequaln(o.return_multiplicity,v.return_multiplicity), ...
            'PKBasis:LiteralRecord','Preserve full raw14/T/stride/p/q/complete section and literal multiplicity, not only an identity string.');
        [~,op]=RecordedReturnPolicy_v3(oldReports{k});[~,vp]=RecordedReturnPolicy_v3(row.report);
        assert(op.complete&&vp.complete&&isequaln(op.configuration,vp.configuration), ...
            'PKBasis:LiteralPolicy','Old and current points must share the full actual recorded policy configuration.');
        cohortKeys={'section_relative_event_signature','cyclic_event_signature','event_cluster_signature','cyclic_event_cluster_signature', ...
            'event_cluster_count','event_cluster_members','event_cluster_names','event_cluster_center_times','maximum_intra_cluster_spread', ...
            'minimum_intercluster_gap','section_cluster_coincidence','section_coincident_cluster_indices'};
        for j=1:numel(cohortKeys),key=cohortKeys{j};assert(isequaln(o.(key),v.(key)), ...
                'PKBasis:LiteralCohort','Preserve every literal symbolic cohort/actual center-time member field.');end
        section=MatchingReturnSection_v3(o,v,{oldReports{k},row.report});assert(section.compatible, ...
            'PKBasis:Section','Exact old/current section-policy compatibility is required.');
        fresh{k}=v;reports{k}=compactReport(row.report);assert(admitted(reports{k}), ...
            'PKBasis:PlainCurrentReport','The existing report serializer must retain every current all9/qualified PK fact.');
        [~,pp]=RecordedReturnPolicy_v3(reports{k});assert(pp.complete&&isequaln(pp.configuration,vp.configuration), ...
            'PKBasis:PlainPolicy','Plain serialization must retain complete current policy settings.');
        joins{k}=struct('source_index',indices(k),'native_id',row.source_native_id,'literal_record_policy_section_cohort_equal',true, ...
            'current_point_admission_reference',bindings.AdmissionReference,'historical_point_metadata',oldMetadata{k}, ...
            'fresh_point_admission_current',true,'historical_P_requalified',false);
    end
    packet=struct('schema','PK30h-current-points-historical-P-new-registration-v1','bindings',bindings,'input_references',{refs}, ...
        'original_budget',B,'operation_work',work,'source_epoch_transitions',{epochRows},'original_saved_plan_reference',bindings.PlanReference, ...
        'historical_plan_scope','Original plan/history/step/profile retained literally; old PAL/old P remain historical.', ...
        'point_joins',{joins},'basis_rows',{{}},'pilot_queue',{{}},'future_queue_options',struct(),'completed',false,'source_posthash',false, ...
        'execution_released',false,'root_solver_calls',0,'historical_physical_edges_transported',0,'new_physical_edges_earned',0, ...
        'historical_P_requalified',false,'old_PAL_plane_reconstructed',false,'old_failed_ladder_reset',false,'failure',struct());
    prefixSHA='';groups={[54,55];[56,57]};pilotDir=fullfile(N,['Connected_PK_',options.Generation]);
    queueFile=fullfile(N,'Audits',[options.Generation,'_Pilot_Queue.mat']);
    assert(~isfolder(pilotDir)&&~isfile(pilotDir)&&~isfile(queueFile)&&~isfile([queueFile,'.pending.mat']), ...
        'PKBasis:FutureFresh','Future numerical fork/Queue/CP generations must be fresh; do not resume or rewrite old CP.');
    for k=1:2
        bpCheck(work);pair=groups{k};[~,slots]=ismember(pair,indices);h=oldPlan.rows{k}.historical;oldJob=oldPlan.pilot_queue{k};
        assert(isequal(sort(oldJob.pair(:).'),pair)&&isequaln(oldJob.options.InitialStep,h.controller.step), ...
            'PKBasis:HistoricalDirection','Preserve the literal old frontier direction and its own saved radius.');
        at=find(cellfun(@(e)isequal([e.from,e.to],pair),ix.edges));assert(isscalar(at), ...
            'PKBasis:HistoricalP','Each ascending exact pair must retain its original actual directed P row.');edge=ix.edges{at};
        assert(strcmp(ix.points{pair(1)}.component_identity,edge.component_identity)&&strcmp(ix.points{pair(2)}.component_identity,edge.component_identity) ...
            &&oldMetadata{slots(2)}.edge_enabled&&oldMetadata{slots(2)}.edge_from==pair(1), ...
            'PKBasis:HistoricalOwner','Bind exact original P owner and literal predecessor metadata.');
        owner=sprintf('%s_Basis_%d_%d',options.Generation,pair);basisFile=fullfile(basisDir,sprintf('C1_PK_0061_%d_%d_CurrentBasis.mat',pair));
        header=struct('schema','current-point-revalidated-historical-P-basis-v1','component_identity',owner,'historical_source_reference',bindings.SourceReference, ...
            'historical_directed_P',edge,'historical_P_row',at,'historical_P_epoch','UNCHANGED RECORDED ORIGINAL SOURCE/PAL EPOCH, NOT REQUALIFIED', ...
            'current_point_admission_reference',bindings.AdmissionReference,'engine_adoption_reference',bindings.AdoptionReference, ...
            'new_physical_edge_earned',false,'new_strategy_registration',true);
        BranchSolutionFile_v3.initialize(basisFile,header);
        for j=1:2
            index=pair(j);m=struct('component_identity',owner,'classification','PK','nativeE',ix.points{index}.nativeE, ...
                'signedmeanU',ix.points{index}.signedmeanU,'order',j,'provenance',struct('kind','EXACT_IDENTITY_TRANSPORT_OF_HISTORICAL_P_AND_CURRENT_POINT_REPORT', ...
                'original_source_reference',bindings.SourceReference,'original_source_index',index,'original_point_metadata',oldMetadata{slots(j)}, ...
                'current_point_admission_reference',bindings.AdmissionReference,'historical_P_requalified',false,'new_physical_edge_earned',false));
            if j==2,m.edge_enabled=true;m.edge_from=1;end
            BranchSolutionFile_v3.append(basisFile,fresh{slots(j)},reports{slots(j)},m);
        end
        basisRef=bpRef(basisFile);basisIndex=BranchSolutionFile_v3.index(basisFile);
        assert(numel(basisIndex.points)==2&&numel(basisIndex.edges)==1&&basisIndex.edges{1}.from==1&&basisIndex.edges{1}.to==2, ...
            'PKBasis:BasisP','Only the one declared transported historical P may appear; no new numerical P is earned.');
        for pass=1:2
            [loaded,rr,mm]=BranchSolutionFile_v3.loadSolutions(basisFile,[1;2]);
            for j=1:2
                v=fresh{slots(j)};assert(strcmp(OrbitContentIdentity_v3(loaded{j}),OrbitContentIdentity_v3(v))&&admitted(rr{j}) ...
                    &&isequaln(loaded{j}.initial_state,v.initial_state)&&isequaln(loaded{j}.period,v.period)&&isequaln(loaded{j}.stride_displacement,v.stride_displacement) ...
                    &&strcmp(C1ScientificDigest_v3(rr{j}),C1ScientificDigest_v3(reports{slots(j)})), ...
                    'PKBasis:NativeRead2','Every basis read must retain actual native record/current plain report and original directed-P bookkeeping.');
                assert(strcmp(mm{j}.component_identity,owner),'PKBasis:ReadOwner','Retain explicit new storage owner.');
            end
            clear loaded rr mm
        end
        assert(strcmp(RoundSHA256_v3(basisFile),basisRef.sha256),'PKBasis:BasisPost','The completed basis source must remain exact.');
        [found,mappedPair]=ismember(oldJob.pair(:).',pair);assert(all(found),'PKBasis:PairMap','Preserve exact requested historical direction without flipping the stored P.');
        job=oldJob;job.id=[oldJob.id,'::',options.Generation];job.source_reference=basisRef;job.pair=mappedPair;
        job.output_file=fullfile(pilotDir,sprintf('C1_PK_0061_%d_%d_Phase.mat',pair));job.execute=false;job.execution_released=false;
        job.options.ComponentIdentity=sprintf('%s_0061_%d_%d',options.Generation,pair);
        job.options.CheckpointFile=fullfile(N,'Audits',sprintf('%s_0061_%d_%d_Checkpoint.mat',options.Generation,pair));
        job.role='new_engine_registered_phase_pilot_from_current_points_historical_P';job.new_strategy_registration=true;
        proofOptions=job.options;proofOptions.ComponentIdentity=oldJob.options.ComponentIdentity;proofOptions.CheckpointFile=oldJob.options.CheckpointFile;
        assert(isequaln(proofOptions,oldJob.options)&&isequaln(job.options.InitialStep,h.controller.step)&&strcmp(job.options.Algorithm,'root-newton') ...
            &&job.options.UsePhasePredictor&&job.options.AdaptiveStep&&job.options.MaxAccepted==1&&job.options.MaxAttempts==1 ...
            &&job.options.MinimumApexHeightRatio==.5&&isequal(job.options.AllowedClasses,{'PK'}), ...
            'PKBasis:LiteralStrategy','Only owner and fresh CP patches change RunOptions; radius/profile/history/strict stop remain literal.');
        freshPaths={job.output_file;[job.output_file,'.pending.mat'];job.options.CheckpointFile;[job.options.CheckpointFile,'.pending.mat']};
        assert(all(cellfun(@(f)~isfile(f)&&~isfolder(f),freshPaths)),'PKBasis:FreshPilot','Future root fork and CP paths must all remain fresh.');
        packet.basis_rows{k,1}=struct('basis_reference',basisRef,'original_ascending_pair',pair,'historical_directed_P',edge,'historical_P_row',at, ...
            'requested_original_pair',oldJob.pair,'requested_basis_pair',mappedPair,'requested_matches_stored_P_direction',isequal(mappedPair,[1,2]), ...
            'literal_historical_context',h,'literal_original_job',oldJob,'fresh_job',job,'historical_P_requalified',false,'new_physical_edge_earned',false);
        packet.pilot_queue{k,1}=job;packet.historical_physical_edges_transported=k;prefixSHA=bpSave(stage,packet,prefixSHA);refs{end+1,1}=basisRef;
    end
    packet.future_queue_options=struct('OutputFile',queueFile,'MaxWallSeconds',1500,'SaveMarginSeconds',60);
    bpVerify(refs);bpCheck(work);packet.input_references=refs;packet.source_posthash=true;packet.completed=true;prefixSHA=bpSave(stage,packet,prefixSHA);
    assert(strcmp(RoundSHA256_v3(stage),prefixSHA)&&~isfile(out),'PKBasis:Publication','Publish only the owned verified completed packet.');
    javaMethod('createLink','java.nio.file.Files',java.io.File(out).toPath(),java.io.File(stage).toPath());
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(out).toPath(),java.io.File(stage).toPath()),'PKBasis:OwnStage','Only the exact linked own stage may be unlinked.');
    javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());bpRead2(out,packet);bpCheck(finish);
    result=struct('completed',true,'source_posthash',true,'packet_reference',bpRef(out),'basis_count',2,'execute_released',false, ...
        'new_physical_edges_earned',0,'historical_physical_edges_transported',2,'root_solver_calls',0,'historical_P_requalified',false);
    fprintf('PK30H_CURRENT_BASIS_PREP_RETURN %s\n',jsonencode(result));
end
function ref=bpRef(file),ref=struct('file',bpPath(file),'sha256',RoundSHA256_v3(file));end
function file=bpPath(file),file=char(java.io.File(char(file)).getCanonicalPath());assert(strcmp(file,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKBasis:LiteralPath','Native/hash paths must coincide.');end
function same=bpEqualRef(a,b),same=isstruct(a)&&isstruct(b)&&all(isfield(a,{'file','sha256'}))&&all(isfield(b,{'file','sha256'}))&&strcmp(a.file,b.file)&&strcmp(a.sha256,b.sha256);end
function bpVerify(refs)
    for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'PKBasis:Changed','An immutable consumed reference changed.');if isfield(r,'bytes'),d=dir(r.file);assert(isscalar(d)&&d.bytes==r.bytes,'PKBasis:Bytes','An immutable reference changed byte count.');end;end
end
function t=bpClock(),t=struct('u',double(java.time.Instant.now().toEpochMilli())/1000,'m',double(java.lang.System.nanoTime()));end
function bpCheck(limit),t=bpClock();assert(min(limit.u-t.u,(limit.m-t.m)/1e9)>0,'PKBasis:Budget','The explicit operation original-grant clocks expired; retain all partial artifacts.');end
function sha=bpSave(stage,packet,previous)
    write=[stage,'.writing.mat'];assert(~isfile(write),'PKBasis:WritingFresh','Retain an interrupted own save.');
    if isempty(previous),assert(~isfile(stage),'PKBasis:StageFresh','First stage must be fresh.');else,assert(strcmp(RoundSHA256_v3(stage),previous),'PKBasis:StageChanged','Only prior own stage may be replaced.');end
    packet_digest=C1ScientificDigest_v3(packet);save(write,'packet','packet_digest','-v7');bpRead2(write,packet);
    [ok,message]=movefile(write,stage,'f');assert(ok,'PKBasis:StageMove','%s',message);sha=RoundSHA256_v3(stage);
end
function bpRead2(file,expected)
    for pass=1:2,x=load(file,'packet','packet_digest');assert(strcmp(C1ScientificDigest_v3(x.packet),x.packet_digest)&&isequaln(x.packet,expected),'PKBasis:Read2','Full plain packet must survive both independent native reads.');end
end

function value=compactReport(value)
    % Preserve correction facts while omitting only runtime reconstruction.
    [~,policyEvidence]=RecordedReturnPolicy_v3(value);
    if policyEvidence.complete
        c=policyEvidence.configuration;
        value.correction_return_policy=struct('diagnostic_kind','runtime-object-descriptor', ...
            'source_class',c.source_class,'settings',c.settings);
    end
    if isfield(value,'options')&&isstruct(value.options)
        if isfield(value.options,'Residual')&&~isempty(value.options.Residual)
            value.options.Residual=[];value.options_residual_runtime_object_omitted=true;
        end
        if isfield(value.options,'SolverOptions')&&isstruct(value.options.SolverOptions) ...
                &&isfield(value.options.SolverOptions,'Jacobian')&&isobject(value.options.SolverOptions.Jacobian)
            j=value.options.SolverOptions.Jacobian;
            assert(isa(j,'FiniteDifferenceJacobian_v3'),'C1Continuation:Report','Unexpected Jacobian runtime object.');
            value.options.SolverOptions.Jacobian=jacobianDescriptor(j);
        end
    end
    holder=CompactResearchBranch_v3(struct('report',value));value=holder.report;
end

function out=jacobianDescriptor(j)
    keys={'Method','RelativeStep','MinimumStep','MaximumStep','CheckFinite','FailurePolicy'};
    if strcmp(class(j),'ValidSidedFiniteDifferenceJacobian_v3')
        keys=[keys,{'DeadlineUnixSeconds','DeadlineMonotonicNs','MaximumHalvings'}];
    else
        assert(strcmp(class(j),'FiniteDifferenceJacobian_v3'), ...
            'C1Continuation:Report','Unknown Jacobian runtime class.');
    end
    assert(isscalar(j) ...
        &&isequal(sort(properties(j)),sort(keys(:))), ...
        'C1Continuation:Report','The complete exact known FD settings schema is required.');
    settings=struct();for k=1:numel(keys),settings.(keys{k})=j.(keys{k});end
    out=struct('diagnostic_kind','runtime-object-descriptor', ...
        'source_class',class(j),'settings',settings);
end

function yes=admitted(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    gates=member(r,'acceptance_gates',struct());g=member(r,'classification',struct());[~,version]=GaitSemanticTable_v3();
    yes=isequal(member(r,'accepted',false),true)&&all(isfield(gates,keys))&&strcmp(member(g,'contract_version',''),version) ...
        &&strcmp(member(g,'validated_gait_type',''),'PK')&&strcmp(member(g,'canonical_point_label',''),'PK') ...
        &&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1);
    for k=1:numel(keys),yes=yes&&isequal(member(gates,keys{k},false),true);end
end

function v=member(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end

function rows=bpCells(value)
if isstruct(value),rows=num2cell(value(:));else,assert(iscell(value),'PKBasis:JSONRows','Decoded object rows require a struct or cell column.');rows=value(:);end
end
