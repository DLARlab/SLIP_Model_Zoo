function result=ClosePK30hLowOverlap20261101(acquireRef,witness,B,options)
%CLOSEPK30HLOWOVERLAP20261101 One saved finite proof and optional diagnostics.
% The baseline is first, before native payload/class loading by this wrapper.
% Existing public methods own proof semantics; no new physics is introduced.
    entryUTC=utc();entryMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');W=fullfile(N,'.work_pk30h_20261101');
    assert(nargin==4&&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'MainOutputFile';'RetainedFile';'BaselineOutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,900)&&isequal(options.SaveMarginSeconds,60), ...
        'PKLowCold:Options','Use three explicit fresh paths and the original900/60 window.');
    assert(B.capture.pid==feature('getpid'),'PKLowCold:Budget','Calibrate the unchanged original grant in this process.');
    finish=limit(min(B.research_deadline_unix_seconds,entryUTC+900),min(B.research_deadline_monotonic_ns,entryMono+900e9));
    work=limit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=literal(options.MainOutputFile);stage=[output,'.pending.mat'];retained=literal(options.RetainedFile);folder=fileparts(retained);
    baseline=literal(options.BaselineOutputFile);baselineStage=[baseline,'.pending.mat'];
    assert(strcmp(output,fullfile(N,'Audits','PK30h_20261101_LowOverlap_ColdAndNegativeDomain.mat')) ...
        &&strcmp(retained,fullfile(W,'LowOverlap_Cold_Run01','Retained_Low.mat')) ...
        &&strcmp(baseline,fullfile(N,'Audits','PK30h_20261101_AcceptedValidation_Baseline_02.mat')) ...
        &&all(cellfun(@(f)~isfile(f)&&~isfolder(f),{output;stage;retained;[retained,'.pending.mat'];baseline;baselineStage;folder})), ...
        'PKLowCold:Fresh','Retain all prior or uncertain output/stages; use exactly the declared fresh paths.');
    assert(strcmp(acquireRef.file,fullfile(N,'Audits','PK30h_20261101_FrontierClosure_Plan_0062To0072_Acquisition.mat')) ...
        &&strcmp(acquireRef.sha256,'5d77e3c42ba15dafd99408cc9229147700e4738cdb16eb20037f4513436d2d49'), ...
        'PKLowCold:AcquireRef','Bind the actual closed low0062-to0072 acquisition.');
    assert(strcmp(witness.schema,'C1-external-native-process-exit-witness-v1') ...
        &&isequal(witness.actual_process_exit_observed,true)&&witness.exit_code==0 ...
        &&witness.process_session_id==67478&&witness.child_pid==94039 ...
        &&isequal(witness.source_posthash_verified,true)&&isequaln(witness.audit_reference,acquireRef), ...
        'PKLowCold:Witness','Keep actual67478/PID94039 exit0 and independent external postguards literal.');
    campaign=struct('file',fullfile(N,'Audits','PK30h_20261101_Campaign.mat'), ...
        'sha256','1ec74f424a23a0e6fd46e4d3c5ebbf81fde8d4fc39e8dcfe68e0019cb2406525');
    grazing=struct('file',fullfile(N,'Audits','PK30h_20261101_Secondary0170Negative_FlightGrazing.mat'), ...
        'sha256','df4179372356901d74e9a0c38283360245de5e3ba2247b463eb12d81d39743a2');
    baselineSource=struct('file',fullfile(W,'AcceptedValidationHoist_20261101','TestHybridSimulatorCapabilityHoist20261101.m'), ...
        'sha256','c8625a349cbcc6f4b2c53889f088882fbf614c9c7227ccf791bde85436938733');
    simulator=struct('file',fullfile(V3Root_v3(),'1_Dynamic_Frameworks','Simulation_v3','HybridSimulator_v3.m'), ...
        'sha256','5010b8b7b34554c1a37527c5bf1a2d18375f586cc380b0c7617967d910b64c75');
    % Only opaque file hashes/plain paths/clocks precede the fresh-class test.
    inputs={acquireRef;campaign;grazing;baselineSource;simulator;ref([mfilename('fullpath'),'.m'])};verifyAll(inputs);check(work);
    audit=struct('schema','PK30h-low-overlap-cold-and-negative-domain-v1','acquire_reference',acquireRef, ...
        'external_witness',witness,'original_budget',B,'original_finish',finish,'options',options,'source_code',{{}}, ...
        'input_references',{inputs},'baseline',struct('attempted',false,'returned',false,'successful',false, ...
            'status','UNATTEMPTED','failure',struct(),'output_reference',struct(),'stage_reference',struct()), ...
        'cold',struct(),'bounds',{{}},'qualifier_calls_attempted',0,'qualifier_calls_returned',0, ...
        'bounds_calls_attempted',0,'bounds_calls_returned',0,'mandatory_cold_custody_complete',false, ...
        'source_posthash',false,'completed',false,'failure',struct(),'root_ODE_map_replay_classifier_calls',0, ...
        'new_admission_claimed',false,'new_scientific_edge_created',false,'formal_continuous_coverage_claimed',false, ...
        'absence_of_earlier_touchdown_claimed',false,'own_process_exit_claimed',false);
    if left(work)>210
        addpath(fileparts(baselineSource.file),'-begin');
        assert(strcmp(which('TestHybridSimulatorCapabilityHoist20261101'),baselineSource.file), ...
            'PKLowCold:BaselineResolution','Resolve the exact reviewed baseline function before its first invocation.');
        audit.baseline.attempted=true;
        try
            b=TestHybridSimulatorCapabilityHoist20261101('baseline',campaign,struct(),baseline,B);
            audit.baseline.returned=true;
            audit.baseline.successful=b.completed&&b.source_posthash;
            audit.baseline.status='RETURNED';audit.baseline.completed=b.completed;audit.baseline.source_posthash=b.source_posthash;
            audit.baseline.scope=b.scope;clear b
        catch e,audit.baseline.failure=failure(e);audit.baseline.status='THREW';end
    else,audit.baseline.status='UNATTEMPTED_full180_plus30_does_not_fit';end
    if isfile(baseline),audit.baseline.output_reference=ref(baseline);inputs{end+1,1}=audit.baseline.output_reference;end
    if isfile(baselineStage),audit.baseline.stage_reference=ref(baselineStage);inputs{end+1,1}=audit.baseline.stage_reference;end
    % No native payload is loaded by this wrapper until the baseline has closed.
    audit.input_references=inputs;checkpoint(stage,audit);
    try
        code=providers();audit.source_code=code;inputs=[inputs;code];verifyAll(inputs);check(work);
        assert(strcmp(RoundSHA256_v3(which('AllFlightClearanceBounds_v3')), ...
            'dc22c3874c345366e138aa7c684fa7fe102b3adde87ef855e3313ea6e82e5620'), ...
            'PKLowCold:BoundsSource','Use the existing reviewed conditional bound kernel unchanged.');
        loaded=load(acquireRef.file,'audit');a=loaded.audit;
        assert(strcmp(a.schema,'C1-finite-owned-PAL-numerical-overlap-experiment-v1')&&a.completed&&a.source_posthash ...
            &&a.ordinary_edge_earned&&a.qualified_numerical_relation&&a.target_index==25 ...
            &&a.fine_calls_attempted==4&&a.fine_calls_returned==4&&isempty(fieldnames(a.failure)), ...
            'PKLowCold:Acquire','Use the actual qualified left3/target25 finite acquisition.');
        for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'}
            assert(strcmp(B.(key{1}),a.budget.(key{1})),'PKLowCold:Grant','Never replace or renew the original grant.');
        end
        inputs=[inputs;a.source_code;{a.run_branch_reference;a.run_checkpoint_reference;a.target_reference;a.source_reference}];verifyAll(inputs);
        [pair,pr,pm]=BranchSolutionFile_v3.loadSolutions(a.run_branch_reference.file,[2;3]);
        [target,tr,tm]=BranchSolutionFile_v3.loadSolutions(a.target_reference.file,25);
        leftSelector=struct('file',a.run_branch_reference.file,'sha256',a.run_branch_reference.sha256,'index',3,'native_ID',OrbitContentIdentity_v3(pair{2}));
        right=struct('file',a.target_reference.file,'sha256',a.target_reference.sha256,'index',25,'native_ID',OrbitContentIdentity_v3(target{1}));
        proof=struct('schema','C1-finite-owned-PAL-numerical-overlap-proof-v1','audit_reference',acquireRef, ...
            'execution_witness',witness,'left_selector',leftSelector,'right_selector',right,'validation_limits',work);
        audit.cold=struct('original_proof',proof,'qualified',false,'evidence',struct(),'retained_reference',struct(), ...
            'full_native_read2_verified',false,'complete_policy_read2_verified',false);
        checkpoint(stage,audit);check(work);
        audit.qualifier_calls_attempted=audit.qualifier_calls_attempted+1;
        e=C1FiniteNumericalOverlap_v3.qualify(pair{2},target{1},pr{2},tr{1},proof);
        audit.qualifier_calls_returned=audit.qualifier_calls_returned+1;
        audit.cold.evidence=e;audit.cold.qualified=true;checkpoint(stage,audit);check(work);
        % The complete earned e is durable before transport bookkeeping.
        javaMethod('createDirectory','java.nio.file.Files',java.io.File(folder).toPath(),javaArray('java.nio.file.attribute.FileAttribute',0));
        os={pair{1};pair{2};target{1}};rs={pr{1};pr{2};tr{1}};original={pm{1};pm{2};tm{1}};ms=cell(3,1);
        sourceRefs={a.run_branch_reference;a.run_branch_reference;a.target_reference};sourceIndices=[2,3,25];
        for n=1:3
            m=original{n};owner='PK30h_ColdRetained_low_source';order=n;
            if n==3,owner='PK30h_ColdRetained_low_target';order=1;end
            ms{n}=struct('component_identity',owner,'classification',m.classification,'nativeE',m.nativeE, ...
                'signedmeanU',m.signedmeanU,'order',order,'edge_enabled',n==2, ...
                'provenance',struct('kind','literal retained finite-proof record transport','source_reference',sourceRefs{n}, ...
                    'source_index',sourceIndices(n),'original_point_metadata',m,'native_id',OrbitContentIdentity_v3(os{n}), ...
                    'fresh_admission_claimed',false,'original_scientific_flags_changed',false));
            if n==2,ms{n}.edge_from=1;end
        end
        fragment=struct('qualified_numerical_overlaps',[2,3],'numerical_overlap_evidence',{{e}});
        BranchSolutionFile_v3.initialize(retained,struct('schema','PK30h-selected-retained-finite-three-records-v1', ...
            'acquire_reference',acquireRef,'component_graph',fragment,'new_scientific_edge_created',false, ...
            'physical_edge_scope','Actual earned predecessor2-to3 remapped1-to2; target remains NONEDGE.'));
        BranchSolutionFile_v3.appendBatch(retained,os,rs,ms);
        for pass=1:2
            [back,br,bm]=BranchSolutionFile_v3.loadSolutions(retained,1:3);
            for n=1:3
                same(public(os{n}),public(back{n}));same(rs{n},br{n});same(ms{n},bm{n});same(original{n},bm{n}.provenance.original_point_metadata);
                assert(strcmp(OrbitContentIdentity_v3(back{n}),OrbitContentIdentity_v3(os{n})), ...
                    'PKLowCold:NativeID','Transported full native records retain their actual NativeIDs.');samePolicy(rs{n},br{n});
            end
        end
        ix=BranchSolutionFile_v3.index(retained);
        assert(numel(ix.points)==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2 ...
            &&~bm{1}.edge_enabled&&bm{2}.edge_enabled&&~bm{3}.edge_enabled, ...
            'PKLowCold:Graph','Keep only P1-to2 and M2-to3; target remains NONEDGE.');
        same(fragment,ix.metadata.component_graph);
        C1FiniteNumericalOverlap_v3.validateRetained(e,back{2},back{3},br{2},br{3},back{1});
        audit.cold.retained_reference=ref(retained);inputs{end+1,1}=audit.cold.retained_reference;
        audit.cold.original_physical_edge=[2,3];audit.cold.retained_physical_edge=[1,2];audit.cold.retained_numerical_row=[2,3];
        audit.cold.full_native_read2_verified=true;audit.cold.complete_policy_read2_verified=true;
        audit.mandatory_cold_custody_complete=true;audit.input_references=inputs;checkpoint(stage,audit);check(work);
        % Optional saved-negative observations cannot change the cold proof.
        try
            loaded=load(grazing.file,'study');g=loaded.study;
            assert(g.completed&&g.source_posthash,'PKLowCold:Grazing','Use the exact closed negative0170 saved study.');
            tol=g.native_orbit.minimum_physical_margins.active_tolerances.swing_penetration;
            validateattributes(tol,{'double'},{'real','finite','scalar','nonnegative'});
            assert(isequal(tol,g.original_swing_penetration_tolerance),'PKLowCold:Tolerance','Retain the actually observed physical tolerance.');
            at=find(cellfun(@(r)isfield(r,'final_flight'),g.stencil));
            assert(isscalar(at)&&isfield(g.boundary,'final_flight'),'PKLowCold:Flights','Use only boundary and the unique actual stencil final flight.');
            flights={g.boundary.final_flight;g.stencil{at}.final_flight};labels={'negative0170_boundary_final';'negative0170_inward_stencil_final'};
            for k=1:2
                f=struct('label',labels{k},'source_reference',grazing,'saved_stencil_index',[], ...
                    'attempted',false,'returned',false,'raw_result',struct(),'failure',struct(),'observed_status','UNRESOLVED');
                if k==2,f.saved_stencil_index=at;end
                ff=flights{k};f.saved_completed=ff.completed;f.saved_continuous_coverage_claimed=ff.continuous_coverage_claimed;
                if ~isfield(ff,'duration')||~isnumeric(ff.duration)||~isscalar(ff.duration)||~isfinite(ff.duration)||ff.duration<=0
                    f.unresolved_reason='missing_or_invalid_saved_duration';audit.bounds{k}=f;checkpoint(stage,audit);continue
                end
                f.initial_state=ff.raw_liftoff_state;f.initial_mode=false(4,1);f.parameter=ff.parameter;f.duration=ff.duration;
                f.options=struct('SwingPenetrationTolerance',tol,'ArithmeticCushion',1e-11,'Limits',work,'MaxWallSeconds',10);
                audit.bounds{k}=f;checkpoint(stage,audit);
                if left(work)<=12,f.unresolved_reason='full10_plus_custody_does_not_fit';audit.bounds{k}=f;checkpoint(stage,audit);continue;end
                f.attempted=true;audit.bounds_calls_attempted=audit.bounds_calls_attempted+1;
                try
                    f.raw_result=AllFlightClearanceBounds_v3(f.initial_state,f.initial_mode,f.parameter,f.duration,f.options);
                    f.returned=true;audit.bounds_calls_returned=audit.bounds_calls_returned+1;
                catch err,f.failure=failure(err);end
                audit.bounds{k}=f;checkpoint(stage,audit); % Full actual return/exception before clock/status/print.
                f.parent_work_timely=left(work)>0;
                if f.returned,f.observed_status=f.raw_result.status;else,f.unresolved_reason='native_bound_exception';end
                audit.bounds{k}=f;checkpoint(stage,audit);
            end
        catch err,audit.optional_bounds_failure=failure(err);end
        verifyAll(inputs);audit.input_references=inputs;audit.source_posthash=true;
        audit.completed=audit.mandatory_cold_custody_complete;
        audit.scope='Cold saved finite proof and literal transport only. Optional mock and conditional raw-flight bounds do not earn admission, formal coverage, absence of earlier touchdown, P1 equivalence or global completion.';
    catch err,audit.failure=failure(err);audit.input_references=inputs;end
    checkpoint(stage,audit);check(finish);
    assert(audit.completed&&audit.source_posthash,'PKLowCold:Incomplete','Retain all partial evidence and files: %s',jsonencode(audit.failure));
    stageSHA=RoundSHA256_v3(stage);javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    back=load(output,'audit');same(audit,back.audit);
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath()) ...
        &&strcmp(RoundSHA256_v3(stage),stageSHA),'PKLowCold:OwnStage','Unlink only the unchanged own linked audit stage.');delete(stage);check(finish);
    result=struct('completed',true,'source_posthash',true,'audit_reference',ref(output),'retained_reference',audit.cold.retained_reference, ...
        'external_witness',witness,'baseline',audit.baseline,'qualifier_calls_attempted',audit.qualifier_calls_attempted, ...
        'qualifier_calls_returned',audit.qualifier_calls_returned,'bounds_calls_attempted',audit.bounds_calls_attempted, ...
        'bounds_calls_returned',audit.bounds_calls_returned,'bounds_summary',{{}},'root_ODE_map_replay_classifier_calls',0, ...
        'own_process_exit_claimed',false,'scope',audit.scope);
    for k=1:numel(audit.bounds),f=audit.bounds{k};result.bounds_summary{k}=struct('label',f.label,'attempted',f.attempted,'returned',f.returned,'status',f.observed_status);end
    result.optional_bounds_failure=struct();
    if isfield(audit,'optional_bounds_failure')
        result.optional_bounds_failure=struct('identifier',audit.optional_bounds_failure.identifier,'message',audit.optional_bounds_failure.message);
    end
    try
        text=jsonencode(result);if numel(unicode2native(text,'UTF-8'))>20000,text='';end
    catch,text='';end
    if isempty(text)
        briefFailure=result.optional_bounds_failure;
        if isfield(briefFailure,'message')&&numel(briefFailure.message)>1000
            briefFailure.message=[briefFailure.message(1:1000),' [TRUNCATED; full message in audit MAT]'];
        end
        compact=struct('completed',true,'source_posthash',true,'audit_reference',result.audit_reference, ...
            'retained_reference',result.retained_reference,'baseline_attempted',audit.baseline.attempted, ...
            'baseline_returned',audit.baseline.returned,'baseline_successful',audit.baseline.successful, ...
            'baseline_output_reference',audit.baseline.output_reference,'baseline_stage_reference',audit.baseline.stage_reference, ...
            'qualifier_calls_attempted',audit.qualifier_calls_attempted,'qualifier_calls_returned',audit.qualifier_calls_returned, ...
            'bounds_calls_attempted',audit.bounds_calls_attempted,'bounds_calls_returned',audit.bounds_calls_returned, ...
            'bounds_summary',{result.bounds_summary},'optional_bounds_failure',briefFailure,'own_process_exit_claimed',false, ...
            'stdout_scope','COMPACT_COUNTS_AND_REFERENCES; optional verbosity omitted; complete failure/raw evidence remains in audit MAT.');
        text=jsonencode(compact);
    end
    fprintf('PK_LOW_OVERLAP_CLOSED_RETURN %s\n',text);
end
function refs=providers()
    names={'ClosePK30hLowOverlap20261101','C1FiniteNumericalOverlap_v3','AcquireC1NumericalOverlap_v3', ...
        'BranchSolutionFile_v3','HybridOrbit_v3','Trajectory_v3','RecordedReturnPolicy_v3', ...
        'OrbitContentIdentity_v3','C1ScientificDigest_v3','AllFlightClearanceBounds_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cell(numel(names),1);for k=1:numel(names),refs{k}=ref(which(names{k}));end
    refs{end+1,1}=ref(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function f=failure(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function t=left(l),t=min(l.deadline_unix_seconds-utc(),(l.deadline_monotonic_ns-nano())/1e9);end
function samePolicy(a,b)
    [~,x]=RecordedReturnPolicy_v3(a);[~,y]=RecordedReturnPolicy_v3(b);
    assert(x.complete&&y.complete,'PKRemainingCold:Policy','Require complete actual recorded policy settings.');same(x.configuration,y.configuration);
end
function checkpoint(file,audit),save(file,'audit','-v7');back=load(file,'audit');same(audit,back.audit);end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKRemainingCold:Readback','Complete declared typed values differ.');end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
function verifyAll(refs),for k=1:numel(refs),verify(refs{k});end,end
function verify(r),assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKRemainingCold:Source','Immutable literal authority changed.');end
function r=ref(file),r=struct('file',literal(file),'sha256',RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKRemainingCold:Alias','Hash and native read must address the same file.');end
function l=limit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKRemainingCold:Clock','Original900/60 clock expired.');end
function v=utc(),v=posixtime(datetime('now','TimeZone','UTC'));end
function v=nano(),v=double(java.lang.System.nanoTime());end
