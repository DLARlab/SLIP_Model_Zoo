function result=SelectPK30hLowGeometry20261102(B,refs,output)
% Pure geometry from already saved native headers; no public orbit/report loads.
u=utc();m=mono();assert(B.capture.pid==feature('getpid')&&min(B.research_deadline_unix_seconds-u,(B.research_deadline_monotonic_ns-m)/1e9)>182,'PKGeom:Fit','Original research clocks must fit180/30.');
finish=struct('utc',u+180,'mono',m+180e9);work=struct('utc',u+150,'mono',m+150e9);
assert(strcmp(output,fullfile(V3Root_v3(),'Research_v3','C1','Audits','PK30h_20261102_CurrentLOW_GeometricSelector01.mat')),'PKGeom:Output','Use this fresh named geometry output.');
fresh({output;[output,'.pending.mat'];[output,'.failure.mat']});guard(refs);check(work);
result=struct('schema','PK30h-pure-header-LOW-geometry-v1','completed',false,'source_posthash',false,'input_references',refs,'original_budget',B,'operation_finish',finish,'operation_work',work,'new_Root_ODE_Map_admission_calls',0,'fresh_admission_claimed',false,'M_earned',false,'frontier_retirement_authorized',false,'own_process_exit_claimed',false);
try
 c=jsondecode(fileread(refs.closure.file));assert(c.process.actual_tool_exit_observed&&c.process.exit_code==1&&c.independent_post_guard.all_passed&&strcmp(c.failure_packet_reference.sha256,refs.packet.sha256),'PKGeom:Closure','Preserve the failed native operation and its actual custody.');
 for pass=1:2
  x=load(refs.packet.file,'plan','plan_digest');assert(strcmp(C1ScientificDigest_v3(x.plan),x.plan_digest),'PKGeom:PacketDigest','Each packet read retains its typed digest.');
  if pass==1,d=x.plan_digest;else,assert(strcmp(d,x.plan_digest),'PKGeom:PacketRead2','Independent packet reads disagree.');end
  assert(isequal(x.plan.completed,false)&&isequal(x.plan.source_posthash,false)&&numel(x.plan.source_headers)==2&&numel(x.plan.target_headers)==54,'PKGeom:FailedFlags','Do not promote original false flags.');
  H=[x.plan.source_headers(:);x.plan.target_headers(:)];for j=1:56,assert(strcmp(C1ScientificDigest_v3(H{j}.record),H{j}.record_typed_digest),'PKGeom:HeaderDigest','A typed literal record changed.');end
  check(work);if pass==1,clear x H;end
 end
 p=x.plan;assert(isequal(p.source_pair,[49,50])&&isequal(p.bindings.SourceReference,refs.source)&&isequal(p.bindings.TargetReference,refs.target),'PKGeom:Sources','Use exact currentLOW49-to50 and grown0072Low raw generations.');
 result.original_failure_flags=struct('completed',p.completed,'source_posthash',p.source_posthash,'failure',p.failure);result.packet_typed_digest=d;result.source_headers=p.source_headers;result.target_headers=p.target_headers;
 si=BranchSolutionFile_v3.index(refs.source.file);ti=BranchSolutionFile_v3.index(refs.target.file);assert(numel(si.points)>=50&&numel(ti.points)==54,'PKGeom:Indices','Use actual raw point counts.');
 e=find(cellfun(@(e)e.from==49&&e.to==50,si.edges));assert(isscalar(e)&&owned(si,si.edges{e}),'PKGeom:SourceP','Require actual directed same-owner49-to50P.');result.source_owned_P=si.edges{e};
 result.source_index_points=si.points([49,50]);result.target_index_points=ti.points;result.target_owned_P=cell(54,1);
 for k=1:56
  h=H{k};if k<=2,r=refs.source;ix=[49,50];index=ix(k);ix=si;else,r=refs.target;index=k-2;ix=ti;end
  assert(isequal(h.reference,r)&&h.index==index&&strcmp(h.metadata.component_identity,ix.points{index}.component_identity)&&ischar(h.native_id)&&~isempty(h.native_id),'PKGeom:HeaderBinding','Literal header file/index/owner/nativeID must bind the raw index.');
 end
 a=p.source_headers{1}.record.initial_state(:);b=p.source_headers{2}.record.initial_state(:);assert(numel(a)==14&&numel(b)==14&&all(isfinite([a;b])),'PKGeom:SourceStates','Use finite literal14-state headers.');
 ids=[2,3,7,8];lift=b;lift([9,11,13])=lift(7);lift([10,12,14])=lift(8);assert(isequaln(lift,b),'PKGeom:BaseLift','The literal base must lift exactly; no source projection.');
 ua=a(ids);ub=b(ids);scale=max([ones(4,1),abs(ua),abs(ub)],[],2);v=(ub-ua)./scale;chord=norm(v);assert(isfinite(chord)&&chord>1e-10,'PKGeom:Chord','Use a resolved source chord.');tangent=v/chord;
 result.source_geometry=struct('coordinate_indices',ids,'source_coordinates',[ua,ub],'scale',scale,'tangent',tangent,'chord',chord,'fixed_direction',[49,50],'PAL_normal',[tangent./scale;0],'base_nativeE_index',si.points{50}.nativeE);
 rows=nan(54,6);reasons=cell(54,1);pred4=zeros(4,54);pred14=zeros(14,54);
 for k=1:54
  check(work);t=p.target_headers{k}.record.initial_state(:);assert(numel(t)==14&&all(isfinite(t)),'PKGeom:TargetState','Each saved target has14 finite literal entries.');ut=t(ids);
  ds=dot(tangent,(ut-ub)./scale);q=ub+scale.*(ds*tangent);dist4=norm((ut-q)./scale);pred=b;pred(ids)=q;pred([9,11,13])=pred(7);pred([10,12,14])=pred(8);
  s13=max([ones(13,1),abs(pred(2:14)),abs(t(2:14))],[],2);full13=norm((pred(2:14)-t(2:14))./s13,Inf);eligible=isfinite(ds)&&ds>=1e-7&&ds<=.04&&isfinite(dist4)&&dist4<=.001&&isfinite(full13)&&full13<=.001;
  out=find(cellfun(@(e)e.from==k&&owned(ti,e),ti.edges));result.target_owned_P{k}=ti.edges(out);rows(k,:)=[k,ds,dist4,full13,eligible,numel(out)];pred4(:,k)=q;pred14(:,k)=pred;
  reasons{k}='eligible';if ~isfinite(ds)||~isfinite(dist4)||~isfinite(full13),reasons{k}='nonfinite_geometry';elseif ds<1e-7||ds>.04,reasons{k}='signed_step_outside_1e-7_to_0.04';elseif dist4>.001,reasons{k}='predictor4D_distance_above_0.001';elseif full13>.001,reasons{k}='full13_scaled_inf_above_0.001';end
 end
 result.columns={'target_index','signed_ds','predictor4D_distance','full13_scaled_inf','geometrically_eligible','actual_outgoing_owned_P_count'};result.rows=rows;result.failure_reason=reasons;result.predictor4D=pred4;result.predictor14=pred14;
 ranked=sortrows(rows(rows(:,5)==1,:),[4,3,1]);next=ranked(ranked(:,6)>0,:);result.eligible_count=size(ranked,1);result.best_any=best(ranked,p.target_headers,result.target_owned_P);result.best_with_next_P=best(next,p.target_headers,result.target_owned_P);
 result.scope='GEOMETRIC PROPOSAL ONLY. Original policy/cohort/section/admission compatibility UNASSESSED until unchanged AcquireC1NumericalOverlap_v3 API6 freshly checks original reports/geometry, then root plus four fines. Header context is observation, not a gate. No M/frontier retirement or nonexistence claim. No source flip, abs(ds), speed ranking, target root seed, optimizer, synthetic report or section test.';
 guard(refs);check(work);result.source_posthash=true;result.completed=true;result.elapsed_seconds=(mono()-m)/1e9;result_digest=C1ScientificDigest_v3(result);stage=[output,'.pending.mat'];save(stage,'result','result_digest','-v7');
 for pass=1:2,z=load(stage,'result','result_digest');assert(strcmp(C1ScientificDigest_v3(z.result),z.result_digest)&&strcmp(z.result_digest,result_digest),'PKGeom:Read2','Actual saved proposal readback must match.');end
 guard(refs);check(finish);assert(~isfile(output),'PKGeom:Fresh','Preserve concurrent output.');javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath()),'PKGeom:Publication','Publish this exact own saved stage.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());check(finish);
 fprintf('PK30H_LOW_GEOMETRY_RETURN %s\n',jsonencode(struct('completed',true,'source_posthash',true,'file',output,'sha256',RoundSHA256_v3(output),'eligible_count',result.eligible_count,'best_any',result.best_any,'best_with_next_P',result.best_with_next_P,'own_process_exit_claimed',false)));
catch problem
 result.completed=false;result.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);if ~isfile([output,'.failure.mat']),save([output,'.failure.mat'],'result','-v7');end;rethrow(problem)
end
end
function r=best(rows,headers,edges)
r=struct();if isempty(rows),return;end;k=rows(1,1);r=struct('reference',headers{k}.reference,'index',k,'native_id',headers{k}.native_id,'geometry_row',rows(1,:),'actual_outgoing_owned_P',{edges{k}},'outgoing_neighbor_indices',cellfun(@(e)e.to,edges{k}),'compatibility','UNASSESSED');
end
function yes=owned(ix,e)
yes=e.from>=1&&e.to>=1&&e.from<=numel(ix.points)&&e.to<=numel(ix.points)&&strcmp(ix.points{e.from}.component_identity,e.component_identity)&&strcmp(ix.points{e.to}.component_identity,e.component_identity)&&isequal(ix.points{e.to}.metadata.edge_enabled,true)&&isequal(ix.points{e.to}.metadata.edge_from,e.from);
end
function guard(refs)
n=fieldnames(refs);for k=1:numel(n),r=refs.(n{k});d=dir(r.file);assert(isscalar(d)&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKGeom:InputHash','An exact input or recipe changed.');end
end
function fresh(files)
assert(all(cellfun(@(f)~isfile(f)&&~isfolder(f),files)),'PKGeom:Fresh','Preserve every existing output/stage/failure.');
end
function check(b),assert(utc()<b.utc&&mono()<b.mono,'PKGeom:Clock','Fixed operation clocks expired.');end
function t=utc(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=mono(),t=double(java.lang.System.nanoTime());end
