function result=ColdRetainPK30hROW13Raw03To333_20261102(queueRef,closureRef,B,options)
% Saved full finite proof and literal3-record transport. No new physics/fines.
entryUTC=utc();entryMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');W=fullfile(N,'.work_pk30h_20261101');
assert(nargin==4&&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort({'OutputFile';'RetainedFile';'MaxWallSeconds';'SaveMarginSeconds'}))&&options.MaxWallSeconds==600&&options.SaveMarginSeconds==60,'PKRow13Cold:Options','Use explicit fresh600/60 saved cold operation.');
assert(B.capture.pid==feature('getpid')&&min(B.research_deadline_unix_seconds-entryUTC,(B.research_deadline_monotonic_ns-entryMono)/1e9)>602,'PKRow13Cold:WholeFit','Full600/60 must fit unchanged science clocks.');finish=limit(entryUTC+600,entryMono+600e9);work=limit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
output=literal(options.OutputFile);stage=[output,'.pending.mat'];retained=literal(options.RetainedFile);folder=fileparts(retained);
assert(strcmp(output,fullfile(N,'Audits','PK30h_20261102_ROW13_Raw03_To_333_ColdQualification01.mat'))&&strcmp(retained,fullfile(W,'ROW13Raw03To333_Cold_Run01','Retained_Row13.mat'))&&all(cellfun(@(f)~isfile(f)&&~isfolder(f),{output;stage;retained;[retained,'.pending.mat'];folder})),'PKRow13Cold:Fresh','Preserve all earlier/uncertain paths; no same-path retry.');
code=providers();inputs=[{queueRef;closureRef};code];verifyAll(inputs);check(work);closed=jsondecode(fileread(closureRef.file));
assert(strcmp(closed.schema,'PK30h-single-ROW13-Acquire-external-closure-v1')&&strcmp(closed.queue_reference.file,queueRef.file)&&strcmp(closed.queue_reference.sha256,queueRef.sha256)&&closed.process.actual_tool_exit_observed&&closed.process.exit_code==0&&closed.independent_post_guard.all_passed&&closed.all_owned_native_workers_closed,'PKRow13Cold:ExternalExit','Require actual nativeexit0, independent postguards and owned worker closure.');
validateattributes(closed.process.session_id,{'numeric'},{'real','finite','scalar','integer','positive'});validateattributes(closed.process.native_pid,{'numeric'},{'real','finite','scalar','integer','positive'});
q1=load(queueRef.file,'manifest');q2=load(queueRef.file,'manifest');same(q1.manifest,q2.manifest);q=q1.manifest;clear q1 q2
assert(strcmp(q.schema,'PK30h-single-ROW13-Acquire-operative-v1')&&q.completed&&q.source_posthash&&q.invoked&&q.returned&&q.return_timely&&q.actual_native_flags.completed&&q.actual_native_flags.source_posthash&&q.actual_native_flags.ordinary_edge_earned&&q.actual_native_flags.qualified_numerical_relation&&q.actual_native_flags.fine_calls_attempted==4&&q.actual_native_flags.fine_calls_returned==4&&isempty(fieldnames(q.actual_exception))&&isequal(q.source_pair,q.saved_geometry_proposal.source_pair)&&q.target_index==333,'PKRow13Cold:ActualSinglePositive','Bind only actual closed one-call positive, never old five-case shape or geometric closeness.');
for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'},assert(strcmp(B.(key{1}),q.original_budget.(key{1})),'PKRow13Cold:Grant','Never renew original grant.');end
acquireRef=struct('file',closed.acquisition_reference.file,'sha256',closed.acquisition_reference.sha256);assert(strcmp(acquireRef.file,q.options.OutputFile)&&strcmp(acquireRef.sha256,q.output_observations{1}.sha256)&&strcmp(closed.branch_reference.file,q.actual_native_flags.run_branch_reference.file)&&strcmp(closed.branch_reference.sha256,q.actual_native_flags.run_branch_reference.sha256)&&strcmp(closed.checkpoint_reference.file,q.actual_native_flags.run_checkpoint_reference.file)&&strcmp(closed.checkpoint_reference.sha256,q.actual_native_flags.run_checkpoint_reference.sha256),'PKRow13Cold:ClosedReferences','Queue/native/external audit, branch and checkpoint hashes must agree.');
inputs=[inputs;q.input_references;{closed.acquisition_reference;closed.branch_reference;closed.checkpoint_reference}];verifyAll(inputs);check(work);
witness=struct('schema','C1-external-native-process-exit-witness-v1','actual_process_exit_observed',true,'exit_code',closed.process.exit_code,'process_session_id',closed.process.session_id,'child_pid',closed.process.native_pid,'source_posthash_verified',closed.independent_post_guard.all_passed,'audit_reference',acquireRef,'external_closure_reference',closureRef,'parent_batch_reference',queueRef);
audit=struct('schema','PK30h-single-ROW13-cold-retained-v1','queue_reference',queueRef,'external_closure_reference',closureRef,'external_closure_payload',closed,'acquire_reference',acquireRef,'external_witness',witness,'historical_queue_completed',q.completed,'historical_queue_source_posthash',q.source_posthash,'original_budget',B,'original_finish',finish,'options',options,'source_code',{code},'input_references',{inputs},'cold',struct(),'qualifier_calls_attempted',0,'qualifier_calls_returned',0,'mandatory_cold_custody_complete',false,'source_posthash',false,'completed',false,'failure',struct(),'root_ODE_map_replay_classifier_calls',0,'new_admission_claimed',false,'new_scientific_edge_created',false,'own_process_exit_claimed',false);checkpoint(stage,audit);
try
 loaded=load(acquireRef.file,'audit');a=loaded.audit;clear loaded
 assert(strcmp(a.schema,'C1-finite-owned-PAL-numerical-overlap-experiment-v1')&&a.completed&&a.source_posthash&&a.ordinary_edge_earned&&a.qualified_numerical_relation&&a.fine_calls_attempted==4&&a.fine_calls_returned==4&&isempty(fieldnames(a.failure))&&isequal(a.source_pair,q.source_pair)&&a.target_index==333&&strcmp(a.source_reference.sha256,'2ca5aa4a2e64ac80f2d2bb95d17379857bc38661a5f13a0bd0d63d34c0b06962')&&strcmp(a.target_reference.sha256,'2ca5aa4a2e64ac80f2d2bb95d17379857bc38661a5f13a0bd0d63d34c0b06962')&&isequal(a.source_reference,q.source_reference)&&isequal(a.target_reference,q.target_reference)&&isequal(a.run_branch_reference,q.actual_native_flags.run_branch_reference)&&isequal(a.run_checkpoint_reference,q.actual_native_flags.run_checkpoint_reference),'PKRow13Cold:ActualAudit','Preserve actual qualified audit, selectors and exact branch/CP generation.');
 for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'},assert(strcmp(B.(key{1}),a.budget.(key{1})),'PKRow13Cold:AuditGrant','Keep acquisition grant labels.');end
 inputs=[inputs;a.source_code;{a.run_branch_reference;a.run_checkpoint_reference;a.target_reference;a.source_reference}];verifyAll(inputs);
 [pair,pr,pm]=BranchSolutionFile_v3.loadSolutions(a.run_branch_reference.file,[2;3]);[target,tr,tm]=BranchSolutionFile_v3.loadSolutions(a.target_reference.file,a.target_index);
 leftSelector=struct('file',a.run_branch_reference.file,'sha256',a.run_branch_reference.sha256,'index',3,'native_ID',OrbitContentIdentity_v3(pair{2}));right=struct('file',a.target_reference.file,'sha256',a.target_reference.sha256,'index',a.target_index,'native_ID',OrbitContentIdentity_v3(target{1}));
 proof=struct('schema','C1-finite-owned-PAL-numerical-overlap-proof-v1','audit_reference',acquireRef,'execution_witness',witness,'left_selector',leftSelector,'right_selector',right,'validation_limits',work);
 audit.cold=struct('original_proof',proof,'qualified',false,'evidence',struct(),'retained_reference',struct(),'full_native_read2_verified',false,'complete_policy_read2_verified',false);checkpoint(stage,audit);check(work);
 audit.qualifier_calls_attempted=audit.qualifier_calls_attempted+1;e=C1FiniteNumericalOverlap_v3.qualify(pair{2},target{1},pr{2},tr{1},proof);audit.qualifier_calls_returned=audit.qualifier_calls_returned+1;
 audit.cold.evidence=e;audit.cold.qualified=true;checkpoint(stage,audit);check(work);
        % The complete earned e is durable before transport bookkeeping.
        javaMethod('createDirectory','java.nio.file.Files',java.io.File(folder).toPath(),javaArray('java.nio.file.attribute.FileAttribute',0));
        os={pair{1};pair{2};target{1}};rs={pr{1};pr{2};tr{1}};original={pm{1};pm{2};tm{1}};ms=cell(3,1);
        sourceRefs={a.run_branch_reference;a.run_branch_reference;a.target_reference};sourceIndices=[2,3,a.target_index];
        for n=1:3
            m=original{n};owner='PK30h_ColdRetained_row13_source';order=n;
            if n==3,owner='PK30h_ColdRetained_row13_target';order=1;end
            ms{n}=struct('component_identity',owner,'classification',m.classification,'nativeE',m.nativeE, ...
                'signedmeanU',m.signedmeanU,'order',order,'edge_enabled',n==2, ...
                'provenance',struct('kind','literal retained finite-proof record transport','source_reference',sourceRefs{n}, ...
                    'source_index',sourceIndices(n),'original_point_metadata',m,'native_id',OrbitContentIdentity_v3(os{n}), ...
                    'fresh_admission_claimed',false,'original_scientific_flags_changed',false));
            if n==2,ms{n}.edge_from=1;end
        end
        fragment=struct('qualified_numerical_overlaps',[2,3],'numerical_overlap_evidence',{{e}});
        BranchSolutionFile_v3.initialize(retained,struct('schema','PK30h-selected-retained-finite-three-records-v1', ...
            'acquire_reference',acquireRef,'component_graph',fragment,'new_scientific_edge_created',false, ...
            'physical_edge_scope','Actual earned predecessor2-to3 remapped1-to2; target remains NONEDGE.'));
        BranchSolutionFile_v3.appendBatch(retained,os,rs,ms);
        for pass=1:2
            [back,br,bm]=BranchSolutionFile_v3.loadSolutions(retained,1:3);
            for n=1:3
                same(public(os{n}),public(back{n}));same(rs{n},br{n});same(ms{n},bm{n});same(original{n},bm{n}.provenance.original_point_metadata);
                assert(strcmp(OrbitContentIdentity_v3(back{n}),OrbitContentIdentity_v3(os{n})), ...
                    'PKLowCold:NativeID','Transported full native records retain their actual NativeIDs.');samePolicy(rs{n},br{n});
            end
        end
        ix=BranchSolutionFile_v3.index(retained);
        assert(numel(ix.points)==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2 ...
            &&~bm{1}.edge_enabled&&bm{2}.edge_enabled&&~bm{3}.edge_enabled, ...
            'PKLowCold:Graph','Keep only P1-to2 and M2-to3; target remains NONEDGE.');
        same(fragment,ix.metadata.component_graph);
        C1FiniteNumericalOverlap_v3.validateRetained(e,back{2},back{3},br{2},br{3},back{1});
        audit.cold.retained_reference=ref(retained);inputs{end+1,1}=audit.cold.retained_reference;
        audit.cold.original_physical_edge=[2,3];audit.cold.retained_physical_edge=[1,2];audit.cold.retained_numerical_row=[2,3];
        audit.cold.full_native_read2_verified=true;audit.cold.complete_policy_read2_verified=true;
        audit.mandatory_cold_custody_complete=true;audit.input_references=inputs;checkpoint(stage,audit);check(work);
        verifyAll(inputs);audit.input_references=inputs;audit.source_posthash=true;audit.completed=audit.mandatory_cold_custody_complete;
        audit.scope='Saved full finite proof and literal three-record transport only. Actual oldP2-to3 becomes P1-to2; qualified M2-to3 remains numerical and target NONEDGE. No new root/ODE/map/fine/admission, exact identity, source/frontier retirement or endpoint/global claim.';
catch err,audit.failure=failure(err);audit.input_references=inputs;end
checkpoint(stage,audit);check(finish);assert(audit.completed&&audit.source_posthash,'PKRow13Cold:Incomplete','Retain all actual partial evidence; no same-path retry: %s',jsonencode(audit.failure));
before=RoundSHA256_v3(stage);assert(~isfile(output),'PKRow13Cold:PublishFresh','Preserve concurrent output.');javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),before),'PKRow13Cold:OwnStage','Remove only unchanged linked own stage.');delete(stage);loaded=load(output,'audit');same(audit,loaded.audit);verifyAll(inputs);check(finish);
result=struct('completed',true,'source_posthash',true,'audit_reference',ref(output),'retained_reference',ref(retained),'qualifier_calls_attempted',audit.qualifier_calls_attempted,'qualifier_calls_returned',audit.qualifier_calls_returned,'full_native_read2_verified',audit.cold.full_native_read2_verified,'complete_policy_read2_verified',audit.cold.complete_policy_read2_verified,'root_ODE_map_replay_classifier_calls',0,'new_admission_claimed',false,'own_process_exit_claimed',false);fprintf('PK30H_SINGLE_ROW13_COLD_RETURN %s\n',jsonencode(result));
end
function refs=providers()
    names={'ColdRetainPK30hROW13Raw03To333_20261102','C1FiniteNumericalOverlap_v3','AcquireC1NumericalOverlap_v3', ...
        'BranchSolutionFile_v3','HybridOrbit_v3','Trajectory_v3','RecordedReturnPolicy_v3', ...
        'OrbitContentIdentity_v3','C1ScientificDigest_v3','HybridSimulator_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cell(numel(names),1);for k=1:numel(names),refs{k}=ref(which(names{k}));end
    refs{end+1,1}=ref(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function f=failure(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function t=left(l),t=min(l.deadline_unix_seconds-utc(),(l.deadline_monotonic_ns-nano())/1e9);end
function samePolicy(a,b)
    [~,x]=RecordedReturnPolicy_v3(a);[~,y]=RecordedReturnPolicy_v3(b);
    assert(x.complete&&y.complete,'PKRemainingCold:Policy','Require complete actual recorded policy settings.');same(x.configuration,y.configuration);
end
function checkpoint(file,audit),save(file,'audit','-v7');back=load(file,'audit');same(audit,back.audit);end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKRemainingCold:Readback','Complete declared typed values differ.');end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
function verifyAll(refs),for k=1:numel(refs),verify(refs{k});end,end
function verify(r),assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKRemainingCold:Source','Immutable literal authority changed.');end
function r=ref(file),r=struct('file',literal(file),'sha256',RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKRemainingCold:Alias','Hash and native read must address the same file.');end
function l=limit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKRemainingCold:Clock','Original600/60 clock expired.');end
function v=utc(),v=posixtime(datetime('now','TimeZone','UTC'));end
function v=nano(),v=double(java.lang.System.nanoTime());end
