function result=AppendPK30hClosedCarriersStoredGraph20261102(B,bindings,options)
% Exact closed Graph03 + mandatory ROW3 and up to two closed ROW13/ROW5 carriers; the previous exact guard projection remains literal.
% Source records/catalogue metadata and historical admission/typed evidence remain literal.
    entryUTC=gpUTC();entryMono=gpNano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    keys={'ParentPlanReference';'ParentClosureReference';'ColdAuditReference';'ColdClosureReference';'CarrierReference';'AcquireAuditReference';'AcquireClosureReference'};
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort([keys;{'AdditionalCarrierRows'}])) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&options.MaxWallSeconds==900&&options.SaveMarginSeconds==60&&B.capture.pid==feature('getpid'), ...
        'PKEligible:Inputs','Use only exact closed input references and the explicit new900/60 saved graph operation.');
    assert(strcmp(B.grant_id,'20261101_PK_30h')&&strcmp(B.start_utc,'2026-11-01T16:29:07Z') ...
        &&strcmp(B.research_deadline_utc,'2026-11-02T20:29:07Z')&&strcmp(B.deadline_utc,'2026-11-02T22:29:07Z') ...
        &&min(B.research_deadline_unix_seconds-entryUTC,(B.research_deadline_monotonic_ns-entryMono)/1e9)>902, ...
        'PKEligible:WholeFit','The full new900/60 saved operation must fit the unchanged original science UTC/JVM grant.');
    finish=gpLimit(entryUTC+900,entryMono+900e9);work=gpLimit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=gpLiteral(options.OutputFile);stage=[output,'.pending.mat'];failureFile=[output,'.failure.mat'];
    assert(strcmp(output,fullfile(N,'Audits','PK30h_20261102_StoredGraph04_ClosedCarriers.mat')) ...
        &&all(cellfun(@(f)~isfile(f)&&~isfolder(f),{output;stage;failureFile})), ...
        'PKEligible:Fresh','Keep every previous/uncertain graph plan and use only the declared fresh Graph04 paths.');
    assert(iscell(bindings.AdditionalCarrierRows)&&(isempty(bindings.AdditionalCarrierRows)||iscolumn(bindings.AdditionalCarrierRows))&&numel(bindings.AdditionalCarrierRows)<=2,'PKClosedGraph:AdditionalRows','Up to two explicit closed rows with unique ROW13/ROW5 roles are permitted; no speculative raw branch append.');
    roles=cell(numel(bindings.AdditionalCarrierRows),1);
    for k=1:numel(bindings.AdditionalCarrierRows),row=bindings.AdditionalCarrierRows{k};assert(isstruct(row)&&isscalar(row)&&isfield(row,'Role')&&ischar(row.Role)&&isrow(row.Role)&&any(strcmp(row.Role,{'ROW13','ROW5'})),'PKClosedGraph:AdditionalRole','Optional roles are exactly ROW13 or ROW5.');roles{k}=row.Role;end
    assert(numel(unique(roles))==numel(roles),'PKClosedGraph:UniqueRoles','An optional closed role may occur only once.');
    code=rfProviders();refs=[cellfun(@(key)bindings.(key),keys,'UniformOutput',false);code];gpVerify(refs);
    parentClosed=jsondecode(fileread(bindings.ParentClosureReference.file));
    assert(strcmp(parentClosed.schema,'PK30h-eligible-stored-graph-external-closure-v1')&&rfRefEqual(parentClosed.graph_reference,bindings.ParentPlanReference) ...
        &&parentClosed.process.actual_tool_exit_observed&&parentClosed.process.exit_code==0&&parentClosed.independent_post_guard.all_passed ...
        &&~parentClosed.raw_materialization_completion_claimed&&~parentClosed.scientific_completion_claimed, ...
        'PKEligible:ParentClosed','Only the actual closed graph-only Graph03 is the parent authority.');
    x=load(bindings.ParentPlanReference.file,'component_plan','plan_digest');parent=x.component_plan;rfSame(x.plan_digest,C1ScientificDigest_v3(parent));clear x
    assert(strcmp(parent.schema,'C1-stored-component-graph-plan-v1')&&parent.completed&&parent.source_posthash ...
        &&numel(parent.nodes)==1109&&numel(parent.source_catalog)==30&&~parent.source_occurrence_bijection_verified&&parent.active_source_occurrence_bijection_verified&&parent.current_guard_projection.applied&&parent.current_guard_projection.excluded_occurrences==1, ...
        'PKEligible:ParentScope','Preserve the exact original closed1109/30 Graph03 and every inherited scientific epoch.');
    for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'},assert(strcmp(B.(key{1}),parent.original_budget.(key{1})),'PKEligible:Grant','A new graph allowance never renews the original grant.');end
    parentView=C1StoredComponentSource_v3.prepare(rfAPIRef(bindings.ParentPlanReference));
    parentRefs=cellfun(@(c)struct('file',c.file,'sha256',c.sha256),parent.source_catalog,'UniformOutput',false);refs=[refs;parentRefs];gpVerify(refs);gpCheck(work);
    coldClosed=jsondecode(fileread(bindings.ColdClosureReference.file));
    assert(strcmp(coldClosed.schema,'PK30h-single-ROW3-cold-external-closure-v1') ...
        &&rfRefEqual(coldClosed.cold_audit_reference,bindings.ColdAuditReference)&&rfRefEqual(coldClosed.retained_carrier_reference,bindings.CarrierReference) ...
        &&rfRefEqual(coldClosed.acquisition_reference,bindings.AcquireAuditReference)&&rfRefEqual(coldClosed.acquire_external_closure_reference,bindings.AcquireClosureReference) ...
        &&coldClosed.process.actual_tool_exit_observed&&coldClosed.process.exit_code==0&&coldClosed.independent_post_guard.all_passed&&coldClosed.all_owned_native_workers_closed, ...
        'PKEligible:ColdClosed','Bind actual successful cold process exit, postguards, closed workers and all four literal authority references.');
    x=load(bindings.ColdAuditReference.file,'audit');cold=x.audit;clear x
    assert(strcmp(cold.schema,'PK30h-single-ROW3-cold-retained-v1')&&cold.completed&&cold.source_posthash&&cold.mandatory_cold_custody_complete ...
        &&cold.qualifier_calls_attempted==1&&cold.qualifier_calls_returned==1&&isempty(fieldnames(cold.failure)) ...
        &&cold.cold.qualified&&cold.cold.full_native_read2_verified&&cold.cold.complete_policy_read2_verified ...
        &&rfRefEqual(cold.cold.retained_reference,bindings.CarrierReference)&&rfRefEqual(cold.acquire_reference,bindings.AcquireAuditReference) ...
        &&rfRefEqual(cold.external_closure_reference,bindings.AcquireClosureReference) ...
        &&isequal(cold.cold.retained_physical_edge,[1,2])&&isequal(cold.cold.retained_numerical_row,[2,3]), ...
        'PKEligible:ColdAudit','Use the whole actual cold finite proof/read2/policy transport, never a raw Acquire branch duplicate.');
    acquireClosed=jsondecode(fileread(bindings.AcquireClosureReference.file));
    assert(strcmp(acquireClosed.schema,'PK30h-single-ROW3-Acquire-external-closure-v1')&&rfRefEqual(acquireClosed.acquisition_reference,bindings.AcquireAuditReference) ...
        &&acquireClosed.process.actual_tool_exit_observed&&acquireClosed.process.exit_code==0&&acquireClosed.independent_post_guard.all_passed&&acquireClosed.all_owned_native_workers_closed, ...
        'PKEligible:AcquireClosed','Keep the closed original finite Acquire authority as provenance without rereading its full numerical workspace.');
    additions={struct('role','closed_original0061_to_recovered0062_row3_carrier','reference',bindings.CarrierReference,'kind','closed-retained-P-M-carrier','cold_case_index',1,'cold_evidence',cold.cold.evidence,'cold_audit_reference',bindings.ColdAuditReference,'cold_closure_reference',bindings.ColdClosureReference,'acquire_audit_reference',bindings.AcquireAuditReference,'acquire_closure_reference',bindings.AcquireClosureReference)};
    for k=1:numel(bindings.AdditionalCarrierRows),[addition,extraRefs]=fgAdditionalCarrier(bindings.AdditionalCarrierRows{k});additions{end+1,1}=addition;refs=[refs;extraRefs];end
    paths=[cellfun(@(c)c.file,parent.source_catalog,'UniformOutput',false);cellfun(@(r)r.reference.file,additions,'UniformOutput',false)];assert(numel(unique(paths))==numel(paths),'PKClosedGraph:DistinctSources','Every appended closed carrier is a distinct immutable generation.');gpVerify(refs);
    assert(~any(cellfun(@(c)strcmp(c.file,bindings.CarrierReference.file),parent.source_catalog)), ...
        'PKEligible:DistinctCarrier','Append exactly one new immutable closed carrier source.');
    component_plan=parent;component_plan.completed=false;component_plan.source_posthash=false;component_plan.failure=struct();
    component_plan.parent_plan_reference=bindings.ParentPlanReference;component_plan.parent_closure_reference=bindings.ParentClosureReference;
    component_plan.graph04_parent_operation_history=struct('bindings',parent.bindings,'source_code',{parent.source_code},'input_references',{parent.input_references}, ...
        'original_budget',parent.original_budget,'operation_finish',parent.operation_finish,'operation_work',parent.operation_work, ...
        'completion_scope',parent.completion_scope,'acquisition_scope',parent.acquisition_scope,'parent_plan_reference',parent.parent_plan_reference, ...
        'parent_closure_reference',parent.parent_closure_reference,'final_incremental',parent.final_incremental, ...
        'current_guard_projection_digest',C1ScientificDigest_v3(parent.current_guard_projection),'finite_forward_LOW_handoff_digest',C1ScientificDigest_v3(parent.finite_forward_LOW_handoff));
    component_plan.bindings=bindings;component_plan.source_code=code;component_plan.input_references=refs;component_plan.original_budget=B;
    component_plan.operation_finish=finish;component_plan.operation_work=work;
    component_plan.completion_scope='GRAPH04 ONLY: append the actually closed declared ROW3/ROW13/ROW5 carriers to the eligible Graph03, preserving its prior exact guard exclusion and historical maps; no new guard search, raw payload materialization, admission or scientific completion.';
    result=struct('schema','PK30h-closed-carrier-stored-graph-append-operation-v1','completed',false,'source_posthash',false,'plan_reference',struct(), ...
        'stage_save_returned',false,'stage_read2_verified',false,'publication_returned',false,'owned_stage_unlink_returned',false,'installed_read2_verified',false, ...
        'parent_occurrences',numel(parent.nodes),'added_occurrences',0,'new_excluded_occurrences',0,'occurrences',0,'component_count',0,'failure',struct(),'own_process_exit_claimed',false);
    try
        catalogue=parent.source_catalog;nodes=parent.nodes;points=parent.view_index.points;edges=parent.view_index.edges;owners=parent.view_index.metadata.source_owner_map;
        discovery=parent.graph_discovery;newNative=cell(0,1);newReports=cell(0,1);newGlobals=zeros(0,1);addedFacts=cell(numel(additions),1);retainedValidations=0;
        for s=1:numel(additions)
            gpCheck(work);row=additions{s};view=C1StoredComponentSource_v3.prepare(rfAPIRef(row.reference));ix=C1StoredComponentSource_v3.index(view);count=numel(ix.points);offset=numel(nodes);sourceNumber=numel(catalogue)+1;
            assert(strcmp(view.kind,'raw-branch')&&count>0,'PKRefresh:AddedKind','Only actual native closed BranchSolutionFile stores are append sources.');
            catalogue{sourceNumber,1}=struct('file',row.reference.file,'sha256',row.reference.sha256,'bytes',dirBytes(row.reference.file),'metadata',ix.metadata, ...
                'point_metadata',{cellfun(@(p)p.metadata,ix.points,'UniformOutput',false)},'original_edges',{ix.edges},'stored_points',count,'stored_edges',numel(ix.edges),'source_public_readback_verified',false);
            firstDigests=cell(count,1);
            for pass=1:2
                [native,reports,metadata]=C1StoredComponentSource_v3.load(view,(1:count).');
                if pass==2,assert(~(kept==native{1}),'PKRefresh:IndependentHandles','Use independently deserialized added-source records; only one witness handle spans passes.');end
                for j=1:count
                    digest=rfNativeDigest(native{j},reports{j},metadata{j});
                    if pass==1,firstDigests{j}=digest;else,rfSame(firstDigests{j},digest);end
                end
                if pass==1,kept=native{1};clear native reports metadata;end
            end
            graphPart=member(ix.metadata,'component_graph',struct());A=member(graphPart,'qualified_record_aliases',zeros(0,2));E=member(graphPart,'exact_record_equalities',zeros(0,2));M=member(graphPart,'qualified_numerical_overlaps',zeros(0,2));ME=member(graphPart,'numerical_overlap_evidence',cell(0,1));
            validateAliasIndices(A,count);validateAliasIndices(E,count);validateAliasIndices(M,count);
            assert(isempty(A)&&isempty(E),'PKRefresh:AddedTypedScope','These declared current-P branches and finite3-record carriers must not contain an unsupported inherited E/A table; preserve/refuse it rather than dropping relations.');
            if row.cold_case_index==0
                assert(isempty(M)&&isempty(ME),'PKRefresh:CurrentPOnly','Current continuation output contributes its actual P only; no association is inferred from range or screen.');
            else
                z=struct('evidence',row.cold_evidence);assert(count==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2&&isequal(M,[2,3])&&iscell(ME)&&numel(ME)==1, ...
                    'PKRefresh:CarrierGraph','Retain exactly earnedP1-to2 and qualifiedM2-to3 with NONEDGE target.');rfSame(ME{1},z.evidence);
                C1FiniteNumericalOverlap_v3.validateRetained(ME{1},native{2},native{3},reports{2},reports{3},native{1});retainedValidations=retainedValidations+1;
            end
            for j=1:count
                originalPoint=ix.points{j};orbit=native{j};report=reports{j};section=MatchingReturnSection_v3(orbit,orbit,{report,report});state=orbit.initial_state(:);schema=QuadrupedSchema_v3.shared();state(schema.TranslationIndex)=0;
                globalIndex=offset+j;nodes{globalIndex,1}=struct('source_number',sourceNumber,'source_index',j,'point',originalPoint,'native_ID',OrbitContentIdentity_v3(orbit), ...
                    'normalized_state',state,'initial_mode',orbit.initial_mode(:),'parameter',orbit.parameter(:),'period',orbit.period,'stride',orbit.stride_displacement(:),'complete_return_section',section.compatible);
                owner=sprintf('source-%06d::%s',sourceNumber,char(originalPoint.component_identity));ownerRow=struct('source_number',sourceNumber,'source_component_identity',char(originalPoint.component_identity),'output_component_identity',owner);
                if ~any(cellfun(@(r)strcmp(r.output_component_identity,owner),owners)),owners{end+1,1}=ownerRow;end
                originalMetadata=normalizedOriginalMetadata(originalPoint.metadata);
                m=struct('component_identity',owner,'classification',char(originalPoint.classification),'nativeE',originalPoint.nativeE,'signedmeanU',originalPoint.signedmeanU, ...
                    'order',globalIndex,'consolidation_point_schema','C1-consolidated-occurrence-v1','provenance',struct('source_file',row.reference.file,'source_sha256',row.reference.sha256, ...
                    'source_index',j,'source_catalog_file',output,'source_catalog_entry',sourceNumber,'original_point_metadata',originalMetadata,'qualification_flags_changed',false));
                incoming=find(cellfun(@(e)e.to==j,ix.edges));assert(numel(incoming)<=1,'PKRefresh:Incoming','An actual occurrence has at most one physical predecessor.');
                if ~isempty(incoming),m.edge_enabled=true;m.edge_from=offset+ix.edges{incoming}.from;end
                points{globalIndex,1}=struct('index',globalIndex,'component_identity',owner,'order',globalIndex,'classification',m.classification,'nativeE',m.nativeE,'signedmeanU',m.signedmeanU, ...
                    'provenance',m.provenance,'metadata',m,'solution_variable',sprintf('solution_%06d',globalIndex),'report_variable',sprintf('report_%06d',globalIndex),'whole_public_data_readback_verified',false);
                newNative{end+1,1}=native{j};newReports{end+1,1}=reports{j};newGlobals(end+1,1)=globalIndex;
            end
            for j=1:numel(ix.edges)
                e=ix.edges{j};assert(strcmp(ix.points{e.from}.component_identity,ix.points{e.to}.component_identity),'PKRefresh:OwnedP','Every added P retains its actual same-owner original index edge.');
                discovery.physical_edges(end+1,:)=[offset+e.from,offset+e.to];edges{end+1,1}=struct('from',offset+e.from,'to',offset+e.to,'component_identity',points{offset+e.to}.component_identity);
            end
            for j=1:size(M,1)
                discovery.qualified_numerical_overlaps(end+1,:)=M(j,:)+offset;discovery.numerical_overlap_evidence{end+1,1}=ME{j};
                discovery.numerical_overlap_transports{end+1,1}=struct('kind','inherited_qualified_numerical_overlap','input_request',struct('source_file',row.reference.file,'source_sha256',row.reference.sha256,'source_overlap_row',j), ...
                    'left_node',offset+M(j,1),'right_node',offset+M(j,2),'original_evidence_unchanged',true);
            end
            addedFacts{s}=struct('role',row.role,'reference',row.reference,'source_number',sourceNumber,'global_indices',(offset+(1:count)).','point_count',count,'physical_edge_count',numel(ix.edges), ...
                'numerical_overlap_count',size(M,1),'independent_native_acquisitions',2,'one_handle_independence_witness_verified',true,'full_public_report_metadata_digest_read2_verified',true,'saved_admission_epoch_only',true);
            gpVerify({row.reference});gpCheck(work);fprintf('PK30H_GRAPH_REFRESH_SOURCE %d/%d points=%d P=%d M=%d\n',s,numel(additions),count,numel(ix.edges),size(M,1));clear native reports metadata view ix orbit report kept
        end
        newIDs=cellfun(@(g)nodes{g}.native_ID,num2cell(newGlobals),'UniformOutput',false);parentIDs=cellfun(@(r)r.native_ID,parent.nodes,'UniformOutput',false);
        originalSource=find(cellfun(@(c)strcmp(c.sha256,'821ed8549ec94c7fdd28d5de37579762d0825e277a15be045472c365c01c9486'),parent.source_catalog));
        recoveredSource=find(cellfun(@(c)strcmp(c.sha256,'c2f4fa0a6bde174b9496ebe327b95e35b2cd6f83b62243aafa38198c12a30ce9'),parent.source_catalog));
        assert(isscalar(originalSource)&&isscalar(recoveredSource),'PKROW3Graph:OriginalSources','Keep the exact original0061 and recovered0062 source generations.');
        original24=find(cellfun(@(n)n.source_number==originalSource&&n.source_index==24,parent.nodes));original25=find(cellfun(@(n)n.source_number==originalSource&&n.source_index==25,parent.nodes));recovered3=find(cellfun(@(n)n.source_number==recoveredSource&&n.source_index==3,parent.nodes));
        assert(isscalar(original24)&&isscalar(original25)&&isscalar(recovered3)&&strcmp(parent.nodes{original24}.native_ID,newIDs{1})&&strcmp(parent.nodes{recovered3}.native_ID,newIDs{3}), ...
            'PKROW3Graph:ImportedAnchors','The reversed ordered source pair25/24 imports original24 as carrier1; recovered target3 is carrier3. NativeID alone does not qualify E.');
        matchedParent=find(ismember(parentIDs,newIDs));groups=C1StoredComponentSource_v3.groups(parentView,matchedParent);parentMatchedFacts=cell(numel(groups),1);newE=0;
        for k=1:numel(groups)
            gpCheck(work);group=groups{k};[native,reports]=C1StoredComponentSource_v3.load(parentView,group.indices);
            for j=1:numel(group.indices)
                parentIndex=group.indices(j);matches=find(strcmp(newIDs,parent.nodes{parentIndex}.native_ID));
                for q=matches(:).'
                    [eligible,evidence]=fgExactE(native{j},newNative{q},reports{j},newReports{q});
                    if eligible,discovery.exact_record_equalities(end+1,:)=[parentIndex,newGlobals(q)];discovery.equality_evidence{end+1,1}=evidence;newE=newE+1;end
                end
            end
            parentMatchedFacts{k}=struct('source_number',group.source_number,'parent_global_indices',group.indices,'acquired_native_records',numel(group.indices),'acquisitions',1,'scope','Only NativeID-matched original full records/policies/sections/cohorts; no whole-source or old-M requalification.');clear native reports
        end
        for j=1:numel(newGlobals)
            for k=j+1:numel(newGlobals)
                if ~strcmp(newIDs{j},newIDs{k}),continue;end
                [eligible,evidence]=fgExactE(newNative{j},newNative{k},newReports{j},newReports{k});
                if eligible,discovery.exact_record_equalities(end+1,:)=[newGlobals(j),newGlobals(k)];discovery.equality_evidence{end+1,1}=evidence;newE=newE+1;end
            end
        end
        clear newNative newReports
        routePairs=[original24,newGlobals(1);newGlobals(1),newGlobals(2);newGlobals(2),newGlobals(3);newGlobals(3),recovered3];routeKinds={'E';'P';'M';'E'};route=cell(4,1);
        for k=1:4
            key='physical_edges';if strcmp(routeKinds{k},'E'),key='exact_record_equalities';elseif strcmp(routeKinds{k},'M'),key='qualified_numerical_overlaps';end
            pairs=discovery.(key);if strcmp(routeKinds{k},'P'),rows=find(all(pairs==routePairs(k,:),2));else,rows=find(all(pairs==routePairs(k,:),2)|all(pairs==fliplr(routePairs(k,:)),2));end
            assert(isscalar(rows),'PKROW3Graph:TypedRoute','Bind the exact actual E/P/M/E route without component-membership or geometric inference.');
            route{k}=struct('kind',routeKinds{k},'relation_row',rows,'from',routePairs(k,1),'to',routePairs(k,2),'from_native_ID',nodes{routePairs(k,1)}.native_ID,'to_native_ID',nodes{routePairs(k,2)}.native_ID,'physical_edge_claimed',strcmp(routeKinds{k},'P'));
        end
        directionAudit=fgROW3DirectionAudit(parent,nodes,discovery,originalSource,recoveredSource,original24,original25,recovered3,newGlobals(1:3));
        rfSame(parent.nodes,nodes(1:numel(parent.nodes)));rfSame(parent.source_catalog,catalogue(1:numel(parent.source_catalog)));rfSame(parent.view_index.points,points(1:numel(parent.nodes)));rfSame(parent.view_index.edges,edges(1:numel(parent.view_index.edges)));
        for field={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'},key=field{1};rfSame(parent.graph_discovery.(key),discovery.(key)(1:size(parent.graph_discovery.(key),1),:));end
        for field={'equality_evidence','qualified_alias_evidence','numerical_overlap_evidence','numerical_overlap_transports'},key=field{1};old=parent.graph_discovery.(key);current=discovery.(key);rfSame(old,reshape(current(1:numel(old)),size(old)));end
        discovery.effective_edges=[discovery.physical_edges;discovery.exact_record_equalities;discovery.qualified_record_aliases;discovery.qualified_numerical_overlaps];
        count=numel(nodes);bins=conncomp(graph(discovery.effective_edges(:,1),discovery.effective_edges(:,2),[],count));componentCount=max(bins);newID=['C1-closed-carrier-append:',C1ScientificDigest_v3(struct('parent',bindings.ParentPlanReference,'added_sources',{additions},'graph',discovery))];
        globalGraph=rfGraph(parent.view_index.metadata.component_graph,discovery,(1:count).',count,componentCount==1);globalMetadata=parent.view_index.metadata;
        globalMetadata.consolidation_id=newID;globalMetadata.component_number=0;globalMetadata.original_connected_component_numbers=1:componentCount;globalMetadata.families=unique(cellfun(@(r)family(r.point.classification),nodes,'UniformOutput',false));
        globalMetadata.source_catalog_file=output;globalMetadata.source_catalog_entries=1:numel(catalogue);globalMetadata.component_graph=globalGraph;globalMetadata.source_owner_map=owners;globalMetadata.scientific_flags_upgraded=false;
        components=cell(componentCount,1);occurrenceMap=cell(count,1);parentMap=zeros(numel(parent.nodes),5);coverage=false(count,1);
        for c=1:componentCount
            selected=find(bins==c).';toLocal=zeros(count,1);toLocal(selected)=1:numel(selected);localPoints=cell(numel(selected),1);localGraph=rfGraph(globalGraph,discovery,selected,count,true);localMetadata=globalMetadata;
            localMetadata.component_number=c;localMetadata.original_connected_component_numbers=c;localMetadata.component_graph=localGraph;localMetadata.families=unique(cellfun(@(r)family(r.point.classification),nodes(selected),'UniformOutput',false));localMetadata.source_catalog_entries=unique(cellfun(@(r)r.source_number,nodes(selected)));
            selectedOwners=cellfun(@(r)r.component_identity,points(selected),'UniformOutput',false);localMetadata.source_owner_map=owners(cellfun(@(r)any(strcmp(selectedOwners,r.output_component_identity)),owners));
            for j=1:numel(selected)
                g=selected(j);point=points{g};point.index=j;point.order=j;point.metadata.order=j;point.solution_variable=sprintf('solution_%06d',j);point.report_variable=sprintf('report_%06d',j);
                if isfield(point.metadata,'edge_from'),assert(toLocal(point.metadata.edge_from)>0,'PKROW3Graph:PhysicalParent','An actual physical parent stays in its effective component.');point.metadata.edge_from=toLocal(point.metadata.edge_from);end
                localPoints{j}=point;node=nodes{g};source=catalogue{node.source_number};occurrenceMap{g}=struct('source_file',source.file,'source_sha256',source.sha256,'source_index',node.source_index,'global_index',g,'component_number',c,'component_index',j);
                if g<=numel(parent.nodes),old=parent.occurrence_map{g};parentMap(g,:)=[g,old.component_number,old.component_index,c,j];end
            end
            localEdges=cell(size(localGraph.original_explicit_edges,1),1);for j=1:numel(localEdges),pair=localGraph.original_explicit_edges(j,:);localEdges{j}=struct('from',pair(1),'to',pair(2),'component_identity',localPoints{pair(2)}.component_identity);end
            ix=struct('storage_version',parent.view_index.storage_version,'metadata',localMetadata,'points',{localPoints},'edges',{localEdges});assertConnected(localGraph,numel(selected));
            assert(~any(coverage(selected)),'PKROW3Graph:Bijection','Every eligible parent/appended occurrence has one current component/local selector.');coverage(selected)=true;
            components{c}=struct('component_number',c,'global_indices',selected(:),'planned_materialization_index',ix,'planned_index_digest',C1ScientificDigest_v3(ix),'materialization_completed_by_this_operation',false);
            fprintf('PK30H_ROW3_GRAPH_COMPONENT %d/%d N=%d P=%d E=%d A=%d M=%d\n',c,componentCount,numel(selected),size(localGraph.original_explicit_edges,1),size(localGraph.exact_record_equalities,1),size(localGraph.qualified_record_aliases,1),size(localGraph.qualified_numerical_overlaps,1));
        end
        assert(all(coverage),'PKROW3Graph:Coverage','Preserve every eligible Graph03 occurrence and every declared carrier occurrence.');
        projection=parent.current_guard_projection;
        for s=1:numel(catalogue)
            actual=cellfun(@(r)r.source_index,nodes(cellfun(@(r)r.source_number==s,nodes)));expected=(1:catalogue{s}.stored_points).';
            if s==projection.excluded_source_number,expected(expected==projection.excluded_source_index)=[];end
            assert(isequal(sort(actual(:)),expected),'PKROW3Graph:EligibleSourceCoverage','Keep all source indices except the single exact previously excluded historical occurrence; do not search/filter it again.');
        end
        composed=projection.parent_to_active_map;for k=1:size(composed,1),g=composed(k,4);if g>0,composed(k,5:6)=parentMap(g,4:5);end,end
        component_plan.consolidation_id=newID;component_plan.source_catalog=catalogue;component_plan.nodes=nodes;component_plan.graph_discovery=discovery;component_plan.components=components;component_plan.occurrence_map=occurrenceMap;
        component_plan.view_index=struct('storage_version',parent.view_index.storage_version,'metadata',globalMetadata,'points',{points},'edges',{edges});component_plan.source_occurrence_bijection_verified=false;component_plan.active_source_occurrence_bijection_verified=true;
        rfSame(parent.current_guard_projection,component_plan.current_guard_projection);rfSame(parent.finite_forward_LOW_handoff,component_plan.finite_forward_LOW_handoff);rfSame(parent.final_incremental,component_plan.final_incremental);rfSame(parent.parent_operation_history,component_plan.parent_operation_history);
        component_plan.current_eligible_scope=struct('schema','PK30h-current-eligible-append-scope-v1','parent_plan_reference',bindings.ParentPlanReference, ...
            'parent_occurrences',numel(parent.nodes),'new_carrier_occurrences',numel(newGlobals),'active_occurrences',count,'new_excluded_occurrences',0,'inherited_excluded_occurrences',projection.excluded_occurrences, ...
            'original_source_occurrences',sum(cellfun(@(c)c.stored_points,catalogue)),'active_component_count',componentCount,'active_component_occurrences',cellfun(@(c)numel(c.global_indices),components), ...
            'parent_guard_projection_unchanged',true,'inherited_guard_projection_epoch','Literal Graph03 projection and its maps/counts are historical. The current component maps are incremental_append.parent_to_current_map and original_guard_parent_to_current_map.', ...
            'all_original_source_occurrences_active',false,'all_eligible_parent_and_new_carrier_occurrences_preserved',true,'new_guard_search_or_exclusion_performed',false,'historical_flags_changed',false);
        component_plan.incremental_append=struct('schema','PK30h-closed-carrier-incremental-append-v1','parent_occurrences',numel(parent.nodes),'added_occurrences',numel(newGlobals),'added_sources',{addedFacts},'closed_carrier_authorities',{additions}, ...
            'cold_audit_reference',bindings.ColdAuditReference,'cold_external_closure_reference',bindings.ColdClosureReference,'cold_external_closure_payload',coldClosed, ...
            'parent_to_current_map',parentMap,'parent_map_columns',{{'parent_global';'parent_component';'parent_local';'current_component';'current_local'}}, ...
            'original_guard_parent_to_current_map',composed,'original_guard_parent_map_columns',{projection.parent_map_columns}, ...
            'selected_original_source_reference',struct('file',catalogue{originalSource}.file,'sha256',catalogue{originalSource}.sha256),'selected_original_predictor_pair',[25,24],'expected_original_stored_physical_edge',[24,25],'ROW3_directional_audit',directionAudit, ...
            'selected_recovered_reference',struct('file',catalogue{recoveredSource}.file,'sha256',catalogue{recoveredSource}.sha256),'selected_recovered_index',3,'actual_typed_route',{route}, ...
            'parent_matched_source_acquisitions',{parentMatchedFacts},'new_exact_E_links',newE,'new_retained_M_validations',retainedValidations, ...
            'parent_nodes_catalogue_virtual_points_edges_and_relation_evidence_prefixes_literal',true,'parent_guard_projection_and_LOW_handoff_literal',true,'all_actual_closed_ROW3_carriers_included',true,'all_actual_declared_closed_carriers_included',true, ...
            'new_sources_independent_acquisitions',2,'parent_native_cache_retained',false,'new_admission_qualification_performed',false);
        component_plan.acquisition_scope=struct('parent_original_source_groups',numel(parent.source_catalog),'added_whole_source_groups',numel(additions),'added_independent_passes',2,'parent_matched_source_groups',numel(groups),'maximum_added_source_records',3,'one_independence_handle_per_added_source',true,'whole_parent_requalification_claimed',false,'universal16_record_bound_claimed',false);
        component_plan.new_root_integrations_classifications_replays=0;component_plan.new_overlap_qualification_calls=0;component_plan.native_payload_copied=false;component_plan.scientific_completion_claimed=false;component_plan.source_retirement_authorized=false;component_plan.own_process_exit_claimed=false;
        component_plan.global_index_scope='Eligible Graph03 global node selectors/order and virtual points remain literal; Declared closed sources append. Dynamic component-local indices and physical predecessors remap. Immutable node.point/catalogue metadata remain original; Graph03 guard-projection maps/counts remain historical with explicit current composed maps.';
        component_plan.input_references=refs;gpVerify(refs);gpCheck(work);component_plan.source_posthash=true;component_plan.completed=true;component_plan.completed_utc=stamp();component_plan.wall_seconds=(gpNano()-entryMono)/1e9;
        plan_digest=C1ScientificDigest_v3(component_plan);save(stage,'component_plan','plan_digest','-v7');result.stage_save_returned=true;gpRead2(stage,component_plan);result.stage_read2_verified=true;gpVerify(refs);gpCheck(finish);
        stageHash=RoundSHA256_v3(stage);assert(~isfile(output),'PKROW3Graph:PublishFresh','Retain a concurrent final result.');javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());result.publication_returned=true;
        assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),stageHash)&&strcmp(RoundSHA256_v3(output),stageHash),'PKROW3Graph:OwnStage','Unlink only the unchanged hardlinked own graph stage.');
        javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());result.owned_stage_unlink_returned=true;gpRead2(output,component_plan);result.installed_read2_verified=true;gpVerify(refs);gpCheck(finish);
        result.plan_reference=gpRef(output);result.completed=true;result.source_posthash=true;result.added_occurrences=numel(newGlobals);result.new_excluded_occurrences=0;result.occurrences=count;result.component_count=componentCount;
    catch problem
        result.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);component_plan.completed=false;component_plan.failure=result.failure;
        if ~isfile(failureFile),plan_digest=C1ScientificDigest_v3(component_plan);operation_result=result;save(failureFile,'component_plan','plan_digest','operation_result','-v7');end
    end
    result.elapsed_seconds=(gpNano()-entryMono)/1e9;result.scope='Saved GRAPH04 append only; original Graph03 guard exclusion and every historical raw flag remain literal. No root/ODE, fresh admission, raw export, retirement, scientific completion or own process-exit claim.';
    try,fprintf('PK30H_ROW3_GRAPH_RETURN %s\n',jsonencode(result));catch,end
end
function out=fgROW3DirectionAudit(parent,nodes,d,originalSource,recoveredSource,original24,original25,recovered3,newGlobals)
% Saved full13 geometry only. Every unresolved prerequisite/sign stays local
% to this observation and cannot turn graph publication into a coverage claim.
    out=struct('schema','PK30h-ROW3-complementary-finite-direction-audit-v1','completed',false,'status','UNRESOLVED', ...
        'positive_finite_direction_observed',false,'finite_frontier_disposition_supported',false, ...
        'full13_state_indices',(2:14).','common_scale13',[],'raw_secants13',[],'scaled_secants13',[], ...
        'secant_names',{{'incoming_recovered3_minus2';'outward_bridge_original24_minus_recovered3';'donor_original25_minus24';'new_earned_carrier2_minus1'}}, ...
        'secant_norms',[],'pairwise_secant_cosines',[],'projections_on_incoming_unit_secant',[], ...
        'tested_cosines_incoming_with_bridge_donor_new',[],'predeclared_positive_signs',[1,1,-1], ...
        'literal_state13',[],'selected_global_indices',[],'selected_native_IDs',{{}},'typed_complementary_route',{{}}, ...
        'actual_recovered_physical_edge_verified',false,'actual_donor_physical_edge_verified',false, ...
        'source_retirement_authorized',false,'fresh_admission_claimed',false,'new_root_ODE_map_fine_native_read_calls',0, ...
        'classical_tangent_uniqueness_or_global_coverage_proved',false,'failure',struct(), ...
        'scope','Conditional finite saved-neighborhood observation only. Incoming must align positively with bridge and donor while the newly earned P points oppositely. A reverse traversal of an existing P creates no directed edge. Missing, zero, nonfinite or nonpositive directional evidence stays UNRESOLVED and cannot authorize frontier/source retirement.');
    try
        recovered2=find(cellfun(@(n)n.source_number==recoveredSource&&n.source_index==2,parent.nodes));
        assert(isscalar(recovered2)&&isscalar(recovered3)&&isscalar(original24)&&isscalar(original25)&&numel(newGlobals)==3, ...
            'PKROW3Direction:Selectors','All literal recovered2/3, original24/25 and carrier1/2/3 selectors must exist uniquely.');
        selected=[recovered2;recovered3;original24;original25;newGlobals(1);newGlobals(2)];out.selected_global_indices=selected;
        out.selected_native_IDs=cellfun(@(g)nodes{g}.native_ID,num2cell(selected),'UniformOutput',false);
        states=zeros(13,numel(selected));for k=1:numel(selected),v=nodes{selected(k)}.normalized_state;assert(isequal(size(v),[14,1])&&all(isfinite(v(2:14))),'PKROW3Direction:State13','Use literal complete finite saved state2:14 without projection or zeroing.');states(:,k)=v(2:14);end
        out.literal_state13=states;scale=max([ones(13,1),abs(states)],[],2);out.common_scale13=scale;
        raw=[states(:,2)-states(:,1),states(:,3)-states(:,2),states(:,4)-states(:,3),states(:,6)-states(:,5)];scaled=raw./scale;out.raw_secants13=raw;out.scaled_secants13=scaled;
        steps=sqrt(sum(scaled.^2,1));out.secant_norms=steps;
        assert(all(isfinite(steps))&&all(steps>0),'PKROW3Direction:ResolvedSecants','All four common-scale full13 finite secants need nonzero observed norms.');
        unit=scaled./steps;cosines=unit.'*unit;out.pairwise_secant_cosines=cosines;out.projections_on_incoming_unit_secant=unit(:,1).'*scaled;
        tested=cosines(1,2:4);out.tested_cosines_incoming_with_bridge_donor_new=tested;
        assert(all(isfinite(tested))&&all(abs(tested)<=1+1e-12),'PKROW3Direction:Cosines','The observed full13 common-scale finite secant cosines must be finite.');
        assert(nodes{recovered2}.source_number==recoveredSource&&nodes{recovered3}.source_number==recoveredSource ...
            &&strcmp(nodes{recovered2}.point.component_identity,nodes{recovered3}.point.component_identity) ...
            &&sum(all(d.physical_edges==[recovered2,recovered3],2))==1, ...
            'PKROW3Direction:RecoveredOwnedP','Require actual same-owner recoveredP2-to3; no assumed incoming edge.');out.actual_recovered_physical_edge_verified=true;
        assert(nodes{original24}.source_number==originalSource&&nodes{original25}.source_number==originalSource ...
            &&strcmp(nodes{original24}.point.component_identity,nodes{original25}.point.component_identity) ...
            &&sum(all(d.physical_edges==[original24,original25],2))==1, ...
            'PKROW3Direction:DonorOwnedP','Require actual same-owner donorP24-to25; no assumed23-to24 edge.');out.actual_donor_physical_edge_verified=true;
        pairs=[recovered2,recovered3;recovered3,newGlobals(3);newGlobals(3),newGlobals(2);newGlobals(2),newGlobals(1);newGlobals(1),original24;original24,original25];kinds={'P';'E';'M';'P';'E';'P'};route=cell(6,1);
        for k=1:6
            key='physical_edges';if strcmp(kinds{k},'E'),key='exact_record_equalities';elseif strcmp(kinds{k},'M'),key='qualified_numerical_overlaps';end
            actual=d.(key);expected=pairs(k,:);if k==4,rows=find(all(actual==fliplr(expected),2));elseif strcmp(kinds{k},'P'),rows=find(all(actual==expected,2));else,rows=find(all(actual==expected,2)|all(actual==fliplr(expected),2));end
            assert(isscalar(rows),'PKROW3Direction:TypedRoute','Every complementary route step must bind its actual P/E/M relation row.');stored=actual(rows,:);
            route{k}=struct('kind',kinds{k},'relation_row',rows,'path_from',expected(1),'path_to',expected(2),'stored_from',stored(1),'stored_to',stored(2), ...
                'path_from_native_ID',nodes{expected(1)}.native_ID,'path_to_native_ID',nodes{expected(2)}.native_ID, ...
                'traversed_in_stored_direction',isequal(expected,stored),'reverse_physical_traversal',k==4,'stored_relation_is_physical',strcmp(kinds{k},'P'),'new_directed_edge_created',false);
        end
        out.typed_complementary_route=route;out.completed=true;
        positive=tested(1)>0&&tested(2)>0&&tested(3)<0;out.positive_finite_direction_observed=positive;out.finite_frontier_disposition_supported=positive;
        if positive,out.status='POSITIVE_FINITE_COMPLEMENTARY_DIRECTION_OBSERVED';else,out.status='UNRESOLVED_NONPOSITIVE_FINITE_DIRECTION';end
    catch problem
        out.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);out.status='UNRESOLVED_PREREQUISITE_OR_FINITE_MEASUREMENT';
    end
end
function [addition,refs]=fgAdditionalCarrier(row)
    keys={'Role';'CarrierReference';'ColdAuditReference';'ColdClosureReference';'AcquireAuditReference';'AcquireClosureReference'};
    assert(isstruct(row)&&isscalar(row)&&isequal(sort(fieldnames(row)),sort(keys))&&ischar(row.Role)&&isrow(row.Role)&&any(strcmp(row.Role,{'ROW13','ROW5'})), ...
        'PKClosedGraph:AdditionalRow','Each optional row has one unique whitelisted ROW13/ROW5 role and all five exact closed authority references.');
    refs={row.CarrierReference;row.ColdAuditReference;row.ColdClosureReference;row.AcquireAuditReference;row.AcquireClosureReference};gpVerify(refs);
    closed=jsondecode(fileread(row.ColdClosureReference.file));
    assert(strcmp(closed.schema,sprintf('PK30h-single-%s-cold-external-closure-v1',row.Role))&&rfRefEqual(closed.cold_audit_reference,row.ColdAuditReference) ...
        &&rfRefEqual(closed.retained_carrier_reference,row.CarrierReference)&&rfRefEqual(closed.acquisition_reference,row.AcquireAuditReference)&&rfRefEqual(closed.acquire_external_closure_reference,row.AcquireClosureReference) ...
        &&closed.process.actual_tool_exit_observed&&closed.process.exit_code==0&&closed.independent_post_guard.all_passed&&closed.all_owned_native_workers_closed, ...
        'PKClosedGraph:AdditionalColdClosed','Every optional carrier requires actual successful cold exit/postguards/worker closure and exact reference joins.');
    x=load(row.ColdAuditReference.file,'audit');a=x.audit;clear x
    assert(strcmp(a.schema,sprintf('PK30h-single-%s-cold-retained-v1',row.Role))&&a.completed&&a.source_posthash&&a.mandatory_cold_custody_complete ...
        &&a.qualifier_calls_attempted==1&&a.qualifier_calls_returned==1&&isempty(fieldnames(a.failure))&&a.cold.qualified&&a.cold.full_native_read2_verified&&a.cold.complete_policy_read2_verified ...
        &&rfRefEqual(a.cold.retained_reference,row.CarrierReference)&&rfRefEqual(a.acquire_reference,row.AcquireAuditReference)&&rfRefEqual(a.external_closure_reference,row.AcquireClosureReference) ...
        &&isequal(a.cold.retained_physical_edge,[1,2])&&isequal(a.cold.retained_numerical_row,[2,3]), ...
        'PKClosedGraph:AdditionalColdAudit','Require whole optional saved finite proof/read2/policy three-record custody, never geometric closeness or a raw branch duplicate.');
    acquired=jsondecode(fileread(row.AcquireClosureReference.file));
    assert(strcmp(acquired.schema,sprintf('PK30h-single-%s-Acquire-external-closure-v1',row.Role))&&rfRefEqual(acquired.acquisition_reference,row.AcquireAuditReference) ...
        &&acquired.process.actual_tool_exit_observed&&acquired.process.exit_code==0&&acquired.independent_post_guard.all_passed&&acquired.all_owned_native_workers_closed, ...
        'PKClosedGraph:AdditionalAcquireClosed','The optional carrier keeps its own closed successful finite Acquire authority.');
    caseIndex=2+double(strcmp(row.Role,'ROW5')); % Literal labels2=ROW13,3=ROW5; both take the unchanged retained-carrier validation path.
    addition=struct('role',sprintf('closed_%s_carrier',row.Role),'reference',row.CarrierReference,'kind','closed-retained-P-M-carrier','cold_case_index',caseIndex, ...
        'cold_evidence',a.cold.evidence,'cold_audit_reference',row.ColdAuditReference,'cold_closure_reference',row.ColdClosureReference, ...
        'acquire_audit_reference',row.AcquireAuditReference,'acquire_closure_reference',row.AcquireClosureReference);
end
function yes=fgCohortEqual(a,b)
    names={'return_multiplicity','event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names','section_cluster_coincidence','section_coincident_cluster_indices'};
    required={'event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names'};yes=true;
    for k=1:numel(required),left=a.(required{k});right=b.(required{k});yes=yes&&~isempty(left)&&~isempty(right);if ischar(left)||isstring(left),yes=yes&&all(strlength(string(left))>0,'all');end;if ischar(right)||isstring(right),yes=yes&&all(strlength(string(right))>0,'all');end;end
    for k=1:numel(names),yes=yes&&strcmp(C1ScientificDigest_v3(a.(names{k})),C1ScientificDigest_v3(b.(names{k})));end
end
function [yes,e]=fgExactE(a,b,ra,rb)
    [yes,e]=rfExactE(a,b,ra,rb);if ~yes,return;end
    names={'return_multiplicity','event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names','section_cluster_coincidence','section_coincident_cluster_indices'};
    if ~fgCohortEqual(a,b),yes=false;e=struct();return;end
    e.symbolic_cluster_and_coincidence_cohort_literal_equal=true;e.symbolic_cohort_fields=names(:);e.absolute_event_time_equality_required=false;
end
function [yes,e]=rfExactE(a,b,ra,rb)
    e=struct();yes=false;if ~strcmp(OrbitContentIdentity_v3(a),OrbitContentIdentity_v3(b))||~isequaln(rfRecord(a),rfRecord(b)),return;end
    [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);if ~pa.complete||~pb.complete||~isequaln(pa.configuration,pb.configuration),return;end
    match=MatchingReturnSection_v3(a,b,{ra,rb});if ~match.compatible,return;end
    yes=true;e=struct('native_ID',OrbitContentIdentity_v3(a),'exact_state_mode_parameter_period_stride',true,'translation_gauge_normalized',false,'raw14_state_exact',true, ...
        'complete_policy_equal',true,'matching_return_section',match,'new_continuation_edge_created',false,'new_admission_claimed',false,'source_admission_epochs_unchanged',true);
end
function r=rfRecord(o)
    r=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement, ...
        'return_policy_name',o.return_policy_name,'section_chart',o.section_chart,'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature);
end
function digest=rfNativeDigest(o,r,m),digest=C1ScientificDigest_v3(struct('orbit',rfPublic(o),'report',rfPublic(r),'metadata',m));end
function yes=rfRefEqual(a,b)
    yes=isstruct(a)&&isscalar(a)&&isstruct(b)&&isscalar(b)&&all(isfield(a,{'file','sha256'}))&&all(isfield(b,{'file','sha256'}))&&strcmp(a.file,b.file)&&strcmp(a.sha256,b.sha256);
    if yes&&isfield(a,'bytes')&&isfield(b,'bytes'),yes=isequal(double(a.bytes),double(b.bytes));end
end
function r=rfAPIRef(r),r=struct('file',r.file,'sha256',r.sha256);end
function rfSame(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKRefresh:Typed','Complete typed plain values differ.');end
function bytes=dirBytes(file),d=dir(file);assert(isscalar(d)&&~d.isdir,'PKRefresh:File','An exact source must remain one regular native file.');bytes=d.bytes;end
function g=rfGraph(template,d,selected,n,connected)
    map=zeros(n,1);map(selected)=1:numel(selected);g=template;g.nodes=numel(selected);
    fields={'original_explicit_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};actual={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};masks=cell(4,1);
    for k=1:4,p=d.(actual{k});mask=ismember(p(:,1),selected)&ismember(p(:,2),selected);masks{k}=mask;g.(fields{k})=reshape(map(p(mask,:)),[],2);end
    g.qualified_alias_evidence=d.qualified_alias_evidence(masks{3});g.numerical_overlap_evidence=d.numerical_overlap_evidence(masks{4});g.equality_evidence=d.equality_evidence(masks{2});
    g.effective_edges=[g.original_explicit_edges;g.exact_record_equalities;g.qualified_record_aliases;g.qualified_numerical_overlaps];g.connected=connected;g.isolated_record_catalogue=false;
end
function refs=rfProviders()
    names={'AppendPK30hClosedCarriersStoredGraph20261102','C1StoredComponentSource_v3','BranchSolutionFile_v3','C1FiniteNumericalOverlap_v3', ...
        'RecordedReturnPolicy_v3','MatchingReturnSection_v3','ReturnPolicyBase_v3','BLMarkedApexReturnPolicy_v3','EventCycleReturnPolicy_v3','IteratedReturnPolicy_v3','FirstReturnPolicy_v3','OrbitContentIdentity_v3','QuadrupedSchema_v3','HybridOrbit_v3','Trajectory_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cellfun(@(name)gpRef(which(name)),names(:),'UniformOutput',false);refs{end+1,1}=gpRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end

function [original,kind]=normalizedOriginalMetadata(metadata)
% One-level flatten only for a direct known envelope. A Run import retains
% its ENTIRE immediate metadata; no provenance crawl or scientific edit.
assert(isstruct(metadata)&&isscalar(metadata),'C1Consolidate:PointMetadata', ...
    'Every immediate point metadata record must be one scalar struct.');
original=metadata;kind=1;
if ~isfield(metadata,'consolidation_point_schema'),return;end
assert(isequal(metadata.consolidation_point_schema,'C1-consolidated-occurrence-v1') ...
    &&isfield(metadata,'provenance')&&isstruct(metadata.provenance)&&isscalar(metadata.provenance), ...
    'C1Consolidate:MarkedMetadata','A marked point needs the exact known schema and scalar provenance.');
p=metadata.provenance;
pathText=@(x)ischar(x)&&isrow(x)&&~isempty(x);
positiveIndex=@(x)isnumeric(x)&&isreal(x)&&isscalar(x)&&isfinite(x)&&x>=1&&x==fix(x);
direct={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
imported={'kind','source_file','source_index','original_provenance'};
if isequal(sort(fieldnames(p)),sort(direct(:)))
    assert(pathText(p.source_file)&&pathText(p.source_catalog_file)&&positiveIndex(p.source_index)&&positiveIndex(p.source_catalog_entry) ...
        &&ischar(p.source_sha256)&&isrow(p.source_sha256)&&~isempty(regexp(p.source_sha256,'^[0-9a-f]{64}$','once')) ...
        &&isstruct(p.original_point_metadata)&&isscalar(p.original_point_metadata)&&isequal(p.qualification_flags_changed,false), ...
        'C1Consolidate:DirectMetadata','The direct consolidation envelope is malformed; retain it and refuse.');
    original=p.original_point_metadata;kind=2;
elseif isequal(sort(fieldnames(p)),sort(imported(:)))
    assert(isequal(p.kind,'imported nonedge initial pair')&&pathText(p.source_file)&&positiveIndex(p.source_index) ...
        &&isstruct(p.original_provenance)&&isscalar(p.original_provenance)&&isfield(metadata,'edge_enabled') ...
        &&isequal(metadata.edge_enabled,false)&&~isfield(metadata,'edge_from'), ...
        'C1Consolidate:ImportedMetadata','Only the exact Run imported-NONEDGE wrapper may preserve its entire immediate metadata.');
    kind=3;
else
    error('C1Consolidate:MarkedMetadata','Unknown marked provenance shape; no generic fallback or recursive flatten is permitted.');
end
end

function validateAliasPoint(value,n)
assert(isnumeric(value)&&isreal(value)&&isscalar(value)&&isfinite(value) ...
    &&value==fix(value)&&value>=1&&value<=n,'C1Consolidate:Aliases', ...
    'Each alias selector needs one bounded positive integer occurrence index.');
end
function validateAliasIndices(pairs,n)
assert(isnumeric(pairs)&&isreal(pairs)&&ismatrix(pairs)&&size(pairs,2)==2 ...
    &&all(isfinite(pairs(:)))&&all(pairs(:)==fix(pairs(:)))&&all(pairs(:)>=1)&&all(pairs(:)<=n), ...
    'C1Consolidate:Aliases','Alias links require bounded positive integer occurrence indices.');
end
function assertConnected(metadata,n)
edges=metadata.effective_edges;bins=conncomp(graph(edges(:,1),edges(:,2),[],n));
assert(n>0 && max(bins)==1,'C1Consolidate:Disconnected','Output must contain one effective connected component.');
end
function out=member(value,key,fallback)
out=fallback;if isstruct(value)&&isscalar(value)&&isfield(value,key),out=value.(key);end
end
function out=family(label)
match=regexp(char(label),'^(PK|BG|BE|FG|FE|HG|HE|GG|GE)[0-9]*$','tokens','once');
out='OTHER';if ~isempty(match),out=match{1};end
end
function path=canonical(value)
assert((ischar(value)&&isrow(value)&&~isempty(value))||(isstring(value)&&isscalar(value)&&strlength(value)>0), ...
    'C1Consolidate:Path','Expected scalar nonempty path text.');
path=char(java.io.File(char(value)).getCanonicalPath());
end
function output=stamp()
output=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
end
function assertPublicEqual(original,saved,allowNative,depth)
% Byte-identical built-in serialization of a plain subtree is stronger than
% numerical isequaln: it preserves nested classes/shapes, sparse/complex
% storage, field order and NaN payloads. Different serialization falls back
% to the original recursive public-data comparison. Native handles always
% use that original recursive path. BranchSolutionFile's independent reader
% also validates every report/metadata subtree as plain data.
if ~allowNative && (isstruct(original)||iscell(original))
    try
        leftBytes=getByteStreamFromArray(original);rightBytes=getByteStreamFromArray(saved);
        if strcmp(class(original),class(saved))&&isequal(size(original),size(saved)) ...
                &&isequal(leftBytes,rightBytes),return;end
    catch
        % Serialization is only an optional equality accelerator.
    end
end
assert(depth<=128&&strcmp(class(original),class(saved))&&isequal(size(original),size(saved)), ...
    'C1Consolidate:Readback','Readback class, shape or nesting differs.');
if isnumeric(original)||islogical(original)
    assert(issparse(original)==issparse(saved)&&isreal(original)==isreal(saved)&&isequaln(original,saved), ...
        'C1Consolidate:Readback','Readback values or storage type differ.');
elseif ischar(original)||isstring(original)
    assert(isequaln(original,saved),'C1Consolidate:Readback','Readback text differs.');
elseif iscell(original)
    for k=1:numel(original),assertPublicEqual(original{k},saved{k},allowNative,depth+1);end
elseif isstruct(original)
    names=fieldnames(original);assert(isequal(names,fieldnames(saved)),'C1Consolidate:Readback','Struct fields differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),allowNative,depth+1);end;end
else
    assert(allowNative&&any(strcmp(class(original),{'HybridOrbit_v3','Trajectory_v3'})), ...
        'C1Consolidate:Readback','Unsupported public object class.');
    names=sort(properties(original));assert(isequal(names,sort(properties(saved))), ...
        'C1Consolidate:Readback','Public properties differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),true,depth+1);end;end
end
end


function gpRead2(file,expected)
    for pass=1:2
        x=load(file,'component_plan','plan_digest');assert(strcmp(C1ScientificDigest_v3(x.component_plan),x.plan_digest), ...
            'PKGraphPlan:ReadDigest','Each independent plan read must verify its whole typed digest.');
        assertPublicEqual(expected,x.component_plan,false,0);clear x
    end
end
function gpVerify(refs)
    for k=1:numel(refs)
        r=refs{k};assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'}))&&strcmp(r.file,gpLiteral(r.file)) ...
            &&ischar(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once'))&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
            'PKGraphPlan:Changed','A consumed immutable source/proof/closure/prefix or current graph recipe changed.');
        if isfield(r,'bytes')
            d=dir(r.file);assert(isscalar(d)&&~d.isdir&&isequal(double(d.bytes),double(r.bytes)), ...
                'PKGraphPlan:Bytes','The actual immutable reference must retain its declared whole-file byte count.');
        end
    end
end
function r=gpRef(file),r=struct('file',gpLiteral(file),'sha256',RoundSHA256_v3(file));end
function file=gpLiteral(value),file=canonical(value);assert(strcmp(file,canonical(V3Path_v3(value))),'PKGraphPlan:Alias','Hash/native-read paths must name the same literal file.');end
function l=gpLimit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function gpCheck(l),assert(min(l.deadline_unix_seconds-gpUTC(),(l.deadline_monotonic_ns-gpNano())/1e9)>0,'PKGraphPlan:Clock','The original grant/operation clocks expired; retain all actual partial/published files.');end
function t=gpUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=gpNano(),t=double(java.lang.System.nanoTime());end

function value=rfPublic(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=rfPublic(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=rfPublic(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=rfPublic(value{k});end
    end
end
