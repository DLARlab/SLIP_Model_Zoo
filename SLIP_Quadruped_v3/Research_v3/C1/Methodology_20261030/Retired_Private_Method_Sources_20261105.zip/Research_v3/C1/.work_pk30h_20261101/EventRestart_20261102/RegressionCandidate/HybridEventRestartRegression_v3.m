function report=HybridEventRestartRegression_v3(requirePass)
%HYBRIDEVENTRESTARTREGRESSION_V3 Real simulator restart ownership regression.
% The generic model deliberately has no unilateral mechanical constraint.
% Its identity resets consume only the triggered channel, so another guard
% stays enabled through the actual HybridSimulator_v3 restart lifecycle.
    if nargin<1,requirePass=true;end
    validateattributes(requirePass,{'logical'},{'scalar'});
    cases=struct('name',{'simultaneous_two','batched_close_TD','distinct_fast_TD', ...
        'distinct_slow_TD','distinct_slow_LO'}, ...
        'slope',{.01,.01,1,.01,.01},'gap',{0,5e-9,5e-8,5e-8,5e-8}, ...
        'direction',{-1,-1,-1,-1,1},'expected_batches',{1,1,2,2,2});
    rows=cell(numel(cases),1);
    for k=1:numel(cases)
        c=cases(k);tA=1e-6;p=[1;c.slope];tEnd=2e-6;
        config=struct('StateDimension',2,'ParameterDimension',2, ...
            'FlowFunction',@(t,x,q,p)c.direction*p, ...
            'ActiveGuardsFunction',@(t,x,q,p)linearGuards(t,x,q,p,c.direction), ...
            'ResetFunction',@(id,t,x,q,p)x,'TransitionFunction',@consumeGuard);
        system=HybridSystemBase_v3(config);
        x0=-c.direction.*[tA;c.slope*(tA+c.gap)];
        simulator=HybridSimulator_v3(struct('ODEOptions', ...
            odeset('InitialStep',tEnd,'MaxStep',tEnd)));
        [trajectory,result]=simulator.simulate(system,x0,false(2,1),p,[0,tEnd]);
        events=trajectory.event_history;physical=events(~[events.is_stop]);
        ids=[physical.guard_id];times=[physical.time];
        expectedTimes=[tA,tA+c.gap];
        if c.expected_batches==1,expectedTimes=[tA,tA];end
        countOK=numel(physical)==2;orderOK=countOK&&isequal(ids,[1,2]);
        timesOK=countOK&&max(abs(times-expectedTimes))<=2e-10;
        batchOK=numel(trajectory.event_batches)==c.expected_batches;
        noDuplicates=numel(unique(ids))==numel(ids);
        completeRecords=all(arrayfun(@(e)all(isfield(e,{'state_before','state_after', ...
            'mode_before','mode_after','metadata'}))&&isfield(e.metadata,'event_batch_index'),physical));
        allConsumed=all(result.final_mode);
        passed=result.success&&countOK&&orderOK&&timesOK&&batchOK&&noDuplicates&&completeRecords&&allConsumed;
        rows{k}=struct('name',c.name,'slope',c.slope,'gap',c.gap,'direction',c.direction, ...
            'expected_times',expectedTimes,'actual_times',times,'actual_ids',ids, ...
            'physical_count',numel(physical),'physical_batch_count',numel(trajectory.event_batches), ...
            'expected_batch_count',c.expected_batches,'count_OK',countOK,'order_OK',orderOK, ...
            'time_OK',timesOK,'batch_OK',batchOK,'no_duplicates',noDuplicates, ...
            'complete_individual_records',completeRecords,'all_consumed',allConsumed, ...
            'simulation_success',result.success,'termination_reason',result.termination_reason, ...
            'first_step_truncation_requested',true,'passed',passed);
        fprintf('HYBRID_RESTART_CASE %s\n',jsonencode(rows{k}));
    end
    report=struct('schema','hybrid-event-restart-regression-v1','rows',{rows}, ...
        'passed',all(cellfun(@(r)r.passed,rows)), ...
        'scope','Actual simulator resets/restarts; unchanged linear physical guard trajectories, default detector tolerances, large first ODE step.');
    if requirePass
        failed=cellfun(@(r)r.name,rows(~cellfun(@(r)r.passed,rows)),'UniformOutput',false);
        assert(report.passed,'HybridEventRestartRegression_v3:RegressionFailure', ...
            'Missed or incorrectly grouped physical events in: %s',strjoin(failed,', '));
    end
end

function q=consumeGuard(id,q)
    q(id)=true;
end

function guards=linearGuards(~,x,q,~,direction)
    prototype=struct('id',0,'name',"",'value',0,'direction',direction, ...
        'isterminal',true,'enabled',true,'interior_sign',-direction,'kind',"synthetic-contact",'metadata',struct());
    guards=repmat(prototype,0,1);
    for id=find(~q(:)).'
        d=prototype;d.id=id;d.name="linear_"+id;d.value=x(id);
        d.metadata=struct('restart_arming',struct('schema','state-parameter-guard-geometry-v1', ...
            'definition',sprintf('synthetic-linear-coordinate-%d-v1',id), ...
            'state_dependencies',id,'mode_independent',true));
        guards(end+1,1)=d; %#ok<AGROW>
    end
end
