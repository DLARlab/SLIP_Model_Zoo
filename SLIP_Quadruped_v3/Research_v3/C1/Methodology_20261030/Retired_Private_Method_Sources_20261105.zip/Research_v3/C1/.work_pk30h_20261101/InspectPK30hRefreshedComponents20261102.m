function out=InspectPK30hRefreshedComponents20261102()
% Saved graph bookkeeping only. No public orbit reload or scientific gate.
V=V3Root_v3();N=fullfile(V,'Research_v3','C1');A=fullfile(N,'Audits');
refs={struct('file',fullfile(A,'PK30h_20261102_StoredGraph02_Refreshed.mat'),'sha256','9e587c814f2de74984ebbb7ee6c8b9fe0391942a90033036e0796add7d51d35b','bytes',11191164); ...
 struct('file',fullfile(A,'PK30h_20261102_StoredGraph02_External_Closure.json'),'sha256','dcafa75a70e0b24dd4a533ebd0548e416b621578baeb75fba4ca1b44a177070f','bytes',57175); ...
 struct('file',fullfile(A,'PK30h_20261102_StoredGraph01_SavedAudit01_DecisionView.json'),'sha256','166be2da545270bb5095f863bdb6b339ebb09e27b2626aa4cb476cc9ce59174b','bytes',1641471)};
guard(refs);saved=load('-mat',refs{1}.file,'component_plan','plan_digest');p=saved.component_plan;
assert(strcmp(C1ScientificDigest_v3(p),saved.plan_digest)&&p.completed&&p.source_posthash,'PKComponentView:Plan','Use the actual completed saved graph and its complete digest.');clear saved
old=p.original_budget;grant=struct('grant_id',old.grant_id,'start_utc',old.start_utc,'research_deadline_utc',old.research_deadline_utc,'deadline_utc',old.deadline_utc);B=AbsoluteRunBudget_v3(grant,old);
t=clockNow();assert(min(B.research_deadline_unix_seconds-t.utc,(B.research_deadline_monotonic_ns-t.mono)/1e9)>182,'PKComponentView:Grant','The new180/30 saved-data operation must fit the original grant.');finish=struct('utc',t.utc+180,'mono',t.mono+180e9);work=struct('utc',finish.utc-30,'mono',finish.mono-30e9);
closed=jsondecode(fileread(refs{2}.file));assert(strcmp(closed.schema,'PK30h-stored-graph-refresh-external-closure-v1')&&closed.process.actual_tool_exit_observed&&closed.process.exit_code==0&&closed.independent_post_guard.all_passed&&strcmp(closed.graph_reference.sha256,refs{1}.sha256),'PKComponentView:Closed','Require the actual independent graph closure, without a scientific-completion inference.');
prior=jsondecode(fileread(refs{3}.file));assert(prior.audit_completed&&prior.audit_source_posthash,'PKComponentView:Decision','Use the already closed native decision-view endpoint observations.');
count=numel(p.nodes);membership=zeros(count,1);out=struct('schema','PK30h-refreshed-components-saved-view-v1','completed',false,'source_posthash',false,'input_references',{refs},'components',{{}},'registered_frontiers',{{}},'new_scientific_admission_claimed',false,'scientific_completion_claimed',false,'frontier_retirement_authorized',false);
for c=1:numel(p.components),at=p.components{c}.global_indices(:);assert(~any(membership(at)),'PKComponentView:Partition','Every occurrence belongs to exactly one saved component.');membership(at)=c;end
assert(all(membership>0),'PKComponentView:Coverage','Preserve all1107 actual occurrences.');
for c=1:numel(p.components)
 check(work);at=p.components{c}.global_indices(:);states=zeros(14,numel(at));parameters=zeros(10,numel(at));modes=false(4,numel(at));periods=zeros(numel(at),1);energies=periods;meanU=periods;sync=false(numel(at),1);chart=sync;contexts=cell(numel(at),1);sourceRows=cell(0,1);
 for j=1:numel(at)
  n=p.nodes{at(j)};states(:,j)=n.normalized_state(:);parameters(:,j)=n.parameter(:);modes(:,j)=n.initial_mode(:);periods(j)=n.period;
  energies(j)=n.point.nativeE;meanU(j)=n.point.signedmeanU;
  sync(j)=isequal(states([7,9,11,13],j),repmat(states(7,j),4,1))&&isequal(states([8,10,12,14],j),repmat(states(8,j),4,1));
  chart(j)=sync(j)&&all(~modes(:,j))&&all(states([4,5,6],j)==0);
  contexts{j}=metadataContexts(n.point.metadata,'metadata',0);
 end
 for s=unique(cellfun(@(n)n.source_number,p.nodes(at)),'stable').'
  take=at(cellfun(@(n)n.source_number==s,p.nodes(at)));catalogue=p.source_catalog{s};
  sourceRows{end+1,1}=struct('source_reference',struct('file',catalogue.file,'sha256',catalogue.sha256),'global_indices',take,'original_indices',cellfun(@(n)n.source_index,p.nodes(take))); %#ok<AGROW>
 end
 [uniqueP,~,pGroup]=unique(parameters.','rows','stable');[uniqueQ,~,qGroup]=unique(modes.','rows','stable');
 graph=p.components{c}.planned_materialization_index.metadata.component_graph;
 row=struct('component_number',c,'occurrence_count',numel(at),'global_indices',at,'source_rows',{sourceRows},'physical_parameter_sets',uniqueP,'physical_parameter_set_counts',accumarray(pGroup,1),'mode_sets',uniqueQ,'mode_set_counts',accumarray(qGroup,1),'apex_dx_range',rangeOf(states(2,:)),'signed_meanU_range',rangeOf(meanU),'saved_native_energy_range',rangeOf(energies),'apex_height_range',rangeOf(states(3,:)),'period_range',rangeOf(periods),'exact_four_leg_sync_count',sum(sync),'exact_upright_allflight_apex_chart_count',sum(chart),'maximum_leg_angle_spread',max(max(states([7,9,11,13],:),[],1)-min(states([7,9,11,13],:),[],1)),'maximum_leg_rate_spread',max(max(states([8,10,12,14],:),[],1)-min(states([8,10,12,14],:),[],1)),'saved_metadata_context_sets',{uniqueContexts(contexts)},'all_complete_policies_available_from_graph_nodes',false,'policy_scope','Only literal saved point-metadata policy/section/cohort fields are inspected here. Complete original report policies are not reconstructed. Exact complete endpoint policies are copied separately from the prior native endpoint audit.','coordinate_scope','normalized_state has the documented translation coordinate gauge; no other state entry is changed. Exact chart membership uses raw equality and is an observation, not a prerequisite or classification.','typed_relation_counts',struct('P',numel(p.components{c}.planned_materialization_index.edges),'E',size(graph.exact_record_equalities,1),'A',size(graph.qualified_record_aliases,1),'M',size(graph.qualified_numerical_overlaps,1)));
 out.components{c,1}=row;
end
rows=prior.registered_endpoints.rows;if isstruct(rows),rows=num2cell(rows(:));end
for k=1:numel(rows)
 check(work);oldrow=rows{k};request=oldrow.request;pair=request.ordered_pair(:);source=find(cellfun(@(s)strcmp(s.file,request.reference.file)&&strcmp(s.sha256,request.reference.sha256),p.source_catalog));
 assert(isscalar(source),'PKComponentView:SourceSelector','Every old registered source remains a unique literal source reference.');globalPair=zeros(2,1);
 for j=1:2,globalPair(j)=find(cellfun(@(n)n.source_number==source&&n.source_index==pair(j),p.nodes));end
 neighbors=cell(2,1);for j=1:2,neighbors{j}=relations(p.view_index,globalPair(j));end
 out.registered_frontiers{k,1}=struct('literal_request',request,'global_pair',globalPair,'component_pair',membership(globalPair),'native_ids',{{p.nodes{globalPair(1)}.native_ID;p.nodes{globalPair(2)}.native_ID}},'literal_prior_endpoint_headers',{oldrow.full_native_headers},'endpoint_incident_relations',{neighbors},'historical_orientation_against_owned_P',oldrow.historical_orientation_against_owned_P,'new_disposition_or_direction_authorized',false,'scope','Actual retained FILE/SHA/ordered-pair map and typed incident relations; a neighboring edge or component membership alone does not certify outward coverage.');
end
out.occurrence_selector_map=cell(count,1);for j=1:count,out.occurrence_selector_map{j}=selector(p,j);end
[cataloguePairs,catalogueTypes]=allRelations(p);out.typed_relation_catalog=struct('global_pairs',cataloguePairs,'types',{catalogueTypes},'scope','Route steps refer to these literal global typed rows; original selectors and owners are stored once in occurrence_selector_map.');
g=p.view_index.metadata.component_graph;out.numerical_seams=cell(size(g.qualified_numerical_overlaps,1),1);
for k=1:numel(out.numerical_seams),pair=g.qualified_numerical_overlaps(k,:);out.numerical_seams{k}=struct('global_pair',pair,'component_pair',membership(pair),'left',selector(p,pair(1)),'right',selector(p,pair(2)),'literal_retained_evidence',g.numerical_overlap_evidence{k});end
out.route_targets=cell(0,1);for s=1:numel(p.source_catalog),catalogue=p.source_catalog{s};name=catalogue.file;indices=[];label='';if contains(name,'C1_PK_0061_54_55_Phase.mat'),indices=catalogue.stored_points;label='current_LOW_last';elseif contains(name,'C1_PK_0061_56_57_Phase.mat'),indices=catalogue.stored_points;label='current_HIGH_last';elseif endsWith(name,'C1_PK_Component_0072.mat'),indices=[6,130,152];label='original0072_named_heads';elseif endsWith(name,'C1_PK_Component_0170.mat'),indices=[59,63];label='original0170_named_heads';elseif contains(name,'0072')&&contains(lower(name),'low'),indices=catalogue.stored_points;label='grown0072_low_last';end;for j=indices(:).',at=find(cellfun(@(n)n.source_number==s&&n.source_index==j,p.nodes));assert(isscalar(at),'PKComponentView:TargetSelector','Keep exact existing target selectors.');out.route_targets{end+1,1}=struct('label',label,'selector',selector(p,at),'global_index',at,'component',membership(at));end;end
out.finite_typed_routes=cell(numel(out.registered_frontiers),1);for k=1:numel(out.registered_frontiers),entry=out.registered_frontiers{k};routes=cell(0,1);for j=1:2,for target=1:numel(out.route_targets),to=out.route_targets{target}.global_index;routes{end+1,1}=struct('source_endpoint',j,'target_number',target,'route',typedRoute(p,entry.global_pair(j),to),'scientific_outward_coverage_certified',false);end;end;out.finite_typed_routes{k}=routes;check(work);end
out.prior_finite_meeting_route=prior.meeting_typed_route;out.prior_finite_meeting_route_scope='Copied historical qualified route only; no fixed-engine endpoint replay or new closure claim.';
out.node_scope='Saved graph node data only; no original public trajectory/report reload, RootSolver, ODE, map, classifier, replay or gate calls.';
guard(refs);check(work);out.source_posthash=true;out.completed=true;out.projection_digest=C1ScientificDigest_v3(out);check(finish);
file=fullfile(A,'PK30h_20261102_StoredGraph02_ComponentView01.json');stage=[file,'.pending'];assert(~isfile(file)&&~isfolder(file)&&~isfile(stage)&&~isfolder(stage),'PKComponentView:Fresh','Preserve any existing output.');
bytes=unicode2native(jsonencode(out),'UTF-8');fid=fopen(stage,'wb');assert(fid>=0,'PKComponentView:Write','Open only the owned fresh JSON stage.');try,fwrite(fid,bytes,'uint8');fclose(fid);catch failure,fclose(fid);rethrow(failure);end
assert(isequal(uint8(filereadBytes(stage)),uint8(bytes(:))),'PKComponentView:Readback','Read back the exact saved UTF8 bytes.');check(finish);javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath()),'PKComponentView:Publish','Publish only the owned saved stage.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());guard(refs);check(finish);
fprintf('PK30H_COMPONENT_VIEW_RETURN %s\n',jsonencode(struct('completed',true,'components',numel(out.components),'occurrences',count,'output_file',file,'sha256',RoundSHA256_v3(file),'bytes',numel(bytes),'new_admission_claimed',false)));
end
function rows=metadataContexts(value,path,depth)
rows=cell(0,1);if depth>5||~isstruct(value)||~isscalar(value),return;end
names=fieldnames(value);for k=1:numel(names),name=names{k};v=value.(name);at=[path,'.',name];
 if ~isempty(regexpi(name,'policy|section|cohort|multiplicity|event_signature','once'))
  try,digest=C1ScientificDigest_v3(v);encoded=jsonencode(v);if numel(encoded)<=20000,entry=struct('path',at,'status','LITERAL_SAVED_METADATA','digest',digest,'value',v);else,entry=struct('path',at,'status','LARGE_LITERAL_VALUE_DIGEST_ONLY','digest',digest,'class',class(v),'size',size(v));end
  catch,entry=struct('path',at,'status','UNASSESSED_UNSUPPORTED_SAVED_TYPE','class',class(v),'size',size(v));end
  rows{end+1,1}=entry; %#ok<AGROW>
 elseif isstruct(v)&&isscalar(v),rows=[rows;metadataContexts(v,at,depth+1)];end %#ok<AGROW>
end
end
function rows=uniqueContexts(cells)
rows=cell(0,1);digests=cell(0,1);for k=1:numel(cells),for j=1:numel(cells{k}),v=cells{k}{j};key=C1ScientificDigest_v3(v);at=find(strcmp(digests,key),1);if isempty(at),digests{end+1,1}=key;rows{end+1,1}=struct('context',v,'occurrence_count',1);else,rows{at}.occurrence_count=rows{at}.occurrence_count+1;end;end;end
end
function out=relations(ix,index)
out=struct('P',zeros(0,2),'E',zeros(0,2),'A',zeros(0,2),'M',zeros(0,2));for k=1:numel(ix.edges),e=ix.edges{k};if e.from==index||e.to==index,out.P(end+1,:)=[e.from,e.to];end;end
g=ix.metadata.component_graph;names={'exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};types={'E','A','M'};for k=1:3,pairs=g.(names{k});out.(types{k})=pairs(any(pairs==index,2),:);end
end
function r=rangeOf(x),assert(all(isfinite(x(:)))&&~isempty(x),'PKComponentView:Range','Ranges summarize finite literal saved scalars only.');r=[min(x(:)),max(x(:))];end
function guard(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKComponentView:Guard','An exact saved input changed.');end;end
function bytes=filereadBytes(file),fid=fopen(file,'rb');assert(fid>=0,'PKComponentView:Read','Read the owned JSON stage.');bytes=fread(fid,Inf,'*uint8');fclose(fid);end
function t=clockNow(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime()));end
function check(limit),t=clockNow();assert(min(limit.utc-t.utc,(limit.mono-t.mono)/1e9)>0,'PKComponentView:Deadline','The bounded saved-data operation deadline elapsed.');end

function s=selector(p,index)
n=p.nodes{index};c=p.source_catalog{n.source_number};s=struct('file',c.file,'sha256',c.sha256,'source_index',n.source_index,'global_index',index,'native_ID',n.native_ID,'owner',p.view_index.points{index}.component_identity);
end
function out=typedRoute(p,start,finish)
n=numel(p.nodes);[pairs,types]=allRelations(p);
parent=zeros(n,1);via=zeros(n,1);seen=false(n,1);seen(start)=true;queue=zeros(n,1);queue(1)=start;head=1;tail=1;while head<=tail&&~seen(finish),at=queue(head);head=head+1;rows=find(any(pairs==at,2));for row=rows(:).',next=pairs(row,1);if next==at,next=pairs(row,2);end;if ~seen(next),seen(next)=true;parent(next)=at;via(next)=row;tail=tail+1;queue(tail)=next;end;end;end
out=struct('source',selector(p,start),'target',selector(p,finish),'connected',seen(finish),'step_rows',zeros(0,4),'step_columns',{{'typed_relation_catalog_row','traversal_from','traversal_to','P_forward'}},'scope','Finite saved typed path only; P traversal orientation is explicit and no outward coverage, fixed-engine replay, local uniqueness or endpoint claim follows.');if ~seen(finish),return;end;rows=zeros(0,1);nodes=finish;at=finish;while at~=start,rows(end+1,1)=via(at);at=parent(at);nodes(end+1,1)=at;end;rows=flipud(rows);nodes=flipud(nodes);for k=1:numel(rows),row=rows(k);from=nodes(k);to=nodes(k+1);out.step_rows(k,:)=[row,from,to,double(strcmp(types{row},'P')&&isequal(pairs(row,:),[from,to]))];end
end

function [pairs,types]=allRelations(p)
ix=p.view_index;g=ix.metadata.component_graph;pairs=zeros(numel(ix.edges),2);for k=1:numel(ix.edges),e=ix.edges{k};pairs(k,:)=[e.from,e.to];end;types=repmat({'P'},size(pairs,1),1);extra={'exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};labels={'E','A','M'};for k=1:3,r=g.(extra{k});pairs=[pairs;r];types=[types;repmat(labels(k),size(r,1),1)];end
end
