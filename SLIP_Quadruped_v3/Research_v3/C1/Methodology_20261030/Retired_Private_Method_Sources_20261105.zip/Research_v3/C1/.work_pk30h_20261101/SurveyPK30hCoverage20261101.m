function result=SurveyPK30hCoverage20261101(journalRef,sustainedRef,coreRef,budget,options)
%SURVEYPK30HCOVERAGE20261101 One stored-observation Queue audit, no tracing.
% Historical obligations, current physical pairs and sign observations have
% distinct roles. Endpoint-scaled chords are optimistic planning estimates,
% not previous Run step lengths, curve arclength or a completion/cost bound.
    entryUTC=utc();entryMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,600)&&isequal(options.SaveMarginSeconds,60), ...
        'PKSurvey:Options','Use the explicit fresh output and fixed600/60 allowance.');
    assert(budget.capture.pid==feature('getpid'),'PKSurvey:Budget','Recalibrate the unchanged original UTC grant in this process.');
    options.OutputFile=literal(options.OutputFile);
    assert(startsWith(options.OutputFile,[literal(fullfile(N,'Audits')),filesep]) ...
        &&~isfile(options.OutputFile)&&~isfile([options.OutputFile,'.pending.mat']), ...
        'PKSurvey:Output','Use one fresh owned V3 audit and preserve earlier pending custody.');
    finish=limit(min(budget.research_deadline_unix_seconds,entryUTC+600), ...
        min(budget.research_deadline_monotonic_ns,entryMono+600e9));
    code=providers();refs=[{journalRef;sustainedRef;coreRef};code];verifyAll(refs);
    assert(strcmp(coreRef.sha256,'75dbd2012853aadbbec2fcee5b10560abad335b8c6bc383d4e4e43405479d6a9'), ...
        'PKSurvey:Core','Use the unchanged delivered historical Core authority.');
    negative=authority(fullfile(N,'Audits','PK30h_20261101_Overlap_negative_primary.mat'), ...
        'f054271ca3e255f2d65f39a521f430decf432fb8fc26e11becabd631d5686d79');
    positive=authority(fullfile(N,'Audits','PK30h_20261101_Overlap_positive_primary.mat'), ...
        '1d41ac65c49cc78a28bfb345dcfca3e20d3b0a3d459125ce6cc0095c13f8419f');
    refs=[refs;{negative;positive}];verifyAll({negative;positive});
    check(finish);loaded=load(journalRef.file,'journal');j=loaded.journal;
    assert(strcmp(j.schema,'C1-persistent-PK-frontier-ledger-v1')&&iscell(j.frontiers) ...
        &&numel(j.frontiers)==13,'PKSurvey:Journal','Retain exactly the13 literal historical obligations.');
    F=j.frontiers(:);ids=cellfun(@(f)f.id,F,'UniformOutput',false);
    assert(numel(unique(ids))==13,'PKSurvey:IDs','Historical frontier IDs must be unique.');
    Q=cell(13,1);
    for k=1:13
        f=F{k};assert(strcmp(f.component_file,f.source_reference.file),'PKSurvey:Source','Historical source path/ref disagree; do not refresh a SHA.');
        snapshot=rmfield(f,'history');C1ScientificDigest_v3(snapshot);C1ScientificDigest_v3(j.options);
        Q{k}=job(f.id,f.status,f.source_reference,f.source_pair,'historical_frontier_obligation');
        Q{k}.journal_reference=journalRef;Q{k}.journal_row=k;Q{k}.historical_frontier_state=snapshot;
        Q{k}.history_locator=struct('journal_reference',journalRef,'row',k,'field','history','entries',numel(f.history));
        Q{k}.historical_scheduler_policy=j.options;
        Q{k}.historical_policy_scope='Literal old scheduling settings only; never fed to Run options or used to reset/adopt the journal.';
    end
    Q{1}.historical_ledger_status=j.status;Q{1}.historical_original_budget=j.original_budget;
    Q{1}.historical_active_budget=j.active_budget;Q{1}.historical_source_code=j.source_code;
    clear loaded j F
    saved=load(sustainedRef.file,'audit');a=saved.audit;
    assert(strcmp(a.schema,'resident-native-frontier-queue-v1')&&a.completed&&a.source_posthash ...
        &&a.all_requested_jobs_returned&&numel(a.jobs)==3&&isempty(fieldnames(a.failure)), ...
        'PKSurvey:Sustained','Use the externally closed successful three-job sustained generation.');
    current=cell(3,1);signRows=cell(0,1);
    for k=1:3
        check(finish);r=a.jobs{k};assert(r.persistence_completion_confirmed&&r.pending_count==0, ...
            'PKSurvey:Pending','Unknown or pending storage requires reconciliation, not another observation selector.');
        verifyAll({r.output_reference;r.checkpoint_reference});refs=[refs;{r.output_reference;r.checkpoint_reference}]; %#ok<AGROW>
        cp=load(r.checkpoint_reference.file,'summary');s=cp.summary;
        at=find(cellfun(@(q)strcmp(q.id,r.id),a.queue));assert(isscalar(at),'PKSurvey:Job','Each returned job needs one Queue authority.');q=a.queue{at};
        assert(strcmp(s.output_file,r.output_reference.file)&&strcmp(q.output_file,s.output_file) ...
            &&isequaln(s.configuration.source_reference,q.source_reference) ...
            &&isequal(s.configuration.source_indices(:),q.pair(:)) ...
            &&isempty(s.pending_batch)&&isempty(fieldnames(s.pending_admission))&&~s.batch_flush_attempted, ...
            'PKSurvey:Checkpoint','Bind the exact original job and clean committed checkpoint.');
        ix=BranchSolutionFile_v3.index(r.output_reference.file);pair=s.current_pair(:).';
        edge=find(cellfun(@(e)isequal([e.from,e.to],pair),ix.edges));
        assert(isscalar(edge)&&numel(ix.points)==s.final_output_count ...
            &&strcmp(ix.points{pair(1)}.component_identity,s.configuration.component_identity) ...
            &&strcmp(ix.points{pair(2)}.component_identity,s.configuration.component_identity), ...
            'PKSurvey:CurrentPair','The actual current pair is one committed same-owner physical edge.');
        row=job(['current_pair_observation::',r.id],r.status,r.output_reference,pair,'current_committed_pair_observation');
        row.checkpoint_reference=r.checkpoint_reference;row.original_job_id=r.id;
        row.declared_symmetry=s.configuration.symmetry;
        row.returned_persistence_completion_confirmed=r.persistence_completion_confirmed;
        row.checkpoint_provisional_persistence_completion_confirmed=s.persistence_completion_confirmed;
        Q{end+1,1}=row;current{k}=row.id;
        if strcmp(r.id,'PK_file_0005_graph_0001_leaf_000045')
            assert(isequal(q.pair(:).',[151,152])&&strcmp(q.source_reference.sha256, ...
                'f2f62cc9de65cb39cece67a1de60ca058db0be8863b87e229c1440a12e939ec7'), ...
                'PKSurvey:0072','Do not conflate the grown low pair with the high grazing pair.');
            for n=1:numel(ix.edges)
                e=ix.edges{n};u=ix.points{e.from}.signedmeanU;v=ix.points{e.to}.signedmeanU;
                assert(strcmp(ix.points{e.from}.component_identity,e.component_identity) ...
                    &&strcmp(ix.points{e.to}.component_identity,e.component_identity),'PKSurvey:Owner','Index edge ownership differs.');
                if ~isfinite(u)||~isfinite(v),continue;end
                crossing=(u<0&&v>0)||(u>0&&v<0);zero=(u==0||v==0);
                if ~crossing&&~zero,continue;end
                role='committed_meanU_sign_cross_observation';if zero,role='committed_meanU_exact_zero_endpoint_observation';end
                z=job(sprintf('%s::%s::%d_%d',role,r.id,e.from,e.to),role,r.output_reference,[e.from,e.to],role);
                z.index_signed_meanU=[u,v];z.actual_index_edge=e;Q{end+1,1}=z;signRows{end+1,1}=z.id; %#ok<AGROW>
            end
        end
    end
    check(finish);fprintf('PK_SURVEY_BEFORE_CORE_VIEW\n');
    [~,~,~,view]=LoadC1SolutionCore29_v3(coreRef.file,1,coreRef.sha256);
    fprintf('PK_SURVEY_AFTER_CORE_VIEW\n');
    verify(coreRef);plain=load(coreRef.file,'solution_core29','core_digest');c=plain.solution_core29;
    assert(strcmp(C1ScientificDigest_v3(c),plain.core_digest),'PKSurvey:CoreDigest','Independent plain intake must bind the validated complete payload.');
    same(c.solution_matrix,view.solution_matrix);same(c.native_ids,view.native_ids);same(c.graph,view.typed_graph);verify(coreRef);
    planning=corePlan(view,c.parameters,c.modes,negative,positive);clear c plain view
    Q{1}.planning=struct('core_reference',coreRef,'core',planning,'input_references',{refs}, ...
        'historical_obligations',13,'current_pair_observation_ids',{current},'sign_observation_ids',{signRows}, ...
        'old_journal_status_and_budgets_scope','Original journal bytes remain authoritative and unchanged; historical policies never renew the grant.', ...
        'source_code',{code},'core_public_load_calls',1,'core_plain_intake_calls',1, ...
        'core_native_reconstruction_scope','Only public loader requested point1 is independently reconstructed; bulk IDs and other values are historically transported.', ...
        'root_map_classifier_replay_calls',0,'fresh_admission_claimed',false);
    assert(all(cellfun(@(q)~q.execute,Q))&&numel(unique(cellfun(@(q)q.id,Q,'UniformOutput',false)))==numel(Q), ...
        'PKSurvey:NoExecute','Every retained or observation role is distinct and execute=false.');
    C1ScientificDigest_v3(Q);verifyAll(refs);remaining=left(finish);
    assert(remaining>options.SaveMarginSeconds+5,'PKSurvey:WholeFit','Preflight and one Queue share the original600-second clock.');
    o=options;o.MaxWallSeconds=remaining;
    audit=RunC1ContinuationQueue_v3(Q,budget,o);
    assert(audit.completed&&audit.source_posthash&&isempty(audit.jobs)&&numel(audit.inventory)==numel(Q) ...
        &&all(cellfun(@(q)~q.execute,audit.queue)),'PKSurvey:Inventory','Every stored role requires an inventory row and zero executed jobs.');
    same(Q,audit.queue);verifyAll(refs);check(finish);
    observations=cell(3,1);
    for k=1:3
        at=find(cellfun(@(x)strcmp(x.id,current{k}),audit.inventory));assert(isscalar(at),'PKSurvey:Current','Missing native pair observation.');
        qi=find(cellfun(@(q)strcmp(q.id,current{k}),Q));assert(isscalar(qi),'PKSurvey:Current','Missing declared current-pair context.');
        observations{k}=reach(audit.inventory{at},Q{qi}.declared_symmetry);fprintf('PK_SURVEY_LOCAL_SECANT %s\n',jsonencode(observations{k}));
    end
    crossings=cell(numel(signRows),1);
    for k=1:numel(signRows)
        at=find(cellfun(@(x)strcmp(x.id,signRows{k}),audit.inventory));assert(isscalar(at),'PKSurvey:Sign','Missing unique native sign observation.');
        x=audit.inventory{at};u=zeros(1,2);
        for n=1:2
            assert(isfinite(x.rows{n}.period)&&x.rows{n}.period>0,'PKSurvey:Period','A signed mean needs a positive finite literal period.');
            u(n)=x.rows{n}.stride(1)/x.rows{n}.period;
        end
        assert(all(isfinite(u)),'PKSurvey:MeanU','Native meanU must be finite.');
        q=find(cellfun(@(x)strcmp(x.id,signRows{k}),Q));assert(isscalar(q),'PKSurvey:Sign','Missing unique selected sign role.');
        metadataEqual=isequal(u,Q{q}.index_signed_meanU);opposite=(u(1)<0&&u(2)>0)||(u(1)>0&&u(2)<0);zero=any(u==0);
        matchesRole=(strcmp(Q{q}.role,'committed_meanU_sign_cross_observation')&&opposite&&~zero) ...
            ||(strcmp(Q{q}.role,'committed_meanU_exact_zero_endpoint_observation')&&zero);
        assert(metadataEqual&&matchesRole,'PKSurvey:Sign','Native stride/period must verify the exact metadata and selected sign role.');
        crossings{k}=struct('id',signRows{k},'source_reference',x.source_reference,'pair',x.source_pair, ...
            'native_meanU',u,'index_metadata_exact',metadataEqual,'strict_opposite_signs',opposite, ...
            'exact_zero_endpoint',zero,'selected_role_verified',matchesRole, ...
            'scope','Finite same-owner committed edge observation; no PIP or bifurcation classification.');
        fprintf('PK_SURVEY_SIGN_OBSERVATION %s\n',jsonencode(crossings{k}));
    end
    check(finish);result=struct('completed',true,'source_posthash',true,'audit_reference',ref(options.OutputFile), ...
        'historical_obligations',13,'inventory_rows',numel(audit.inventory),'executed_jobs',0, ...
        'all_requested_jobs_returned_scope','Vacuous0==0 for execute=false, not13 root trials.', ...
        'physical_component_count',planning.component_counts(1),'physical_exact_component_count',planning.component_counts(2), ...
        'all_layer_component_count',planning.component_counts(4),'observed_physical_chord_sum',planning.observed_physical_chord_sum, ...
        'optimistic_point_allowances_004_008',planning.optimistic_point_allowances_004_008, ...
        'endpoint_relation',planning.endpoint_relation,'root_map_classifier_replay_calls',0,'own_process_exit_claimed',false);
    fprintf('PK_SURVEY_COVERAGE_RETURN %s\n',jsonencode(result));
end

function p=corePlan(v,parameters,modes,negative,positive)
    s=QuadrupedSchema_v3.shared();rows=[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL];U=v.solution_matrix(rows,:);N=size(U,2);
    names={'physical_edges','record_equalities','qualified_aliases','numerical_seams'};tables=cell(4,1);
    for t=1:4,tables{t}=zeros(numel(v.typed_graph.(names{t})),2);for k=1:size(tables{t},1),e=v.typed_graph.(names{t}){k};tables{t}(k,:)=[e.from,e.to];end,end
    P=tables{1};chords=zeros(size(P,1),1);scales=zeros(4,size(P,1));
    for k=1:size(P,1),a=U(:,P(k,1));b=U(:,P(k,2));scales(:,k)=max([ones(4,1),abs(a),abs(b)],[],2);chords(k)=norm((b-a)./scales(:,k));end
    bins=cell(4,1);counts=zeros(1,4);edges=zeros(0,2);
    for t=1:4,edges=[edges;tables{t}];bins{t}=conncomp(graph(edges(:,1),edges(:,2),[],N));counts(t)=max(bins{t});end %#ok<AGROW>
    screen=false(1,N);defects=zeros(N,5);
    for k=1:N,[screen(k),defects(k,:)]=kinematic(v.solution_matrix(1:14,k),parameters{k},modes{k},s);end
    physicalComponents=cell(counts(1),1);G=graph(P(:,1),P(:,2),[],N);
    for k=1:counts(1)
        nodes=find(bins{1}==k);which=ismember(P(:,1),nodes)&ismember(P(:,2),nodes);total=sum(chords(which));
        physicalComponents{k}=struct('nodes',nodes,'physical_edge_rows',find(which).','owner_values',{unique(cellfun(@(m)m.component_identity,v.point_metadata(nodes),'UniformOutput',false))}, ...
            'is_linear_chain',all(degree(G,nodes)<=2),'observed_chord_sum',total,'optimistic_004_008',ceil(total./[.04,.08]), ...
            'all_endpoints_pass_kinematic_four_coordinate_screen',all(screen(nodes)));
    end
    endpoints=cell(2,1);authorityRefs={negative;positive};
    for k=1:2
        loaded=load(authorityRefs{k}.file,'audit');a=loaded.audit;
        assert(a.completed&&a.source_posthash&&numel(a.source_native_ids)==2,'PKSurvey:Association','Use actual saved association base selectors.');
        id=a.source_native_ids{2};matches=find(strcmp(v.native_ids,id));
        endpoints{k}=struct('association_audit_reference',authorityRefs{k},'original_source_reference',a.source_reference, ...
            'original_source_pair',a.source_pair,'native_id',id,'core_occurrence_matches',matches(:).', ...
            'occurrence_contexts',{v.contexts(matches)},'physical_bins',unique(bins{1}(matches)), ...
            'physical_exact_bins',unique(bins{2}(matches)),'physical_exact_alias_bins',unique(bins{3}(matches)), ...
            'all_layer_bins',unique(bins{4}(matches)));
    end
    relation=struct('status','UNASSESSED_missing_or_nonunique_occurrence','physical_arc_across_nonphysical_links_claimed',false);
    if numel(endpoints{1}.core_occurrence_matches)==1&&numel(endpoints{2}.core_occurrence_matches)==1
        a=endpoints{1}.core_occurrence_matches;b=endpoints{2}.core_occurrence_matches;layer=0;
        for t=1:4,if bins{t}(a)==bins{t}(b),layer=t;break;end,end
        relation.status='disconnected_in_all_saved_layers';relation.minimum_connectivity_layer=layer;
        if layer>0
            edges=vertcat(tables{1:layer});path=shortestpath(graph(edges(:,1),edges(:,2),[],N),a,b);steps=cell(max(0,numel(path)-1),1);total=0;ambiguous=false;
            for k=1:numel(steps)
                pair=path(k:k+1);kinds=cell(0,1);indices=cell(4,1);
                for t=1:4,z=tables{t};indices{t}=find((z(:,1)==pair(1)&z(:,2)==pair(2))|(z(:,1)==pair(2)&z(:,2)==pair(1)));if ~isempty(indices{t}),kinds{end+1,1}=names{t};end,end %#ok<AGROW>
                physicalOnly=numel(kinds)==1&&strcmp(kinds{1},'physical_edges');
                step=struct('from',pair(1),'to',pair(2),'relation_kinds',{kinds},'relation_rows',{indices},'physical_chord_assigned',physicalOnly);
                if physicalOnly,step.physical_chord=chords(indices{1});total=total+step.physical_chord;
                elseif numel(kinds)>1,ambiguous=true;end
                steps{k}=step;
            end
            relation.status='finite_stored_connectivity_path';relation.path=path;relation.steps=steps;
            relation.observed_physical_chord_sum_only=total;relation.ambiguous_parallel_relation_types=ambiguous;
            relation.optimistic_004_008=ceil(total./[.04,.08]);
            relation.scope='Shortest stored-edge-count path, not an orbit metric. Only literal P edges contribute chords; E/A/M receive no physical arc. Parallel relation types remain unresolved.';
        end
    end
    seams=cell(numel(v.typed_graph.numerical_seams),1);
    for k=1:numel(seams)
        e=v.typed_graph.numerical_seams{k};a=U(:,e.from);b=U(:,e.to);scale=max([ones(4,1),abs(a),abs(b)],[],2);
        seams{k}=struct('from',e.from,'to',e.to,'from_native_id',v.native_ids{e.from},'to_native_id',v.native_ids{e.to}, ...
            'from_owner',v.point_metadata{e.from}.component_identity,'to_owner',v.point_metadata{e.to}.component_identity, ...
            'from_context',v.contexts{e.from},'to_context',v.contexts{e.to},'observed_four_coordinate_gap',norm((b-a)./scale), ...
            'evidence_digest',C1ScientificDigest_v3(e.evidence),'physical_arc_assigned',false);
    end
    p=struct('coordinate_order','dx,height,alphaBL,omegaBL','core_occurrences',N,'typed_edge_counts',cellfun(@(x)size(x,1),tables).', ...
        'component_counts',counts,'physical_components',{physicalComponents},'physical_edge_pairs',P, ...
        'endpoint_local_scales',scales,'physical_scaled_chords',chords,'observed_physical_chord_sum',sum(chords), ...
        'optimistic_point_allowances_004_008',ceil(sum(chords)./[.04,.08]),'association_source_bases',{endpoints}, ...
        'endpoint_relation',relation,'numerical_seams',{seams},'kinematic_four_coordinate_screen',screen,'raw_screen_defects',defects, ...
        'four_coordinate_scope','Flight/pronk/apex geometric screen only. Energy pivot, full chart regularity, native all-nine admission and event-time/phase-R8 runnable context remain UNASSESSED.', ...
        'arc_scope','Sum of observed endpoint-scaled physical secants; Run used preceding-pair scales. Not exact past steps or true curve arclength. .04/.08 ceilings are optimistic planning allowances, not completion/cost bounds; .08 is not executed.', ...
        'missing_evidence_scope','Historical Core has no full event histories or detailed saved classifier/primitive. Adopt an actual chosen public Raw03 pair with complete reports/policy/events/t0/IDs before any acquisition.');
end

function out=reach(inventory,declaredSymmetry)
    s=QuadrupedSchema_v3.shared();a=inventory.rows{1};b=inventory.rows{2};idx=[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL];
    ua=a.state(idx);ua=ua(:);ub=b.state(idx);ub=ub(:);
    scale=max([ones(4,1),abs(ua),abs(ub)],[],2);d=(ub-ua)./scale;chord=norm(d);
    assert(all(isfinite([a.period,b.period]))&&a.period>0&&b.period>0,'PKSurvey:Period','Native meanU needs positive finite literal periods.');
    meanU=[a.stride(1)/a.period,b.stride(1)/b.period];assert(all(isfinite(meanU)),'PKSurvey:MeanU','Native meanU must be finite.');
    [sa,da]=kinematic(a.state,a.parameter,a.mode,s);[sb,db]=kinematic(b.state,b.parameter,b.mode,s);
    samePQ=isequaln(a.parameter,b.parameter)&&isequaln(a.mode,b.mode);pronk=strcmp(declaredSymmetry,'pronk');eligible=pronk&&samePQ&&sa&&sb;
    out=struct('id',inventory.id,'pair',inventory.source_pair,'base_native_id',b.native_id,'chord',chord, ...
        'target','initial_apex_dx_zero','base_initial_apex_dx',ub(1),'base_actual_stride_period_meanU',meanU(2),'pair_native_meanU',meanU, ...
        'declared_symmetry',declaredSymmetry,'identical_literal_parameter_and_mode',samePQ, ...
        'kinematic_four_coordinate_screen',[sa,sb],'raw_screen_defects',[da;db],'reach_prerequisites_met',eligible, ...
        'status','UNASSESSED_context_or_kinematic_screen','heading_toward_initial_apex_dx_zero',false, ...
        'straight_tangent_arc_to_initial_apex_dx_zero',[],'optimistic_004_008',[], ...
        'scope','Finite native secant extrapolation toward initial apex dx=0, not meanU=0. Event/energy regularity and runnable phase context remain UNASSESSED; no curve-length bound, reachable root, cost, PIP or bifurcation claim.');
    if isfinite(chord)&&chord>1e-10
        t=d/chord;out.scale=scale;out.tangent=t;
        if eligible
            out.status='not_heading_toward_initial_apex_dx_zero';
            if ub(1)*t(1)<0
                out.status='finite_secant_heading_toward_initial_apex_dx_zero';out.heading_toward_initial_apex_dx_zero=true;
                out.straight_tangent_arc_to_initial_apex_dx_zero=abs(ub(1)/(scale(1)*t(1)));
                out.optimistic_004_008=ceil(out.straight_tangent_arc_to_initial_apex_dx_zero./[.04,.08]);
            end
        end
    elseif eligible,out.status='UNASSESSED_unresolved_native_chord';end
end
function [pass,defects]=kinematic(x,p,q,s)
    x=x(:);p=p(:);q=q(:);idx=s.Parameter;
    defects=[abs(x(s.State.dy)),norm(x([s.State.phi,s.State.dphi]),Inf), ...
        norm(x(s.Leg.AngleIndices)-x(s.State.alphaBL),Inf),norm(x(s.Leg.RateIndices)-x(s.State.dalphaBL),Inf), ...
        norm(p([idx.k_l_b,idx.k_s_b,idx.l_l_b,idx.rsla_b])-p([idx.k_l_f,idx.k_s_f,idx.l_l_f,idx.rsla_f]),Inf)];
    pass=~any(q)&&all(defects(1:4)<=1e-8)&&defects(5)<=1e-12&&abs(p(idx.l_com)-.5)<=1e-12;
end
function q=job(id,status,source,pair,role)
    q=struct('id',id,'historical_status',status,'execute',false,'source_reference',source,'pair',pair(:).', ...
        'output_file','','symmetry','pronk','options',struct(),'role',role,'fresh_admission_claimed',false);
end
function refs=providers()
    names={'SurveyPK30hCoverage20261101','RunC1ContinuationQueue_v3','BranchSolutionFile_v3','LoadC1SolutionCore29_v3', ...
        'EnergyFamilyResidual_v3','QuadrupedSchema_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cell(numel(names),1);for k=1:numel(names),refs{k}=ref(which(names{k}));end
end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKSurvey:Typed','Declared typed values differ.');end
function verifyAll(refs),for k=1:numel(refs),verify(refs{k});end,end
function verify(r),assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKSurvey:Changed','Exact literal authority changed.');end
function r=authority(file,sha),r=struct('file',literal(file),'sha256',sha);end
function r=ref(file),r=authority(file,RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKSurvey:Path','Hash and native read must use the same file.');end
function l=limit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function v=left(l),v=min(l.deadline_unix_seconds-utc(),(l.deadline_monotonic_ns-nano())/1e9);end
function check(l),assert(left(l)>0,'PKSurvey:Clock','The original600/60 planning/inventory window expired.');end
function v=utc(),v=posixtime(datetime('now','TimeZone','UTC'));end
function v=nano(),v=double(java.lang.System.nanoTime());end
