function result=PreparePK30hStoredComponentPlan20261102(B,bindings,options)
%PREPAREPK30HSTOREDCOMPONENTPLAN20261102 Original selectors and stored graph only.
% This NEW projection operation uses the original grant, not either expired
% raw-materialization local allowance. It copies no native orbit/trajectory.
% completed/source_posthash certify GRAPH PLANNING ONLY. Failed raw receipts,
% actual committed-prefix storage facts and all six full M-proof authorities
% remain literal historical evidence, never prospective storage certificates.
    enteredUTC=gpUTC();enteredMono=gpNano();timer=tic;
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)), ...
        sort({'SourceRows';'FailedConsolidationReference';'HistoricalAuthorityReferences'})) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,1800)&&isequal(options.SaveMarginSeconds,60)&&B.capture.pid==feature('getpid'), ...
        'PKGraphPlan:Inputs','Use exact closed inputs and one explicitly authorized new original-grant1800/60 projection allowance.');
    assert(min(B.research_deadline_unix_seconds-enteredUTC,(B.research_deadline_monotonic_ns-enteredMono)/1e9)>1802, ...
        'PKGraphPlan:WholeFit','The complete new1800-second projection must fit the unchanged original science clocks at entry.');
    finish=gpLimit(min(B.research_deadline_unix_seconds,enteredUTC+1800),min(B.research_deadline_monotonic_ns,enteredMono+1800e9));
    budget=gpLimit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);validationLimits=budget;maxWall=1800;
    output=gpLiteral(options.OutputFile);stage=[output,'.pending.mat'];failureFile=[output,'.failure.mat'];N=fullfile(V3Root_v3(),'Research_v3','C1');
    paths={output;stage;failureFile};assert(all(cellfun(@(f)startsWith(f,[gpLiteral(fullfile(N,'Audits')),filesep]) ...
        &&~isfile(f)&&~isfolder(f)&&isfolder(fileparts(f)),paths)), ...
        'PKGraphPlan:Fresh','Use one fresh own plan MAT/stage and preserve any partial failure output.');
    assert(iscell(bindings.SourceRows)&&iscolumn(bindings.SourceRows)&&numel(bindings.SourceRows)==22 ...
        &&iscell(bindings.HistoricalAuthorityReferences)&&iscolumn(bindings.HistoricalAuthorityReferences)&&~isempty(bindings.HistoricalAuthorityReferences), ...
        'PKGraphPlan:Rows','Retain all22 ordered sources and explicit immutable failed-output/full-proof/closure authorities.');
    sourceRefs=cellfun(@(r)r.reference,bindings.SourceRows,'UniformOutput',false);
    sourceFiles=cellfun(@(r)r.file,sourceRefs,'UniformOutput',false);roles=cellfun(@(r)r.role,bindings.SourceRows,'UniformOutput',false);
    assert(numel(unique(sourceFiles))==numel(sourceFiles)&&numel(unique(roles))==numel(roles), ...
        'PKGraphPlan:Unique','Each frozen source path and role occurs exactly once.');
    code=gpProviders();refs=[sourceRefs;{bindings.FailedConsolidationReference};bindings.HistoricalAuthorityReferences;code];gpVerify(refs);checkTime();
    x=load(bindings.FailedConsolidationReference.file,'receipt');priorReceipt=x.receipt;clear x
    assert(strcmp(priorReceipt.schema,'C1-connected-component-consolidation-v1')&&isequal(priorReceipt.completed,false) ...
        &&isequal(priorReceipt.source_public_readback_verified,false)&&isequal(priorReceipt.source_hashes_verified_after_work,false) ...
        &&numel(priorReceipt.source_catalog)==22&&priorReceipt.stored_occurrences==1036 ...
        &&priorReceipt.connected_components==6&&priorReceipt.qualified_numerical_overlaps==6&&numel(priorReceipt.component_files)==5&&priorReceipt.output_files==6 ...
        &&isempty(fieldnames(priorReceipt.isolated_records_file))&&isempty(priorReceipt.requested_qualified_alias_pairs) ...
        &&isempty(priorReceipt.requested_numerical_overlap_pairs), ...
        'PKGraphPlan:ActualFailedScope','Use the actual failed six-component1036-occurrence receipt with five committed prefixes, without promoting its false flags.');
    receiptFile=canonical(priorReceipt.receipt_file);assert(strcmp(receiptFile,bindings.FailedConsolidationReference.file), ...
        'PKGraphPlan:ReceiptLocator','The historical materialization provenance uses its actual closed receipt path.');
    for k=1:numel(sourceRefs)
        c=priorReceipt.source_catalog{k};assert(strcmp(c.file,sourceRefs{k}.file)&&strcmp(c.sha256,sourceRefs{k}.sha256), ...
            'PKGraphPlan:SourceOrder','The exact original source order and frozen generations must match the failed discovery.');
    end
    component_plan=struct('schema','C1-stored-component-graph-plan-v1','completed',false,'source_posthash',false, ...
        'completion_scope','GRAPH PLAN ONLY: original occurrence/owner/provenance and P/E/A/M discovery/index checks; no new raw component materialization or whole-public trajectory readback.', ...
        'bindings',bindings,'source_code',{code},'input_references',{refs},'original_budget',B,'operation_finish',finish,'operation_work',budget, ...
        'source_catalog',{{}},'nodes',{{}},'view_index',struct(),'components',{{}},'occurrence_map',{{}}, ...
        'historical_materialization',struct('reference',bindings.FailedConsolidationReference,'literal_failed_receipt',priorReceipt, ...
        'false_flags_preserved',true,'complete_raw_copy_claimed',false), ...
        'historical_prefix_observations',{{}},'consolidation_id','','source_occurrence_bijection_verified',false, ...
        'new_root_integrations_classifications_replays',0,'new_overlap_qualification_calls',0,'native_payload_copied',false, ...
        'source_retirement_authorized',false,'scientific_completion_claimed',false,'own_process_exit_claimed',false,'failure',struct());
    result=struct('schema','PK30h-stored-graph-plan-operation-v1','completed',false,'source_posthash',false,'plan_reference',struct(), ...
        'stage_save_returned',false,'stage_read2_verified',false,'publication_returned',false,'owned_stage_unlink_returned',false, ...
        'installed_read2_verified',false,'failure',struct(),'component_count',0,'occurrences',0,'own_process_exit_claimed',false);
    requestedAliases=cell(0,1);requestedOverlaps=cell(0,1);packIsolated=false;
    try
    sourceCatalog = cell(numel(sourceFiles), 1);
    nodes = cell(0,1);
    explicitEdges = zeros(0,2);
    offsets = zeros(numel(sourceFiles),1);
    aliasRequests=cell(0,1);overlapRequests=cell(0,1);
    for sourceNumber = 1:numel(sourceFiles)
        checkTime();
        file = sourceFiles{sourceNumber};
        before = dir(file);
        assert(isscalar(before) && ~before.isdir, 'C1Consolidate:Missing', 'Missing source %s.', file);
        hash = RoundSHA256_v3(file);
        index = BranchSolutionFile_v3.index(file);
        offsets(sourceNumber) = numel(nodes);
        sourceCatalog{sourceNumber} = struct('file',file,'sha256',hash, ...
            'bytes',before.bytes,'metadata',index.metadata,'point_metadata', ...
            {cellfun(@(p)p.metadata,index.points,'UniformOutput',false)}, ...
            'original_edges',{index.edges},'stored_points',numel(index.points), ...
            'stored_edges',numel(index.edges),'source_public_readback_verified',false);
        variables = cell(1,2*numel(index.points));metadataKinds=zeros(1,3);
        for k = 1:numel(index.points)
            [~,metadataKind]=normalizedOriginalMetadata(index.points{k}.metadata);
            metadataKinds(metadataKind)=metadataKinds(metadataKind)+1;
            variables{2*k-1}=index.points{k}.solution_variable;
            variables{2*k}=index.points{k}.report_variable;
        end
        if isempty(variables), saved=struct(); else, saved=load(file,variables{:}); end
        for k = 1:numel(index.points)
            checkTime();
            point=index.points{k}; orbit=saved.(point.solution_variable);
            report=saved.(point.report_variable);
            selfCheck=MatchingReturnSection_v3(orbit,orbit,{report,report});
            state=orbit.initial_state(:);
            schema=QuadrupedSchema_v3.shared(); state(schema.TranslationIndex)=0;
            nodes{end+1,1}=struct('source_number',sourceNumber,'source_index',k, ...
                'point',point,'native_ID',OrbitContentIdentity_v3(orbit), ...
                'normalized_state',state,'initial_mode',orbit.initial_mode(:), ...
                'parameter',orbit.parameter(:),'period',orbit.period, ...
                'stride',orbit.stride_displacement(:), ...
                'complete_return_section',selfCheck.compatible); %#ok<AGROW>
        end
        for k=1:numel(index.edges)
            edge=index.edges{k};
            explicitEdges(end+1,:)=[edge.from,edge.to]+offsets(sourceNumber); %#ok<AGROW>
        end
        priorGraph=member(index.metadata,'component_graph',struct());
        priorAliases=member(priorGraph,'qualified_record_aliases',zeros(0,2));
        validateAliasIndices(priorAliases,numel(index.points));
        for k=1:size(priorAliases,1)
            aliasRequests{end+1,1}=struct('left_node',priorAliases(k,1)+offsets(sourceNumber), ...
                'right_node',priorAliases(k,2)+offsets(sourceNumber), ...
                'kind','inherited_qualified_record_alias', ...
                'input_request',struct('source_file',file,'source_sha256',hash,'source_alias_row',k)); %#ok<AGROW>
        end
        priorOverlaps=member(priorGraph,'qualified_numerical_overlaps',zeros(0,2));
        priorOverlapEvidence=member(priorGraph,'numerical_overlap_evidence',cell(0,1));
        validateAliasIndices(priorOverlaps,numel(index.points));
        assert(iscell(priorOverlapEvidence)&&numel(priorOverlapEvidence)==size(priorOverlaps,1), ...
            'C1Consolidate:NumericalOverlaps','Every retained numerical adjacency needs its original compact qualification.');
        for k=1:size(priorOverlaps,1)
            overlapRequests{end+1,1}=struct('left_node',priorOverlaps(k,1)+offsets(sourceNumber), ...
                'right_node',priorOverlaps(k,2)+offsets(sourceNumber),'kind','inherited_qualified_numerical_overlap', ...
                'input_request',struct('source_file',file,'source_sha256',hash,'source_overlap_row',k), ...
                'retained_evidence',priorOverlapEvidence{k}); %#ok<AGROW>
        end
        after=dir(file);
        assert(sameStat(before,after) && strcmp(hash,RoundSHA256_v3(file)), ...
            'C1Consolidate:SourceChanged','The source changed during discovery: %s.',file);
        clear saved orbit report
        fprintf('C1_COMPONENT_SOURCE %d/%d points=%d edges=%d metadataUnmarked=%d metadataDirectEnvelope=%d metadataImportedNonedge=%d\n', ...
            sourceNumber,numel(sourceFiles),numel(index.points),numel(index.edges),metadataKinds(1),metadataKinds(2),metadataKinds(3));
    end
    equalityEdges=zeros(0,2); equalityEvidence=cell(0,1);
    if ~isempty(nodes)
        identifiers=cellfun(@(p)p.native_ID,nodes,'UniformOutput',false);
        [~,~,idGroups]=unique(identifiers);
        for group=1:max(idGroups)
            candidates=find(idGroups==group);
            if numel(candidates)<2,continue;end
            remaining=true(size(candidates));
            for a=1:numel(candidates)
                if ~remaining(a),continue;end
                left=nodes{candidates(a)};
                if ~left.complete_return_section,continue;end
                [leftOrbit,leftReport]=readNode(left);
                for b=a+1:numel(candidates)
                    if ~remaining(b),continue;end
                    right=nodes{candidates(b)};
                    if ~sameNumericalRecord(left,right),continue;end
                    checkTime();
                    [rightOrbit,rightReport]=readNode(right);
                    compatibility=MatchingReturnSection_v3(leftOrbit,rightOrbit,{leftReport,rightReport});
                    if ~compatibility.compatible,continue;end
                    equalityEdges(end+1,:)=[candidates(a),candidates(b)]; %#ok<AGROW>
                    equalityEvidence{end+1,1}=struct('native_ID',left.native_ID, ...
                        'exact_state_mode_parameter_period_stride',true, ...
                        'translation_gauge_normalized',true, ...
                        'matching_return_section',compatibility, ...
                        'new_continuation_edge_created',false); %#ok<AGROW>
                    remaining(b)=false;
                end
            end
        end
    end
    qualifiedAliasEdges=zeros(0,2);qualifiedAliasEvidence=cell(0,1);
    aliasQualificationSource=struct();
    if ~isempty(aliasRequests)
        aliasSource=which('QualifyC1RecordAlias_v3');assert(~isempty(aliasSource),'C1Consolidate:AliasSource','Resolve the original inherited-alias validator.');
        aliasQualificationSource=struct('file',canonical(aliasSource),'sha256',RoundSHA256_v3(aliasSource));
    end
    for k=1:numel(aliasRequests)
        checkTime();request=aliasRequests{k};pair=[request.left_node,request.right_node];
        assert(pair(1)~=pair(2),'C1Consolidate:Aliases','An alias must link distinct stored occurrences.');
        if ismember(sort(pair),sort(qualifiedAliasEdges,2),'rows'),continue;end
        [aliasLeft,aliasLeftReport]=readNode(nodes{pair(1)});
        [aliasRight,aliasRightReport]=readNode(nodes{pair(2)});
        evidence=QualifyC1RecordAlias_v3(aliasLeft,aliasRight,aliasLeftReport,aliasRightReport);
        assert(evidence.qualified,'C1Consolidate:Aliases','The requested alias failed native qualification.');
        evidence.request=request;evidence.qualification_source=aliasQualificationSource;
        qualifiedAliasEdges(end+1,:)=pair;qualifiedAliasEvidence{end+1,1}=evidence; %#ok<AGROW>
    end
    if ~isempty(aliasRequests)
        assert(strcmp(RoundSHA256_v3(aliasQualificationSource.file),aliasQualificationSource.sha256), ...
            'C1Consolidate:AliasSource','The alias qualification source changed.');
    end
    numericalEdges=zeros(0,2);numericalEvidence=cell(0,1);numericalTransports=cell(0,1);numericalQualificationSource=struct();
    qualifierNames=cell(0,1);
    for k=1:numel(overlapRequests)
        request=overlapRequests{k};
        assert(strcmp(request.kind,'inherited_qualified_numerical_overlap'), ...
            'PKGraphPlan:InheritedOnly','No new numerical qualification is requested by a stored graph plan.');
        if isstruct(request.retained_evidence)&&isscalar(request.retained_evidence) ...
                &&isfield(request.retained_evidence,'schema') ...
                &&strcmp(request.retained_evidence.schema,'C1-qualified-finite-numerical-overlap-v1')
            qualifierNames{end+1,1}='C1FiniteNumericalOverlap_v3'; %#ok<AGROW>
        end
    end
    qualifierNames=unique(qualifierNames,'stable');
    for k=1:numel(qualifierNames)
        f=which(qualifierNames{k});assert(~isempty(f),'C1Consolidate:NumericalOverlapSource','The numerical-overlap qualifier must resolve to an existing source.');
        row=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));
        if isempty(fieldnames(numericalQualificationSource)),numericalQualificationSource=row;
        else,numericalQualificationSource(end+1,1)=row;end %#ok<AGROW>
    end
    for k=1:numel(overlapRequests)
        checkTime();request=overlapRequests{k};pair=[request.left_node,request.right_node];
        assert(pair(1)~=pair(2)&&~ismember(sort(pair),sort(numericalEdges,2),'rows'), ...
            'C1Consolidate:NumericalOverlaps','Numerical pairs must be distinct explicitly selected occurrences, without duplicate requests.');
        [left,leftReport]=readNode(nodes{pair(1)});[right,rightReport]=readNode(nodes{pair(2)});
        incoming=find(explicitEdges(:,2)==pair(1));
        assert(isscalar(incoming),'C1Consolidate:NumericalOverlaps', ...
            'The retained C occurrence must keep its one actual physical predecessor.');
        parentIndex=explicitEdges(incoming,1);[parent,~]=readNode(nodes{parentIndex});
        assert(nodes{parentIndex}.source_number==nodes{pair(1)}.source_number ...
            &&strcmp(nodes{parentIndex}.point.component_identity,nodes{pair(1)}.point.component_identity), ...
            'C1Consolidate:NumericalOverlaps','An actual same-owner physical edge, never adjacency, must reach C.');
        % Inherited evidence is validated against literal saved native
        % records, not qualified again and not inferred by the source view.
        evidence=request.retained_evidence;
        validateNumericalEvidence(evidence,left,right,leftReport,rightReport,parent);
        numericalEdges(end+1,:)=pair;numericalEvidence{end+1,1}=evidence; %#ok<AGROW>
        numericalTransports{end+1,1}=struct('kind',request.kind,'input_request',request.input_request, ...
            'left_node',pair(1),'right_node',pair(2),'original_evidence_unchanged',true); %#ok<AGROW>
    end
    if ~isempty(fieldnames(numericalQualificationSource))
        for k=1:numel(numericalQualificationSource)
            assert(strcmp(RoundSHA256_v3(numericalQualificationSource(k).file),numericalQualificationSource(k).sha256), ...
                'C1Consolidate:NumericalOverlapSource','The numerical-overlap qualifier source changed.');
        end
    end
    strictEdges=[explicitEdges;equalityEdges;qualifiedAliasEdges];
    effectiveEdges=[strictEdges;numericalEdges];
    if isempty(nodes), bins=zeros(1,0); else
        bins=conncomp(graph(effectiveEdges(:,1),effectiveEdges(:,2),[],numel(nodes)));
    end
    componentCount=max([0,bins]);
    groupMembers=cell(0,1);groupComponentNumbers=cell(0,1);isIsolatedGroup=false(0,1);
    isolatedNumbers=[];
    for k=1:componentCount
        selected=find(bins==k);
        if packIsolated && numel(selected)==1
            isolatedNumbers(end+1)=k; %#ok<AGROW>
        else
            groupMembers{end+1,1}=selected;groupComponentNumbers{end+1,1}=k; %#ok<AGROW>
            isIsolatedGroup(end+1,1)=false; %#ok<AGROW>
        end
    end
    if ~isempty(isolatedNumbers)
        groupMembers{end+1,1}=find(ismember(bins,isolatedNumbers));
        groupComponentNumbers{end+1,1}=isolatedNumbers;isIsolatedGroup(end+1,1)=true;
    end
    sourceIdentity=strjoin(cellfun(@(s)[s.file,'::',s.sha256],sourceCatalog,'UniformOutput',false),'|');
    if ~isempty(qualifiedAliasEdges),sourceIdentity=[sourceIdentity,'|qualified_aliases=',mat2str(qualifiedAliasEdges)];end
    if ~isempty(numericalEdges)
        contracts=cellfun(@(e)digestText(jsonencode(e)),numericalEvidence,'UniformOutput',false);
        sourceIdentity=[sourceIdentity,'|numerical_adjacencies=',mat2str(numericalEdges),'|proof_contracts=',strjoin(contracts,'|')];
    end
    consolidationID=['C1-components:',digestText(sourceIdentity)];
    assert(strcmp(priorReceipt.consolidation_id,consolidationID)&&priorReceipt.stored_occurrences==numel(nodes) ...
        &&priorReceipt.original_explicit_edges==size(explicitEdges,1)&&priorReceipt.exact_record_equalities==size(equalityEdges,1) ...
        &&priorReceipt.qualified_record_aliases==size(qualifiedAliasEdges,1)&&priorReceipt.qualified_numerical_overlaps==size(numericalEdges,1) ...
        &&priorReceipt.connected_components==componentCount&&numel(groupMembers)==6&&~any(isIsolatedGroup), ...
        'PKGraphPlan:DeterministicGraph','The actual repeated discovery must retain the exact failed graph identity/counts, not infer a replacement.');
    assertPublicEqual(priorReceipt.numerical_overlap_transports,numericalTransports,false,0);
    for k=1:numel(sourceCatalog),assertPublicEqual(priorReceipt.source_catalog{k},sourceCatalog{k},false,0);end
    clear leftOrbit leftReport rightOrbit rightReport aliasLeft aliasLeftReport aliasRight aliasRightReport left right leftReport rightReport parent
    component_plan.consolidation_id=consolidationID;component_plan.source_catalog=sourceCatalog;component_plan.nodes=nodes;
    component_plan.acquisition_scope=struct('original_source_groups',numel(sourceCatalog), ...
        'maximum_records_in_one_source_group',max(cellfun(@(c)c.stored_points,sourceCatalog)), ...
        'discovery_pattern','Whole original source once for discovery, then release all native objects; isolated comparison/retained-evidence reads are separate and no native cache is kept.', ...
        'universal16_record_bound_claimed',false,'process_RSS_measured_by_this_helper',false);

    component_plan.graph_discovery=struct('physical_edges',explicitEdges,'exact_record_equalities',equalityEdges, ...
        'qualified_record_aliases',qualifiedAliasEdges,'qualified_alias_evidence',{qualifiedAliasEvidence}, ...
        'qualified_numerical_overlaps',numericalEdges,'numerical_overlap_evidence',{numericalEvidence}, ...
        'equality_evidence',{equalityEvidence},'effective_edges',effectiveEdges, ...
        'qualified_alias_qualification_source',aliasQualificationSource,'numerical_overlap_qualification_source',numericalQualificationSource, ...
        'numerical_overlap_transports',{numericalTransports});
    if ~isempty(fieldnames(aliasQualificationSource)),refs{end+1,1}=aliasQualificationSource;end
    if ~isempty(fieldnames(numericalQualificationSource)),refs=[refs;num2cell(numericalQualificationSource(:))];end
    oldRows=priorReceipt.component_files;coverage=false(numel(nodes),1);globalPoints=cell(numel(nodes),1);globalOwners=cell(0,1);
    for storageGroup=1:numel(groupMembers)
            checkTime();selected=groupMembers{storageGroup};componentNumbers=groupComponentNumbers{storageGroup};
            componentNumber=componentNumbers(1);catalogue=isIsolatedGroup(storageGroup);
            globalToLocal=zeros(numel(nodes),1);globalToLocal(selected)=1:numel(selected);
            explicitMask=ismember(explicitEdges(:,1),selected)&ismember(explicitEdges(:,2),selected);
            equalityMask=ismember(equalityEdges(:,1),selected)&ismember(equalityEdges(:,2),selected);
            aliasMask=ismember(qualifiedAliasEdges(:,1),selected)&ismember(qualifiedAliasEdges(:,2),selected);
            numericalMask=ismember(numericalEdges(:,1),selected)&ismember(numericalEdges(:,2),selected);
            localNumerical=reshape(globalToLocal(numericalEdges(numericalMask,:)),[],2);
            localExplicit=reshape(globalToLocal(explicitEdges(explicitMask,:)),[],2);
            localEquality=reshape(globalToLocal(equalityEdges(equalityMask,:)),[],2);
            localAlias=reshape(globalToLocal(qualifiedAliasEdges(aliasMask,:)),[],2);
            families=unique(cellfun(@(j)family(j.point.classification),nodes(selected),'UniformOutput',false));
            graphMetadata=struct('schema','C1-connected-component-graph-v1', ...
                'nodes',numel(selected),'original_explicit_edges',localExplicit, ...
                'exact_record_equalities',localEquality, ...
                'qualified_record_aliases',localAlias, ...
                'qualified_alias_evidence',{qualifiedAliasEvidence(aliasMask)}, ...
                'qualified_numerical_overlaps',localNumerical, ...
                'numerical_overlap_evidence',{numericalEvidence(numericalMask)}, ...
                'effective_edges',[localExplicit;localEquality;localAlias;localNumerical], ...
                'strict_trace_scope','Only physical index edges plus exact/state-identical storage aliases; numerical adjacency does not merge strict traces.', ...
                'numerical_storage_scope','Numerical adjacency connects distinct retained occurrences only under its immutable qualified evidence.', ...
                'numerical_adjacencies_are_identity_quotients',false,'numerical_adjacencies_are_physical_edges',false, ...
                'equality_evidence',{equalityEvidence(equalityMask)}, ...
                'connected',~catalogue||numel(selected)==1, ...
                'isolated_record_catalogue',catalogue,'equality_links_are_continuation_edges',false, ...
                'qualified_aliases_are_exact_record_equalities',false, ...
                'qualified_aliases_are_continuation_edges',false);
            metadata=struct('schema','C1-consolidated-component-v1', ...
                'consolidation_id',consolidationID,'component_number',componentNumber, ...
                'original_connected_component_numbers',componentNumbers, ...
                'families',{families},'source_catalog_file',receiptFile, ...
                'source_catalog_entries',unique(cellfun(@(p)p.source_number,nodes(selected))), ...
                'component_graph',graphMetadata,'source_owner_map',{cell(0,1)}, ...
                'scientific_flags_upgraded',false);
            branch_index=struct('storage_version','BranchSolutionFile_v3:2', ...
                'metadata',metadata,'points',{cell(numel(selected),1)},'edges',{cell(size(localExplicit,1),1)});
            for localIndex=1:numel(selected)
                globalIndex=selected(localIndex);node=nodes{globalIndex};originalMetadata=node.point.metadata;
                firstMetadata=normalizedOriginalMetadata(originalMetadata);
                source=sourceCatalog{node.source_number};
                owner=sprintf('source-%06d::%s',node.source_number,char(node.point.component_identity));
                ownerRow=struct('source_number',node.source_number, ...
                    'source_component_identity',char(node.point.component_identity), ...
                    'output_component_identity',owner);
                ownerKey=cellfun(@(r)r.output_component_identity, ...
                    branch_index.metadata.source_owner_map,'UniformOutput',false);
                if ~ismember(owner,ownerKey)
                    branch_index.metadata.source_owner_map{end+1,1}=ownerRow;
                end
                pointMetadata=struct('component_identity',owner, ...
                    'classification',char(node.point.classification), ...
                    'nativeE',node.point.nativeE,'signedmeanU',node.point.signedmeanU, ...
                    'order',localIndex,'consolidation_point_schema','C1-consolidated-occurrence-v1', ...
                    'provenance',struct('source_file',source.file,'source_sha256',source.sha256, ...
                    'source_index',node.source_index,'source_catalog_file',receiptFile, ...
                    'source_catalog_entry',node.source_number,'original_point_metadata',firstMetadata, ...
                    'qualification_flags_changed',false));
                incoming=find(localExplicit(:,2)==localIndex);
                assert(numel(incoming)<=1,'C1Consolidate:Incoming','Original occurrence has multiple incoming edges.');
                if ~isempty(incoming)
                    pointMetadata.edge_enabled=true;pointMetadata.edge_from=localExplicit(incoming,1);
                end
                solutionName=sprintf('solution_%06d',localIndex);reportName=sprintf('report_%06d',localIndex);
                branch_index.points{localIndex}=struct('index',localIndex, ...
                    'component_identity',owner,'order',localIndex, ...
                    'classification',pointMetadata.classification,'nativeE',pointMetadata.nativeE, ...
                    'signedmeanU',pointMetadata.signedmeanU,'provenance',pointMetadata.provenance, ...
                    'metadata',pointMetadata,'solution_variable',solutionName, ...
                    'report_variable',reportName,'whole_public_data_readback_verified',false);
            end
            for k=1:size(localExplicit,1)
                branch_index.edges{k}=struct('from',localExplicit(k,1),'to',localExplicit(k,2), ...
                    'component_identity',branch_index.points{localExplicit(k,2)}.component_identity);
            end
            assertConnected(graphMetadata,numel(selected));
            assert(~any(coverage(selected)),'PKGraphPlan:Bijection','A component may not duplicate original selectors.');coverage(selected)=true;
            component_plan.components{storageGroup,1}=struct('component_number',componentNumber,'global_indices',selected(:), ...
                'planned_materialization_index',branch_index,'planned_index_digest',C1ScientificDigest_v3(branch_index), ...
                'materialization_completed_by_this_operation',false);
            for localIndex=1:numel(selected)
                globalIndex=selected(localIndex);p=branch_index.points{localIndex};
                p.index=globalIndex;p.order=globalIndex;p.metadata.order=globalIndex;
                p.solution_variable=sprintf('solution_%06d',globalIndex);p.report_variable=sprintf('report_%06d',globalIndex);
                if isfield(p.metadata,'edge_from'),p.metadata.edge_from=selected(p.metadata.edge_from);end
                globalPoints{globalIndex}=p;node=nodes{globalIndex};c=sourceCatalog{node.source_number};
                component_plan.occurrence_map{globalIndex,1}=struct('source_file',c.file,'source_sha256',c.sha256, ...
                    'source_index',node.source_index,'global_index',globalIndex,'component_number',componentNumber,'component_index',localIndex);
            end
            for ownerNumber=1:numel(branch_index.metadata.source_owner_map)
                ownerRow=branch_index.metadata.source_owner_map{ownerNumber};ownerKeys=cellfun(@(r)r.output_component_identity,globalOwners,'UniformOutput',false);
                previousOwner=find(strcmp(ownerKeys,ownerRow.output_component_identity));
                if isempty(previousOwner),globalOwners{end+1,1}=ownerRow;
                else,assert(isscalar(previousOwner),'PKGraphPlan:OwnerMap','An original owner has one explicit global bookkeeping row.');assertPublicEqual(globalOwners{previousOwner},ownerRow,false,0);end
            end
            if storageGroup<=numel(oldRows)
                actualRow=oldRows{storageGroup};actualRef=struct('file',actualRow.file,'sha256',actualRow.sha256);gpVerify({actualRef});
                expectedFile=fullfile(priorReceipt.output_directory,sprintf('C1_%s_Component_%04d.mat',gpFamilyTag(families),componentNumber));
                assert(strcmp(actualRow.file,expectedFile)&&actualRow.component_index==componentNumber&&actualRow.points==numel(selected) ...
                    &&isequal(actualRow.whole_public_data_readback_verified,true), ...
                    'PKGraphPlan:PrefixIdentity','Each prefix is the exact original committed component row, with its historical flags retained.');
                actualIndex=BranchSolutionFile_v3.index(actualRow.file);originalDigest=C1ScientificDigest_v3(actualIndex);
                historicalFlags=cellfun(@(p)p.whole_public_data_readback_verified,actualIndex.points);
                assert(all(historicalFlags),'PKGraphPlan:PrefixFlags','The literal historical public point-readback flags must be recorded as observed.');
                for pointNumber=1:numel(actualIndex.points),actualIndex.points{pointNumber}.whole_public_data_readback_verified=false;end
                assertPublicEqual(branch_index,actualIndex,false,0);
                assertPublicEqual(actualRow.families,families,false,0);
                assert(actualRow.explicit_edges==size(localExplicit,1)&&actualRow.equality_links==size(localEquality,1) ...
                    &&actualRow.qualified_aliases==size(localAlias,1)&&actualRow.qualified_numerical_overlaps==size(localNumerical,1), ...
                    'PKGraphPlan:PrefixRelations','Full original prefix graph kinds/counts and owners/provenance must match the planned component.');
                component_plan.historical_prefix_observations{storageGroup,1}=struct('reference',actualRef,'literal_actual_row',actualRow, ...
                    'actual_index_digest',originalDigest,'literal_actual_point_readback_flags',historicalFlags, ...
                    'planned_index_digest',C1ScientificDigest_v3(branch_index),'full_index_equal_after_only_storage_flag_exception',true, ...
                    'comparison_exception','Only each point.whole_public_data_readback_verified is changed TRUE to FALSE on a copied actual index for comparison. Actual raw/public readbacks are historical; no new full data readback is claimed.');
                refs{end+1,1}=actualRef;gpVerify({actualRef});clear actualIndex
            end
            fprintf('C1_STORED_GRAPH_PLAN_COMPONENT %d/%d points=%d P=%d E=%d A=%d M=%d\n',storageGroup,numel(groupMembers), ...
                numel(selected),size(localExplicit,1),size(localEquality,1),size(localAlias,1),size(localNumerical,1));
    end
    assert(all(coverage)&&numel(component_plan.occurrence_map)==numel(nodes),'PKGraphPlan:AllOccurrences','All original1036 selectors must appear exactly once, including all original seven stores.');
    graphMetadata=struct('schema','C1-connected-component-graph-v1','nodes',numel(nodes),'original_explicit_edges',explicitEdges, ...
        'exact_record_equalities',equalityEdges,'qualified_record_aliases',qualifiedAliasEdges,'qualified_alias_evidence',{qualifiedAliasEvidence}, ...
        'qualified_numerical_overlaps',numericalEdges,'numerical_overlap_evidence',{numericalEvidence},'effective_edges',effectiveEdges, ...
        'strict_trace_scope','Only physical index edges plus exact/state-identical storage aliases; numerical adjacency does not merge strict traces.', ...
        'numerical_storage_scope','Numerical adjacency connects distinct retained occurrences only under its immutable qualified evidence.', ...
        'numerical_adjacencies_are_identity_quotients',false,'numerical_adjacencies_are_physical_edges',false,'equality_evidence',{equalityEvidence}, ...
        'connected',componentCount==1,'isolated_record_catalogue',false,'equality_links_are_continuation_edges',false, ...
        'qualified_aliases_are_exact_record_equalities',false,'qualified_aliases_are_continuation_edges',false);
    metadata=struct('schema','C1-consolidated-component-v1','consolidation_id',consolidationID,'component_number',0, ...
        'original_connected_component_numbers',1:componentCount,'families',{unique(cellfun(@(n)family(n.point.classification),nodes,'UniformOutput',false))}, ...
        'source_catalog_file',receiptFile,'source_catalog_entries',1:numel(sourceCatalog),'component_graph',graphMetadata, ...
        'source_owner_map',{globalOwners},'scientific_flags_upgraded',false);
    globalEdges=cell(size(explicitEdges,1),1);
    for k=1:size(explicitEdges,1),globalEdges{k}=struct('from',explicitEdges(k,1),'to',explicitEdges(k,2),'component_identity',globalPoints{explicitEdges(k,2)}.component_identity);end
    component_plan.view_index=struct('storage_version','BranchSolutionFile_v3:2','metadata',metadata,'points',{globalPoints},'edges',{globalEdges});
    component_plan.global_index_scope='Virtual global selectors/order/physical parents. Each planned_materialization_index retains literal Conso local order and provenance. Core preserves selected global point.order; only physical edge_from is mapped by its existing entry transport.';
    component_plan.source_occurrence_bijection_verified=true;component_plan.input_references=refs;
    gpVerify(refs);checkTime();component_plan.source_posthash=true;component_plan.completed=true;component_plan.completed_utc=stamp();
    component_plan.wall_seconds=(gpNano()-enteredMono)/1e9;
    plan_digest=C1ScientificDigest_v3(component_plan); %#ok<NASGU>
    save(stage,'component_plan','plan_digest','-v7');result.stage_save_returned=true;
    gpRead2(stage,component_plan);result.stage_read2_verified=true;gpVerify(refs);gpCheck(finish);
    stageHash=RoundSHA256_v3(stage);assert(~isfile(output)&&strcmp(stageHash,RoundSHA256_v3(stage)), ...
        'PKGraphPlan:Publication','Publish only the unchanged own stage to the still-fresh final path.');
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());result.publication_returned=true;
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath()), ...
        'PKGraphPlan:Link','Final publication must identify the exact own stage.');
    assert(strcmp(RoundSHA256_v3(output),stageHash)&&strcmp(RoundSHA256_v3(stage),stageHash), ...
        'PKGraphPlan:PublicationHash','Keep actual outputs if either linked path changes; never remove an uncertain stage.');
    javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());result.owned_stage_unlink_returned=true;
    gpRead2(output,component_plan);result.installed_read2_verified=true;gpVerify(refs);gpCheck(finish);
    result.plan_reference=struct('file',output,'sha256',RoundSHA256_v3(output));gpCheck(finish);result.completed=true;result.source_posthash=true;
    result.component_count=numel(component_plan.components);result.occurrences=numel(nodes);
    catch problem
        result.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);
        component_plan.completed=false;component_plan.failure=result.failure;
        % Keep an already-published plan or linked/uncertain stage unchanged.
        % The separate fresh failure MAT contains actual operation flags and
        % the small plain planning progress; no rollback or retry occurs.
        if ~isfile(failureFile)
            plan_digest=C1ScientificDigest_v3(component_plan);operation_result=result; %#ok<NASGU>
            save(failureFile,'component_plan','plan_digest','operation_result','-v7');
        end
    end
    result.elapsed_seconds=(gpNano()-enteredMono)/1e9;
    result.scope='GRAPH PLAN ONLY; actual process exit/custody, six Core exports, raw source retirement, scientific coverage and frontier closure remain external and unclaimed.';
    try,fprintf('C1_STORED_GRAPH_PLAN_ACTUAL_RETURN %s\n',jsonencode(result));catch,end

    function checkTime()
        assert(toc(timer)<maxWall && posixtime(datetime('now','TimeZone','UTC'))<budget.deadline_unix_seconds && ...
            double(java.lang.System.nanoTime)<budget.deadline_monotonic_ns, ...
            'C1Consolidate:Budget','Shared final deadline or operation wall limit reached.');
    end
    function [orbit,report,pointMetadata]=readNode(selectedNode)
        nodeSource=sourceCatalog{selectedNode.source_number};
        % Discovery and final full-byte guards bind all isolated reads. No
        % writer may mutate a source during this single-writer transaction.
        nodePoint=selectedNode.point;
        nodeSaved=load(nodeSource.file,nodePoint.solution_variable,nodePoint.report_variable);
        orbit=nodeSaved.(nodePoint.solution_variable);report=nodeSaved.(nodePoint.report_variable);pointMetadata=nodePoint.metadata;
        assert(strcmp(OrbitContentIdentity_v3(orbit),selectedNode.native_ID), ...
            'C1Consolidate:SourceChanged','The numerical record changed during isolated loading.');
    end
end

function [original,kind]=normalizedOriginalMetadata(metadata)
% One-level flatten only for a direct known envelope. A Run import retains
% its ENTIRE immediate metadata; no provenance crawl or scientific edit.
assert(isstruct(metadata)&&isscalar(metadata),'C1Consolidate:PointMetadata', ...
    'Every immediate point metadata record must be one scalar struct.');
original=metadata;kind=1;
if ~isfield(metadata,'consolidation_point_schema'),return;end
assert(isequal(metadata.consolidation_point_schema,'C1-consolidated-occurrence-v1') ...
    &&isfield(metadata,'provenance')&&isstruct(metadata.provenance)&&isscalar(metadata.provenance), ...
    'C1Consolidate:MarkedMetadata','A marked point needs the exact known schema and scalar provenance.');
p=metadata.provenance;
pathText=@(x)ischar(x)&&isrow(x)&&~isempty(x);
positiveIndex=@(x)isnumeric(x)&&isreal(x)&&isscalar(x)&&isfinite(x)&&x>=1&&x==fix(x);
direct={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
imported={'kind','source_file','source_index','original_provenance'};
if isequal(sort(fieldnames(p)),sort(direct(:)))
    assert(pathText(p.source_file)&&pathText(p.source_catalog_file)&&positiveIndex(p.source_index)&&positiveIndex(p.source_catalog_entry) ...
        &&ischar(p.source_sha256)&&isrow(p.source_sha256)&&~isempty(regexp(p.source_sha256,'^[0-9a-f]{64}$','once')) ...
        &&isstruct(p.original_point_metadata)&&isscalar(p.original_point_metadata)&&isequal(p.qualification_flags_changed,false), ...
        'C1Consolidate:DirectMetadata','The direct consolidation envelope is malformed; retain it and refuse.');
    original=p.original_point_metadata;kind=2;
elseif isequal(sort(fieldnames(p)),sort(imported(:)))
    assert(isequal(p.kind,'imported nonedge initial pair')&&pathText(p.source_file)&&positiveIndex(p.source_index) ...
        &&isstruct(p.original_provenance)&&isscalar(p.original_provenance)&&isfield(metadata,'edge_enabled') ...
        &&isequal(metadata.edge_enabled,false)&&~isfield(metadata,'edge_from'), ...
        'C1Consolidate:ImportedMetadata','Only the exact Run imported-NONEDGE wrapper may preserve its entire immediate metadata.');
    kind=3;
else
    error('C1Consolidate:MarkedMetadata','Unknown marked provenance shape; no generic fallback or recursive flatten is permitted.');
end
end

function validateAliasPoint(value,n)
assert(isnumeric(value)&&isreal(value)&&isscalar(value)&&isfinite(value) ...
    &&value==fix(value)&&value>=1&&value<=n,'C1Consolidate:Aliases', ...
    'Each alias selector needs one bounded positive integer occurrence index.');
end
function validateAliasIndices(pairs,n)
assert(isnumeric(pairs)&&isreal(pairs)&&ismatrix(pairs)&&size(pairs,2)==2 ...
    &&all(isfinite(pairs(:)))&&all(pairs(:)==fix(pairs(:)))&&all(pairs(:)>=1)&&all(pairs(:)<=n), ...
    'C1Consolidate:Aliases','Alias links require bounded positive integer occurrence indices.');
end
function tf=sameNumericalRecord(a,b)
tf=a.complete_return_section && b.complete_return_section && strcmp(a.native_ID,b.native_ID) && ...
    isequaln(a.normalized_state,b.normalized_state) && isequaln(a.initial_mode,b.initial_mode) && ...
    isequaln(a.parameter,b.parameter) && isequaln(a.period,b.period) && isequaln(a.stride,b.stride);
end
function assertConnected(metadata,n)
edges=metadata.effective_edges;bins=conncomp(graph(edges(:,1),edges(:,2),[],n));
assert(n>0 && max(bins)==1,'C1Consolidate:Disconnected','Output must contain one effective connected component.');
end
function output=bounds(nodes,indices,field)
values=cellfun(@(n)n.point.(field),nodes(indices));values=values(isfinite(values));
output=[];if ~isempty(values),output=[min(values),max(values)];end
end
function out=member(value,key,fallback)
out=fallback;if isstruct(value)&&isscalar(value)&&isfield(value,key),out=value.(key);end
end
function out=family(label)
match=regexp(char(label),'^(PK|BG|BE|FG|FE|HG|HE|GG|GE)[0-9]*$','tokens','once');
out='OTHER';if ~isempty(match),out=match{1};end
end
function path=canonical(value)
assert((ischar(value)&&isrow(value)&&~isempty(value))||(isstring(value)&&isscalar(value)&&strlength(value)>0), ...
    'C1Consolidate:Path','Expected scalar nonempty path text.');
path=char(java.io.File(char(value)).getCanonicalPath());
end
function tf=sameStat(a,b)
tf=isscalar(b)&&~b.isdir&&isequal(a.bytes,b.bytes)&&isequal(a.datenum,b.datenum);
end
function output=digestText(value)
digest=java.security.MessageDigest.getInstance('SHA-256');digest.update(unicode2native(value,'UTF-8'));
output=lower(reshape(dec2hex(typecast(digest.digest(),'uint8'),2).',1,[]));
end
function output=stamp()
output=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
end
function assertPublicEqual(original,saved,allowNative,depth)
% Byte-identical built-in serialization of a plain subtree is stronger than
% numerical isequaln: it preserves nested classes/shapes, sparse/complex
% storage, field order and NaN payloads. Different serialization falls back
% to the original recursive public-data comparison. Native handles always
% use that original recursive path. BranchSolutionFile's independent reader
% also validates every report/metadata subtree as plain data.
if ~allowNative && (isstruct(original)||iscell(original))
    try
        leftBytes=getByteStreamFromArray(original);rightBytes=getByteStreamFromArray(saved);
        if strcmp(class(original),class(saved))&&isequal(size(original),size(saved)) ...
                &&isequal(leftBytes,rightBytes),return;end
    catch
        % Serialization is only an optional equality accelerator.
    end
end
assert(depth<=128&&strcmp(class(original),class(saved))&&isequal(size(original),size(saved)), ...
    'C1Consolidate:Readback','Readback class, shape or nesting differs.');
if isnumeric(original)||islogical(original)
    assert(issparse(original)==issparse(saved)&&isreal(original)==isreal(saved)&&isequaln(original,saved), ...
        'C1Consolidate:Readback','Readback values or storage type differ.');
elseif ischar(original)||isstring(original)
    assert(isequaln(original,saved),'C1Consolidate:Readback','Readback text differs.');
elseif iscell(original)
    for k=1:numel(original),assertPublicEqual(original{k},saved{k},allowNative,depth+1);end
elseif isstruct(original)
    names=fieldnames(original);assert(isequal(names,fieldnames(saved)),'C1Consolidate:Readback','Struct fields differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),allowNative,depth+1);end;end
else
    assert(allowNative&&any(strcmp(class(original),{'HybridOrbit_v3','Trajectory_v3'})), ...
        'C1Consolidate:Readback','Unsupported public object class.');
    names=sort(properties(original));assert(isequal(names,sort(properties(saved))), ...
        'C1Consolidate:Readback','Public properties differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),true,depth+1);end;end
end
end


function validateNumericalEvidence(e,left,right,leftReport,rightReport,parent)
if isstruct(e)&&isscalar(e)&&isfield(e,'schema') ...
        &&strcmp(e.schema,'C1-qualified-finite-numerical-overlap-v1')
    C1FiniteNumericalOverlap_v3.validateRetained(e,left,right,leftReport,rightReport,parent);
    return
end
% Bind compact immutable qualification to actual retained public records.
% Native IDs were computed at full qualification. Comparing every literal
% identity-bearing field (including raw x) is stronger than that normalized
% ID binding; no unguarded identity helper or historical raw reload occurs.
assert(isstruct(e)&&isscalar(e)&&strcmp(e.schema,'C1-qualified-PK-numerical-overlap-v1') ...
    &&isequal(e.qualified,true)&&isequal(e.full_native_proof_validated,true) ...
    &&strcmp(e.proof_identity,'43b7037ec366d628018b40205545194a17f5291c45c3775ef4ddec290900d43c') ...
    &&strcmp(e.audit_reference.sha256,e.proof_identity)&&isequal(e.all_source_references_posthash_verified,true) ...
    &&isequal(e.identity_claimed,false)&&isequal(e.quotient_identification,false) ...
    &&isequal(e.new_continuation_edge_created,false)&&isequal(e.classification_or_admission_flags_changed,false) ...
    &&isequal(e.original_orbits_reports_and_native_IDs_retained,true), ...
    'C1NumericalAdjacency:Evidence','A retained numerical adjacency needs its distinct complete immutable qualification contract.');
for key={'left_native_ID','right_native_ID'}
    assert(~isempty(regexp(e.(key{1}),'^native-orbit-record:sha256:[0-9a-f]{64}$','once')), ...
        'C1NumericalAdjacency:Identity','A qualifier-produced native record identity is required.');
end
assert(isequaln(e.left_record,overlapRecord(left))&&isequaln(e.right_record,overlapRecord(right)), ...
    'C1NumericalAdjacency:Identity','The actual public endpoints must exactly retain all original identity-bearing fields.');
assert(isequaln(e.left_admission,overlapAdmission(leftReport)) ...
    &&isequaln(e.right_admission,overlapAdmission(rightReport)), ...
    'C1NumericalAdjacency:Admission','Current saved admission/classification/policy facts differ from original qualification.');
assert(isequaln(e.earned_physical_edge.from_record,overlapRecord(parent)) ...
    &&e.earned_physical_edge.from==2&&e.earned_physical_edge.to==3 ...
    &&e.earned_physical_edge.actual_new_points==1&&e.earned_physical_edge.actual_new_edges==1, ...
    'C1NumericalAdjacency:PhysicalEdge','The actual retained predecessor must bind the earned A2-to-C3 physical edge.');
assert(strcmp(e.execution_witness.schema,'C1-external-GateB-process-exit-witness-v1') ...
    &&e.execution_witness.process_session_id==39141&&e.execution_witness.actual_process_exit_observed ...
    &&e.execution_witness.exit_code==0&&strcmp(e.execution_witness.run_name,'GateBOwned01') ...
    &&strcmp(e.execution_witness.audit_reference.sha256,e.proof_identity), ...
    'C1NumericalAdjacency:Execution','External actual process closure remains distinct from stored audit completion.');
actual=overlapComparison(left,right,leftReport,rightReport);
assert(isequaln(actual,e.comparison)&&actual.conditions_met,'C1NumericalAdjacency:Comparison', ...
    'Every actual finite comparison must still match the original fixed contract; closeness alone creates no link.');
for side={'left_original_fines','right_original_fines'}
    rows=e.(side{1});assert(iscell(rows)&&numel(rows)==2,'C1NumericalAdjacency:Fines','Retained adjacency requires two original-state fine controls per endpoint.');
    for k=1:2
        f=rows{k};steps=[.0005,.00025];
        assert(f.MaxStep==steps(k)&&isequal(f.passed,true)&&isequal(f.initial_trajectory_row_exact,true) ...
            &&f.full13_norm<=1e-8&&f.matching_saved_section.compatible ...
            &&f.primitive.cover_count==1&&strcmp(f.primitive.status,'primitive_within_checked_bound') ...
            &&f.saved_period_scaled_error<=1e-8&&f.saved_stride_scaled_error<=1e-8 ...
            &&f.observation.invoked&&f.observation.returned&&f.observation.return_timely ...
            &&f.raw_custody.storage_completed&&f.raw_custody.storage_timely ...
            &&f.raw_custody.readback_completed&&f.raw_custody.readback_timely, ...
            'C1NumericalAdjacency:Fines','Literal original-state fine/timing facts cannot be inferred or upgraded.');
    end
end
end
function out=overlapRecord(o)
out=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter, ...
    'period',o.period,'stride_displacement',o.stride_displacement,'return_policy_name',o.return_policy_name);
end
function out=overlapAdmission(r)
names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations', ...
    'family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
for k=1:numel(names),assert(isequal(r.acceptance_gates.(names{k}),true),'C1NumericalAdjacency:Admission','The retained endpoint must preserve literal accepted all-nine admission.');end
status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true), ...
    'C1NumericalAdjacency:Admission','A retained endpoint must have literal accepted native status.');g=r.classification;
assert(strcmp(member(g,'contract_version',''),'quadruped-gait-v3.5')&&strcmp(member(g,'validated_gait_type',''),'PK') ...
    &&strcmp(member(g,'canonical_point_label',''),'PK')&&isequal(member(g,'canonical_label_qualified',false),true) ...
    &&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1), ...
    'C1NumericalAdjacency:PK','Both actual saved endpoints must retain qualified current PK1.');
[policy,p]=RecordedReturnPolicy_v3(r);assert(p.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3') ...
    &&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1NumericalAdjacency:Policy','The retained endpoint must preserve its complete actual BL1 mode-closed policy.');
out=struct('all_nine_literal_true',true,'accepted',true,'stored_status',status,'classification',g, ...
    'policy_configuration',p.configuration,'original_flags_changed',false);
end
function out=overlapComparison(a,b,ra,rb)
dx=a.initial_state(2:14)-b.initial_state(2:14);sx=max([ones(13,1),abs(a.initial_state(2:14)),abs(b.initial_state(2:14))],[],2);
dt=a.period-b.period;ts=max([1,abs(a.period),abs(b.period)]);dq=a.stride_displacement-b.stride_displacement;
qs=max([ones(size(dq)),abs(a.stride_displacement),abs(b.stride_displacement)],[],2);
match=MatchingReturnSection_v3(a,b,{ra,rb});[~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);
out=struct('raw_full13_delta',dx,'raw_full13_scaled_inf',norm(dx./sx,inf),'period_delta',dt,'period_tolerance',1e-10*ts, ...
    'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
    'native_energy_delta',QuadrupedEnergy_v3.evaluate(a.initial_state,a.initial_mode,a.parameter)-QuadrupedEnergy_v3.evaluate(b.initial_state,b.initial_mode,b.parameter), ...
    'exact_state_equal',isequaln(a.initial_state,b.initial_state),'exact_p_q_equal',isequaln(a.parameter,b.parameter)&&isequaln(a.initial_mode,b.initial_mode), ...
    'matching_section',match,'exact_complete_policy_equal',pa.complete&&pb.complete&&isequaln(pa.configuration,pb.configuration), ...
    'same_section_event_signature',strcmp(string(a.section_relative_event_signature),string(b.section_relative_event_signature)),'conditions_met',false);
out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
    &&out.exact_p_q_equal&&match.compatible&&out.exact_complete_policy_equal&&out.same_section_event_signature;
end
function value=gpFamilyTag(families)
    value='MIXED';if numel(families)==1,value=families{1};end
end
function refs=gpProviders()
    names={'PreparePK30hStoredComponentPlan20261102','ConsolidateC1ConnectedComponents_v3','BranchSolutionFile_v3', ...
        'OrbitContentIdentity_v3','MatchingReturnSection_v3','QualifyC1RecordAlias_v3','C1FiniteNumericalOverlap_v3', ...
        'RecordedReturnPolicy_v3','ReturnPolicyBase_v3','BLMarkedApexReturnPolicy_v3','EventCycleReturnPolicy_v3', ...
        'IteratedReturnPolicy_v3','FirstReturnPolicy_v3','HybridOrbit_v3','Trajectory_v3','GaitSemanticTable_v3', ...
        'QuadrupedSchema_v3','QuadrupedEnergy_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cellfun(@(n)gpRef(which(n)),names(:),'UniformOutput',false);refs{end+1,1}=gpRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function gpRead2(file,expected)
    for pass=1:2
        x=load(file,'component_plan','plan_digest');assert(strcmp(C1ScientificDigest_v3(x.component_plan),x.plan_digest), ...
            'PKGraphPlan:ReadDigest','Each independent plan read must verify its whole typed digest.');
        assertPublicEqual(expected,x.component_plan,false,0);clear x
    end
end
function gpVerify(refs)
    for k=1:numel(refs)
        r=refs{k};assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'}))&&strcmp(r.file,gpLiteral(r.file)) ...
            &&ischar(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once'))&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
            'PKGraphPlan:Changed','A consumed immutable source/proof/closure/prefix or current graph recipe changed.');
        if isfield(r,'bytes')
            d=dir(r.file);assert(isscalar(d)&&~d.isdir&&isequal(double(d.bytes),double(r.bytes)), ...
                'PKGraphPlan:Bytes','The actual immutable reference must retain its declared whole-file byte count.');
        end
    end
end
function r=gpRef(file),r=struct('file',gpLiteral(file),'sha256',RoundSHA256_v3(file));end
function file=gpLiteral(value),file=canonical(value);assert(strcmp(file,canonical(V3Path_v3(value))),'PKGraphPlan:Alias','Hash/native-read paths must name the same literal file.');end
function l=gpLimit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function gpCheck(l),assert(min(l.deadline_unix_seconds-gpUTC(),(l.deadline_monotonic_ns-gpNano())/1e9)>0,'PKGraphPlan:Clock','The original grant/operation clocks expired; retain all actual partial/published files.');end
function t=gpUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=gpNano(),t=double(java.lang.System.nanoTime());end
