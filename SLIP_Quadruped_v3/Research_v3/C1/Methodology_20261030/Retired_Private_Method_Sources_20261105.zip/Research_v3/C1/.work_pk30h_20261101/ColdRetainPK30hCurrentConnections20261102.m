function result=ColdRetainPK30hCurrentConnections20261102(batchRef,closureRef,B,options)
%COLDRETAINPK30HCURRENTCONNECTIONS20261102 Saved finite proof/transport only.
% Actual independently closed batch positives only. No new scientific calls.
    entryUTC=utc();entryMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');W=fullfile(N,'.work_pk30h_20261101');
    assert(nargin==4&&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'OutputFile';'RetainedFiles';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&options.MaxWallSeconds==3300&&options.SaveMarginSeconds==120&&iscell(options.RetainedFiles)&&isequal(size(options.RetainedFiles),[5,1]), ...
        'PKCurrentCold:Options','Use one fresh audit and five explicit carrier paths with fixed resident3300/120.');
    assert(B.capture.pid==feature('getpid')&&min(B.research_deadline_unix_seconds-entryUTC,(B.research_deadline_monotonic_ns-entryMono)/1e9)>3302, ...
        'PKCurrentCold:WholeFit','The complete new3300/120 saved cold operation must fit the unchanged original science UTC/JVM grant.');
    finish=limit(entryUTC+3300,entryMono+3300e9);work=limit(finish.deadline_unix_seconds-120,finish.deadline_monotonic_ns-120e9);
    output=literal(options.OutputFile);stage=[output,'.pending.mat'];paths={output;stage};folders=cell(5,1);
    assert(strcmp(output,fullfile(N,'Audits','PK30h_20261102_CurrentConnections01_ColdQualification.mat')), ...
        'PKCurrentCold:AuditPath','Use the declared fresh CurrentConnections01 cold audit.');
    for k=1:5
        retained=literal(options.RetainedFiles{k});folders{k}=fileparts(retained);
        assert(strcmp(retained,fullfile(W,sprintf('CurrentConnections01_Cold_Case%02d_Run01',k),sprintf('Retained_Case%02d.mat',k))), ...
            'PKCurrentCold:CarrierPath','Only the declared fresh private carrier and its own folder are writable.');
        paths=[paths;{retained;[retained,'.pending.mat'];folders{k}}];
    end
    assert(numel(unique(paths))==17&&all(cellfun(@(f)~isfile(f)&&~isfolder(f),paths)), ...
        'PKCurrentCold:Fresh','Preserve every old/uncertain audit, carrier, own pending stage and folder. No unchanged-path retry.');
    code=providers();inputs=[{batchRef;closureRef};code];verifyAll(inputs);check(work);
    closed=jsondecode(fileread(closureRef.file));
    assert(strcmp(closed.schema,'PK30h-current-connections-external-closure-v1') ...
        &&strcmp(closed.queue_reference.file,batchRef.file)&&strcmp(closed.queue_reference.sha256,batchRef.sha256) ...
        &&closed.process.actual_tool_exit_observed&&closed.process.exit_code==0 ...
        &&closed.independent_post_guard.all_passed&&closed.all_owned_native_workers_closed, ...
        'PKCurrentCold:ExternalClosure','Require the actual batch process0, independent protected-input postguard and campaign-owned worker closure, not native self-certification.');
    validateattributes(closed.process.session_id,{'numeric'},{'real','finite','scalar','integer','positive'});
    validateattributes(closed.process.native_pid,{'numeric'},{'real','finite','scalar','integer','positive'});
    loaded=load(batchRef.file,'manifest','manifest_digest');same(loaded.manifest_digest,C1ScientificDigest_v3(loaded.manifest));batch=loaded.manifest;clear loaded
    assert(strcmp(batch.schema,'PK30h-five-independent-public-Acquire-queue-v1')&&batch.completed&&batch.source_posthash ...
        &&numel(batch.cases)==5&&batch.calls_returned==5&&~batch.unknown_commit_hold&&isempty(fieldnames(batch.pending_native_call)), ...
        'PKCurrentCold:Batch','Preserve the actual five returned known-nonpending native cases and literal scientific outcomes.');
    for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'}
        assert(strcmp(B.(key{1}),batch.original_budget.(key{1})),'PKCurrentCold:Grant','A new local saved-data allowance never renews the original grant.');
    end
    inputs=[inputs;batch.input_references];verifyAll(inputs);
    audit=struct('schema','PK30h-current-five-case-cold-retained-v1','batch_reference',batchRef,'external_closure_reference',closureRef, ...
        'external_closure_payload',closed,'historical_batch_completed',batch.completed,'historical_batch_source_posthash',batch.source_posthash, ...
        'original_budget',B,'original_finish',finish,'original_work',work,'options',options,'source_code',{code},'input_references',{inputs}, ...
        'cases',{{}},'qualifier_calls_prepared',0,'qualifier_calls_attempted',0,'qualifier_calls_returned',0,'qualified_relations_retained',0, ...
        'pending_qualifier_call',struct(),'unknown_publication_hold',false,'source_posthash',false,'completed',false,'failure',struct(), ...
        'root_ODE_map_replay_classifier_calls',0,'new_admission_claimed',false,'new_scientific_edge_created',false,'own_process_exit_claimed',false);
    checkpoint(stage,audit);hold=false;
    try
        for k=1:5
            originalRow=batch.cases{k};row=struct('index',k,'label',originalRow.label,'actual_batch_case',originalRow, ...
                'cold_attempted',false,'cold_returned',false,'cold_qualified',false,'status','COLD_NOT_ATTEMPTED_BATCH_NEGATIVE', ...
                'original_proof',struct(),'evidence',struct(),'failure',struct(),'retained_reference',struct(), ...
                'full_native_read2_verified',false,'complete_policy_read2_verified',false,'transport_attempted',false,'transport_completed',false);
            audit.cases{k,1}=row;
            assert(originalRow.returned&&originalRow.known_nonpending_output_state,'PKCurrentCold:KnownNativeReturn','Only literal known closed native outcomes enter this saved queue.');
            if ~originalRow.actual_native_flags.qualified_numerical_relation,checkpoint(stage,audit);continue;end
            if hold,audit.cases{k}.status='UNATTEMPTED_PRIOR_UNKNOWN_PUBLICATION_HOLD';checkpoint(stage,audit);continue;end
            if left(work)<=602,audit.cases{k}.status='UNATTEMPTED_FULL600_CHILD_DOES_NOT_FIT';checkpoint(stage,audit);continue;end
            fullAcquireRef=originalRow.actual_audit_reference;verify(fullAcquireRef);acquireRef=struct('file',fullAcquireRef.file,'sha256',fullAcquireRef.sha256);inputs{end+1,1}=fullAcquireRef;
            loaded=load(acquireRef.file,'audit');a=loaded.audit;clear loaded
            assert(strcmp(a.schema,'C1-finite-owned-PAL-numerical-overlap-experiment-v1')&&a.completed&&a.source_posthash ...
                &&a.ordinary_edge_earned&&a.qualified_numerical_relation&&a.fine_calls_attempted==4&&a.fine_calls_returned==4&&isempty(fieldnames(a.failure)) ...
                &&strcmp(a.source_reference.file,originalRow.source_reference.file)&&strcmp(a.source_reference.sha256,originalRow.source_reference.sha256) ...
                &&isequal(a.source_pair,originalRow.source_pair)&&strcmp(a.target_reference.file,originalRow.target_reference.file) ...
                &&strcmp(a.target_reference.sha256,originalRow.target_reference.sha256)&&a.target_index==originalRow.target_index, ...
                'PKCurrentCold:ActualPositive','Use only the exact actual qualified case audit and its original selector/alias context; no closeness promotion.');
            for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'}
                assert(strcmp(B.(key{1}),a.budget.(key{1})),'PKCurrentCold:CaseGrant','Preserve the actual acquisition grant labels.');
            end
            inputs=[inputs;a.source_code;{a.run_branch_reference;a.run_checkpoint_reference;a.target_reference;a.source_reference}];verifyAll(inputs);
            [pair,pr,pm]=BranchSolutionFile_v3.loadSolutions(a.run_branch_reference.file,[2;3]);
            [target,tr,tm]=BranchSolutionFile_v3.loadSolutions(a.target_reference.file,a.target_index);
            leftSelector=struct('file',a.run_branch_reference.file,'sha256',a.run_branch_reference.sha256,'index',3,'native_ID',OrbitContentIdentity_v3(pair{2}));
            rightSelector=struct('file',a.target_reference.file,'sha256',a.target_reference.sha256,'index',a.target_index,'native_ID',OrbitContentIdentity_v3(target{1}));
            childUTC=utc();childMono=nano();
            if left(work)<=602,audit.cases{k}.status='UNATTEMPTED_PREFLIGHT_FULL600_NO_LONGER_FITS';checkpoint(stage,audit);clear a pair pr pm target tr tm;continue;end
            child=limit(childUTC+600,childMono+600e9);childWork=limit(child.deadline_unix_seconds-60,child.deadline_monotonic_ns-60e9);
            witness=struct('schema','C1-external-native-process-exit-witness-v1','actual_process_exit_observed',true,'exit_code',closed.process.exit_code, ...
                'process_session_id',closed.process.session_id,'child_pid',closed.process.native_pid,'source_posthash_verified',closed.independent_post_guard.all_passed, ...
                'audit_reference',acquireRef,'external_closure_reference',closureRef,'parent_batch_reference',batchRef);
            proof=struct('schema','C1-finite-owned-PAL-numerical-overlap-proof-v1','audit_reference',acquireRef, ...
                'execution_witness',witness,'left_selector',leftSelector,'right_selector',rightSelector,'validation_limits',childWork);
            audit.cases{k}.original_proof=proof;audit.cases{k}.status='PREPARED_COLD_NOT_INVOKED';audit.qualifier_calls_prepared=audit.qualifier_calls_prepared+1;
            audit.pending_qualifier_call=struct('case_index',k,'kind','C1FiniteNumericalOverlap_v3.qualify','MaxWallSeconds',600,'SaveMarginSeconds',60,'original_child_finish',child,'original_child_work',childWork);
            audit.input_references=inputs;checkpoint(stage,audit);verifyAll(inputs);
            if left(work)<=602,audit.cases{k}.status='UNATTEMPTED_PREPARED_FULL600_CHILD_NO_LONGER_FITS';audit.pending_qualifier_call=struct();checkpoint(stage,audit);clear a pair pr pm target tr tm;continue;end
            check(childWork);check(work);
            audit.cases{k}.cold_attempted=true;audit.qualifier_calls_attempted=audit.qualifier_calls_attempted+1;
            try
                e=C1FiniteNumericalOverlap_v3.qualify(pair{2},target{1},pr{2},tr{1},proof);audit.cases{k}.cold_returned=true;audit.qualifier_calls_returned=audit.qualifier_calls_returned+1;
                audit.cases{k}.evidence=e;audit.cases{k}.cold_qualified=true;audit.cases{k}.status='QUALIFIED_E_DURABLE_BEFORE_TRANSPORT';
            catch problem
                audit.cases{k}.failure=failure(problem);audit.cases{k}.status='COLD_QUALIFICATION_REFUSED_NO_TRANSPORT';
            end
            audit.pending_qualifier_call=struct();checkpoint(stage,audit);
            if ~audit.cases{k}.cold_qualified,clear a pair pr pm target tr tm;continue;end
            check(childWork);check(work);retained=literal(options.RetainedFiles{k});folder=fileparts(retained);audit.cases{k}.transport_attempted=true;
            try
        % The complete earned e is durable before transport bookkeeping.
        javaMethod('createDirectory','java.nio.file.Files',java.io.File(folder).toPath(),javaArray('java.nio.file.attribute.FileAttribute',0));
        os={pair{1};pair{2};target{1}};rs={pr{1};pr{2};tr{1}};original={pm{1};pm{2};tm{1}};ms=cell(3,1);
        sourceRefs={a.run_branch_reference;a.run_branch_reference;a.target_reference};sourceIndices=[2,3,a.target_index];
        for n=1:3
            m=original{n};owner=sprintf('PK30h_CurrentConnections01_Cold_Case%02d_source',k);order=n;
            if n==3,owner=sprintf('PK30h_CurrentConnections01_Cold_Case%02d_target',k);order=1;end
            ms{n}=struct('component_identity',owner,'classification',m.classification,'nativeE',m.nativeE, ...
                'signedmeanU',m.signedmeanU,'order',order,'edge_enabled',n==2, ...
                'provenance',struct('kind','literal retained finite-proof record transport','source_reference',sourceRefs{n}, ...
                    'source_index',sourceIndices(n),'original_point_metadata',m,'native_id',OrbitContentIdentity_v3(os{n}), ...
                    'fresh_admission_claimed',false,'original_scientific_flags_changed',false));
            if n==2,ms{n}.edge_from=1;end
        end
        fragment=struct('qualified_numerical_overlaps',[2,3],'numerical_overlap_evidence',{{e}});
        BranchSolutionFile_v3.initialize(retained,struct('schema','PK30h-selected-retained-finite-three-records-v1', ...
            'acquire_reference',acquireRef,'component_graph',fragment,'new_scientific_edge_created',false, ...
            'physical_edge_scope','Actual earned predecessor2-to3 remapped1-to2; target remains NONEDGE.'));
        BranchSolutionFile_v3.appendBatch(retained,os,rs,ms);
        for pass=1:2
            [back,br,bm]=BranchSolutionFile_v3.loadSolutions(retained,1:3);
            for n=1:3
                same(public(os{n}),public(back{n}));same(rs{n},br{n});same(ms{n},bm{n});same(original{n},bm{n}.provenance.original_point_metadata);
                assert(strcmp(OrbitContentIdentity_v3(back{n}),OrbitContentIdentity_v3(os{n})), ...
                    'PKLowCold:NativeID','Transported full native records retain their actual NativeIDs.');samePolicy(rs{n},br{n});
            end
        end
        ix=BranchSolutionFile_v3.index(retained);
        assert(numel(ix.points)==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2 ...
            &&~bm{1}.edge_enabled&&bm{2}.edge_enabled&&~bm{3}.edge_enabled, ...
            'PKLowCold:Graph','Keep only P1-to2 and M2-to3; target remains NONEDGE.');
        same(fragment,ix.metadata.component_graph);
        C1FiniteNumericalOverlap_v3.validateRetained(e,back{2},back{3},br{2},br{3},back{1});
                audit.cases{k}.retained_reference=ref(retained);inputs{end+1,1}=audit.cases{k}.retained_reference;
                audit.cases{k}.original_physical_edge=[2,3];audit.cases{k}.retained_physical_edge=[1,2];audit.cases{k}.retained_numerical_row=[2,3];
                audit.cases{k}.full_native_read2_verified=true;audit.cases{k}.complete_policy_read2_verified=true;
                audit.cases{k}.transport_completed=true;audit.cases{k}.status='COLD_QUALIFIED_P_AND_M_CARRIER_RETAINED';audit.qualified_relations_retained=audit.qualified_relations_retained+1;
            catch problem
                audit.cases{k}.failure=failure(problem);audit.cases{k}.status='TRANSPORT_PARTIAL_OR_UNKNOWN_HELD_NO_RETRY';hold=true;
            end
            audit.unknown_publication_hold=hold;audit.input_references=inputs;checkpoint(stage,audit);verifyAll(inputs);check(child);check(work);
            clear a pair pr pm target tr tm os rs ms original back br bm e ix fragment proof
        end
        verifyAll(inputs);audit.input_references=inputs;audit.source_posthash=true;
        processed=cellfun(@(r)~startsWith(r.status,'UNATTEMPTED'),audit.cases);audit.completed=numel(audit.cases)==5&&all(processed)&&~audit.unknown_publication_hold;
        audit.all_declared_positives_retained=all(cellfun(@(r)~r.actual_batch_case.actual_native_flags.qualified_numerical_relation||r.transport_completed,audit.cases));
        audit.scope='Saved cold finite qualification and literal P/M transport only. Negative/refused cases remain literal. New carriers retain earnedP and finiteM; no new root/admission, endpoint/global/identity claim, old-proof requalification, graph refresh or source/frontier retirement.';
    catch problem,audit.failure=failure(problem);audit.input_references=inputs;end
    checkpoint(stage,audit);check(finish);
    assert(audit.completed&&audit.source_posthash,'PKCurrentCold:Incomplete','Retain every actual partial/evidence/carrier and refuse automatic retry: %s',jsonencode(audit.failure));
    before=RoundSHA256_v3(stage);assert(~isfile(output),'PKCurrentCold:PublishFresh','Preserve any concurrent/uncertain final audit.');
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath()) ...
        &&strcmp(RoundSHA256_v3(stage),before),'PKCurrentCold:OwnStage','Remove only the unchanged linked own audit stage.');
    delete(stage);loaded=load(output,'audit');same(audit,loaded.audit);verifyAll(inputs);check(finish);
    result=struct('completed',true,'source_posthash',true,'audit_reference',ref(output),'qualified_relations_retained',audit.qualified_relations_retained, ...
        'qualifier_calls_prepared',audit.qualifier_calls_prepared,'qualifier_calls_attempted',audit.qualifier_calls_attempted,'qualifier_calls_returned',audit.qualifier_calls_returned, ...
        'all_declared_positives_retained',audit.all_declared_positives_retained,'case_statuses',{cellfun(@(r)r.status,audit.cases,'UniformOutput',false)}, ...
        'retained_references',{cellfun(@(r)r.retained_reference,audit.cases,'UniformOutput',false)}, ...
        'root_ODE_map_replay_classifier_calls',0,'new_admission_claimed',false,'own_process_exit_claimed',false);
    try,fprintf('PK30H_CURRENT_COLD_RETURN %s\n',jsonencode(result));catch,fprintf('PK30H_CURRENT_COLD_RETURN {"completed":true,"source_posthash":true,"optional_output_unavailable":true}\n');end
end
function refs=providers()
    names={'ColdRetainPK30hCurrentConnections20261102','C1FiniteNumericalOverlap_v3','AcquireC1NumericalOverlap_v3', ...
        'BranchSolutionFile_v3','HybridOrbit_v3','Trajectory_v3','RecordedReturnPolicy_v3', ...
        'OrbitContentIdentity_v3','C1ScientificDigest_v3','HybridSimulator_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cell(numel(names),1);for k=1:numel(names),refs{k}=ref(which(names{k}));end
    refs{end+1,1}=ref(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function f=failure(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function t=left(l),t=min(l.deadline_unix_seconds-utc(),(l.deadline_monotonic_ns-nano())/1e9);end
function samePolicy(a,b)
    [~,x]=RecordedReturnPolicy_v3(a);[~,y]=RecordedReturnPolicy_v3(b);
    assert(x.complete&&y.complete,'PKRemainingCold:Policy','Require complete actual recorded policy settings.');same(x.configuration,y.configuration);
end
function checkpoint(file,audit),save(file,'audit','-v7');back=load(file,'audit');same(audit,back.audit);end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKRemainingCold:Readback','Complete declared typed values differ.');end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
function verifyAll(refs),for k=1:numel(refs),verify(refs{k});end,end
function verify(r),assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKRemainingCold:Source','Immutable literal authority changed.');end
function r=ref(file),r=struct('file',literal(file),'sha256',RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKRemainingCold:Alias','Hash and native read must address the same file.');end
function l=limit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKRemainingCold:Clock','The original fixed UTC/JVM cold operation or child clock expired.');end
function v=utc(),v=posixtime(datetime('now','TimeZone','UTC'));end
function v=nano(),v=double(java.lang.System.nanoTime());end
