function result=AuditPK30hStoredGraph20261102(B,bindings,options)
%AUDITPK30HSTOREDGRAPH20261102 Original saved records and finite experiment screen.
% PRIMARY authority is the explicit graph plan. Incomplete Core storage is
% optional literal history, never a gate or a synthetic completedConso.
% Historical all9/M/P facts are the RECORDED admission epoch, not fresh fixed
% engine qualification. Ongoing0061 science is independent of this audit.
    entryUTC=auUTC();entryMono=auNano();
    required={'GraphPlanReference';'GraphClosureReference';'EssentialReference';'OldCoreReference';'OldConsolidationReference'; ...
        'ClosedSourceCapsuleReference';'LegacyReference';'LocalGrazingReferences';'OptionalCoreManifestReference';'CurrentWorkReferences';'SupplementalDonorRows'};
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort(required)) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,1800)&&isequal(options.SaveMarginSeconds,60)&&B.capture.pid==feature('getpid'), ...
        'PKGraphAudit:Inputs','Use exact graph/history bindings and one new original-grant1800/60 saved-data audit.');
    assert(min(B.research_deadline_unix_seconds-entryUTC,(B.research_deadline_monotonic_ns-entryMono)/1e9)>1802, ...
        'PKGraphAudit:WholeFit','The full new saved-data operation must fit the unchanged original science UTC/JVM clocks.');
    finish=auLimit(entryUTC+1800,entryMono+1800e9);work=auLimit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=auLiteral(options.OutputFile);stage=[output,'.pending.mat'];assert(~isfile(output)&&~isfile(stage),'PKGraphAudit:Fresh','Preserve previous outputs and uncertain stages.');
    names={'AuditPK30hStoredGraph20261102','C1StoredComponentSource_v3','BranchSolutionFile_v3','LoadC1SolutionCore29_v3', ...
        'OrbitContentIdentity_v3','RecordedReturnPolicy_v3','C1FiniteNumericalOverlap_v3','MatchingReturnSection_v3', ...
        'HybridOrbit_v3','Trajectory_v3','ReturnPolicyBase_v3','BLMarkedApexReturnPolicy_v3','EventCycleReturnPolicy_v3', ...
        'IteratedReturnPolicy_v3','FirstReturnPolicy_v3','QuadrupedSchema_v3','GaitSemanticTable_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Path_v3','V3Root_v3'};
    code=cellfun(@(n)auRef(which(n)),names(:),'UniformOutput',false);code{end+1,1}=auRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
    assert(iscell(bindings.CurrentWorkReferences)&&iscell(bindings.LocalGrazingReferences), ...
        'PKGraphAudit:OpaqueRows','Current closed-work references are opaque provenance outside the original22 graph, never mutable live CP/output pins.');
    assert(iscell(bindings.SupplementalDonorRows)&&(isempty(bindings.SupplementalDonorRows)||iscolumn(bindings.SupplementalDonorRows))&&numel(bindings.SupplementalDonorRows)<=2, ...
        'PKGraphAudit:SupplementalBound','At most2 explicit CLOSED donor branches may be screened; empty cell preserves original1036 scope.');
    refs=[code;{bindings.GraphPlanReference;bindings.GraphClosureReference;bindings.EssentialReference;bindings.OldCoreReference;bindings.OldConsolidationReference; ...
        bindings.ClosedSourceCapsuleReference;bindings.LegacyReference};bindings.LocalGrazingReferences(:);bindings.CurrentWorkReferences(:)];auVerify(refs);auCheck(work);
    assert(strcmp(bindings.GraphPlanReference.sha256,'86beef51cc7d0ec9cb23ffb1b63b3a0b61596c7ea15ebb8511d5b4e319b51e83') ...
        &&strcmp(bindings.GraphClosureReference.sha256,'54a5888081315f74af1376acf66929939a5fcb6be4824c62b4699d22b207dadb') ...
        &&strcmp(bindings.OldCoreReference.sha256,'75dbd2012853aadbbec2fcee5b10560abad335b8c6bc383d4e4e43405479d6a9') ...
        &&strcmp(bindings.OldConsolidationReference.sha256,'96b18a0cfa2984b0ea71b96e6b062e2260e2e04ab4b3460a187e53b541a2c348') ...
        &&strcmp(bindings.ClosedSourceCapsuleReference.sha256,'1d6c0d2857c47dd30d2c018f2e137c288df4f534d00178be6e83bae348b1c697') ...
        &&strcmp(bindings.LegacyReference.sha256,'cb08770e36de5a8318620aed7f5fcaa4a3114bf8cb378d405ab3c14aaf374407'), ...
        'PKGraphAudit:Authorities','Use the exact closed graph, retained old494 map/capsule/Core and historical177 inventory.');
    audit=struct('schema','PK30h-stored-graph-saved-audit-and-screen-v1','completed',false,'source_posthash',false, ...
        'bindings',bindings,'input_references',{refs},'source_code',{code},'original_budget',B,'original_finish',finish, ...
        'graph_scope',struct(),'literal_failed_storage_flags',struct(),'optional_storage_facts',struct(),'source_acquisition',struct(), ...
        'component_inventory',{{}},'old_core_mapping',struct(),'meeting',struct(),'registered_endpoints',struct(), ...
        'target_screen',struct(),'supplemental_donor_intake',struct(),'legacy_inventory',struct(),'failure',struct(),'root_ODE_map_classifier_replay_calls',0, ...
        'fresh_engine_admission_claimed',false,'historical_M_requalified',false,'frontier_retirement_authorized',false, ...
        'source_retirement_authorized',false,'global_endpoint_or_uniqueness_claimed',false,'own_process_exit_claimed',false);auSave(stage,audit);
    try
        gc=jsondecode(fileread(bindings.GraphClosureReference.file));assert(strcmp(gc.schema,'PK30h-stored-graph-external-closure-v1') ...
            &&auRefEqual(gc.graph_reference,bindings.GraphPlanReference)&&gc.process.exit_code==0&&gc.process.actual_tool_exit_observed ...
            &&gc.independent_post_guard.all_passed&&~gc.raw_materialization_completion_claimed&&~gc.scientific_completion_claimed, ...
            'PKGraphAudit:GraphClosure','Actual closed graph process/custody proves graph planning only, never raw materialization or new science.');
        x=load(bindings.GraphPlanReference.file,'component_plan','plan_digest');plan=x.component_plan;
        assert(strcmp(C1ScientificDigest_v3(plan),x.plan_digest)&&strcmp(plan.schema,'C1-stored-component-graph-plan-v1') ...
            &&plan.completed&&plan.source_posthash&&plan.source_occurrence_bijection_verified&&numel(plan.nodes)==1036&&numel(plan.components)==6 ...
            &&~plan.native_payload_copied&&~plan.scientific_completion_claimed&&~plan.source_retirement_authorized, ...
            'PKGraphAudit:Plan','Use the complete exact graph-only selector plan, not a facade for failed rawConso.');clear x gc
        view=C1StoredComponentSource_v3.prepare(auRef2(bindings.GraphPlanReference));vix=C1StoredComponentSource_v3.index(view);auSame(vix,plan.view_index);refs=[refs;view.input_references];
        sourceRows=plan.bindings.SourceRows;roles=cellfun(@(r)r.role,sourceRows,'UniformOutput',false);assert(numel(sourceRows)==22,'PKGraphAudit:Original22','All original22 sources remain the immutable actual source universe.');
        x=load(bindings.EssentialReference.file,'final_manifest','manifest_digest');mf=x.final_manifest;
        assert(strcmp(C1ScientificDigest_v3(mf),x.manifest_digest)&&numel(mf.historical_obligations)==13&&numel(mf.proof_headers)==6, ...
            'PKGraphAudit:EssentialHistory','Load only the literal13 history and six proof headers; full native triples remain in the unchanged original Essential authority.');clear x
        for k=1:22,assert(auRefEqual(sourceRows{k}.reference,mf.configuration.SourceRows{k}.reference),'PKGraphAudit:HistorySourceOrder','Graph and retained Essential preserve every exact original source in order.');end
        audit.literal_failed_storage_flags=struct('essential_reference',bindings.EssentialReference,'essential_completed',mf.completed, ...
            'essential_source_posthash',mf.source_posthash,'essential_failure',mf.failure,'literal_graph_failed_raw_receipt',plan.historical_materialization.literal_failed_receipt, ...
            'six_historical_proof_headers',{mf.proof_headers},'historical_obligations',{mf.historical_obligations}, ...
            'scope','Literal old failed/raw/science epochs remain unchanged; current source-epoch and engine changes do not retroactively requalify these M/P facts.');
        graphs=auGraphs(plan,bindings.GraphPlanReference);requests=auRequests(mf,sourceRows,roles);oldInfo=struct('enabled',false,'failure',struct());
        try,oldInfo=auOldAuthority(bindings,plan,graphs,work);catch e,oldInfo.failure=auFailure(e);end
        headerGlobals=[];for k=1:numel(requests),for j=1:2,m=auMap(plan,requests{k}.reference,requests{k}.ordered_pair(j));headerGlobals(end+1)=m.global_index;end,end %#ok<AGROW>
        for name={'original0060','original0064','original0159'},r=auRole(sourceRows,roles,name{1});ix=auOriginalIndex(plan,r);for k=1:numel(ix.points),m=auMap(plan,r,k);headerGlobals(end+1)=m.global_index;end,end %#ok<AGROW>
        meetingGlobals=auMeetingGlobals(sourceRows,roles,plan);headerGlobals=unique([headerGlobals(:);meetingGlobals(:)]);
        [cache,acquisition]=auAcquire(view,plan,oldInfo,headerGlobals,meetingGlobals,work);audit.source_acquisition=acquisition;auSave(stage,audit);auCheck(work);
        try,audit.old_core_mapping=auOldCore(bindings,plan,graphs,oldInfo,cache,work);catch e,audit.old_core_mapping=auUnresolved(e);end;auSave(stage,audit);
        try,audit.meeting=auMeeting(sourceRows,roles,plan,graphs,bindings.LocalGrazingReferences,cache,work);catch e,audit.meeting=auUnresolved(e);end;auSave(stage,audit);
        audit.component_inventory=auComponents(plan,graphs,cache);audit.registered_endpoints=auEndpoints(requests,plan,cache);auSave(stage,audit);
        [supplemental,audit.supplemental_donor_intake,supplementalRefs]=auSupplemental(bindings.SupplementalDonorRows,work);refs=[refs;supplementalRefs];auSave(stage,audit);
        try,audit.target_screen=auTargets(sourceRows,roles,plan,graphs,cache,requests,supplemental,work);catch e,audit.target_screen=auUnresolved(e);end;auSave(stage,audit);
        unionIDs=unique(cellfun(@(n)n.native_ID,plan.nodes,'UniformOutput',false));clear cache oldInfo supplemental
        try,[audit.optional_storage_facts,storageRefs]=auOptionalStorage(bindings.OptionalCoreManifestReference,plan,bindings.GraphPlanReference,work);refs=[refs;storageRefs];catch e,audit.optional_storage_facts=auUnresolved(e);end;auSave(stage,audit);
        try,audit.legacy_inventory=auLegacy(bindings.LegacyReference,unionIDs,work);catch e,audit.legacy_inventory=auUnresolved(e);end
        audit.graph_scope=struct('graph_reference',bindings.GraphPlanReference,'whole_occurrences',numel(plan.nodes),'components',numel(graphs), ...
            'native_source_kind',view.kind,'recorded_admission_epoch_only',true,'new0061_outputs_outside_original22',true,'current_closed_work_references',{bindings.CurrentWorkReferences}, ...
            'scope','Current-work references are opaque provenance; neither this audit nor optional storage completion gates a separately verified0061 experiment.');
        audit.input_references=refs;auVerify(refs);auCheck(work);audit.source_posthash=true;audit.completed=acquisition.completed;if ~acquisition.completed,audit.failure=acquisition.failure;end
    catch e,audit.failure=auFailure(e);audit.input_references=refs;end
    auSave(stage,audit);auCheck(finish);sha=RoundSHA256_v3(stage);
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    for pass=1:2,x=load(output,'audit');auSame(audit,x.audit);clear x;end
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),sha), ...
        'PKGraphAudit:OwnStage','Delete only the exact unchanged linked own audit stage.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());auCheck(finish);
    result=struct('completed',audit.completed,'source_posthash',audit.source_posthash,'audit_reference',auRef(output), ...
        'components',numel(audit.component_inventory),'P_E_A_M_counts',{cellfun(@(g)g.P_E_A_M_counts,audit.component_inventory,'UniformOutput',false)}, ...
        'old_core_status',auMember(audit.old_core_mapping,'status','UNAVAILABLE'),'meeting_status',auMember(audit.meeting,'status','UNAVAILABLE'), ...
        'target_status',auMember(audit.target_screen,'status','UNAVAILABLE'),'prospective_Acquire_count',numel(auMember(audit.target_screen,'prospective_Acquire_selectors',{})), ...
        'optional_storage_status',auMember(audit.optional_storage_facts,'status','UNAVAILABLE'),'fresh_engine_admission_claimed',false, ...
        'frontier_retirement_authorized',false,'source_retirement_authorized',false,'own_process_exit_claimed',false);
    try,fprintf('PK30H_STORED_GRAPH_AUDIT_RETURN %s\n',jsonencode(result));catch,end
end

function info=auOldAuthority(bindings,plan,graphs,clock)
    cap=jsondecode(fileread(bindings.ClosedSourceCapsuleReference.file));x=load(bindings.OldConsolidationReference.file,'receipt');old=x.receipt;
    assert(strcmp(cap.schema,'C1-primary-PK-closed-source-snapshot-capsule-v1')&&cap.source_point_count==494&&cap.physical_edge_count==476 ...
        &&cap.source_to_output_bijection_verified&&cap.all_source_physical_edges_transported&&cap.native_receipt_read2_verified ...
        &&cap.actual_source_acquisition_exit_observed&&cap.actual_source_acquisition_exit_code==0&&cap.custody_complete ...
        &&auRefEqual(cap.consolidation_receipt_reference,bindings.OldConsolidationReference)&&old.completed ...
        &&old.source_public_readback_verified&&old.source_hashes_verified_after_work&&old.stored_occurrences==494&&old.original_explicit_edges==476, ...
        'PKPost:OldPublication','The exact retained additive receipt/capsule supplies the old four-source occurrence authority.');
    oldOutput=find(cellfun(@(r)strcmp(r.file,cap.source_reference.file)&&strcmp(r.sha256,cap.source_reference.sha256),old.component_files));
    assert(isscalar(oldOutput)&&old.component_files{oldOutput}.points==494&&old.component_files{oldOutput}.explicit_edges==476 ...
        &&strcmp(cap.source_reference.sha256,'71697fdabed0491def7d45c69b2ac03dc0d7c52c179d40a63f65ba114d83bc7b'), ...
        'PKPost:OldTargetSHA','Bind the old map target FILE/SHA/INDEX through its registered output row, without reopening Raw04.');
    [~,~,~,view]=LoadC1SolutionCore29_v3(bindings.OldCoreReference.file,1,bindings.OldCoreReference.sha256);
    x=load(bindings.OldCoreReference.file,'solution_core29','core_digest');c=x.solution_core29;
    assert(strcmp(C1ScientificDigest_v3(c),x.core_digest)&&c.point_count==494&&numel(c.graph.physical_edges)==476, ...
        'PKPost:OldCore','Verify the entire unchanged typed oldCore payload/counts.');auSame(c.native_ids,view.native_ids);auSame(c.graph,view.typed_graph);
    ordered=cap.ordered_consolidation_source_references;if isstruct(ordered),ordered=num2cell(ordered(:));else,ordered=ordered(:);end
    assert(numel(ordered)==4&&numel(old.source_catalog)==4,'PKPost:OldFour','Use all four literal ordered original inputs.');
    for k=1:4,assert(strcmp(old.source_catalog{k}.file,ordered{k}.file)&&strcmp(old.source_catalog{k}.sha256,ordered{k}.sha256), ...
        'PKPost:OldFourOrder','Old source catalogue order must match the closed capsule exactly.');end
    maps=cell(494,1);oldOwnerMap=cell(0,1);sourceKeys=cell(494,1);targetKeys=cell(494,1);
    for k=1:494
        context=c.contexts{k};assert(context.expected_index==k&&context.source_index==k&&auRefEqual(context.source_reference,cap.source_reference),'PKPost:OldContext','Keep the actual expected old occurrence ordinal.');
        at=find(cellfun(@(m)strcmp(m.target_file,cap.source_reference.file)&&m.target_index==context.expected_index,old.occurrence_map));
        assert(isscalar(at),'PKPost:OldInverse','The exact oldRaw04 FILE/INDEX must invert uniquely through the SHA-bound old receipt.');m=old.occurrence_map{at};
        sr=struct('file',m.source_file,'sha256',m.source_sha256);catalogue=find(cellfun(@(s)strcmp(s.file,sr.file)&&strcmp(s.sha256,sr.sha256),old.source_catalog));
        assert(isscalar(catalogue)&&auRefEqual(sr,ordered{catalogue}), ...
            'PKPost:OldInverseSHA','Every inverse selector must belong to the exact old four-source FILE/SHA catalogue.');
        sourceOwner=old.source_catalog{catalogue}.point_metadata{m.source_index}.component_identity;oldOwner=c.point_metadata{k}.component_identity;
        hit=find(cellfun(@(v)v.source_number==catalogue&&strcmp(v.source_component_identity,sourceOwner),oldOwnerMap));
        if isempty(hit),oldOwnerMap{end+1,1}=struct('source_number',catalogue,'source_component_identity',sourceOwner,'output_component_identity',oldOwner);
        else,assert(isscalar(hit)&&strcmp(oldOwnerMap{hit}.output_component_identity,oldOwner),'PKPost:OldOwnerMap','Literal inverse selectors must yield one consistent old output owner.');end
        next=auMap(plan,sr,m.source_index);maps{k}=struct('old_core_index',k,'historical_context',context,'old_raw04_reference',cap.source_reference, ...
            'old_raw04_index',context.expected_index,'original_source_reference',sr,'original_source_index',m.source_index, ...
            'old_source_number',catalogue,'original_source_owner',sourceOwner,'old_core_owner',oldOwner,'graph_mapping',next);
        sourceKeys{k}=sprintf('%s|%s|%d',sr.file,sr.sha256,m.source_index);targetKeys{k}=sprintf('%d|%d',next.component_number,next.component_index);
    end
    assert(numel(unique(cellfun(@(m)m.output_component_identity,oldOwnerMap,'UniformOutput',false)))==numel(oldOwnerMap), ...
        'PKPost:OldOwnerBijection','The explicit observed old source-owner map must preserve distinct source owners.');
    assert(numel(unique(sourceKeys))==494&&numel(unique(targetKeys))==494,'PKPost:OldBijection','All494 old occurrences survive as distinct source/output occurrence selectors.');
    globalToOld=zeros(numel(plan.nodes),1);for k=1:494,n=maps{k}.graph_mapping.global_index;assert(globalToOld(n)==0,'PKGraphAudit:OldUnique','Each old occurrence has one exact original global selector.');globalToOld(n)=k;end
    info=struct('enabled',true,'core',c,'maps',{maps},'old_owner_map',{oldOwnerMap},'old_receipt',old,'capsule',cap,'global_to_old',globalToOld);
end

function out=auOldCore(bindings,plan,graphs,info,cache,clock)
    if ~info.enabled,out=struct('status','UNRESOLVED_OLD_AUTHORITY','observations_completed',false,'failure',info.failure);return;end
    c=info.core;maps=info.maps;old=info.old_receipt;cap=info.capsule;oldOwnerMap=info.old_owner_map;rows=cache.old_rows;
    globals=cellfun(@(m)m.graph_mapping.global_index,maps);
    assert(all(cache.verified(globals))&&numel(rows)==494&&all(~cellfun(@isempty,rows)),'PKGraphAudit:OldCoverage','Both original source passes must cover all494 inverse selectors.');
    physical=cell(476,1);
    for k=1:476
        edge=c.graph.physical_edges{k};a=maps{edge.from};b=maps{edge.to};
        assert(isequaln(a.original_source_reference,b.original_source_reference)&&a.old_source_number==b.old_source_number, ...
            'PKPost:OldPhysicalSource','An original physical edge must stay inside its exact source/owner, not a nonphysical cross-file relation.');
        oldSource=old.source_catalog{a.old_source_number};hit=find(cellfun(@(e)e.from==a.original_source_index&&e.to==b.original_source_index,oldSource.original_edges));
        assert(isscalar(hit)&&strcmp(oldSource.original_edges{hit}.component_identity,a.original_source_owner) ...
            &&strcmp(a.original_source_owner,b.original_source_owner)&&strcmp(edge.component_identity,a.old_core_owner)&&strcmp(a.old_core_owner,b.old_core_owner), ...
            'PKPost:OldPhysicalOwner','Retained source/core P rows must preserve exact orientation and observed old source-owner mapping.');
        sourceEdge=oldSource.original_edges{hit};
        [g,from,to]=auSameComponent(graphs,a.graph_mapping,b.graph_mapping);ix=graphs{g}.index;hit=find(cellfun(@(e)e.from==from&&e.to==to,ix.edges));
        assert(isscalar(hit),'PKPost:NewPhysical','Every old oriented physical edge must survive as P, never E/A/M.');newEdge=ix.edges{hit};
        sourceNumber=find(cellfun(@(s)strcmp(s.file,a.original_source_reference.file)&&strcmp(s.sha256,a.original_source_reference.sha256),plan.source_catalog));
        ownerRows=ix.metadata.source_owner_map;owner=find(cellfun(@(v)v.source_number==sourceNumber&&strcmp(v.source_component_identity,a.original_source_owner),ownerRows));
        assert(isscalar(owner)&&strcmp(ownerRows{owner}.output_component_identity,newEdge.component_identity) ...
            &&strcmp(ix.points{from}.component_identity,newEdge.component_identity)&&strcmp(ix.points{to}.component_identity,newEdge.component_identity), ...
            'PKPost:NewOwnerMap','Use explicit actual new source_owner_map; do not compare or strip owner prefixes.');
        physical{k}=struct('old_core_physical_row',k,'old_core_edge',edge,'original_source_reference',a.original_source_reference, ...
            'original_source_edge',sourceEdge, ...
            'observed_old_owner',a.old_core_owner,'original_source_owner',a.original_source_owner,'new_source_owner_map',ownerRows{owner}, ...
            'graph_reference',graphs{g}.reference,'component_number',graphs{g}.component_number,'union_physical_row',hit,'union_edge',newEdge,'orientation_preserved',true);
    end
    verified=all(cellfun(@(r)r.all_retained_values_equal,rows));out=struct('status','UNRESOLVED','observations_completed',true, ...
        'old_core_reference',bindings.OldCoreReference,'old_raw04_reference',cap.source_reference,'old_receipt_reference',bindings.OldConsolidationReference, ...
        'capsule_reference',bindings.ClosedSourceCapsuleReference,'occurrence_count',494,'physical_edge_count',476,'rows',{rows},'physical_rows',{physical}, ...
        'observed_old_source_owner_map',{oldOwnerMap},'owner_map_scope','Exact old inverse-source metadata joined to oldCore literal owners; no prefix parsing or deleted Raw04 access.', ...
        'maximum_original_source_records',cache.maximum_original_source_records,'all494_retained_projections_verified',verified,'all476_oriented_physical_edges_verified',true,'oldCore_retirement_authorized',false, ...
        'scope','Preservation of declared oldCore information and physical occurrences only; report/primitive/classifier omissions stay literal, no old trajectory or fresh admission claim.');
    if verified,out.status='VERIFIED_494_OCCURRENCES_476_ORIENTED_P';end
end

function row=auOldProjection(c,k,mapping,o,r)
    [~,policy]=RecordedReturnPolicy_v3(r);e=c.orbit_evidence{k};kept=fieldnames(e);orbitSubset=struct();
    for z=1:numel(kept)
        key=kept{z};assert(isprop(o,key),'PKPost:OldEvidenceProperty','Every old retained orbit property remains available on the actual original native record.');v=o.(key);
        if ismember(key,{'primitive_cycle','gait_identification'}),v=auHead(e.(key),v);end;orbitSubset.(key)=v;
    end
    reportSubset=auReportSubset(c.saved_reports{k},r);
    checks=struct('state14',auEqual(c.solution_matrix(1:14,k),o.initial_state),'stride14',auEqual(c.solution_matrix(15:28,k),o.stride_displacement), ...
        'period',auEqual(c.solution_matrix(29,k),o.period),'parameter',auEqual(c.parameters{k},o.parameter),'mode',auEqual(c.modes{k},o.initial_mode), ...
        'native_id',strcmp(c.native_ids{k},OrbitContentIdentity_v3(o)),'complete_policy',policy.complete&&auEqual(c.policies{k}.configuration,policy.configuration), ...
        'section_chart',auEqual(c.section_charts{k},o.section_chart),'retained_orbit_evidence',auEqual(e,orbitSubset), ...
        'declared_saved_report_projection',auEqual(c.saved_reports{k},reportSubset));
    sameFields=isequal(fieldnames(c.saved_reports{k}),fieldnames(r));sameFull=false;if sameFields,sameFull=auEqual(c.saved_reports{k},r);end
    row=struct('mapping',mapping,'literal_equal',checks,'all_retained_values_equal',all(structfun(@(v)v,checks)), ...
        'old_saved_report_fields',{fieldnames(c.saved_reports{k})},'old_classifier_present',isfield(c.saved_reports{k},'classification'), ...
        'old_primitive_present',isfield(c.saved_reports{k},'primitive'),'original_full_report_fields',{fieldnames(r)}, ...
        'old_saved_report_digest',C1ScientificDigest_v3(c.saved_reports{k}),'actual_declared_projection_digest',C1ScientificDigest_v3(reportSubset), ...
        'full_reports_equal_observed',sameFull,'full_report_comparison_scope','Different fieldsets prove literal report inequality; matching fieldsets use full typed equality. Dense unprojected report values are not copied or hashed for494rows.', ...
        'old_core_trajectory_scope','UNAVAILABLE: oldCore did not retain complete trajectories; no old full trajectory equality claimed.');
end

function out=auMeeting(rows,roles,plan,graphs,grazing,cache,clock)
    source=auRole(rows,roles,'latest0170');fork=auRole(rows,roles,'join_fork');target=auRole(rows,roles,'grown0072');retained=auRole(rows,roles,'retained_join');
    original17=auRole(rows,roles,'original0170');original72=auRole(rows,roles,'original0072');auCheck(clock);
    [a,ar,ag]=auCached(cache,plan,source,16);[f,fr,fg]=auCached(cache,plan,fork,[2;3]);[t,tr,tg]=auCached(cache,plan,target,[53;54]);
    fi=auOriginalIndex(plan,fork);ti=auOriginalIndex(plan,target);ri=auOriginalIndex(plan,retained);rg=ri.metadata.component_graph;
    assert(size(rg.qualified_numerical_overlaps,1)==1&&numel(rg.numerical_overlap_evidence)==1, ...
        'PKPost:NewM','Use the one actual retained new-join numerical row.');mpair=rg.qualified_numerical_overlaps(1,:);e=rg.numerical_overlap_evidence{1};
    assert(strcmp(e.schema,'C1-qualified-finite-numerical-overlap-v1')&&strcmp(e.left_selector.file,fork.file) ...
        &&strcmp(e.left_selector.sha256,fork.sha256)&&e.left_selector.index==3&&strcmp(e.right_selector.file,target.file) ...
        &&strcmp(e.right_selector.sha256,target.sha256)&&e.right_selector.index==54, ...
        'PKPost:NewSelectors','The unchanged cold proof must name actual fork3 and grown0072 terminal54.');
    assert(auEqual(e.left_record,auRecord(f{2}))&&auEqual(e.right_record,auRecord(t{2})) ...
        &&auEqual(e.earned_physical_edge.from_record,auRecord(f{1}))&&strcmp(e.left_native_ID,OrbitContentIdentity_v3(f{2})) ...
        &&strcmp(e.right_native_ID,OrbitContentIdentity_v3(t{2}))&&auEqual(e.left_admission,auFiniteAdmission(fr{2})) ...
        &&auEqual(e.right_admission,auFiniteAdmission(tr{2})), ...
        'PKGraphAudit:OldMRecordedProjection','Keep exact original records/IDs/recorded admission-policy projections behind OLD GraphPlan-qualified M. No repaired-engine requalification or compact-policy provenance substitution.');
    importFlags=struct('full_native_orbit_equal',strcmp(cache.full_orbit_digests{ag(1)},cache.full_orbit_digests{fg(1)}),'native_record_equal',auEqual(auRecord(a{1}),auRecord(f{1})), ...
        'native_id_equal',strcmp(OrbitContentIdentity_v3(a{1}),OrbitContentIdentity_v3(f{1})), ...
        'admission_policy_projection_equal',auEqual(auAdmission(ar{1}),auAdmission(fr{1})));
    importReport=struct('source_report_digest',cache.full_report_digests{ag(1)},'fork_compacted_report_digest',cache.full_report_digests{fg(1)}, ...
        'full_reports_equal_observed',strcmp(cache.full_report_digests{ag(1)},cache.full_report_digests{fg(1)}),'comparison_scope','Report compaction differences are preserved; only declared admission/policy projection equality is required.');
    fedge=auEdge(fi,2,3);tedge=auEdge(ti,53,54);forkTerminal=~any(cellfun(@(p)p.from==3,fi.edges));targetTerminal=~any(cellfun(@(p)p.from==54,ti.edges));
    states=[f{1}.initial_state(2:14),f{2}.initial_state(2:14),t{1}.initial_state(2:14),t{2}.initial_state(2:14)];
    scale=max([ones(13,1),abs(states)],[],2);u=(states(:,2)-states(:,1))./scale;v=(states(:,4)-states(:,3))./scale;nu=norm(u);nv=norm(v);cosine=[];
    if isfinite(nu)&&isfinite(nv)&&nu>0&&nv>0,cosine=dot(u,v)/(nu*nv);end
    geometry=struct('raw_state_indices',2:14,'raw_states',states,'common_scale',scale,'fork_incoming_secant',u,'target_incoming_secant',v, ...
        'fork_secant_norm',nu,'target_secant_norm',nv,'cosine',cosine,'opposed_observed',~isempty(cosine)&&isfinite(cosine)&&cosine<0, ...
        'scope','Finite raw13 incoming secants with one common max1 scale; no classical tangent, local uniqueness or branch theorem.');
    sourceMap=auMap(plan,source,16);forkParentMap=auMap(plan,fork,2);forkHeadMap=auMap(plan,fork,3);targetPrevMap=auMap(plan,target,53);targetHeadMap=auMap(plan,target,54);
    high17=auMap(plan,original17,59);high72=auMap(plan,original72,6);mleft=auMap(plan,retained,mpair(1));mright=auMap(plan,retained,mpair(2));
    route=struct('status','UNRESOLVED','original0170_high_selector',struct('reference',original17,'index',59,'study_pair',[55,59]), ...
        'original0072_high_selector',struct('reference',original72,'index',6,'study_pair',[5,6]), ...
        'source_to_union_maps',{{high17;high72;mleft;mright;sourceMap;forkParentMap;forkHeadMap;targetPrevMap;targetHeadMap}}, ...
        'local_grazing_study_references',{grazing},'boundary_physical_edges_added',false);
    sameFile=high17.component_number==high72.component_number&&high17.component_number==mleft.component_number&&mleft.component_number==mright.component_number;
    if sameFile
        [g,l,r]=auSameComponent(graphs,mleft,mright);ix=graphs{g}.index;gg=ix.metadata.component_graph;
        at=find(gg.qualified_numerical_overlaps(:,1)==l&gg.qualified_numerical_overlaps(:,2)==r);
        assert(isscalar(at)&&auEqual(gg.numerical_overlap_evidence{at},e),'PKPost:MappedNewM','Keep the exact original newM evidence under actual union remapping.');
        leftPath=auPath(graphs{g},high17.component_index,l,at);rightPath=auPath(graphs{g},r,high72.component_index,at);
        route.graph_reference=graphs{g}.reference;route.component_number=graphs{g}.component_number;route.left_subpath=leftPath;route.right_subpath=rightPath;
        route.forced_newM_step=auStep(graphs{g},l,r,4,at);route.newM_evidence_unchanged=true;
        if strcmp(leftPath.status,'FOUND')&&strcmp(rightPath.status,'FOUND')
            route.status='FOUND_FINITE_TYPED_ROUTE_THROUGH_NEW_M';route.nodes=[leftPath.nodes,rightPath.nodes];
            route.simple_path_observed=numel(unique(route.nodes))==numel(route.nodes);
            route.steps=[leftPath.steps;{route.forced_newM_step};rightPath.steps];
        end
    else,route.reason='Mapped high endpoints and the newM are in different actual stored components.';end
    out=struct('status','UNRESOLVED','observations_completed',true,'source16_to_fork2',importFlags,'report_difference_observation',importReport, ...
        'actual_fork_physical_edge',struct('reference',fork,'row',fedge),'actual_target_physical_edge',struct('reference',target,'row',tedge), ...
        'fork3_no_outgoing_P',forkTerminal,'target54_no_outgoing_P',targetTerminal,'finite_secant_geometry',geometry,'typed_route',route, ...
        'historical_M_qualification_epoch','UNCHANGED_GRAPHPLAN_OLD_RECORDED_EVIDENCE','fresh_M_qualification_performed',false,'newM_cold_evidence',e,'newM_retained_reference',retained,'finite_numerical_meeting_observed',false, ...
        'low_frontier_retirement_authorized',false,'global_endpoint_or_uniqueness_claimed',false,'classical_tangent_claimed',false);
    out.finite_numerical_meeting_observed=all(structfun(@(v)v,importFlags))&&forkTerminal&&targetTerminal&&geometry.opposed_observed ...
        &&strcmp(route.status,'FOUND_FINITE_TYPED_ROUTE_THROUGH_NEW_M');
    if out.finite_numerical_meeting_observed,out.status='FINITE_NUMERICAL_FRONT_MEETING_OBSERVED';end;auCheck(clock);
end
function path=auPath(g,a,b,excludedM)
    [tables,~]=auTables(g.index);path=struct('status','UNRESOLVED','start',a,'finish',b,'nodes',[],'steps',{{}}, ...
        'scope','Undirected stored route only; every P traversal direction/owner and E/A/M evidence remains explicit.');
    for level=1:4
        edges=zeros(0,2);
        for kind=1:level
            p=tables{kind};if kind==4,p(excludedM,:)=[];end;edges=[edges;p]; %#ok<AGROW>
        end
        nodes=shortestpath(graph(edges(:,1),edges(:,2),[],numel(g.index.points)),a,b);
        if isempty(nodes),continue;end
        path.status='FOUND';path.minimum_subpath_connectivity_layer=level;path.nodes=nodes;
        path.steps=cell(numel(nodes)-1,1);for k=1:numel(nodes)-1,item=auStep(g,nodes(k),nodes(k+1),0,0);item.path_maximum_relation_kind=level;
            for kind=1:level,eligible=item.relation_rows{kind};if kind==4,eligible=eligible(eligible~=excludedM);end
                if ~isempty(eligible),item.selected_kind=kind;item.selected_row=eligible(1);break;end
            end;path.steps{k}=item;end
        return
    end
end
function step=auStep(g,a,b,forcedKind,forcedRow)
    [tables,evidence]=auTables(g.index);labels={'P','E','A','M'};rows=cell(4,1);relations=cell(0,1);
    for kind=1:4
        p=tables{kind};rows{kind}=find((p(:,1)==a&p(:,2)==b)|(p(:,1)==b&p(:,2)==a));
        for j=rows{kind}(:).'
            from=p(j,1);to=p(j,2);owner='';if kind==1,owner=evidence{kind}{j}.component_identity;end
            relations{end+1,1}=struct('kind',labels{kind},'row',j,'stored_from',from,'stored_to',to,'path_from',a,'path_to',b, ...
                'traversed_in_saved_direction',from==a,'owner',owner,'from_native_id',g.native_ids{from},'to_native_id',g.native_ids{to},'evidence',evidence{kind}{j}); %#ok<AGROW>
        end
    end
    assert(~isempty(relations),'PKPost:PathStep','Every reported graph step needs actual typed relation evidence.');
    if forcedKind>0,assert(ismember(forcedRow,rows{forcedKind}),'PKPost:ForcedM','The explicitly forced newM row must be present at this exact mapped step.');end
    step=struct('path_from',a,'path_to',b,'relation_rows',{rows},'relations',{relations}, ...
        'parallel_relation_kinds_present',nnz(cellfun(@(r)~isempty(r),rows))>1,'forced_kind',forcedKind,'forced_row',forcedRow, ...
        'selected_kind',forcedKind,'selected_row',forcedRow,'scope','All parallel evidence is listed; selected_kind/row identifies the actual chosen typed traversal.');
end
function [tables,evidence]=auTables(ix)
    g=ix.metadata.component_graph;P=zeros(numel(ix.edges),2);for k=1:numel(ix.edges),P(k,:)=[ix.edges{k}.from,ix.edges{k}.to];end
    tables={P;g.exact_record_equalities;g.qualified_record_aliases;g.qualified_numerical_overlaps};
    evidence={ix.edges;g.equality_evidence;g.qualified_alias_evidence;g.numerical_overlap_evidence};
end
function e=auEdge(ix,a,b)
    at=find(cellfun(@(e)e.from==a&&e.to==b,ix.edges));assert(isscalar(at),'PKPost:OwnedEdge','Use the actual one directed physical edge.');e=ix.edges{at};
    assert(strcmp(ix.points{a}.component_identity,e.component_identity)&&strcmp(ix.points{b}.component_identity,e.component_identity) ...
        &&isequal(ix.points{b}.metadata.edge_enabled,true)&&isequal(ix.points{b}.metadata.edge_from,a), ...
        'PKPost:OwnedEdgeOwner','Physical edge and same-owner predecessor metadata must agree.');
end

function out=auLegacy(r,unionIDs,clock)
    info=dir(r.file);vars=whos('-file',r.file);out=struct('status','UNASSESSED_UNSUPPORTED_LEGACY_SCHEMA','observations_completed',true, ...
        'reference',r,'top_variables',{arrayfun(@(v)struct('name',v.name,'class',v.class,'size',v.size),vars,'UniformOutput',false)}, ...
        'rows',{{}},'novel_supported_ID_count',[],'retained_universe_expanded',false,'retirement_authorized',false);
    assert(isscalar(info)&&info.bytes==44967003,'PKPost:LegacyBytes','Use the exact44967003B historical177 native store.');
    if ~all(ismember({'solutions','branch'},{vars.name})),return;end
    x=load(r.file,'solutions','branch');
    if ~iscell(x.solutions)||numel(x.solutions)~=177||~isstruct(x.branch)||~isscalar(x.branch) ...
            ||~all(isfield(x.branch,{'records','components'}))||~isstruct(x.branch.records)||numel(x.branch.records)~=177 ...
            ||~isstruct(x.branch.components)||numel(x.branch.components)~=39,return;end
    out.status='HISTORICAL177_NATIVE_INVENTORY';out.branch_fields=fieldnames(x.branch);out.component_count=39;out.rows=cell(177,1);novel=cell(0,1);supported=0;
    for k=1:177
        auCheck(clock);o=x.solutions{k};rec=x.branch.records(k);
        row=struct('index',k,'native_class',class(o),'native_shape',size(o),'record_fields',{fieldnames(rec)}, ...
            'recorded_provenance',auPick(rec,{'solution_index','component_index','source_path','source_sha256','source_record_index', ...
                'source_group_key','period','signed_drift','energy','classification_label','physical_flight_count'}), ...
            'status','UNASSESSED_UNSUPPORTED_NATIVE_IDENTITY','failure',struct(),'current_admission_claimed',false);
        try
            assert(isa(o,'HybridOrbit_v3')&&isscalar(o)&&isnumeric(o.initial_state)&&numel(o.initial_state)==14 ...
                &&isnumeric(o.stride_displacement)&&isvector(o.stride_displacement)&&~isempty(o.stride_displacement) ...
                &&numel(o.parameter)==10&&numel(o.initial_mode)==4&&isscalar(o.period)&&o.period>0 ...
                &&all(isfinite([o.initial_state(:);o.stride_displacement(:);o.parameter(:);double(o.initial_mode(:));o.period])), ...
                'PKPost:LegacyIdentityShape','Only actual finite native identity-bearing records are supported; no constructor, replay or classifier substitutes.');
            id=OrbitContentIdentity_v3(o);matches=find(strcmp(unionIDs,id));row.native_id=id;row.union_unique_ID_matches=matches;
            row.status='SUPPORTED_HISTORICAL_NATIVE_ID';row.state_shape=size(o.initial_state);row.stride_shape=size(o.stride_displacement); ...
                row.current_matrix29_layout_supported=isequal(size(o.initial_state),[14,1])&&isequal(size(o.stride_displacement),[14,1]);row.return_policy_name_literal=o.return_policy_name;row.section_chart_fields=auFields(o.section_chart);
            row.saved_classifier_contract=auMember(o.gait_identification,'contract_version','UNAVAILABLE');row.saved_primitive_fields=auFields(o.primitive_cycle);
            row.period=o.period;row.stride=o.stride_displacement;row.parameter=o.parameter;row.mode=o.initial_mode;
            row.policy_report_scope='UNASSESSED historical complete policy/admission; supported bundle has no restored source reports.';
            row.native_ID_scope='Exact numerical record ID inventory only; an ID match alone does not prove current policy, cycle equivalence or admission.';
            if isempty(matches),novel{end+1,1}=id;row.retained_universe_status='NOVEL_SUPPORTED_NATIVE_RECORD_MUST_RETAIN';
            else,row.retained_universe_status='OBSERVED_NATIVE_ID_MATCH_ONLY';end;supported=supported+1;
        catch e,row.failure=auFailure(e);end
        out.rows{k}=row;
    end
    out.supported_native_ID_records=supported;out.novel_supported_ID_count=numel(unique(novel));out.retained_universe_expanded=~isempty(novel);
    out.scope='Historical dated177-record inventory. Novel supported native records enlarge retained inventory; unsupported/stale schema stays UNASSESSED, never nonexistent, retired or automatically replayed.';
end
function h=auEndpointHeader(o,r,m,p)
    [~,policy]=RecordedReturnPolicy_v3(r);s=QuadrupedSchema_v3.shared();x=o.initial_state;par=o.parameter;
    height=struct('status','UNASSESSED_UNSUPPORTED_LENGTH','strict_less',[],'new_stop_authorized',false);
    Lb=par(s.Parameter.l_l_b);Lf=par(s.Parameter.l_l_f);
    if isfinite(Lb)&&Lb>0&&isequaln(Lb,Lf)
        height=struct('status','MEASURED_STRICT_LITERAL_HEIGHT','H',x(s.State.y),'L0',Lb,'threshold',.5*Lb,'ratio',x(s.State.y)/Lb, ...
            'strict_less',x(s.State.y)<.5*Lb,'new_stop_authorized',false,'scope','Recorded-section measurement; no fresh downward-flow derivative or admission is earned.');
    end
    cohort=struct('event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'members',{o.event_cluster_members},'names',{o.event_cluster_names},'center_times',o.event_cluster_center_times, ...
        'maximum_intra_cluster_spread',o.maximum_intra_cluster_spread,'minimum_intercluster_gap',o.minimum_intercluster_gap, ...
        'section_cluster_coincidence',o.section_cluster_coincidence,'section_coincident_cluster_indices',o.section_coincident_cluster_indices);
    h=struct('index',p.index,'native_id',OrbitContentIdentity_v3(o),'owner',m.component_identity,'state14',x,'parameter',par,'mode',o.initial_mode, ...
        'period',o.period,'stride14',o.stride_displacement,'policy',policy,'section',o.section_chart, ...
        'section_signature',o.section_relative_event_signature,'cyclic_signature',o.cyclic_event_signature,'saved_event_history',o.event_history, ...
        'saved_cohort',cohort,'raw_leg_angles',x(s.Leg.AngleIndices),'raw_leg_rates',x(s.Leg.RateIndices),'return_multiplicity',o.return_multiplicity, ...
        'saved_current_all9_PK',admitted(r),'classification',auPick(auMember(r,'classification',struct()),{'contract_version','status','validated_gait_type','canonical_point_label','canonical_label_qualified','flight_count','flight_count_certain','primitive_flight_count','period_used','descriptive_only','isotropy_proved'}),'acceptance_gates',auMember(r,'acceptance_gates',struct()), ...
        'strict_height_measurement',height,'cohort_scope','Literal saved properties; empty/default cohort headers establish no new validity.');
end
function [small,report,context]=auScreenView(o,r)
    small=auRecord(o);small.return_policy=o.return_policy;small.return_multiplicity=o.return_multiplicity;
    cohort=struct('event_cluster_signature',o.event_cluster_signature,'cyclic_event_cluster_signature',o.cyclic_event_cluster_signature, ...
        'event_cluster_members',{o.event_cluster_members},'event_cluster_names',{o.event_cluster_names}, ...
        'section_cluster_coincidence',o.section_cluster_coincidence,'section_coincident_cluster_indices',o.section_coincident_cluster_indices);
    token=o.event_cluster_signature;cohortSupported=((ischar(token)&&isrow(token))||(isstring(token)&&isscalar(token)))&&strlength(string(token))>0;
    [~,policy]=RecordedReturnPolicy_v3(r);report=auPick(r,{'accepted','acceptance_gates','full_closure'});
    report.classification=auPick(auMember(r,'classification',struct()),{'contract_version','canonical_point_label','canonical_label_qualified','validated_gait_type','flight_count','flight_count_certain'});
    report.options=struct('Residual',[]);
    if policy.complete
        report.correction_return_policy=struct('diagnostic_kind','runtime-object-descriptor','source_class',policy.configuration.source_class,'settings',policy.configuration.settings);
        [~,back]=RecordedReturnPolicy_v3(report);assert(back.complete&&auEqual(back.configuration,policy.configuration),'PKPost:ScreenPolicyView','The small actual screen context must roundtrip every recorded policy setting.');
    end
    assert(strcmp(OrbitContentIdentity_v3(o),OrbitContentIdentity_v3(small)),'PKPost:ScreenRecordView','The named literal screen view must retain the native identity-bearing values.');
    context=struct('native_id',OrbitContentIdentity_v3(o),'parameter',o.parameter,'mode',o.initial_mode,'section',o.section_chart, ...
        'complete_policy',policy,'cohort',cohort,'cohort_supported',cohortSupported,'return_multiplicity',o.return_multiplicity, ...
        'saved_current_all9_PK',admitted(r),'scope','Named small literal record/policy/admission/cohort view for pure screening; no native reports/trajectories retained in the candidate table.');
end
function yes=auLexLess(a,b),k=find(a~=b,1);yes=~isempty(k)&&a(k)<b(k);end
function v=auEmpty(x),if isempty(x),v=NaN;else,v=x;end,end

function r=auRole(rows,roles,name)
    at=find(strcmp(roles,name));assert(isscalar(at),'PKPost:Role','One explicit immutable source role is required.');r=rows{at}.reference;
end
function out=auReportSubset(template,full)
    assert(isstruct(template)&&isscalar(template)&&isstruct(full)&&isscalar(full),'PKPost:ReportShape','Compare only the old declared saved scalar report projection.');out=struct();
    for name=fieldnames(template).'
        key=name{1};assert(isfield(full,key),'PKPost:RetainedReportField','A declared old retained report field is missing from the actual union report.');v=full.(key);
        if ismember(key,{'classification','primitive'}),v=auHead(template.(key),v);end;out.(key)=v;
    end
end
function out=auHead(template,full)
    assert(isstruct(template)&&isscalar(template),'PKPost:RetainedHead','The old retained head must keep its actual scalar struct shape.');out=struct();names=fieldnames(template);
    if isempty(names),return;end
    assert(isstruct(full)&&isscalar(full)&&all(isfield(full,names)),'PKPost:RetainedHeadFields','Only actual fields retained by the old projection are compared.');
    for k=1:numel(names),out.(names{k})=full.(names{k});end
end
function out=auAdmission(r)
    out=auPick(r,{'accepted','acceptance_gates','full_closure'});g=auMember(r,'classification',struct());
    out.classification=auPick(g,{'contract_version','canonical_point_label','canonical_label_qualified','validated_gait_type','flight_count','flight_count_certain'});
    [~,policy]=RecordedReturnPolicy_v3(r);out.complete_policy=policy.complete;out.policy_configuration=policy.configuration;
end
function out=auRecord(o)
    out=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement, ...
        'return_policy_name',o.return_policy_name,'section_chart',o.section_chart,'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature);
end
function out=auPick(s,names)
    out=struct();if ~isstruct(s)||~isscalar(s),out.unsupported_source_class=class(s);out.unsupported_source_size=size(s);return;end
    for k=1:numel(names),if isfield(s,names{k}),out.(names{k})=s.(names{k});end,end
end
function out=auFields(s),if isstruct(s),out=fieldnames(s);else,out={['UNSUPPORTED_',class(s)]};end,end
function v=auMember(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end
function yes=auEqual(a,b),yes=strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b));end
function auSame(a,b),assert(auEqual(a,b),'PKPost:Typed','Complete declared typed values differ.');end
function auSave(file,audit),save(file,'audit','-v7');x=load(file,'audit');auSame(audit,x.audit);end
function f=auFailure(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function out=auUnresolved(e),out=struct('status','UNRESOLVED','observations_completed',false,'failure',auFailure(e));end
function r=auRef(file),r=struct('file',auLiteral(file),'sha256',RoundSHA256_v3(file));end
function p=auLiteral(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKPost:Alias','Hash and native read must address the same literal file.');end
function l=auLimit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function auCheck(l),assert(auUTC()<l.deadline_unix_seconds&&auNano()<l.deadline_monotonic_ns,'PKPost:Clock','Original1800/60 saved-data clock expired.');end
function t=auUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=auNano(),t=double(java.lang.System.nanoTime());end
function g=screen(source,target,pair,index,ix)
    g=struct('eligible',false,'source_pair',pair,'failure',struct(),'energy_chart_regularity','UNASSESSED_until_future_native_Run', ...
        'target_is_root_seed',false,'target_scope','Only selects the owned PAL plane.');
    try
        [a,ra,ma]=get(source,pair(1));[b,rb,mb]=get(source,pair(2));[t,rt,mt]=get(target,index);
        g.source_native_ids={OrbitContentIdentity_v3(a);OrbitContentIdentity_v3(b)};g.target_native_id=OrbitContentIdentity_v3(t);
        e=find(cellfun(@(z)isequal(sort([z.from,z.to]),sort(pair)),ix.edges));
        assert(isscalar(e)&&edgeOwner(ix,ix.edges{e})&&strcmp(ma.component_identity,mb.component_identity), ...
            'PKClosure:SourceEdge','Both explicit orientations must bind the same actual owned edge.');g.stored_edge=ix.edges{e};
        assert(admitted(ra)&&admitted(rb)&&admitted(rt),'PKClosure:Admission','Require literal saved current-contract one-flight PK/all9.');
        [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);[~,pt]=RecordedReturnPolicy_v3(rt);
        g.complete_policy_equal=pa.complete&&pb.complete&&pt.complete&&isequaln(pa.configuration,pb.configuration)&&isequaln(pb.configuration,pt.configuration);
        g.exact_pq=isequaln(a.parameter,b.parameter)&&isequaln(b.parameter,t.parameter)&&isequaln(a.initial_mode,b.initial_mode)&&isequaln(b.initial_mode,t.initial_mode);
        g.source_section=MatchingReturnSection_v3(a,b,{ra,rb});g.target_section=MatchingReturnSection_v3(b,t,{rb,rt});
        g.section_tokens_equal=isequaln(a.section_relative_event_signature,b.section_relative_event_signature)&&isequaln(b.section_relative_event_signature,t.section_relative_event_signature);
        g.cyclic_tokens_equal=isequaln(a.cyclic_event_signature,b.cyclic_event_signature)&&isequaln(b.cyclic_event_signature,t.cyclic_event_signature);
        assert(g.complete_policy_equal&&g.exact_pq&&g.source_section.compatible&&g.target_section.compatible ...
            &&g.section_tokens_equal&&g.cyclic_tokens_equal,'PKClosure:Contract','Exact saved policy/pq/marked-section/token contracts differ.');
        assert(~any(b.initial_mode)&&all(isfinite([a.initial_state(:);b.initial_state(:);t.initial_state(:)])), ...
            'PKClosure:FlightChart','Use actual all-flight raw states for the source-backed4D pronk calculation.');
        s=QuadrupedSchema_v3.shared();p=b.parameter(:);x=b.initial_state(:);parameter=s.Parameter;
        defects=[abs(x(s.State.dy)),norm(x([s.State.phi,s.State.dphi]),Inf), ...
            norm(x(s.Leg.AngleIndices)-x(s.State.alphaBL),Inf),norm(x(s.Leg.RateIndices)-x(s.State.dalphaBL),Inf), ...
            norm(p([parameter.k_l_b,parameter.k_s_b,parameter.l_l_b,parameter.rsla_b]) ...
                -p([parameter.k_l_f,parameter.k_s_f,parameter.l_l_f,parameter.rsla_f]),Inf),abs(p(parameter.l_com)-.5)];
        g.source_base_chart_defects=defects;
        assert(all(defects(1:4)<=1e-8)&&all(defects(5:6)<=1e-12), ...
            'PKClosure:PronkChart','The admitted base must satisfy the existing all-flight apex/pronk coordinate preconditions.');
        ids=[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL];
        assert(isequal(ids,[2,3,7,8]),'PKClosure:Coordinates','Retain the actual current four independent raw-coordinate indices.');
        ua=a.initial_state(ids);ua=ua(:);ub=b.initial_state(ids);ub=ub(:);ut=t.initial_state(ids);ut=ut(:);
        lift=b.initial_state(:);lift(ids)=ub;lift([9,11,13])=lift(7);lift([10,12,14])=lift(8);
        assert(isequaln(lift,b.initial_state(:)),'PKClosure:BaseLift','The unchanged admitted base must roundtrip exactly; no snap or projection.');
        scale=max([ones(4,1),abs(ua),abs(ub)],[],2);delta=(ub-ua)./scale;chord=norm(delta);
        assert(isfinite(chord)&&chord>1e-10,'PKClosure:Chord','Use a resolved actual preceding-pair chord.');tangent=delta/chord;
        ds=dot(tangent,(ut-ub)./scale);predictor=ub+scale.*(ds*tangent);
        g.coordinate_indices=ids;g.source_coordinates=[ua,ub];g.target_coordinates=ut;g.scale=scale;g.tangent=tangent;
        g.chord=chord;g.requested_step=ds;g.predictor_coordinates=predictor;g.predictor_distance=norm((ut-predictor)./scale);
        g.source_owner=ma.component_identity;g.target_owner=mt.component_identity;
        g.eligible=isfinite(ds)&&ds>=1e-7&&ds<=.04&&isfinite(g.predictor_distance)&&g.predictor_distance<=.001;
        g.scope='Run243-246 max1 preceding-pair scales and signed projection only; no abs(ds), automatic flip, target seed, Map or energy-pivot test.';
    catch e,g.failure=struct('identifier',e.identifier,'message',e.message);end
end
function [o,r,m]=get(d,index)
    k=find(d.indices==index);assert(isscalar(k),'PKClosure:SelectedIndex','One actual selected native view is required.');o=d.orbits{k};r=d.reports{k};m=d.metadata{k};
end
function yes=admitted(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    gates=member(r,'acceptance_gates',struct());g=member(r,'classification',struct());[~,version]=GaitSemanticTable_v3();
    yes=isequal(member(r,'accepted',false),true)&&all(isfield(gates,keys))&&strcmp(member(g,'contract_version',''),version) ...
        &&strcmp(member(g,'validated_gait_type',''),'PK')&&strcmp(member(g,'canonical_point_label',''),'PK') ...
        &&isequal(member(g,'canonical_label_qualified',false),true)&&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1);
    for k=1:numel(keys),yes=yes&&isequal(member(gates,keys{k},false),true);end
end
function yes=edgeOwner(ix,e)
    yes=e.from>=1&&e.to>=1&&e.from<=numel(ix.points)&&e.to<=numel(ix.points) ...
        &&strcmp(ix.points{e.from}.component_identity,e.component_identity)&&strcmp(ix.points{e.to}.component_identity,e.component_identity);
end
function v=member(s,k,d),if isstruct(s)&&isscalar(s)&&isfield(s,k),v=s.(k);else,v=d;end,end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end

function graphs=auGraphs(plan,reference)
    graphs=cell(numel(plan.components),1);seen=false(numel(plan.nodes),1);
    for k=1:numel(graphs)
        g=plan.components{k};selected=g.global_indices(:);ix=g.planned_materialization_index;
        assert(g.component_number==k&&numel(ix.points)==numel(selected)&&~any(seen(selected)) ...
            &&strcmp(C1ScientificDigest_v3(ix),g.planned_index_digest),'PKGraphAudit:Component','Each literal local planned index has one disjoint exact global selector list.');seen(selected)=true;
        for j=1:numel(selected)
            m=plan.occurrence_map{selected(j)};n=plan.nodes{selected(j)};
            assert(m.global_index==selected(j)&&m.component_number==k&&m.component_index==j&&m.source_index==n.source_index ...
                &&strcmp(m.source_file,plan.source_catalog{n.source_number}.file)&&strcmp(m.source_sha256,plan.source_catalog{n.source_number}.sha256) ...
                &&isequal(ix.points{j}.whole_public_data_readback_verified,false),'PKGraphAudit:GlobalLocal','The plan map is literal source/global/component/local bookkeeping; it claims no new raw readback.');
        end
        graphs{k}=struct('reference',auRef2(reference),'component_number',k,'global_indices',selected,'index',ix, ...
            'native_ids',{cellfun(@(n)n.native_ID,plan.nodes(selected),'UniformOutput',false)});
    end
    assert(all(seen),'PKGraphAudit:WholeView','All1036 original occurrences survive exactly once; component-local indices are not whole-view indices.');
end
function ix=auOriginalIndex(plan,r)
    at=find(cellfun(@(c)strcmp(c.file,r.file)&&strcmp(c.sha256,r.sha256),plan.source_catalog));
    assert(isscalar(at),'PKGraphAudit:OriginalSource','Use one exact original source catalogue generation.');c=plan.source_catalog{at};
    selected=find(cellfun(@(n)n.source_number==at,plan.nodes));indices=cellfun(@(n)n.source_index,plan.nodes(selected));
    [indices,order]=sort(indices);assert(isequal(indices(:),(1:c.stored_points).'),'PKGraphAudit:OriginalIndices','Every original source ordinal appears exactly once, without NativeID collapse.');
    ix=struct('storage_version','BranchSolutionFile_v3:2','metadata',c.metadata,'points',{cellfun(@(n)n.point,plan.nodes(selected(order)),'UniformOutput',false)},'edges',{c.original_edges});
end
function m=auMap(plan,r,index)
    at=find(cellfun(@(m)strcmp(m.source_file,r.file)&&strcmp(m.source_sha256,r.sha256)&&m.source_index==index,plan.occurrence_map));
    assert(isscalar(at),'PKPost:OccurrenceMap','Exact source FILE/SHA/INDEX must map uniquely; no NativeID-nearest matching.');m=plan.occurrence_map{at};
    assert(m.global_index==at&&plan.components{m.component_number}.global_indices(m.component_index)==m.global_index, ...
        'PKGraphAudit:MapRoundtrip','Source/global/component/local selector joins must roundtrip literally.');
end
function [g,a,b]=auSameComponent(graphs,left,right)
    assert(left.component_number==right.component_number,'PKPost:SameComponent','The mapped occurrences must share an actual planned all-layer component.');
    g=find(cellfun(@(v)v.component_number==left.component_number,graphs));assert(isscalar(g),'PKPost:GraphReference','One exact planned component graph is required.');a=left.component_index;b=right.component_index;
end
function requests=auRequests(mf,rows,roles)
    requests=cell(0,1);
    for k=1:numel(mf.historical_obligations)
        item=mf.historical_obligations{k};h=item.literal;
        requests{end+1,1}=struct('id',h.id,'journal_row',h.journal_row,'reference',h.source_reference,'ordered_pair',h.pair, ...
            'literal_direction',auMember(h.historical_frontier_state,'direction',struct('status','UNAVAILABLE')), ...
            'literal_historical_disposition',item.new_disposition,'literal_history_locator',h.history_locator, ...
            'literal_frontier_state',h.historical_frontier_state,'scope','Historical registration only; later0061 science is separate opaque provenance.'); %#ok<AGROW>
    end
    r=auRole(rows,roles,'original0061');
    for pair={[54,55],[56,57]},v=pair{1};requests{end+1,1}=struct('id',sprintf('explicit_original0061_%d_%d',v),'journal_row',[], ...
            'reference',r,'ordered_pair',v,'literal_direction',struct('status','EXPLICIT_ORDER_ONLY'), ...
            'literal_historical_disposition','EXPLICIT_SELECTED_PAIR_NOT_A_NEW_DISPOSITION','literal_history_locator',struct(), ...
            'literal_frontier_state',struct(),'scope','Exact original endpoints; fresh fixed-engine replay and new forks are separate authorities.');end
end
function globals=auMeetingGlobals(rows,roles,plan)
    selectors={'latest0170',16;'join_fork',2;'join_fork',3;'grown0072',53;'grown0072',54};globals=zeros(size(selectors,1),1);
    for k=1:size(selectors,1),r=auRole(rows,roles,selectors{k,1});m=auMap(plan,r,selectors{k,2});globals(k)=m.global_index;end
end
function [cache,observation]=auAcquire(view,plan,oldInfo,headerGlobals,meetingGlobals,clock)
    N=numel(plan.nodes);cache=struct('orbits',{cell(N,1)},'reports',{cell(N,1)},'contexts',{cell(N,1)},'headers',{cell(N,1)}, ...
        'full_orbit_digests',{cell(N,1)},'full_report_digests',{cell(N,1)},'old_rows',{cell(494,1)},'verified',false(N,1),'maximum_original_source_records',0);
    observation=struct('schema','PK30h-two-pass-original-source-acquisition-v1','completed',false,'source_passes_completed',0, ...
        'actual_public_group_calls_returned',0,'per_pass_coverage',false(N,2),'maximum_original_source_records',0, ...
        'native_cache_shared_across_passes',false,'independence_handle_witness_records',1,'failure',struct(), ...
        'scope','Each pass uses shared source-view groups/load, whole original source once; native group released after small literal projections. Actual largest source may be485; no universal16 or RSS claim.');
    groups=C1StoredComponentSource_v3.groups(view,(1:N).');signatures=cell(N,1);witness=[];
    try
        for pass=1:2
            for groupNumber=1:numel(groups)
                group=groups{groupNumber};auCheck(clock);
                [os,rs,ms]=C1StoredComponentSource_v3.load(view,group.indices);observation.actual_public_group_calls_returned=observation.actual_public_group_calls_returned+1;
                observation.maximum_original_source_records=max(observation.maximum_original_source_records,numel(group.indices));
                fprintf('PK30H_GRAPH_AUDIT_SOURCE_RETURN pass=%d source=%d/%d records=%d\n',pass,groupNumber,numel(groups),numel(group.indices));
                for within=1:numel(group.indices)
                    n=group.indices(within);o=os{within};r=rs{within};node=plan.nodes{n};
                    if n==1
                        if pass==1,witness=o;else,assert(~(witness==o),'PKGraphAudit:IndependentSource','Second pass must deserialize an independent original native handle.');end
                    end
                    try,[small,report,context]=auScreenView(o,r);context.supported=true;
                    catch e,small=struct();report=struct();context=struct('supported',false,'saved_current_all9_PK',admitted(r),'failure',auFailure(e));end
                    projected=struct('orbit',small,'report',report,'context',context,'original_owner',node.point.component_identity,'native_id',OrbitContentIdentity_v3(o));
                    assert(strcmp(projected.native_id,node.native_ID),'PKGraphAudit:OriginalID','The actual original native record must retain its exact acquired plan ID.');
                    signature=C1ScientificDigest_v3(projected);
                    if pass==1,cache.orbits{n}=small;cache.reports{n}=report;cache.contexts{n}=context;signatures{n}=signature;
                    else,assert(strcmp(signature,signatures{n}),'PKGraphAudit:TwoPassProjection','Independent native acquisitions must retain every literal small record/policy/cohort/admission projection.');end
                    if ismember(n,headerGlobals)
                        try,h=auEndpointHeader(o,r,node.point.metadata,node.point);catch e,h=struct('status','UNASSESSED_UNSUPPORTED_HEADER','failure',auFailure(e));end
                        if pass==1,cache.headers{n}=h;else,auSame(cache.headers{n},h);end
                    end
                    if ismember(n,meetingGlobals)
                        orbitDigest=C1ScientificDigest_v3(public(o));reportDigest=C1ScientificDigest_v3(r);
                        if pass==1,cache.full_orbit_digests{n}=orbitDigest;cache.full_report_digests{n}=reportDigest;
                        else,assert(strcmp(cache.full_orbit_digests{n},orbitDigest)&&strcmp(cache.full_report_digests{n},reportDigest), ...
                                'PKGraphAudit:MeetingRead2','All public native properties and full original source reports of the finite meeting selectors must agree independently.');end
                    end
                    if oldInfo.enabled&&oldInfo.global_to_old(n)>0
                        k=oldInfo.global_to_old(n);try,row=auOldProjection(oldInfo.core,k,oldInfo.maps{k},o,r);catch e,row=struct('all_retained_values_equal',false,'failure',auFailure(e));end
                        if pass==1,cache.old_rows{k}=row;else,auSame(cache.old_rows{k},row);end
                    end
                    observation.per_pass_coverage(n,pass)=true;if pass==2,cache.verified(n)=true;end
                end
                clear os rs ms o r small report context projected h row
            end
            assert(all(observation.per_pass_coverage(:,pass)),'PKGraphAudit:PassCoverage','Every actual original occurrence must be acquired once in each independent pass.');
            observation.source_passes_completed=pass;
        end
        observation.completed=true;
    catch e,observation.failure=auFailure(e);end
    cache.maximum_original_source_records=observation.maximum_original_source_records;clear witness
end
function [orbits,reports,globals]=auCached(cache,plan,reference,indices)
    orbits=cell(numel(indices),1);reports=orbits;globals=zeros(numel(indices),1);
    for k=1:numel(indices)
        m=auMap(plan,reference,indices(k));n=m.global_index;assert(cache.verified(n)&&~isempty(cache.orbits{n})&&cache.contexts{n}.supported, ...
            'PKGraphAudit:CachedSource','Require two independently verified original acquisitions of this exact literal selector.');
        orbits{k}=cache.orbits{n};reports{k}=cache.reports{n};globals(k)=n;
    end
end
function out=auComponents(plan,graphs,cache)
    out=cell(numel(graphs),1);
    for k=1:numel(graphs)
        g=graphs{k};[tables,~]=auTables(g.index);selected=g.global_indices;maps=plan.occurrence_map(selected);current=0;supported=0;
        for j=selected(:).',if ~isempty(cache.contexts{j}),current=current+double(cache.contexts{j}.saved_current_all9_PK);supported=supported+double(cache.verified(j)&&cache.contexts{j}.supported);end,end
        out{k}=struct('graph_reference',g.reference,'component_number',g.component_number,'occurrences',numel(selected),'global_indices',selected, ...
            'P_E_A_M_counts',cellfun(@(p)size(p,1),tables).','source_occurrence_maps',{maps},'unique_native_ID_count',numel(unique(g.native_ids)), ...
            'recorded_current_contract_all9_PK_count',current,'two_pass_supported_contexts',supported,'fully_native_observed',all(cache.verified(selected)), ...
            'scope','All six graph components; saved admission is recorded epoch only. Distinct component2 and zero-P components are not connected or discharged by scalar ranges.');
    end
end
function out=auEndpoints(requests,plan,cache)
    rows=cell(numel(requests),1);
    for k=1:numel(requests)
        q=requests{k};ix=auOriginalIndex(plan,q.reference);headers=cell(2,1);maps=cell(2,1);
        for j=1:2,m=auMap(plan,q.reference,q.ordered_pair(j));maps{j}=m;headers{j}=cache.headers{m.global_index};end
        edge=find(cellfun(@(e)isequal(sort([e.from,e.to]),sort(q.ordered_pair(:).')),ix.edges));owned=struct();orientation='UNASSESSED_NO_UNIQUE_OWNED_P';
        if isscalar(edge)
            e=ix.edges{edge};assert(edgeOwner(ix,e),'PKGraphAudit:EndpointOwner','A historical unordered pair needs its actual same-owner P row.');owned=e;
            if isequal([e.from,e.to],q.ordered_pair(:).'),orientation='HISTORICAL_ORDER_EQUALS_STORED_P';else,orientation='HISTORICAL_ORDER_REVERSES_STORED_P';end
        end
        rows{k}=struct('request',q,'full_native_headers',{headers},'graph_maps',{maps},'actual_owned_physical_edge',owned, ...
            'historical_orientation_against_owned_P',orientation,'two_pass_native_verified',all(cache.verified(cellfun(@(m)m.global_index,maps))), ...
            'new_disposition_or_direction_authorized',false);
    end
    out=struct('status','LITERAL13_AND_EXPLICIT0061_REGISTERED_PAIRS_OBSERVED','observations_completed',true,'rows',{rows}, ...
        'explicit0061_pairs',[54,55;56,57],'scope','Original13 statuses/HOLD/ladder/direction/history remain literal. Later new0061 queues are outside this source universe and never blocked by this audit.');
end
function yes=auRefEqual(a,b),yes=isstruct(a)&&isscalar(a)&&isstruct(b)&&isscalar(b)&&all(isfield(a,{'file','sha256'}))&&all(isfield(b,{'file','sha256'}))&&strcmp(a.file,b.file)&&strcmp(a.sha256,b.sha256);end
function r=auRef2(r),r=struct('file',r.file,'sha256',r.sha256);end
function auVerify(refs)
    for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,auLiteral(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
            'PKPost:Changed','A currently consumed immutable original/graph/source/reference changed. Historical source epochs are not demanded against replaced live paths.');
        if isfield(r,'bytes'),d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes,'PKGraphAudit:ReferenceBytes','Retain actual declared whole-file bytes across2/3-field headers.');end
    end
end

function out=auTargets(rows,roles,plan,graphs,cache,requests,supplemental,clock)
    names={'original0060';'original0064';'original0159'};targets=cell(0,1);inventory=cell(3,1);keys=cell(0,1);sourceContexts=cell(numel(graphs),1);selectedTargets=cell(0,1);
    for k=1:3
        r=auRole(rows,roles,names{k});ix=auOriginalIndex(plan,r);assert(isempty(ix.edges),'PKPost:ZeroP','Only the actual zero-P stores enter this inventory target set.');heads=cell(numel(ix.points),1);
        for n=1:numel(ix.points)
            m=auMap(plan,r,n);heads{n}=cache.headers{m.global_index};selectedTargets{end+1,1}=struct('reference',r,'index',n,'role',names{k},'purpose','ZERO_P_ACTUAL_RECORD_TARGET_ONLY'); %#ok<AGROW>
        end
        inventory{k}=struct('role',names{k},'reference',r,'all_occurrences',numel(ix.points),'physical_edges',0,'headers',{heads});
    end
    for k=1:numel(requests)
        q=requests{k};selectedTargets{end+1,1}=struct('reference',q.reference,'index',q.ordered_pair(2),'role',q.id,'purpose','LITERAL_REGISTERED_ORDERED_HEAD_TARGET_ONLY'); %#ok<AGROW>
    end
    intake=cell(numel(selectedTargets),1);
    for k=1:numel(selectedTargets)
        selector=selectedTargets{k};m=auMap(plan,selector.reference,selector.index);n=m.global_index;
        intake{k}=struct('selector',selector,'graph_mapping',m,'status','UNASSESSED_SOURCE_CONTEXT_UNAVAILABLE');
        if ~cache.verified(n)||isempty(cache.contexts{n})||~cache.contexts{n}.supported,continue;end
        context=cache.contexts{n};
        if ~context.saved_current_all9_PK||~context.complete_policy.complete,intake{k}.status='UNASSESSED_RECORDED_PK_ALL9_OR_COMPLETE_POLICY_UNSUPPORTED';continue;end
        small=cache.orbits{n};report=cache.reports{n};recordKey=C1ScientificDigest_v3(struct('record',auRecord(small),'policy',context.complete_policy.configuration));
        key=C1ScientificDigest_v3(struct('record_policy_digest',recordKey,'cohort',context.cohort,'return_multiplicity',context.return_multiplicity,'component_number',m.component_number));
        at=find(strcmp(keys,key));selector.graph_mapping=m;
        if isempty(at)
            node=plan.nodes{n};targets{end+1,1}=struct('selectors',{{selector}},'orbit',small,'report',report,'context',context, ...
                'metadata',struct('component_identity',node.point.component_identity),'point',struct('index',selector.index), ...
                'record_policy_digest',recordKey,'context_dedup_digest',key,'component',m.component_number,'rows',zeros(0,9),'failures',{{}},'best',struct());keys{end+1,1}=key; %#ok<AGROW>
        else,targets{at}.selectors{end+1,1}=selector;end
        intake{k}.status='RECORDED_PK_TARGET_ONLY_CONTEXT_SUPPORTED';
    end
    if isempty(targets)
        out=struct('status','UNASSESSED_no_supported_recorded_PK_targets','observations_completed',true,'zero_P_source_inventory',{inventory}, ...
            'target_intake',{intake},'unique_recorded_PK_targets',0,'source_contexts',{{}},'targets',{{}},'prospective_Acquire_selectors',{{}}, ...
            'maximum_proposals',2,'native_calls_authorized',false,'fresh_engine_admission_claimed',false, ...
            'scope','Unsupported saved target context is UNASSESSED; no nonexistence, completion or automatic one-point initialization claim.');return
    end
    donors=auDonors(plan,graphs,cache,supplemental);sourceContexts=cell(numel(donors),1);
    for g=1:numel(donors)
        donor=donors{g};ix=donor.index;if isempty(ix.edges),continue;end
        selected=unique(cell2mat(cellfun(@(e)[e.from;e.to],ix.edges,'UniformOutput',false)),'stable');auCheck(clock);
        plainOrbits=donor.orbits(selected);plainReports=donor.reports(selected);contexts=donor.contexts(selected);metadata=donor.metadata(selected);
        sourceCache=struct('indices',selected,'orbits',{plainOrbits},'reports',{plainReports},'metadata',{metadata});
        sourceContexts{g}=struct('donor_reference',donor.reference,'source_kind',donor.source_kind,'component_number',donor.component_number, ...
            'local_indices',selected,'source_epoch',donor.source_epoch,'point_contexts',{contexts},'two_pass_verified',donor.verified(selected), ...
            'graph_membership_inferred',false);
        for t=1:numel(targets)
            if strcmp(donor.source_kind,'ORIGINAL_GRAPH_COMPONENT')&&targets{t}.component==donor.component_number,continue;end
            z=targets{t};one=struct('indices',z.point.index,'orbits',{{z.orbit}},'reports',{{z.report}},'metadata',{{z.metadata}});
            for e=1:numel(ix.edges)
                edge=ix.edges{e};pairs=[edge.from,edge.to;edge.to,edge.from];
                for orientation=1:2
                    auCheck(clock);full13=[];
                    try
                        ai=find(selected==pairs(orientation,1));bi=find(selected==pairs(orientation,2));ca=contexts{ai};cb=contexts{bi};ct=z.context;
                        assert(donor.verified(selected(ai))&&donor.verified(selected(bi))&&ca.supported&&cb.supported&&ct.supported ...
                            &&ca.cohort_supported&&cb.cohort_supported&&ct.cohort_supported&&auEqual(ca.cohort,cb.cohort)&&auEqual(cb.cohort,ct.cohort) ...
                            &&isequaln(ca.return_multiplicity,cb.return_multiplicity)&&isequaln(cb.return_multiplicity,ct.return_multiplicity), ...
                            'PKPost:CohortMultiplicity','Require actual nonempty symbolic cohort/multiplicity compatibility; no event-time equality or defaults-as-evidence.');
                        candidate=screen(sourceCache,one,pairs(orientation,:),z.point.index,ix);
                    catch err,candidate=struct('eligible',false,'failure',auFailure(err));end
                    if candidate.eligible
                        base=plainOrbits{bi};pred=base.initial_state;pred(candidate.coordinate_indices)=candidate.predictor_coordinates;
                        pred([9,11,13])=pred(7);pred([10,12,14])=pred(8);scale=max([ones(13,1),abs(pred(2:14)),abs(z.orbit.initial_state(2:14))],[],2);
                        full13=norm((pred(2:14)-z.orbit.initial_state(2:14))./scale,Inf);candidate.full13_predictor_target_scaled_inf=full13;
                        candidate.PAL_normal=[candidate.tangent./candidate.scale;0];candidate.base_nativeE_index=ix.points{pairs(orientation,2)}.nativeE;
                        candidate.full13_scope='Separate prospective full-state eligibility observation only; never feeds or renormalizes the Run4D scale/normal/ds.';
                        candidate.eligible=full13<=.001;
                    end
                    targets{t}.rows(end+1,:)=[g,pairs(orientation,:),orientation,double(candidate.eligible),auMember(candidate,'requested_step',NaN), ...
                        auMember(candidate,'predictor_distance',NaN),auEmpty(full13),double(isempty(fieldnames(candidate.failure)))];
                    targets{t}.failures{end+1,1}=auMember(candidate.failure,'identifier','');
                    if candidate.eligible
                        best=targets{t}.best;
                        score=[full13,candidate.predictor_distance,g,e,orientation];
                        if isempty(fieldnames(best))||auLexLess(score,best.score)
                            sourcePair=pairs(orientation,:);na=donor.original_nodes{sourcePair(1)};nb=donor.original_nodes{sourcePair(2)};
                            assert(na.source_number==nb.source_number,'PKGraphAudit:ProposalSource','The actual owned P must originate inside one literal immutable source.');
                            sourceCatalogue=donor.source_catalog{na.source_number};sourceRef=struct('file',sourceCatalogue.file,'sha256',sourceCatalogue.sha256);originalPair=[na.source_index,nb.source_index];
                            if strcmp(donor.source_kind,'ORIGINAL_GRAPH_COMPONENT'),originalIndex=auOriginalIndex(plan,sourceRef);else,originalIndex=donor.index;end;sourceEdge=find(cellfun(@(z)isequal(sort([z.from,z.to]),sort(originalPair)),originalIndex.edges));
                            assert(isscalar(sourceEdge)&&edgeOwner(originalIndex,originalIndex.edges{sourceEdge}),'PKGraphAudit:ProposalPhysicalEdge','Preserve the literal original same-owner P and explicit orientation; no edge is created by closeness.');
                            targets{t}.best=struct('score',score,'source_reference',sourceRef,'source_pair',originalPair, ...
                                'original_graph_component_number',donor.component_number,'donor_local_pair',sourcePair,'donor_source_epoch',donor.source_epoch, ...
                                'graph_membership_inferred',false, ...
                                'target_selectors',{z.selectors},'geometry',candidate,'actual_stored_edge',originalIndex.edges{sourceEdge},'planned_stored_edge',edge,'target_is_root_seed',false, ...
                                'fresh_engine_all9_qualification_claimed',false,'new_experiment_review_required',true);
                        end
                    end
                end
            end
        end
    end
    observed=cell(numel(targets),1);rank=zeros(0,6);
    for t=1:numel(targets)
        z=targets{t};observed{t}=struct('target_selectors',{z.selectors},'target_native_id',OrbitContentIdentity_v3(z.orbit), ...
            'record_policy_digest',z.record_policy_digest,'context_dedup_digest',z.context_dedup_digest, ...
            'compact_screen_rows',z.rows,'failure_identifiers',{z.failures},'best',z.best);
        if ~isempty(fieldnames(z.best)),rank(end+1,:)=[z.best.score,t];end %#ok<AGROW>
    end
    proposals=cell(0,1);if ~isempty(rank),rank=sortrows(rank,1:5);for k=1:min(2,size(rank,1)),proposals{k,1}=observed{rank(k,6)}.best;end,end
    out=struct('status','BOUNDED_TARGET_ONLY_SCREEN_COMPLETED','observations_completed',true,'zero_P_source_inventory',{inventory},'target_intake',{intake}, ...
        'unique_recorded_PK_targets',numel(targets),'source_contexts',{sourceContexts},'targets',{observed},'screen_columns',{{'donor_ordinal';'source_from';'source_to';'orientation';'eligible';'signed_ds';'predictor4D_norm';'predictor_full13_scaled_inf';'context_checks_no_exception'}}, ...
        'prospective_Acquire_selectors',{proposals},'maximum_proposals',2,'maximum_original_source_records',cache.maximum_original_source_records,'native_calls_authorized',false,'fresh_engine_admission_claimed',false,'single_point_initializer_proposed',false, ...
        'scope','RECORDED admission epoch only. Zero-P original records and literal registered heads are targets only; each best source is an actual original FILE/SHA/ordered P pair. Full record/policy/section context, unchanged signed4D PAL donor(.04/.001), full13 predictor check<=.001. No speed/NID-nearest ranking, target seeding, arbitrary edge import, Root/Map call, energy-pivot or nonexistence claim.');
end

function [out,refs]=auOptionalStorage(reference,plan,graphReference,clock)
    refs=cell(0,1);out=struct('status','UNASSESSED_NOT_REQUESTED','optional',true,'graph_science_gate',false,'completed_Core_set_claimed',false);
    assert(isstruct(reference)&&isscalar(reference),'PKGraphAudit:OptionalStorageReference','Use an explicit exact reference or literal empty scalar struct.');
    if isempty(fieldnames(reference)),return;end
    try
    auVerify({reference});refs={reference};auCheck(clock);x=load(reference.file,'manifest','manifest_digest');m=x.manifest;
    assert(strcmp(C1ScientificDigest_v3(m),x.manifest_digest)&&strcmp(m.schema,'PK30h-direct-stored-core-set-v1') ...
        &&auRefEqual(m.plan_reference,graphReference)&&m.whole_occurrence_count==1036&&m.component_count==6 ...
        &&~m.raw_trajectory_materialization_claimed&&~m.scientific_completion_claimed&&~m.source_retirement_authorized, ...
        'PKGraphAudit:OptionalManifest','Observe literal CoreSet results, including failure/incompleteness, without turning them into a graph/science gate.');clear x
    rows=cell(numel(m.core_rows),1);
    for k=1:numel(m.core_rows)
        auCheck(clock);row=m.core_rows{k};component=row.component_number;selected=plan.components{component}.global_indices(:);N=numel(selected);r=row.actual_returned_receipt;
        assert(row.actual_helper_returned&&isequal(row.global_indices(:),selected)&&auRefEqual(r.source_reference,graphReference) ...
            &&strcmp(r.source_kind,'composite-graph-plan')&&r.source_point_count==1036&&r.point_count==N ...
            &&isequal(r.source_indices(:),selected)&&isequal(r.occurrence_map,[selected,(1:N).']), ...
            'PKGraphAudit:CoreGlobalJoin','Each actual prefix Core joins whole-view1036/global source indices to local expected indices, never raw1:N source assumptions.');
        auVerify({row.core_reference;row.audit_reference});refs=[refs;{row.core_reference;row.audit_reference}]; %#ok<AGROW>
        x=load(row.audit_reference.file,'receipt');returnedOnly={'audit_publication_returned','elapsed_seconds','final_return_timely'};
        assert(all(isfield(r,returnedOnly)),'PKGraphAudit:ReturnedReceipt','Manifest retains actual API return-only publication/timing fields.');
        savedProjection=rmfield(r,returnedOnly);auSame(x.receipt,savedProjection);clear x
        x=load(row.core_reference.file,'solution_core29','core_digest');c=x.solution_core29;
        assert(strcmp(C1ScientificDigest_v3(c),x.core_digest)&&c.point_count==N&&c.original_v2_bytes==110861&&c.maximum_core_bytes==554305 ...
            &&isequal(size(c.solution_matrix),[29,N])&&auRefEqual(c.source_reference,graphReference), ...
            'PKGraphAudit:OptionalCoreDigest','The optional published Core retains its whole original value digest/schema/reference/cap.');clear x
        ids=cellfun(@(n)n.native_ID,plan.nodes(selected),'UniformOutput',false);auSame(ids,c.native_ids);map=zeros(numel(plan.nodes),1);map(selected)=1:N;
        for j=1:N
            context=c.contexts{j};point=plan.view_index.points{selected(j)};
            assert(context.expected_index==j&&context.source_index==selected(j)&&auRefEqual(context.source_reference,graphReference) ...
                &&strcmp(context.native_id,ids{j})&&isequaln(c.point_metadata{j}.order,point.order) ...
                &&strcmp(c.point_metadata{j}.component_identity,point.component_identity), ...
                'PKGraphAudit:OptionalCoreContext','Core context ordinal is local; original plan source index and literal point.order are global.');
            if isfield(point.metadata,'edge_from')
                assert(c.point_metadata{j}.edge_enabled&&c.point_metadata{j}.edge_from==map(point.metadata.edge_from), ...
                    'PKGraphAudit:OptionalParent','Only physical predecessor bookkeeping is remapped to the actual component-local Core ordinal.');
            end
        end
        [tables,evidence]=auTables(plan.components{component}.planned_materialization_index);kinds={'physical_edges','record_equalities','qualified_aliases','numerical_seams'};
        for kind=1:4
            actual=c.graph.(kinds{kind});assert(numel(actual)==size(tables{kind},1),'PKGraphAudit:OptionalGraphCount','Each typed relation count remains separate.');
            for j=1:numel(actual)
                e=actual{j};assert(isequal([e.from,e.to],tables{kind}(j,:)),'PKGraphAudit:OptionalGraphMap','Exact directed/local relation endpoints must survive.');
                if kind==1
                    originalGlobal=evidence{kind}{j};originalGlobal.from=selected(originalGlobal.from);originalGlobal.to=selected(originalGlobal.to);auSame(e.original_edge,originalGlobal);
                    assert(e.source_from==originalGlobal.from&&e.source_to==originalGlobal.to&&auRefEqual(e.source_reference,graphReference), ...
                        'PKGraphAudit:OptionalPhysicalGlobal','Core local P endpoints retain the original global graph selectors in source bookkeeping.');
                else,auSame(e.evidence,evidence{kind}{j});assert(strcmp(e.from_native_id,ids{e.from})&&strcmp(e.to_native_id,ids{e.to}), ...
                        'PKGraphAudit:OptionalGraphIDs','Nonphysical relation rows retain both exact source IDs and their original evidence.');end
            end
        end
        actual=dir(row.core_reference.file);assert(actual.bytes==r.core_bytes&&strcmp(row.core_reference.sha256,r.core_sha256)&&actual.bytes<=c.maximum_core_bytes, ...
            'PKGraphAudit:OptionalCoreBytes','Only actual complete prefix Core files have measured whole-file cap evidence.');
        rows{k}=struct('component_number',component,'global_indices',selected,'core_reference',row.core_reference,'audit_reference',row.audit_reference, ...
            'literal_actual_helper_returned',row.actual_helper_returned,'literal_receipt_flags',auPick(r,{'completed','source_posthash','source_passes_completed','retained_projection_read2', ...
            'stage_native_read2','installed_native_read2','loader_smoke_returned','audit_publication_returned','final_return_timely','core_bytes','maximum_core_bytes'}), ...
            'saved_audit_omits_return_only_fields',{returnedOnly},'actual_prefix_native_load_typed_digest_verified',true, ...
            'exact_original_global_local_ids_and_typed_graph_verified',true,'fresh_native_source_projection_recomputed_for_Core',false);
        clear c
    end
    out=struct('status','OPTIONAL_CORE_PREFIX_LITERAL_OBSERVATIONS','optional',true,'reference',reference,'literal_manifest_completed',m.completed, ...
        'literal_manifest_source_posthash',m.source_posthash,'literal_manifest_failure',m.failure,'actual_recorded_prefix_count',numel(m.core_rows), ...
        'declared_component_count',m.component_count,'rows',{rows},'graph_science_gate',false,'completed_Core_set_claimed',false, ...
        'scope','Optional saved storage facts only. An incomplete2/6 manifest/retained oversize stage remains failure/working data. No cap relaxation, six-Core requirement, rawConso completion, new all9 or frontier retirement claim.');
    catch e,out=struct('status','UNRESOLVED_OPTIONAL_STORAGE','optional',true,'graph_science_gate',false,'failure',auFailure(e),'completed_Core_set_claimed',false);end
end

function [sources,observation,refs]=auSupplemental(rows,clock)
    sources=cell(0,1);refs=cell(0,1);facts=cell(numel(rows),1);
    for sourceNumber=1:numel(rows)
        row=rows{sourceNumber};facts{sourceNumber}=struct('status','UNASSESSED','row',row,'failure',struct(),'source_passes_completed',0,'actual_group_calls_returned',0,'maximum_native_group_records',0);
        try
            assert(isstruct(row)&&isscalar(row)&&isequal(sort(fieldnames(row)),sort({'reference';'closure_reference';'actual_process_exit_observed';'actual_exit_code'})) ...
                &&isequal(row.actual_process_exit_observed,true)&&isequal(row.actual_exit_code,0), ...
                'PKGraphAudit:ClosedSupplemental','Caller must supply an explicit immutable closed Branch generation and actual0 closure authority; no live growing file intake.');
            refs=[refs;{row.reference;row.closure_reference}];auVerify({row.reference;row.closure_reference});auCheck(clock); %#ok<AGROW>
            view=C1StoredComponentSource_v3.prepare(auRef2(row.reference));assert(strcmp(view.kind,'raw-branch'),'PKGraphAudit:SupplementalBranch','Supplemental donors are actual closed Branch files, not inferred graph views.');refs=[refs;view.input_references]; %#ok<AGROW>
            ix=C1StoredComponentSource_v3.index(view);N=numel(ix.points);groups=C1StoredComponentSource_v3.groups(view,(1:N).');signatures=cell(N,1);
            smallOrbits=cell(N,1);smallReports=smallOrbits;contexts=smallOrbits;metadata=smallOrbits;verified=false(N,1);witness=[];
            for pass=1:2
                coverage=false(N,1);
                for bulk=1:numel(groups)
                    group=groups{bulk};auCheck(clock);[os,rs,ms]=C1StoredComponentSource_v3.load(view,group.indices);facts{sourceNumber}.actual_group_calls_returned=facts{sourceNumber}.actual_group_calls_returned+1;
                    facts{sourceNumber}.maximum_native_group_records=max(facts{sourceNumber}.maximum_native_group_records,numel(group.indices));
                    for within=1:numel(group.indices)
                        n=group.indices(within);
                        if n==1,if pass==1,witness=os{within};else,assert(~(witness==os{within}),'PKGraphAudit:SupplementalRead2','Independent supplemental passes deserialize separate original native handles.');end,end
                        [o,r,c]=auScreenView(os{within},rs{within});c.supported=true;signature=C1ScientificDigest_v3(struct('orbit',o,'report',r,'context',c,'metadata',ms{within}));
                        if pass==1,smallOrbits{n}=o;smallReports{n}=r;contexts{n}=c;metadata{n}=struct('component_identity',ms{within}.component_identity);signatures{n}=signature;
                        else,assert(strcmp(signatures{n},signature),'PKGraphAudit:SupplementalProjection','Both closed-source passes must preserve exact native record/policy/cohort/admission values.');verified(n)=true;end
                        coverage(n)=true;
                    end
                    clear os rs ms o r c
                end
                assert(all(coverage),'PKGraphAudit:SupplementalCoverage','All literal supplemental source occurrences are acquired once per pass.');facts{sourceNumber}.source_passes_completed=pass;
            end
            auVerify({row.reference;row.closure_reference});facts{sourceNumber}.status='CLOSED_DONOR_TWO_PASS_OBSERVED';clear witness
            sources{end+1,1}=struct('reference',auRef2(row.reference),'source_kind','CLOSED_SUPPLEMENTAL_BRANCH','component_number',[], ...
                'index',ix,'original_nodes',{view.nodes},'source_catalog',{view.source_catalog},'orbits',{smallOrbits},'reports',{smallReports},'contexts',{contexts}, ...
                'metadata',{metadata},'verified',verified,'source_epoch',struct('source_reference',row.reference,'external_closed_reference',row.closure_reference, ...
                'recorded_admission_epoch_only',true,'membership_in_original1036_graph','UNASSESSED_NOT_INFERRED')); %#ok<AGROW>
        catch e,facts{sourceNumber}.failure=auFailure(e);end
    end
    observation=struct('status','BOUNDED_OPTIONAL_CLOSED_DONOR_INTAKE','rows',{facts},'actual_supported_donor_sources',numel(sources),'maximum_sources',2, ...
        'original_graph_occurrences_unchanged',1036,'graph_membership_or_connection_inferred',false,'fresh_qualification_claimed',false, ...
        'scope','Caller-owned actual0 closure and immutable source SHA required; historical/new source epochs are explicit. No live CP/output intake, graph append, source retirement or new admission.');
end
function donors=auDonors(plan,graphs,cache,supplemental)
    donors=cell(numel(graphs),1);
    for k=1:numel(graphs)
        selected=graphs{k}.global_indices;metadata=cell(numel(selected),1);for j=1:numel(selected),metadata{j}=struct('component_identity',plan.nodes{selected(j)}.point.component_identity);end
        donors{k}=struct('reference',graphs{k}.reference,'source_kind','ORIGINAL_GRAPH_COMPONENT','component_number',k,'index',graphs{k}.index, ...
            'original_nodes',{plan.nodes(selected)},'source_catalog',{plan.source_catalog},'orbits',{cache.orbits(selected)},'reports',{cache.reports(selected)}, ...
            'contexts',{cache.contexts(selected)},'metadata',{metadata},'verified',cache.verified(selected), ...
            'source_epoch',struct('graph_reference',graphs{k}.reference,'component_number',k,'recorded_admission_epoch_only',true));
    end
    donors=[donors;supplemental];
end

function a=auFiniteAdmission(r)
    [~,policy]=RecordedReturnPolicy_v3(r);g=r.classification;
    assert(admitted(r)&&policy.complete,'PKGraphAudit:RecordedMAdmission','Use only literal recorded PK/all9 and complete policy configuration, never fresh engine admission.');
    a=struct('accepted',r.accepted,'acceptance_gates',r.acceptance_gates,'full_closure',r.full_closure, ...
        'classification',struct('contract_version',g.contract_version,'canonical_point_label',g.canonical_point_label, ...
        'canonical_label_qualified',g.canonical_label_qualified,'validated_gait_type',g.validated_gait_type, ...
        'flight_count',g.flight_count,'flight_count_certain',g.flight_count_certain),'policy_configuration',policy.configuration);
end
