function cfg=AssemblePK30hUnionCfg20261101(listRef,bindings,B,options)
%ASSEMBLEPK30HUNIONCFG20261101 Saved producer metadata only; no union or physics.
% Template supplies fresh final paths/caps and all closed-input authorities.
% Its AllOwnedNativeWorkersClosed flag is retained literally. A later launcher
% may make the sole declared false-to-true patch after actual owned closure.
    enteredUTC=acUTC();enteredMono=acNano();
    assert(nargin==4&&B.capture.pid==feature('getpid')&&isstruct(options)&&isscalar(options) ...
        &&isequal(sort(fieldnames(options)),sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,300)&&isequal(options.SaveMarginSeconds,30), ...
        'PKCfg:Options','Use this-process original clocks and one fresh300/30 native cfg output.');
    required={'Template';'FinalizerReference';'SustainedReference';'ExtensionReference';'JoinAcquireReference'; ...
        'JoinPlanReference';'CohortClosureRows';'RetainedAuthorityReferences';'IncludeJoinCohort'};
    assert(isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort(required)), ...
        'PKCfg:Bindings','Supply exact saved producers, externally verified closure refs and a plain finalizer template.');
    finish=struct('deadline_unix_seconds',min(B.deadline_unix_seconds,enteredUTC+300), ...
        'deadline_monotonic_ns',min(B.deadline_monotonic_ns,enteredMono+300e9));
    work=finish;work.deadline_unix_seconds=work.deadline_unix_seconds-30;work.deadline_monotonic_ns=work.deadline_monotonic_ns-30e9;
    output=acLiteral(options.OutputFile);stage=[output,'.pending.mat'];assert(~isfile(output)&&~isfile(stage), ...
        'PKCfg:Fresh','Keep previous cfg/stage and use a fresh output.');
    cfg=bindings.Template;assert(isstruct(cfg)&&isscalar(cfg)&&islogical(cfg.AllOwnedNativeWorkersClosed)&&isscalar(cfg.AllOwnedNativeWorkersClosed), ...
        'PKCfg:Template','The plain scalar template retains the actual owned-worker closure flag, including false during GUI work.');
    assert(strcmp(listRef.sha256,'fbc521eeb7d9a28074fe00296f7082f067a7e6eb282da560b1d157c9e7c7ea5f'), ...
        'PKCfg:SourceList','Bind the reviewed22-role list including the three oldCore P1 control forks.');
    refs=[{listRef;bindings.FinalizerReference;cfg.SurveyReference;cfg.DomainReference;cfg.HistoricalJournalReference;cfg.OriginalV2Reference; ...
        bindings.SustainedReference;bindings.ExtensionReference;bindings.JoinAcquireReference;bindings.JoinPlanReference}; ...
        cfg.ClosureReferences(:);bindings.RetainedAuthorityReferences(:)];
    for k=1:numel(bindings.CohortClosureRows),refs{end+1,1}=bindings.CohortClosureRows{k}.reference;end
    code={acRef([mfilename('fullpath'),'.m']);acRef(which('C1ScientificDigest_v3'));acRef(which('RoundSHA256_v3'));acRef(which('V3Path_v3'));acRef(which('V3Root_v3'))};
    refs=[refs;code];acVerify(refs);acCheck(work);
    assert(nargin('FinalizePK30hUnion20261101')==2&&strcmp(which('FinalizePK30hUnion20261101'),bindings.FinalizerReference.file), ...
        'PKCfg:FinalizerABI','Resolve and parse the exact reviewed finalizer API without invoking it.');
    receipt=struct('schema','PK30h-native-final-union-cfg-assembly-v1','input_references',{refs},'original_budget',B, ...
        'original_finish',finish,'options',options,'source_posthash',false,'completed',false,'failure',struct(), ...
        'oldCore_replacement_authorized',false,'scientific_frontier_closure_claimed',false,'source_retirement_authorized',false, ...
        'own_process_exit_claimed',false,'root_ODE_map_classifier_replay_calls',0);
    try
        x=jsondecode(fileread(listRef.file));assert(strcmp(x.schema,'PK30h-frozen-union-source-path-hash-list-v1')&&numel(x.rows)==22, ...
            'PKCfg:ListShape','The exact administrative source list must contain all22 literal roles.');
        if iscell(x.rows),cfg.SourceRows=x.rows(:);else,cfg.SourceRows=num2cell(x.rows(:));end
        roles=cellfun(@(r)r.role,cfg.SourceRows,'UniformOutput',false);
        assert(numel(unique(roles))==22&&all(ismember({'p1_column1','p1_column179','p1_column152','retained_join','join_fork'},roles)), ...
            'PKCfg:RetainedScope','Keep oldCore P1 stores and both actual new-join authorities; no replacement is yet authorized.');
        acVerify(cellfun(@(r)r.reference,cfg.SourceRows,'UniformOutput',false));
        x=load(cfg.SurveyReference.file,'audit');survey=x.audit;
        assert(survey.completed&&survey.source_posthash&&isempty(survey.jobs)&&numel(survey.queue)>=13, ...
            'PKCfg:Survey','Read only the completed observation-only Survey headers; do not load the91MB journal.');
        x=load(bindings.SustainedReference.file,'audit');sustained=x.audit;
        x=load(bindings.ExtensionReference.file,'audit');extension=x.audit;
        x=load(bindings.JoinAcquireReference.file,'audit');join=x.audit;
        x=load(bindings.JoinPlanReference.file,'plan');joinPlan=x.plan;
        assert(joinPlan.completed&&joinPlan.source_posthash,'PKCfg:JoinPlan','Use the exact completed saved JoinPlan parameter authority.');
        cfg.MatchedPhysicalParameter=joinPlan.native_intake{1}.headers{1}.parameter;
        receipt.parameter_source=struct('reference',bindings.JoinPlanReference,'locator','plan.native_intake{1}.headers{1}.parameter');
        proofNames={'oldGateB';'negative_primary';'positive_primary';'secondary';'low0062_0072';'join0170_0072'};
        proofRoles={'raw03';'retained_negative';'retained_positive';'retained_secondary';'retained_low';'retained_join'};
        cfg.ProofRows=cell(6,1);
        for k=1:6
            kind='generic';if k==1,kind='oldGateB';end
            cfg.ProofRows{k}=struct('role',proofNames{k},'kind',kind,'source_role',proofRoles{k});
        end
        cfg.CohortRows=cell(0,1);
        for name={'grown0062','grown0072','grown0170'}
            cfg.CohortRows{end+1,1}=acQueueCohort(sustained,name{1},cfg.SourceRows,roles,bindings.CohortClosureRows);
        end
        cfg.CohortRows{end+1,1}=acQueueCohort(extension,'latest0170',cfg.SourceRows,roles,bindings.CohortClosureRows);
        assert(islogical(bindings.IncludeJoinCohort)&&isscalar(bindings.IncludeJoinCohort),'PKCfg:JoinFlag','Explicitly choose whether to retain a future owned-pair context for the closed join fork.');
        if bindings.IncludeJoinCohort
            assert(join.completed&&join.source_posthash&&join.ordinary_edge_earned&&join.qualified_numerical_relation ...
                &&join.run.persistence_completion_confirmed&&isempty(join.run.pending_batch)&&isempty(fieldnames(join.run.pending_admission)), ...
                'PKCfg:Join','Use the actual clean returned ordinary join source, without reconstructing a new run.');
            at=find(strcmp(roles,'join_fork'));assert(isscalar(at)&&isequaln(join.run_branch_reference,cfg.SourceRows{at}.reference), ...
                'PKCfg:JoinGeneration','Actual original join fork and fixed SourceRows generation must agree.');
            q=struct('id','saved_owned_join0170_0072','historical_status',join.run.status,'execute',false, ...
                'source_reference',join.source_reference,'pair',join.source_pair,'output_file',join.run_branch_reference.file, ...
                'symmetry',join.options.Symmetry,'options',join.options.RunOptions,'role','saved_Acquire_owned_fork_options');
            c=acClosure('join_fork',bindings.CohortClosureRows);c.source_role='join_fork';c.checkpoint_reference=join.run_checkpoint_reference;
            c.queue_job=q;c.returned_persistence_completion_confirmed=join.run.persistence_completion_confirmed;cfg.CohortRows{end+1,1}=c;
        end
        cfg.HistoricalDispositionRows=cell(13,1);
        for k=1:13
            q=survey.queue{k};assert(strcmp(q.role,'historical_frontier_obligation')&&q.journal_row==k ...
                &&isequaln(q.journal_reference,cfg.HistoricalJournalReference)&&isequaln(q.history_locator.journal_reference,cfg.HistoricalJournalReference), ...
                'PKCfg:Historical','Preserve each exact original journal/id/row/history locator and ordered pair.');
            [successor,lineage]=acSuccessor(q.id,cfg.CohortRows,cfg.SourceRows,roles);
            cfg.HistoricalDispositionRows{k}=struct('frontier_id',q.id,'journal_row',k,'disposition','HOLD', ...
                'successor_cohort_role',successor,'recorded_metadata_lineage',{lineage}, ...
                'scope','Honest storage-stage HOLD. Recorded ordinary-fork ancestry selects a current context only; typed-route/scientific direction closure and retirement remain separate.');
        end
        expected={'Generation';'SourceRows';'ProofRows';'CohortRows';'HistoricalDispositionRows';'SurveyReference';'DomainReference'; ...
            'HistoricalJournalReference';'OriginalV2Reference';'MatchedPhysicalParameter';'ClosureReferences';'AllOwnedNativeWorkersClosed'; ...
            'UnionDirectory';'ConsolidationReceiptFile';'EssentialAuditFile';'CoreDirectory';'ResumeDirectory';'CampaignFile'; ...
            'MaxWallSeconds';'SaveMarginSeconds';'ConsolidateSeconds';'CoreSeconds';'CoreSaveMarginSeconds'};
        assert(isequal(sort(fieldnames(cfg)),sort(expected))&&iscell(cfg.SourceRows)&&iscolumn(cfg.SourceRows) ...
            &&iscell(cfg.CohortRows)&&iscolumn(cfg.CohortRows)&&~isempty(cfg.CohortRows), ...
            'PKCfg:FinalizerABI','Produce exactly the current scalar finalizer configuration contract and column cells.');
        receipt.source_count=22;receipt.proof_count=6;receipt.cohort_count=numel(cfg.CohortRows);receipt.historical_disposition_count=13;
        receipt.all_owned_workers_closed_in_prepared_cfg=cfg.AllOwnedNativeWorkersClosed;
        receipt.declared_later_patch='The actual execution launcher may set ONLY AllOwnedNativeWorkersClosed=true after all prior owned workers actually close; this is not a grant renewal.';
        receipt.pre_union_retained_authorities=bindings.RetainedAuthorityReferences;
        receipt.oldCore_scope='The old494occ/476P Core and supplied publication authorities remain essential pending actual native post-union occurrence/P mapping; SourceRows presence alone does not authorize replacement.';
        acVerify(refs);acVerify(cellfun(@(r)r.reference,cfg.SourceRows,'UniformOutput',false));receipt.source_posthash=true;receipt.completed=true;
    catch e,receipt.failure=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
    acCheck(work);cfg_digest=C1ScientificDigest_v3(cfg);save(stage,'cfg','cfg_digest','receipt','-v7');
    a=load(stage,'cfg','cfg_digest','receipt');b=load(stage,'cfg','cfg_digest','receipt');acSame(cfg,a.cfg);acSame(cfg,b.cfg);acSame(receipt,a.receipt);acSame(receipt,b.receipt);
    assert(strcmp(a.cfg_digest,cfg_digest)&&strcmp(b.cfg_digest,cfg_digest),'PKCfg:Digest','Both independent native cfg digests must agree.');acCheck(finish);
    assert(receipt.completed&&receipt.source_posthash,'PKCfg:Incomplete','Retain partial cfg stage: %s',jsonencode(receipt.failure));
    sha=RoundSHA256_v3(stage);javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    a=load(output,'cfg','cfg_digest','receipt');b=load(output,'cfg','cfg_digest','receipt');acSame(cfg,a.cfg);acSame(cfg,b.cfg);acSame(receipt,a.receipt);acSame(receipt,b.receipt);
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),sha), ...
        'PKCfg:OwnStage','Unlink only the unchanged linked own cfg stage.');delete(stage);acVerify(refs);acCheck(finish);
    fprintf('PK30H_UNION_CFG_RETURN %s\n',jsonencode(struct('completed',true,'source_posthash',true,'cfg_reference',acRef(output), ...
        'source_count',22,'proof_count',6,'cohort_count',numel(cfg.CohortRows),'historical_HOLD_rows',13, ...
        'all_owned_native_workers_closed',cfg.AllOwnedNativeWorkersClosed,'oldCore_replacement_authorized',false,'own_process_exit_claimed',false)));
end
function c=acQueueCohort(a,role,rows,roles,closures)
    assert(a.completed&&a.source_posthash&&a.all_requested_jobs_returned&&isempty(fieldnames(a.failure)), ...
        'PKCfg:QueueAudit','Use a completed exact saved Queue with closed outputs and no failure.');
    at=find(strcmp(roles,role));assert(isscalar(at),'PKCfg:SourceRole','Exactly one actual source role is required.');r=rows{at}.reference;
    hit=find(cellfun(@(j)isfield(j,'output_reference')&&isequaln(j.output_reference,r),a.jobs));
    assert(isscalar(hit),'PKCfg:QueueGeneration','One actual returned output reference must match this fixed source path/SHA.');j=a.jobs{hit};
    hit=find(cellfun(@(q)strcmp(q.id,j.id),a.queue));assert(isscalar(hit)&&j.persistence_completion_confirmed&&j.pending_count==0, ...
        'PKCfg:QueueJob','Bind one exact original Queue job and the returned clean persistence flags.');
    c=acClosure(role,closures);c.source_role=role;c.checkpoint_reference=j.checkpoint_reference;c.queue_job=a.queue{hit};
    c.returned_persistence_completion_confirmed=j.persistence_completion_confirmed;
end
function c=acClosure(role,rows)
    at=find(cellfun(@(r)strcmp(r.role,role),rows));assert(isscalar(at)&&isequal(rows{at}.external_exit_zero_and_postchecks_confirmed,true), ...
        'PKCfg:ExternalClosure','Caller supplies the actual independently closed science-worker authority per cohort.');
    c=struct('role',role,'closure_reference',rows{at}.reference,'external_exit_zero_and_postchecks_confirmed',true);
end
function [role,lineage]=acSuccessor(id,cohorts,rows,roles)
    role='';lineage=cell(0,1);at=find(cellfun(@(c)strcmp(c.queue_job.id,id),cohorts));if ~isscalar(at),return;end
    seen=false(numel(cohorts),1);
    for step=1:numel(cohorts)
        assert(~seen(at),'PKCfg:Lineage','Recorded ordinary-fork metadata lineage may not cycle.');seen(at)=true;role=cohorts{at}.role;lineage{end+1,1}=role;
        sourceAt=find(strcmp(roles,cohorts{at}.source_role));r=rows{sourceAt}.reference;
        child=find(cellfun(@(c)isequaln(c.queue_job.source_reference,r),cohorts));child=child(~seen(child));
        if ~isscalar(child),return;end;at=child;
    end
end
function acVerify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(r.file,acLiteral(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKCfg:Changed','An immutable administrative/native/source reference changed.');end,end
function acSame(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKCfg:Read2','Complete declared plain native values differ.');end
function r=acRef(file),r=struct('file',acLiteral(file),'sha256',RoundSHA256_v3(file));end
function p=acLiteral(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKCfg:Alias','Hash and native read must address the same literal file.');end
function acCheck(l),assert(acUTC()<l.deadline_unix_seconds&&acNano()<l.deadline_monotonic_ns,'PKCfg:Clock','The original300/30 cfg clock expired.');end
function t=acUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=acNano(),t=double(java.lang.System.nanoTime());end
