function receipt = ConsolidateC1ConnectedComponents_v3(sourceFiles, outputDirectory, receiptFile, options)
%CONSOLIDATEC1CONNECTEDCOMPONENTS_V3 Lossless storage of connected components.
% Explicit continuation edges are retained, never inferred from proximity.
% Equal numerical records may connect storage graphs only after their native
% return sections and complete recorded policy configurations agree. These
% equality links are separate from scientific continuation edges. Every
% occurrence, native public orbit, report and original metadata is retained.
% No integration, classification, correction, optimization or deletion occurs.
%
% component_graph.original_explicit_edges/effective_edges are consolidation
% snapshots. Later frontiers use current index.edges plus the fixed
% exact_record_equalities and qualified_record_aliases. Quotient both kinds
% of state-identical links before computing strict trace degrees. Separately
% qualified numerical overlaps connect storage graphs only; they are neither
% identity quotients nor physical edges. receipt.occurrence_map maps each input occurrence
% to its output file/index. Source catalogue metadata is stored once, in the
% receipt, rather than repeated in every isolated component.
    if nargin < 4, options = struct(); end
    assert(isstruct(options) && isscalar(options), 'C1Consolidate:Options', ...
        'Options must be a scalar struct.');
    if isfield(options, 'Budget'), budget = options.Budget; else, budget = C1RunBudget_v3(); end
    maxWall = member(options, 'MaxWallSeconds', 7200);
    packIsolated = member(options, 'PackIsolatedRecords', false);
    resumeRequested=member(options,'ResumeReceipt',false);
    assert(islogical(resumeRequested)&&isscalar(resumeRequested),'C1Consolidate:Resume');
    requestedAliases = member(options, 'QualifiedAliasPairs', cell(0,1));
    if isstruct(requestedAliases), requestedAliases = num2cell(requestedAliases(:)); end
    assert(iscell(requestedAliases) && (isvector(requestedAliases) || isempty(requestedAliases)), ...
        'C1Consolidate:Aliases','QualifiedAliasPairs must be explicit selector structs.');
    requestedAliases=requestedAliases(:);
    requestedOverlaps=member(options,'NumericalOverlapPairs',cell(0,1));
    if isstruct(requestedOverlaps),requestedOverlaps=num2cell(requestedOverlaps(:));end
    assert(iscell(requestedOverlaps)&&(isvector(requestedOverlaps)||isempty(requestedOverlaps)), ...
        'C1Consolidate:NumericalOverlaps','NumericalOverlapPairs must be explicit selectors and fresh immutable proofs.');
    requestedOverlaps=requestedOverlaps(:);
    assert(islogical(packIsolated) && isscalar(packIsolated), ...
        'C1Consolidate:Isolates','PackIsolatedRecords must be a logical scalar.');
    assert(isnumeric(maxWall) && isscalar(maxWall) && isfinite(maxWall) && maxWall > 0, ...
        'C1Consolidate:Wall', 'MaxWallSeconds must be finite and positive.');
    requiredClocks = {'deadline_unix_seconds', 'deadline_monotonic_ns'};
    assert(isstruct(budget) && isscalar(budget) && all(isfield(budget, requiredClocks)), ...
        'C1Consolidate:Budget', 'A shared UTC and monotonic final deadline is required.');
    timer = tic;
    validationLimits=struct('deadline_unix_seconds',min(budget.deadline_unix_seconds, ...
        posixtime(datetime('now','TimeZone','UTC'))+maxWall), ...
        'deadline_monotonic_ns',min(budget.deadline_monotonic_ns,double(java.lang.System.nanoTime)+maxWall*1e9));
    checkTime();
    if ischar(sourceFiles) || (isstring(sourceFiles) && isscalar(sourceFiles))
        sourceFiles = {char(sourceFiles)};
    elseif isstring(sourceFiles), sourceFiles = cellstr(sourceFiles(:)); end
    assert(iscell(sourceFiles) && isvector(sourceFiles) && ~isempty(sourceFiles), ...
        'C1Consolidate:Sources', 'Supply an explicit nonempty source file list.');
    sourceFiles = cellfun(@canonical, sourceFiles(:), 'UniformOutput', false);
    assert(numel(unique(sourceFiles)) == numel(sourceFiles), ...
        'C1Consolidate:Sources', 'Repeated source paths are not separate occurrences.');
    outputDirectory = canonical(outputDirectory);
    receiptFile = canonical(receiptFile);
    [~,~,extension] = fileparts(receiptFile);
    assert(strcmpi(extension,'.mat')&&~isfolder(receiptFile),'C1Consolidate:Receipt');
    priorReceipt=struct();priorReceiptReference=struct();
    if resumeRequested
        assert(isfile(receiptFile)&&isfolder(outputDirectory),'C1Consolidate:Resume', ...
            'ResumeReceipt requires an existing owned receipt and output directory.');
        priorReceiptReference=struct('file',receiptFile,'sha256',RoundSHA256_v3(receiptFile));
        priorSaved=load(receiptFile,'receipt');priorReceipt=priorSaved.receipt;
        assert(strcmp(priorReceipt.schema,'C1-connected-component-consolidation-v1') ...
            &&isequal(priorReceipt.completed,false)&&strcmp(priorReceipt.output_directory,outputDirectory), ...
            'C1Consolidate:Resume','Only an incomplete matching consolidation can be resumed.');
    else
        assert(~isfile(receiptFile)&&~isfolder(outputDirectory)&&~isfile(outputDirectory), ...
            'C1Consolidate:Fresh','Use fresh outputs or explicitly ResumeReceipt=true.');
    end
    assert(~any(strcmp(sourceFiles,receiptFile)), 'C1Consolidate:Output', ...
        'A receipt cannot replace a source.');
    sourceCatalog = cell(numel(sourceFiles), 1);
    nodes = cell(0,1);
    explicitEdges = zeros(0,2);
    offsets = zeros(numel(sourceFiles),1);
    aliasRequests=cell(0,1);overlapRequests=cell(0,1);
    for sourceNumber = 1:numel(sourceFiles)
        checkTime();
        file = sourceFiles{sourceNumber};
        before = dir(file);
        assert(isscalar(before) && ~before.isdir, 'C1Consolidate:Missing', 'Missing source %s.', file);
        hash = RoundSHA256_v3(file);
        index = BranchSolutionFile_v3.index(file);
        offsets(sourceNumber) = numel(nodes);
        sourceCatalog{sourceNumber} = struct('file',file,'sha256',hash, ...
            'bytes',before.bytes,'metadata',index.metadata,'point_metadata', ...
            {cellfun(@(p)p.metadata,index.points,'UniformOutput',false)}, ...
            'original_edges',{index.edges},'stored_points',numel(index.points), ...
            'stored_edges',numel(index.edges),'source_public_readback_verified',false);
        variables = cell(1,2*numel(index.points));metadataKinds=zeros(1,3);
        for k = 1:numel(index.points)
            [~,metadataKind]=normalizedOriginalMetadata(index.points{k}.metadata);
            metadataKinds(metadataKind)=metadataKinds(metadataKind)+1;
            variables{2*k-1}=index.points{k}.solution_variable;
            variables{2*k}=index.points{k}.report_variable;
        end
        if isempty(variables), saved=struct(); else, saved=load(file,variables{:}); end
        for k = 1:numel(index.points)
            checkTime();
            point=index.points{k}; orbit=saved.(point.solution_variable);
            report=saved.(point.report_variable);
            selfCheck=MatchingReturnSection_v3(orbit,orbit,{report,report});
            state=orbit.initial_state(:);
            schema=QuadrupedSchema_v3.shared(); state(schema.TranslationIndex)=0;
            nodes{end+1,1}=struct('source_number',sourceNumber,'source_index',k, ...
                'point',point,'native_ID',OrbitContentIdentity_v3(orbit), ...
                'normalized_state',state,'initial_mode',orbit.initial_mode(:), ...
                'parameter',orbit.parameter(:),'period',orbit.period, ...
                'stride',orbit.stride_displacement(:), ...
                'complete_return_section',selfCheck.compatible); %#ok<AGROW>
        end
        for k=1:numel(index.edges)
            edge=index.edges{k};
            explicitEdges(end+1,:)=[edge.from,edge.to]+offsets(sourceNumber); %#ok<AGROW>
        end
        priorGraph=member(index.metadata,'component_graph',struct());
        priorAliases=member(priorGraph,'qualified_record_aliases',zeros(0,2));
        validateAliasIndices(priorAliases,numel(index.points));
        for k=1:size(priorAliases,1)
            aliasRequests{end+1,1}=struct('left_node',priorAliases(k,1)+offsets(sourceNumber), ...
                'right_node',priorAliases(k,2)+offsets(sourceNumber), ...
                'kind','inherited_qualified_record_alias', ...
                'input_request',struct('source_file',file,'source_sha256',hash,'source_alias_row',k)); %#ok<AGROW>
        end
        priorOverlaps=member(priorGraph,'qualified_numerical_overlaps',zeros(0,2));
        priorOverlapEvidence=member(priorGraph,'numerical_overlap_evidence',cell(0,1));
        validateAliasIndices(priorOverlaps,numel(index.points));
        assert(iscell(priorOverlapEvidence)&&numel(priorOverlapEvidence)==size(priorOverlaps,1), ...
            'C1Consolidate:NumericalOverlaps','Every retained numerical adjacency needs its original compact qualification.');
        for k=1:size(priorOverlaps,1)
            overlapRequests{end+1,1}=struct('left_node',priorOverlaps(k,1)+offsets(sourceNumber), ...
                'right_node',priorOverlaps(k,2)+offsets(sourceNumber),'kind','inherited_qualified_numerical_overlap', ...
                'input_request',struct('source_file',file,'source_sha256',hash,'source_overlap_row',k), ...
                'retained_evidence',priorOverlapEvidence{k}); %#ok<AGROW>
        end
        after=dir(file);
        assert(sameStat(before,after) && strcmp(hash,RoundSHA256_v3(file)), ...
            'C1Consolidate:SourceChanged','The source changed during discovery: %s.',file);
        clear saved orbit report
        fprintf('C1_COMPONENT_SOURCE %d/%d points=%d edges=%d metadataUnmarked=%d metadataDirectEnvelope=%d metadataImportedNonedge=%d\n', ...
            sourceNumber,numel(sourceFiles),numel(index.points),numel(index.edges),metadataKinds(1),metadataKinds(2),metadataKinds(3));
    end
    equalityEdges=zeros(0,2); equalityEvidence=cell(0,1);
    if ~isempty(nodes)
        identifiers=cellfun(@(p)p.native_ID,nodes,'UniformOutput',false);
        [~,~,idGroups]=unique(identifiers);
        for group=1:max(idGroups)
            candidates=find(idGroups==group);
            if numel(candidates)<2,continue;end
            remaining=true(size(candidates));
            for a=1:numel(candidates)
                if ~remaining(a),continue;end
                left=nodes{candidates(a)};
                if ~left.complete_return_section,continue;end
                [leftOrbit,leftReport]=readNode(left);
                for b=a+1:numel(candidates)
                    if ~remaining(b),continue;end
                    right=nodes{candidates(b)};
                    if ~sameNumericalRecord(left,right),continue;end
                    checkTime();
                    [rightOrbit,rightReport]=readNode(right);
                    compatibility=MatchingReturnSection_v3(leftOrbit,rightOrbit,{leftReport,rightReport});
                    if ~compatibility.compatible,continue;end
                    equalityEdges(end+1,:)=[candidates(a),candidates(b)]; %#ok<AGROW>
                    equalityEvidence{end+1,1}=struct('native_ID',left.native_ID, ...
                        'exact_state_mode_parameter_period_stride',true, ...
                        'translation_gauge_normalized',true, ...
                        'matching_return_section',compatibility, ...
                        'new_continuation_edge_created',false); %#ok<AGROW>
                    remaining(b)=false;
                end
            end
        end
    end
    for k=1:numel(requestedAliases)
        selector=requestedAliases{k};required={'left_file','left_index','right_file','right_index'};
        assert(isstruct(selector)&&isscalar(selector)&&all(isfield(selector,required)), ...
            'C1Consolidate:Aliases','Each explicit alias needs left/right file and index selectors.');
        leftSource=find(strcmp(sourceFiles,canonical(selector.left_file)));
        rightSource=find(strcmp(sourceFiles,canonical(selector.right_file)));
        assert(isscalar(leftSource)&&isscalar(rightSource),'C1Consolidate:Aliases', ...
            'Both alias selectors must belong to the explicit input source list.');
        validateAliasPoint(selector.left_index,sourceCatalog{leftSource}.stored_points);
        validateAliasPoint(selector.right_index,sourceCatalog{rightSource}.stored_points);
        aliasRequests{end+1,1}=struct('left_node',offsets(leftSource)+selector.left_index, ...
            'right_node',offsets(rightSource)+selector.right_index, ...
            'kind','explicit_requested_numeric_alias','input_request',selector); %#ok<AGROW>
    end
    qualifiedAliasEdges=zeros(0,2);qualifiedAliasEvidence=cell(0,1);
    aliasQualificationSource=struct();
    if ~isempty(aliasRequests)
        aliasSource=which('QualifyC1RecordAlias_v3');assert(~isempty(aliasSource),'C1Consolidate:AliasSource');
        aliasQualificationSource=struct('file',canonical(aliasSource),'sha256',RoundSHA256_v3(aliasSource));
    end
    for k=1:numel(aliasRequests)
        checkTime();request=aliasRequests{k};pair=[request.left_node,request.right_node];
        assert(pair(1)~=pair(2),'C1Consolidate:Aliases','An alias must link distinct stored occurrences.');
        if ismember(sort(pair),sort(qualifiedAliasEdges,2),'rows'),continue;end
        [aliasLeft,aliasLeftReport]=readNode(nodes{pair(1)});
        [aliasRight,aliasRightReport]=readNode(nodes{pair(2)});
        evidence=QualifyC1RecordAlias_v3(aliasLeft,aliasRight,aliasLeftReport,aliasRightReport);
        assert(evidence.qualified,'C1Consolidate:Aliases','The requested alias failed native qualification.');
        evidence.request=request;evidence.qualification_source=aliasQualificationSource;
        qualifiedAliasEdges(end+1,:)=pair;qualifiedAliasEvidence{end+1,1}=evidence; %#ok<AGROW>
    end
    if ~isempty(aliasRequests)
        assert(strcmp(RoundSHA256_v3(aliasQualificationSource.file),aliasQualificationSource.sha256), ...
            'C1Consolidate:AliasSource','The alias qualification source changed.');
    end
    for k=1:numel(requestedOverlaps)
        selector=requestedOverlaps{k};required={'left_file','left_index','right_file','right_index','proof'};
        assert(isstruct(selector)&&isscalar(selector)&&all(isfield(selector,required)) ...
            &&isstruct(selector.proof)&&isscalar(selector.proof) ...
            &&ismember(selector.proof.schema,{'C1-owned-PAL-numerical-overlap-proof-v1', ...
                'C1-finite-owned-PAL-numerical-overlap-proof-v1'}), ...
            'C1Consolidate:NumericalOverlaps','An explicit NEW adjacency requires the full fresh-proof path; retained evidence is internal only.');
        leftSource=find(strcmp(sourceFiles,canonical(selector.left_file)));
        rightSource=find(strcmp(sourceFiles,canonical(selector.right_file)));
        assert(isscalar(leftSource)&&isscalar(rightSource),'C1Consolidate:NumericalOverlaps', ...
            'Both numerical-overlap selectors must belong to the explicit input source list.');
        validateAliasPoint(selector.left_index,sourceCatalog{leftSource}.stored_points);
        validateAliasPoint(selector.right_index,sourceCatalog{rightSource}.stored_points);
        assert(strcmp(canonical(selector.left_file),canonical(selector.proof.left_selector.file)) ...
            &&selector.left_index==selector.proof.left_selector.index ...
            &&strcmp(canonical(selector.right_file),canonical(selector.proof.right_selector.file)) ...
            &&selector.right_index==selector.proof.right_selector.index, ...
            'C1Consolidate:NumericalOverlaps','New selectors must name the original proof occurrences exactly; transport is internal only.');
        overlapRequests{end+1,1}=struct('left_node',offsets(leftSource)+selector.left_index, ...
            'right_node',offsets(rightSource)+selector.right_index,'kind','explicit_new_numerical_overlap', ...
            'input_request',selector,'retained_evidence',struct()); %#ok<AGROW>
    end
    numericalEdges=zeros(0,2);numericalEvidence=cell(0,1);numericalTransports=cell(0,1);numericalQualificationSource=struct();
    qualifierNames=cell(0,1);
    for k=1:numel(overlapRequests)
        request=overlapRequests{k};
        if strcmp(request.kind,'explicit_new_numerical_overlap')
            if strcmp(request.input_request.proof.schema,'C1-owned-PAL-numerical-overlap-proof-v1')
                qualifierNames{end+1,1}='QualifyC1PKNumericalOverlap_v3'; %#ok<AGROW>
            else
                qualifierNames{end+1,1}='C1FiniteNumericalOverlap_v3'; %#ok<AGROW>
            end
        elseif isstruct(request.retained_evidence)&&isscalar(request.retained_evidence) ...
                &&isfield(request.retained_evidence,'schema') ...
                &&strcmp(request.retained_evidence.schema,'C1-qualified-finite-numerical-overlap-v1')
            % Retained generic evidence also invokes its public transport
            % validator. Guard that provider even with no new requests.
            qualifierNames{end+1,1}='C1FiniteNumericalOverlap_v3'; %#ok<AGROW>
        end
    end
    qualifierNames=unique(qualifierNames,'stable');
    for k=1:numel(qualifierNames)
        f=which(qualifierNames{k});assert(~isempty(f),'C1Consolidate:NumericalOverlapSource','The numerical-overlap qualifier must resolve to an existing source.');
        row=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));
        if isempty(fieldnames(numericalQualificationSource)),numericalQualificationSource=row;
        else,numericalQualificationSource(end+1,1)=row;end %#ok<AGROW>
    end
    for k=1:numel(overlapRequests)
        checkTime();request=overlapRequests{k};pair=[request.left_node,request.right_node];
        assert(pair(1)~=pair(2)&&~ismember(sort(pair),sort(numericalEdges,2),'rows'), ...
            'C1Consolidate:NumericalOverlaps','Numerical pairs must be distinct explicitly selected occurrences, without duplicate requests.');
        [left,leftReport]=readNode(nodes{pair(1)});[right,rightReport]=readNode(nodes{pair(2)});
        incoming=find(explicitEdges(:,2)==pair(1));
        assert(isscalar(incoming),'C1Consolidate:NumericalOverlaps', ...
            'The retained C occurrence must keep its one actual physical predecessor.');
        parentIndex=explicitEdges(incoming,1);[parent,~]=readNode(nodes{parentIndex});
        assert(nodes{parentIndex}.source_number==nodes{pair(1)}.source_number ...
            &&strcmp(nodes{parentIndex}.point.component_identity,nodes{pair(1)}.point.component_identity), ...
            'C1Consolidate:NumericalOverlaps','An actual same-owner physical edge, never adjacency, must reach C.');
        if strcmp(request.kind,'explicit_new_numerical_overlap')
            nativeProof=request.input_request.proof;nativeProof.validation_limits=validationLimits;
            if strcmp(nativeProof.schema,'C1-finite-owned-PAL-numerical-overlap-proof-v1')
                evidence=C1FiniteNumericalOverlap_v3.qualify(left,right,leftReport,rightReport,nativeProof);
            else
                evidence=QualifyC1PKNumericalOverlap_v3(left,right,leftReport,rightReport,nativeProof);
            end
        else
            % Internal transport only: the whole source SHA/public reads bind
            % the already-qualified evidence. Archived raw authorities need
            % not be reopened or rewritten to preserve this fixed adjacency.
            evidence=request.retained_evidence;
        end
        validateNumericalEvidence(evidence,left,right,leftReport,rightReport,parent);
        numericalEdges(end+1,:)=pair;numericalEvidence{end+1,1}=evidence; %#ok<AGROW>
        numericalTransports{end+1,1}=struct('kind',request.kind,'input_request',request.input_request, ...
            'left_node',pair(1),'right_node',pair(2),'original_evidence_unchanged',true); %#ok<AGROW>
    end
    if ~isempty(fieldnames(numericalQualificationSource))
        for k=1:numel(numericalQualificationSource)
            assert(strcmp(RoundSHA256_v3(numericalQualificationSource(k).file),numericalQualificationSource(k).sha256), ...
                'C1Consolidate:NumericalOverlapSource','The numerical-overlap qualifier source changed.');
        end
    end
    strictEdges=[explicitEdges;equalityEdges;qualifiedAliasEdges];
    effectiveEdges=[strictEdges;numericalEdges];
    if isempty(nodes), bins=zeros(1,0); else
        bins=conncomp(graph(effectiveEdges(:,1),effectiveEdges(:,2),[],numel(nodes)));
    end
    componentCount=max([0,bins]);
    groupMembers=cell(0,1);groupComponentNumbers=cell(0,1);isIsolatedGroup=false(0,1);
    isolatedNumbers=[];
    for k=1:componentCount
        selected=find(bins==k);
        if packIsolated && numel(selected)==1
            isolatedNumbers(end+1)=k; %#ok<AGROW>
        else
            groupMembers{end+1,1}=selected;groupComponentNumbers{end+1,1}=k; %#ok<AGROW>
            isIsolatedGroup(end+1,1)=false; %#ok<AGROW>
        end
    end
    if ~isempty(isolatedNumbers)
        groupMembers{end+1,1}=find(ismember(bins,isolatedNumbers));
        groupComponentNumbers{end+1,1}=isolatedNumbers;isIsolatedGroup(end+1,1)=true;
    end
    sourceIdentity=strjoin(cellfun(@(s)[s.file,'::',s.sha256],sourceCatalog,'UniformOutput',false),'|');
    if ~isempty(qualifiedAliasEdges),sourceIdentity=[sourceIdentity,'|qualified_aliases=',mat2str(qualifiedAliasEdges)];end
    if ~isempty(numericalEdges)
        contracts=cellfun(@(e)digestText(jsonencode(e)),numericalEvidence,'UniformOutput',false);
        sourceIdentity=[sourceIdentity,'|numerical_adjacencies=',mat2str(numericalEdges),'|proof_contracts=',strjoin(contracts,'|')];
    end
    consolidationID=['C1-components:',digestText(sourceIdentity)];
    receipt=struct('schema','C1-connected-component-consolidation-v1', ...
        'consolidation_id',consolidationID,'started_utc',stamp(), ...
        'completed',false,'output_directory',outputDirectory,'receipt_file',receiptFile, ...
        'scope','Stored occurrence graph: original physical edges, exact/state-identical storage aliases, and separately qualified explicit numerical adjacency. Numerical adjacency is not identity, strict trace connectivity, or a new scientific edge.', ...
        'new_root_solves',0,'new_integrations',0,'new_classifications',0, ...
        'source_files_deleted',0,'source_public_readback_verified',false, ...
        'source_hashes_verified_after_work',false,'qualification_flags_changed',false, ...
        'source_catalog',{sourceCatalog},'component_files',{cell(0,1)}, ...
        'isolated_records_file',struct(),'packed_isolated_components',numel(isolatedNumbers), ...
        'occurrence_map',{cell(0,1)},'stored_occurrences',numel(nodes), ...
        'original_explicit_edges',size(explicitEdges,1),'exact_record_equalities',size(equalityEdges,1), ...
        'qualified_record_aliases',size(qualifiedAliasEdges,1), ...
        'requested_qualified_alias_pairs',{requestedAliases},'qualified_alias_qualification_source',aliasQualificationSource, ...
        'qualified_numerical_overlaps',size(numericalEdges,1),'requested_numerical_overlap_pairs',{requestedOverlaps}, ...
        'numerical_overlap_transports',{numericalTransports},'numerical_overlap_qualification_source',numericalQualificationSource, ...
        'numerical_adjacencies_are_identity_quotients',false,'numerical_adjacencies_are_physical_edges',false, ...
        'connected_components',componentCount,'output_files',numel(groupMembers), ...
        'budget',budget,'failure',struct(),'resume_history',{cell(0,1)});
    committedGroups=0;
    if resumeRequested
        assert(isequaln(priorReceipt.budget,budget)&&strcmp(priorReceipt.consolidation_id,consolidationID) ...
            &&priorReceipt.stored_occurrences==numel(nodes) ...
            &&priorReceipt.original_explicit_edges==size(explicitEdges,1) ...
            &&priorReceipt.exact_record_equalities==size(equalityEdges,1) ...
            &&member(priorReceipt,'qualified_record_aliases',0)==size(qualifiedAliasEdges,1) ...
            &&member(priorReceipt,'qualified_numerical_overlaps',0)==size(numericalEdges,1) ...
            &&priorReceipt.connected_components==componentCount ...
            &&numel(priorReceipt.source_catalog)==numel(sourceCatalog), ...
            'C1Consolidate:Resume','The deterministic source graph changed.');
        for k=1:numel(sourceCatalog)
            old=priorReceipt.source_catalog{k};fresh=sourceCatalog{k};
            assert(strcmp(old.file,fresh.file)&&strcmp(old.sha256,fresh.sha256)&&old.bytes==fresh.bytes, ...
                'C1Consolidate:Resume','Resume sources must match the original complete file list.');
            assertPublicEqual(old.metadata,fresh.metadata,false,0);
            assertPublicEqual(old.point_metadata,fresh.point_metadata,false,0);
        end
        oldRows=priorReceipt.component_files;
        if ~isempty(fieldnames(priorReceipt.isolated_records_file)),oldRows{end+1,1}=priorReceipt.isolated_records_file;end
        assert(numel(oldRows)<=numel(groupMembers),'C1Consolidate:Resume');
        for k=1:numel(oldRows)
            checkTime();row=oldRows{k};selected=groupMembers{k};numbers=groupComponentNumbers{k};
            families=unique(cellfun(@(j)family(j.point.classification),nodes(selected),'UniformOutput',false));
            if numel(families)==1,tag=families{1};else,tag='MIXED';end
            if isIsolatedGroup(k),expectedFile=fullfile(outputDirectory,'Isolated_Records.mat');
            else,expectedFile=fullfile(outputDirectory,sprintf('C1_%s_Component_%04d.mat',tag,numbers(1)));end
            assert(strcmp(row.file,expectedFile)&&isequal(row.whole_public_data_readback_verified,true) ...
                &&row.points==numel(selected)&&strcmp(RoundSHA256_v3(row.file),row.sha256), ...
                'C1Consolidate:Resume','A committed prefix component changed or lacks original whole-public readback.');
            closedIndex=BranchSolutionFile_v3.index(row.file);
            assert(numel(closedIndex.points)==numel(selected) ...
                &&strcmp(closedIndex.metadata.consolidation_id,consolidationID), ...
                'C1Consolidate:Resume','Committed component indices differ.');
            for j=1:numel(selected)
                node=nodes{selected(j)};m=closedIndex.points{j}.metadata;source=sourceCatalog{node.source_number};
                assert(strcmp(m.provenance.source_file,source.file)&&strcmp(m.provenance.source_sha256,source.sha256) ...
                    &&m.provenance.source_index==node.source_index,'C1Consolidate:Resume','Occurrence mapping differs.');
                receipt.occurrence_map{end+1,1}=struct('source_file',source.file,'source_sha256',source.sha256, ...
                    'source_index',node.source_index,'target_file',row.file,'target_index',j);
            end
            if isIsolatedGroup(k),receipt.isolated_records_file=row;else,receipt.component_files{end+1,1}=row;end
        end
        committedGroups=numel(oldRows);
        assert(strcmp(RoundSHA256_v3(receiptFile),priorReceiptReference.sha256),'C1Consolidate:Resume');
        [preFolder,preName]=fileparts(receiptFile);
        preimage=fullfile(preFolder,[preName,'_resume_preimage_',char(java.util.UUID.randomUUID),'.mat']);
        [ok,message]=copyfile(receiptFile,preimage);assert(ok,'C1Consolidate:Resume','%s',message);
        assert(strcmp(RoundSHA256_v3(preimage),priorReceiptReference.sha256),'C1Consolidate:Resume');
        receipt.resume_history=member(priorReceipt,'resume_history',cell(0,1));
        receipt.resume_history{end+1,1}=struct('original_receipt_preimage', ...
            struct('file',preimage,'sha256',priorReceiptReference.sha256), ...
            'original_completed_flag',priorReceipt.completed,'original_failure',priorReceipt.failure, ...
            'verified_committed_groups',committedGroups, ...
            'uncommitted_occurrence_mapping_entries_discarded',numel(priorReceipt.occurrence_map)-numel(receipt.occurrence_map), ...
            'original_failure_upgraded',false,'resumed_utc',stamp());
    end
    if ~isfolder(outputDirectory),mkdir(outputDirectory);end
    if ~isfolder(fileparts(receiptFile)),mkdir(fileparts(receiptFile));end
    writeReceipt();
    try
        for storageGroup=committedGroups+1:numel(groupMembers)
            checkTime();
            selected=groupMembers{storageGroup};componentNumbers=groupComponentNumbers{storageGroup};
            componentNumber=componentNumbers(1);catalogue=isIsolatedGroup(storageGroup);
            globalToLocal=zeros(numel(nodes),1);globalToLocal(selected)=1:numel(selected);
            explicitMask=ismember(explicitEdges(:,1),selected)&ismember(explicitEdges(:,2),selected);
            equalityMask=ismember(equalityEdges(:,1),selected)&ismember(equalityEdges(:,2),selected);
            aliasMask=ismember(qualifiedAliasEdges(:,1),selected)&ismember(qualifiedAliasEdges(:,2),selected);
            numericalMask=ismember(numericalEdges(:,1),selected)&ismember(numericalEdges(:,2),selected);
            localNumerical=reshape(globalToLocal(numericalEdges(numericalMask,:)),[],2);
            localExplicit=globalToLocal(explicitEdges(explicitMask,:));
            localEquality=globalToLocal(equalityEdges(equalityMask,:));
            localExplicit=reshape(localExplicit,[],2);localEquality=reshape(localEquality,[],2);
            localAlias=reshape(globalToLocal(qualifiedAliasEdges(aliasMask,:)),[],2);
            families=unique(cellfun(@(j)family(j.point.classification),nodes(selected),'UniformOutput',false));
            if numel(families)==1,tag=families{1};else,tag='MIXED';end
            if catalogue,file=fullfile(outputDirectory,'Isolated_Records.mat');
            else,file=fullfile(outputDirectory,sprintf('C1_%s_Component_%04d.mat',tag,componentNumber));end
            assert(~isfile(file)&&~isfolder(file),'C1Consolidate:UnregisteredOutput', ...
                'An output not in the verified committed prefix exists; retain and reconcile it separately.');
            graphMetadata=struct('schema','C1-connected-component-graph-v1', ...
                'nodes',numel(selected),'original_explicit_edges',localExplicit, ...
                'exact_record_equalities',localEquality, ...
                'qualified_record_aliases',localAlias, ...
                'qualified_alias_evidence',{qualifiedAliasEvidence(aliasMask)}, ...
                'qualified_numerical_overlaps',localNumerical, ...
                'numerical_overlap_evidence',{numericalEvidence(numericalMask)}, ...
                'effective_edges',[localExplicit;localEquality;localAlias;localNumerical], ...
                'strict_trace_scope','Only physical index edges plus exact/state-identical storage aliases; numerical adjacency does not merge strict traces.', ...
                'numerical_storage_scope','Numerical adjacency connects distinct retained occurrences only under its immutable qualified evidence.', ...
                'numerical_adjacencies_are_identity_quotients',false,'numerical_adjacencies_are_physical_edges',false, ...
                'equality_evidence',{equalityEvidence(equalityMask)}, ...
                'connected',~catalogue||numel(selected)==1, ...
                'isolated_record_catalogue',catalogue,'equality_links_are_continuation_edges',false, ...
                'qualified_aliases_are_exact_record_equalities',false, ...
                'qualified_aliases_are_continuation_edges',false);
            metadata=struct('schema','C1-consolidated-component-v1', ...
                'consolidation_id',consolidationID,'component_number',componentNumber, ...
                'original_connected_component_numbers',componentNumbers, ...
                'families',{families},'source_catalog_file',receiptFile, ...
                'source_catalog_entries',unique(cellfun(@(p)p.source_number,nodes(selected))), ...
                'component_graph',graphMetadata,'source_owner_map',{cell(0,1)}, ...
                'scientific_flags_upgraded',false);
            branch_index=struct('storage_version','BranchSolutionFile_v3:2', ...
                'metadata',metadata,'points',{cell(numel(selected),1)},'edges',{cell(size(localExplicit,1),1)});
            payload=struct();
            for first=1:16:numel(selected)
                block=first:min(first+15,numel(selected));checkTime();
                [sourceOrbits,sourceReports,sourceMetadata]=readSourceBatch(nodes(selected(block)),sourceCatalog);
                for within=1:numel(block)
                localIndex=block(within);globalIndex=selected(localIndex);node=nodes{globalIndex};
                orbit=sourceOrbits{within};report=sourceReports{within};originalMetadata=sourceMetadata{within};
                firstMetadata=normalizedOriginalMetadata(originalMetadata);
                source=sourceCatalog{node.source_number};
                owner=sprintf('source-%06d::%s',node.source_number,char(node.point.component_identity));
                ownerRow=struct('source_number',node.source_number, ...
                    'source_component_identity',char(node.point.component_identity), ...
                    'output_component_identity',owner);
                ownerKey=cellfun(@(r)r.output_component_identity, ...
                    branch_index.metadata.source_owner_map,'UniformOutput',false);
                if ~ismember(owner,ownerKey)
                    branch_index.metadata.source_owner_map{end+1,1}=ownerRow;
                end
                pointMetadata=struct('component_identity',owner, ...
                    'classification',char(node.point.classification), ...
                    'nativeE',node.point.nativeE,'signedmeanU',node.point.signedmeanU, ...
                    'order',localIndex,'consolidation_point_schema','C1-consolidated-occurrence-v1', ...
                    'provenance',struct('source_file',source.file,'source_sha256',source.sha256, ...
                    'source_index',node.source_index,'source_catalog_file',receiptFile, ...
                    'source_catalog_entry',node.source_number,'original_point_metadata',firstMetadata, ...
                    'qualification_flags_changed',false));
                incoming=find(localExplicit(:,2)==localIndex);
                assert(numel(incoming)<=1,'C1Consolidate:Incoming','Original occurrence has multiple incoming edges.');
                if ~isempty(incoming)
                    pointMetadata.edge_enabled=true;pointMetadata.edge_from=localExplicit(incoming,1);
                end
                solutionName=sprintf('solution_%06d',localIndex);reportName=sprintf('report_%06d',localIndex);
                branch_index.points{localIndex}=struct('index',localIndex, ...
                    'component_identity',owner,'order',localIndex, ...
                    'classification',pointMetadata.classification,'nativeE',pointMetadata.nativeE, ...
                    'signedmeanU',pointMetadata.signedmeanU,'provenance',pointMetadata.provenance, ...
                    'metadata',pointMetadata,'solution_variable',solutionName, ...
                    'report_variable',reportName,'whole_public_data_readback_verified',true);
                payload.(solutionName)=orbit;payload.(reportName)=report;
                receipt.occurrence_map{end+1,1}=struct('source_file',source.file, ...
                    'source_sha256',source.sha256,'source_index',node.source_index, ...
                    'target_file',file,'target_index',localIndex);
                end
                clear sourceOrbits sourceReports sourceMetadata orbit report originalMetadata
            end
            for k=1:size(localExplicit,1)
                branch_index.edges{k}=struct('from',localExplicit(k,1),'to',localExplicit(k,2), ...
                    'component_identity',branch_index.points{localExplicit(k,2)}.component_identity);
            end
            payload.branch_index=branch_index;
            staged=[tempname(outputDirectory),'.mat'];
            cleaner=onCleanup(@()removeStage(staged));
            save(staged,'-struct','payload','-v7');
            % Preserve the exact variable contract before releasing the whole
            % payload; each verification pass independently deserializes it.
            payloadNames=fieldnames(payload);expectedHeaders=cell(numel(payloadNames),1);
            for variable=1:numel(payloadNames)
                name=payloadNames{variable};value=payload.(name);
                expectedHeaders{variable}=struct('name',name,'class',class(value),'size',size(value));
            end
            clear payload value orbit report
            savedIndex=BranchSolutionFile_v3.index(staged);
            assertPublicEqual(branch_index,savedIndex,false,0);
            for pass=1:2
                checkTime();actualHeaders=whos('-file',staged);
                assert(isequal(sort(payloadNames),sort({actualHeaders.name}.')), ...
                    'C1Consolidate:Variables','MAT variable names differ.');
                for variable=1:numel(expectedHeaders)
                    h=expectedHeaders{variable};at=find(strcmp({actualHeaders.name},h.name));
                    assert(isscalar(at)&&strcmp(actualHeaders(at).class,h.class)&&isequal(actualHeaders(at).size,h.size), ...
                        'C1Consolidate:VariableHeader','MAT variable classes or shapes differ.');
                end
                backIndex=load(staged,'branch_index');assertPublicEqual(branch_index,backIndex.branch_index,false,0);clear backIndex
                coverage=false(numel(selected),1);
                for first=1:16:numel(selected)
                    checkTime();block=first:min(first+15,numel(selected));
                    [sourceOrbits,sourceReports]=readSourceBatch(nodes(selected(block)),sourceCatalog);
                    variables=cell(2*numel(block),1);
                    for within=1:numel(block)
                        point=branch_index.points{block(within)};
                        variables{2*within-1}=point.solution_variable;variables{2*within}=point.report_variable;
                    end
                    back=load(staged,variables{:});
                    assert(isequal(sort(fieldnames(back)),sort(variables)), ...
                        'C1Consolidate:Variables','A raw target chunk lost or added variables.');
                    for within=1:numel(block)
                        point=branch_index.points{block(within)};
                        assertPublicEqual(sourceOrbits{within},back.(point.solution_variable),true,0);
                        assertPublicEqual(sourceReports{within},back.(point.report_variable),false,0);
                    end
                    assert(~any(coverage(block)),'C1Consolidate:Coverage','A raw pass repeated records.');coverage(block)=true;
                    clear sourceOrbits sourceReports back
                end
                assert(all(coverage),'C1Consolidate:Coverage','A raw pass omitted records.');
            end
            coverage=false(numel(selected),1);
            for first=1:16:numel(selected)
                checkTime();block=first:min(first+15,numel(selected));
                [backOrbits,backReports,backPoints]=BranchSolutionFile_v3.loadSolutions(staged,block);
                [sourceOrbits,sourceReports,sourceMetadata]=readSourceBatch(nodes(selected(block)),sourceCatalog);
                for within=1:numel(block)
                    localIndex=block(within);node=nodes{selected(localIndex)};
                    assertPublicEqual(sourceOrbits{within},backOrbits{within},true,0);
                    assertPublicEqual(sourceReports{within},backReports{within},false,0);
                    assertPublicEqual(sourceMetadata{within},sourceCatalog{node.source_number}.point_metadata{node.source_index},false,0);
                    assertPublicEqual(branch_index.points{localIndex}.metadata,backPoints{within},false,0);
                end
                assert(~any(coverage(block)),'C1Consolidate:Coverage','The public pass repeated records.');coverage(block)=true;
                clear sourceOrbits sourceReports sourceMetadata backOrbits backReports backPoints
            end
            assert(all(coverage),'C1Consolidate:Coverage','The public pass omitted records.');
            if catalogue
                assert(isempty(graphMetadata.effective_edges),'C1Consolidate:Isolates', ...
                    'An isolated-record catalogue must contain no links or branch edges.');
            else,assertConnected(graphMetadata,numel(selected));end
            checkTime();publish(staged,file,false);clear cleaner
            assertPublicEqual(branch_index,BranchSolutionFile_v3.index(file),false,0);
            fileRow=struct('file',file,'sha256',RoundSHA256_v3(file), ...
                'component_index',componentNumber,'families',{families}, ...
                'points',numel(selected),'explicit_edges',size(localExplicit,1), ...
                'equality_links',size(localEquality,1),'qualified_aliases',size(localAlias,1), ...
                'qualified_numerical_overlaps',size(localNumerical,1), ...
                'energy_range',bounds(nodes,selected,'nativeE'), ...
                'mean_velocity_range',bounds(nodes,selected,'signedmeanU'), ...
                'whole_public_data_readback_verified',true,'connected',~catalogue||numel(selected)==1, ...
                'isolated_record_catalogue',catalogue,'original_connected_component_numbers',componentNumbers);
            if catalogue,receipt.isolated_records_file=fileRow;
            else,receipt.component_files{end+1,1}=fileRow;end
            writeReceipt();
            fprintf('C1_COMPONENT_WRITTEN %d/%d points=%d edges=%d equalities=%d\n', ...
                storageGroup,numel(groupMembers),numel(selected),size(localExplicit,1),size(localEquality,1));
            clear payload branch_index original back orbit report
        end
        for k=1:numel(sourceCatalog)
            checkTime();source=sourceCatalog{k};
            assert(strcmp(source.sha256,RoundSHA256_v3(source.file)), ...
                'C1Consolidate:SourceChanged','Source hash changed: %s.',source.file);
            receipt.source_catalog{k}.source_public_readback_verified=true;
        end
        assert(numel(receipt.occurrence_map)==numel(nodes) && ...
            numel(receipt.component_files)+receipt.packed_isolated_components==receipt.connected_components, ...
            'C1Consolidate:Coverage','Each source occurrence must appear exactly once.');
        if ~isempty(aliasRequests)
            assert(strcmp(RoundSHA256_v3(aliasQualificationSource.file),aliasQualificationSource.sha256), ...
                'C1Consolidate:AliasSource','The alias qualification source changed.');
        end
        if ~isempty(fieldnames(numericalQualificationSource))
            for k=1:numel(numericalQualificationSource)
                assert(strcmp(RoundSHA256_v3(numericalQualificationSource(k).file),numericalQualificationSource(k).sha256), ...
                    'C1Consolidate:NumericalOverlapSource','The numerical-overlap qualifier source changed before receipt completion.');
            end
        end
        receipt.source_public_readback_verified=true;
        receipt.source_hashes_verified_after_work=true;
        receipt.completed=true;receipt.completed_utc=stamp();receipt.wall_seconds=toc(timer);
        checkTime();writeReceipt();
    catch problem
        receipt.completed=false;receipt.failure=struct('identifier',problem.identifier,'message',problem.message);
        receipt.wall_seconds=toc(timer);writeReceipt();rethrow(problem)
    end
    fprintf('C1_COMPONENT_CONSOLIDATION_ACTUAL_RETURN completed=1 components=%d points=%d original_edges=%d equality_links=%d\n', ...
        receipt.connected_components,receipt.stored_occurrences,receipt.original_explicit_edges,receipt.exact_record_equalities);

    function checkTime()
        assert(toc(timer)<maxWall && posixtime(datetime('now','TimeZone','UTC'))<budget.deadline_unix_seconds && ...
            double(java.lang.System.nanoTime)<budget.deadline_monotonic_ns, ...
            'C1Consolidate:Budget','Shared final deadline or operation wall limit reached.');
    end
    function [orbit,report,pointMetadata]=readNode(selectedNode)
        nodeSource=sourceCatalog{selectedNode.source_number};
        % Discovery and final full-byte guards bind all isolated reads. No
        % writer may mutate a source during this single-writer transaction.
        nodePoint=selectedNode.point;
        nodeSaved=load(nodeSource.file,nodePoint.solution_variable,nodePoint.report_variable);
        orbit=nodeSaved.(nodePoint.solution_variable);report=nodeSaved.(nodePoint.report_variable);pointMetadata=nodePoint.metadata;
        assert(strcmp(OrbitContentIdentity_v3(orbit),selectedNode.native_ID), ...
            'C1Consolidate:SourceChanged','The numerical record changed during isolated loading.');
    end
    function writeReceipt()
        receiptStage=[tempname(fileparts(receiptFile)),'.mat'];
        receiptCleanup=onCleanup(@()removeStage(receiptStage));
        save(receiptStage,'receipt','-v7');receiptBack=load(receiptStage,'receipt');
        assertPublicEqual(receipt,receiptBack.receipt,false,0);
        publish(receiptStage,receiptFile,true);clear receiptCleanup
    end
end

function [chunkOrbits,chunkReports,chunkMetadata]=readSourceBatch(chunkNodes,sourceCatalog)
    % Group at most16 source-backed points by immutable source file.
    assert(iscell(chunkNodes)&&numel(chunkNodes)<=16,'C1Consolidate:Chunk','Source hydration chunks are bounded.');
    chunkOrbits=cell(numel(chunkNodes),1);chunkReports=chunkOrbits;chunkMetadata=chunkOrbits;
    chunkSourceNumbers=cellfun(@(n)n.source_number,chunkNodes);
    for chunkSourceNumber=unique(chunkSourceNumbers(:)).'
        chunkPositions=find(chunkSourceNumbers==chunkSourceNumber);chunkVariables=cell(2*numel(chunkPositions),1);
        for chunkWithin=1:numel(chunkPositions)
            chunkNode=chunkNodes{chunkPositions(chunkWithin)};chunkVariables{2*chunkWithin-1}=chunkNode.point.solution_variable;chunkVariables{2*chunkWithin}=chunkNode.point.report_variable;
        end
        chunkSaved=load(sourceCatalog{chunkSourceNumber}.file,chunkVariables{:});
        for chunkWithin=1:numel(chunkPositions)
            chunkPosition=chunkPositions(chunkWithin);chunkNode=chunkNodes{chunkPosition};
            chunkOrbit=chunkSaved.(chunkNode.point.solution_variable);chunkReport=chunkSaved.(chunkNode.point.report_variable);
            assert(strcmp(OrbitContentIdentity_v3(chunkOrbit),chunkNode.native_ID), ...
                'C1Consolidate:SourceChanged','The numerical record changed during source chunk loading.');
            chunkOrbits{chunkPosition}=chunkOrbit;chunkReports{chunkPosition}=chunkReport;chunkMetadata{chunkPosition}=chunkNode.point.metadata;
        end
        clear chunkSaved chunkOrbit chunkReport
    end
end

function [original,kind]=normalizedOriginalMetadata(metadata)
% One-level flatten only for a direct known envelope. A Run import retains
% its ENTIRE immediate metadata; no provenance crawl or scientific edit.
assert(isstruct(metadata)&&isscalar(metadata),'C1Consolidate:PointMetadata', ...
    'Every immediate point metadata record must be one scalar struct.');
original=metadata;kind=1;
if ~isfield(metadata,'consolidation_point_schema'),return;end
assert(isequal(metadata.consolidation_point_schema,'C1-consolidated-occurrence-v1') ...
    &&isfield(metadata,'provenance')&&isstruct(metadata.provenance)&&isscalar(metadata.provenance), ...
    'C1Consolidate:MarkedMetadata','A marked point needs the exact known schema and scalar provenance.');
p=metadata.provenance;
pathText=@(x)ischar(x)&&isrow(x)&&~isempty(x);
positiveIndex=@(x)isnumeric(x)&&isreal(x)&&isscalar(x)&&isfinite(x)&&x>=1&&x==fix(x);
direct={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
imported={'kind','source_file','source_index','original_provenance'};
if isequal(sort(fieldnames(p)),sort(direct(:)))
    assert(pathText(p.source_file)&&pathText(p.source_catalog_file)&&positiveIndex(p.source_index)&&positiveIndex(p.source_catalog_entry) ...
        &&ischar(p.source_sha256)&&isrow(p.source_sha256)&&~isempty(regexp(p.source_sha256,'^[0-9a-f]{64}$','once')) ...
        &&isstruct(p.original_point_metadata)&&isscalar(p.original_point_metadata)&&isequal(p.qualification_flags_changed,false), ...
        'C1Consolidate:DirectMetadata','The direct consolidation envelope is malformed; retain it and refuse.');
    original=p.original_point_metadata;kind=2;
elseif isequal(sort(fieldnames(p)),sort(imported(:)))
    assert(isequal(p.kind,'imported nonedge initial pair')&&pathText(p.source_file)&&positiveIndex(p.source_index) ...
        &&isstruct(p.original_provenance)&&isscalar(p.original_provenance)&&isfield(metadata,'edge_enabled') ...
        &&isequal(metadata.edge_enabled,false)&&~isfield(metadata,'edge_from'), ...
        'C1Consolidate:ImportedMetadata','Only the exact Run imported-NONEDGE wrapper may preserve its entire immediate metadata.');
    kind=3;
else
    error('C1Consolidate:MarkedMetadata','Unknown marked provenance shape; no generic fallback or recursive flatten is permitted.');
end
end

function validateAliasPoint(value,n)
assert(isnumeric(value)&&isreal(value)&&isscalar(value)&&isfinite(value) ...
    &&value==fix(value)&&value>=1&&value<=n,'C1Consolidate:Aliases', ...
    'Each alias selector needs one bounded positive integer occurrence index.');
end
function validateAliasIndices(pairs,n)
assert(isnumeric(pairs)&&isreal(pairs)&&ismatrix(pairs)&&size(pairs,2)==2 ...
    &&all(isfinite(pairs(:)))&&all(pairs(:)==fix(pairs(:)))&&all(pairs(:)>=1)&&all(pairs(:)<=n), ...
    'C1Consolidate:Aliases','Alias links require bounded positive integer occurrence indices.');
end
function tf=sameNumericalRecord(a,b)
tf=a.complete_return_section && b.complete_return_section && strcmp(a.native_ID,b.native_ID) && ...
    isequaln(a.normalized_state,b.normalized_state) && isequaln(a.initial_mode,b.initial_mode) && ...
    isequaln(a.parameter,b.parameter) && isequaln(a.period,b.period) && isequaln(a.stride,b.stride);
end
function assertConnected(metadata,n)
edges=metadata.effective_edges;bins=conncomp(graph(edges(:,1),edges(:,2),[],n));
assert(n>0 && max(bins)==1,'C1Consolidate:Disconnected','Output must contain one effective connected component.');
end
function output=bounds(nodes,indices,field)
values=cellfun(@(n)n.point.(field),nodes(indices));values=values(isfinite(values));
output=[];if ~isempty(values),output=[min(values),max(values)];end
end
function out=member(value,key,fallback)
out=fallback;if isstruct(value)&&isscalar(value)&&isfield(value,key),out=value.(key);end
end
function out=family(label)
match=regexp(char(label),'^(PK|BG|BE|FG|FE|HG|HE|GG|GE)[0-9]*$','tokens','once');
out='OTHER';if ~isempty(match),out=match{1};end
end
function path=canonical(value)
assert((ischar(value)&&isrow(value)&&~isempty(value))||(isstring(value)&&isscalar(value)&&strlength(value)>0), ...
    'C1Consolidate:Path','Expected scalar nonempty path text.');
path=char(java.io.File(char(value)).getCanonicalPath());
end
function tf=sameStat(a,b)
tf=isscalar(b)&&~b.isdir&&isequal(a.bytes,b.bytes)&&isequal(a.datenum,b.datenum);
end
function output=digestText(value)
digest=java.security.MessageDigest.getInstance('SHA-256');digest.update(unicode2native(value,'UTF-8'));
output=lower(reshape(dec2hex(typecast(digest.digest(),'uint8'),2).',1,[]));
end
function output=stamp()
output=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
end
function publish(stage,file,replace)
assert(replace||~isfile(file),'C1Consolidate:Exists','Refusing to replace a component file.');
if replace,count=2;else,count=1;end
options=javaArray('java.nio.file.CopyOption',count);
options(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');
if replace,options(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');end
javaMethod('move','java.nio.file.Files',java.io.File(stage).toPath(),java.io.File(file).toPath(),options);
end
function removeStage(stage)
if isfile(stage),delete(stage);end
end
function assertPublicEqual(original,saved,allowNative,depth)
% Byte-identical built-in serialization of a plain subtree is stronger than
% numerical isequaln: it preserves nested classes/shapes, sparse/complex
% storage, field order and NaN payloads. Different serialization falls back
% to the original recursive public-data comparison. Native handles always
% use that original recursive path. BranchSolutionFile's independent reader
% also validates every report/metadata subtree as plain data.
if ~allowNative && (isstruct(original)||iscell(original))
    try
        leftBytes=getByteStreamFromArray(original);rightBytes=getByteStreamFromArray(saved);
        if strcmp(class(original),class(saved))&&isequal(size(original),size(saved)) ...
                &&isequal(leftBytes,rightBytes),return;end
    catch
        % Serialization is only an optional equality accelerator.
    end
end
assert(depth<=128&&strcmp(class(original),class(saved))&&isequal(size(original),size(saved)), ...
    'C1Consolidate:Readback','Readback class, shape or nesting differs.');
if isnumeric(original)||islogical(original)
    assert(issparse(original)==issparse(saved)&&isreal(original)==isreal(saved)&&isequaln(original,saved), ...
        'C1Consolidate:Readback','Readback values or storage type differ.');
elseif ischar(original)||isstring(original)
    assert(isequaln(original,saved),'C1Consolidate:Readback','Readback text differs.');
elseif iscell(original)
    for k=1:numel(original),assertPublicEqual(original{k},saved{k},allowNative,depth+1);end
elseif isstruct(original)
    names=fieldnames(original);assert(isequal(names,fieldnames(saved)),'C1Consolidate:Readback','Struct fields differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),allowNative,depth+1);end;end
else
    assert(allowNative&&any(strcmp(class(original),{'HybridOrbit_v3','Trajectory_v3'})), ...
        'C1Consolidate:Readback','Unsupported public object class.');
    names=sort(properties(original));assert(isequal(names,sort(properties(saved))), ...
        'C1Consolidate:Readback','Public properties differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),true,depth+1);end;end
end
end


function validateNumericalEvidence(e,left,right,leftReport,rightReport,parent)
if isstruct(e)&&isscalar(e)&&isfield(e,'schema') ...
        &&strcmp(e.schema,'C1-qualified-finite-numerical-overlap-v1')
    C1FiniteNumericalOverlap_v3.validateRetained(e,left,right,leftReport,rightReport,parent);
    return
end
% Bind compact immutable qualification to actual retained public records.
% Native IDs were computed at full qualification. Comparing every literal
% identity-bearing field (including raw x) is stronger than that normalized
% ID binding; no unguarded identity helper or historical raw reload occurs.
assert(isstruct(e)&&isscalar(e)&&strcmp(e.schema,'C1-qualified-PK-numerical-overlap-v1') ...
    &&isequal(e.qualified,true)&&isequal(e.full_native_proof_validated,true) ...
    &&strcmp(e.proof_identity,'43b7037ec366d628018b40205545194a17f5291c45c3775ef4ddec290900d43c') ...
    &&strcmp(e.audit_reference.sha256,e.proof_identity)&&isequal(e.all_source_references_posthash_verified,true) ...
    &&isequal(e.identity_claimed,false)&&isequal(e.quotient_identification,false) ...
    &&isequal(e.new_continuation_edge_created,false)&&isequal(e.classification_or_admission_flags_changed,false) ...
    &&isequal(e.original_orbits_reports_and_native_IDs_retained,true), ...
    'C1NumericalAdjacency:Evidence','A retained numerical adjacency needs its distinct complete immutable qualification contract.');
for key={'left_native_ID','right_native_ID'}
    assert(~isempty(regexp(e.(key{1}),'^native-orbit-record:sha256:[0-9a-f]{64}$','once')), ...
        'C1NumericalAdjacency:Identity','A qualifier-produced native record identity is required.');
end
assert(isequaln(e.left_record,overlapRecord(left))&&isequaln(e.right_record,overlapRecord(right)), ...
    'C1NumericalAdjacency:Identity','The actual public endpoints must exactly retain all original identity-bearing fields.');
assert(isequaln(e.left_admission,overlapAdmission(leftReport)) ...
    &&isequaln(e.right_admission,overlapAdmission(rightReport)), ...
    'C1NumericalAdjacency:Admission','Current saved admission/classification/policy facts differ from original qualification.');
assert(isequaln(e.earned_physical_edge.from_record,overlapRecord(parent)) ...
    &&e.earned_physical_edge.from==2&&e.earned_physical_edge.to==3 ...
    &&e.earned_physical_edge.actual_new_points==1&&e.earned_physical_edge.actual_new_edges==1, ...
    'C1NumericalAdjacency:PhysicalEdge','The actual retained predecessor must bind the earned A2-to-C3 physical edge.');
assert(strcmp(e.execution_witness.schema,'C1-external-GateB-process-exit-witness-v1') ...
    &&e.execution_witness.process_session_id==39141&&e.execution_witness.actual_process_exit_observed ...
    &&e.execution_witness.exit_code==0&&strcmp(e.execution_witness.run_name,'GateBOwned01') ...
    &&strcmp(e.execution_witness.audit_reference.sha256,e.proof_identity), ...
    'C1NumericalAdjacency:Execution','External actual process closure remains distinct from stored audit completion.');
actual=overlapComparison(left,right,leftReport,rightReport);
assert(isequaln(actual,e.comparison)&&actual.conditions_met,'C1NumericalAdjacency:Comparison', ...
    'Every actual finite comparison must still match the original fixed contract; closeness alone creates no link.');
for side={'left_original_fines','right_original_fines'}
    rows=e.(side{1});assert(iscell(rows)&&numel(rows)==2,'C1NumericalAdjacency:Fines','Retained adjacency requires two original-state fine controls per endpoint.');
    for k=1:2
        f=rows{k};steps=[.0005,.00025];
        assert(f.MaxStep==steps(k)&&isequal(f.passed,true)&&isequal(f.initial_trajectory_row_exact,true) ...
            &&f.full13_norm<=1e-8&&f.matching_saved_section.compatible ...
            &&f.primitive.cover_count==1&&strcmp(f.primitive.status,'primitive_within_checked_bound') ...
            &&f.saved_period_scaled_error<=1e-8&&f.saved_stride_scaled_error<=1e-8 ...
            &&f.observation.invoked&&f.observation.returned&&f.observation.return_timely ...
            &&f.raw_custody.storage_completed&&f.raw_custody.storage_timely ...
            &&f.raw_custody.readback_completed&&f.raw_custody.readback_timely, ...
            'C1NumericalAdjacency:Fines','Literal original-state fine/timing facts cannot be inferred or upgraded.');
    end
end
end
function out=overlapRecord(o)
out=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter, ...
    'period',o.period,'stride_displacement',o.stride_displacement,'return_policy_name',o.return_policy_name);
end
function out=overlapAdmission(r)
names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations', ...
    'family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
for k=1:numel(names),assert(isequal(r.acceptance_gates.(names{k}),true),'C1NumericalAdjacency:Admission','The retained endpoint must preserve literal accepted all-nine admission.');end
status=member(r,'status',member(r,'native_status',''));assert(isequal(member(r,'accepted',strcmp(status,'accepted')),true), ...
    'C1NumericalAdjacency:Admission','A retained endpoint must have literal accepted native status.');g=r.classification;
assert(strcmp(member(g,'contract_version',''),'quadruped-gait-v3.5')&&strcmp(member(g,'validated_gait_type',''),'PK') ...
    &&strcmp(member(g,'canonical_point_label',''),'PK')&&isequal(member(g,'canonical_label_qualified',false),true) ...
    &&isequal(member(g,'flight_count_certain',false),true)&&isequal(member(g,'flight_count',NaN),1), ...
    'C1NumericalAdjacency:PK','Both actual saved endpoints must retain qualified current PK1.');
[policy,p]=RecordedReturnPolicy_v3(r);assert(p.complete&&isa(policy,'BLMarkedApexReturnPolicy_v3') ...
    &&policy.BLTouchdownsPerReturn==1&&policy.RequireModeClosure,'C1NumericalAdjacency:Policy','The retained endpoint must preserve its complete actual BL1 mode-closed policy.');
out=struct('all_nine_literal_true',true,'accepted',true,'stored_status',status,'classification',g, ...
    'policy_configuration',p.configuration,'original_flags_changed',false);
end
function out=overlapComparison(a,b,ra,rb)
dx=a.initial_state(2:14)-b.initial_state(2:14);sx=max([ones(13,1),abs(a.initial_state(2:14)),abs(b.initial_state(2:14))],[],2);
dt=a.period-b.period;ts=max([1,abs(a.period),abs(b.period)]);dq=a.stride_displacement-b.stride_displacement;
qs=max([ones(size(dq)),abs(a.stride_displacement),abs(b.stride_displacement)],[],2);
match=MatchingReturnSection_v3(a,b,{ra,rb});[~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);
out=struct('raw_full13_delta',dx,'raw_full13_scaled_inf',norm(dx./sx,inf),'period_delta',dt,'period_tolerance',1e-10*ts, ...
    'full_stride_delta',dq,'full_stride_tolerance',1e-10*qs, ...
    'native_energy_delta',QuadrupedEnergy_v3.evaluate(a.initial_state,a.initial_mode,a.parameter)-QuadrupedEnergy_v3.evaluate(b.initial_state,b.initial_mode,b.parameter), ...
    'exact_state_equal',isequaln(a.initial_state,b.initial_state),'exact_p_q_equal',isequaln(a.parameter,b.parameter)&&isequaln(a.initial_mode,b.initial_mode), ...
    'matching_section',match,'exact_complete_policy_equal',pa.complete&&pb.complete&&isequaln(pa.configuration,pb.configuration), ...
    'same_section_event_signature',strcmp(string(a.section_relative_event_signature),string(b.section_relative_event_signature)),'conditions_met',false);
out.conditions_met=out.raw_full13_scaled_inf<=1e-8&&abs(dt)<=out.period_tolerance&&all(abs(dq)<=out.full_stride_tolerance) ...
    &&out.exact_p_q_equal&&match.compatible&&out.exact_complete_policy_equal&&out.same_section_event_signature;
end
