function result=ColdRetainPK30hJoin20261101(acquireRef,witness,B,options)
%COLDRETAINPK30HJOIN20261101 One cold proof and full three-record transport.
% Public proof semantics and literal donor transport are unchanged. No physics.
    entryUTC=utc();entryMono=nano();N=fullfile(V3Root_v3(),'Research_v3','C1');W=fullfile(N,'.work_pk30h_20261101');
    assert(nargin==4&&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)), ...
        sort({'OutputFile';'RetainedFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&isequal(options.MaxWallSeconds,600)&&isequal(options.SaveMarginSeconds,60), ...
        'PKJoinCold:Options','Use the explicit fresh audit/retained paths and fixed600/60.');
    assert(B.capture.pid==feature('getpid'),'PKJoinCold:Budget','Calibrate the unchanged original grant in this process.');
    assert(min(B.research_deadline_unix_seconds-entryUTC,(B.research_deadline_monotonic_ns-entryMono)/1e9)>602, ...
        'PKJoinCold:WholeFit','The full600-second cold transport must fit the original science grant.');
    finish=limit(entryUTC+600,entryMono+600e9);work=limit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=literal(options.OutputFile);stage=[output,'.pending.mat'];retained=literal(options.RetainedFile);folder=fileparts(retained);
    assert(strcmp(output,fullfile(N,'Audits','PK30h_20261101_0170To0072_ColdQualification.mat')) ...
        &&strcmp(retained,fullfile(W,'Join0170To0072_Cold_Run01','Retained_Join.mat')) ...
        &&all(cellfun(@(f)~isfile(f)&&~isfolder(f),{output;stage;retained;[retained,'.pending.mat'];folder})), ...
        'PKJoinCold:Fresh','Retain any earlier/uncertain files; use exactly the declared fresh paths.');
    assert(strcmp(acquireRef.file,fullfile(N,'Audits','PK30h_20261101_0170To0072_Join01_Acquisition.mat')), ...
        'PKJoinCold:AcquireRef','Bind only the actual closed0170-to0072 acquisition.');
    assert(strcmp(witness.schema,'C1-external-native-process-exit-witness-v1') ...
        &&isequal(witness.actual_process_exit_observed,true)&&witness.exit_code==0 ...
        &&witness.process_session_id==34329&&witness.child_pid==2499 ...
        &&isequal(witness.source_posthash_verified,true)&&isequaln(witness.audit_reference,acquireRef), ...
        'PKJoinCold:Witness','Require actual34329/PID2499 exit0 and independent external postguards.');
    code=providers();inputs=[{acquireRef};code];verifyAll(inputs);check(work);
    audit=struct('schema','PK30h-0170-to0072-cold-retained-v1','acquire_reference',acquireRef, ...
        'external_witness',witness,'original_budget',B,'original_finish',finish,'options',options,'source_code',{code}, ...
        'input_references',{inputs},'cold',struct(),'qualifier_calls_attempted',0,'qualifier_calls_returned',0, ...
        'mandatory_cold_custody_complete',false,'source_posthash',false,'completed',false,'failure',struct(), ...
        'root_ODE_map_replay_classifier_calls',0,'new_admission_claimed',false,'new_scientific_edge_created',false, ...
        'own_process_exit_claimed',false);
    checkpoint(stage,audit);
    try
        loaded=load(acquireRef.file,'audit');a=loaded.audit;
        assert(strcmp(a.schema,'C1-finite-owned-PAL-numerical-overlap-experiment-v1')&&a.completed&&a.source_posthash ...
            &&a.ordinary_edge_earned&&a.qualified_numerical_relation&&a.target_index==54 ...
            &&a.fine_calls_attempted==4&&a.fine_calls_returned==4&&isempty(fieldnames(a.failure)), ...
            'PKJoinCold:Acquire','Use the actual qualified left3/target54 finite acquisition.');
        assert(isequal(a.source_pair,[15,16])&&strcmp(a.source_reference.sha256, ...
            '21611b1a7bcf44c66a9f66819a5fe88fad087fe4e2021cc40b8e5cff5985b506') ...
            &&strcmp(a.target_reference.sha256,'95fcae1ace29e0fdf1bcd42bd46a0b3c7d78b1c5b75e78c17ece73607d906a67'), ...
            'PKJoinCold:SelectedGeneration','Retain the actual selected source15-to16 and literal target54 generation.');
        for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'}
            assert(strcmp(B.(key{1}),a.budget.(key{1})),'PKLowCold:Grant','Never replace or renew the original grant.');
        end
        inputs=[inputs;a.source_code;{a.run_branch_reference;a.run_checkpoint_reference;a.target_reference;a.source_reference}];verifyAll(inputs);
        [pair,pr,pm]=BranchSolutionFile_v3.loadSolutions(a.run_branch_reference.file,[2;3]);
        [target,tr,tm]=BranchSolutionFile_v3.loadSolutions(a.target_reference.file,54);
        leftSelector=struct('file',a.run_branch_reference.file,'sha256',a.run_branch_reference.sha256,'index',3,'native_ID',OrbitContentIdentity_v3(pair{2}));
        right=struct('file',a.target_reference.file,'sha256',a.target_reference.sha256,'index',54,'native_ID',OrbitContentIdentity_v3(target{1}));
        proof=struct('schema','C1-finite-owned-PAL-numerical-overlap-proof-v1','audit_reference',acquireRef, ...
            'execution_witness',witness,'left_selector',leftSelector,'right_selector',right,'validation_limits',work);
        audit.cold=struct('original_proof',proof,'qualified',false,'evidence',struct(),'retained_reference',struct(), ...
            'full_native_read2_verified',false,'complete_policy_read2_verified',false);
        checkpoint(stage,audit);check(work);
        audit.qualifier_calls_attempted=audit.qualifier_calls_attempted+1;
        e=C1FiniteNumericalOverlap_v3.qualify(pair{2},target{1},pr{2},tr{1},proof);
        audit.qualifier_calls_returned=audit.qualifier_calls_returned+1;
        audit.cold.evidence=e;audit.cold.qualified=true;checkpoint(stage,audit);check(work);
        % The complete earned e is durable before transport bookkeeping.
        javaMethod('createDirectory','java.nio.file.Files',java.io.File(folder).toPath(),javaArray('java.nio.file.attribute.FileAttribute',0));
        os={pair{1};pair{2};target{1}};rs={pr{1};pr{2};tr{1}};original={pm{1};pm{2};tm{1}};ms=cell(3,1);
        sourceRefs={a.run_branch_reference;a.run_branch_reference;a.target_reference};sourceIndices=[2,3,54];
        for n=1:3
            m=original{n};owner='PK30h_ColdRetained_join_source';order=n;
            if n==3,owner='PK30h_ColdRetained_join_target';order=1;end
            ms{n}=struct('component_identity',owner,'classification',m.classification,'nativeE',m.nativeE, ...
                'signedmeanU',m.signedmeanU,'order',order,'edge_enabled',n==2, ...
                'provenance',struct('kind','literal retained finite-proof record transport','source_reference',sourceRefs{n}, ...
                    'source_index',sourceIndices(n),'original_point_metadata',m,'native_id',OrbitContentIdentity_v3(os{n}), ...
                    'fresh_admission_claimed',false,'original_scientific_flags_changed',false));
            if n==2,ms{n}.edge_from=1;end
        end
        fragment=struct('qualified_numerical_overlaps',[2,3],'numerical_overlap_evidence',{{e}});
        BranchSolutionFile_v3.initialize(retained,struct('schema','PK30h-selected-retained-finite-three-records-v1', ...
            'acquire_reference',acquireRef,'component_graph',fragment,'new_scientific_edge_created',false, ...
            'physical_edge_scope','Actual earned predecessor2-to3 remapped1-to2; target remains NONEDGE.'));
        BranchSolutionFile_v3.appendBatch(retained,os,rs,ms);
        for pass=1:2
            [back,br,bm]=BranchSolutionFile_v3.loadSolutions(retained,1:3);
            for n=1:3
                same(public(os{n}),public(back{n}));same(rs{n},br{n});same(ms{n},bm{n});same(original{n},bm{n}.provenance.original_point_metadata);
                assert(strcmp(OrbitContentIdentity_v3(back{n}),OrbitContentIdentity_v3(os{n})), ...
                    'PKLowCold:NativeID','Transported full native records retain their actual NativeIDs.');samePolicy(rs{n},br{n});
            end
        end
        ix=BranchSolutionFile_v3.index(retained);
        assert(numel(ix.points)==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2 ...
            &&~bm{1}.edge_enabled&&bm{2}.edge_enabled&&~bm{3}.edge_enabled, ...
            'PKLowCold:Graph','Keep only P1-to2 and M2-to3; target remains NONEDGE.');
        same(fragment,ix.metadata.component_graph);
        C1FiniteNumericalOverlap_v3.validateRetained(e,back{2},back{3},br{2},br{3},back{1});
        audit.cold.retained_reference=ref(retained);inputs{end+1,1}=audit.cold.retained_reference;
        audit.cold.original_physical_edge=[2,3];audit.cold.retained_physical_edge=[1,2];audit.cold.retained_numerical_row=[2,3];
        audit.cold.full_native_read2_verified=true;audit.cold.complete_policy_read2_verified=true;
        audit.mandatory_cold_custody_complete=true;audit.input_references=inputs;checkpoint(stage,audit);check(work);
        verifyAll(inputs);audit.input_references=inputs;audit.source_posthash=true;
        audit.completed=audit.mandatory_cold_custody_complete;
        audit.scope='Cold saved finite proof and literal full transport only; retainedP is the previously earned edge. M stays numerical; no new root/admission, exact identity, endpoint, P1 or global completion.';
    catch err,audit.failure=failure(err);audit.input_references=inputs;end
    checkpoint(stage,audit);check(finish);
    assert(audit.completed&&audit.source_posthash,'PKJoinCold:Incomplete','Retain all actual partial evidence: %s',jsonencode(audit.failure));
    before=RoundSHA256_v3(stage);assert(~isfile(output),'PKJoinCold:PublishFresh','Preserve a concurrent output.');
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath()) ...
        &&strcmp(RoundSHA256_v3(stage),before),'PKJoinCold:OwnStage','Remove only the unchanged linked own stage.');
    delete(stage);loaded=load(output,'audit');same(audit,loaded.audit);verifyAll(inputs);check(finish);
    result=struct('completed',true,'source_posthash',true,'audit_reference',ref(output),'retained_reference',ref(retained), ...
        'qualifier_calls_attempted',audit.qualifier_calls_attempted,'qualifier_calls_returned',audit.qualifier_calls_returned, ...
        'full_native_read2_verified',audit.cold.full_native_read2_verified,'complete_policy_read2_verified',audit.cold.complete_policy_read2_verified, ...
        'root_ODE_map_replay_classifier_calls',0,'new_admission_claimed',false,'own_process_exit_claimed',false);
    try,fprintf('PK30H_JOIN_COLD_RETAINED_RETURN %s\n',jsonencode(result));
    catch,fprintf('PK30H_JOIN_COLD_RETAINED_RETURN {"completed":true,"source_posthash":true,"optional_output_unavailable":true}\n');end
end
function refs=providers()
    names={'ColdRetainPK30hJoin20261101','C1FiniteNumericalOverlap_v3','AcquireC1NumericalOverlap_v3', ...
        'BranchSolutionFile_v3','HybridOrbit_v3','Trajectory_v3','RecordedReturnPolicy_v3', ...
        'OrbitContentIdentity_v3','C1ScientificDigest_v3','HybridSimulator_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cell(numel(names),1);for k=1:numel(names),refs{k}=ref(which(names{k}));end
    refs{end+1,1}=ref(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function f=failure(e),f=struct('identifier',e.identifier,'message',e.message,'stack',e.stack);end
function t=left(l),t=min(l.deadline_unix_seconds-utc(),(l.deadline_monotonic_ns-nano())/1e9);end
function samePolicy(a,b)
    [~,x]=RecordedReturnPolicy_v3(a);[~,y]=RecordedReturnPolicy_v3(b);
    assert(x.complete&&y.complete,'PKRemainingCold:Policy','Require complete actual recorded policy settings.');same(x.configuration,y.configuration);
end
function checkpoint(file,audit),save(file,'audit','-v7');back=load(file,'audit');same(audit,back.audit);end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKRemainingCold:Readback','Complete declared typed values differ.');end
function value=public(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=public(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=public(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=public(value{k});end
    end
end
function verifyAll(refs),for k=1:numel(refs),verify(refs{k});end,end
function verify(r),assert(strcmp(r.file,literal(r.file))&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKRemainingCold:Source','Immutable literal authority changed.');end
function r=ref(file),r=struct('file',literal(file),'sha256',RoundSHA256_v3(file));end
function p=literal(file),p=char(java.io.File(file).getCanonicalPath());assert(strcmp(p,char(java.io.File(V3Path_v3(file)).getCanonicalPath())),'PKRemainingCold:Alias','Hash and native read must address the same file.');end
function l=limit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function check(l),assert(utc()<l.deadline_unix_seconds&&nano()<l.deadline_monotonic_ns,'PKRemainingCold:Clock','Original600/60 clock expired.');end
function v=utc(),v=posixtime(datetime('now','TimeZone','UTC'));end
function v=nano(),v=double(java.lang.System.nanoTime());end
