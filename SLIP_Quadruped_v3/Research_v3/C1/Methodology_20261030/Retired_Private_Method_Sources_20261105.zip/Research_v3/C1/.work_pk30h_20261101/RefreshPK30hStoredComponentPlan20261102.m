function result=RefreshPK30hStoredComponentPlan20261102(B,bindings,options)
%REFRESHPK30HSTOREDCOMPONENTPLAN20261102 Append closed saved occurrences only.
% Parent scientific/metadata/evidence epochs stay literal. New E requires
% exact ORIGINAL full records/policies/sections; new M stays retained M.
    entryUTC=gpUTC();entryMono=gpNano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort( ...
        {'ParentPlanReference';'ParentClosureReference';'CurrentBranchRows';'ColdQueueReference';'ColdClosureReference';'ColdCarrierRows'})) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&options.MaxWallSeconds==1800&&options.SaveMarginSeconds==60&&B.capture.pid==feature('getpid'), ...
        'PKRefresh:Inputs','Use only the explicit closed append inputs and new original-grant1800/60 saved projection allowance.');
    assert(min(B.research_deadline_unix_seconds-entryUTC,(B.research_deadline_monotonic_ns-entryMono)/1e9)>1802, ...
        'PKRefresh:WholeFit','The complete new1800/60 operation must fit the unchanged original science UTC/JVM grant.');
    finish=gpLimit(entryUTC+1800,entryMono+1800e9);work=gpLimit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=gpLiteral(options.OutputFile);stage=[output,'.pending.mat'];failureFile=[output,'.failure.mat'];
    assert(startsWith(output,[gpLiteral(fullfile(N,'Audits')),filesep])&&all(cellfun(@(f)~isfile(f)&&~isfolder(f),{output;stage;failureFile})), ...
        'PKRefresh:Fresh','Use one fresh own graph-plan MAT/stage/failure path and preserve uncertain products.');
    assert(iscell(bindings.CurrentBranchRows)&&isequal(size(bindings.CurrentBranchRows),[2,1]) ...
        &&iscell(bindings.ColdCarrierRows)&&(isempty(bindings.ColdCarrierRows)||iscolumn(bindings.ColdCarrierRows))&&numel(bindings.ColdCarrierRows)<=5, ...
        'PKRefresh:Rows','Append exactly the two explicitly closed current branches and ALL actually retained cold carriers, at most five.');
    code=rfProviders();refs=[{bindings.ParentPlanReference;bindings.ParentClosureReference;bindings.ColdQueueReference;bindings.ColdClosureReference};code];gpVerify(refs);
    parentClosed=jsondecode(fileread(bindings.ParentClosureReference.file));
    assert(strcmp(parentClosed.schema,'PK30h-stored-graph-external-closure-v1')&&rfRefEqual(parentClosed.graph_reference,bindings.ParentPlanReference) ...
        &&parentClosed.process.actual_tool_exit_observed&&parentClosed.process.exit_code==0&&parentClosed.independent_post_guard.all_passed ...
        &&~parentClosed.raw_materialization_completion_claimed&&~parentClosed.scientific_completion_claimed, ...
        'PKRefresh:ParentClosed','Bind the actual successful graph-only parent and independent external process/postguard facts.');
    x=load(bindings.ParentPlanReference.file,'component_plan','plan_digest');parent=x.component_plan;rfSame(x.plan_digest,C1ScientificDigest_v3(parent));clear x
    assert(strcmp(parent.schema,'C1-stored-component-graph-plan-v1')&&parent.completed&&parent.source_posthash ...
        &&numel(parent.nodes)==1036&&numel(parent.source_catalog)==22&&parent.source_occurrence_bijection_verified, ...
        'PKRefresh:ParentScope','Preserve the exact original1036/22 parent, its old admission/M epochs and literal failed raw-materialization history.');
    for field={'grant_id','start_utc','research_deadline_utc','deadline_utc'},assert(strcmp(B.(field{1}),parent.original_budget.(field{1})),'PKRefresh:Grant','A new projection allowance never renews the original grant.');end
    parentView=C1StoredComponentSource_v3.prepare(rfAPIRef(bindings.ParentPlanReference));
    parentRefs=cellfun(@(c)struct('file',c.file,'sha256',c.sha256),parent.source_catalog,'UniformOutput',false);refs=[refs;parentRefs];gpVerify(refs);gpCheck(work);
    coldClosed=jsondecode(fileread(bindings.ColdClosureReference.file));
    assert(strcmp(coldClosed.schema,'PK30h-current-cold-external-closure-v1')&&rfRefEqual(coldClosed.queue_reference,bindings.ColdQueueReference) ...
        &&coldClosed.process.actual_tool_exit_observed&&coldClosed.process.exit_code==0&&coldClosed.independent_post_guard.all_passed&&coldClosed.all_owned_native_workers_closed, ...
        'PKRefresh:ColdClosed','Actual cold queue process closure/postguard is separate from its in-process proof flags.');
    x=load(bindings.ColdQueueReference.file,'audit');cold=x.audit;clear x
    assert(strcmp(cold.schema,'PK30h-current-five-case-cold-retained-v1')&&cold.completed&&cold.source_posthash&&numel(cold.cases)==5 ...
        &&~cold.unknown_publication_hold&&isempty(fieldnames(cold.pending_qualifier_call)), ...
        'PKRefresh:ColdQueue','Use the actual closed cold queue, retaining negative/refused cases literally without inventing carriers.');
    retainedCases=find(cellfun(@(r)r.transport_completed,cold.cases));declared=cellfun(@(r)r.case_index,bindings.ColdCarrierRows);
    assert(isequal(declared(:),retainedCases(:)),'PKRefresh:AllCarriers','ALL actually retained cold carriers are required in original case order; no silent P/M omission.');
    closedCarriers=coldClosed.retained_carrier_references;if isstruct(closedCarriers),closedCarriers=num2cell(closedCarriers(:));else,closedCarriers=closedCarriers(:);end
    assert(numel(closedCarriers)==numel(declared),'PKRefresh:ExternalCarrierCount','The actual external cold closure must name every retained carrier, with no extra or omitted source.');
    additions=cell(2+numel(declared),1);currentFacts=cell(2,1);
    for k=1:2
        row=bindings.CurrentBranchRows{k};currentFacts{k}=rfClosedBranch(row);refs=[refs;{row.reference;row.queue_reference;row.closure_reference}];
        additions{k}=struct('role',sprintf('current_branch_%d',k),'reference',row.reference,'kind','closed-current-P-branch','cold_case_index',0);
    end
    for k=1:numel(declared)
        row=bindings.ColdCarrierRows{k};z=cold.cases{row.case_index};
        assert(rfRefEqual(row.reference,z.retained_reference)&&rfRefEqual(row.reference,closedCarriers{k})&&z.cold_qualified&&z.full_native_read2_verified&&z.complete_policy_read2_verified ...
            &&strcmp(z.status,'COLD_QUALIFIED_P_AND_M_CARRIER_RETAINED'), ...
            'PKRefresh:CarrierAuthority','Each carrier must bind its actual cold-qualified full public/read2/policy result and original case selectors.');
        additions{2+k}=struct('role',sprintf('cold_M_case_%02d',row.case_index),'reference',row.reference,'kind','closed-retained-P-M-carrier','cold_case_index',row.case_index);refs{end+1,1}=row.reference;
    end
    paths=[cellfun(@(c)c.file,parent.source_catalog,'UniformOutput',false);cellfun(@(r)r.reference.file,additions,'UniformOutput',false)];
    assert(numel(unique(paths))==numel(paths),'PKRefresh:DistinctSources','Append distinct immutable source generations without replacing the parent catalogue.');gpVerify(refs);
    component_plan=parent;component_plan.completed=false;component_plan.source_posthash=false;component_plan.failure=struct();
    component_plan.parent_plan_reference=bindings.ParentPlanReference;component_plan.parent_closure_reference=bindings.ParentClosureReference;
    component_plan.parent_operation_history=struct('bindings',parent.bindings,'source_code',{parent.source_code},'input_references',{parent.input_references}, ...
        'original_budget',parent.original_budget,'operation_finish',parent.operation_finish,'operation_work',parent.operation_work,'completion_scope',parent.completion_scope,'acquisition_scope',parent.acquisition_scope);
    component_plan.bindings=bindings;component_plan.source_code=code;component_plan.input_references=refs;component_plan.original_budget=B;
    component_plan.operation_finish=finish;component_plan.operation_work=work;component_plan.completion_scope='REFRESH GRAPH PLAN ONLY: explicit closed source append and saved exactE/retainedM validation; no new admission, flow, raw component materialization or Core export.';
    result=struct('schema','PK30h-stored-graph-refresh-operation-v1','completed',false,'source_posthash',false,'plan_reference',struct(), ...
        'stage_save_returned',false,'stage_read2_verified',false,'publication_returned',false,'owned_stage_unlink_returned',false,'installed_read2_verified',false, ...
        'parent_occurrences',numel(parent.nodes),'added_occurrences',0,'occurrences',0,'component_count',0,'failure',struct(),'own_process_exit_claimed',false);
    try
        catalogue=parent.source_catalog;nodes=parent.nodes;points=parent.view_index.points;edges=parent.view_index.edges;owners=parent.view_index.metadata.source_owner_map;
        discovery=parent.graph_discovery;newNative=cell(0,1);newReports=cell(0,1);newGlobals=zeros(0,1);addedFacts=cell(numel(additions),1);retainedValidations=0;
        for s=1:numel(additions)
            gpCheck(work);row=additions{s};view=C1StoredComponentSource_v3.prepare(rfAPIRef(row.reference));ix=C1StoredComponentSource_v3.index(view);count=numel(ix.points);offset=numel(nodes);sourceNumber=numel(catalogue)+1;
            assert(strcmp(view.kind,'raw-branch')&&count>0,'PKRefresh:AddedKind','Only actual native closed BranchSolutionFile stores are append sources.');
            catalogue{sourceNumber,1}=struct('file',row.reference.file,'sha256',row.reference.sha256,'bytes',dirBytes(row.reference.file),'metadata',ix.metadata, ...
                'point_metadata',{cellfun(@(p)p.metadata,ix.points,'UniformOutput',false)},'original_edges',{ix.edges},'stored_points',count,'stored_edges',numel(ix.edges),'source_public_readback_verified',false);
            firstDigests=cell(count,1);
            for pass=1:2
                [native,reports,metadata]=C1StoredComponentSource_v3.load(view,(1:count).');
                if pass==2,assert(~(kept==native{1}),'PKRefresh:IndependentHandles','Use independently deserialized added-source records; only one witness handle spans passes.');end
                for j=1:count
                    digest=rfNativeDigest(native{j},reports{j},metadata{j});
                    if pass==1,firstDigests{j}=digest;else,rfSame(firstDigests{j},digest);end
                end
                if pass==1,kept=native{1};clear native reports metadata;end
            end
            graphPart=member(ix.metadata,'component_graph',struct());A=member(graphPart,'qualified_record_aliases',zeros(0,2));E=member(graphPart,'exact_record_equalities',zeros(0,2));M=member(graphPart,'qualified_numerical_overlaps',zeros(0,2));ME=member(graphPart,'numerical_overlap_evidence',cell(0,1));
            validateAliasIndices(A,count);validateAliasIndices(E,count);validateAliasIndices(M,count);
            assert(isempty(A)&&isempty(E),'PKRefresh:AddedTypedScope','These declared current-P branches and finite3-record carriers must not contain an unsupported inherited E/A table; preserve/refuse it rather than dropping relations.');
            if row.cold_case_index==0
                assert(isempty(M)&&isempty(ME),'PKRefresh:CurrentPOnly','Current continuation output contributes its actual P only; no association is inferred from range or screen.');
            else
                z=cold.cases{row.cold_case_index};assert(count==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2&&isequal(M,[2,3])&&iscell(ME)&&numel(ME)==1, ...
                    'PKRefresh:CarrierGraph','Retain exactly earnedP1-to2 and qualifiedM2-to3 with NONEDGE target.');rfSame(ME{1},z.evidence);
                C1FiniteNumericalOverlap_v3.validateRetained(ME{1},native{2},native{3},reports{2},reports{3},native{1});retainedValidations=retainedValidations+1;
            end
            for j=1:count
                originalPoint=ix.points{j};orbit=native{j};report=reports{j};section=MatchingReturnSection_v3(orbit,orbit,{report,report});state=orbit.initial_state(:);schema=QuadrupedSchema_v3.shared();state(schema.TranslationIndex)=0;
                globalIndex=offset+j;nodes{globalIndex,1}=struct('source_number',sourceNumber,'source_index',j,'point',originalPoint,'native_ID',OrbitContentIdentity_v3(orbit), ...
                    'normalized_state',state,'initial_mode',orbit.initial_mode(:),'parameter',orbit.parameter(:),'period',orbit.period,'stride',orbit.stride_displacement(:),'complete_return_section',section.compatible);
                owner=sprintf('source-%06d::%s',sourceNumber,char(originalPoint.component_identity));ownerRow=struct('source_number',sourceNumber,'source_component_identity',char(originalPoint.component_identity),'output_component_identity',owner);
                if ~any(cellfun(@(r)strcmp(r.output_component_identity,owner),owners)),owners{end+1,1}=ownerRow;end
                originalMetadata=normalizedOriginalMetadata(originalPoint.metadata);
                m=struct('component_identity',owner,'classification',char(originalPoint.classification),'nativeE',originalPoint.nativeE,'signedmeanU',originalPoint.signedmeanU, ...
                    'order',globalIndex,'consolidation_point_schema','C1-consolidated-occurrence-v1','provenance',struct('source_file',row.reference.file,'source_sha256',row.reference.sha256, ...
                    'source_index',j,'source_catalog_file',output,'source_catalog_entry',sourceNumber,'original_point_metadata',originalMetadata,'qualification_flags_changed',false));
                incoming=find(cellfun(@(e)e.to==j,ix.edges));assert(numel(incoming)<=1,'PKRefresh:Incoming','An actual occurrence has at most one physical predecessor.');
                if ~isempty(incoming),m.edge_enabled=true;m.edge_from=offset+ix.edges{incoming}.from;end
                points{globalIndex,1}=struct('index',globalIndex,'component_identity',owner,'order',globalIndex,'classification',m.classification,'nativeE',m.nativeE,'signedmeanU',m.signedmeanU, ...
                    'provenance',m.provenance,'metadata',m,'solution_variable',sprintf('solution_%06d',globalIndex),'report_variable',sprintf('report_%06d',globalIndex),'whole_public_data_readback_verified',false);
                newNative{end+1,1}=native{j};newReports{end+1,1}=reports{j};newGlobals(end+1,1)=globalIndex;
            end
            for j=1:numel(ix.edges)
                e=ix.edges{j};assert(strcmp(ix.points{e.from}.component_identity,ix.points{e.to}.component_identity),'PKRefresh:OwnedP','Every added P retains its actual same-owner original index edge.');
                discovery.physical_edges(end+1,:)=[offset+e.from,offset+e.to];edges{end+1,1}=struct('from',offset+e.from,'to',offset+e.to,'component_identity',points{offset+e.to}.component_identity);
            end
            for j=1:size(M,1)
                discovery.qualified_numerical_overlaps(end+1,:)=M(j,:)+offset;discovery.numerical_overlap_evidence{end+1,1}=ME{j};
                discovery.numerical_overlap_transports{end+1,1}=struct('kind','inherited_qualified_numerical_overlap','input_request',struct('source_file',row.reference.file,'source_sha256',row.reference.sha256,'source_overlap_row',j), ...
                    'left_node',offset+M(j,1),'right_node',offset+M(j,2),'original_evidence_unchanged',true);
            end
            addedFacts{s}=struct('role',row.role,'reference',row.reference,'source_number',sourceNumber,'global_indices',(offset+(1:count)).','point_count',count,'physical_edge_count',numel(ix.edges), ...
                'numerical_overlap_count',size(M,1),'independent_native_acquisitions',2,'one_handle_independence_witness_verified',true,'full_public_report_metadata_digest_read2_verified',true,'saved_admission_epoch_only',true);
            gpVerify({row.reference});gpCheck(work);fprintf('PK30H_GRAPH_REFRESH_SOURCE %d/%d points=%d P=%d M=%d\n',s,numel(additions),count,numel(ix.edges),size(M,1));clear native reports metadata view ix orbit report kept
        end
        newIDs=cellfun(@(g)nodes{g}.native_ID,num2cell(newGlobals),'UniformOutput',false);parentIDs=cellfun(@(r)r.native_ID,parent.nodes,'UniformOutput',false);
        matchedParent=find(ismember(parentIDs,newIDs));groups=C1StoredComponentSource_v3.groups(parentView,matchedParent);parentMatchedFacts=cell(numel(groups),1);newE=0;
        for k=1:numel(groups)
            gpCheck(work);group=groups{k};[native,reports]=C1StoredComponentSource_v3.load(parentView,group.indices);
            for j=1:numel(group.indices)
                parentIndex=group.indices(j);matches=find(strcmp(newIDs,parent.nodes{parentIndex}.native_ID));
                for q=matches(:).'
                    [eligible,evidence]=rfExactE(native{j},newNative{q},reports{j},newReports{q});
                    if eligible,discovery.exact_record_equalities(end+1,:)=[parentIndex,newGlobals(q)];discovery.equality_evidence{end+1,1}=evidence;newE=newE+1;end
                end
            end
            parentMatchedFacts{k}=struct('source_number',group.source_number,'parent_global_indices',group.indices,'acquired_native_records',numel(group.indices),'acquisitions',1,'scope','Matched original full-record/policy/section read only, not new whole-source admission/M qualification.');clear native reports
        end
        for j=1:numel(newGlobals)
            for k=j+1:numel(newGlobals)
                if ~strcmp(newIDs{j},newIDs{k}),continue;end
                [eligible,evidence]=rfExactE(newNative{j},newNative{k},newReports{j},newReports{k});
                if eligible,discovery.exact_record_equalities(end+1,:)=[newGlobals(j),newGlobals(k)];discovery.equality_evidence{end+1,1}=evidence;newE=newE+1;end
            end
        end
        clear newNative newReports
        rfSame(parent.nodes,nodes(1:numel(parent.nodes)));rfSame(parent.source_catalog,catalogue(1:numel(parent.source_catalog)));rfSame(parent.view_index.points,points(1:numel(parent.nodes)));rfSame(parent.view_index.edges,edges(1:numel(parent.view_index.edges)));
        for field={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'},key=field{1};rfSame(parent.graph_discovery.(key),discovery.(key)(1:size(parent.graph_discovery.(key),1),:));end
        for field={'equality_evidence','qualified_alias_evidence','numerical_overlap_evidence','numerical_overlap_transports'},key=field{1};old=parent.graph_discovery.(key);current=discovery.(key);rfSame(old,reshape(current(1:numel(old)),size(old)));end
        discovery.effective_edges=[discovery.physical_edges;discovery.exact_record_equalities;discovery.qualified_record_aliases;discovery.qualified_numerical_overlaps];
        count=numel(nodes);bins=conncomp(graph(discovery.effective_edges(:,1),discovery.effective_edges(:,2),[],count));componentCount=max(bins);newID=['C1-refresh:',C1ScientificDigest_v3(struct('parent',bindings.ParentPlanReference,'added_sources',{additions},'graph',discovery))];
        globalGraph=rfGraph(parent.view_index.metadata.component_graph,discovery,(1:count).',count,componentCount==1);globalMetadata=parent.view_index.metadata;
        globalMetadata.consolidation_id=newID;globalMetadata.component_number=0;globalMetadata.original_connected_component_numbers=1:componentCount;globalMetadata.families=unique(cellfun(@(r)family(r.point.classification),nodes,'UniformOutput',false));
        globalMetadata.source_catalog_file=output;globalMetadata.source_catalog_entries=1:numel(catalogue);globalMetadata.component_graph=globalGraph;globalMetadata.source_owner_map=owners;globalMetadata.scientific_flags_upgraded=false;
        components=cell(componentCount,1);occurrenceMap=cell(count,1);parentMap=zeros(numel(parent.nodes),5);coverage=false(count,1);
        for c=1:componentCount
            selected=find(bins==c).';toLocal=zeros(count,1);toLocal(selected)=1:numel(selected);localPoints=cell(numel(selected),1);localGraph=rfGraph(globalGraph,discovery,selected,count,true);localMetadata=globalMetadata;
            localMetadata.component_number=c;localMetadata.original_connected_component_numbers=c;localMetadata.component_graph=localGraph;localMetadata.families=unique(cellfun(@(r)family(r.point.classification),nodes(selected),'UniformOutput',false));localMetadata.source_catalog_entries=unique(cellfun(@(r)r.source_number,nodes(selected)));
            selectedOwners=cellfun(@(r)r.component_identity,points(selected),'UniformOutput',false);localMetadata.source_owner_map=owners(cellfun(@(r)any(strcmp(selectedOwners,r.output_component_identity)),owners));
            for j=1:numel(selected)
                g=selected(j);point=points{g};point.index=j;point.order=j;point.metadata.order=j;point.solution_variable=sprintf('solution_%06d',j);point.report_variable=sprintf('report_%06d',j);
                if isfield(point.metadata,'edge_from'),assert(toLocal(point.metadata.edge_from)>0,'PKRefresh:PhysicalParent','A physical parent must stay in its effective component.');point.metadata.edge_from=toLocal(point.metadata.edge_from);end
                localPoints{j}=point;node=nodes{g};source=catalogue{node.source_number};occurrenceMap{g}=struct('source_file',source.file,'source_sha256',source.sha256,'source_index',node.source_index,'global_index',g,'component_number',c,'component_index',j);
                if g<=numel(parent.nodes),old=parent.occurrence_map{g};parentMap(g,:)=[g,old.component_number,old.component_index,c,j];end
            end
            localEdges=cell(size(localGraph.original_explicit_edges,1),1);for j=1:numel(localEdges),p=localGraph.original_explicit_edges(j,:);localEdges{j}=struct('from',p(1),'to',p(2),'component_identity',localPoints{p(2)}.component_identity);end
            ix=struct('storage_version',parent.view_index.storage_version,'metadata',localMetadata,'points',{localPoints},'edges',{localEdges});assertConnected(localGraph,numel(selected));
            assert(~any(coverage(selected)),'PKRefresh:Bijection','Every original and appended occurrence has exactly one component/local selector.');coverage(selected)=true;
            components{c}=struct('component_number',c,'global_indices',selected(:),'planned_materialization_index',ix,'planned_index_digest',C1ScientificDigest_v3(ix),'materialization_completed_by_this_operation',false);
            fprintf('PK30H_GRAPH_REFRESH_COMPONENT %d/%d points=%d P=%d E=%d A=%d M=%d\n',c,componentCount,numel(selected),size(localGraph.original_explicit_edges,1),size(localGraph.exact_record_equalities,1),size(localGraph.qualified_record_aliases,1),size(localGraph.qualified_numerical_overlaps,1));
        end
        assert(all(coverage),'PKRefresh:Coverage','Preserve all parent and append-source occurrences without identity quotient or missing singleton.');
        for s=1:numel(catalogue),indices=cellfun(@(r)r.source_index,nodes(cellfun(@(r)r.source_number==s,nodes)));assert(isequal(sort(indices(:)),(1:catalogue{s}.stored_points).'),'PKRefresh:SourceBijection','Every source FILE/SHA/index appears exactly once.');end
        component_plan.consolidation_id=newID;component_plan.source_catalog=catalogue;component_plan.nodes=nodes;component_plan.graph_discovery=discovery;component_plan.components=components;component_plan.occurrence_map=occurrenceMap;
        component_plan.view_index=struct('storage_version',parent.view_index.storage_version,'metadata',globalMetadata,'points',{points},'edges',{edges});component_plan.source_occurrence_bijection_verified=true;
        component_plan.refresh=struct('parent_occurrences',numel(parent.nodes),'added_occurrences',numel(newGlobals),'added_sources',{addedFacts},'current_closed_branch_authorities',{currentFacts}, ...
            'cold_queue_reference',bindings.ColdQueueReference,'cold_external_closure_payload',coldClosed,'cold_case_statuses',{cellfun(@(r)r.status,cold.cases,'UniformOutput',false)}, ...
            'parent_to_current_map',parentMap,'parent_map_columns',{{'parent_global';'parent_component';'parent_local';'current_component';'current_local'}}, ...
            'parent_matched_source_acquisitions',{parentMatchedFacts},'new_exact_E_links',newE,'new_retained_M_validations',retainedValidations, ...
            'parent_nodes_catalogue_virtual_points_edges_and_all_relation_evidence_prefixes_literal',true,'parent_old_admission_M_epochs_preserved',true,'all_actual_cold_carriers_included',true, ...
            'new_sources_independent_acquisitions',2,'new_native_records_retained_only_after_second_pass_during_E_checks',numel(newGlobals),'parent_native_cache_retained',false, ...
            'maximum_new_source_records',max(cellfun(@(r)r.point_count,addedFacts)),'current_admission_inferred_for_parent',false,'new_admission_qualification_performed',false);
        component_plan.acquisition_scope=struct('parent_original_source_groups',numel(parent.source_catalog),'added_whole_source_groups',numel(additions),'added_independent_passes',2,'parent_matched_source_groups',numel(groups),'maximum_added_source_records',max(cellfun(@(r)r.point_count,addedFacts)),'one_independence_handle_per_added_source',true,'whole_parent_requalification_claimed',false,'universal16_record_bound_claimed',false,'process_RSS_measured_by_this_helper',false);
        component_plan.new_root_integrations_classifications_replays=0;component_plan.new_overlap_qualification_calls=0;component_plan.native_payload_copied=false;component_plan.scientific_completion_claimed=false;component_plan.source_retirement_authorized=false;component_plan.own_process_exit_claimed=false;
        component_plan.global_index_scope='Original parent1036 global nodes/order/virtual points remain literal. Appended global order is bookkeeping; each planned local index remaps order and physical parent. Core preserves chosen global point.order and remaps edge_from by its existing selected-global map.';
        component_plan.input_references=refs;gpVerify(refs);gpCheck(work);component_plan.source_posthash=true;component_plan.completed=true;component_plan.completed_utc=stamp();component_plan.wall_seconds=(gpNano()-entryMono)/1e9;
        plan_digest=C1ScientificDigest_v3(component_plan);save(stage,'component_plan','plan_digest','-v7');result.stage_save_returned=true;gpRead2(stage,component_plan);result.stage_read2_verified=true;gpVerify(refs);gpCheck(finish);
        stageHash=RoundSHA256_v3(stage);assert(~isfile(output),'PKRefresh:PublishFresh','Retain a concurrent final result.');javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());result.publication_returned=true;
        assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),stageHash)&&strcmp(RoundSHA256_v3(output),stageHash),'PKRefresh:OwnStage','Unlink only the unchanged hardlinked own plan stage.');
        javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());result.owned_stage_unlink_returned=true;gpRead2(output,component_plan);result.installed_read2_verified=true;gpVerify(refs);gpCheck(finish);
        result.plan_reference=gpRef(output);result.completed=true;result.source_posthash=true;result.added_occurrences=numel(newGlobals);result.occurrences=count;result.component_count=componentCount;
    catch problem
        result.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);component_plan.completed=false;component_plan.failure=result.failure;
        if ~isfile(failureFile),plan_digest=C1ScientificDigest_v3(component_plan);operation_result=result;save(failureFile,'component_plan','plan_digest','operation_result','-v7');end
    end
    result.elapsed_seconds=(gpNano()-entryMono)/1e9;result.scope='Saved GRAPH REFRESH ONLY. Old epochs/failed raw flags remain historical; current native admission, future Core/working export, actual process exit, scientific completion and source/frontier retirement are unclaimed.';
    try,fprintf('PK30H_GRAPH_REFRESH_RETURN %s\n',jsonencode(result));catch,end
end
function out=rfClosedBranch(row)
    assert(isstruct(row)&&isscalar(row)&&isequal(sort(fieldnames(row)),sort({'reference';'queue_reference';'closure_reference';'job_index'})), ...
        'PKRefresh:CurrentRow','A current branch needs explicit native queue job and immutable external closure.');
    gpVerify({row.reference;row.queue_reference;row.closure_reference});closed=jsondecode(fileread(row.closure_reference.file));
    assert(strcmp(closed.schema,'PK30h-continuation-window-external-closure-v1')&&rfRefEqual(closed.queue_reference,row.queue_reference) ...
        &&closed.process.actual_tool_exit_observed&&closed.process.exit_code==0&&closed.independent_post_guard.all_passed&&closed.independent_post_guard.process_absence_verified, ...
        'PKRefresh:CurrentClosed','Use an actually closed continuation window, never native self-certified tool exit.');
    refs=closed.branch_references;if isstruct(refs),refs=num2cell(refs(:));end
    assert(sum(cellfun(@(r)rfRefEqual(r,row.reference),refs))==1,'PKRefresh:ClosedBranchJoin','Bind only the selected closed exact branch header; other historical mutable locators are not live inputs.');
    x=load(row.queue_reference.file,'audit');queue=x.audit;validateAliasPoint(row.job_index,numel(queue.jobs));job=queue.jobs{row.job_index};
    assert(strcmp(queue.schema,'resident-native-frontier-queue-v1')&&queue.completed&&queue.source_posthash&&queue.all_requested_jobs_returned&&rfRefEqual(job.output_reference,row.reference) ...
        &&job.pending_count==0&&job.persistence_completion_confirmed,'PKRefresh:CurrentQueue','The selected actual job needs exact output generation and closed nonpending persistence.');
    out=struct('reference',row.reference,'queue_reference',row.queue_reference,'closure_reference',row.closure_reference,'job_index',row.job_index,'actual_job',job, ...
        'process',closed.process,'independent_post_guard_all_passed',closed.independent_post_guard.all_passed,'qualification_scope','Recorded admission in this immutable source only; no epoch transfer to parent records.');
end
function [yes,e]=rfExactE(a,b,ra,rb)
    e=struct();yes=false;if ~strcmp(OrbitContentIdentity_v3(a),OrbitContentIdentity_v3(b))||~isequaln(rfRecord(a),rfRecord(b)),return;end
    [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);if ~pa.complete||~pb.complete||~isequaln(pa.configuration,pb.configuration),return;end
    match=MatchingReturnSection_v3(a,b,{ra,rb});if ~match.compatible,return;end
    yes=true;e=struct('native_ID',OrbitContentIdentity_v3(a),'exact_state_mode_parameter_period_stride',true,'translation_gauge_normalized',false,'raw14_state_exact',true, ...
        'complete_policy_equal',true,'matching_return_section',match,'new_continuation_edge_created',false,'new_admission_claimed',false,'source_admission_epochs_unchanged',true);
end
function r=rfRecord(o)
    r=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement, ...
        'return_policy_name',o.return_policy_name,'section_chart',o.section_chart,'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature);
end
function digest=rfNativeDigest(o,r,m),digest=C1ScientificDigest_v3(struct('orbit',rfPublic(o),'report',rfPublic(r),'metadata',m));end
function yes=rfRefEqual(a,b)
    yes=isstruct(a)&&isscalar(a)&&isstruct(b)&&isscalar(b)&&all(isfield(a,{'file','sha256'}))&&all(isfield(b,{'file','sha256'}))&&strcmp(a.file,b.file)&&strcmp(a.sha256,b.sha256);
    if yes&&isfield(a,'bytes')&&isfield(b,'bytes'),yes=isequal(double(a.bytes),double(b.bytes));end
end
function r=rfAPIRef(r),r=struct('file',r.file,'sha256',r.sha256);end
function rfSame(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKRefresh:Typed','Complete typed plain values differ.');end
function bytes=dirBytes(file),d=dir(file);assert(isscalar(d)&&~d.isdir,'PKRefresh:File','An exact source must remain one regular native file.');bytes=d.bytes;end
function g=rfGraph(template,d,selected,n,connected)
    map=zeros(n,1);map(selected)=1:numel(selected);g=template;g.nodes=numel(selected);
    fields={'original_explicit_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};actual={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};masks=cell(4,1);
    for k=1:4,p=d.(actual{k});mask=ismember(p(:,1),selected)&ismember(p(:,2),selected);masks{k}=mask;g.(fields{k})=reshape(map(p(mask,:)),[],2);end
    g.qualified_alias_evidence=d.qualified_alias_evidence(masks{3});g.numerical_overlap_evidence=d.numerical_overlap_evidence(masks{4});g.equality_evidence=d.equality_evidence(masks{2});
    g.effective_edges=[g.original_explicit_edges;g.exact_record_equalities;g.qualified_record_aliases;g.qualified_numerical_overlaps];g.connected=connected;g.isolated_record_catalogue=false;
end
function refs=rfProviders()
    names={'RefreshPK30hStoredComponentPlan20261102','C1StoredComponentSource_v3','BranchSolutionFile_v3','C1FiniteNumericalOverlap_v3', ...
        'RecordedReturnPolicy_v3','MatchingReturnSection_v3','ReturnPolicyBase_v3','BLMarkedApexReturnPolicy_v3','EventCycleReturnPolicy_v3','IteratedReturnPolicy_v3','FirstReturnPolicy_v3','OrbitContentIdentity_v3','QuadrupedSchema_v3','HybridOrbit_v3','Trajectory_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cellfun(@(name)gpRef(which(name)),names(:),'UniformOutput',false);refs{end+1,1}=gpRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end

function [original,kind]=normalizedOriginalMetadata(metadata)
% One-level flatten only for a direct known envelope. A Run import retains
% its ENTIRE immediate metadata; no provenance crawl or scientific edit.
assert(isstruct(metadata)&&isscalar(metadata),'C1Consolidate:PointMetadata', ...
    'Every immediate point metadata record must be one scalar struct.');
original=metadata;kind=1;
if ~isfield(metadata,'consolidation_point_schema'),return;end
assert(isequal(metadata.consolidation_point_schema,'C1-consolidated-occurrence-v1') ...
    &&isfield(metadata,'provenance')&&isstruct(metadata.provenance)&&isscalar(metadata.provenance), ...
    'C1Consolidate:MarkedMetadata','A marked point needs the exact known schema and scalar provenance.');
p=metadata.provenance;
pathText=@(x)ischar(x)&&isrow(x)&&~isempty(x);
positiveIndex=@(x)isnumeric(x)&&isreal(x)&&isscalar(x)&&isfinite(x)&&x>=1&&x==fix(x);
direct={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
imported={'kind','source_file','source_index','original_provenance'};
if isequal(sort(fieldnames(p)),sort(direct(:)))
    assert(pathText(p.source_file)&&pathText(p.source_catalog_file)&&positiveIndex(p.source_index)&&positiveIndex(p.source_catalog_entry) ...
        &&ischar(p.source_sha256)&&isrow(p.source_sha256)&&~isempty(regexp(p.source_sha256,'^[0-9a-f]{64}$','once')) ...
        &&isstruct(p.original_point_metadata)&&isscalar(p.original_point_metadata)&&isequal(p.qualification_flags_changed,false), ...
        'C1Consolidate:DirectMetadata','The direct consolidation envelope is malformed; retain it and refuse.');
    original=p.original_point_metadata;kind=2;
elseif isequal(sort(fieldnames(p)),sort(imported(:)))
    assert(isequal(p.kind,'imported nonedge initial pair')&&pathText(p.source_file)&&positiveIndex(p.source_index) ...
        &&isstruct(p.original_provenance)&&isscalar(p.original_provenance)&&isfield(metadata,'edge_enabled') ...
        &&isequal(metadata.edge_enabled,false)&&~isfield(metadata,'edge_from'), ...
        'C1Consolidate:ImportedMetadata','Only the exact Run imported-NONEDGE wrapper may preserve its entire immediate metadata.');
    kind=3;
else
    error('C1Consolidate:MarkedMetadata','Unknown marked provenance shape; no generic fallback or recursive flatten is permitted.');
end
end

function validateAliasPoint(value,n)
assert(isnumeric(value)&&isreal(value)&&isscalar(value)&&isfinite(value) ...
    &&value==fix(value)&&value>=1&&value<=n,'C1Consolidate:Aliases', ...
    'Each alias selector needs one bounded positive integer occurrence index.');
end
function validateAliasIndices(pairs,n)
assert(isnumeric(pairs)&&isreal(pairs)&&ismatrix(pairs)&&size(pairs,2)==2 ...
    &&all(isfinite(pairs(:)))&&all(pairs(:)==fix(pairs(:)))&&all(pairs(:)>=1)&&all(pairs(:)<=n), ...
    'C1Consolidate:Aliases','Alias links require bounded positive integer occurrence indices.');
end
function assertConnected(metadata,n)
edges=metadata.effective_edges;bins=conncomp(graph(edges(:,1),edges(:,2),[],n));
assert(n>0 && max(bins)==1,'C1Consolidate:Disconnected','Output must contain one effective connected component.');
end
function out=member(value,key,fallback)
out=fallback;if isstruct(value)&&isscalar(value)&&isfield(value,key),out=value.(key);end
end
function out=family(label)
match=regexp(char(label),'^(PK|BG|BE|FG|FE|HG|HE|GG|GE)[0-9]*$','tokens','once');
out='OTHER';if ~isempty(match),out=match{1};end
end
function path=canonical(value)
assert((ischar(value)&&isrow(value)&&~isempty(value))||(isstring(value)&&isscalar(value)&&strlength(value)>0), ...
    'C1Consolidate:Path','Expected scalar nonempty path text.');
path=char(java.io.File(char(value)).getCanonicalPath());
end
function output=stamp()
output=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
end
function assertPublicEqual(original,saved,allowNative,depth)
% Byte-identical built-in serialization of a plain subtree is stronger than
% numerical isequaln: it preserves nested classes/shapes, sparse/complex
% storage, field order and NaN payloads. Different serialization falls back
% to the original recursive public-data comparison. Native handles always
% use that original recursive path. BranchSolutionFile's independent reader
% also validates every report/metadata subtree as plain data.
if ~allowNative && (isstruct(original)||iscell(original))
    try
        leftBytes=getByteStreamFromArray(original);rightBytes=getByteStreamFromArray(saved);
        if strcmp(class(original),class(saved))&&isequal(size(original),size(saved)) ...
                &&isequal(leftBytes,rightBytes),return;end
    catch
        % Serialization is only an optional equality accelerator.
    end
end
assert(depth<=128&&strcmp(class(original),class(saved))&&isequal(size(original),size(saved)), ...
    'C1Consolidate:Readback','Readback class, shape or nesting differs.');
if isnumeric(original)||islogical(original)
    assert(issparse(original)==issparse(saved)&&isreal(original)==isreal(saved)&&isequaln(original,saved), ...
        'C1Consolidate:Readback','Readback values or storage type differ.');
elseif ischar(original)||isstring(original)
    assert(isequaln(original,saved),'C1Consolidate:Readback','Readback text differs.');
elseif iscell(original)
    for k=1:numel(original),assertPublicEqual(original{k},saved{k},allowNative,depth+1);end
elseif isstruct(original)
    names=fieldnames(original);assert(isequal(names,fieldnames(saved)),'C1Consolidate:Readback','Struct fields differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),allowNative,depth+1);end;end
else
    assert(allowNative&&any(strcmp(class(original),{'HybridOrbit_v3','Trajectory_v3'})), ...
        'C1Consolidate:Readback','Unsupported public object class.');
    names=sort(properties(original));assert(isequal(names,sort(properties(saved))), ...
        'C1Consolidate:Readback','Public properties differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),true,depth+1);end;end
end
end


function gpRead2(file,expected)
    for pass=1:2
        x=load(file,'component_plan','plan_digest');assert(strcmp(C1ScientificDigest_v3(x.component_plan),x.plan_digest), ...
            'PKGraphPlan:ReadDigest','Each independent plan read must verify its whole typed digest.');
        assertPublicEqual(expected,x.component_plan,false,0);clear x
    end
end
function gpVerify(refs)
    for k=1:numel(refs)
        r=refs{k};assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'}))&&strcmp(r.file,gpLiteral(r.file)) ...
            &&ischar(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once'))&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
            'PKGraphPlan:Changed','A consumed immutable source/proof/closure/prefix or current graph recipe changed.');
        if isfield(r,'bytes')
            d=dir(r.file);assert(isscalar(d)&&~d.isdir&&isequal(double(d.bytes),double(r.bytes)), ...
                'PKGraphPlan:Bytes','The actual immutable reference must retain its declared whole-file byte count.');
        end
    end
end
function r=gpRef(file),r=struct('file',gpLiteral(file),'sha256',RoundSHA256_v3(file));end
function file=gpLiteral(value),file=canonical(value);assert(strcmp(file,canonical(V3Path_v3(value))),'PKGraphPlan:Alias','Hash/native-read paths must name the same literal file.');end
function l=gpLimit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function gpCheck(l),assert(min(l.deadline_unix_seconds-gpUTC(),(l.deadline_monotonic_ns-gpNano())/1e9)>0,'PKGraphPlan:Clock','The original grant/operation clocks expired; retain all actual partial/published files.');end
function t=gpUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=gpNano(),t=double(java.lang.System.nanoTime());end

function value=rfPublic(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=rfPublic(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=rfPublic(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=rfPublic(value{k});end
    end
end
