function audit=InspectEventRestartReplayInputs20261102()
%INSPECTEVENTRESTARTREPLAYINPUTS20261102 Native saved-header discovery only.
% No flow, energy, map, classifier, root, correction or admission is invoked.
    V=V3Root_v3();N=fullfile(V,'Research_v3','C1');
    pk=fullfile(N,'Components','C1_PK_Component_0061.mat');
    generic=fullfile(V,'P1_Single_Flight_Phase_Continua','Bifurcation_Audits', ...
        'Strict_Contact_Results','Validated_Generic_Principal_Points','C1_G_10_20_2.mat');
    refs={reference(pk);reference(generic)};
    assert(strcmp(refs{1}.sha256,'821ed8549ec94c7fdd28d5de37579762d0825e277a15be045472c365c01c9486') ...
        &&strcmp(refs{2}.sha256,'d4d37aa3db32c34298b8e6db13a756e46fba3f6995087f185434545f15e785bb'), ...
        'EventReplayInspect:Source','Inspect the literal retained PK0061 and generic G datasets.');
    indices=[54;55;56;57];ix=BranchSolutionFile_v3.index(pk);
    [o,r,m]=BranchSolutionFile_v3.loadSolutions(pk,indices);
    [oo,rr,mm]=BranchSolutionFile_v3.loadSolutions(pk,indices);
    rows=cell(numel(indices),1);
    for k=1:numel(indices)
        firstHeader=orbitHeader(o{k});secondHeader=orbitHeader(oo{k});
        assert(strcmp(OrbitContentIdentity_v3(o{k}),OrbitContentIdentity_v3(oo{k})) ...
            &&strcmp(C1ScientificDigest_v3(firstHeader),C1ScientificDigest_v3(secondHeader)) ...
            &&strcmp(C1ScientificDigest_v3(r{k}),C1ScientificDigest_v3(rr{k})) ...
            &&strcmp(C1ScientificDigest_v3(m{k}),C1ScientificDigest_v3(mm{k})), ...
            'EventReplayInspect:Read2','Each selected literal orbit/report/metadata must deserialize consistently.');
        rows{k}=firstHeader;rows{k}.index=indices(k);
        rows{k}.index_point=selected(ix.points{indices(k)},{'index','component_identity','order', ...
            'classification','nativeE','signedmeanU','solution_variable','report_variable'});
        rows{k}.report_fields=fieldnames(r{k});rows{k}.report_tree=tree(r{k},'',2);
        rows{k}.accepted=member(r{k},'accepted',[]);rows{k}.status=member(r{k},'status','');
        rows{k}.acceptance_gates=member(r{k},'acceptance_gates',struct());
        [~,rows{k}.recorded_policy]=RecordedReturnPolicy_v3(r{k});
        rows{k}.classification=classificationHeader(member(r{k},'classification',struct()));
        rows{k}.options_header=selected(member(r{k},'options',struct()), ...
            {'MaxReturnTime','MaxCycleEvents','MaxSectionCrossings','IntegrationMaxStep','IntegrationRelTol','IntegrationAbsTol'});
        rows{k}.replay_integration_header=tree(member(r{k},'replay_integration',struct()),'',2);
        rows{k}.report_digest=C1ScientificDigest_v3(r{k});
    end
    g=load(generic);gg=load(generic);
    genericHeader=datasetHeader(g,generic);genericHeader2=datasetHeader(gg,generic);
    assert(strcmp(C1ScientificDigest_v3(genericHeader),C1ScientificDigest_v3(genericHeader2)), ...
        'EventReplayInspect:Read2','The small generic dataset header must deserialize consistently.');
    for k=1:numel(refs),assert(strcmp(RoundSHA256_v3(refs{k}.file),refs{k}.sha256));end
    audit=struct('schema','event-restart-replay-input-native-inspection-v1', ...
        'source_references',{refs},'PK0061_rows',{rows},'generic_G_header',genericHeader, ...
        'source_posthash',true,'completed',true,'flow_energy_map_root_classifier_admission_calls',0);
    fprintf('EVENT_RESTART_REPLAY_INPUT_HEADERS %s\n',jsonencode(audit));
end
function genericHeader=datasetHeader(g,file)
    genericHeader=struct('variables',{whos('-file',file)},'tree',{tree(g,'',4)});
    if isfield(g,'solutions')&&iscell(g.solutions)&&numel(g.solutions)==1
        v=g.solutions{1};genericHeader.solution_class=class(v);
        if isa(v,'HybridOrbit_v3'),genericHeader.orbit=orbitHeader(v);
        elseif isstruct(v)&&isscalar(v)
            genericHeader.solution_fields=fieldnames(v);
            genericHeader.solution_tree=tree(v,'solutions{1}',4);
            if isfield(v,'orbit')&&isa(v.orbit,'HybridOrbit_v3'),genericHeader.orbit=orbitHeader(v.orbit);end
        end
    end
end
function h=orbitHeader(o)
    assert(isa(o,'HybridOrbit_v3')&&isscalar(o),'EventReplayInspect:Orbit');
    policy=o.return_policy;
    if isobject(policy)||isa(policy,'function_handle')
        policy=struct('supported_plain',false,'unsupported_class',class(policy),'size',size(policy));
    end
    h=struct('native_id',OrbitContentIdentity_v3(o),'initial_state',o.initial_state, ...
        'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period, ...
        'stride_displacement',o.stride_displacement,'return_policy',policy, ...
        'return_policy_name',o.return_policy_name,'return_multiplicity',o.return_multiplicity, ...
        'section_chart',o.section_chart,'event_signature',o.section_relative_event_signature, ...
        'cohort_signature',o.event_cluster_signature,'event_count',numel(o.event_history));
end
function rows=tree(v,path,depth)
    rows=cell(0,1);
    if depth<0,return;end
    if isstruct(v)&&isscalar(v)
        keys=fieldnames(v);
        for k=1:numel(keys)
            key=keys{k};name=key;if ~isempty(path),name=[path,'.',key];end
            value=v.(key);row=struct('path',name,'class',class(value),'size',size(value));
            if (isnumeric(value)||islogical(value))&&numel(value)<=14,row.value=value;
            elseif (ischar(value)&&numel(value)<=200)||(isstring(value)&&isscalar(value)),row.value=value;
            elseif iscell(value)&&numel(value)==1,row.cell_value_class=class(value{1});
                if isstruct(value{1})&&isscalar(value{1}),row.children=tree(value{1},[name,'{1}'],depth-1);end
            elseif isstruct(value)&&isscalar(value),row.children=tree(value,name,depth-1);
            elseif isobject(value)&&isscalar(value),row.public_properties=properties(value);end
            rows{end+1,1}=row; %#ok<AGROW>
        end
    end
end
function h=classificationHeader(v)
    h=selected(v,{'contract_version','canonical_point_label','canonical_label_qualified', ...
        'validated_gait_type','flight_count','flight_count_certain'});
end
function out=selected(v,keys)
    out=struct();if ~isstruct(v)||~isscalar(v),out.unsupported_class=class(v);return;end
    for k=1:numel(keys),if isfield(v,keys{k}),out.(keys{k})=v.(keys{k});end,end
end
function out=member(v,key,fallback)
    out=fallback;if isstruct(v)&&isscalar(v)&&isfield(v,key),out=v.(key);end
end
function r=reference(file)
    d=dir(file);assert(isscalar(d));r=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',d.bytes);
end
