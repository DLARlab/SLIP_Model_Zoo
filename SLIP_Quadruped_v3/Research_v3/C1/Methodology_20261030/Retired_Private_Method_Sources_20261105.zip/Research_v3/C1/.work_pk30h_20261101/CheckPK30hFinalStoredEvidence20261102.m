function out=CheckPK30hFinalStoredEvidence20261102()
% A fresh native-process storage check and saved numerical evidence summary.
V=V3Root_v3();N=fullfile(V,'Research_v3','C1');A=fullfile(N,'Audits');W=fullfile(N,'.work_pk30h_20261101');
packetFile=fullfile(W,'CheckPK30hFinalStoredEvidence01.inputs.json');packet=jsondecode(fileread(packetFile));
refs=num2cell(packet.references(:));for k=1:numel(packet.methods),r=packet.methods(k);assert(strcmp(which(r.name),r.file),'PKFinalEvidence:Provider','Use the reviewed canonical storage/runtime providers.');refs{end+1,1}=r;end
refs{end+1,1}=struct('file',packetFile,'sha256',RoundSHA256_v3(packetFile),'bytes',dirBytes(packetFile));guard(refs);
x=load('-mat',packet.budget_reference.file,'plan');old=x.plan.original_budget;grant=struct('grant_id',old.grant_id,'start_utc',old.start_utc,'research_deadline_utc',old.research_deadline_utc,'deadline_utc',old.deadline_utc);B=AbsoluteRunBudget_v3(grant,old);clear x old
t=clockNow();assert(min(B.research_deadline_unix_seconds-t.utc,(B.research_deadline_monotonic_ns-t.mono)/1e9)>302,'PKFinalEvidence:Grant','The new300/60 saved-data check must fit the unchanged original grant.');finish=struct('utc',t.utc+300,'mono',t.mono+300e9);work=struct('utc',finish.utc-60,'mono',finish.mono-60e9);
file=fullfile(A,'PK30h_20261102_FinalStoredEvidence01.mat');jsonFile=fullfile(A,'PK30h_20261102_FinalStoredEvidence01.json');stage=[file,'.pending.mat'];fresh({file;stage;jsonFile});
out=struct('schema','PK30h-final-stored-evidence-check-v1','completed',false,'source_posthash',false,'input_references',{refs},'current_pid',feature('getpid'),'studies',{{}},'cold_working_reader_rows',{{}},'Root_ODE_map_replay_classifier_calls',0,'fresh_admission_claimed',false,'whole_branch_completion_claimed',false,'failure',struct());
try
 for k=1:2
  check(work);r=packet.study_references(k);x=load('-mat',r.file,'study');s=x.study;clear x
  assert(s.completed&&s.source_posthash&&s.first_flight_local_regularity&&s.native_all_nine&&s.native_PK_qualified&&s.native_phase_consistent,'PKFinalEvidence:Study','Summarize the actual successful saved root/native results without rerunning them.');
  info=s.boundary.info;observation=s.native_inward_clearance;
  row=struct('reference',r,'boundary_coordinates',s.boundary.coordinates,'boundary_seed',s.boundary.initial_coordinates,'boundary_displacement_from_seed',s.boundary.displacement_from_seed,'boundary_physical_residual',info.physical_residual,'local_rank',s.local_rank,'signed_critical_clearance',s.signed_critical_clearance,'first_flight_local_regularity',s.first_flight_local_regularity,'actual_native_ID',OrbitContentIdentity_v3(s.native_orbit),'actual_native_state14',s.native_orbit.initial_state,'actual_native_p',s.native_orbit.parameter,'actual_native_q',s.native_orbit.initial_mode,'actual_native_period',s.native_orbit.period,'actual_native_stride14',s.native_orbit.stride_displacement,'boundary_disposition',s.boundary_disposition,'actual_native_inward',struct('status',observation.status,'completed',observation.completed,'positive_interior_gap',observation.positive_interior_gap,'physical_tolerance_unchanged',observation.physical_tolerance_unchanged,'interior_stationary_point',observation.interior_stationary_point,'interior_guard_values',observation.interior_guard_values,'minimum_interior_guard',observation.minimum_interior_guard,'literal_native_phase_durations',observation.literal_native_phase_durations),'continuous_coverage_claimed',false,'new_physical_edge_added',false);
  out.studies{k,1}=row;clear s info observation
 end
 x=load('-mat',packet.manifest_reference.file,'manifest','manifest_digest');manifest=x.manifest;assert(strcmp(C1ScientificDigest_v3(manifest),x.manifest_digest)&&manifest.completed&&manifest.source_posthash,'PKFinalEvidence:Manifest','Require the complete actual two-component export manifest.');assert(feature('getpid')~=manifest.original_budget.capture.pid,'PKFinalEvidence:FreshProcess','Use a new native process, not the resident exporter.');clear x
 for c=1:2
  check(work);r=packet.core_references(c);assert(strcmp(r.sha256,manifest.core_rows{c}.core_reference.sha256)&&strcmp(r.file,manifest.core_rows{c}.core_reference.file),'PKFinalEvidence:CoreJoin','The cold reads must bind the actual whole-component export outputs.');
  x=load('-mat',r.file,'solution_core29','core_digest');core=x.solution_core29;assert(strcmp(C1ScientificDigest_v3(core),x.core_digest),'PKFinalEvidence:CoreDigest','Preserve the complete plain working core.');clear x
  for index=[1,core.point_count]
   check(work);[o,report,point,view]=LoadC1WorkingSolutionCore29_v3(r.file,index,r.sha256);
   same([o.initial_state;o.stride_displacement;o.period],core.solution_matrix(:,index));same(o.parameter,core.parameters{index});same(o.initial_mode,core.modes{index});
   assert(strcmp(OrbitContentIdentity_v3(o),core.native_ids{index})&&strcmp(point.native_id,core.native_ids{index})&&point.requires_fresh_replay&&~point.fresh_admission_claimed&&~report.core29_view.fresh_all_nine_admission_claimed,'PKFinalEvidence:ColdIdentity','Independent public file reads must preserve literal matrix/p/q/NativeID and historical qualification scope.');
   assert(point.context.expected_index==index&&point.context.source_index==manifest.core_rows{c}.global_indices(index)&&strcmp(view.source_reference.sha256,core.source_reference.sha256),'PKFinalEvidence:ColdContext','The selected local/global source context must remain literal.');
   out.cold_working_reader_rows{end+1,1}=struct('core_reference',r,'component_number',c,'index',index,'point_count',core.point_count,'native_ID',point.native_id,'matrix29',core.solution_matrix(:,index),'parameter',o.parameter,'mode',o.initial_mode,'context',point.context,'working_storage',view.working_storage,'passed',true); %#ok<AGROW>
   clear o report point view
  end
  clear core
 end
 guard(refs);check(work);out.source_posthash=true;out.completed=true;
catch failure
 out.failure=struct('identifier',failure.identifier,'message',failure.message,'report',getReport(failure,'extended','hyperlinks','off'));
end
out.scope='Fresh native-process storage reads of first/last points in both whole working files and literal saved two-FD grazing summaries. No new flow, root, replay, admission, continuous-clearance certificate or branch-completion inference.';
check(finish);evidence_check=out;evidence_digest=C1ScientificDigest_v3(out);save(stage,'evidence_check','evidence_digest','-v7');for pass=1:2,x=load('-mat',stage);assert(strcmp(C1ScientificDigest_v3(x.evidence_check),x.evidence_digest)&&strcmp(x.evidence_digest,evidence_digest),'PKFinalEvidence:Read2','Retain the exact plain summary and literal numeric raw bits.');clear x;end
javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath()),'PKFinalEvidence:Publication','Publish only this owned fresh stage.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());
text=jsonencode(out);fid=fopen(jsonFile,'w');assert(fid>=0,'PKFinalEvidence:JSON','Open the fresh display summary.');fprintf(fid,'%s',text);fclose(fid);assert(strcmp(fileread(jsonFile),text),'PKFinalEvidence:JSONRead','Read back the exact display text.');check(finish);
fprintf('PK30H_FINAL_STORED_EVIDENCE_RETURN %s\n',jsonencode(struct('completed',out.completed,'source_posthash',out.source_posthash,'cold_rows',numel(out.cold_working_reader_rows),'study_rows',numel(out.studies),'audit_reference',struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',dirBytes(file)),'failure',out.failure)));
assert(out.completed,'PKFinalEvidence:Incomplete','Preserve the actual prefix/failure audit.');
end
function guard(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKFinalEvidence:Guard','An exact saved input/provider changed.');end;end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'PKFinalEvidence:Fresh','Preserve existing output.');end;end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKFinalEvidence:Literal','Literal class/shape/raw bits differ.');end
function n=dirBytes(file),d=dir(file);assert(isscalar(d)&&~d.isdir,'PKFinalEvidence:File','Require one actual saved file.');n=d.bytes;end
function t=clockNow(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime()));end
function check(limit),t=clockNow();assert(min(limit.utc-t.utc,(limit.mono-t.mono)/1e9)>0,'PKFinalEvidence:Deadline','The bounded saved-data operation deadline elapsed.');end
