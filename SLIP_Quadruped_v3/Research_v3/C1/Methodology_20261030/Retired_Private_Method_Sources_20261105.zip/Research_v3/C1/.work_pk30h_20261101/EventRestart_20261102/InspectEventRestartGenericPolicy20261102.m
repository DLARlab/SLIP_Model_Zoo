function headers=InspectEventRestartGenericPolicy20261102()
%INSPECTEVENTRESTARTGENERICPOLICY20261102 Native archived-service headers only.
% Reads the exact verified single extracted member. No flow, energy, map,
% root, correction, classifier or new admission is called.
    W=fileparts(mfilename('fullpath'));file=fullfile(W,'ReplaySources','GenericG_StrictService.mat');
    d=dir(file);expected='0e8e12ee0717c0d4ec2bf32e55c8f55073a698cba53fe22151c021e4830505ed';
    assert(isscalar(d)&&d.bytes==2681665&&strcmp(RoundSHA256_v3(file),expected),'EventGenericHeader:Source');
    first=load(file);second=load(file);one=inspect(first);two=inspect(second);
    assert(strcmp(C1ScientificDigest_v3(one),C1ScientificDigest_v3(two)), ...
        'EventGenericHeader:Read2','The two native policy/header projections must agree exactly.');
    assert(strcmp(RoundSHA256_v3(file),expected));
    headers=struct('schema','event-restart-generic-native-policy-headers-v1', ...
        'source_reference',struct('file',file,'sha256',expected,'bytes',2681665), ...
        'native_headers',one,'completed',true,'source_posthash',true, ...
        'new_flow_energy_map_root_classifier_admission_calls',0);
    fprintf('EVENT_RESTART_GENERIC_POLICY_HEADERS %s\n',jsonencode(headers));
end
function out=inspect(value)
    top=fieldnames(value);topRows=cell(numel(top),1);
    for k=1:numel(top)
        v=value.(top{k});topRows{k}=struct('name',top{k},'class',class(v),'size',size(v));
        if isstruct(v)&&isscalar(v),topRows{k}.fieldnames=fieldnames(v);end
    end
    policies=cell(0,1);orbits=cell(0,1);visited=0;walk(value,'',0);
    out=struct('top_variables',{topRows},'policy_candidates',{policies},'orbit_headers',{orbits});
    function walk(v,path,depth)
        visited=visited+1;assert(visited<=4096,'EventGenericHeader:TraversalBound');
        if depth>4,return;end
        if isa(v,'HybridOrbit_v3')&&isscalar(v)
            orbits{end+1,1}=struct('path',path,'native_id',OrbitContentIdentity_v3(v), ...
                'initial_state',v.initial_state,'initial_mode',v.initial_mode, ...
                'parameter',v.parameter,'period',v.period,'stride_displacement',v.stride_displacement, ...
                'section_chart',v.section_chart,'event_signature',v.section_relative_event_signature); %#ok<AGROW>
        elseif isstruct(v)&&isscalar(v)
            if any(isfield(v,{'correction_return_policy','seed','options'}))
                [~,evidence]=RecordedReturnPolicy_v3(v);
                if evidence.complete||~strcmp(evidence.reason,'missing_recorded_return_policy')
                    row=struct('path',path,'recorded_policy',evidence, ...
                        'accepted',member(v,'accepted',[]),'status',member(v,'status',''), ...
                        'acceptance_gates',member(v,'acceptance_gates',struct()));
                    policies{end+1,1}=row; %#ok<AGROW>
                end
            end
            fields=fieldnames(v);
            for j=1:numel(fields)
                name=fields{j};child=name;if ~isempty(path),child=[path,'.',name];end
                if isstruct(v.(name))||iscell(v.(name))||isa(v.(name),'HybridOrbit_v3'),walk(v.(name),child,depth+1);end
            end
        elseif iscell(v)&&numel(v)<=4
            for j=1:numel(v),walk(v{j},sprintf('%s{%d}',path,j),depth+1);end
        end
    end
end
function out=member(v,key,fallback)
    out=fallback;if isstruct(v)&&isscalar(v)&&isfield(v,key),out=v.(key);end
end
