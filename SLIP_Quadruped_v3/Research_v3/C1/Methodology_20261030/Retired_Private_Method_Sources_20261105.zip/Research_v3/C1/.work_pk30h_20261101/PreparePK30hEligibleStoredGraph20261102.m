function result=PreparePK30hEligibleStoredGraph20261102(B,bindings,options)
% Exact closed Graph02 + one closed3-record carrier, then one explicit guard projection.
% Source records/catalogue metadata and historical admission/typed evidence remain literal.
    entryUTC=gpUTC();entryMono=gpNano();N=fullfile(V3Root_v3(),'Research_v3','C1');
    keys={'ParentPlanReference';'ParentClosureReference';'ColdAuditReference';'ColdClosureReference';'CarrierReference';'AcquireAuditReference';'AcquireClosureReference';'GuardAuditReference';'GuardJSONReference'};
    assert(nargin==3&&isstruct(bindings)&&isscalar(bindings)&&isequal(sort(fieldnames(bindings)),sort(keys)) ...
        &&isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort({'OutputFile';'MaxWallSeconds';'SaveMarginSeconds'})) ...
        &&options.MaxWallSeconds==900&&options.SaveMarginSeconds==60&&B.capture.pid==feature('getpid'), ...
        'PKEligible:Inputs','Use only exact closed input references and the explicit new900/60 saved graph operation.');
    assert(strcmp(B.grant_id,'20261101_PK_30h')&&strcmp(B.start_utc,'2026-11-01T16:29:07Z') ...
        &&strcmp(B.research_deadline_utc,'2026-11-02T20:29:07Z')&&strcmp(B.deadline_utc,'2026-11-02T22:29:07Z') ...
        &&min(B.research_deadline_unix_seconds-entryUTC,(B.research_deadline_monotonic_ns-entryMono)/1e9)>902, ...
        'PKEligible:WholeFit','The full new900/60 saved operation must fit the unchanged original science UTC/JVM grant.');
    finish=gpLimit(entryUTC+900,entryMono+900e9);work=gpLimit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    output=gpLiteral(options.OutputFile);stage=[output,'.pending.mat'];failureFile=[output,'.failure.mat'];
    assert(strcmp(output,fullfile(N,'Audits','PK30h_20261102_StoredGraph03_Eligible.mat')) ...
        &&all(cellfun(@(f)~isfile(f)&&~isfolder(f),{output;stage;failureFile})), ...
        'PKEligible:Fresh','Keep every previous/uncertain graph plan and use only the declared fresh Graph03 paths.');
    code=rfProviders();refs=[cellfun(@(key)bindings.(key),keys,'UniformOutput',false);code];gpVerify(refs);
    parentClosed=jsondecode(fileread(bindings.ParentClosureReference.file));
    assert(strcmp(parentClosed.schema,'PK30h-stored-graph-refresh-external-closure-v1')&&rfRefEqual(parentClosed.graph_reference,bindings.ParentPlanReference) ...
        &&parentClosed.process.actual_tool_exit_observed&&parentClosed.process.exit_code==0&&parentClosed.independent_post_guard.all_passed ...
        &&~parentClosed.raw_materialization_completion_claimed&&~parentClosed.scientific_completion_claimed, ...
        'PKEligible:ParentClosed','Only the actual closed graph-only Graph02 is the parent authority.');
    x=load(bindings.ParentPlanReference.file,'component_plan','plan_digest');parent=x.component_plan;rfSame(x.plan_digest,C1ScientificDigest_v3(parent));clear x
    assert(strcmp(parent.schema,'C1-stored-component-graph-plan-v1')&&parent.completed&&parent.source_posthash ...
        &&numel(parent.nodes)==1107&&numel(parent.source_catalog)==29&&parent.source_occurrence_bijection_verified, ...
        'PKEligible:ParentScope','Preserve the exact original closed1107/29 Graph02 and every inherited scientific epoch.');
    for key={'grant_id','start_utc','research_deadline_utc','deadline_utc'},assert(strcmp(B.(key{1}),parent.original_budget.(key{1})),'PKEligible:Grant','A new graph allowance never renews the original grant.');end
    parentView=C1StoredComponentSource_v3.prepare(rfAPIRef(bindings.ParentPlanReference));
    parentRefs=cellfun(@(c)struct('file',c.file,'sha256',c.sha256),parent.source_catalog,'UniformOutput',false);refs=[refs;parentRefs];gpVerify(refs);gpCheck(work);
    coldClosed=jsondecode(fileread(bindings.ColdClosureReference.file));
    assert(strcmp(coldClosed.schema,'PK30h-single-LOW-cold-external-closure-v1') ...
        &&rfRefEqual(coldClosed.cold_audit_reference,bindings.ColdAuditReference)&&rfRefEqual(coldClosed.retained_carrier_reference,bindings.CarrierReference) ...
        &&rfRefEqual(coldClosed.acquisition_reference,bindings.AcquireAuditReference)&&rfRefEqual(coldClosed.acquire_external_closure_reference,bindings.AcquireClosureReference) ...
        &&coldClosed.process.actual_tool_exit_observed&&coldClosed.process.exit_code==0&&coldClosed.independent_post_guard.all_passed&&coldClosed.all_owned_native_workers_closed, ...
        'PKEligible:ColdClosed','Bind actual successful cold process exit, postguards, closed workers and all four literal authority references.');
    x=load(bindings.ColdAuditReference.file,'audit');cold=x.audit;clear x
    assert(strcmp(cold.schema,'PK30h-single-LOW-cold-retained-v1')&&cold.completed&&cold.source_posthash&&cold.mandatory_cold_custody_complete ...
        &&cold.qualifier_calls_attempted==1&&cold.qualifier_calls_returned==1&&isempty(fieldnames(cold.failure)) ...
        &&cold.cold.qualified&&cold.cold.full_native_read2_verified&&cold.cold.complete_policy_read2_verified ...
        &&rfRefEqual(cold.cold.retained_reference,bindings.CarrierReference)&&rfRefEqual(cold.acquire_reference,bindings.AcquireAuditReference) ...
        &&rfRefEqual(cold.external_closure_reference,bindings.AcquireClosureReference) ...
        &&isequal(cold.cold.retained_physical_edge,[1,2])&&isequal(cold.cold.retained_numerical_row,[2,3]), ...
        'PKEligible:ColdAudit','Use the whole actual cold finite proof/read2/policy transport, never a raw Acquire branch duplicate.');
    acquireClosed=jsondecode(fileread(bindings.AcquireClosureReference.file));
    assert(strcmp(acquireClosed.schema,'PK30h-single-LOW-Acquire-external-closure-v1')&&rfRefEqual(acquireClosed.acquisition_reference,bindings.AcquireAuditReference) ...
        &&acquireClosed.process.actual_tool_exit_observed&&acquireClosed.process.exit_code==0&&acquireClosed.independent_post_guard.all_passed&&acquireClosed.all_owned_native_workers_closed, ...
        'PKEligible:AcquireClosed','Keep the closed original finite Acquire authority as provenance without rereading its full numerical workspace.');
    additions={struct('role','closed_current_LOW_to_grown0072Low_carrier','reference',bindings.CarrierReference,'kind','closed-retained-P-M-carrier','cold_case_index',1)};
    assert(~any(cellfun(@(c)strcmp(c.file,bindings.CarrierReference.file),parent.source_catalog)), ...
        'PKEligible:DistinctCarrier','Append exactly one new immutable closed carrier source.');
    component_plan=parent;component_plan.completed=false;component_plan.source_posthash=false;component_plan.failure=struct();
    component_plan.parent_plan_reference=bindings.ParentPlanReference;component_plan.parent_closure_reference=bindings.ParentClosureReference;
    component_plan.parent_operation_history=struct('bindings',parent.bindings,'source_code',{parent.source_code},'input_references',{parent.input_references}, ...
        'original_budget',parent.original_budget,'operation_finish',parent.operation_finish,'operation_work',parent.operation_work, ...
        'completion_scope',parent.completion_scope,'acquisition_scope',parent.acquisition_scope,'refresh',parent.refresh, ...
        'prior_parent_operation_history',parent.parent_operation_history,'source_occurrence_bijection_verified',parent.source_occurrence_bijection_verified);
    component_plan=rmfield(component_plan,'refresh');component_plan.bindings=bindings;component_plan.source_code=code;component_plan.input_references=refs;component_plan.original_budget=B;
    component_plan.operation_finish=finish;component_plan.operation_work=work;
    component_plan.completion_scope='GRAPH03 ONLY: closed carrier append plus exact known guard exclusion from the current eligible view; all raw and historical flags unchanged; no native payload materialization, new admission or scientific completion.';
    result=struct('schema','PK30h-eligible-stored-graph-operation-v1','completed',false,'source_posthash',false,'plan_reference',struct(), ...
        'stage_save_returned',false,'stage_read2_verified',false,'publication_returned',false,'owned_stage_unlink_returned',false,'installed_read2_verified',false, ...
        'parent_occurrences',numel(parent.nodes),'added_occurrences',0,'excluded_occurrences',0,'occurrences',0,'component_count',0,'failure',struct(),'own_process_exit_claimed',false);
    try
        catalogue=parent.source_catalog;nodes=parent.nodes;points=parent.view_index.points;edges=parent.view_index.edges;owners=parent.view_index.metadata.source_owner_map;
        discovery=parent.graph_discovery;newNative=cell(0,1);newReports=cell(0,1);newGlobals=zeros(0,1);addedFacts=cell(numel(additions),1);retainedValidations=0;
        for s=1:numel(additions)
            gpCheck(work);row=additions{s};view=C1StoredComponentSource_v3.prepare(rfAPIRef(row.reference));ix=C1StoredComponentSource_v3.index(view);count=numel(ix.points);offset=numel(nodes);sourceNumber=numel(catalogue)+1;
            assert(strcmp(view.kind,'raw-branch')&&count>0,'PKRefresh:AddedKind','Only actual native closed BranchSolutionFile stores are append sources.');
            catalogue{sourceNumber,1}=struct('file',row.reference.file,'sha256',row.reference.sha256,'bytes',dirBytes(row.reference.file),'metadata',ix.metadata, ...
                'point_metadata',{cellfun(@(p)p.metadata,ix.points,'UniformOutput',false)},'original_edges',{ix.edges},'stored_points',count,'stored_edges',numel(ix.edges),'source_public_readback_verified',false);
            firstDigests=cell(count,1);
            for pass=1:2
                [native,reports,metadata]=C1StoredComponentSource_v3.load(view,(1:count).');
                if pass==2,assert(~(kept==native{1}),'PKRefresh:IndependentHandles','Use independently deserialized added-source records; only one witness handle spans passes.');end
                for j=1:count
                    digest=rfNativeDigest(native{j},reports{j},metadata{j});
                    if pass==1,firstDigests{j}=digest;else,rfSame(firstDigests{j},digest);end
                end
                if pass==1,kept=native{1};clear native reports metadata;end
            end
            graphPart=member(ix.metadata,'component_graph',struct());A=member(graphPart,'qualified_record_aliases',zeros(0,2));E=member(graphPart,'exact_record_equalities',zeros(0,2));M=member(graphPart,'qualified_numerical_overlaps',zeros(0,2));ME=member(graphPart,'numerical_overlap_evidence',cell(0,1));
            validateAliasIndices(A,count);validateAliasIndices(E,count);validateAliasIndices(M,count);
            assert(isempty(A)&&isempty(E),'PKRefresh:AddedTypedScope','These declared current-P branches and finite3-record carriers must not contain an unsupported inherited E/A table; preserve/refuse it rather than dropping relations.');
            if row.cold_case_index==0
                assert(isempty(M)&&isempty(ME),'PKRefresh:CurrentPOnly','Current continuation output contributes its actual P only; no association is inferred from range or screen.');
            else
                z=cold.cold;assert(count==3&&numel(ix.edges)==1&&ix.edges{1}.from==1&&ix.edges{1}.to==2&&isequal(M,[2,3])&&iscell(ME)&&numel(ME)==1, ...
                    'PKRefresh:CarrierGraph','Retain exactly earnedP1-to2 and qualifiedM2-to3 with NONEDGE target.');rfSame(ME{1},z.evidence);
                C1FiniteNumericalOverlap_v3.validateRetained(ME{1},native{2},native{3},reports{2},reports{3},native{1});retainedValidations=retainedValidations+1;
            end
            for j=1:count
                originalPoint=ix.points{j};orbit=native{j};report=reports{j};section=MatchingReturnSection_v3(orbit,orbit,{report,report});state=orbit.initial_state(:);schema=QuadrupedSchema_v3.shared();state(schema.TranslationIndex)=0;
                globalIndex=offset+j;nodes{globalIndex,1}=struct('source_number',sourceNumber,'source_index',j,'point',originalPoint,'native_ID',OrbitContentIdentity_v3(orbit), ...
                    'normalized_state',state,'initial_mode',orbit.initial_mode(:),'parameter',orbit.parameter(:),'period',orbit.period,'stride',orbit.stride_displacement(:),'complete_return_section',section.compatible);
                owner=sprintf('source-%06d::%s',sourceNumber,char(originalPoint.component_identity));ownerRow=struct('source_number',sourceNumber,'source_component_identity',char(originalPoint.component_identity),'output_component_identity',owner);
                if ~any(cellfun(@(r)strcmp(r.output_component_identity,owner),owners)),owners{end+1,1}=ownerRow;end
                originalMetadata=normalizedOriginalMetadata(originalPoint.metadata);
                m=struct('component_identity',owner,'classification',char(originalPoint.classification),'nativeE',originalPoint.nativeE,'signedmeanU',originalPoint.signedmeanU, ...
                    'order',globalIndex,'consolidation_point_schema','C1-consolidated-occurrence-v1','provenance',struct('source_file',row.reference.file,'source_sha256',row.reference.sha256, ...
                    'source_index',j,'source_catalog_file',output,'source_catalog_entry',sourceNumber,'original_point_metadata',originalMetadata,'qualification_flags_changed',false));
                incoming=find(cellfun(@(e)e.to==j,ix.edges));assert(numel(incoming)<=1,'PKRefresh:Incoming','An actual occurrence has at most one physical predecessor.');
                if ~isempty(incoming),m.edge_enabled=true;m.edge_from=offset+ix.edges{incoming}.from;end
                points{globalIndex,1}=struct('index',globalIndex,'component_identity',owner,'order',globalIndex,'classification',m.classification,'nativeE',m.nativeE,'signedmeanU',m.signedmeanU, ...
                    'provenance',m.provenance,'metadata',m,'solution_variable',sprintf('solution_%06d',globalIndex),'report_variable',sprintf('report_%06d',globalIndex),'whole_public_data_readback_verified',false);
                newNative{end+1,1}=native{j};newReports{end+1,1}=reports{j};newGlobals(end+1,1)=globalIndex;
            end
            for j=1:numel(ix.edges)
                e=ix.edges{j};assert(strcmp(ix.points{e.from}.component_identity,ix.points{e.to}.component_identity),'PKRefresh:OwnedP','Every added P retains its actual same-owner original index edge.');
                discovery.physical_edges(end+1,:)=[offset+e.from,offset+e.to];edges{end+1,1}=struct('from',offset+e.from,'to',offset+e.to,'component_identity',points{offset+e.to}.component_identity);
            end
            for j=1:size(M,1)
                discovery.qualified_numerical_overlaps(end+1,:)=M(j,:)+offset;discovery.numerical_overlap_evidence{end+1,1}=ME{j};
                discovery.numerical_overlap_transports{end+1,1}=struct('kind','inherited_qualified_numerical_overlap','input_request',struct('source_file',row.reference.file,'source_sha256',row.reference.sha256,'source_overlap_row',j), ...
                    'left_node',offset+M(j,1),'right_node',offset+M(j,2),'original_evidence_unchanged',true);
            end
            addedFacts{s}=struct('role',row.role,'reference',row.reference,'source_number',sourceNumber,'global_indices',(offset+(1:count)).','point_count',count,'physical_edge_count',numel(ix.edges), ...
                'numerical_overlap_count',size(M,1),'independent_native_acquisitions',2,'one_handle_independence_witness_verified',true,'full_public_report_metadata_digest_read2_verified',true,'saved_admission_epoch_only',true);
            gpVerify({row.reference});gpCheck(work);fprintf('PK30H_GRAPH_REFRESH_SOURCE %d/%d points=%d P=%d M=%d\n',s,numel(additions),count,numel(ix.edges),size(M,1));clear native reports metadata view ix orbit report kept
        end
        newIDs=cellfun(@(g)nodes{g}.native_ID,num2cell(newGlobals),'UniformOutput',false);parentIDs=cellfun(@(r)r.native_ID,parent.nodes,'UniformOutput',false);
        matchedParent=find(ismember(parentIDs,newIDs));
        targetSource=find(cellfun(@(c)strcmp(c.sha256,'95fcae1ace29e0fdf1bcd42bd46a0b3c7d78b1c5b75e78c17ece73607d906a67'),parent.source_catalog));assert(isscalar(targetSource),'PKEligible:ForwardTargetSource','Use only the literal original grown0072Low source generation.');
        target46=find(cellfun(@(n)n.source_number==targetSource&&n.source_index==46,parent.nodes));target47=find(cellfun(@(n)n.source_number==targetSource&&n.source_index==47,parent.nodes));
        raw50=find(cellfun(@(n)n.source_index==50&&strcmp(parent.source_catalog{n.source_number}.sha256,'a2f371cf68f3480dcf3a4b698e9243b5c9b5da988ffe5f19bf974974193e9a0f'),parent.nodes));
        assert(isscalar(target46)&&isscalar(target47)&&isscalar(raw50)&&ismember(target46,matchedParent)&&ismember(raw50,matchedParent),'PKEligible:ForwardSelectors','Actual carrier imports must match the original currentLOW50 and target46 NativeIDs; target47 is one selected saved reference record.');
        selectedParent=unique([matchedParent(:);target47],'stable');groups=C1StoredComponentSource_v3.groups(parentView,selectedParent);parentMatchedFacts=cell(numel(groups),1);newE=0;forwardObservation=struct();
        for k=1:numel(groups)
            gpCheck(work);group=groups{k};[native,reports]=C1StoredComponentSource_v3.load(parentView,group.indices);
            for j=1:numel(group.indices)
                parentIndex=group.indices(j);matches=find(strcmp(newIDs,parent.nodes{parentIndex}.native_ID));
                for q=matches(:).'
                    [eligible,evidence]=fgExactE(native{j},newNative{q},reports{j},newReports{q});
                    if eligible,discovery.exact_record_equalities(end+1,:)=[parentIndex,newGlobals(q)];discovery.equality_evidence{end+1,1}=evidence;newE=newE+1;end
                end
            end
            if group.source_number==targetSource
                at46=find(group.indices==target46);at47=find(group.indices==target47);assert(isscalar(at46)&&isscalar(at47),'PKEligible:ForwardSameGroup','Load target46/47 together once in their actual matched original source group.');
                forwardObservation=fgForwardObservation(newNative{1},newNative{2},native{at46},native{at47},newReports{1},newReports{2},reports{at46},reports{at47},cold.cold.evidence);
            end
            parentMatchedFacts{k}=struct('source_number',group.source_number,'parent_global_indices',group.indices,'NativeID_matched_parent_indices',intersect(group.indices,matchedParent,'stable'),'extra_saved_forward_reference_indices',setdiff(group.indices,matchedParent,'stable'),'acquired_native_records',numel(group.indices),'acquisitions',1,'scope','Matched original full-record/policy/section reads plus target47 in the same matched group; no whole-source admission/M requalification.');clear native reports
        end
        for j=1:numel(newGlobals)
            for k=j+1:numel(newGlobals)
                if ~strcmp(newIDs{j},newIDs{k}),continue;end
                [eligible,evidence]=fgExactE(newNative{j},newNative{k},newReports{j},newReports{k});
                if eligible,discovery.exact_record_equalities(end+1,:)=[newGlobals(j),newGlobals(k)];discovery.equality_evidence{end+1,1}=evidence;newE=newE+1;end
            end
        end
        routePairs=[raw50,newGlobals(1);newGlobals(1),newGlobals(2);newGlobals(2),newGlobals(3);newGlobals(3),target46;target46,target47];routeKinds={'E';'P';'M';'E';'P'};route=cell(5,1);
        for k=1:5
            key='physical_edges';if strcmp(routeKinds{k},'E'),key='exact_record_equalities';elseif strcmp(routeKinds{k},'M'),key='qualified_numerical_overlaps';end
            pairs=discovery.(key);if strcmp(routeKinds{k},'P'),rows=find(all(pairs==routePairs(k,:),2));else,rows=find(all(pairs==routePairs(k,:),2)|all(pairs==fliplr(routePairs(k,:)),2));end
            assert(isscalar(rows),'PKEligible:ForwardTypedRoute','The finite handoff needs each actual typed P/E/M route relation, with no component-only inference.');
            route{k}=struct('kind',routeKinds{k},'relation_row',rows,'pre_projection_from',routePairs(k,1),'pre_projection_to',routePairs(k,2),'from_native_ID',nodes{routePairs(k,1)}.native_ID,'to_native_ID',nodes{routePairs(k,2)}.native_ID,'physical_edge_claimed',strcmp(routeKinds{k},'P'));
        end
        assert(~isempty(fieldnames(forwardObservation)),'PKEligible:ForwardObserved','The selected saved target46-to47 oriented neighborhood must be observed before source release.');forwardObservation.pre_projection_typed_route=route;forwardObservation.carrier_reference=bindings.CarrierReference;forwardObservation.overlap_cold_audit_reference=bindings.ColdAuditReference;
        clear newNative newReports
        rfSame(parent.nodes,nodes(1:numel(parent.nodes)));rfSame(parent.source_catalog,catalogue(1:numel(parent.source_catalog)));
        rfSame(parent.view_index.points,points(1:numel(parent.nodes)));rfSame(parent.view_index.edges,edges(1:numel(parent.view_index.edges)));
        for field={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'},key=field{1};rfSame(parent.graph_discovery.(key),discovery.(key)(1:size(parent.graph_discovery.(key),1),:));end
        for field={'equality_evidence','qualified_alias_evidence','numerical_overlap_evidence','numerical_overlap_transports'},key=field{1};old=parent.graph_discovery.(key);current=discovery.(key);rfSame(old,reshape(current(1:numel(old)),size(old)));end
        [nodes,points,edges,discovery,projection,preToActive]=fgGuardProjection(parent,nodes,points,edges,discovery,catalogue,bindings);
        for k=1:numel(addedFacts),addedFacts{k}.pre_projection_global_indices=addedFacts{k}.global_indices;addedFacts{k}.global_indices=preToActive(addedFacts{k}.global_indices);end
        for k=1:numel(forwardObservation.pre_projection_typed_route),r=forwardObservation.pre_projection_typed_route{k};r.active_from=preToActive(r.pre_projection_from);r.active_to=preToActive(r.pre_projection_to);assert(r.active_from>0&&r.active_to>0,'PKEligible:ForwardActiveRoute','Every finite LOW route selector remains eligible.');key='physical_edges';if strcmp(r.kind,'E'),key='exact_record_equalities';elseif strcmp(r.kind,'M'),key='qualified_numerical_overlaps';end;pairs=discovery.(key);pair=[r.active_from,r.active_to];if strcmp(r.kind,'P'),row=find(all(pairs==pair,2));else,row=find(all(pairs==pair,2)|all(pairs==fliplr(pair),2));end;assert(isscalar(row),'PKEligible:ForwardActiveRelation','Each active typed route edge needs its actual current relation-row selector.');r.pre_projection_relation_row=r.relation_row;r=rmfield(r,'relation_row');r.active_relation_row=row;forwardObservation.active_typed_route{k,1}=r;end
        count=numel(nodes);discovery.effective_edges=[discovery.physical_edges;discovery.exact_record_equalities;discovery.qualified_record_aliases;discovery.qualified_numerical_overlaps];
        bins=conncomp(graph(discovery.effective_edges(:,1),discovery.effective_edges(:,2),[],count));componentCount=max(bins);
        newID=['C1-eligible:',C1ScientificDigest_v3(struct('parent',bindings.ParentPlanReference,'carrier',bindings.CarrierReference,'guard',bindings.GuardAuditReference,'graph',discovery))];
        globalGraph=rfGraph(parent.view_index.metadata.component_graph,discovery,(1:count).',count,componentCount==1);globalMetadata=parent.view_index.metadata;
        globalMetadata.consolidation_id=newID;globalMetadata.component_number=0;globalMetadata.original_connected_component_numbers=1:componentCount;
        globalMetadata.families=unique(cellfun(@(r)family(r.point.classification),nodes,'UniformOutput',false));globalMetadata.source_catalog_file=output;
        globalMetadata.source_catalog_entries=unique(cellfun(@(r)r.source_number,nodes));globalMetadata.component_graph=globalGraph;globalMetadata.source_owner_map=owners;globalMetadata.scientific_flags_upgraded=false;
        components=cell(componentCount,1);occurrenceMap=cell(count,1);parentMap=zeros(numel(parent.nodes),6);coverage=false(count,1);
        for g=1:numel(parent.nodes),old=parent.occurrence_map{g};parentMap(g,1:4)=[g,old.component_number,old.component_index,preToActive(g)];end
        for c=1:componentCount
            selected=find(bins==c).';toLocal=zeros(count,1);toLocal(selected)=1:numel(selected);localPoints=cell(numel(selected),1);localGraph=rfGraph(globalGraph,discovery,selected,count,true);localMetadata=globalMetadata;
            localMetadata.component_number=c;localMetadata.original_connected_component_numbers=c;localMetadata.component_graph=localGraph;
            localMetadata.families=unique(cellfun(@(r)family(r.point.classification),nodes(selected),'UniformOutput',false));localMetadata.source_catalog_entries=unique(cellfun(@(r)r.source_number,nodes(selected)));
            selectedOwners=cellfun(@(r)r.component_identity,points(selected),'UniformOutput',false);localMetadata.source_owner_map=owners(cellfun(@(r)any(strcmp(selectedOwners,r.output_component_identity)),owners));
            for j=1:numel(selected)
                g=selected(j);point=points{g};point.index=j;point.order=j;point.metadata.order=j;point.solution_variable=sprintf('solution_%06d',j);point.report_variable=sprintf('report_%06d',j);
                if isfield(point.metadata,'edge_from'),assert(toLocal(point.metadata.edge_from)>0,'PKEligible:PhysicalParent','Every active physical parent stays in its actual component.');point.metadata.edge_from=toLocal(point.metadata.edge_from);end
                localPoints{j}=point;node=nodes{g};source=catalogue{node.source_number};occurrenceMap{g}=struct('source_file',source.file,'source_sha256',source.sha256,'source_index',node.source_index,'global_index',g,'component_number',c,'component_index',j);
                old=find(parentMap(:,4)==g);if ~isempty(old),assert(isscalar(old),'PKEligible:ParentMap','An active occurrence has at most one parent selector.');parentMap(old,5:6)=[c,j];end
            end
            localEdges=cell(size(localGraph.original_explicit_edges,1),1);for j=1:numel(localEdges),pair=localGraph.original_explicit_edges(j,:);localEdges{j}=struct('from',pair(1),'to',pair(2),'component_identity',localPoints{pair(2)}.component_identity);end
            ix=struct('storage_version',parent.view_index.storage_version,'metadata',localMetadata,'points',{localPoints},'edges',{localEdges});assertConnected(localGraph,numel(selected));
            assert(~any(coverage(selected)),'PKEligible:Bijection','Each eligible occurrence gets exactly one current component/local selector.');coverage(selected)=true;
            components{c}=struct('component_number',c,'global_indices',selected(:),'planned_materialization_index',ix,'planned_index_digest',C1ScientificDigest_v3(ix),'materialization_completed_by_this_operation',false);
            fprintf('PK30H_ELIGIBLE_GRAPH_COMPONENT %d/%d N=%d P=%d E=%d A=%d M=%d\n',c,componentCount,numel(selected),size(localGraph.original_explicit_edges,1),size(localGraph.exact_record_equalities,1),size(localGraph.qualified_record_aliases,1),size(localGraph.qualified_numerical_overlaps,1));
        end
        assert(all(coverage),'PKEligible:Coverage','Keep every occurrence except the one explicitly witnessed failed tuple.');
        for s=1:numel(catalogue)
            actual=cellfun(@(r)r.source_index,nodes(cellfun(@(r)r.source_number==s,nodes)));expected=(1:catalogue{s}.stored_points).';
            if s==projection.excluded_source_number,expected(expected==projection.excluded_source_index)=[];end
            assert(isequal(sort(actual(:)),expected),'PKEligible:SourceCoverage','Each source contributes every original index exactly once, apart from the single explicit guard exclusion.');
        end
        rfSame(parent.source_catalog,catalogue(1:numel(parent.source_catalog)));
        projection.parent_to_active_map=parentMap;projection.parent_map_columns={'parent_global';'parent_component';'parent_local';'active_global_or_zero';'active_component_or_zero';'active_local_or_zero'};
        projection.active_component_count=componentCount;projection.active_component_counts=cellfun(@(c)numel(c.global_indices),components);projection.active_relation_counts=[size(discovery.physical_edges,1),size(discovery.exact_record_equalities,1),size(discovery.qualified_record_aliases,1),size(discovery.qualified_numerical_overlaps,1)];
        component_plan.consolidation_id=newID;component_plan.source_catalog=catalogue;component_plan.nodes=nodes;component_plan.graph_discovery=discovery;component_plan.components=components;component_plan.occurrence_map=occurrenceMap;
        component_plan.view_index=struct('storage_version',parent.view_index.storage_version,'metadata',globalMetadata,'points',{points},'edges',{edges});
        component_plan.source_occurrence_bijection_verified=false;component_plan.active_source_occurrence_bijection_verified=true;component_plan.current_guard_projection=projection;component_plan.finite_forward_LOW_handoff=forwardObservation;
        component_plan.final_incremental=struct('parent_occurrences',numel(parent.nodes),'added_occurrences',numel(newGlobals),'added_sources',{addedFacts}, ...
            'cold_audit_reference',bindings.ColdAuditReference,'cold_external_closure_reference',bindings.ColdClosureReference,'cold_external_closure_payload',coldClosed, ...
            'parent_matched_source_acquisitions',{parentMatchedFacts},'new_exact_E_links',newE,'new_retained_M_validations',retainedValidations, ...
            'parent_original_nodes_and_source_metadata_literal',true,'parent_old_admission_M_epochs_preserved',true,'new_sources_independent_acquisitions',2, ...
            'parent_native_cache_retained',false,'new_admission_qualification_performed',false,'guard_projection_applied',true);
        component_plan.acquisition_scope=struct('parent_source_groups',numel(parent.source_catalog),'added_whole_source_groups',1,'added_independent_passes',2,'parent_matched_source_groups',numel(groups),'maximum_added_source_records',3,'one_independence_handle_per_added_source',true,'whole_parent_requalification_claimed',false,'universal16_record_bound_claimed',false);
        component_plan.new_root_integrations_classifications_replays=0;component_plan.new_overlap_qualification_calls=0;component_plan.native_payload_copied=false;component_plan.scientific_completion_claimed=false;component_plan.source_retirement_authorized=false;component_plan.own_process_exit_claimed=false;
        component_plan.global_index_scope='Current eligible view global indices/order and physical predecessor references are explicitly remapped; immutable node.point and source catalogue metadata remain exact original values. All parent selectors, the excluded full node/header/incident relations and literal guard witness remain in current_guard_projection and immutable parent authority.';
        component_plan.input_references=refs;gpVerify(refs);gpCheck(work);component_plan.source_posthash=true;component_plan.completed=true;component_plan.completed_utc=stamp();component_plan.wall_seconds=(gpNano()-entryMono)/1e9;
        plan_digest=C1ScientificDigest_v3(component_plan);save(stage,'component_plan','plan_digest','-v7');result.stage_save_returned=true;gpRead2(stage,component_plan);result.stage_read2_verified=true;gpVerify(refs);gpCheck(finish);
        stageHash=RoundSHA256_v3(stage);assert(~isfile(output),'PKEligible:PublishFresh','Retain a concurrent final result.');javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());result.publication_returned=true;
        assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath())&&strcmp(RoundSHA256_v3(stage),stageHash)&&strcmp(RoundSHA256_v3(output),stageHash),'PKEligible:OwnStage','Unlink only the unchanged hardlinked own graph stage.');
        javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());result.owned_stage_unlink_returned=true;gpRead2(output,component_plan);result.installed_read2_verified=true;gpVerify(refs);gpCheck(finish);
        result.plan_reference=gpRef(output);result.completed=true;result.source_posthash=true;result.added_occurrences=numel(newGlobals);result.excluded_occurrences=1;result.occurrences=count;result.component_count=componentCount;
    catch problem
        result.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);component_plan.completed=false;component_plan.failure=result.failure;
        if ~isfile(failureFile),plan_digest=C1ScientificDigest_v3(component_plan);operation_result=result;save(failureFile,'component_plan','plan_digest','operation_result','-v7');end
    end
    result.elapsed_seconds=(gpNano()-entryMono)/1e9;result.scope='Saved current eligible GRAPH ONLY. Historical accepted/P/M/class flags remain unchanged. No native trajectory export, source/frontier retirement, fresh all-nine admission, scientific completion or own process-exit claim.';
    try,fprintf('PK30H_ELIGIBLE_GRAPH_RETURN %s\n',jsonencode(result));catch,end
end
function out=fgForwardObservation(a,b,t,u,ra,rb,rt,ru,overlapEvidence)
    os={a;b;t;u};rs={ra;rb;rt;ru};contexts=cell(4,1);matches=cell(3,1);
    names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    for k=1:4
        r=rs{k};g=r.classification;assert(isequal(r.accepted,true)&&all(isfield(r.acceptance_gates,names))&&all(cellfun(@(n)isequal(r.acceptance_gates.(n),true),names)) ...
            &&isequal(g.canonical_label_qualified,true)&&isequal(g.flight_count_certain,true)&&isequal(g.flight_count,1)&&strcmp(g.validated_gait_type,'PK'), ...
            'PKEligible:ForwardSavedAdmission','Use each selected record literal saved all-nine/qualified one-flight PK context; no fresh admission is implied.');
        [~,policy]=RecordedReturnPolicy_v3(r);assert(policy.complete,'PKEligible:ForwardPolicy','All selected forward-neighborhood reports need complete actual policy configurations.');
        contexts{k}=struct('native_ID',OrbitContentIdentity_v3(os{k}),'accepted',r.accepted,'all_nine_decisions',r.acceptance_gates,'classification',struct('contract_version',g.contract_version,'canonical_point_label',g.canonical_point_label,'canonical_label_qualified',g.canonical_label_qualified,'validated_gait_type',g.validated_gait_type,'flight_count',g.flight_count,'flight_count_certain',g.flight_count_certain),'policy_configuration',policy.configuration,'saved_historical_context_only',true);
        if k>1
            matches{k-1}=MatchingReturnSection_v3(a,os{k},{ra,r});assert(matches{k-1}.compatible ...
                &&strcmp(C1ScientificDigest_v3(a.parameter),C1ScientificDigest_v3(os{k}.parameter))&&strcmp(C1ScientificDigest_v3(a.initial_mode),C1ScientificDigest_v3(os{k}.initial_mode)) ...
                &&strcmp(C1ScientificDigest_v3(contexts{1}.policy_configuration),C1ScientificDigest_v3(policy.configuration)) ...
                &&strcmp(g.contract_version,contexts{1}.classification.contract_version)&&fgCohortEqual(a,os{k}), ...
                'PKEligible:ForwardContext','Full p/q, complete policy, marked section and symbolic event-cluster/coincidence cohort must agree literally across the selected finite neighborhood.');
        end
    end
    coordinates=cellfun(@(o)o.initial_state(2:14),os,'UniformOutput',false);scale=max([ones(13,1),abs(coordinates{1}),abs(coordinates{2}),abs(coordinates{3}),abs(coordinates{4})],[],2);
    source=(coordinates{2}-coordinates{1})./scale;target=(coordinates{4}-coordinates{3})./scale;steps=[norm(source),norm(target)];
    assert(all(isfinite(scale))&&all(scale>0)&&all(isfinite(steps))&&all(steps>1e-10),'PKEligible:ForwardSecants','Both full13 source/target saved chords must be finite and resolved under one explicit common scale.');
    cosine=(source.'*target)/(steps(1)*steps(2));assert(isfinite(cosine)&&abs(cosine)<=1+1e-12,'PKEligible:ForwardCosine','The finite common-scale secant cosine must be a valid observed scalar.');
    out=struct('schema','PK30h-finite-forward-LOW-saved-neighborhood-observation-v1','completed',true,'full13_state_indices',(2:14).','common_scale13',scale, ...
        'source_scaled_secant13',source,'target_scaled_secant13',target,'source_step_norm',steps(1),'target_step_norm',steps(2),'secant_cosine',cosine, ...
        'positive_finite_secant_orientation_observed',cosine>0,'source_raw_state13',{coordinates(1:2)},'target_raw_state13',{coordinates(3:4)}, ...
        'selected_saved_contexts',{contexts},'matching_return_sections',{matches},'symbolic_cohort_literal_equal',true,'exact_pq_and_complete_policy_equal',true, ...
        'actual_cold_overlap_evidence',overlapEvidence,'target_original_source_indices',[46,47],'new_carrier_source_indices',[1,2,3], ...
        'new_root_ODE_map_fine_admission_calls',0,'absolute_event_time_equality_required',false,'classical_tangent_or_uniqueness_proved',false,'global_coverage_proved',false, ...
        'scope','Finite oriented full13 saved-neighborhood observation through actual P/E/M/E/P route only. Positive cosine supports finite forward alignment under this common scale; no classical tangent, local uniqueness, exact M identity, fresh target47 fine proof, endpoint or global-coverage claim.');
end
function yes=fgCohortEqual(a,b)
    names={'return_multiplicity','event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names','section_cluster_coincidence','section_coincident_cluster_indices'};
    required={'event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names'};yes=true;
    for k=1:numel(required),left=a.(required{k});right=b.(required{k});yes=yes&&~isempty(left)&&~isempty(right);if ischar(left)||isstring(left),yes=yes&&all(strlength(string(left))>0,'all');end;if ischar(right)||isstring(right),yes=yes&&all(strlength(string(right))>0,'all');end;end
    for k=1:numel(names),yes=yes&&strcmp(C1ScientificDigest_v3(a.(names{k})),C1ScientificDigest_v3(b.(names{k})));end
end
function [yes,e]=fgExactE(a,b,ra,rb)
    [yes,e]=rfExactE(a,b,ra,rb);if ~yes,return;end
    names={'return_multiplicity','event_cluster_signature','cyclic_event_cluster_signature','event_cluster_members','event_cluster_names','section_cluster_coincidence','section_coincident_cluster_indices'};
    if ~fgCohortEqual(a,b),yes=false;e=struct();return;end
    e.symbolic_cluster_and_coincidence_cohort_literal_equal=true;e.symbolic_cohort_fields=names(:);e.absolute_event_time_equality_required=false;
end
function [nodes,points,edges,d,p,map]=fgGuardProjection(parent,nodes,points,edges,d,catalogue,b)
    x=load(b.GuardAuditReference.file,'audit','audit_digest');a=x.audit;rfSame(x.audit_digest,C1ScientificDigest_v3(a));clear x
    expectedFile=fullfile(V3Root_v3(),'Research_v3','C1','Components','C1_PK_Component_0072.mat');expectedSHA='f2f62cc9de65cb39cece67a1de60ca058db0be8863b87e229c1440a12e939ec7';expectedID='native-orbit-record:sha256:e05b77d6ae892069a3e20ffe83a475ccce7ac96dc7f5027695ada928e86101f6';
    assert(strcmp(a.schema,'PK30h-old0072-literal-firstflight-guard-witness-v1')&&a.completed&&a.source_posthash&&a.all_recorded_states_assessed ...
        &&isequal(a.source_selected_indices,[5;6;13;130])&&isequal(a.current_guard_failure_mask,[false;true;false;false]) ...
        &&a.physical_swing_tolerance==1e-8&&~a.historical_accepted_classification_P_M_flags_changed, ...
        'PKEligible:GuardAudit','Use only the exact completed literal source6 negative native guard audit; no range/height filter or historical flag rewrite.');
    row=a.rows{2};assert(row.assessed&&row.current_guard_failure&&row.source_two_pass_verified&&row.source_key.index==6 ...
        &&strcmp(row.source_key.reference.file,expectedFile)&&strcmp(row.source_key.reference.sha256,expectedSHA)&&strcmp(row.source_key.native_id,expectedID) ...
        &&~isempty(row.violation_witnesses),'PKEligible:GuardWitness','Retain the whole exact witnessed raw-state guard counterexample.');
    witnessFound=false;for k=1:numel(row.violation_witnesses),w=row.violation_witnesses{k};witnessFound=witnessFound||(w.violation_observed&&w.consistent_with_native&&w.local_time>0&&w.local_time<row.first_flight.duration&&any(w.native_guard< -a.physical_swing_tolerance));end
    assert(witnessFound,'PKEligible:ConcreteGuard','A strictly interior, native-consistent guard below the actual tolerance is required.');
    source=find(cellfun(@(c)strcmp(c.file,expectedFile)&&strcmp(c.sha256,expectedSHA),catalogue));assert(isscalar(source),'PKEligible:GuardSource','The failed original source generation must occur uniquely.');
    bad=find(cellfun(@(n)n.source_number==source&&n.source_index==6&&strcmp(n.native_ID,expectedID),nodes));
    assert(isscalar(bad)&&bad<=numel(parent.nodes)&&sum(cellfun(@(n)strcmp(n.native_ID,expectedID),nodes))==1, ...
        'PKEligible:GuardUnique','Unexpected aliases or multiple failed NativeID occurrences require a hold, never a guessed exclusion.');
    previous=find(cellfun(@(n)n.source_number==source&&n.source_index==5,nodes));assert(isscalar(previous),'PKEligible:GuardPredecessor','Original source5 must remain the unique physical predecessor selector.');
    rfSame(nodes{bad}.point,row.literal_source.source_point_header);
    names={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};ev={'','equality_evidence','qualified_alias_evidence','numerical_overlap_evidence'};incident=struct();masks=cell(4,1);
    for k=1:4,key=names{k};pairs=d.(key);masks{k}=any(pairs==bad,2);incident.(key)=pairs(masks{k},:);if k>1,incident.(ev{k})=d.(ev{k})(masks{k});end,end
    incident.numerical_overlap_transports=d.numerical_overlap_transports(masks{4});
    assert(isequal(incident.physical_edges,[previous,bad])&&isempty(incident.exact_record_equalities)&&isempty(incident.qualified_record_aliases)&&isempty(incident.qualified_numerical_overlaps) ...
        &&~any(d.physical_edges(:,1)==bad),'PKEligible:GuardLeafHold','Expected one leaf source5-to6 P only; outgoing/E/A/M or other incident topology requires explicit review.');
    originalCount=numel(nodes);keep=setdiff((1:originalCount).',bad,'stable');map=zeros(originalCount,1);map(keep)=1:numel(keep);
    p=struct('schema','PK30h-exact-current-guard-eligible-projection-v1','applied',true,'reason','Exact literal old0072 source6 has an observed native-consistent guard below-1e-8 strictly before its own firstTD; only this source/SHA/index/NativeID is excluded from the current eligible view.', ...
        'parent_plan_reference',b.ParentPlanReference,'parent_external_closure_reference',b.ParentClosureReference,'guard_audit_reference',b.GuardAuditReference,'guard_json_reference',b.GuardJSONReference, ...
        'original_parent_occurrences',numel(parent.nodes),'closed_carrier_added_occurrences',originalCount-numel(parent.nodes),'pre_projection_occurrences',originalCount,'active_occurrences',numel(keep),'excluded_occurrences',1, ...
        'excluded_source_number',source,'excluded_source_index',6,'excluded_pre_projection_global_index',bad,'excluded_native_ID',expectedID, ...
        'excluded_node',nodes{bad},'excluded_virtual_point',points{bad},'excluded_parent_selector',parent.occurrence_map{bad},'excluded_incident_relations',incident, ...
        'excluded_virtual_physical_edges',{edges(cellfun(@(e)e.from==bad||e.to==bad,edges))},'guard_witness_row',row, ...
        'pre_projection_to_active_global_map',[(1:originalCount).',map],'parent_original_graph_digest',C1ScientificDigest_v3(parent.graph_discovery), ...
        'parent_original_nodes_digest',C1ScientificDigest_v3(parent.nodes),'all_original_source_occurrences_active',false,'all_remaining_source_occurrences_preserved',true, ...
        'inherited_evidence_internal_selectors_scope','Literal historical evidence rows retain their original graph/source selectors; use parent_to_active_map for current lookup. Current transport descriptors and typed relation tables carry explicit active endpoints.','raw_source_files_changed',false,'historical_accepted_P_M_classification_flags_changed',false,'old_M_requalification_performed',false,'new_admission_claimed',false);
    nodes=nodes(keep);points=points(keep);
    for k=1:numel(points)
        point=points{k};point.index=k;point.order=k;point.metadata.order=k;point.solution_variable=sprintf('solution_%06d',k);point.report_variable=sprintf('report_%06d',k);
        if isfield(point.metadata,'edge_from'),assert(map(point.metadata.edge_from)>0,'PKEligible:ExcludedPredecessor','Any unexpected active child of the excluded node requires a hold.');point.metadata.edge_from=map(point.metadata.edge_from);end
        points{k}=point;
    end
    edges=edges(~cellfun(@(e)e.from==bad||e.to==bad,edges));for k=1:numel(edges),edges{k}.from=map(edges{k}.from);edges{k}.to=map(edges{k}.to);end
    for k=1:4,key=names{k};pairs=d.(key);d.(key)=reshape(map(pairs(~masks{k},:)),[],2);if k>1,d.(ev{k})=d.(ev{k})(~masks{k});end,end
    d.numerical_overlap_transports=d.numerical_overlap_transports(~masks{4});
    for k=1:numel(d.numerical_overlap_transports)
        t=d.numerical_overlap_transports{k};if isfield(t,'left_node'),t.left_node=map(t.left_node);end;if isfield(t,'right_node'),t.right_node=map(t.right_node);end;d.numerical_overlap_transports{k}=t;
    end
    for k=1:numel(keep),if keep(k)<=numel(parent.nodes),rfSame(nodes{k},parent.nodes{keep(k)});end,end
end
function [yes,e]=rfExactE(a,b,ra,rb)
    e=struct();yes=false;if ~strcmp(OrbitContentIdentity_v3(a),OrbitContentIdentity_v3(b))||~isequaln(rfRecord(a),rfRecord(b)),return;end
    [~,pa]=RecordedReturnPolicy_v3(ra);[~,pb]=RecordedReturnPolicy_v3(rb);if ~pa.complete||~pb.complete||~isequaln(pa.configuration,pb.configuration),return;end
    match=MatchingReturnSection_v3(a,b,{ra,rb});if ~match.compatible,return;end
    yes=true;e=struct('native_ID',OrbitContentIdentity_v3(a),'exact_state_mode_parameter_period_stride',true,'translation_gauge_normalized',false,'raw14_state_exact',true, ...
        'complete_policy_equal',true,'matching_return_section',match,'new_continuation_edge_created',false,'new_admission_claimed',false,'source_admission_epochs_unchanged',true);
end
function r=rfRecord(o)
    r=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement, ...
        'return_policy_name',o.return_policy_name,'section_chart',o.section_chart,'section_relative_event_signature',o.section_relative_event_signature,'cyclic_event_signature',o.cyclic_event_signature);
end
function digest=rfNativeDigest(o,r,m),digest=C1ScientificDigest_v3(struct('orbit',rfPublic(o),'report',rfPublic(r),'metadata',m));end
function yes=rfRefEqual(a,b)
    yes=isstruct(a)&&isscalar(a)&&isstruct(b)&&isscalar(b)&&all(isfield(a,{'file','sha256'}))&&all(isfield(b,{'file','sha256'}))&&strcmp(a.file,b.file)&&strcmp(a.sha256,b.sha256);
    if yes&&isfield(a,'bytes')&&isfield(b,'bytes'),yes=isequal(double(a.bytes),double(b.bytes));end
end
function r=rfAPIRef(r),r=struct('file',r.file,'sha256',r.sha256);end
function rfSame(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKRefresh:Typed','Complete typed plain values differ.');end
function bytes=dirBytes(file),d=dir(file);assert(isscalar(d)&&~d.isdir,'PKRefresh:File','An exact source must remain one regular native file.');bytes=d.bytes;end
function g=rfGraph(template,d,selected,n,connected)
    map=zeros(n,1);map(selected)=1:numel(selected);g=template;g.nodes=numel(selected);
    fields={'original_explicit_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};actual={'physical_edges','exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};masks=cell(4,1);
    for k=1:4,p=d.(actual{k});mask=ismember(p(:,1),selected)&ismember(p(:,2),selected);masks{k}=mask;g.(fields{k})=reshape(map(p(mask,:)),[],2);end
    g.qualified_alias_evidence=d.qualified_alias_evidence(masks{3});g.numerical_overlap_evidence=d.numerical_overlap_evidence(masks{4});g.equality_evidence=d.equality_evidence(masks{2});
    g.effective_edges=[g.original_explicit_edges;g.exact_record_equalities;g.qualified_record_aliases;g.qualified_numerical_overlaps];g.connected=connected;g.isolated_record_catalogue=false;
end
function refs=rfProviders()
    names={'PreparePK30hEligibleStoredGraph20261102','C1StoredComponentSource_v3','BranchSolutionFile_v3','C1FiniteNumericalOverlap_v3', ...
        'RecordedReturnPolicy_v3','MatchingReturnSection_v3','ReturnPolicyBase_v3','BLMarkedApexReturnPolicy_v3','EventCycleReturnPolicy_v3','IteratedReturnPolicy_v3','FirstReturnPolicy_v3','OrbitContentIdentity_v3','QuadrupedSchema_v3','HybridOrbit_v3','Trajectory_v3','C1ScientificDigest_v3','RoundSHA256_v3','V3Root_v3','V3Path_v3'};
    refs=cellfun(@(name)gpRef(which(name)),names(:),'UniformOutput',false);refs{end+1,1}=gpRef(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end

function [original,kind]=normalizedOriginalMetadata(metadata)
% One-level flatten only for a direct known envelope. A Run import retains
% its ENTIRE immediate metadata; no provenance crawl or scientific edit.
assert(isstruct(metadata)&&isscalar(metadata),'C1Consolidate:PointMetadata', ...
    'Every immediate point metadata record must be one scalar struct.');
original=metadata;kind=1;
if ~isfield(metadata,'consolidation_point_schema'),return;end
assert(isequal(metadata.consolidation_point_schema,'C1-consolidated-occurrence-v1') ...
    &&isfield(metadata,'provenance')&&isstruct(metadata.provenance)&&isscalar(metadata.provenance), ...
    'C1Consolidate:MarkedMetadata','A marked point needs the exact known schema and scalar provenance.');
p=metadata.provenance;
pathText=@(x)ischar(x)&&isrow(x)&&~isempty(x);
positiveIndex=@(x)isnumeric(x)&&isreal(x)&&isscalar(x)&&isfinite(x)&&x>=1&&x==fix(x);
direct={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
imported={'kind','source_file','source_index','original_provenance'};
if isequal(sort(fieldnames(p)),sort(direct(:)))
    assert(pathText(p.source_file)&&pathText(p.source_catalog_file)&&positiveIndex(p.source_index)&&positiveIndex(p.source_catalog_entry) ...
        &&ischar(p.source_sha256)&&isrow(p.source_sha256)&&~isempty(regexp(p.source_sha256,'^[0-9a-f]{64}$','once')) ...
        &&isstruct(p.original_point_metadata)&&isscalar(p.original_point_metadata)&&isequal(p.qualification_flags_changed,false), ...
        'C1Consolidate:DirectMetadata','The direct consolidation envelope is malformed; retain it and refuse.');
    original=p.original_point_metadata;kind=2;
elseif isequal(sort(fieldnames(p)),sort(imported(:)))
    assert(isequal(p.kind,'imported nonedge initial pair')&&pathText(p.source_file)&&positiveIndex(p.source_index) ...
        &&isstruct(p.original_provenance)&&isscalar(p.original_provenance)&&isfield(metadata,'edge_enabled') ...
        &&isequal(metadata.edge_enabled,false)&&~isfield(metadata,'edge_from'), ...
        'C1Consolidate:ImportedMetadata','Only the exact Run imported-NONEDGE wrapper may preserve its entire immediate metadata.');
    kind=3;
else
    error('C1Consolidate:MarkedMetadata','Unknown marked provenance shape; no generic fallback or recursive flatten is permitted.');
end
end

function validateAliasPoint(value,n)
assert(isnumeric(value)&&isreal(value)&&isscalar(value)&&isfinite(value) ...
    &&value==fix(value)&&value>=1&&value<=n,'C1Consolidate:Aliases', ...
    'Each alias selector needs one bounded positive integer occurrence index.');
end
function validateAliasIndices(pairs,n)
assert(isnumeric(pairs)&&isreal(pairs)&&ismatrix(pairs)&&size(pairs,2)==2 ...
    &&all(isfinite(pairs(:)))&&all(pairs(:)==fix(pairs(:)))&&all(pairs(:)>=1)&&all(pairs(:)<=n), ...
    'C1Consolidate:Aliases','Alias links require bounded positive integer occurrence indices.');
end
function assertConnected(metadata,n)
edges=metadata.effective_edges;bins=conncomp(graph(edges(:,1),edges(:,2),[],n));
assert(n>0 && max(bins)==1,'C1Consolidate:Disconnected','Output must contain one effective connected component.');
end
function out=member(value,key,fallback)
out=fallback;if isstruct(value)&&isscalar(value)&&isfield(value,key),out=value.(key);end
end
function out=family(label)
match=regexp(char(label),'^(PK|BG|BE|FG|FE|HG|HE|GG|GE)[0-9]*$','tokens','once');
out='OTHER';if ~isempty(match),out=match{1};end
end
function path=canonical(value)
assert((ischar(value)&&isrow(value)&&~isempty(value))||(isstring(value)&&isscalar(value)&&strlength(value)>0), ...
    'C1Consolidate:Path','Expected scalar nonempty path text.');
path=char(java.io.File(char(value)).getCanonicalPath());
end
function output=stamp()
output=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));
end
function assertPublicEqual(original,saved,allowNative,depth)
% Byte-identical built-in serialization of a plain subtree is stronger than
% numerical isequaln: it preserves nested classes/shapes, sparse/complex
% storage, field order and NaN payloads. Different serialization falls back
% to the original recursive public-data comparison. Native handles always
% use that original recursive path. BranchSolutionFile's independent reader
% also validates every report/metadata subtree as plain data.
if ~allowNative && (isstruct(original)||iscell(original))
    try
        leftBytes=getByteStreamFromArray(original);rightBytes=getByteStreamFromArray(saved);
        if strcmp(class(original),class(saved))&&isequal(size(original),size(saved)) ...
                &&isequal(leftBytes,rightBytes),return;end
    catch
        % Serialization is only an optional equality accelerator.
    end
end
assert(depth<=128&&strcmp(class(original),class(saved))&&isequal(size(original),size(saved)), ...
    'C1Consolidate:Readback','Readback class, shape or nesting differs.');
if isnumeric(original)||islogical(original)
    assert(issparse(original)==issparse(saved)&&isreal(original)==isreal(saved)&&isequaln(original,saved), ...
        'C1Consolidate:Readback','Readback values or storage type differ.');
elseif ischar(original)||isstring(original)
    assert(isequaln(original,saved),'C1Consolidate:Readback','Readback text differs.');
elseif iscell(original)
    for k=1:numel(original),assertPublicEqual(original{k},saved{k},allowNative,depth+1);end
elseif isstruct(original)
    names=fieldnames(original);assert(isequal(names,fieldnames(saved)),'C1Consolidate:Readback','Struct fields differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),allowNative,depth+1);end;end
else
    assert(allowNative&&any(strcmp(class(original),{'HybridOrbit_v3','Trajectory_v3'})), ...
        'C1Consolidate:Readback','Unsupported public object class.');
    names=sort(properties(original));assert(isequal(names,sort(properties(saved))), ...
        'C1Consolidate:Readback','Public properties differ.');
    for k=1:numel(original),for j=1:numel(names),assertPublicEqual(original(k).(names{j}),saved(k).(names{j}),true,depth+1);end;end
end
end


function gpRead2(file,expected)
    for pass=1:2
        x=load(file,'component_plan','plan_digest');assert(strcmp(C1ScientificDigest_v3(x.component_plan),x.plan_digest), ...
            'PKGraphPlan:ReadDigest','Each independent plan read must verify its whole typed digest.');
        assertPublicEqual(expected,x.component_plan,false,0);clear x
    end
end
function gpVerify(refs)
    for k=1:numel(refs)
        r=refs{k};assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'}))&&strcmp(r.file,gpLiteral(r.file)) ...
            &&ischar(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once'))&&strcmp(RoundSHA256_v3(r.file),r.sha256), ...
            'PKGraphPlan:Changed','A consumed immutable source/proof/closure/prefix or current graph recipe changed.');
        if isfield(r,'bytes')
            d=dir(r.file);assert(isscalar(d)&&~d.isdir&&isequal(double(d.bytes),double(r.bytes)), ...
                'PKGraphPlan:Bytes','The actual immutable reference must retain its declared whole-file byte count.');
        end
    end
end
function r=gpRef(file),r=struct('file',gpLiteral(file),'sha256',RoundSHA256_v3(file));end
function file=gpLiteral(value),file=canonical(value);assert(strcmp(file,canonical(V3Path_v3(value))),'PKGraphPlan:Alias','Hash/native-read paths must name the same literal file.');end
function l=gpLimit(u,m),l=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function gpCheck(l),assert(min(l.deadline_unix_seconds-gpUTC(),(l.deadline_monotonic_ns-gpNano())/1e9)>0,'PKGraphPlan:Clock','The original grant/operation clocks expired; retain all actual partial/published files.');end
function t=gpUTC(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=gpNano(),t=double(java.lang.System.nanoTime());end

function value=rfPublic(value)
    if isa(value,'HybridOrbit_v3')||isa(value,'Trajectory_v3')
        out=struct('native_class',class(value));names=properties(value);
        for k=1:numel(names),out.(names{k})=rfPublic(value.(names{k}));end;value=out;
    elseif isstruct(value)
        names=fieldnames(value);for n=1:numel(value),for k=1:numel(names),value(n).(names{k})=rfPublic(value(n).(names{k}));end,end
    elseif iscell(value),for k=1:numel(value),value{k}=rfPublic(value{k});end
    end
end
