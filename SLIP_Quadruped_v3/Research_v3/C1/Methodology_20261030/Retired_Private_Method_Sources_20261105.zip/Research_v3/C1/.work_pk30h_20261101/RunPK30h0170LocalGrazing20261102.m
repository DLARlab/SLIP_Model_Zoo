function study=RunPK30h0170LocalGrazing20261102(contextReference,budget,options)
% Actual negative0170 high pair; native raw-head seed and local family bound.
% At most three square 9-variable roots share one original phase deadline.
% First flight is analytic in the NEW exact chart. Final flight is observed
% from the literal raw liftoff state by native flow, without a projection.
% Only a positively cleared inward candidate is offered once to native PSS.
% No physical edge, continuous-clearance certificate or endpoint is claimed.
    entry=tic;entryUTC=nowUnix();entryMono=nano();
    assert(strcmp(budget.grant_id,'20261101_PK_30h')&&budget.capture.pid==feature('getpid') ...
        &&strcmp(budget.research_deadline_utc,'2026-11-02T20:29:07Z')&&strcmp(budget.deadline_utc,'2026-11-02T22:29:07Z'), ...
        'PKNegativeGrazing:Grant','Retain the original30-hour native UTC and monotonic grant.');
    keys={'OutputFile','PhaseSeconds','NativeSeconds','MaxWallSeconds','StencilOffset'};
    assert(isstruct(options)&&isscalar(options)&&isequal(sort(fieldnames(options)),sort(keys(:))), ...
        'PKGrazing:Options','Supply the five explicit bounded-study options.');
    for key=keys(2:end),validateattributes(options.(key{1}),{'numeric'},{'real','finite','positive','scalar'});end
    assert(options.PhaseSeconds<=240&&options.NativeSeconds==300&&options.MaxWallSeconds<=900, ...
        'PKGrazing:Caps','Use at most240 phase seconds, one full300 native slot and at most900 total seconds.');
    contextKeys={'source_reference','source_pair','frontier_id'};
    assert(isstruct(contextReference)&&isscalar(contextReference) ...
        &&isequal(sort(fieldnames(contextReference)),sort(contextKeys(:))) ...
        &&ischar(contextReference.frontier_id)&&isrow(contextReference.frontier_id) ...
        &&~isempty(contextReference.frontier_id),'PKGrazing:Context','Declare the exact public pair and frontier label.');
    source=contextReference.source_reference;
    assert(isstruct(source)&&isscalar(source)&&isequal(sort(fieldnames(source)),sort({'file';'sha256'})), ...
        'PKGrazing:Reference','Use an exact source file/SHA reference.');
    output=canonical(options.OutputFile);stage=[output,'.pending.mat'];
    root=canonical(V3Root_v3());
    assert(startsWith(output,[root,filesep])&&~isfile(output)&&~isfile(stage), ...
        'PKGrazing:Fresh','Use fresh final/pending study paths inside v3.');
    finish=limit(min(budget.research_deadline_unix_seconds,entryUTC+options.MaxWallSeconds), ...
        min(budget.research_deadline_monotonic_ns,entryMono+options.MaxWallSeconds*1e9));
    work=limit(finish.deadline_unix_seconds-60,finish.deadline_monotonic_ns-60e9);
    refs=providers();verify([refs;{source}]);
    pairReference=source;pairReference.source_pair=contextReference.source_pair;
    old=publicPairContext(pairReference);verify({source});
    assert(isequal(old.source_pair,[55,59]),'PKNegativeGrazing:Pair','Use actual negative0170 directed edge55 to59, never a reflected positive source.');
    descriptor=struct('diagnostic_kind','runtime-object-descriptor', ...
        'source_class',old.policy_configuration.source_class,'settings',old.policy_configuration.settings);
    [policy,pe]=RecordedReturnPolicy_v3(struct('correction_return_policy',descriptor));
    assert(pe.complete&&isequaln(pe.configuration,old.policy_configuration), ...
        'PKGrazing:Policy','Restore the complete unchanged recorded policy.');
    sources=cell(2,1);
    for k=1:2
        c=old.source_core{k};
        sources{k}=HybridOrbit_v3(struct('initial_state',c.state,'initial_mode',c.mode, ...
            'parameter',c.parameter,'period',c.period,'stride_displacement',c.stride, ...
            'return_policy_name',pe.configuration.settings.Name,'section_chart',c.section_chart, ...
            'section_relative_event_signature',c.section_signature,'cyclic_event_signature',c.cyclic_signature));
        assert(strcmp(OrbitContentIdentity_v3(sources{k}),old.seed_native_ids{k}), ...
            'PKGrazing:SourceIdentity','Literal source core must reconstruct its recorded NativeID.');
    end
    base=sources{2};p=base.parameter;q=base.initial_mode;
    assert(left(work)>options.PhaseSeconds+options.NativeSeconds+30, ...
        'PKGrazing:WholeFit','Full phase study, native service and custody must fit the original clocks.');
    study=struct('schema','PK30h-0170-negative-raw-head-local-grazing-v1','context_reference',contextReference, ...
        'source_reference',source,'source_pair',old.source_pair,'source_code',{refs}, ...
        'budget',budget,'original_finish',finish,'original_work',work,'options',options,'owner',old.owner, ...
        'seed_native_ids',{old.seed_native_ids},'source_core',{old.source_core}, ...
        'policy_configuration',pe.configuration,'original_owned_constraint',old.owned_constraint, ...
        'raw_source_phase_guess',old.phase_coordinates,'source_native_event_history',old.source_native_event_history, ...
        'source_native_event_times',old.source_native_event_times,'source_native_event_ids',old.source_native_event_ids, ...
        'source_trajectory_initial_time',old.source_trajectory_initial_time,'source_native_period',old.source_native_period, ...
        'source_event_time_guess_scope', ...
        'Actual native TD/LO history and period; the exact-chart lift is a NEW acquisition candidate, never a snapped source.', ...
        'provisional_origin_quarantine','No off-MATLAB geometry, numerical root, critical time or provisional value is an input.', ...
        'phase_root_calls_attempted',0,'phase_root_calls_returned',0,'native_service_calls_attempted',0, ...
        'native_service_calls_returned',0,'final_flow_calls_attempted',0,'final_flow_calls_returned',0, ...
        'boundary',struct(),'stencil',{{}},'local_rank',struct(),'source_first_flight',struct(), ...
        'native_orbit',[],'native_report',struct(),'native_all_nine',false,'native_PK_qualified',false, ...
        'native_phase_consistent',false,'native_consistency',struct(), ...
        'native_inward_clearance',struct('status','UNASSESSED_native_not_admitted','completed',false,'positive_interior_gap',false), ...
        'first_flight_local_regularity',false, ...
        'final_flight_assessed',false,'final_flight_continuous_coverage_claimed',false, ...
        'boundary_disposition','UNRESOLVED','status','prepared','source_posthash',false, ...
        'edge_committed',false,'global_endpoint_claimed',false,'completed',false,'failure',struct());
    savePending(stage,study);
    try
        study=acquire(study,base,old,p,q,policy,pe,work,options,stage);
        study.completed=isempty(fieldnames(study.failure));
    catch exception
        study.failure=struct('identifier',exception.identifier,'message',exception.message,'stack',exception.stack);
        study.status='caught_failure';
    end
    verify([refs;{source}]);study.source_posthash=true;
    study.elapsed_seconds=toc(entry);savePending(stage,study);
    assert(left(finish)>0,'PKGrazing:Final','Original study final expired; retain pending custody.');
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());delete(stage);
    fprintf('C1_PK_FLIGHT_GRAZING_STUDY_RETURN %s\n',jsonencode(struct('completed',study.completed, ...
        'status',study.status,'source_posthash',study.source_posthash,'phase_roots',study.phase_root_calls_attempted, ...
        'native_services',study.native_service_calls_attempted,'native_all_nine',study.native_all_nine, ...
        'native_PK_qualified',study.native_PK_qualified,'native_phase_consistent',study.native_phase_consistent, ...
        'final_flow_calls',study.final_flow_calls_attempted,'first_flight_local_regularity',study.first_flight_local_regularity, ...
        'final_flight_assessed',study.final_flight_assessed,'boundary_disposition',study.boundary_disposition, ...
        'continuous_coverage_claimed',false,'edge_committed',false,'global_endpoint_claimed',false, ...
        'failure',study.failure,'output_reference',reference(output),'elapsed_seconds',study.elapsed_seconds)));
end
function study=acquire(study,base,old,p,q,policy,pe,work,options,stage)
    try
    s=QuadrupedSchema_v3.shared();
    phaseFinish=limit(min(work.deadline_unix_seconds,nowUnix()+options.PhaseSeconds), ...
        min(work.deadline_monotonic_ns,nano()+options.PhaseSeconds*1e9));
    study.original_phase_finish=phaseFinish;
    ode=odeset('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001);
    phaseOptions=struct('ODEOptions',ode,'DeadlineUnixSeconds',phaseFinish.deadline_unix_seconds, ...
        'DeadlineMonotonicNs',phaseFinish.deadline_monotonic_ns,'AllowNewCandidateChart',true);
    c=old.owned_constraint;c.kind='owned-PAL';
    inner=SynchronousPKPhaseResidual_v3(base.initial_state,q,p,c,phaseOptions);
    boundaryResidual=SynchronousPKFlightGrazingResidual_v3(inner,struct('Kind','flight-grazing'));
    z0=old.phase_coordinates;
    study.source_candidate_lift=inner.fullState(z0);
    study.source_candidate_lift_delta=study.source_candidate_lift-base.initial_state;
    study.source_first_flight=firstInventory(z0,p,s,phaseFinish);
    savePending(stage,study);
    rows=study.source_first_flight.stationary_points;
    candidates=find(arrayfun(@(r)r.leg_index==1&&r.time>0&&r.time<z0(6)&&r.guard_second_derivatives(1)>0,rows));
    if isempty(candidates),study.status='no_resolved_first_flight_minimum_seed';return;end
    guards=arrayfun(@(r)r.guard_values(1),rows(candidates));
    [~,order]=sortrows([guards(:),reshape([rows(candidates).time],[],1)],[1,2]);
    selected=rows(candidates(order(1)));w0=[z0;selected.time];
    study.critical_seed=struct('coordinates',w0,'source_stationary_row',candidates(order(1)), ...
        'selection_scope','Smallest found BL stationary guard with positive curvature; finite grid/bracket seed selection only.');
    savePending(stage,study);
    solver=phaseSolver(phaseFinish,max(eps,left(phaseFinish)));
    fprintf('C1_PK_FLIGHT_GRAZING_BOUNDARY_ROOT_BEGIN\n');call=tic;study.phase_root_calls_attempted=1;savePending(stage,study);
    [w,result]=solver.solve(boundaryResidual,w0,p,q);study.phase_root_calls_returned=1;
    study.boundary=struct('coordinates',w,'initial_coordinates',w0,'displacement_from_seed',w-w0, ...
        'result',result,'seconds',toc(call));savePending(stage,study);
    if ~result.converged||left(phaseFinish)<=0,study.status='boundary_root_unresolved';return;end
    info=boundInfo(boundaryResidual,w,result);study.boundary.info=info;
    study.boundary.literal_seed_delta=w-w0;
    study.boundary.literal_seed_scale=max(ones(9,1),abs(w0));
    study.boundary.literal_seed_distance_inf=norm(w-w0,Inf);
    study.boundary.literal_seed_relative_distance_inf=norm((w-w0)./study.boundary.literal_seed_scale,Inf);
    study.boundary.local_capture_radius_inf=1e-3;
    study.boundary.local_capture_reason='Actual negative rawhead59 is farther from grazing than positive accepted phasehead6. Energy includes dx^2/2 and can require a few1e-4 correction. The predeclared1e-3 bound restricts family capture only; native admission tolerances are unchanged.';
    assert(study.boundary.literal_seed_distance_inf<1e-3&&norm(info.physical_residual,Inf)<=1e-10, ...
        'PKNegativeGrazing:LocalRoot','The root must stay within the declared local actual-negative-source neighborhood.');
    study.boundary.first_flight=firstInventory(w(1:8),p,s,phaseFinish);savePending(stage,study);
    study.boundary.hypothetical_touchdown=hypotheticalTouchdown(info,p,s,phaseFinish);savePending(stage,study);
    % Fresh central finite differences at TWO step sizes. Neither uses
    % Newton's current or Broyden matrix. Full svd retains the eighth null.
    normal=[old.owned_constraint.normal(:);zeros(3,1)];
    geo=info.critical_flight_geometry;gz=geo.fixed_time_z_gradient(1,:);
    gtz=geo.fixed_time_stationarity_z_gradient(1,:);gtt=geo.guard_second_derivatives(1);
    ranks=cell(2,1);steps=[1e-7,3e-8];
    for pass=1:2
        fd=FiniteDifferenceJacobian_v3(struct('Method','central','RelativeStep',steps(pass)));
        J=fd.compute(@(value)boundaryResidual.evaluate(value,p,q),w);
        J7=J(1:7,1:8);[~,S,V]=svd(J7);singular=diag(S);tangent=V(:,end);
        if normal.'*tangent<0,tangent=-tangent;end
        tol7=100*max(size(J7))*eps(max(singular));s9=svd(J);tol9=100*max(size(J))*eps(max(s9));
        ranks{pass}=struct('relative_step',steps(pass),'fresh_numerical_matrix',J,'periodic_J7',J7, ...
            'singular_values',singular,'rank_tolerance',tol7,'rank_J7',nnz(singular>tol7), ...
            'oriented_null_tangent',tangent,'null_residual_inf',norm(J7*tangent,Inf), ...
            'original_PAL_normal_dot_tangent',normal.'*tangent,'guard_gradient_dot_tangent',gz*tangent, ...
            'boundary_singular_values',s9,'boundary_rank_tolerance',tol9,'rank_J9',nnz(s9>tol9), ...
            'restricted_two_by_two_determinant',gz*tangent*gtt);
    end
    A=ranks{1};C=ranks{2};tangent=A.oriented_null_tangent;
    jdiff=norm(A.fresh_numerical_matrix-C.fresh_numerical_matrix,Inf)/max(1,norm(A.fresh_numerical_matrix,Inf));
    ddiff=abs(A.guard_gradient_dot_tangent-C.guard_gradient_dot_tangent)/max(abs([A.guard_gradient_dot_tangent,C.guard_gradient_dot_tangent]));
    study.local_rank=struct('independent_FD_passes',{ranks},'fixed_time_guard_gradient',gz, ...
        'stationarity_gradient',gtz,'guard_second_derivative',gtt,'relative_J_difference_inf',jdiff, ...
        'relative_guard_tangent_difference',ddiff,'classical_derivative_certificate',false, ...
        'derivative_scope','Numerical local rank and step sensitivity only; no validated global certificate.');
    study.first_flight_local_regularity=all(cellfun(@(r)r.rank_J7==7&&r.rank_J9==9 ...
        &&abs(r.original_PAL_normal_dot_tangent)>1e-8&&abs(r.guard_gradient_dot_tangent)>1e-8,ranks)) ...
        &&A.guard_gradient_dot_tangent*C.guard_gradient_dot_tangent>0&&gtt>0&&jdiff<=.05&&ddiff<=.05;
    savePending(stage,study);
    assert(study.final_flow_calls_attempted<2,'PKGrazing:FinalCap','At most two bounded raw final-flow diagnostics.');
    study.final_flow_calls_attempted=study.final_flow_calls_attempted+1;
    study.boundary.final_flight=finalObservation(info.inner_evaluation,p,s,ode,phaseFinish);
    study.final_flow_calls_returned=study.final_flow_calls_returned+1;savePending(stage,study);
    if ~study.first_flight_local_regularity,study.status='local_regularity_unresolved';return;end
    center=old.owned_constraint.normal.'*(w(1:5)-old.owned_constraint.reference);
    criticalTangent=-gtz*tangent/gtt;
    for direction=[-1,1]
        if left(phaseFinish)<=5,study.status='shared_phase_clock_exhausted';return;end
        assert(study.phase_root_calls_attempted<3,'PKGrazing:RootCap','At most three outer acquisition roots.');
        target=center+direction*options.StencilOffset;c=old.owned_constraint;c.kind='owned-PAL';c.target=target;
        oneInner=SynchronousPKPhaseResidual_v3(base.initial_state,q,p,c,phaseOptions);
        one=SynchronousPKFlightGrazingResidual_v3(oneInner,struct('Kind','stationary-owned-PAL'));
        initial=w+[tangent;criticalTangent]*(direction*options.StencilOffset/(normal.'*tangent));
        solver=phaseSolver(phaseFinish,max(eps,left(phaseFinish)));call=tic;
        study.phase_root_calls_attempted=study.phase_root_calls_attempted+1;savePending(stage,study);
        [ws,rs]=solver.solve(one,initial,p,q);study.phase_root_calls_returned=study.phase_root_calls_returned+1;
        row=struct('original_PAL_target',target,'direction',direction,'initial_coordinates',initial, ...
            'coordinates',ws,'displacement_from_boundary',ws-w,'result',rs,'seconds',toc(call));
        study.stencil{end+1,1}=row;savePending(stage,study);
        if ~rs.converged||left(phaseFinish)<=0,study.status='signed_stationary_stencil_unresolved';return;end
        row.info=boundInfo(one,ws,rs);row.first_flight=firstInventory(ws(1:8),p,s,phaseFinish);
        study.stencil{end}=row;savePending(stage,study);
        if norm(ws-w,Inf)>=1e-3||norm(ws-w0,Inf)>=1e-3,study.status='stencil_left_declared_local_neighborhood';return;end
    end
    admissibility=QuadrupedAdmissibility_v3(s);physicalTolerance=admissibility.SwingPenetrationTolerance;
    study.original_swing_penetration_tolerance=physicalTolerance;
    criticalClearance=cellfun(@(r)min(r.info.all_critical_guard_values),study.stencil);
    study.signed_critical_clearance=criticalClearance;
    inward=find(criticalClearance>physicalTolerance);
    outward=find(criticalClearance< -physicalTolerance);
    if numel(inward)~=1||numel(outward)~=1,study.status='no_resolved_signed_inward_outward_pair';return;end
    row=study.stencil{inward};wi=row.coordinates;ii=row.info.inner_evaluation;
    observedFirst=[row.first_flight.minimum_observed_guard_per_leg;ii.phase_geometry{1}.minimum_saved_guard_per_leg];
    observedFinal=[ii.phase_geometry{3}.minimum_saved_guard_per_leg; ...
        inner.Guards.legValues(ii.phase_endpoint_states(:,5),p);inner.Guards.legValues(ii.phase_endpoint_states(:,6),p)];
    study.inward_index=inward;study.outward_index=outward;
    study.inward_observed_first_gap_min=min(observedFirst);study.inward_observed_final_gap_min=min(observedFinal);
    savePending(stage,study);
    assert(study.final_flow_calls_attempted<2,'PKGrazing:FinalCap','At most two bounded raw final-flow diagnostics.');
    study.final_flow_calls_attempted=study.final_flow_calls_attempted+1;
    row.final_flight=finalObservation(ii,p,s,ode,phaseFinish);
    study.final_flow_calls_returned=study.final_flow_calls_returned+1;
    study.stencil{inward}=row;study.final_flight_assessed=row.final_flight.completed;
    observedFinal=[observedFinal;row.final_flight.minimum_observed_guard_per_leg];
    study.inward_observed_final_gap_min=min(observedFinal);
    study.final_flight_scope='Literal raw liftoff native flow, endpoints/saved rows/found stationary points only; finite search cannot certify continuous clearance or exclude even roots.';
    savePending(stage,study);
    if ~(ii.direction_inequalities_hold&&norm(ii.acquisition_full13_delta,Inf)<=1e-8 ...
            &&max(abs([ii.all_td_guard_values;ii.all_lo_guard_values]))<=1e-8 ...
            &&all(isfinite(observedFirst))&&all(observedFirst>=-physicalTolerance) ...
            &&all(isfinite(observedFinal))&&all(observedFinal>=-physicalTolerance))
        study.status='inward_phase_or_observed_clearance_refused';return;
    end
    study.boundary_disposition='finite_local_stationary_crossing_observed_continuous_final_clearance_UNRESOLVED';
    study.native_selector=old.owned_constraint;study.native_selector.target=row.original_PAL_target;
    study.native_selector_scope='Same original owned PAL normal/reference and actual signed inward target; no nonlinear grazing equation in native PSS.';
    savePending(stage,study);
    if left(work)<=options.NativeSeconds+30,study.status='full_native_slot_does_not_fit';return;end
    nativeFinish=limit(min(work.deadline_unix_seconds,nowUnix()+options.NativeSeconds), ...
        min(work.deadline_monotonic_ns,nano()+options.NativeSeconds*1e9));
    integration=struct('RelTol',1e-12,'AbsTol',1e-14,'MaxStep',.001, ...
        'ODEOptions',odeset('OutputFcn',@(~,~,~)double(left(nativeFinish)<=0)));
    map=PoincareMap_v3(Quadrupedal_Dynamics_v3(),PoincareSection_v3.apex(s.PhaseIndex), ...
        HybridSimulator_v3(integration),policy,struct('MaxReturnTime',30,'MaxCycleEvents',1000,'MaxSectionCrossings',64));
    assert(ii.period_guess<map.MaxReturnTime,'PKGrazing:Horizon','Preserve the original native horizon.');
    family=EnergyFamilyResidual_v3(PeriodicOrbitResidual_v3(map,ii.initial_state),ii.initial_state,q,p,struct('Symmetry','pronk'));
    assert(isequal(family.CoordinateIndices(:).',[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL]) ...
        &&isequal(family.fullState(family.packState(ii.initial_state)),ii.initial_state), ...
        'PKGrazing:NativeBasis','Native family must retain the exact inward state and original PAL order.');
    nativeResidual=ConstrainedEnergyResidual_v3(family,1:4,study.native_selector,ones(5,1));
    seed=struct('state',ii.initial_state,'mode',q,'parameter',p,'return_policy',policy, ...
        'occurrence',1,'provenance',struct('kind','NEW exact-chart positive first-flight-clearance native control', ...
        'context_reference',study.context_reference,'source_reference',old.source_reference,'source_pair',old.source_pair, ...
        'literal_source_state',base.initial_state,'full_source_difference',ii.initial_state-base.initial_state));
    nativeOptions=struct('Residual',nativeResidual,'Coordinates',[family.packState(ii.initial_state);wi(5)], ...
        'AugmentedParameter',[p;wi(5)],'MaxWallSeconds',options.NativeSeconds,'TraceFailure',false, ...
        'SolverOptions',nativeSolverOptions(nativeFinish,options.NativeSeconds));
    fprintf('C1_PK_FLIGHT_GRAZING_INWARD_NATIVE_BEGIN critical_clearance=%.17g final_observed_gap=%.17g\n', ...
        criticalClearance(inward),min(observedFinal));
    call=tic;study.native_service_calls_attempted=1;savePending(stage,study);
    [orbit,report]=PeriodicSolutionSolver_v3(seed,nativeOptions);study.native_service_calls_returned=1;
    study.native_seconds=toc(call);study.native_orbit=orbit;study.native_report=report;
    study.native_all_nine=isa(orbit,'HybridOrbit_v3')&&nine(report);savePending(stage,study);
    assert(left(nativeFinish)>0&&left(work)>0,'PKGrazing:NativeLate','Native return must be timely.');
    if study.native_all_nine
        c=report.classification;[~,actualPolicy]=RecordedReturnPolicy_v3(report);[~,version]=GaitSemanticTable_v3();
        study.native_PK_qualified=strcmp(c.contract_version,version)&&isequal(c.canonical_label_qualified,true) ...
            &&strcmp(c.validated_gait_type,'PK')&&isequal(c.flight_count_certain,true)&&isequal(c.flight_count,1);
        study.native_consistency=struct('period_difference',orbit.period-ii.period_guess, ...
            'stride_difference',orbit.stride_displacement(s.TranslationIndex)-ii.stride_guess, ...
            'full13_initial_scaled_inf',norm((orbit.initial_state(2:14)-ii.initial_state(2:14)) ...
                ./max(ones(13,1),abs(ii.initial_state(2:14))),Inf), ...
            'section_token_equal',isequal(orbit.section_relative_event_signature,base.section_relative_event_signature), ...
            'cyclic_token_equal',isequal(orbit.cyclic_event_signature,base.cyclic_event_signature), ...
            'complete_policy_equal',actualPolicy.complete&&isequaln(actualPolicy.configuration,pe.configuration));
        nc=study.native_consistency;
        study.native_phase_consistent=nc.full13_initial_scaled_inf<=1e-8&&abs(nc.period_difference)<=1e-7 ...
            &&abs(nc.stride_difference)<=1e-7&&nc.section_token_equal&&nc.cyclic_token_equal&&nc.complete_policy_equal;
        % Re-observe the ACTUAL corrected native control, not only its phase
        % seed. This does not rewrite any native acceptance or classification.
        study.native_inward_clearance=actualNativeInwardClearance(orbit,wi(9),physicalTolerance,s,nativeFinish);
        savePending(stage,study);
    end
    study.status='native_control_returned';
    catch exception
        study.failure=struct('identifier',exception.identifier,'message',exception.message,'stack',exception.stack);
        study.status='caught_failure';
    end
end
function info=boundInfo(residual,w,result)
    info=result.evaluationInfo;
    assert(isstruct(info)&&isscalar(info)&&isequal(result.state,w) ...
        &&isequal(info.initial_state,residual.fullState(w))&&isequal(info.inner_evaluation.energy_unknown,w(5)) ...
        &&isequal(info.phase_durations,w(6:8))&&isequal(info.critical_time,w(9)) ...
        &&numel(info.physical_residual)==9&&all(isfinite(info.physical_residual)), ...
        'PKGrazing:Binding','Root evidence must bind the literal returned coordinates and all nine rows.');
end
function inventory=firstInventory(z,p,s,finish)
    inventory=stationaryInventory(@(t)firstAt(z,t,p,s),z(6),finish);
    inventory.flight='first';inventory.geometry='Exact upright synchronous analytic NEW-candidate flight, literal rest lengths/swing stiffness/rest angles.';
    inventory.raw_candidate_coordinates=z;
end
function point=firstAt(z,t,p,s)
    expanded=s.expandParameters(p);angle=zeros(4,1);rate=angle;accel=angle;
    for k=1:4
        L=expanded.l_0(k);ks=expanded.k_s(k);r=expanded.rsla(k);
        if ks==0
            C=1;D=t;Ct=0;
            angle(k)=z(3)+z(4)*t;rate(k)=z(4);accel(k)=0;
        else
            nu=sqrt(ks/L^2);assert(isfinite(nu)&&nu>0,'PKGrazing:Frequency','Resolve the literal positive frequency.');
            C=cos(nu*t);D=sin(nu*t)/nu;Ct=-nu*sin(nu*t);
            angle(k)=r+(z(3)-r)*C+z(4)*D;
            rate(k)=(z(3)-r)*Ct+z(4)*C;accel(k)=-(ks/L^2)*(angle(k)-r);
        end
    end
    g=z(2)-t^2/2-expanded.l_0.*cos(angle);
    gt=-t+expanded.l_0.*sin(angle).*rate;
    gtt=-1+expanded.l_0.*(cos(angle).*rate.^2+sin(angle).*accel);
    point=struct('time',t,'guard_values',g,'guard_rates',gt,'guard_second_derivatives',gtt);
end
function observation=hypotheticalTouchdown(info,p,s,finish)
    geometry=info.critical_flight_geometry;x=geometry.state;q=false(4,1);t=info.critical_time;
    observation=struct('completed',false,'raw_critical_state',x,'raw_critical_mode',q, ...
        'raw_critical_time',t,'raw_pre_reset_leg_rates',x(s.Leg.RateIndices), ...
        'raw_pre_guard_values',geometry.native_guard_values,'raw_pre_guard_rates',geometry.native_guard_rates, ...
        'actual_event_claimed',false,'admission_claimed',false,'tensile_failure_cause_claimed',false, ...
        'endpoint_claimed',false,'failure',struct(), ...
        'scope','Hypothetical simultaneous four-TD reset at the solved critical state; no event detection, time advance, energy correction or actual contact/admission inference.');
    if left(finish)<=0,observation.status='UNRESOLVED_shared_phase_deadline';return;end
    try
        reset=ResetMap_v3(s);transition=ModeTransition_v3(s);flow=ContinuousDynamics_v3(s);guards=GuardFunctions_v3(s);
        ids=s.Event.IDs(s.Event.IsTouchdown);observation.touchdown_event_ids=ids;
        xp=reset.applyBatch(ids,t,x,q,p);qp=transition.applyBatch(ids,q);
        observation.raw_post_reset_state=xp;observation.raw_post_reset_mode=qp;
        observation.raw_reset_difference=xp-x;observation.raw_post_reset_leg_rates=xp(s.Leg.RateIndices);
        checkDeadline(finish);[f,diagnostics]=flow.evaluate(t,xp,qp,p);
        observation.raw_post_flow=f;observation.native_post_flow_diagnostics=diagnostics;
        observation.raw_post_guard_values=guards.legValues(xp,p);
        observation.raw_post_guard_rates=guards.legLieDerivatives(xp,f,p);
        expanded=s.expandParameters(p);phi=xp(s.State.phi);theta=phi+xp(s.Leg.AngleIndices);
        cosine=cos(theta);hip=xp(s.State.y)+expanded.s*sin(phi);
        assert(all(abs(cosine)>flow.GeometryTolerance),'PKGrazing:HypotheticalGeometry','Hypothetical stance geometry must be regular.');
        thetaRate=f(s.State.phi)+f(s.Leg.AngleIndices);
        hipRate=f(s.State.y)+expanded.s*cos(phi)*f(s.State.phi);
        length=hip./cosine;lengthRate=hipRate./cosine+hip.*sin(theta).*thetaRate./cosine.^2;
        observation.raw_radial_length=length;observation.raw_radial_length_rate=lengthRate;
        observation.literal_rest_length=expanded.l_0;observation.raw_compression=expanded.l_0-length;
        observation.raw_downward_cosine=cosine;
        observation.original_stance_tension_tolerance=flow.AdmissibilityComponent.StanceTensionTolerance;
        observation.raw_stance_margin=observation.raw_compression+observation.original_stance_tension_tolerance;
        checkDeadline(finish);observation.completed=true;observation.status='hypothetical_native_reset_and_flow_observed';
    catch exception
        observation.failure=struct('identifier',exception.identifier,'message',exception.message,'stack',exception.stack);
        observation.status='UNRESOLVED_hypothetical_reset_or_flow';
    end
end
function observation=finalObservation(innerInfo,p,s,ode,phaseFinish)
    x=innerInfo.phase_endpoint_states(:,5);duration=innerInfo.phase_durations(3);
    flow=ContinuousDynamics_v3(s);guards=GuardFunctions_v3(s);q=false(4,1);
    observation=struct('flight','final','completed',false,'status','UNRESOLVED', ...
        'native_flow_attempted',false,'native_flow_returned',false, ...
        'stationary_search_attempted',false,'stationary_search_returned',false, ...
        'raw_liftoff_state',x,'raw_phase_final_state',innerInfo.phase_endpoint_states(:,6), ...
        'raw_pitch_and_rate',x([s.State.phi,s.State.dphi]),'duration',duration,'parameter',p, ...
        'ODEOptions',ode,'maximum_local_seconds',20,'no_projection',true, ...
        'absolute_liftoff_time',sum(innerInfo.phase_durations(1:2)), ...
        'touchdown_event_ids',s.Event.IDs(s.Event.IsTouchdown).', ...
        'touchdown_event_directions',s.Event.Directions(s.Event.IsTouchdown).', ...
        'native_autonomous_return_claimed',false,'continuous_coverage_claimed',false, ...
        'minimum_observed_guard_per_leg',innerInfo.phase_geometry{3}.minimum_saved_guard_per_leg, ...
        'failure',struct(),'scope','One raw-state flight flow with no events or reset. Endpoints/saved rows/found stationary points only; no absence-of-grazing or global minimum certificate.');
    if left(phaseFinish)<=0,observation.status='UNRESOLVED_shared_phase_deadline';return;end
    finish=limit(min(phaseFinish.deadline_unix_seconds,nowUnix()+20), ...
        min(phaseFinish.deadline_monotonic_ns,nano()+20e9));observation.original_local_finish=finish;
    observation.raw_start=point(0,x);observation.raw_phase_end=point(duration,innerInfo.phase_endpoint_states(:,6));
    try
        opts=odeset(ode,'OutputFcn',@(~,~,~)double(left(finish)<=0));
        observation.native_flow_attempted=true;
        sol=ode45(@rhs,[0,duration],x,opts);observation.native_flow_returned=true;
        observation.native_saved_time=sol.x;observation.native_saved_state=sol.y;
        % Preserve every actually observed native saved-row gap even when
        % endpoint/time/search validation later reports UNRESOLVED.
        saved=zeros(4,numel(sol.x));
        for j=1:numel(sol.x),saved(:,j)=guards.legValues(sol.y(:,j),p);end
        observation.minimum_observed_guard_per_leg=min([observation.minimum_observed_guard_per_leg,min(saved,[],2)],[],2);
        assert(left(finish)>0&&abs(sol.x(end)-duration)<=8*eps(max(1,abs(duration))), ...
            'PKGrazing:FinalFlightIncomplete','Raw native final flight must actually reach its endpoint.');
        assert(all(isfinite(sol.y(:))),'PKGrazing:FinalFlightFinite','Raw native final flight must remain finite.');
        observation.stationary_search_attempted=true;
        inventory=stationaryInventory(@at,duration,finish);observation.stationary_search_returned=true;
        observation.inventory=inventory;observation.native_end=point(duration,sol.y(:,end));
        observation.native_minus_phase_end=sol.y(:,end)-innerInfo.phase_endpoint_states(:,6);
        observation.minimum_observed_guard_per_leg=min([observation.minimum_observed_guard_per_leg, ...
            min(saved,[],2),inventory.minimum_observed_guard_per_leg],[],2);
        observation.completed=true;observation.status='finite_raw_flow_observed_continuous_search_UNRESOLVED';
    catch exception
        observation.failure=struct('identifier',exception.identifier,'message',exception.message,'stack',exception.stack);
    end
    function dx=rhs(t,y),checkDeadline(finish);dx=flow.evaluate(t,y,q,p);end
    function value=at(t)
        checkDeadline(finish);value=point(t,deval(sol,t));
        observation.minimum_observed_guard_per_leg=min(observation.minimum_observed_guard_per_leg,value.guard_values);
    end
    function value=point(t,y)
        f=flow.evaluate(t,y,q,p);
        value=struct('time',t,'state',y,'flow',f,'guard_values',guards.legValues(y,p), ...
            'guard_rates',guards.legLieDerivatives(y,f,p),'guard_second_derivatives',nan(4,1));
    end
end
function inventory=stationaryInventory(at,duration,finish)
    % Sign-change bracketing is deliberately NOT a proof that all roots were
    % found. Even roots, multiple roots and unresolved narrow features remain.
    validateattributes(duration,{'numeric'},{'real','finite','positive','scalar'});
    grid=linspace(0,duration,257);G=zeros(4,numel(grid));D=G;points=cell(numel(grid),1);
    for j=1:numel(grid),checkDeadline(finish);points{j}=at(grid(j));G(:,j)=points{j}.guard_values;D(:,j)=points{j}.guard_rates;end
    inventory=struct('endpoints',{{points{1},points{end}}},'grid_time',grid,'grid_guard_values',G, ...
        'grid_guard_rates',D,'stationary_points',struct([]),'scalar_roots_attempted',0, ...
        'scalar_roots_returned',0,'failed_brackets',{{}},'bracket_cap',64,'bracket_cap_reached',false, ...
        'minimum_observed_guard_per_leg',min(G,[],2),'complete_stationary_coverage_claimed',false, ...
        'continuous_minimum_claimed',false,'search_scope','257 fixed native times, exact sampled zeros and strict sign-change scalar roots for each leg. Even/multiple/narrow roots may be missed.');
    for k=1:4
        zerosAt=find(D(k,:)==0);
        for j=zerosAt(:).'
            r=points{j};r.leg_index=k;r.source='exact_sampled_stationarity';
            if isempty(inventory.stationary_points),inventory.stationary_points=r;else,inventory.stationary_points(end+1)=r;end
        end
        for j=1:numel(grid)-1
            checkDeadline(finish);
            if ~((D(k,j)<0&&D(k,j+1)>0)||(D(k,j)>0&&D(k,j+1)<0)),continue;end
            if inventory.scalar_roots_attempted>=64,inventory.bracket_cap_reached=true;continue;end
            inventory.scalar_roots_attempted=inventory.scalar_roots_attempted+1;
            try
                [t,value,flag]=fzero(@rate,[grid(j),grid(j+1)],optimset('TolX',1e-12,'Display','off'));
                inventory.scalar_roots_returned=inventory.scalar_roots_returned+1;
                assert(flag>0&&t>0&&t<duration&&isfinite(value),'PKGrazing:Stationarity','Require an actual interior scalar-root return.');
                r=at(t);r.leg_index=k;r.source='strict_sign_change_scalar_root';
                if isempty(inventory.stationary_points),inventory.stationary_points=r;else,inventory.stationary_points(end+1)=r;end
                inventory.minimum_observed_guard_per_leg=min(inventory.minimum_observed_guard_per_leg,r.guard_values);
            catch exception
                inventory.failed_brackets{end+1,1}=struct('leg_index',k,'time_bracket',grid(j:j+1), ...
                    'identifier',exception.identifier,'message',exception.message);
                if left(finish)<=0,rethrow(exception);end
            end
        end
    end
    function value=rate(t),checkDeadline(finish);r=at(t);value=r.guard_rates(k);end
end
function checkDeadline(finish)
    assert(left(finish)>0,'PKGrazing:SharedDeadline','The original shared diagnostic/phase deadline expired.');
end
function solver=phaseSolver(finish,seconds)
    options=nativeSolverOptions(finish,seconds);options.FunctionTolerance=1e-12;solver=RootSolver_v3(options);
end
function options=nativeSolverOptions(finish,seconds)
    jac=ValidSidedFiniteDifferenceJacobian_v3(struct('RelativeStep',1e-8, ...
        'DeadlineUnixSeconds',finish.deadline_unix_seconds,'DeadlineMonotonicNs',finish.deadline_monotonic_ns));
    options=struct('Algorithm','root-newton','MaxIterations',40,'MaxFunctionEvaluations',1000, ...
        'FunctionTolerance',1e-11,'ResidualAcceptanceTolerance',1e-10,'StepTolerance',1e-13, ...
        'OptimalityTolerance',1e-18,'ReuseJacobian',true,'InitialJacobian',[],'UseBroyden',true, ...
        'JacobianRefreshInterval',5,'Jacobian',jac,'MaxWallSeconds',seconds);
end
function savePending(file,study)
    save(file,'study','-v7');check=load(file,'study');
    assert(isequaln(check.study.context_reference,study.context_reference) ...
        &&isequaln(check.study.phase_root_calls_attempted,study.phase_root_calls_attempted) ...
        &&isequal(isfield(check.study.boundary,'coordinates'),isfield(study.boundary,'coordinates')), ...
        'PKBoundary:Readback','Source/count/boundary framing changed in pending readback.');
    if isfield(study.boundary,'coordinates')
        assert(isequaln(check.study.boundary.coordinates,study.boundary.coordinates), ...
            'PKBoundary:Readback','Boundary coordinates changed in pending readback.');
    end
    if study.native_all_nine
        [~,a]=RecordedReturnPolicy_v3(study.native_report);[~,b]=RecordedReturnPolicy_v3(check.study.native_report);
        assert(strcmp(OrbitContentIdentity_v3(study.native_orbit),OrbitContentIdentity_v3(check.study.native_orbit)) ...
            &&strcmp(C1ScientificDigest_v3(core(study.native_orbit)),C1ScientificDigest_v3(core(check.study.native_orbit))) ...
            &&a.complete&&b.complete&&isequaln(a.configuration,b.configuration) ...
            &&isequaln(study.native_report.acceptance_gates,check.study.native_report.acceptance_gates) ...
            &&strcmp(C1ScientificDigest_v3(study.native_report.classification), ...
                C1ScientificDigest_v3(check.study.native_report.classification)), ...
            'PKBoundary:NativeReadback','Earned candidate core/ID/full policy/all-nine differs in readback.');
    end
end
function c=core(o),c=struct('state',o.initial_state,'p',o.parameter,'q',o.initial_mode,'T',o.period,'stride',o.stride_displacement,'section',o.section_chart);end
function context=publicPairContext(ref)
    pair=ref.source_pair;
    validateattributes(pair,{'numeric'},{'vector','numel',2,'integer','positive','finite'});
    assert(pair(1)~=pair(2),'PKBoundary:Pair','A directed source pair must contain distinct occurrences.');
    [orbits,reports,metadata]=BranchSolutionFile_v3.loadSolutions(ref.file,pair);
    a=orbits{1};b=orbits{2};ma=metadata{1};mb=metadata{2};
    [~,pa]=RecordedReturnPolicy_v3(reports{1});[~,pb]=RecordedReturnPolicy_v3(reports{2});
    match=MatchingReturnSection_v3(a,b,reports);
    assert(nine(reports{1})&&nine(reports{2})&&pa.complete&&pb.complete ...
        &&isequaln(pa.configuration,pb.configuration)&&match.compatible ...
        &&isequal(a.parameter,b.parameter)&&isequal(a.initial_mode,b.initial_mode) ...
        &&strcmp(pa.configuration.source_class,'BLMarkedApexReturnPolicy_v3') ...
        &&pb.configuration.settings.BLTouchdownsPerReturn==1&&pb.configuration.settings.RequireModeClosure ...
        &&strcmp(ma.component_identity,mb.component_identity)&&isfield(mb,'edge_enabled')&&mb.edge_enabled ...
        &&isfield(mb,'edge_from') ...
        &&isequal(mb.edge_from,pair(1)), ...
        'PKBoundary:Pair','Require one actual directed physical edge and identical complete native context.');
    [~,version]=GaitSemanticTable_v3();
    for k=1:2
        c=reports{k}.classification;
        assert(strcmp(c.contract_version,version)&&isequal(c.canonical_label_qualified,true) ...
            &&strcmp(c.validated_gait_type,'PK')&&isequal(c.flight_count_certain,true)&&c.flight_count==1, ...
            'PKBoundary:Pair','Imported anchors require their literal qualified one-flight PK reports.');
    end
    s=QuadrupedSchema_v3.shared();indices=[s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL];
    ua=a.initial_state(indices);ub=b.initial_state(indices);
    scale=max([ones(4,1),abs(ua),abs(ub)],[],2);delta=(ub-ua)./scale;
    assert(norm(delta)>1e-10,'PKBoundary:Chord','Require a resolved native source secant.');
    E=QuadrupedEnergy_v3.evaluate(b.initial_state,b.initial_mode,b.parameter);
    h=b.event_history;
    assert(isstruct(h)&&all(isfield(h,{'is_stop','guard_id','time'})), ...
        'PKBoundary:History','Require actual native source event history.');
    h=h(~[h.is_stop]);assert(numel(h)==8,'PKBoundary:History','Require exactly four TD and four LO native events.');
    ids=zeros(8,1);times=zeros(8,1);
    for k=1:8,ids(k)=s.eventId(h(k).guard_id);times(k)=h(k).time;end
    td=ismember(ids,s.Event.IDs(s.Event.IsTouchdown));lo=~td;tol=pb.configuration.settings.TimeTolerance;
    assert(isequal(sort(ids),(1:8).')&&all(td(1:4))&&all(lo(5:8)) ...
        &&max(times(td))-min(times(td))<=tol&&max(times(lo))-min(times(lo))<=tol, ...
        'PKBoundary:History','Require native synchronous TD then LO cohorts, without synthesis.');
    t0=b.trajectory.time(1);d=times(ids==1);l=times(ids==2);
    durations=[d-t0;l-d;b.period-(l-t0)];
    assert(all(isfinite(durations)&durations>0),'PKBoundary:History','All recorded duration guesses must be positive.');
    cores=cell(2,1);
    for k=1:2
        o=orbits{k};cores{k}=struct('state',o.initial_state,'mode',o.initial_mode,'parameter',o.parameter, ...
            'period',o.period,'stride',o.stride_displacement,'section_chart',o.section_chart, ...
            'section_signature',o.section_relative_event_signature,'cyclic_signature',o.cyclic_event_signature);
    end
    context=struct('source_reference',struct('file',ref.file,'sha256',ref.sha256), ...
        'source_pair',pair(:).','source_core',{cores},'owner',mb.component_identity, ...
        'source_native_event_history',h,'source_native_event_times',times,'source_native_event_ids',ids, ...
        'source_trajectory_initial_time',t0,'source_native_period',b.period, ...
        'seed_native_ids',{{OrbitContentIdentity_v3(a),OrbitContentIdentity_v3(b)}}, ...
        'policy_configuration',pb.configuration,'phase_coordinates',[ub;E;durations], ...
        'owned_constraint',struct('reference',[ub;E],'normal',[delta/norm(delta)./scale;0],'target',0));
end
function yes=nine(r)
    keys={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations', ...
        'family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    yes=isstruct(r)&&isscalar(r)&&isfield(r,'accepted')&&isequal(r.accepted,true) ...
        &&isfield(r,'acceptance_gates')&&all(isfield(r.acceptance_gates,keys));
    if yes,for k=1:numel(keys),yes=yes&&isequal(r.acceptance_gates.(keys{k}),true);end,end
end
function refs=providers()
    names={'RunPK30h0170LocalGrazing20261102','SynchronousPKFlightGrazingResidual_v3','SynchronousPKPhaseResidual_v3','RootSolver_v3','PeriodicSolutionSolver_v3', ...
        'FiniteDifferenceJacobian_v3','ValidSidedFiniteDifferenceJacobian_v3','RecordedReturnPolicy_v3', ...
        'BLMarkedApexReturnPolicy_v3','HybridOrbit_v3','OrbitContentIdentity_v3','QuadrupedSchema_v3', ...
        'PoincareMap_v3','PoincareSection_v3','PeriodicOrbitResidual_v3','EnergyFamilyResidual_v3','ConstrainedEnergyResidual_v3', ...
        'HybridSimulator_v3','EventDetector_v3','Quadrupedal_Dynamics_v3','ContinuousDynamics_v3','GuardFunctions_v3', ...
        'ResetMap_v3','ModeTransition_v3','QuadrupedEnergy_v3','QuadrupedPhysicalChart_v3','QuadrupedAdmissibility_v3', ...
        'GaitIdentification_v3','GaitSemanticTable_v3','PrimitiveCycleCheck_v3','HybridCycleData_v3','C1ScientificDigest_v3', ...
        'BranchSolutionFile_v3','MatchingReturnSection_v3', ...
        'RoundSHA256_v3','V3Path_v3','V3Root_v3'};
    refs=cell(numel(names)+1,1);
    for k=1:numel(names),file=which(names{k});assert(~isempty(file),'PKBoundary:Provider','Missing %s.',names{k});refs{k}=reference(file);end
    refs{end}=reference(fullfile(V3Root_v3(),'Audits_v3','Folder_Organization','locations.json'));
end
function verify(refs)
    for k=1:numel(refs),file=canonical(refs{k}.file);assert(strcmp(file,canonical(V3Path_v3(file))) ...
        &&strcmp(RoundSHA256_v3(file),refs{k}.sha256),'PKBoundary:Changed','Consumed source/input changed: %s',file);end
end
function r=reference(file),file=canonical(file);r=struct('file',file,'sha256',RoundSHA256_v3(file));end
function file=canonical(file),file=char(java.io.File(char(file)).getCanonicalPath());end
function v=limit(u,m),v=struct('deadline_unix_seconds',u,'deadline_monotonic_ns',m);end
function v=left(f),v=min(f.deadline_unix_seconds-nowUnix(),(f.deadline_monotonic_ns-nano())/1e9);end
function v=nowUnix(),v=posixtime(datetime('now','TimeZone','UTC'));end
function v=nano(),v=double(java.lang.System.nanoTime());end

function observation=actualNativeInwardClearance(orbit,referenceTime,physicalTolerance,s,finish)
    observation=struct('status','UNASSESSED','completed',false,'positive_interior_gap',false, ...
        'raw_native_state14',orbit.initial_state,'raw_native_parameter',orbit.parameter,'raw_native_mode',orbit.initial_mode, ...
        'reference_critical_time',referenceTime,'nearby_stationary_time_radius',1e-3, ...
        'physical_tolerance_unchanged',physicalTolerance,'failure',struct(), ...
        'continuous_nonpenetration_claimed',false, ...
        'scope','Actual admitted native initial state and actual firstTD duration. Exact analytic chart required, no snap. Only the nearby strictly interior positive-curvature stationary clearance is tested; scheduledTD endpoints and whole-flight sampled gaps are separate.');
    try
        checkDeadline(finish);x=orbit.initial_state;p=orbit.parameter;q=orbit.initial_mode;
        assert(~any(q)&&all(x([s.State.dy,s.State.phi,s.State.dphi])==0) ...
            &&all(x(s.Leg.AngleIndices)==x(s.State.alphaBL))&&all(x(s.Leg.RateIndices)==x(s.State.dalphaBL)), ...
            'PKLocalGrazing:ActualNativeChart','Literal admitted state must have the exact analytic chart; never project or snap.');
        history=orbit.event_history;assert(isstruct(history)&&all(isfield(history,{'is_stop','guard_id','time'})), ...
            'PKLocalGrazing:ActualNativeEvents','Use the actual native event history.');
        history=history(~[history.is_stop]);assert(numel(history)==8,'PKLocalGrazing:ActualNativeEvents','Require actual fourTD/fourLO one-flight history.');
        ids=zeros(8,1);times=zeros(8,1);
        for k=1:8,ids(k)=s.eventId(history(k).guard_id);times(k)=history(k).time;end
        assert(isequal(sort(ids),(1:8).')&&all(isfinite(times)),'PKLocalGrazing:ActualNativeEvents','Use literal native labeled event times.');
        td=ismember(ids,s.Event.IDs(s.Event.IsTouchdown));lo=~td;t0=orbit.trajectory.time(1);
        firstTD=min(times(td));lastLO=max(times(lo));durations=[firstTD-t0;lastLO-firstTD;orbit.period-(lastLO-t0)];
        assert(all(isfinite(durations)&durations>0),'PKLocalGrazing:ActualNativeDuration','Use actual positive native phase durations.');
        E=QuadrupedEnergy_v3.evaluate(x,q,p);z=[x([s.State.dx,s.State.y,s.State.alphaBL,s.State.dalphaBL]);E;durations];
        observation.literal_native_event_history=history;observation.literal_native_event_times=times;
        observation.literal_native_initial_time=t0;observation.literal_native_phase_durations=durations;
        inventory=firstInventory(z,p,s,finish);
        inventory.geometry='Exact raw admitted native state/chart and actual native firstTD duration, without projection.';
        observation.first_flight_observations=inventory;
        rows=inventory.stationary_points;
        found=find(arrayfun(@(r)r.leg_index==1&&r.time>0&&r.time<durations(1) ...
            &&abs(r.time-referenceTime)<=1e-3&&all(r.guard_second_derivatives>0),rows));
        assert(isscalar(found),'PKLocalGrazing:ActualNativeCritical','Require one nearby strictly interior positive-curvature BL stationary point.');
        point=rows(found);observation.interior_stationary_point=point;
        observation.interior_guard_values=point.guard_values;observation.minimum_interior_guard=min(point.guard_values);
        observation.scheduled_TD_endpoint=inventory.endpoints{2};
        observation.all_sampled_or_found_guard_minima=inventory.minimum_observed_guard_per_leg;
        observation.positive_interior_gap=all(isfinite(point.guard_values))&&all(point.guard_values>physicalTolerance);
        checkDeadline(finish);observation.completed=true;
        if observation.positive_interior_gap,observation.status='ACTUAL_NATIVE_INTERIOR_POSITIVE_CLEARANCE_OBSERVED';
        else,observation.status='ACTUAL_NATIVE_INTERIOR_POSITIVE_CLEARANCE_REFUSED';end
    catch failure
        observation.failure=struct('identifier',failure.identifier,'message',failure.message,'stack',failure.stack);
        observation.status='UNASSESSED_ACTUAL_NATIVE_CLEARANCE';
    end
end
