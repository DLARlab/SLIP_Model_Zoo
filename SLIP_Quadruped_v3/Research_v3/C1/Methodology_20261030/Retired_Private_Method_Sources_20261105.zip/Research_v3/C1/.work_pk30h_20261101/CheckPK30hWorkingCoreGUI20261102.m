function out=CheckPK30hWorkingCoreGUI20261102(expectedSHA,expectedBytes)
% One cold visible callback check. FIRST supplies the closed promoted-file pin.
% No ODE, correction, admission, animation or actual mouse/hover action.
assert(ischar(expectedSHA)&&isrow(expectedSHA)&&~isempty(regexp(expectedSHA,'^[0-9a-f]{64}$','once')), ...
 'PKWorkingGUI:FuturePin','Materialize the promoted working-file SHA only after its successful native close.');
validateattributes(expectedBytes,{'double'},{'real','scalar','finite','integer','positive','<=',2*1024^2});
V='/Users/nanyoujiayu/Documents/GitHub/SLIP_Model_Zoo/SLIP_Quadruped_v3';N=fullfile(V,'Research_v3','C1');A=fullfile(N,'Audits');
file=fullfile(N,'Compact_Exports_20261030','PK30h_20261101_StoredCoreSet01','C1_PK_Component_0003_WorkingCore29.mat');
refs={ref(file,expectedSHA,expectedBytes); ...
 ref(fullfile(V,'2_Graphic_ToolBox','GUI_v3','QuadrupedGUIController_v3.m'),'0a1eeab690ed669e05adfaa23a2cb16d64758a169646eca2aa73e353c9870c5c',101151); ...
 ref(fullfile(V,'4_Solution_Management','LoadC1WorkingSolutionCore29_v3.m'),'b0680eb630641cdeb092edcf659892112a39e5cb0f8bcd1cbd03b0a71259e69b',16892); ...
 ref(fullfile(V,'4_Solution_Management','LoadC1SolutionCore29_v3.m'),'79e879e565c1a6d6dd6112f327635f85efb5f3a2329cbec7588adf6a197a81a6',14300); ...
 ref(fullfile(V,'SLIP_Quadruped_GUI_v3.m'),'9eb23561dba6949b6198410c7ccd2270d55e5c101fd3b811b0efaa2a91f5ea60',59123); ...
 ref(fullfile(V,'2_Graphic_ToolBox','GUI_v3','BuildQuadrupedGUILayout_v3.m'),'729f10d6f4fe011bd837213aa18f6a6bfea3b28f692debe34e1d19fb1cbb7224',25918); ...
 ref(fullfile(A,'PK30h_20261101_Sustained01_Plan.mat'),'38459ef421412b12dab9eb27afc39c8a77582bebf0ae44bbe25d3f9328c14fb2',5714)};
guard(refs);assert(strcmp(which('QuadrupedGUIController_v3'),refs{2}.file)&&strcmp(which('LoadC1WorkingSolutionCore29_v3'),refs{3}.file) ...
 &&strcmp(which('SLIP_Quadruped_GUI_v3'),refs{5}.file),'PKWorkingGUI:Canonical','Use canonical installed GUI/readers without private provider shadows.');
x=load('-mat',refs{7}.file,'plan');old=x.plan.original_budget;grant=struct('grant_id',old.grant_id,'start_utc',old.start_utc,'research_deadline_utc',old.research_deadline_utc,'deadline_utc',old.deadline_utc);B=AbsoluteRunBudget_v3(grant,old);clear x old
t=clocks();assert(min(B.research_deadline_unix_seconds-t.utc,(B.research_deadline_monotonic_ns-t.mono)/1e9)>422,'PKWorkingGUI:Fit','The420/45 callback operation must fit the unchanged grant.');
finish=struct('utc',t.utc+420,'mono',t.mono+420e9);work=struct('utc',finish.utc-45,'mono',finish.mono-45e9);
audit=fullfile(A,'PK30h_20261102_WorkingCore03_GUI01.mat');png=fullfile(A,'PK30h_20261102_WorkingCore03_GUI01.png');fresh({audit;[audit,'.pending.mat'];png});
originalFolder=pwd;originalPath=path;fig=[];h=[];cleanup=onCleanup(@finishGUI);
out=struct('schema','PK30h-working-core29-visible-callback-v1','completed',false,'source_posthash',false, ...
 'input_references',{refs},'original_budget',B,'operation_finish',finish,'entry_folder','', ...
 'thin_record_count',0,'hydrated_indices_before',[],'hydrated_indices_after',[],'rendered_physical_edge_count',0, ...
 'axes_pixel_bounds',[],'axes_position_verified',false,'folder_dropdown_order_verified',false, ...
 'startup_from_pwd_verified',false,'screenshot',struct('requested',true,'returned',false), ...
 'failure',struct(),'actual_mouse_or_hover_checked',false,'numerical_replay_performed',false,'fresh_admission_claimed',false,'own_process_exit_claimed',false);
try
 check(work);packed=load('-mat',file,'solution_core29','core_digest');core=packed.solution_core29;
 assert(strcmp(C1ScientificDigest_v3(core),packed.core_digest)&&core.point_count==472, ...
  'PKWorkingGUI:Input','Use the full exact472-occurrence working payload.');
 cd(fileparts(file));out.entry_folder=pwd;
 [fig,c,h]=SLIP_Quadruped_GUI_v3(struct('Visible','on','StartTimers',false));drawnow;
 assert(strcmp(c.Folder,out.entry_folder)&&strcmp(c.Root,V)&&strcmp(pwd,out.entry_folder), ...
  'PKWorkingGUI:StartupFolder','The cold GUI must start from actual pwd rather than the GUI .m directory.');
 assert(h.SelectFolder.Layout.Column==1&&h.File.Layout.Column==2&&isequal(h.SelectFolder.Parent,h.File.Parent), ...
  'PKWorkingGUI:Layout','Data Info must place Select Folder before the dataset dropdown.');
 out.startup_from_pwd_verified=true;out.folder_dropdown_order_verified=true;
 check(work);h.Callbacks.LoadDataset(file);drawnow;
 assert(numel(c.Datasets)==1&&c.SelectedDataset==1&&c.SelectedIndex==1&&strcmp(c.Datasets(1).source,file), ...
  'PKWorkingGUI:PlotCallback','LoadDataset callback must load and plot the actual working dataset.');
 records=c.Datasets(1).solutions;assert(numel(records)==472,'PKWorkingGUI:ThinCount','Every occurrence must have its own thin display record.');
 hydrated=false(1,472);
 for k=1:472
  r=records{k};p=r.provenance.core29;hydrated(k)=p.hydrated;
  same(r.initial_state,core.solution_matrix(1:14,k));same(r.parameter,core.parameters{k});same(r.initial_mode,core.modes{k});
  assert(strcmp(p.reader,'LoadC1WorkingSolutionCore29_v3')&&strcmp(p.sha256,expectedSHA) ...
   &&strcmp(p.native_id,core.native_ids{k})&&~p.fresh_admission_claimed&&p.saved_decisions_are_historical, ...
   'PKWorkingGUI:ThinIdentity','Every thin record must retain exact literal values, identity and explicit working-reader provenance.');
 end
 assert(isequal(find(hydrated),1),'PKWorkingGUI:InitialHydration','Initial GUI acquisition must hydrate only the first selected occurrence.');
 out.thin_record_count=472;out.hydrated_indices_before=find(hydrated);
 first=c.selected();same([first.orbit.initial_state;first.orbit.stride_displacement;first.orbit.period],core.solution_matrix(:,1));
 assert(strcmp(OrbitContentIdentity_v3(first.orbit),core.native_ids{1}),'PKWorkingGUI:InitialNative','First native hydration changed identity.');
 h.Index.Value=472;check(work);h.Callbacks.SelectIndex();drawnow;
 last=c.selected();assert(c.SelectedIndex==472&&strcmp(last.provenance.core29.reader,'LoadC1WorkingSolutionCore29_v3') ...
  &&last.provenance.core29.hydrated&&strcmp(OrbitContentIdentity_v3(last.orbit),core.native_ids{472}), ...
  'PKWorkingGUI:LazySelection','Index callback must hydrate and select the last actual working occurrence.');
 same([last.orbit.initial_state;last.orbit.stride_displacement;last.orbit.period],core.solution_matrix(:,472));
 hydrated=cellfun(@(r)r.provenance.core29.hydrated,c.Datasets(1).solutions);assert(isequal(find(hydrated),[1,472]), ...
  'PKWorkingGUI:LazyCount','Only the two requested occurrences should be hydrated.');out.hydrated_indices_after=find(hydrated);
 out.selected_native_ids={core.native_ids{1};core.native_ids{472}};
 lines=findall(h.StateAxes,'Tag','OrderedContinuationComponent');rendered=zeros(0,2);
 for k=1:numel(lines)
  row=lines(k);indices=row.UserData.indices;
  assert(strcmp(row.LineStyle,'-')&&row.LineWidth==2&&row.UserData.dataset==1&&numel(indices)>=2, ...
   'PKWorkingGUI:Lines','Physical branches must render as declared width-two solid lines.');
  rendered=[rendered;[indices(1:end-1).',indices(2:end).']]; %#ok<AGROW>
 end
 physical=zeros(numel(core.graph.physical_edges),2);
 for k=1:numel(core.graph.physical_edges),e=core.graph.physical_edges{k};physical(k,:)=[e.from,e.to];end
 assert(~isempty(physical)&&isequal(sortrows(rendered),sortrows(physical)),'PKWorkingGUI:TypedLines','Every rendered line edge must equal one saved typedP edge; E/A/M do not create physical display lines.');
 out.rendered_physical_edge_count=size(rendered,1);out.nonphysical_relation_counts=[numel(core.graph.record_equalities),numel(core.graph.qualified_aliases),numel(core.graph.numerical_seams)];
 assert(isgraphics(fig)&&isgraphics(h.StateAxes)&&strcmp(fig.Visible,'on')&&strcmp(h.StateAxes.Visible,'on') ...
  &&strcmp(h.PlotTabs.SelectedTab.Title,'State Plot'),'PKWorkingGUI:StateAxes','The selected visible State Plot must contain a valid visible state axes.');
 drawnow;bounds=getpixelposition(h.StateAxes,true);figureSize=fig.Position(3:4);
 assert(all(isfinite(bounds))&&all(bounds(3:4)>50)&&all(bounds(1:2)>=0) ...
  &&all(bounds(1:2)+bounds(3:4)<=figureSize+2),'PKWorkingGUI:AxesBounds','Native rendered axes bounds must be positive and lie inside this figure.');
 out.axes_pixel_bounds=bounds;out.figure_position=fig.Position;out.axes_position_verified=true;
 try
  check(work);exportapp(fig,png);d=dir(png);assert(isscalar(d)&&d.bytes>0,'PKWorkingGUI:PNG','PNG export returned no bytes.');
  out.screenshot=struct('requested',true,'returned',true,'reference',ref(png,RoundSHA256_v3(png),d.bytes), ...
   'scope','Native visible-uifigure export after actual GUI callbacks; human display visibility and actual pointer/hover actions remain untested.');
 catch captureFailure
  out.screenshot=struct('requested',true,'returned',false,'failure_identifier',captureFailure.identifier,'failure_message',captureFailure.message);
 end
 guard(refs);check(work);out.source_posthash=true;out.completed=true;
catch failure
 out.failure=struct('identifier',failure.identifier,'message',failure.message,'report',getReport(failure,'extended','hyperlinks','off'));
end
finishGUI();clear cleanup
out.scope='Cold visible native GUI callback/storage test, including initial Plot and lazy last-point selection. No actual mouse/hover, map/ODE, root solve, scientific admission or branch-completion claim.';
check(finish);gui_check=out;gui_check_digest=C1ScientificDigest_v3(gui_check);stage=[audit,'.pending.mat'];
save(stage,'gui_check','gui_check_digest','-v7');expected=struct('gui_check',gui_check,'gui_check_digest',gui_check_digest);read2(stage,expected);publish(stage,audit);read2(audit,expected);
fprintf('PK30H_WORKING_CORE_GUI_RETURN %s\n',jsonencode(struct('completed',out.completed,'source_posthash',out.source_posthash,'records',out.thin_record_count,'rendered_P',out.rendered_physical_edge_count,'screenshot',out.screenshot,'audit',audit,'audit_sha256',RoundSHA256_v3(audit),'failure',out.failure)));
check(finish);assert(out.completed,'PKWorkingGUI:Incomplete','Retain the native callback audit and any screenshot for review.');
 function finishGUI()
  if ~isempty(fig)&&isgraphics(fig),if ~isempty(h)&&isfield(h,'Callbacks'),h.Callbacks.Close();else,delete(fig);end,end
  fig=[];cd(originalFolder);path(originalPath);
 end
end
function r=ref(file,sha,bytes),r=struct('file',file,'sha256',sha,'bytes',bytes);end
function guard(refs),for k=1:numel(refs),r=refs{k};d=dir(r.file);assert(isscalar(d)&&~d.isdir&&d.bytes==r.bytes&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKWorkingGUI:Guard','An exact immutable input changed: %s',r.file);end,end
function fresh(paths),for k=1:numel(paths),assert(~isfile(paths{k})&&~isfolder(paths{k}),'PKWorkingGUI:Fresh','Preserve existing output: %s',paths{k});end,end
function same(a,b),assert(strcmp(C1ScientificDigest_v3(a),C1ScientificDigest_v3(b)),'PKWorkingGUI:TypedEquality','Literal class/shape/raw bits differ.');end
function read2(file,expected),for pass=1:2,x=load('-mat',file);names=fieldnames(expected);assert(isequal(sort(fieldnames(x)),sort(names)),'PKWorkingGUI:Variables','Exact saved variables differ.');for k=1:numel(names),same(x.(names{k}),expected.(names{k}));end;end,end
function publish(stage,file),fresh({file});javaMethod('createLink','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath());assert(javaMethod('isSameFile','java.nio.file.Files',java.io.File(file).toPath(),java.io.File(stage).toPath()),'PKWorkingGUI:Publication','Publish the owned stage only.');javaMethod('delete','java.nio.file.Files',java.io.File(stage).toPath());end
function t=clocks(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime()));end
function check(limit),t=clocks();assert(min(limit.utc-t.utc,(limit.mono-t.mono)/1e9)>0,'PKWorkingGUI:Deadline','The unchanged bounded operation deadline elapsed.');end
