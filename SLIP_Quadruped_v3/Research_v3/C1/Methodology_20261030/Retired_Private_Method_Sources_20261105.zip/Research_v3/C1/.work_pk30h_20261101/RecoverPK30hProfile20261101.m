function receipt=RecoverPK30hProfile20261101()
%RECOVERPK30HPROFILE20261101 Publish preserved profiling evidence only.
% No map, classifier, root, reacquisition, replay or admission is invoked.
    root=V3Root_v3();base=fullfile(root,'Research_v3','C1','Audits');
    input=fullfile(base,'PK30h_20261101_Regular_Profile_02.mat.raw.pending.mat');
    output=fullfile(base,'PK30h_20261101_Regular_Profile_Recovered.mat');stage=[output,'.pending.mat'];
    expected='ecf525bc33cc53389b8ff77856f4ac3894a80659c7d11440c5a0890e1d78962b';
    assert(~isfile(output)&&~isfile(stage),'PK30hRecover:Fresh','Recovery output and stage must be fresh.');
    rawReference=reference(input);info=dir(input);
    assert(strcmp(rawReference.sha256,expected)&&isscalar(info)&&info.bytes==19887810, ...
        'PK30hRecover:Raw','Use the exact preserved Profile02 native checkpoint.');
    codes={reference(which('RecoverPK30hProfile20261101'));reference(which('C1ScientificDigest_v3')); ...
        reference(which('RoundSHA256_v3'));reference(which('AbsoluteRunBudget_v3')); ...
        reference(which('V3Path_v3'));reference(which('V3Root_v3'))};
    a=load(input,'audit');b=load(input,'audit');
    old=a.audit.budget;
    config=struct('grant_id',old.grant_id,'start_utc',old.start_utc, ...
        'research_deadline_utc',old.research_deadline_utc,'deadline_utc',old.deadline_utc);
    budget=AbsoluteRunBudget_v3(config,old);
    assert(strcmp(a.audit.schema,'C1-PK-held-regular-profile-v1') ...
        &&a.audit.profile.completed&&a.audit.profile.source_unchanged ...
        &&numel(a.audit.profile.map)==2&&numel(a.audit.profile.classification)==2, ...
        'PK30hRecover:Facts','Require the actual four successful saved profiling calls.');
    diagnostic=struct('native_raw_isequaln',isequaln(a.audit,b.audit), ...
        'map',{summary(a.audit.profile,'map')}, ...
        'classification',{summary(a.audit.profile,'classification')}, ...
        'scope','Saved profiler data only. Native function-handle equality is diagnostic, not a scientific value comparison.');
    fprintf('C1_PK_PROFILE_RECOVERY_HOTSPOTS %s\n',jsonencode(diagnostic));
    [projectedA,solverA]=describeIntegrator(a.audit);
    [projectedB,solverB]=describeIntegrator(b.audit);
    fprintf('C1_PK_PROFILE_RECOVERY_INTEGRATOR %s\n',jsonencode(solverA));
    assertPlain(projectedA,'raw_audit');assertPlain(projectedB,'raw_read2_audit');
    projectionDigest=C1ScientificDigest_v3(projectedA);
    assert(strcmp(projectionDigest,C1ScientificDigest_v3(projectedB))&&isequaln(solverA,solverB), ...
        'PK30hRecover:ProjectionRead2','Independent complete plain projections differ.');
    recovery=struct('schema','C1-PK-profile-output-recovery-v1','completed',true, ...
        'budget',budget,'raw_reference',rawReference,'source_code',{codes}, ...
        'raw_read2',true,'raw_projection_typed_digest',projectionDigest, ...
        'original_reporting_failure','main_trajectory_steps absent after an earlier caught postprocessing error', ...
        'original_earlier_caught_error','UNASSESSED: not persisted by the failed harness', ...
        'original_flags_preserved',true,'map_calls',0,'classification_calls',0,'root_calls',0, ...
        'raw_audit',projectedA,'integrator_observation',solverA, ...
        'scope','Output recovery only. Original raw completed/source_posthash/publication flags remain literal. Historical source_code is provenance, not a current-method hash assertion.');
    clear a b projectedB
    assertPlain(recovery,'recovery');digest=C1ScientificDigest_v3(recovery);
    verify([codes;{rawReference}]);
    assert(posixtime(datetime('now','TimeZone','UTC'))<budget.deadline_unix_seconds, ...
        'PK30hRecover:Deadline','Original hard publication deadline expired.');
    wh=whos('recovery');assert(wh.bytes<1750000000,'PK30hRecover:Headroom','Observed recovery exceeds conservative stage headroom.');
    save(stage,'recovery','digest','-v7');readback=load(stage,'recovery','digest');
    assert(strcmp(readback.digest,digest)&&strcmp(C1ScientificDigest_v3(readback.recovery),digest), ...
        'PK30hRecover:Readback','Complete recovered native audit typed readback differs.');
    javaMethod('createLink','java.nio.file.Files',java.io.File(output).toPath(),java.io.File(stage).toPath());
    publicationReturned=true;delete(stage);verify([codes;{rawReference}]);
    receipt=struct('completed',true,'publication_returned',publicationReturned, ...
        'output_reference',reference(output),'typed_digest',digest,'raw_reference',rawReference, ...
        'raw_preserved',isfile(input),'source_posthash',true,'map_calls',0,'classification_calls',0,'root_calls',0, ...
        'scope','Recovered saved profiling evidence; numerical calls were not repeated.');
    fprintf('C1_PK_PROFILE_RECOVERY_ACTUAL_RETURN %s\n',jsonencode(receipt));
end
function [audit,observation]=describeIntegrator(audit)
    solver=audit.profile.integration.ODESolver;
    assert(isa(solver,'function_handle'),'PK30hRecover:Solver','Expected the actual saved ODESolver handle.');
    details=functions(solver);headers=struct();
    for key={'function','type','file'}
        if isfield(details,key{1}),headers.(key{1})=details.(key{1});end
    end
    % Saved callable metadata is observed, not an identity certificate for a
    % currently resolved function. Workspace/captured objects remain opaque
    % in the exact retained raw MAT; the callback is never executed here.
    observation=struct('source_class',class(solver),'func2str',func2str(solver), ...
        'present_function_headers',headers, ...
        'omitted_functions_metadata_fields',{setdiff(fieldnames(details),fieldnames(headers),'stable')}, ...
        'handle_equals_current_ode45',isequal(solver,@ode45), ...
        'current_ode45_observation',reference(which('ode45')), ...
        'historical_current_provider_identity_claimed',false, ...
        'scope','Opaque saved callback metadata only. Full serialization authority is the exact raw MAT SHA. Current ode45 is a separate observation; neither callback is executed.');
    audit.profile.integration.ODESolver=struct('diagnostic_kind','opaque-saved-callback-output-descriptor', ...
        'observation',observation);
    audit.profile.integration_projection_scope='ODESolver callable itself is omitted from the mathematical digest and retained by raw MAT SHA; observed headers are separate. All numerical settings, profiler tables and scientific evidence are retained.';
end
function verify(refs)
    for k=1:numel(refs),assert(strcmp(RoundSHA256_v3(refs{k}.file),refs{k}.sha256), ...
        'PK30hRecover:Changed','Recovery input/provider changed: %s',refs{k}.file);end
end
function rows=summary(profile,kind)
    rows={};if ~isfield(profile,kind),return;end
    for k=1:numel(profile.(kind))
        item=profile.(kind){k};row=struct('pass',k,'profiled',item.profiled,'seconds',item.seconds);
        if isfield(item,'full13_inf'),row.full13_inf=item.full13_inf;end
        if isfield(item,'main_trajectory_steps'),row.main_trajectory_steps=item.main_trajectory_steps;
        else,row.main_trajectory_steps_scope='Not present in the preserved pre-postprocessing raw checkpoint.';end
        if isfield(item,'stored_output_typed_equal'),row.stored_output_typed_equal=item.stored_output_typed_equal;end
        if item.profiled
            table=item.profile.FunctionTable;[~,order]=sort([table.TotalTime],'descend');heads=cell(min(20,numel(order)),1);
            for j=1:numel(heads)
                f=table(order(j));name=char(f.FunctionName);
                heads{j}=struct('function_name_prefix',name(1:min(160,numel(name))), ...
                    'function_name_characters',numel(name),'calls',f.NumCalls,'reported_total_seconds',f.TotalTime);
            end
            row.top20=heads;row.total_function_rows=numel(table);
        end
        rows{k,1}=row;
    end
end
function assertPlain(value,location)
    assert(~issparse(value),'PK30hProfile:UnsupportedLeaf','Sparse output at %s (%s).',location,class(value));
    if isstruct(value)
        names=fieldnames(value);
        for k=1:numel(value)
            for j=1:numel(names),assertPlain(value(k).(names{j}),sprintf('%s(%d).%s',location,k,names{j}));end
        end
    elseif iscell(value)
        for k=1:numel(value),assertPlain(value{k},sprintf('%s{%d}',location,k));end
    else
        assert(isnumeric(value)||islogical(value)||ischar(value)||isstring(value), ...
            'PK30hProfile:UnsupportedLeaf','Unsupported output at %s: class=%s shape=%s.',location,class(value),mat2str(size(value)));
    end
end
function out=reference(file)
    file=char(java.io.File(char(file)).getCanonicalPath());
    assert(strcmp(char(java.io.File(V3Path_v3(file)).getCanonicalPath()),file), ...
        'PK30hProfile:LiteralPath','Hash and native paths must agree.');
    out=struct('file',file,'sha256',RoundSHA256_v3(file));
end
