function result=BuildPK30hCleanupOutcomeCatalog20261102(B,manifestRef,protectedRefs,options)
% Saved plain data only. No deletions, object getters, callbacks, roots or model services.
u=utc();m=mono();assert(B.capture.pid==feature('getpid')&&min(B.deadline_unix_seconds-u,(B.deadline_monotonic_ns-m)/1e9)>1802&&options.MaxWallSeconds==1800&&options.SaveMarginSeconds==120,'PKCatalog:HardFit','Full1800/120 saved-only operation must fit original hard22:29 deadline.');finish=struct('utc',u+1800,'mono',m+1800e9);work=struct('utc',u+1680,'mono',m+1680e9);
assert(iscell(protectedRefs)&&numel(protectedRefs)>=4,'PKCatalog:Protected','Supply Root''s full immutable transitive current Resolution/Graph04/export/mainledger consumer/proof/source-epoch protected references.');output=options.OutputFile;N=fullfile(V3Root_v3(),'Research_v3','C1');assert(strcmp(output,fullfile(N,'Audits','PK30h_20261102_CleanupOutcomeCatalog01.mat'))&&all(cellfun(@(p)~isfile(p)&&~isfolder(p),{output;[output,'.pending.mat'];[output,'.failure.mat']})),'PKCatalog:Fresh','Keep every prior/uncertain catalog path.');
for k=1:numel(protectedRefs),assert(isstruct(protectedRefs{k})&&isscalar(protectedRefs{k})&&all(ismember(fieldnames(protectedRefs{k}),{'file';'sha256';'bytes';'role'})),'PKCatalog:ProtectedHeader','Protected authorities must be compact FILE/SHA/bytes/role headers only.');end
self=reference(which(mfilename));base=[{manifestRef;self};protectedRefs(:)];guardAll(base);manifest=jsondecode(fileread(manifestRef.file));assert(strcmp(manifest.schema,'PK30h-cleanup-outcome-candidate-manifest-v1'),'PKCatalog:Manifest','Use exact administrative candidates only.');J=cells(manifest.mirror_candidates);S=cells(manifest.small_mat_candidates);W=cells(manifest.zero_work_whitelist);T=cells(manifest.producer_transform_references);bounds=manifest.bounds;assert(numel(J)<=64&&numel(S)<=320,'PKCatalog:Bound','Keep finite candidate counts.');for k=1:numel(W),base{end+1,1}=W{k}.source_reference;end;base=[base;T];guardAll(base);check(work);
protected=cellfun(@(r)r.file,protectedRefs,'UniformOutput',false);catalog=struct('schema','PK30h-compact-native-cleanup-outcome-catalog-v1','completed',false,'source_posthash',false,'manifest_reference',manifestRef,'protected_references',{protectedRefs},'original_budget',B,'operation_finish',finish,'operation_work',work,'source_reference',self,'mirror_rows',{{}},'outcome_rows',{{}},'required_native_authorities_to_keep',{{}},'retirement_candidates',{{}},'failure',struct(),'Root_ODE_map_replay_admission_calls',0,'files_unlinked',0,'source_deletion_authorized',false,'scientific_flags_changed',false,'own_process_exit_claimed',false);consumed=base;required=cell(0,1);
try
 for k=1:numel(J)
  check(work);r=J{k}.json_reference;row=struct('json_reference',r,'qualified',false,'decision','KEEP','reason','NO_WHOLE_EXACT_NATIVE_JSON_MATCH','native_reference',struct(),'top_variable','','transform','','native_schema','','whole_decoded_JSON_equal',false,'independent_native_read2_equal',false,'source_posthash',false,'failure',struct());
  try
   assert(~ismember(r.file,protected)&&isempty(regexpi(r.file,'closure|root_closed|implementation|custody|resolution|retirement|cleanup','once'))&&r.bytes<=bounds.max_json_bytes,'PKCatalog:ProtectedJSON','Protected/unique administrative JSON stays KEEP.');guard(r);original=jsondecode(fileread(r.file));authorities=cells(J{k}.native_authorities);matched=false;
   for a=1:numel(authorities)
    check(work);nr=authorities{a};guard(nr);assert(nr.bytes<=bounds.max_native_authority_bytes,'PKCatalog:NativeBound','Oversized named native authority stays KEEP.');vars=whos('-file',nr.file);
    for vi=1:numel(vars)
     if ~any(strcmp(vars(vi).class,{'struct','cell','double','single','logical','char','string','int8','uint8','int16','uint16','int32','uint32','int64','uint64'})),continue;end
     z=load(nr.file,'-mat',vars(vi).name);v=z.(vars(vi).name);if ~plain(v,0),clear z v;continue;end % Reject objects/callbacks before any jsonencode; no getters.
     for variant=1:3
      check(work);try,candidate=decoded(v,variant);equal=isequaln(candidate,original);catch,equal=false;end;clear candidate
      if ~equal,continue;end
      clear z v;z=load(nr.file,'-mat',vars(vi).name);v=z.(vars(vi).name);assert(plain(v,0)&&isequaln(decoded(v,variant),original),'PKCatalog:MirrorRead2','A second independent plain native reconstruction must equal WHOLE decoded JSON.');guard(nr);guard(r);check(work);
      row.qualified=true;row.decision='EXACT_NATIVE_JSON_MIRROR_CANDIDATE';row.reason='WHOLE_DECODED_VALUES_EQUAL_WITHOUT_TOLERANCE';row.native_reference=nr;row.top_variable=vars(vi).name;names={'native_jsonencode_decode','producer_jsonValue_native_strings','producer_jsonSafe_cellstr'};row.transform=names{variant};row.native_schema=schemaOf(v);row.whole_decoded_JSON_equal=true;row.independent_native_read2_equal=true;row.source_posthash=true;required{end+1,1}=nr;consumed=[consumed;{r;nr}];matched=true;clear z v;break
     end
     if matched,break;end
    end
    if matched,break;end
   end
   clear original
  catch problem,row.failure=err(problem);row.reason=problem.identifier;end
  catalog.mirror_rows{k,1}=row;check(work);
 end
 schemas=cellfun(@(r)r.schema,W,'UniformOutput',false);
 for k=1:numel(S)
  check(work);r=S{k}.reference;row=struct('reference',r,'qualified',false,'decision','KEEP','reason',S{k}.default_keep_reason,'top_variable','','original_schema','','zero_work_fields',{{}},'retained_compact_fields',{{}},'omitted_fields',{{}},'inverse_retained_fields_verified',false,'source_posthash',false,'failure',struct());
  try
   assert(S{k}.screen_allowed&&~ismember(r.file,protected)&&r.bytes<bounds.max_small_mat_bytes,'PKCatalog:ExcludedMAT','Scientific/current/unknown path remains KEEP.');guard(r);vars=whos('-file',r.file);assert(sum([vars.bytes])<=bounds.max_small_loaded_bytes&&all(ismember({vars.class},{'struct','cell','double','single','logical','char','string','int8','uint8','int16','uint16','int32','uint32','int64','uint64'})),'PKCatalog:MATBound','Only bounded plain native top variables can be screened.');z=load(r.file,'-mat');assert(plain(z,0)&&~payload(z,'',0),'PKCatalog:Payload','Objects, callbacks, accepted roots, solutions, trajectories, journals and partial payloads stay KEEP.');names=fieldnames(z);hits=[];
   for j=1:numel(names),v=z.(names{j});if isstruct(v)&&isscalar(v)&&isfield(v,'schema')&&any(strcmp(schemaOf(v),schemas)),hits(end+1)=j;end;end
   assert(isscalar(hits),'PKCatalog:UnknownSchema','Exactly one source-derived whitelisted observation/intake/plan/test schema is required.');name=names{hits};v=z.(name);used=zeroWork(v);[kept,omitted]=compact(z);assert(logicalBytes(kept)<=bounds.max_compact_outcome_bytes,'PKCatalog:CompactBound','Unknown or oversized details remain in their original MAT.');clear z v
   for pass=1:2
    z=load(r.file,'-mat');assert(plain(z,0)&&~payload(z,'',0),'PKCatalog:Read2Plain','No runtime/accepted scientific payload may appear on either read.');zeroWork(z.(name));values=cellfun(@(x)at(z,x.path),kept,'UniformOutput',false);expected=cellfun(@(x)x.value,kept,'UniformOutput',false);assert(strcmp(C1ScientificDigest_v3(values),C1ScientificDigest_v3(expected)),'PKCatalog:Inverse','Every retained compact value/class/shape must reconstruct exactly from the original native file.');clear z values expected;end
   guard(r);check(work);row.qualified=true;row.decision='ZERO_WORK_COMPACT_OUTCOME_CANDIDATE';row.reason='EXPLICIT_ZERO_WORK_AND_EXACT_RETAINED_FIELDS';row.top_variable=name;z=load(r.file,'-mat',name);row.original_schema=schemaOf(z.(name));clear z;row.zero_work_fields=used;row.retained_compact_fields=kept;row.omitted_fields=omitted;row.inverse_retained_fields_verified=true;row.source_posthash=true;consumed{end+1,1}=r;
  catch problem,row.failure=err(problem);row.reason=problem.identifier;end
  catalog.outcome_rows{k,1}=row;check(work);
 end
 required=uniqueRefs(required);catalog.required_native_authorities_to_keep=required;requiredPaths=cellfun(@(r)r.file,required,'UniformOutput',false);
 for k=1:numel(catalog.mirror_rows),r=catalog.mirror_rows{k};if r.qualified,catalog.retirement_candidates{end+1,1}=struct('reference',r.json_reference,'kind','whole_JSON_mirror','authority_reference',r.native_reference,'proof_row',k);end;end
 for k=1:numel(catalog.outcome_rows),r=catalog.outcome_rows{k};if r.qualified&&~ismember(r.reference.file,requiredPaths),catalog.retirement_candidates{end+1,1}=struct('reference',r.reference,'kind','zero_work_compact_outcome','authority_reference',struct('file',output,'native_variable','catalog','binding','External returned catalog_reference SHA binds this complete row'),'proof_row',k);elseif r.qualified,catalog.outcome_rows{k}.decision='KEEP_REQUIRED_NATIVE_JSON_AUTHORITY';end;end
 guardAll(consumed);check(work);catalog.source_posthash=true;catalog.completed=true;catalog.scope='Retirement candidates only, never unlink authorization. Root must preserve named native JSON authorities, protected current outputs and every last consumer. Unknown/nonplain/scientific records stay KEEP. No opaque all-detail archive or model/classifier service is created.';
catch problem,catalog.failure=err(problem);end
assert(logicalBytes(catalog)<=bounds.max_catalog_bytes,'PKCatalog:CatalogBound','Never create an opaque oversized outcome archive.');stage=[output,'.pending.mat'];catalog_digest=C1ScientificDigest_v3(catalog);save(stage,'catalog','catalog_digest','-v7');for pass=1:2,z=load(stage,'catalog','catalog_digest');assert(strcmp(C1ScientificDigest_v3(z.catalog),z.catalog_digest)&&strcmp(z.catalog_digest,catalog_digest),'PKCatalog:NativeRead2','Both complete native catalog reads must preserve all compact fields/proof headers.');end
guardAll(consumed);check(finish);assert(catalog.completed&&catalog.source_posthash,'PKCatalog:Incomplete','Keep all originals and partial catalog stage: %s',jsonencode(catalog.failure));javaMethod('move','java.nio.file.Files',java.io.File(stage).toPath(),java.io.File(output).toPath(),javaArray('java.nio.file.CopyOption',0));for pass=1:2,z=load(output,'catalog','catalog_digest');assert(strcmp(C1ScientificDigest_v3(z.catalog),z.catalog_digest)&&strcmp(z.catalog_digest,catalog_digest),'PKCatalog:InstalledRead2','Installed compact catalog read2 must remain exact.');end;guardAll(consumed);check(finish);
refs=cellfun(@(x)x.reference,catalog.retirement_candidates,'UniformOutput',false);result=struct('completed',true,'source_posthash',true,'catalog_reference',reference(output),'native_catalog_read2_verified',true,'mirror_matches',sum(cellfun(@(r)r.qualified,catalog.mirror_rows)),'zero_work_compact_matches',sum(cellfun(@(r)r.qualified,catalog.outcome_rows)),'retirement_candidate_count',numel(refs),'candidate_logical_bytes',sum(cellfun(@(r)r.bytes,refs)),'files_unlinked',0,'Root_ODE_map_replay_admission_calls',0,'own_process_exit_claimed',false);fprintf('PK30H_CLEANUP_CATALOG_RETURN %s\n',jsonencode(result));
end
function out=decoded(v,variant),if variant>1,v=jsonValue(v,variant==3);end;out=jsondecode(jsonencode(v));end
function out=jsonValue(x,cellStrings)
out=x;if isstruct(x),f=fieldnames(x);for j=1:numel(x),for k=1:numel(f),out(j).(f{k})=jsonValue(x(j).(f{k}),cellStrings);end;end
elseif iscell(x),for j=1:numel(x),out{j}=jsonValue(x{j},cellStrings);end
elseif isnumeric(x)&&(~isreal(x)||any(~isfinite(x(:)))),if ~isreal(x),out=struct('real',jsonValue(real(x),cellStrings),'imaginary',jsonValue(imag(x),cellStrings));else,out=cell(size(x));for j=1:numel(x),out{j}=sprintf('%.17g',x(j));end;end
elseif isstring(x)&&cellStrings,out=cellstr(x);end
end
function yes=plain(v,depth)
yes=depth<=80&&(isnumeric(v)||islogical(v)||ischar(v)||isstring(v)||iscell(v)||isstruct(v));if ~yes,return;end;if iscell(v),for j=1:numel(v),if ~plain(v{j},depth+1),yes=false;return;end;end;elseif isstruct(v),f=fieldnames(v);for j=1:numel(v),for k=1:numel(f),if ~plain(v(j).(f{k}),depth+1),yes=false;return;end;end;end;end
end
function yes=payload(v,key,depth)
yes=depth>80;if yes,return;end;bad={'branch_index','solution_core29','component_plan','orbit','orbits','trajectory','trajectories','candidate','candidate_orbit','candidate_report','root','root_result','root_report','root_payload','root_state','root_coordinates','root_output','root_journal','accepted_root','accepted_solution','candidate_state','candidate_coordinates','returned_state','return_state','periodic_state','partial_native','pending_native','state_history','mode_history','dense_samples','flow_samples','solution','solutions','solution_matrix','solved_state','partial_solution','journal','run','attempts','failed_root_journals','pending_admission','pending_batch','fines','proof','earned_physical_edge'};flags={'accepted','all_nine','ordinary_edge_earned','qualified_numerical_relation','edge_committed','isolated_committed','new_admission_claimed','fresh_admission_claimed','new_scientific_edge_created','new_continuation_edge_created','physical_edge_created','M_earned','M_earned_by_this_plan','edge_earned'};
nonempty=~isempty(v)&&~(isstruct(v)&&isscalar(v)&&isempty(fieldnames(v)));if any(strcmpi(key,bad))&&nonempty,yes=true;return;end;if any(strcmpi(key,flags))&&((isnumeric(v)||islogical(v))&&any(v(:)~=0)),yes=true;return;end
if ~isempty(regexpi(key,'^((phase_|native_|new_)?root|periodic_solver|map|ODE|replay|fine|classifier|admission).*(_calls|_count|_attempts|_attempted|_returned)$','once'))&&(isnumeric(v)||islogical(v))&&any(v(:)~=0),yes=true;return;end
if iscell(v),for j=1:numel(v),if payload(v{j},key,depth+1),yes=true;return;end;end;elseif isstruct(v),f=fieldnames(v);for j=1:numel(v),for k=1:numel(f),if payload(v(j).(f{k}),f{k},depth+1),yes=true;return;end;end;end;end
end
function used=zeroWork(v)
combined={'root_ODE_map_replay_classifier_calls','Root_ODE_map_replay_classifier_calls','new_Root_Map_ODE_replay_fine_classifier_calls','root_map_classifier_ODE_replay_calls'};groups={{'root_calls','root_solver_calls','new_roots','new_root_solves','periodic_roots','root_calls_attempted','root_calls_returned','phase_root_calls_attempted','native_root_calls_attempted','root_attempt_count','periodic_solver_calls_attempted'}, {'ODE_calls','new_integrations','integration_calls','ODE_calls_attempted','invoked_map_count','map_calls','flow_calls','full_return_map_calls_attempted'}, {'replay_calls','new_replays','map_calls','new_maps','new_integrations','replay_calls_attempted','fine_calls_attempted'}, {'classifier_calls','classification_calls','new_classifications','classifier_calls_attempted'}, {'new_admissions','admission_calls','fresh_admission_claimed','new_admission_claimed','admission_calls_attempted','admissions'}, {'new_points','earned_points','new_points_created','new_accepted_points','actual_new_points','accepted_points'}, {'new_edges','earned_edges','new_physical_edges','new_edges_created','new_scientific_edge_created','new_continuation_edge_created','actual_new_edges','ordinary_edge_earned','qualified_numerical_relation'}};used=cell(7,1);
for g=1:7,aliases=groups{g};if g<=4,aliases=[aliases,combined];end;found=aliases(isfield(v,aliases));assert(~isempty(found),'PKCatalog:MissingZeroCounter','Missing explicit zero work/earned category%d means KEEP, never an assumed zero.',g);for j=1:numel(found),x=v.(found{j});assert((isnumeric(x)||islogical(x))&&isscalar(x)&&isreal(x)&&isfinite(x)&&x==0,'PKCatalog:NonzeroWork','Every present matching work/earned counter must be literal0/false.');end;used{g}=found;end
end
function [kept,omitted]=compact(z)
kept=cell(0,1);omitted=cell(0,1);walk(z,{},'',0);
 function walk(v,path,key,depth)
  assert(depth<=80&&numel(kept)<10000,'PKCatalog:CompactDepth','Unknown deep/large payload stays KEEP.');essential=~isempty(regexpi(key,'config|option|seed|selector|reference|(^|_)file($|_)|sha256|indices|index|native_?id|initial_state|initial_mode|parameter|period|counter|calls|attempt|new_points|new_edges|earned|status|schema|scope','once'));
  if any(strcmpi(key,{'stack','debug_trace','diagnostic_timings'})),omitted{end+1,1}=descriptor(v,path,'EXPLICIT_NONESSENTIAL_DIAGNOSTIC_FIELD');return;end
  if essential||isempty(v)||(isstruct(v)&&isscalar(v)&&isempty(fieldnames(v))),retain(v,path);return;end
  if isstruct(v),if ~isscalar(v),for j=1:numel(v),walk(v(j),[path,{j}],key,depth+1);end;else,f=fieldnames(v);for j=1:numel(f),walk(v.(f{j}),[path,{f{j}}],f{j},depth+1);end;end
  elseif iscell(v),for j=1:numel(v),walk(v{j},[path,{j}],key,depth+1);end
  else,assert(numel(v)<=64||(ischar(v)&&numel(v)<=4096)||(isstring(v)&&logicalBytes(v)<=8192),'PKCatalog:UnknownArray','No blind numeric/unknown array drop: original MAT stays KEEP.');retain(v,path);end
 end
 function retain(v,path),d=descriptor(v,path,'EXACT_RETAINED_COMPACT_VALUE');d.value=v;kept{end+1,1}=d;end
end
function d=descriptor(v,path,reason),d=struct('path',{path},'class',class(v),'shape',size(v),'logical_bytes',logicalBytes(v),'typed_digest',C1ScientificDigest_v3(v),'reason',reason);end
function v=at(v,path),for j=1:numel(path),p=path{j};if ischar(p),v=v.(p);elseif iscell(v),v=v{p};else,v=v(p);end;end;end
function n=logicalBytes(v),w=whos('v');n=w.bytes;end
function s=schemaOf(v),s='';if isstruct(v)&&isscalar(v)&&isfield(v,'schema')&&(ischar(v.schema)||(isstring(v.schema)&&isscalar(v.schema))),s=char(v.schema);end;end
function c=cells(v),if isstruct(v),c=num2cell(v(:));elseif iscell(v),c=v(:);else,error('PKCatalog:Rows','Expected explicit struct/cell rows.');end;end
function refs=uniqueRefs(refs),if isempty(refs),return;end;keys=cellfun(@(r)[r.file,'|',r.sha256],refs,'UniformOutput',false);[~,at]=unique(keys,'stable');refs=refs(at);end
function r=reference(file),d=dir(file);r=struct('file',char(java.io.File(file).getCanonicalPath()),'sha256',RoundSHA256_v3(file),'bytes',d.bytes);end
function guardAll(refs),for k=1:numel(refs),guard(refs{k});end;end
function guard(r),d=dir(r.file);assert(isscalar(d)&&~d.isdir&&strcmp(char(java.io.File(r.file).getCanonicalPath()),r.file)&&(~isfield(r,'bytes')||d.bytes==r.bytes)&&strcmp(RoundSHA256_v3(r.file),r.sha256),'PKCatalog:Hash','Exact literal consumed source changed.');end
function f=err(e),f=struct('identifier',e.identifier,'message',e.message);end
function check(b),assert(utc()<b.utc&&mono()<b.mono,'PKCatalog:Clock','Original hard/local saved-only clock expired.');end
function t=utc(),t=double(java.time.Instant.now().toEpochMilli())/1000;end
function t=mono(),t=double(java.lang.System.nanoTime());end
