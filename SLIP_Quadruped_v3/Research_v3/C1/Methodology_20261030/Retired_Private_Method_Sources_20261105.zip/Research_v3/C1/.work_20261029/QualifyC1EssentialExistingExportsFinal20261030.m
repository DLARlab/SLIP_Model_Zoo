function audit=QualifyC1EssentialExistingExportsFinal20261030(workerClosure,options)
% Read-only qualification of the TWO exact candidates left by closed16485.
% Historical original-source read2/digests are reused explicitly; no K write,
% raw orbit/report load, callback invocation, Root/map/replay/admission occurs.
    entered=pairClock();
    o=struct('JournalReference',struct(),'MergedComponentReference',struct(),'ReferenceAuditReference',struct(), ...
        'WireQualificationReference',struct(),'KernelReference',struct(),'DigestReference',struct(),'ClosedWorkerSourceReference',struct(), ...
        'ProtectedReferences',{{}},'CoreReferences',{{}},'ResultsReferences',{{}},'SourceReferences',{{}}, ...
        'CompleteCases',{cell(0,1)},'OutputPrefix','','MaxWallSeconds',1200,'OperationalMaximumBytes',NaN, ...
        'SourceClosedBoundaryReference',struct(),'PriorExportAuditReference',struct(),'PriorExportClosureReference',struct());
    assert(isstruct(options)&&isscalar(options)&&all(ismember(fieldnames(options),fieldnames(o))),'C1Existing:Options','Only the explicit18 qualification inputs are allowed.');
    for key=fieldnames(options).',o.(key{1})=options.(key{1});end
    assert(isequal(o.MaxWallSeconds,1200)&&isequal(o.OperationalMaximumBytes,100000000),'C1Existing:Caps','Use this separately reviewed1200s read-only/100MB candidate profile.');
    for key={'JournalReference','MergedComponentReference','ReferenceAuditReference','WireQualificationReference','KernelReference','DigestReference','ClosedWorkerSourceReference','SourceClosedBoundaryReference','PriorExportAuditReference','PriorExportClosureReference'},o.(key{1})=checked(o.(key{1}));end
    closed(workerClosure,o.ClosedWorkerSourceReference);
    assert(workerClosure.process_session_id==14809&&numel(o.CoreReferences)==44&&numel(o.ResultsReferences)==13&&numel(o.SourceReferences)==30&&iscell(o.CompleteCases)&&isequal(size(o.CompleteCases),[2,1]),'C1Existing:Scope','Use the exact PUBLIC B24 source boundary and two complete cases.');
    assert(strcmp(o.KernelReference.sha256,'60a9ff5336ac094be2254d863511139c3488f32fc39b17837b18935d851fd792')&&strcmp(o.DigestReference.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3') ...
        &&strcmp(canonical(which('EssentialBranchSolutionFile_v3')),o.KernelReference.file)&&strcmp(canonical(which('C1ScientificDigest_v3')),o.DigestReference.file),'C1Existing:Methods','The unchanged qualified public kernel/digest must resolve exactly.');
    budget=C1RunBudget_v3();fence=finalStorageLimit(budget);finish=minLimit(shift(entered,1200),fence);work=shift(finish,-120);assert(left(fence)>1202,'C1Existing:Fit','The full new1200s storage allowance must fit BOTH ORIGINAL final clocks.');
    root=canonical(fileparts(which('C1RunBudget_v3')));workspace=fileparts([mfilename('fullpath'),'.m']);prefix=canonical(o.OutputPrefix);assert(strcmp(fileparts(prefix),workspace),'C1Existing:Output','Only fresh own W audit/observation products.');
    lease=acquireWriterLock([o.JournalReference.file,'.writer.lock']); %#ok<NASGU>
    code=[o.SourceReferences(:);{o.KernelReference;o.DigestReference;reference([mfilename('fullpath'),'.m'])}];verifyCode(code);
    refs=[o.ProtectedReferences(:);o.CoreReferences(:);o.ResultsReferences(:);{o.JournalReference;o.MergedComponentReference;o.PriorExportAuditReference;o.PriorExportClosureReference;o.SourceClosedBoundaryReference}];verify(refs);
    c1=jsondecode(fileread(o.PriorExportClosureReference.file));c2=jsondecode(fileread(o.PriorExportClosureReference.file));rawEqual3(c1,c2,c2,'closed crash receipt read2');
    assert(c1.actual_session==16485&&c1.actual_exit_code==137&&c1.actual_child_exit_code==-9&&isequal(c1.qualification_earned,false)&&isequal(c1.native_uncaught_crash_observed,true) ...
        &&isequal(c1.full_native_log_transport_stdout_byte_identity,true)&&isequal(c1.full_tool_log_stdout_byte_identity,false)&&c1.postguard_refs==164 ...
        &&strcmp(c1.source_reference.sha256,'975906621435d23c01f290c76c749b49e05dc4c491a4215e18279b6b51b99b23') ...
        &&isequal(ref2(c1.outputs.audit),ref2(o.PriorExportAuditReference))&&isequal(ref2(c1.current_journal),ref2(o.JournalReference))&&isequal(ref2(c1.current_component),ref2(o.MergedComponentReference)),'C1Existing:PriorCrash','Only the independently closed literal failed16485 source authority is accepted; no old success flag is promoted.');
    q1=load(o.PriorExportAuditReference.file,'audit');q2=load(o.PriorExportAuditReference.file,'audit');rawEqual3(q1.audit,q2.audit,q2.audit,'actual prior NativeMAT read2');prior=q1.audit;clear q1 q2 c2
    assert(strcmp(prior.schema,'C1-essential-additive-complete-store-export-v1')&&isequal(prior.complete,false)&&isempty(fieldnames(prior.failure))&&numel(prior.cases)==2 ...
        &&prior.no_map_root_classifier_fine_replay_or_new_admission&&~prior.whole_original_method_settings_equality_claimed&&~prior.full_branch_completion_claimed ...
        &&prior.cases{1}.completed&&~prior.cases{2}.completed&&~prior.cases{2}.kernel_call_returned&&~prior.cases{2}.correctness_read2_passed,'C1Existing:PriorFlags','Retain the exact incomplete crash audit and its literal case/return flags.');
    rawEqual3(prior.options.CompleteCases,o.CompleteCases,o.CompleteCases,'unchanged complete case selection');verify(prior.source_code);
    output=[prefix,'.audit.mat'];json=[prefix,'.audit.json'];returnFile=[prefix,'.returns.mat'];fresh({output,json,[output,'.pending.mat'],[json,'.pending.json'],returnFile,[returnFile,'.pending.mat']});
    cp=fullfile(root,'Audits','PK_Persistent_Frontiers_20261026_active_checkpoint.mat');absent={cp,[cp,'.pending.mat'],[o.JournalReference.file,'.pending.mat']};fresh(absent);
    audit=struct('schema','C1-essential-readonly-complete-store-qualification-v1','worker_closure',workerClosure,'options',o,'budget',budget,'storage_final_deadline',fence, ...
        'started_utc',stamp(),'finished_utc','','source_code',{code},'inputs',{refs},'prior_export_closure_reference',o.PriorExportClosureReference,'prior_export_audit_reference',o.PriorExportAuditReference, ...
        'prior_cases',{prior.cases},'prior_export_complete',prior.complete,'prior_export_source_posthash',prior.source_posthash, ...
        'source_read2_scope','Prior actual owned source projection read2/ordered C1ScientificDigest authority, pinned to unchanged raw sources; this worker does NOT repeat original raw orbit/report projections.', ...
        'candidate_read_scope','One actual public index plus TWO sequential public bulk thin loads; actual full markers precede actual-context reprojection. Ordered prior digests prove normalized retained-projection transitivity. No candidate-public-index-read2 claim.', ...
        'clock_scope','NEW read-only1200/save120, clipped to ORIGINAL FINAL UTC/JVM; no renewal or alteration of failed16485 clocks.', ...
        'writer_invoked_by_this_worker',false,'whole_old_runtime_equality_claimed',false,'whole_original_method_settings_equality_claimed',false, ...
        'no_map_root_classifier_fine_replay_or_new_admission',true,'core_publication_performed',false,'production_storage_epoch_adopted',false,'full_branch_completion_claimed',false, ...
        'cases',{cell(0,1)},'export_rows_draft',{cell(0,1)},'digest_fixtures',struct(),'native_returns_reference',struct(),'complete',false,'source_posthash',false,'no_live_source_or_core_mutation',false,'failure',struct());
    observations=cell(0,1);products=cell(0,1);publish(output,json,audit,finish);
    try
        for number=1:2
            guard();old=prior.cases{number};spec=o.CompleteCases{number};source=checked(old.source_reference);N=old.source_point_count;
            assert(old.whole_store&&old.source_read2_projection_verified&&old.runtime_descriptor_dispositions_read2_verified&&old.kernel_call_prepared&&N==spec.ExpectedPointCount ...
                &&isequal(ref2(source),ref2(spec.SourceReference))&&iscell(old.record_digests)&&isequal(size(old.record_digests),[N,1])&&all(cellfun(@(h)ischar(h)&&isrow(h)&&~isempty(regexp(h,'^[0-9a-f]{64}$','once')),old.record_digests)),'C1Existing:SourceAuthority','Only the exact fully read2 source-projection receipt may authorize a candidate.');
            [callbacks,derivatives]=validateRuntimeDispositions(old.runtime_descriptor_dispositions,source,N);callbackCounts=[0,24];derivativeCounts=[0,6];assert(callbacks==callbackCounts(number)&&derivatives==derivativeCounts(number),'C1Existing:RuntimeEvidence','Preserve all original24/6 dispositions.');
            raw1=BranchSolutionFile_v3.index(source.file);raw2=BranchSolutionFile_v3.index(source.file);rawEqual3(raw1,raw2,raw2,'fresh raw public index read2, NO raw orbit load');assert(strcmp(C1ScientificDigest_v3(raw1),old.source_index_digest),'C1Existing:SourceIndex','The current source index must match the prior native projection authority.');clear raw2
            candidate=checked(c1.outputs.(sprintf('case%02d_export',number)));expectedPath=sprintf('%s.case%02d.N%d.essential.mat',prior.options.OutputPrefix,number,N);assert(strcmp(candidate.file,canonical(expectedPath))&&strcmp(fileparts(candidate.file),workspace),'C1Existing:CandidatePath','Use only the actual closed canonical nonstage product, without moving or rewriting it.');products{end+1,1}=candidate;wirePreflight(candidate.file);
            progress('candidate_public_index_begin',number);ix=EssentialBranchSolutionFile_v3.index(candidate.file);check(work);assert(numel(ix.points)==N&&strcmp(C1ScientificDigest_v3(ix.metadata),old.typed_graph_digest),'C1Existing:Graph','Actual complete candidate graph must match the prior typed graph digest.');rawEqual3(raw1.edges,ix.edges,ix.edges,'all literal source physical edges');
            assert(isa(ix.record_projection_digests,'uint8')&&isequal(size(ix.record_projection_digests),[32,N]),'C1Existing:IndexDigest','One native32-byte actual record digest per source occurrence.');
            tiny=cell(N,1);for k=1:N,h=lower(reshape(dec2hex(ix.record_projection_digests(:,k),2).',1,[]));assert(strcmp(h,old.record_digests{k}),'C1Existing:IndexRecord','Actual public index record differs from original read2 projection authority.');p=ix.points{k};s=raw1.points{k};assert(isequaln(p.component_identity,s.component_identity)&&isequaln(p.order,s.order),'C1Existing:Owner','Every literal source owner/order must survive.');tiny{k}=struct('native_id',ix.record_native_ids{k},'occurrence_id',ix.occurrence_ids{k},'component_identity',p.component_identity,'order',p.order);end
            counts=struct('physical_edges',numel(ix.metadata.physical_edges),'record_equalities',numel(ix.metadata.record_equalities),'qualified_aliases',numel(ix.metadata.qualified_aliases),'numerical_seams',numel(ix.metadata.numerical_seams));physicalCount=numel(ix.edges);clear ix raw1
            progress('candidate_public_thin_pass1_begin',number);[first,probe]=thinPass(candidate.file,old.record_digests,tiny,source,[],work);verify({candidate});check(work);
            progress('candidate_public_thin_pass2_begin',number);[second,unused]=thinPass(candidate.file,old.record_digests,tiny,source,probe,work);assert(isempty(unused),'C1Existing:Probe','Only one bounded thin handle may be retained between passes.');clear probe unused;rawEqual3(first,second,second,'two independent actual public thin projection digests');verify({candidate});check(work);
            info=dir(candidate.file);assert(isscalar(info)&&info.bytes<=o.OperationalMaximumBytes,'C1Existing:OperationalBound','The exact existing complete candidate must fit the unchanged finite100MB operating bound.');original=dir(spec.V2Reference.file);verify({spec.V2Reference});assert(isscalar(original)&&original.bytes==old.original_v2_bytes,'C1Existing:OriginalV2','Bind literal actual whole-original V2 file bytes, not a subset.');
            row=struct('case_number',number,'family_label',spec.FamilyLabel,'source_reference',source,'source_point_count',N,'snapshot_utc',old.snapshot_utc, ...
                'source_index_digest',old.source_index_digest,'record_digests',{old.record_digests},'typed_graph_digest',old.typed_graph_digest,'typed_graph_counts',counts, ...
                'source_read2_projection_verified',true,'source_read2_projection_scope','Historical actual original read2 receipt; fresh canonical/digest transitivity, no repeated raw orbit/report loading.', ...
                'runtime_descriptor_dispositions',{old.runtime_descriptor_dispositions},'runtime_descriptor_dispositions_read2_verified',true,'callback_descriptor_conversion_count',callbacks,'unavailable_jacobian_omission_count',derivatives, ...
                'prior_kernel_call_returned',old.kernel_call_returned,'prior_kernel_return_timely',old.kernel_return_timely,'prior_case_completed',old.completed,'writer_invoked_by_this_worker',false, ...
                'candidate_reference',candidate,'candidate_is_unpublished_stage',false,'actual_bytes',info.bytes,'operational_maximum_bytes',o.OperationalMaximumBytes, ...
                'original_v2_reference',ref2(spec.V2Reference),'original_v2_bytes',original.bytes,'original_v2_point_count',old.original_v2_point_count,'final_target_bytes',5*original.bytes,'final_target_passed',info.bytes<=5*original.bytes, ...
                'matched_V2_bytes',old.matched_V2_bytes,'maximum_bytes',old.maximum_bytes,'size_gate_passed',info.bytes<=old.maximum_bytes, ...
                'matched_N_scope','Actual compressed candidate bytes against the prior saved/read2 same-N derivative size; observational only. The prior derivative need not remain available.', ...
                'candidate_public_index_reads',1,'candidate_public_thin_reads',2,'correctness_read2_passed',true,'whole_graph_owner_identity_verified',true,'duplicate_handle_sharing_verified',true,'completed',true);
            boundary=struct('schema','C1-closed-native-source-boundary-v1','process_session_id',workerClosure.process_session_id,'exit_code',workerClosure.exit_code,'actual_process_exit_observed',workerClosure.actual_process_exit_observed,'custody_complete',workerClosure.custody_complete,'closure_reference',o.SourceClosedBoundaryReference,'source_reference',source,'source_point_count',N,'scope','Actual closed PUBLIC B24 raw authority plus prior owned projection read2 and this separate existing-candidate qualification; no new admission or branch completion.');
            sizeObservation=struct('operational_maximum_bytes',row.operational_maximum_bytes,'actual_export_bytes',row.actual_bytes,'original_v2_reference',row.original_v2_reference,'original_v2_bytes',row.original_v2_bytes,'original_v2_point_count',row.original_v2_point_count,'final_target_bytes',row.final_target_bytes,'final_target_passed',row.final_target_passed,'matched_N_diagnostics',struct('actual_point_count',N,'matched_v2_bytes',row.matched_V2_bytes,'maximum_bytes',row.maximum_bytes,'passed',row.size_gate_passed));
            audit.cases{end+1,1}=row;audit.export_rows_draft{end+1,1}=struct('export_reference',candidate,'source_reference',source,'source_point_count',N,'source_physical_edge_count',physicalCount,'snapshot_utc',row.snapshot_utc,'source_closed_boundary',boundary,'full_branch_completion_claimed',false,'canonical_projection_read2_verified',true,'ids_owner_graph_verified',true,'published_additive_export',true,'candidate_is_unpublished_stage',false,'size_observation',sizeObservation);
            observations{end+1,1}=struct('case_number',number,'source_point_count',N,'candidate_reference',candidate,'fresh_read_only_qualification_completed',true,'writer_invoked',false);saveReturns(returnFile,observations);audit.native_returns_reference=reference(returnFile);publish(output,json,audit,finish);guard();progress('case_readonly_qualification_passed',number);
        end
        guard();verify(products);audit.complete=true;audit.source_posthash=true;audit.no_live_source_or_core_mutation=true;audit.finished_utc=stamp();publish(output,json,audit,finish);guard();fprintf('C1_EXISTING_EXPORT_QUALIFICATION_RETURN cases=2 complete=1 writerInvoked=0\n');check(finish);
    catch problem
        audit.complete=false;audit.failure=exceptionData(problem);audit.finished_utc=stamp();try,publish(output,json,audit,finish);catch custody,warning('C1Existing:Custody','Retain actual products/outcomes: %s',custody.message);end;rethrow(problem)
    end
    function guard()
        check(work);verifyCode(code);verify(refs);verify(products);fresh(absent);assert(isequaln(C1RunBudget_v3(),budget),'C1Existing:Budget','Original clocks never renew.');
        assert(isequal(coreRoster(root,o.MergedComponentReference.file),sort(cellfun(@(r)canonical(r.file),o.CoreReferences(:),'UniformOutput',false)))&&isequal(resultsRoster(root),sort(cellfun(@(r)canonical(r.file),o.ResultsReferences(:),'UniformOutput',false))),'C1Existing:Rosters','Current raw store/13MAT roster must remain unchanged; all19 external/protected guards remain.');
    end
    function progress(phase,number),fprintf('C1_EXISTING_EXPORT_PROGRESS case=%d phase=%s\n',number,phase);check(work);end
end

function wirePreflight(file)
    v=whos('-file',file);assert(isequal(sort({v.name}),{'branch_index','essential_branch'}),'C1Existing:Variables','Only the exact newly written wire form is allowed.');a=v(strcmp({v.name},'branch_index'));b=v(strcmp({v.name},'essential_branch'));
    assert(strcmp(a.class,'struct')&&isequal(a.size,[1,1])&&a.bytes<=16*1024&&strcmp(b.class,'uint8')&&numel(b.size)==2&&b.size(2)==1&&b.bytes==b.size(1)&&b.bytes<=256*1024^2,'C1Existing:WireBounds','Inspect bounded scalar discovery/uint8 column BEFORE any public decode; no legacy struct fallback.');
end

function [digests,probe]=thinPass(file,expected,tiny,source,priorProbe,limit)
    N=numel(expected);[orbits,reports,metadata]=EssentialBranchSolutionFile_v3.loadSolutions(file,[(1:N).';N;1]);digests=cell(N,1);probe=[];
    assert(orbits{N}==orbits{N+1}&&orbits{1}==orbits{N+2},'C1Existing:Handles','Duplicate requested positions share exact handles within each actual call.');
    if isempty(priorProbe),probe=orbits{1};else,assert(priorProbe~=orbits{1},'C1Existing:Handles','Independent actual calls create distinct thin handles.');end
    for k=1:N
        originalMarker=orbits{k}.schema_metadata.essential_storage;rawEqual3(originalMarker,reports{k}.essential_storage,reports{k}.essential_storage,'actual full orbit/report marker before project');context=originalMarker.context;
        assert(context.source_index==k&&context.expected_index==k&&isequal(ref2(context.source_reference),ref2(source))&&strcmp(context.occurrence_id,sprintf('source-sha256:%s:index:%d',source.sha256,k)),'C1Existing:Context','Use the ACTUAL source-bound occurrence context.');
        record=EssentialBranchSolutionFile_v3.project(orbits{k},reports{k},metadata{k},context);rawEqual3(expectedMarker(record),originalMarker,reports{k}.essential_storage,'actual marker compared with fresh projection contract');
        assert(isequal(record.native_id,tiny{k}.native_id)&&strcmp(record.context.occurrence_id,tiny{k}.occurrence_id)&&isequaln(record.metadata.component_identity,tiny{k}.component_identity)&&isequaln(record.metadata.order,tiny{k}.order),'C1Existing:Identity','Full literal ID/occurrence/owner/order agrees with the actual index.');
        digests{k}=C1ScientificDigest_v3(record);assert(strcmp(digests{k},expected{k}),'C1Existing:Projection','Actual complete canonical record differs from the actual prior source read2 digest authority.');check(limit);
    end
end

function [callbacks,derivatives]=validateRuntimeDispositions(groups,source,N)
    callbacks=0;derivatives=0;seen=cell(0,1);
    for k=1:numel(groups)
        g=groups{k};
        for index=g.source_indices.'
            key=sprintf('%s:%d',g.path,index);assert(~ismember(key,seen),'C1EssentialComplete:RuntimeDuplicate','No repeated normalized runtime occurrence.');seen{end+1,1}=key; %#ok<AGROW>
        end
        if strcmp(g.disposition,'saved_name_retained_without_runtime_closure'),callbacks=callbacks+numel(g.source_indices);
        elseif strcmp(g.disposition,'omitted_runtime_leaf_settings_not_saved'),derivatives=derivatives+numel(g.source_indices);
        else,error('C1EssentialComplete:RuntimeDisposition','Unknown runtime evidence disposition.');end
    end
    if strcmp(source.sha256,'352a07916704238c4cace61ba0950e7b671aaf7ef51234731288c7294f43ef5f')
        assert(N==465&&numel(groups)==7&&callbacks==24&&derivatives==6&&numel(seen)==30, ...
            'C1EssentialComplete:RuntimeCount','The exact current PK source must conserve all24 name conversions and6 explicit settings-unavailable omissions.');
        paths={'integration.ODESolver';'integration.ODEOptions.OutputFcn';'replay_integration.ODESolver';'replay_integration.ODEOptions.OutputFcn';'options.SolverOptions.Jacobian'};
        for j=1:numel(paths),for index=289:294,assert(ismember(sprintf('%s:%d',paths{j},index),seen),'C1EssentialComplete:RuntimeCoverage','Every exact observed path/index must retain its original descriptor in the audit.');end,end
    else
        assert(isempty(groups)&&callbacks==0&&derivatives==0,'C1EssentialComplete:RuntimeScope','No unrelated saved store may receive a runtime descriptor adaptation.');
    end
end

function marker=expectedMarker(r)
    c=EssentialBranchSolutionFile_v3.contract();marker=struct('schema',c.schema,'historical_evidence_only',true, ...
        'trajectory_available',false,'event_state_tapes_available',false,'solver_tapes_available',false, ...
        'requires_fresh_replay',true,'whole_runtime_equality_claimed',false,'omissions',c.omissions, ...
        'receipt_reference_availability',c.receipt_reference_availability,'cluster_membership_domain',c.cluster_membership_domain);
    marker.native_id=r.native_id;marker.context=r.context;marker.recorded_policy_evidence=r.policy;
    marker.retained_orbit_fields=fieldnames(r.orbit);marker.retained_report_fields=fieldnames(r.report);marker.retained_method_fields=fieldnames(r.method);marker.native_id_available=~isempty(r.native_id);
end

function saveReturns(file,observations)
    stage=[file,'.pending.mat'];fresh({stage});save(stage,'observations','-v7');a=load(stage,'observations');b=load(stage,'observations');rawEqual3(observations,a.observations,b.observations,'actual kernel returns');move(stage,file,isfile(file));a=load(file,'observations');b=load(file,'observations');rawEqual3(observations,a.observations,b.observations,'installed kernel returns');
end

function out=ref2(r),out=struct('file',canonical(r.file),'sha256',r.sha256);end

function rawEqual3(expected,a,b,where)
    assert(strcmp(class(expected),class(a))&&strcmp(class(expected),class(b))&&isequal(size(expected),size(a),size(b)),'C1PackedPilot:ExactType','Type/shape changed at %s.',where);
    if isnumeric(expected)
        assert(isequal(isreal(expected),isreal(a),isreal(b)),'C1PackedPilot:ExactRealness','Numeric realness changed at %s.',where);
        assert(isequal(typecast(real(expected(:)),'uint8'),typecast(real(a(:)),'uint8'),typecast(real(b(:)),'uint8')),'C1PackedPilot:ExactBytes','Real numeric raw bytes changed at %s.',where);
        if ~isreal(expected),assert(isequal(typecast(imag(expected(:)),'uint8'),typecast(imag(a(:)),'uint8'),typecast(imag(b(:)),'uint8')),'C1PackedPilot:ExactBytes','Imaginary raw bytes changed at %s.',where);end
    elseif islogical(expected)||ischar(expected)
        assert(isequal(expected,a,b),'C1PackedPilot:ExactValue','Literal values changed at %s.',where);
    elseif isstring(expected)
        assert(isequaln(expected,a,b),'C1PackedPilot:ExactString','Literal strings/missingness changed at %s.',where);
    elseif iscell(expected)
        for k=1:numel(expected),rawEqual3(expected{k},a{k},b{k},sprintf('%s{%d}',where,k));end
    elseif isstruct(expected)
        f=fieldnames(expected);assert(isequal(f,fieldnames(a),fieldnames(b)),'C1PackedPilot:ExactFields','Field names/order changed at %s.',where);
        for k=1:numel(expected),for j=1:numel(f),rawEqual3(expected(k).(f{j}),a(k).(f{j}),b(k).(f{j}),[where,'.',f{j}]);end,end
    else
        error('C1PackedPilot:ExactClass','Unsupported projection class %s at %s.',class(expected),where);
    end
end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function closed(w,r)
    fields={'schema','actual_process_exit_observed','all_owned_native_workers_exit_observed','process_session_id','exit_code','source_sha256','custody_complete','pending_boundary_reviewed'};
    assert(isstruct(w)&&isscalar(w)&&all(isfield(w,fields))&&strcmp(w.schema,'C1-closed-owned-native-worker-v1')&&isequal(w.actual_process_exit_observed,true)&&isequal(w.all_owned_native_workers_exit_observed,true) ...
        &&isnumeric(w.process_session_id)&&isscalar(w.process_session_id)&&isfinite(w.process_session_id)&&w.process_session_id>0&&w.process_session_id==fix(w.process_session_id)&&isequal(w.exit_code,0) ...
        &&strcmp(w.source_sha256,r.sha256)&&isequal(w.custody_complete,true)&&isequal(w.pending_boundary_reviewed,true), ...
        'C1MergedB:WorkerClosure','Require actual previous owned-worker exit0 and completed custody/pending review; marker/current empty active fields alone do not prove process closure.');
    [~,name,ext]=fileparts(r.file);assert(strcmp(ext,'.m')&&strcmp(canonical(which(name)),r.file),'C1MergedB:WorkerSource','The actually closed helper source must match its retained current resolver.');
end

function paths=coreRoster(root,merged)
    d=dir(fullfile(root,'Components'));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==43&&~any([d.isdir])&&all(endsWith(lower(string({d.name})),'.mat'))&&~any(contains(lower(string({d.name})),'pending')),'C1MergedB:OriginalCores','Keep exact43 untouched core MATs and no unknown stage.');paths=cellfun(@(n)canonical(fullfile(root,'Components',n)),{d.name}.','UniformOutput',false);
    d=dir(fileparts(merged));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==1&&~d.isdir&&strcmp(canonical(fullfile(d.folder,d.name)),merged),'C1MergedB:MergedDirectory','The permanent merged directory contains exactly its current one MAT with no random/stage file.');paths=sort([paths;{merged}]);
end

function names=resultsRoster(root)
    d=dir(fullfile(root,'Results','*.mat'));assert(~any([d.isdir]),'C1MergedB:ResultsDirectory','A Results MAT entry cannot be a directory.');names=sort(cellfun(@(n)canonical(fullfile(root,'Results',n)),{d.name}.','UniformOutput',false));
end

function l=finalStorageLimit(b),l=struct('utc',b.deadline_unix_seconds,'mono',b.deadline_monotonic_ns);end

function l=minLimit(a,b),l=struct('utc',min(a.utc,b.utc),'mono',min(a.mono,b.mono));end

function publish(file,json,audit,l)
check(l);stage=[file,'.pending.mat'];fresh({stage});save(stage,'audit','-v7');a=load(stage,'-mat','audit');b=load(stage,'-mat','audit');assert(isequaln(a.audit,audit)&&isequaln(b.audit,audit),'C1Pilot:Audit','Both complete plain audit reads must agree.');move(stage,file,isfile(file));stage=[json,'.pending.json'];fresh({stage});jsonProjection=audit;
if isstruct(jsonProjection.digest_fixtures)&&isscalar(jsonProjection.digest_fixtures)&&isfield(jsonProjection.digest_fixtures,'payload')
    % Complex values, raw NaN payloads, signed zero, uint64 and missing-string
    % fixtures are native MAT evidence. JSON cannot represent them faithfully.
    % Never alter the native audit, fixture inputs, digests or pass/fail flags.
    jsonProjection.digest_fixtures=rmfield(jsonProjection.digest_fixtures,'payload');
    jsonProjection.digest_fixtures.payload_available_in_JSON=false;
    jsonProjection.digest_fixtures.payload_storage_scope='Full literal fixture payload is retained and read twice in the audit MAT; this JSON projection omits only that payload. Digests, distinct pairs and actual flags remain literal. JSON is not the native scientific equality authority.';
end
text=jsonencode(jsonProjection,PrettyPrint=true);h=fopen(stage,'w');assert(h>=0,'C1Pilot:JSON','Cannot open fresh JSON stage.');c=onCleanup(@()fclose(h));bytes=unicode2native(text,'UTF-8');assert(fwrite(h,bytes,'uint8')==numel(bytes),'C1Pilot:JSON','Write every projected byte.');clear c;assert(isequaln(jsondecode(fileread(stage)),jsondecode(text)),'C1Pilot:JSON','Projected JSON differs.');move(stage,json,isfile(json));a=load(file,'-mat','audit');b=load(file,'-mat','audit');assert(isequaln(a.audit,audit)&&isequaln(b.audit,audit),'C1Pilot:Installed','Both whole installed audit reads must agree.');check(l);
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1Pilot:Resolver','A guarded implementation resolves elsewhere.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Pilot:Changed','A guarded authority/source/core changed.');end,end

function r=reference(f),assert(isfile(f),'C1Pilot:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function move(a,b,replace),if replace,v=javaArray('java.nio.file.CopyOption',2);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');v(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');else,fresh({b});v=javaArray('java.nio.file.CopyOption',1);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');end;javaMethod('move','java.nio.file.Files',java.io.File(a).toPath(),java.io.File(b).toPath(),v);end

function fresh(files),for k=1:numel(files),assert(~isfile(files{k})&&~isfolder(files{k}),'C1Pilot:Fresh','Retain an existing authority or uncertain stage.');end,end

function e=exceptionData(x),causes=cell(size(x.cause));for k=1:numel(causes),causes{k}=exceptionData(x.cause{k});end;e=struct('identifier',x.identifier,'message',x.message,'stack',x.stack,'causes',{causes});end

function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end

function t=pairClock(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function t=shift(t,s),t.utc=t.utc+s;t.mono=t.mono+s*1e9;end

function v=left(t),v=min(t.utc-posixtime(datetime('now','TimeZone','UTC')),(t.mono-double(java.lang.System.nanoTime))/1e9);end

function check(t),assert(left(t)>0,'C1Pilot:Clock','The fixed whole/local/science clock expired.');end

function s=stamp(),s=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

