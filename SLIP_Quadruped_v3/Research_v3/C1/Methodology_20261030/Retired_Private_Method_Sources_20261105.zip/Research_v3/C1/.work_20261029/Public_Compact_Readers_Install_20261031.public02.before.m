function audit=AuditC1LiveRanges_v3(c1Root,maxWallSeconds,confirmedIdle,useFinalReserve)
%AUDITC1LIVERANGES_V3 Closed-store snapshot; no integration, map or replay.
% Optional fourth logical opts into the original final deadline for saved-data auditing only.
% Each output is atomically replaced. Matching audit_id binds the MAT/JSON
% pair; two distinct filesystem names cannot be published as one transaction.
    if nargin<2,maxWallSeconds=600;end
    assert(nargin>=3&&nargin<=4&&isequal(confirmedIdle,true),'C1Ranges:Idle','Confirm all owned branch writers exited.');
    if nargin<4,useFinalReserve=false;end
    assert(islogical(useFinalReserve)&&isscalar(useFinalReserve),'C1Ranges:Reserve','UseFinalReserve must be a scalar logical.');
    validateattributes(maxWallSeconds,{'double'},{'scalar','real','finite','>',20,'<=',600});
    c1Root=char(java.io.File(char(c1Root)).getCanonicalPath());budget=C1RunBudget_v3();
    capUTC=budget.research_deadline_unix_seconds;capMono=budget.research_deadline_monotonic_ns;
    if useFinalReserve,capUTC=budget.deadline_unix_seconds;capMono=budget.deadline_monotonic_ns;end
    stopUTC=min(capUTC,utc()+maxWallSeconds);
    stopMono=min(capMono,nano()+maxWallSeconds*1e9);
    workUTC=stopUTC-20;workMono=stopMono-20e9;guard();
    [~,contract]=GaitSemanticTable_v3();schema=QuadrupedSchema_v3.shared();
    audit=struct('schema','C1-native-stored-range-snapshot-v1','audit_id',char(java.util.UUID.randomUUID()), ...
        'started_utc',stamp(),'completed_utc','','complete',false,'budget',budget, ...
        'local_cap_seconds',maxWallSeconds,'use_final_reserve',useFinalReserve, ...
        'selected_deadline_unix_seconds',capUTC,'selected_deadline_monotonic_ns',capMono,'current_classification_contract',contract, ...
        'files',{{}},'components',{{}},'v2_reference',struct(),'source_code',{{}},'failure',struct(), ...
        'new_replays',0,'new_corrections',0,'new_classifications',0,'new_admissions',0, ...
        'scope','Occurrences remain separate by source file and stored component identity; no independent-cycle count, attachment, inheritance or disconnectedness claim.', ...
        'range_scope','Stored native points and literal accepted/all-nine subsets are separate. Canonical qualification is copied from the saved current contract, without a fresh fine replay.', ...
        'energy_scope','Native Energy.evaluate recomputes E and may evaluate the algebraic flow for power diagnostics; no time integration is performed.', ...
        'comparison_scope','Only textual family labels are aligned. Signed direction, recorded return duration, parameters and range overlap may differ without implying topology.', ...
        'publication_scope','Matching audit_id required across MAT/JSON; stored completion precedes final rename/postguard.');
    names={'AuditC1LiveRanges_v3','BranchSolutionFile_v3','QuadrupedEnergy_v3','QuadrupedSchema_v3','GaitSemanticTable_v3','C1RunBudget_v3','RoundSHA256_v3'};
    for k=1:numel(names),audit.source_code{k}=reference(which(names{k}));end
    refs={};
    try
        baseline=fullfile(c1Root,'Audits','P1_v2_Native_Reference_Audit.mat');br=reference(baseline);
        saved=load(baseline,'audit');v2=saved.audit;
        assert(isstruct(v2)&&isscalar(v2)&&isequal(v2.complete,true)&&iscell(v2.branches), ...
            'C1Ranges:Reference','Require the closed complete native scalar P1 reference audit.');
        for k=1:numel(v2.branches)
            b=v2.branches{k};mask=b.energy_available;
            p=b.native_physical_parameter(:,mask);example=[];constant=false;
            if ~isempty(p),example=p(:,1).';constant=all(all(p==p(:,1)));end
            refs{k}=struct('label',b.label,'stored_column_count',numel(b.stored_period), ...
                'energy_available_count',sum(mask),'mechanical_energy',bounds(b.mechanical_energy(mask)), ...
                'signed_initial_dx',bounds(b.stored_initial_dx),'stored_return_period',bounds(b.stored_period), ...
                'parameter_example',example,'parameters_constant',constant, ...
                'original_acceptance_available',b.original_validity_flags_available,'signed_mean_U_available',false);
        end
        audit.v2_reference=struct('source',br,'branches',{refs}, ...
            'signed_mean_U_status','Unavailable: no scheduled v2 integrations are run or inferred.', ...
            'period_scope','Original stored return duration; no primitive-period identification or temporal alias correction.');
        entries=dir(fullfile(c1Root,'Results','*.mat'));[~,order]=sort({entries.name});entries=entries(order);
        selected=entries(arrayfun(@(d)~d.isdir&&(startsWith(d.name,'branch_')||startsWith(d.name,'C1_')) ...
            &&~contains(lower(d.name),'checkpoint')&&~contains(lower(d.name),'index')&&~contains(lower(d.name),'.pending'),entries));
        for f=1:numel(selected)
            guard();file=fullfile(selected(f).folder,selected(f).name);header=whos('-file',file);
            if ~any(strcmp({header.name},'branch_index')),continue;end
            src=reference(file);ix=BranchSolutionFile_v3.index(file);
            one=struct('source',src,'metadata',smallMetadata(ix.metadata),'indexed_point_count',numel(ix.points), ...
                'edges',{ix.edges},'points',{{}},'source_unchanged',false,'failures',{{}});
            for k=1:numel(ix.points)
                guard();
                try
                    point=ix.points{k};loaded=load(file,point.solution_variable,point.report_variable);guard();
                    assert(isfield(loaded,point.solution_variable)&&isfield(loaded,point.report_variable),'C1Ranges:Variables');
                    orbit=loaded.(point.solution_variable);report=loaded.(point.report_variable);p=point.metadata;
                    assert(strcmp(class(orbit),'HybridOrbit_v3')&&isscalar(orbit) ...
                        &&isstruct(report)&&isscalar(report),'C1Ranges:NativeSchema');
                    x=orbit.initial_state(:);q=orbit.initial_mode(:);parameter=orbit.parameter(:);
                    assert(isnumeric(x)&&isreal(x)&&numel(x)==14&&all(isfinite(x)) ...
                        &&isnumeric(parameter)&&isreal(parameter)&&numel(parameter)==10 ...
                        &&(isnumeric(q)||islogical(q))&&isreal(q)&&numel(q)==4&&all(ismember(q,[0,1])),'C1Ranges:Native');
                    g=get(report,'classification',struct());gates=get(report,'acceptance_gates',struct());
                    [present,allNine]=nine(gates);T=orbit.period;stride=orbit.stride_displacement;
                    assert(isnumeric(T)&&isreal(T)&&isscalar(T)&&isfinite(T)&&T>0 ...
                        &&isnumeric(stride)&&isreal(stride)&&~isempty(stride)&&isfinite(stride(1)),'C1Ranges:Period');
                    E=QuadrupedEnergy_v3.evaluate(x,q,parameter);assert(isreal(E)&&isscalar(E)&&isfinite(E),'C1Ranges:Energy');
                    label=get(g,'canonical_point_label','');accepted=get(report,'accepted',[]);
                    row=struct('point_index',k,'order',ix.points{k}.order,'component_identity',p.component_identity, ...
                        'provenance_ID',struct('file',file,'sha256',src.sha256,'solution_variable',ix.points{k}.solution_variable, ...
                        'report_variable',ix.points{k}.report_variable,'metadata_path',sprintf('branch_index.points{%d}.metadata.provenance',k)), ...
                        'metadata_classification',p.classification,'accepted_present',isfield(report,'accepted'), ...
                        'accepted',accepted,'acceptance_gates',gates,'all_nine_present',present,'all_nine_true',allNine, ...
                        'status',get(report,'status',''),'native_status',get(report,'native_status',''), ...
                        'classification_contract',get(g,'contract_version',''), ...
                        'synchrony_predicate_version',get(g,'synchrony_predicate_version',''), ...
                        'canonical_label',label,'validated_gait_type',get(g,'validated_gait_type',''), ...
                        'canonical_label_qualified',get(g,'canonical_label_qualified',[]), ...
                        'flight_count_certain',get(g,'flight_count_certain',[]),'flight_count',get(g,'flight_count',[]), ...
                        'primitive_flight_count',get(g,'primitive_flight_count',[]), ...
                        'classification_period_used',get(g,'period_used',[]),'return_policy_name',orbit.return_policy_name, ...
                        'return_multiplicity',orbit.return_multiplicity,'physical_final_support',get(report,'physical_final_support',[]), ...
                        'canonical_target',get(report,'canonical_target',[]),'initial_state',x.', ...
                        'initial_mode',q.','hind_pair_angle_selector',x(schema.Leg.AngleIndices(1))-x(schema.Leg.AngleIndices(2)), ...
                        'fore_pair_angle_selector',x(schema.Leg.AngleIndices(3))-x(schema.Leg.AngleIndices(4)), ...
                        'E',E,'signed_apex_dx',x(2), ...
                        'signed_mean_U',stride(1)/T,'T',T,'physical_parameter',parameter.', ...
                        'stored_nativeE',p.nativeE,'stored_signedmeanU',p.signedmeanU, ...
                        'literal_accepted_all9',isequal(accepted,true)&&allNine, ...
                        'saved_current_canonical_qualified',strcmp(text(get(g,'contract_version','')),text(contract)) ...
                        &&isequal(get(g,'canonical_label_qualified',false),true));
                    one.points{end+1,1}=row;
                catch problem
                    one.failures{end+1,1}=struct('point_index',k,'failure',exception(problem));
                    guard();
                end
            end
            one.source_unchanged=strcmp(src.sha256,RoundSHA256_v3(file));assert(one.source_unchanged,'C1Ranges:SourceChanged');
            audit.files{end+1,1}=one;
            fprintf('C1 ranges file=%s points=%d/%d failures=%d\n',selected(f).name,numel(one.points),one.indexed_point_count,numel(one.failures));
            ids=unique(cellfun(@(r)r.component_identity,one.points,'UniformOutput',false),'stable');
            for j=1:numel(ids)
                rows=one.points(cellfun(@(r)strcmp(r.component_identity,ids{j}),one.points));
                admitted=rows(cellfun(@(r)r.literal_accepted_all9,rows));
                qualified=admitted(cellfun(@(r)r.saved_current_canonical_qualified,admitted));
                component=struct('source_file',file,'component_identity',ids{j},'stored_occurrences',numel(rows), ...
                    'literal_accepted_all9_occurrences',numel(admitted),'stored_ranges',ranges(rows), ...
                    'literal_accepted_all9_ranges',ranges(admitted),'stored_label_counts',{counts(rows)}, ...
                    'accepted_current_qualified_label_counts',{counts(qualified)},'v2_textual_comparisons',{{}});
                labels=unique(cellfun(@(r)text(r.canonical_label),qualified,'UniformOutput',false),'stable');
                for z=1:numel(labels)
                    token=regexp(labels{z},'^(PK|BG|BE|FG|FE|HG|HE|GG|GE)\d*$','tokens','once');
                    if isempty(token),continue;end
                    hit=find(cellfun(@(r)strcmp(r.label,token{1}),refs));if ~isscalar(hit),continue;end
                    points=qualified(cellfun(@(r)strcmp(text(r.canonical_label),labels{z}),qualified));v=refs{hit};native=ranges(points);
                    sameP=[];if v.parameters_constant,sameP=all(cellfun(@(r)isequaln(r.physical_parameter,v.parameter_example),points));end
                    comparison=struct('native_label',labels{z},'v2_text_label',v.label,'native',native, ...
                        'v2',v,'exact_parameters_match_constant_v2',sameP, ...
                        'E_ranges_overlap',overlap(native.E,v.mechanical_energy), ...
                        'signed_apex_ranges_overlap',overlap(native.signed_apex_dx,v.signed_initial_dx), ...
                        'recorded_T_ranges_overlap',overlap(native.T,v.stored_return_period), ...
                        'recorded_T_ratio_range',ratio(native.T,v.stored_return_period), ...
                        'mean_U_comparison_available',false,'relationship_inferred',false);
                    component.v2_textual_comparisons{end+1,1}=comparison;
                end
                audit.components{end+1,1}=component;
            end
        end
        guard();assert(strcmp(br.sha256,RoundSHA256_v3(baseline)),'C1Ranges:ReferenceChanged');
        for k=1:numel(audit.source_code)
            r=audit.source_code{k};guard();assert(strcmp(r.sha256,RoundSHA256_v3(r.file)),'C1Ranges:CodeChanged');
        end
        audit.complete=~isempty(audit.files)&&all(cellfun(@(r)isempty(r.failures)&&numel(r.points)==r.indexed_point_count,audit.files));guard();
    catch problem,audit.failure=exception(problem);audit.complete=false;end
    audit.counts=struct('indexed_branch_files',numel(audit.files), ...
        'indexed_occurrences',sum(cellfun(@(r)r.indexed_point_count,audit.files)), ...
        'native_occurrences_read',sum(cellfun(@(r)numel(r.points),audit.files)), ...
        'literal_accepted_all9_occurrences',sum(cellfun(@(r)sum(cellfun(@(p)p.literal_accepted_all9,r.points)),audit.files)), ...
        'accepted_current_canonical_qualified_occurrences',sum(cellfun(@(r)sum(cellfun(@(p) ...
        p.literal_accepted_all9&&p.saved_current_canonical_qualified,r.points)),audit.files)));
    audit.completed_utc=stamp();audit.work_timely=utc()<workUTC&&nano()<workMono;audit.complete=audit.complete&&audit.work_timely;
    folder=fullfile(c1Root,'Audits');matFile=fullfile(folder,'Live_Branch_Ranges.mat');jsonFile=fullfile(folder,'Live_Branch_Ranges.json');
    matStage=[tempname(folder),'.mat'];jsonStage=[tempname(folder),'.json'];clean=onCleanup(@()removeStages(matStage,jsonStage));
    finishGuard();save(matStage,'audit','-v7');saved=load(matStage,'audit');assert(isequaln(saved.audit,audit),'C1Ranges:MATReadback');
    encoded=jsonencode(plain(audit));fid=fopen(jsonStage,'w');assert(fid>=0,'C1Ranges:JSON');closer=onCleanup(@()fclose(fid));
    bytes=unicode2native(encoded,'UTF-8');assert(fwrite(fid,bytes,'uint8')==numel(bytes),'C1Ranges:JSON');clear closer
    assert(isequaln(jsondecode(fileread(jsonStage)),jsondecode(encoded)),'C1Ranges:JSONReadback');finishGuard();
    commit(matStage,matFile);finishGuard();commit(jsonStage,jsonFile);finishGuard();clear clean
    function guard(),assert(utc()<workUTC&&nano()<workMono,'C1Ranges:Budget','Original/local dual-clock work budget expired.');end
    function finishGuard(),assert(utc()<stopUTC&&nano()<stopMono,'C1Ranges:PublicationBudget','Publication exceeded original/local deadline; matching files may already exist.');end
end
function out=smallMetadata(value)
    out=struct();for name={'component_key','protocol','component_identity','source_file','source_indices','symmetry'}
        if isfield(value,name{1}),out.(name{1})=value.(name{1});end
    end
end
function [present,yes]=nine(gates)
    names={'full_closure','mode_closure','target_energy','trajectory_energy_variation', ...
        'unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    present=isstruct(gates)&&isscalar(gates)&&all(isfield(gates,names));yes=present;
    if yes,for k=1:numel(names),yes=yes&&isequal(gates.(names{k}),true);end,end
end
function out=ranges(rows)
    out=struct('E',[],'signed_apex_dx',[],'signed_mean_U',[],'T',[]);
    keys=fieldnames(out);for k=1:numel(keys),out.(keys{k})=bounds(cellfun(@(r)r.(keys{k}),rows));end
end
function out=counts(rows)
    out={};labels=cellfun(@(r)text(r.canonical_label),rows,'UniformOutput',false);u=unique(labels,'stable');
    for k=1:numel(u),out{end+1,1}=struct('literal_label',u{k},'occurrences',sum(strcmp(labels,u{k})));end
end
function out=bounds(values),values=values(isfinite(values));if isempty(values),out=[];else,out=[min(values),max(values)];end,end
function out=overlap(a,b),out=[];if numel(a)==2&&numel(b)==2,out=max(a(1),b(1))<=min(a(2),b(2));end,end
function out=ratio(a,b),out=[];if numel(a)==2&&numel(b)==2&&b(1)>0,out=[a(1)/b(2),a(2)/b(1)];end,end
function out=text(v),out='';if (ischar(v)&&isrow(v))||(isstring(v)&&isscalar(v)),out=char(v);end,end
function out=get(s,key,fallback),out=fallback;if isstruct(s)&&isscalar(s)&&isfield(s,key),out=s.(key);end,end
function out=reference(file),d=dir(file);assert(isscalar(d)&&~d.isdir,'C1Ranges:Missing');out=struct('file',file,'sha256',RoundSHA256_v3(file),'bytes',d.bytes);end
function out=exception(e),out=struct('identifier',e.identifier,'message',e.message);end
function out=plain(out)
    if isstruct(out)
        keys=fieldnames(out);for i=1:numel(out),for k=1:numel(keys),out(i).(keys{k})=plain(out(i).(keys{k}));end,end
    elseif iscell(out),for i=1:numel(out),out{i}=plain(out{i});end
    elseif isnumeric(out)&&(~isreal(out)||any(~isfinite(out(:))))
        if ~isreal(out),out=struct('real',plain(real(out)),'imaginary',plain(imag(out)));return;end
        cells=cell(size(out));for i=1:numel(out),cells{i}=sprintf('%.17g',out(i));end;out=cells;
    else,assert(isnumeric(out)||islogical(out)||ischar(out)||isstring(out),'C1Ranges:JSONClass');end
end
function commit(stage,file)
    opts=javaArray('java.nio.file.CopyOption',2);
    opts(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');
    opts(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');
    javaMethod('move','java.nio.file.Files',java.io.File(stage).toPath(),java.io.File(file).toPath(),opts);
end
function removeStages(a,b),if isfile(a),delete(a);end;if isfile(b),delete(b);end,end
function out=utc(),out=posixtime(datetime('now','TimeZone','UTC'));end
function out=nano(),out=double(java.lang.System.nanoTime);end
function out=stamp(),out=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end
