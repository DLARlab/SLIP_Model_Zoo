function audit=ExportC1EssentialCompleteStoresFinal03_20261030(workerClosure,options)
%MEASUREC1ESSENTIALCOMPLETESTORES20261030 Two complete saved-store measurements.
% STORAGE ONLY: original final cutoff, no numerical budget renewal.
% BE0092 N2 and the complete merged PK store are separate snapshot exports. No
% root/map/classifier/replay/admission or live replacement is performed.
% Original runtime objects exist in one local block32 workspace at a time.
    entered=pairClock();
    o=struct('JournalReference',struct(),'MergedComponentReference',struct(), ...
        'ReferenceAuditReference',struct(),'WireQualificationReference',struct(), ...
        'KernelReference',struct(),'DigestReference',struct(),'ClosedWorkerSourceReference',struct(), ...
        'ProtectedReferences',{{}},'CoreReferences',{{}},'ResultsReferences',{{}},'SourceReferences',{{}}, ...
        'CompleteCases',{cell(0,1)},'OutputPrefix','','MaxWallSeconds',1800, ...
        'OperationalMaximumBytes',NaN,'SourceClosedBoundaryReference',struct());
    assert(isstruct(options)&&isscalar(options)&&all(ismember(fieldnames(options),fieldnames(o))), ...
        'C1EssentialComplete:Options','Use only the explicit complete-store measurement inputs.');
    for key=fieldnames(options).',o.(key{1})=options.(key{1});end
    validateattributes(o.MaxWallSeconds,{'double'},{'real','scalar','finite','>=',300,'<=',1800});
    validateattributes(o.OperationalMaximumBytes,{'double'},{'real','scalar','finite','integer','positive','<=',flintmax});
    for key={'JournalReference','MergedComponentReference','ReferenceAuditReference','WireQualificationReference','KernelReference','DigestReference','ClosedWorkerSourceReference','SourceClosedBoundaryReference'},o.(key{1})=checked(o.(key{1}));end
    closed(workerClosure,o.ClosedWorkerSourceReference);
    assert(numel(o.CoreReferences)==44&&iscell(o.CompleteCases)&&isequal(size(o.CompleteCases),[2,1]), ...
        'C1EssentialComplete:Bound','Measure exactly the two declared complete stores and retain all44 current core references.');
    assert(strcmp(o.KernelReference.sha256,'60a9ff5336ac094be2254d863511139c3488f32fc39b17837b18935d851fd792') ...
        &&strcmp(o.DigestReference.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'), ...
        'C1EssentialComplete:Implementations','Use the reviewed direct-projection writer and exact scientific digest.');
    assert(strcmp(canonical(which('EssentialBranchSolutionFile_v3')),o.KernelReference.file)&&strcmp(canonical(which('C1ScientificDigest_v3')),o.DigestReference.file), ...
        'C1EssentialComplete:Resolvers','The explicit private implementations must resolve exactly.');
    root=canonical(fileparts(which('C1RunBudget_v3')));budget=C1RunBudget_v3();fence=finalStorageLimit(budget);
    finish=minLimit(shift(entered,o.MaxWallSeconds),fence);work=shift(finish,-120);
    assert(left(fence)>o.MaxWallSeconds+2,'C1EssentialComplete:Fit','Keep the full storage allowance before the ORIGINAL final cutoff; no Root or scientific service is authorized.');
    lease=acquireWriterLock([o.JournalReference.file,'.writer.lock']); %#ok<NASGU>
    branchSource=reference(which('BranchSolutionFile_v3'));assert(strcmp(branchSource.sha256,'ee7336bee19d5fca4bd5be62b6bab22e428d14fdfe37e801c7b040610aa8bccc'), ...
        'C1EssentialComplete:SourceReader','Use the exact schema2 public reader whose selected-variable/validation semantics are copied here.');
    code=[o.SourceReferences(:);{branchSource;o.KernelReference;o.DigestReference;reference([mfilename('fullpath'),'.m'])}];verifyCode(code);
    refs=[o.ProtectedReferences(:);o.CoreReferences(:);o.ResultsReferences(:);{o.JournalReference;o.MergedComponentReference;o.ReferenceAuditReference;o.WireQualificationReference;o.SourceClosedBoundaryReference}];
    boundaryOne=jsondecode(fileread(o.SourceClosedBoundaryReference.file));boundaryTwo=jsondecode(fileread(o.SourceClosedBoundaryReference.file));rawEqual3(boundaryOne,boundaryTwo,boundaryTwo,'actual source custody summary read2');
    assert(isstruct(boundaryOne)&&isscalar(boundaryOne)&&all(isfield(boundaryOne,{'current_journal','current_component','tool_records','child','postguard_refs'})) ...
        &&strcmp(canonical(boundaryOne.current_journal.file),o.JournalReference.file)&&strcmp(boundaryOne.current_journal.sha256,o.JournalReference.sha256) ...
        &&strcmp(canonical(boundaryOne.current_component.file),o.MergedComponentReference.file)&&strcmp(boundaryOne.current_component.sha256,o.MergedComponentReference.sha256) ...
        &&isequal(boundaryOne.child.child_exit_code,0)&&boundaryOne.postguard_refs>=1, ...
        'C1Export:SourceBoundary','Use the actual closed-source custody summary bound to this current journal/component, not an opaque unrelated receipt.');
    toolWitness=checked(boundaryOne.tool_records);toolOne=jsondecode(fileread(toolWitness.file));toolTwo=jsondecode(fileread(toolWitness.file));rawEqual3(toolOne,toolTwo,toolTwo,'actual source PTY witness read2');
    assert(isstruct(toolOne)&&isscalar(toolOne)&&all(isfield(toolOne,{'session_id','records'}))&&toolOne.session_id==workerClosure.process_session_id&&~isempty(toolOne.records), ...
        'C1Export:SourceBoundary','Actual source tool witness must bind the declared prior process.');
    if iscell(toolOne.records),lastTool=toolOne.records{end};else,lastTool=toolOne.records(end);end
    assert(isfield(lastTool,'exit_code')&&isequal(lastTool.exit_code,0),'C1Export:SourceBoundary','The actual prior source PTY exit must be zero.');
    refs=[refs;{toolWitness}];clear boundaryTwo toolOne toolTwo lastTool
    for k=1:2,validateCompleteCase(o.CompleteCases{k});refs=[refs;{o.CompleteCases{k}.SourceReference;o.CompleteCases{k}.V2Reference}];end %#ok<AGROW>
    first=o.CompleteCases{1};[~,leaf,ext]=fileparts(first.SourceReference.file);
    assert(strcmp(leaf,'C1_BE_Component_0092')&&strcmp(ext,'.mat')&&strcmp(first.FamilyLabel,'BE')&&first.ExpectedPointCount==2 ...
        &&strcmp(o.CompleteCases{2}.FamilyLabel,'PK')&&strcmp(canonical(o.CompleteCases{2}.SourceReference.file),o.MergedComponentReference.file), ...
        'C1EssentialComplete:Cases','The only cases are complete BE0092 N2 followed by the actual complete current merged PK store.');
    verify(refs);roster=sort(cellfun(@(r)canonical(r.file),o.ResultsReferences(:),'UniformOutput',false));
    corePaths=sort(cellfun(@(r)canonical(r.file),o.CoreReferences(:),'UniformOutput',false));
    assert(all(cellfun(@(s)ismember(canonical(s.SourceReference.file),corePaths),o.CompleteCases)), ...
        'C1EssentialComplete:CoreCase','Both complete cases must be members of the guarded current44 stores.');
    prefix=canonical(o.OutputPrefix);workspace=fileparts([mfilename('fullpath'),'.m']);assert(strcmp(fileparts(prefix),workspace), ...
        'C1EssentialComplete:Output','Publish only fresh private measurement derivatives in this workspace.');
    output=[prefix,'.audit.mat'];json=[prefix,'.audit.json'];returnFile=[prefix,'.returns.mat'];fresh({output,json,[output,'.pending.mat'],[json,'.pending.json'],returnFile,[returnFile,'.pending.mat']});
    cp=fullfile(root,'Audits','PK_Persistent_Frontiers_20261026_active_checkpoint.mat');isolated=fullfile(root,'Results',['C1_Isolated_Native_Admissions',budget.result_suffix,'.mat']);
    absent={cp,[cp,'.pending.mat'],[o.JournalReference.file,'.pending.mat']};fresh(absent);
    isolationBefore=struct('present',isfile(isolated),'reference',struct());if isolationBefore.present,isolationBefore.reference=reference(isolated);end
    audit=struct('schema','C1-essential-additive-complete-store-export-v1','worker_closure',workerClosure,'options',o, ...
        'budget',budget,'storage_final_deadline',fence,'clock_scope','STORAGE ONLY: local<=1800 with120s save reserve, clipped to ORIGINAL final UTC/JVM cutoff; no renewed science.','source_code',{code},'inputs',{refs},'started_utc',stamp(),'finished_utc','', ...
        'no_map_root_classifier_fine_replay_or_new_admission',true,'whole_old_runtime_equality_claimed',false,'whole_original_method_settings_equality_claimed',false, ...
        'runtime_descriptor_scope','For exact observed saved PK rows289:294 only: preserve original runtime descriptors in each case audit; retain callback name without closure, omit ONLY the Jacobian leaf whose settings were never saved. Producer provenance is unknown. Canonical/read2 equality concerns the normalized retained scientific projection, not unavailable runtime method settings.', ...
        'core_publication_performed',false,'production_storage_epoch_adopted',false,'full_branch_completion_claimed',false, ...
        'export_manifest_scope','Native rows are a draft only. First may finalize one administrative JSON manifest AFTER actual exporter exit0 and all native/opaque custody guards. No self-exit claim or future-hash cycle.','raw_source_block_size',32,'raw_block_reads_sequential',true, ...
        'source_read_scope','Two actual public index validations per store, then independent native SELECTED-VARIABLE block32 loads against those pinned locators with the exact schema2 value validator; these are not repeated public loadSolutions calls.', ...
        'fine_projection_scope','Each historical fine preserves its side/order and actual fields only; primitive is the deterministic2-element cell {literalstatus;literalcover_count}. Missing all-nine/currentPK/tolerance fields remain absent.', ...
        'role_projection_scope','Literal accepted/status/exactnine only, with recognized immediate source control/isolation/rejection disposition; otherwise historical-unknown. Accepted never creates an edge.', ...
        'cases',{cell(0,1)},'export_rows_draft',{cell(0,1)},'digest_fixtures',struct(),'native_returns_reference',struct(), ...
        'both_declared_fullstore_cases_allowed_after_size_refusal',true,'complete',false,'source_posthash',false,'no_live_source_or_core_mutation',false,'failure',struct());
    products=cell(0,1);observations=cell(0,1);returnRef=struct();publish(output,json,audit,finish);
    try
        guard();q1=load(o.WireQualificationReference.file,'audit');q2=load(o.WireQualificationReference.file,'audit');rawEqual3(q1.audit,q2.audit,q2.audit,'closed wire qualification read2');validateWireQualification(q1.audit);clear q1 q2
        p1=load(o.ReferenceAuditReference.file,'audit');p2=load(o.ReferenceAuditReference.file,'audit');rawEqual3(p1.audit,p2.audit,p2.audit,'P1 reference audit read2');referenceAudit=p1.audit;clear p1 p2
        assert(strcmp(referenceAudit.schema,'C1-original-P1-v2-native-reference-audit-v1')&&referenceAudit.complete&&referenceAudit.source_files_posthash, ...
            'C1EssentialComplete:P1Authority','Use the complete pinned P1 family/source/column authority.');
        for caseNumber=1:2
            guard();spec=o.CompleteCases{caseNumber};source=ref2(spec.SourceReference);verify({source});sourceStat=dir(source.file);assert(isscalar(sourceStat)&&~sourceStat.isdir,'C1EssentialComplete:SourceStat','Pin one actual source file.');
            ix=BranchSolutionFile_v3.index(source.file);otherIndex=BranchSolutionFile_v3.index(source.file);rawEqual3(ix,otherIndex,otherIndex,'two complete public source indices');clear otherIndex;sourceUnchanged(source,sourceStat);N=numel(ix.points);
            assert(strcmp(ix.storage_version,'BranchSolutionFile_v3:2')&&N==spec.ExpectedPointCount&&numel(spec.V2Columns)==N, ...
                'C1EssentialComplete:WholeCount','Use every actual source occurrence1:N, with exactly the declared same-N benchmark columns.');
            bindBenchmark(referenceAudit,spec);tag=sprintf('%s.case%02d.N%d',prefix,caseNumber,N);baseline=[tag,'.v2.mat'];packed=[tag,'.essential.mat'];fresh({baseline,packed});
            [points,contexts,physical]=wholePoints(ix,source);expected=cell(N,1);digests=cell(N,1);roles=cell(N,1);
            row=struct('case_number',caseNumber,'family_label',spec.FamilyLabel,'source_reference',source,'source_point_count',N, ...
                'source_indices',(1:N).','source_metadata',struct('bytes',sourceStat.bytes,'datenum',sourceStat.datenum),'source_index_digest',C1ScientificDigest_v3(ix), ...
                'V2_reference',ref2(spec.V2Reference),'V2_columns',spec.V2Columns,'whole_store',true, ...
                'source_read2_projection_verified',false,'runtime_descriptor_dispositions',{cell(0,1)}, ...
                'callback_descriptor_conversion_count',0,'unavailable_jacobian_omission_count',0,'runtime_descriptor_dispositions_read2_verified',false,'record_digests',{cell(N,1)},'role_counts',struct(),'typed_graph_counts',struct(),'typed_graph_digest','', ...
                'baseline_reference',struct(),'baseline_availability','not_created','matched_V2_bytes',NaN,'maximum_bytes',NaN, ...
                'kernel_call_prepared',false,'kernel_call_returned',false,'kernel_return_timely',false,'kernel_exception',struct(), ...
                'candidate_reference',struct(),'candidate_availability','not_created','candidate_is_unpublished_stage',false, ...
                'actual_bytes',NaN,'bytes_per_point',NaN,'size_gate_passed',false,'correctness_read2_passed',false, ...
                'size_gate_scope','Unchanged same-N density diagnostic; not a continuation or export-admission gate.', ...
                'operational_maximum_bytes',o.OperationalMaximumBytes,'original_v2_reference',ref2(spec.V2Reference), ...
                'original_v2_bytes',NaN,'original_v2_point_count',NaN,'final_target_bytes',NaN,'final_target_passed',false, ...
                'final_target_scope','Observational final5x ORIGINAL v2 family file target, separate from finite operational writer bound.', ...
                'snapshot_utc',stamp(),'source_closed_boundary_reference',o.SourceClosedBoundaryReference, ...
                'whole_graph_owner_identity_verified',false,'duplicate_handle_sharing_verified',false,'statistics',struct(), ...
                'cleanup',{cell(0,1)},'completed',false);
            audit.cases{end+1,1}=row;publish(output,json,audit,finish);
            for lo=1:32:N
                guard();indices=(lo:min(N,lo+31)).';
                [one,oneRuntime]=sourceProjectionBlock(source,sourceStat,indices,points,contexts,ix); % Function workspace releases ALL original raw objects.
                [two,twoRuntime]=sourceProjectionBlock(source,sourceStat,indices,points,contexts,ix); % Independent native selected-variable load, not a public index rewalk.
                rawEqual3(oneRuntime,twoRuntime,twoRuntime,'independent exact saved-runtime dispositions');
                row.runtime_descriptor_dispositions=mergeRuntimeDispositions(row.runtime_descriptor_dispositions,oneRuntime);
                for j=1:numel(indices)
                    k=indices(j);rawEqual3(one{j},two{j},two{j},sprintf('independent source projection%d',k));expected{k}=one{j};digests{k}=C1ScientificDigest_v3(one{j});roles{k}=one{j}.context.role;
                end
                clear one two oneRuntime twoRuntime;verify({source});check(work);
            end
            [row.callback_descriptor_conversion_count,row.unavailable_jacobian_omission_count]=validateRuntimeDispositions(row.runtime_descriptor_dispositions,source,N);
            row.runtime_descriptor_dispositions_read2_verified=true;
            [branch,graphCounts]=wholeGraph(ix,source,expected,physical,code,spec.FamilyLabel);clear physical
            row.record_digests=digests;row.role_counts=countRoles(roles);row.typed_graph_counts=graphCounts;row.typed_graph_digest=C1ScientificDigest_v3(branch);row.source_read2_projection_verified=true;
            originalV2=load(spec.V2Reference.file,spec.V2Variable);otherV2=load(spec.V2Reference.file,spec.V2Variable);originalV2=originalV2.(spec.V2Variable);otherV2=otherV2.(spec.V2Variable);
            assert(isa(originalV2,'double')&&isreal(originalV2)&&ismatrix(originalV2)&&size(originalV2,1)==29&&all(spec.V2Columns<=size(originalV2,2)), ...
                'C1EssentialComplete:V2Schema','Use exact actual real-double29-row V2 columns, without padding or extrapolation.');
            row.original_v2_point_count=size(originalV2,2);originalInfo=dir(spec.V2Reference.file);assert(isscalar(originalInfo)&&~originalInfo.isdir,'C1Export:OriginalFile','Use the literal original V2 branch file bytes.');row.original_v2_bytes=originalInfo.bytes;row.final_target_bytes=5*originalInfo.bytes;
            results=originalV2(:,spec.V2Columns);rawEqual3(results,otherV2(:,spec.V2Columns),otherV2(:,spec.V2Columns),'literal matchedN V2 source');clear originalV2 otherV2
            save(baseline,'results','-v7');a=load(baseline,'results');b=load(baseline,'results');rawEqual3(results,a.results,b.results,'actual matchedN V2 derivative read2');clear results a b
            d=dir(baseline);row.matched_V2_bytes=d.bytes;row.maximum_bytes=5*d.bytes;row.baseline_reference=reference(baseline);row.baseline_availability='current_verified_private_derivative';products{end+1,1}=row.baseline_reference;
            row.kernel_call_prepared=true;audit.cases{end}=row;publish(output,json,audit,finish);guard();
            assert(left(work)>180,'C1EssentialComplete:ClosestFit','Keep120s operational kernel allowance plus60s post-observation allowance after durable intent; blocking IO is not preempted.');
            stagesBefore=stageNames(workspace);returned=[];callClock=tic;
            try,returned=EssentialBranchSolutionFile_v3.writeProjections(packed,branch,expected,row.operational_maximum_bytes);row.kernel_call_returned=true;
            catch problem,row.kernel_exception=exceptionData(problem);end
            row.kernel_return_timely=left(work)>0;audit.cases{end}=row;
            observation=struct('case_number',caseNumber,'point_count',N,'observed_utc',stamp(),'seconds',toc(callClock), ...
                'returned',row.kernel_call_returned,'return_timely',row.kernel_return_timely,'exception',row.kernel_exception, ...
                'return_projection',returnSummary(returned),'full_return_payload_retained',false, ...
                'scope','Actual storage-call disposition and a digest/count projection of its plain public index; canonical derivative/source authorities remain separate. No numerical return is generated.');
            observations{end+1,1}=observation;if ~isempty(fieldnames(returnRef)),verify({returnRef});end
            saveReturns(returnFile,observations);returnRef=reference(returnFile);audit.native_returns_reference=returnRef;clear returned observation
            guard();assert(row.kernel_return_timely,'C1EssentialComplete:LateKernel','Retain the actual return/exception and generated product; no subsequent case follows a late kernel.');
            added=setdiff(stageNames(workspace),stagesBefore);
            if row.kernel_call_returned&&isempty(fieldnames(row.kernel_exception))
                assert(isfile(packed)&&isempty(added),'C1EssentialComplete:Product','A normal returned write must leave only its exact fresh published private product.');candidate=packed;
            elseif ~row.kernel_call_returned&&~isfile(packed)&&isfield(row.kernel_exception,'identifier')&&strcmp(row.kernel_exception.identifier,'EssentialBranch:ByteLimit')
                assert(numel(added)==1,'C1EssentialComplete:Stage','Only the sole complete new stage belongs to this prepared ByteLimit call; retain all uncertainty.');candidate=added{1};row.candidate_is_unpublished_stage=true;
            else,error('C1EssentialComplete:KernelRefusal','Preserve every non-ByteLimit exception/product and stop without another call.');end
            row.candidate_reference=reference(candidate);row.candidate_availability='current_verified_private_derivative';products{end+1,1}=row.candidate_reference;d=dir(candidate);row.actual_bytes=d.bytes;row.bytes_per_point=d.bytes/N;row.size_gate_passed=d.bytes<=row.maximum_bytes;row.final_target_passed=d.bytes<=row.final_target_bytes;audit.cases{end}=row;
            verifyCandidatePass(candidate,expected);verifyCandidatePass(candidate,expected); % Sequential full public thin read2, not O(N^2) selected reads.
            px=EssentialBranchSolutionFile_v3.index(candidate);rawEqual3(branch,px.metadata,px.metadata,'complete typed essential graph');rawEqual3(ix.edges,px.edges,px.edges,'all actual physical source edges');
            for k=1:N
                assert(isequaln(px.points{k}.component_identity,points{k}.component_identity)&&isequaln(px.points{k}.order,points{k}.order) ...
                    &&isequal(px.points{k}.native_id,expected{k}.native_id)&&strcmp(px.points{k}.occurrence_id,expected{k}.context.occurrence_id), ...
                    'C1EssentialComplete:PointBinding','Every literal owner/order/NativeID/occurrence must survive complete-store storage.');
            end
            a=EssentialBranchSolutionFile_v3.loadSolutions(candidate,[N;1;N]);b=EssentialBranchSolutionFile_v3.loadSolutions(candidate,N);
            assert(a{1}==a{3}&&a{1}~=b{1},'C1EssentialComplete:Handles','Duplicate positions share handles within a call; separate calls remain independent.');clear a b px
            row.duplicate_handle_sharing_verified=true;row.correctness_read2_passed=true;row.whole_graph_owner_identity_verified=true;row.statistics=EssentialBranchSolutionFile_v3.storageStatistics(candidate);row.completed=true;
            if row.kernel_call_returned,row.candidate_availability='retained_verified_additive_export_snapshot';end
            audit.cases{end}=row;
            boundary=struct('schema','C1-closed-native-source-boundary-v1','process_session_id',workerClosure.process_session_id, ...
                'exit_code',workerClosure.exit_code,'actual_process_exit_observed',workerClosure.actual_process_exit_observed, ...
                'custody_complete',workerClosure.custody_complete,'closure_reference',o.SourceClosedBoundaryReference, ...
                'source_reference',source,'source_point_count',N, ...
                'scope','Prior actual closed public worker plus this independent current source byte/index read2; no new admission or completed-branch claim.');
            sizeObservation=struct('operational_maximum_bytes',row.operational_maximum_bytes,'actual_export_bytes',row.actual_bytes, ...
                'original_v2_reference',row.original_v2_reference,'original_v2_bytes',row.original_v2_bytes, ...
                'original_v2_point_count',row.original_v2_point_count,'final_target_bytes',row.final_target_bytes, ...
                'final_target_passed',row.final_target_passed, ...
                'matched_N_diagnostics',struct('actual_point_count',N,'matched_v2_bytes',row.matched_V2_bytes,'maximum_bytes',row.maximum_bytes,'passed',row.size_gate_passed));
            audit.export_rows_draft{end+1,1}=struct('export_reference',row.candidate_reference,'source_reference',source, ...
                'source_point_count',N,'source_physical_edge_count',numel(ix.edges),'snapshot_utc',row.snapshot_utc, ...
                'source_closed_boundary',boundary,'full_branch_completion_claimed',false, ...
                'canonical_projection_read2_verified',true,'ids_owner_graph_verified',true, ...
                'published_additive_export',row.kernel_call_returned,'candidate_is_unpublished_stage',row.candidate_is_unpublished_stage, ...
                'size_observation',sizeObservation);
            verify({source});verify(products);verify({returnRef});publish(output,json,audit,finish);guard();
            fprintf('C1_ESSENTIAL_EXPORT case=%d family=%s N=%d actual=%d operationalLimit=%d originalV2bytes=%d finalTarget=%d targetPass=%d matchedNPass=%d correct2=%d published=%d\n',caseNumber,spec.FamilyLabel,N,row.actual_bytes,row.operational_maximum_bytes,row.original_v2_bytes,row.final_target_bytes,row.final_target_passed,row.size_gate_passed,row.correctness_read2_passed,row.kernel_call_returned);check(finish);
            % The complete proof is installed/read2 before exact derivative retirement.
            toRetire={row.baseline_reference}; % Actual additive exports/stages remain; only the transient measured V2 slice retires.
            for rno=1:numel(toRetire)
                r=toRetire{rno};row.cleanup{end+1,1}=struct('reference',r,'unlink_prepared',true,'unlink_returned',false,'absent_observed',false);audit.cases{end}=row;publish(output,json,audit,finish);guard();
                verifyPrivateRetirement(r,workspace);delete(r.file);row.cleanup{end}.unlink_returned=true;audit.cases{end}=row;
                assert(~isfile(r.file),'C1EssentialComplete:Cleanup','The exact verified derivative is present after unlink returned; preserve that actual return and stop.');row.cleanup{end}.absent_observed=true;
                products=products(~cellfun(@(p)strcmp(p.file,r.file),products));
                if strcmp(r.file,row.baseline_reference.file),row.baseline_availability='retired_after_verified_measurement';else,row.candidate_availability='retired_after_verified_measurement';end
                audit.cases{end}=row;publish(output,json,audit,finish);
            end
            clear expected digests roles branch points contexts ix candidate row;guard();
        end
        verify(refs);verify(products);verify({returnRef});guard();audit.complete=true;audit.source_posthash=true;audit.no_live_source_or_core_mutation=true;audit.finished_utc=stamp();publish(output,json,audit,finish);guard();
        fprintf('C1_ESSENTIAL_EXPORT_RETURN cases=%d complete=%d noCoreMutation=%d\n',numel(audit.cases),audit.complete,audit.no_live_source_or_core_mutation);check(finish);
    catch problem
        audit.complete=false;audit.source_posthash=false;audit.no_live_source_or_core_mutation=false;audit.failure=exceptionData(problem);audit.finished_utc=stamp();
        try,publish(output,json,audit,finish);catch custody,warning('C1EssentialComplete:Custody','Preserve all actual products and uncertain stages; publication refused: %s',custody.message);end
        rethrow(problem)
    end
    function guard()
        check(work);fresh(absent);verifyCode(code);assert(isfile(isolated)==isolationBefore.present,'C1EssentialComplete:Isolation','Read-only measurement cannot change shared isolation presence.');
        if isolationBefore.present,verify({isolationBefore.reference});end
        assert(isequaln(C1RunBudget_v3(),budget),'C1EssentialComplete:Budget','Keep the same original native budget object.');
        assert(isequal(coreRoster(root,o.MergedComponentReference.file),corePaths)&&isequal(resultsRoster(root),roster), ...
            'C1EssentialComplete:Roster','Keep the complete current44/Results roster and all pending boundaries exact.');
    end
end

function validateCompleteCase(s)
    names={'SourceReference','ExpectedPointCount','FamilyLabel','V2Reference','V2Variable','V2Columns'};exactFields(s,names,'complete case');checked(s.SourceReference);checked(s.V2Reference);
    validateattributes(s.ExpectedPointCount,{'double'},{'real','scalar','finite','integer','positive'});
    assert(any(strcmp(s.FamilyLabel,{'BE','PK'}))&&strcmp(s.V2Variable,'results'),'C1EssentialComplete:Family','Use the two declared actual P1 families/results variables only.');
    assert(isnumeric(s.V2Columns)&&isreal(s.V2Columns)&&iscolumn(s.V2Columns)&&numel(s.V2Columns)==s.ExpectedPointCount ...
        &&all(isfinite(s.V2Columns))&&all(s.V2Columns>=1&s.V2Columns==fix(s.V2Columns))&&numel(unique(s.V2Columns))==numel(s.V2Columns), ...
        'C1EssentialComplete:V2Columns','Same-N uses exactly N unique literal source columns; no padding, repetition or extrapolation.');
end

function validateWireQualification(q)
    assert(isstruct(q)&&isscalar(q)&&strcmp(q.schema,'C1-essential-native-wire-codec-fixture-v1')&&isequal(q.complete,true)&&isequal(q.source_posthash,true) ...
        &&isequal(q.no_map_root_classification_replay_or_admission,true)&&isempty(fieldnames(q.failure))&&q.synthetic_fixture.public_read2_passed ...
        &&numel(q.fixture_cases)==17&&numel(q.negative_wire_cases)==23&&numel(q.inputs)==2 ...
        &&strcmp(q.inputs{1}.sha256,'021b1d6a5a9c7d8901de6301cd64368c0c9d122409d89ab5d97567cc5bc7562e') ...
        &&strcmp(q.inputs{2}.sha256,'0027b47e8537641c799882575f497b80547fa55890abe6931da0296a58ec80b3'), ...
        'C1EssentialComplete:WireQualification','A closed actual17-positive/23-negative reviewed97 wire fixture is required; no production size result is inferred.');
    for k=1:numel(q.fixture_cases),assert(isequal(q.fixture_cases{k}.independent_public_read2_passed,true),'C1EssentialComplete:WireQualification','Every actual positive codec case must pass.');end
    for k=1:numel(q.negative_wire_cases),r=q.negative_wire_cases{k};assert(isequal(r.refused,true)&&strcmp(r.actual_identifier,r.expected_identifier),'C1EssentialComplete:WireQualification','Every actual malformed wire must refuse with its declared identifier.');end
end

function bindBenchmark(a,s)
    match=find(cellfun(@(r)strcmp(r.label,s.FamilyLabel),a.branches));assert(isscalar(match),'C1EssentialComplete:BenchmarkFamily','One actual pinned P1 family row must match.');r=a.branches{match};
    assert(strcmp(canonical(r.source.file),canonical(s.V2Reference.file))&&strcmp(r.source.sha256,s.V2Reference.sha256)&&strcmp(r.source_variable,s.V2Variable)&&all(ismember(s.V2Columns,r.columns)), ...
        'C1EssentialComplete:BenchmarkBinding','File/variable/all unique columns must match the literal family recorded in the native P1 authority.');
end

function [points,contexts,physical]=wholePoints(ix,source)
    N=numel(ix.points);points=cell(N,1);contexts=points;physical=cell(numel(ix.edges),1);
    for k=1:N
        p=ix.points{k};m=struct('component_identity',p.component_identity,'order',p.order);
        for key={'classification','nativeE','signedmeanU'},if isfield(p,key{1}),m.(key{1})=p.(key{1});end,end
        m.edge_enabled=false;m.edge_from=[];points{k}=m;
        contexts{k}=struct('role','historical-unknown','occurrence_id',sprintf('source-sha256:%s:index:%d',source.sha256,k), ...
            'source_reference',source,'source_index',k,'expected_index',k);
    end
    for j=1:numel(ix.edges)
        e=ix.edges{j};a=e.from;b=e.to;assert(a>=1&&b<=N&&a<b&&strcmp(ix.points{a}.component_identity,ix.points{b}.component_identity)&&strcmp(e.component_identity,ix.points{b}.component_identity), ...
            'C1EssentialComplete:PhysicalEdge','Use only actual ordered same-owner public physical edges.');
        assert(~points{b}.edge_enabled,'C1EssentialComplete:Incoming','Every occurrence has at most one actual physical predecessor.');
        p=struct('kind','historical_physical_edge','source_reference',source,'source_from',a,'source_to',b, ...
            'receipt_reference',source,'receipt_availability','historical_locator');
        points{b}.edge_enabled=true;points{b}.edge_from=a;contexts{b}.physical_edge_provenance=p;
        physical{j}=struct('from',a,'to',b,'component_identity',e.component_identity,'provenance',p);
    end
end

function [records,runtimeEvidence]=sourceProjectionBlock(source,sourceStat,indices,points,contexts,ix)
    % No raw object/report escapes this separate function workspace.
    sourceUnchanged(source,sourceStat);variables=cell(2*numel(indices),1);
    for j=1:numel(indices),p=ix.points{indices(j)};variables{2*j-1}=p.solution_variable;variables{2*j}=p.report_variable;end
    saved=load(source.file,variables{:});records=cell(numel(indices),1);runtimeEvidence=cell(0,1);
    for j=1:numel(indices)
        k=indices(j);p=ix.points{k};orbit=saved.(p.solution_variable);report=saved.(p.report_variable);metadata=p.metadata;
        assert(strcmp(class(orbit),'HybridOrbit_v3')&&isscalar(orbit),'C1EssentialComplete:SourceOrbit','Each selected source solution must be one exact native HybridOrbit_v3.');
        sourceValidateValue(orbit,true,0);sourceValidateValue(report,false,0);
        context=contexts{k};context.role=sourceRole(report,metadata);
        if any(strcmp(context.role,{'nonedge-control','isolated','rejected'})),assert(~points{k}.edge_enabled,'C1EssentialComplete:RoleEdge','An explicit NONEDGE/control/isolation/rejection disposition contradicts an incoming physical edge.');end
        [report,localRuntime]=observedRuntimeDisposition(report,source,k);runtimeEvidence=[runtimeEvidence;localRuntime]; %#ok<AGROW>
        records{j}=EssentialBranchSolutionFile_v3.project(orbit,report,points{k},context);
    end
    sourceUnchanged(source,sourceStat);
end

function [report,evidence]=observedRuntimeDisposition(report,source,index)
    % Pure copied-report adaptation, applied independently after EACH native load.
    % The raw source is immutable; no callback/object is reconstructed or invoked.
    evidence=cell(0,1);
    if ~strcmp(source.sha256,'352a07916704238c4cace61ba0950e7b671aaf7ef51234731288c7294f43ef5f')||~ismember(index,(289:294).'),return;end
    if index==289,outputSignature='@(~,~,~)budgetOutput(trial.limit)';else,outputSignature='@(~,~,~)budgetOutput(limit)';end
    for envelope={'integration','replay_integration'}
        name=envelope{1};in=report.(name);solver=in.ODESolver;callback=in.ODEOptions.OutputFcn;
        exactFields(solver,{'runtime_class','reconstruction_required','signature'},'observed saved ODE descriptor');
        exactFields(callback,{'runtime_class','reconstruction_required','signature'},'observed saved output descriptor');
        assert(strcmp(solver.runtime_class,'function_handle')&&isequal(solver.reconstruction_required,true)&&strcmp(solver.signature,'ode45') ...
            &&strcmp(callback.runtime_class,'function_handle')&&isequal(callback.reconstruction_required,true)&&strcmp(callback.signature,outputSignature), ...
            'C1EssentialComplete:ObservedCallback','Accept only the literal observed six-row class/flag/signature forms; unknown producers or shapes remain refused.');
        in.ODESolver=struct('source_class','function_handle','name',solver.signature,'closure_available',false);
        in.ODEOptions.OutputFcn=struct('source_class','function_handle','name',callback.signature,'closure_available',false);report.(name)=in;
        evidence{end+1,1}=struct('path',[name,'.ODESolver'],'original_descriptor',solver,'source_indices',index,'disposition','saved_name_retained_without_runtime_closure','scope','Observed saved descriptor; producer provenance unknown. Original signature/class/reconstruction flag retained here; no captured workspace was saved or reconstructed.'); %#ok<AGROW>
        evidence{end+1,1}=struct('path',[name,'.ODEOptions.OutputFcn'],'original_descriptor',callback,'source_indices',index,'disposition','saved_name_retained_without_runtime_closure','scope','Observed saved descriptor; producer provenance unknown. Original signature/class/reconstruction flag retained here; no captured workspace was saved or reconstructed.'); %#ok<AGROW>
    end
    derivative=report.options.SolverOptions.Jacobian;
    exactFields(derivative,{'runtime_class','reconstruction_required'},'observed settings-unavailable Jacobian descriptor');
    assert(strcmp(derivative.runtime_class,'FiniteDifferenceJacobian_v3')&&isequal(derivative.reconstruction_required,true), ...
        'C1EssentialComplete:ObservedDerivative','Only the exact observed descriptor with ABSENT settings may be omitted as unavailable historical runtime evidence.');
    report.options.SolverOptions=rmfield(report.options.SolverOptions,'Jacobian'); % ONLY this leaf; every other solver option remains literal.
    evidence{end+1,1}=struct('path','options.SolverOptions.Jacobian','original_descriptor',derivative,'source_indices',index, ...
        'disposition','omitted_runtime_leaf_settings_not_saved','scope','Observed saved descriptor; producer provenance unknown. Settings are ABSENT, not empty/default/complete. This unsupported runtime leaf is omitted from the normalized retained projection and preserved verbatim here; no lossless original-method-settings claim.');
end

function groups=mergeRuntimeDispositions(groups,items)
    for k=1:numel(items)
        item=items{k};found=[];
        for j=1:numel(groups)
            if strcmp(groups{j}.path,item.path)&&isequaln(groups{j}.original_descriptor,item.original_descriptor)&&strcmp(groups{j}.disposition,item.disposition)&&strcmp(groups{j}.scope,item.scope),found=j;break;end
        end
        if isempty(found),groups{end+1,1}=item;else
            assert(~any(groups{found}.source_indices==item.source_indices),'C1EssentialComplete:RuntimeDuplicate','Each original descriptor occurrence is retained once after independent read2 equality.');
            groups{found}.source_indices(end+1,1)=item.source_indices;
        end
    end
end

function [callbacks,derivatives]=validateRuntimeDispositions(groups,source,N)
    callbacks=0;derivatives=0;seen=cell(0,1);
    for k=1:numel(groups)
        g=groups{k};
        for index=g.source_indices.'
            key=sprintf('%s:%d',g.path,index);assert(~ismember(key,seen),'C1EssentialComplete:RuntimeDuplicate','No repeated normalized runtime occurrence.');seen{end+1,1}=key; %#ok<AGROW>
        end
        if strcmp(g.disposition,'saved_name_retained_without_runtime_closure'),callbacks=callbacks+numel(g.source_indices);
        elseif strcmp(g.disposition,'omitted_runtime_leaf_settings_not_saved'),derivatives=derivatives+numel(g.source_indices);
        else,error('C1EssentialComplete:RuntimeDisposition','Unknown runtime evidence disposition.');end
    end
    if strcmp(source.sha256,'352a07916704238c4cace61ba0950e7b671aaf7ef51234731288c7294f43ef5f')
        assert(N==465&&numel(groups)==7&&callbacks==24&&derivatives==6&&numel(seen)==30, ...
            'C1EssentialComplete:RuntimeCount','The exact current PK source must conserve all24 name conversions and6 explicit settings-unavailable omissions.');
        paths={'integration.ODESolver';'integration.ODEOptions.OutputFcn';'replay_integration.ODESolver';'replay_integration.ODEOptions.OutputFcn';'options.SolverOptions.Jacobian'};
        for j=1:numel(paths),for index=289:294,assert(ismember(sprintf('%s:%d',paths{j},index),seen),'C1EssentialComplete:RuntimeCoverage','Every exact observed path/index must retain its original descriptor in the audit.');end,end
    else
        assert(isempty(groups)&&callbacks==0&&derivatives==0,'C1EssentialComplete:RuntimeScope','No unrelated saved store may receive a runtime descriptor adaptation.');
    end
end

function sourceUnchanged(source,before)
    after=dir(source.file);assert(isscalar(after)&&~after.isdir&&isequal(after.bytes,before.bytes)&&isequal(after.datenum,before.datenum), ...
        'C1EssentialComplete:SourceStat','The pinned source metadata changed between index and selected-variable reads.');verify({source});
end

function role=sourceRole(report,metadata)
    role='';m=metadata;
    for depth=1:16
        assert(isstruct(m)&&isscalar(m),'C1EssentialComplete:RoleMetadata','Known role metadata envelopes must be scalar structures.');
        if isfield(m,'independent_NONEDGE_control')
            assert(isequal(m.independent_NONEDGE_control,true),'C1EssentialComplete:RoleMarker','Do not reinterpret a false/unknown declared independent-control marker.');role='nonedge-control';break
        end
        if ~isfield(m,'provenance'),break;end;p=m.provenance;if ~isstruct(p)||~isscalar(p),break;end
        if isfield(p,'kind')&&strcmp(p.kind,'imported nonedge initial pair'),role='nonedge-control';break;end
        if isfield(p,'kind')&&strcmp(p.kind,'native all-nine return rejected by continuation wrapper')
            assert(isequal(p.wrapper_accepted,false)&&isequal(p.edge_claimed,false),'C1EssentialComplete:RoleMarker','Known isolated-native disposition must retain literal wrapper/edge falseflags.');role='isolated';break
        end
        if isfield(p,'historical_predictor')&&isequal(p.historical_predictor,true)&&isfield(p,'edge_claimed')&&isequal(p.edge_claimed,false),role='nonedge-control';break;end
        if isfield(p,'original_point_metadata')
            fields={'source_file','source_sha256','source_index','source_catalog_file','source_catalog_entry','original_point_metadata','qualification_flags_changed'};
            exactFields(p,fields,'Consolidate direct provenance');assert(isequal(p.qualification_flags_changed,false),'C1EssentialComplete:RoleMarker','A historical wrapper cannot claim upgraded flags.');m=p.original_point_metadata;
        else,break;end
        assert(depth<16,'C1EssentialComplete:RoleDepth','Known source metadata wrappers exceed the explicit bound; do not infer a role.');
    end
    if isempty(role)
        if literalAccepted(report),role='accepted';
        elseif isfield(report,'accepted')&&isequal(report.accepted,false)&&isfield(report,'status')&&strcmp(report.status,'rejected'),role='rejected';
        else,role='historical-unknown';end
    end
    if strcmp(role,'rejected'),assert(~isfield(report,'accepted')||~isequal(report.accepted,true),'C1EssentialComplete:RoleConflict','A rejected claim cannot relabel a saved accepted return.');end
    if isfield(metadata,'role'),assert(strcmp(metadata.role,role),'C1EssentialComplete:RoleConflict','An explicit unknown/contradictory source role is not silently discarded.');end
end

function yes=literalAccepted(r)
    names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    yes=isstruct(r)&&isscalar(r)&&isfield(r,'accepted')&&isequal(r.accepted,true)&&isfield(r,'status')&&strcmp(r.status,'accepted') ...
        &&isfield(r,'acceptance_gates')&&isstruct(r.acceptance_gates)&&isscalar(r.acceptance_gates)&&isequal(sort(fieldnames(r.acceptance_gates)),sort(names(:)));
    if yes,yes=all(cellfun(@(k)isequal(r.acceptance_gates.(k),true),names));end
end

function [branch,counts]=wholeGraph(ix,source,records,physical,code,label)
    names={'record_equalities','qualified_aliases','numerical_seams'};oldNames={'exact_record_equalities','qualified_record_aliases','qualified_numerical_overlaps'};
    evidenceNames={'equality_evidence','qualified_alias_evidence','numerical_overlap_evidence'};relations=struct('record_equalities',{cell(0,1)},'qualified_aliases',{cell(0,1)},'numerical_seams',{cell(0,1)});
    if isfield(ix.metadata,'component_graph')
        g=ix.metadata.component_graph;
        legacyFields={'schema','nodes','original_explicit_edges','exact_record_equalities','qualified_record_aliases','qualified_alias_evidence','effective_edges','equality_evidence','connected','isolated_record_catalogue','equality_links_are_continuation_edges','qualified_aliases_are_exact_record_equalities','qualified_aliases_are_continuation_edges'};
        numericalFields={'qualified_numerical_overlaps','numerical_overlap_evidence','strict_trace_scope','numerical_storage_scope','numerical_adjacencies_are_identity_quotients','numerical_adjacencies_are_physical_edges'};
        assert(isstruct(g)&&isscalar(g),'C1EssentialComplete:GraphSource','Use a scalar literal Consolidate graph snapshot.');
        if isequal(sort(fieldnames(g)),sort(legacyFields(:)))
            relationCount=2; % The exact legacy producer has no numerical relation table or numerical flags.
        elseif isequal(sort(fieldnames(g)),sort([legacyFields(:);numericalFields(:)]))
            relationCount=3;
            assert(isequal(g.numerical_adjacencies_are_identity_quotients,false)&&isequal(g.numerical_adjacencies_are_physical_edges,false), ...
                'C1EssentialComplete:GraphSource','Retain the distinct modern numerical-adjacency semantics, without identity or physical-edge claims.');
        else
            error('C1EssentialComplete:GraphSource','Unknown or mixed Consolidate graph fields; require exactly the known legacy13 or modern19 producer.');
        end
        assert(strcmp(g.schema,'C1-connected-component-graph-v1')&&isequal(g.equality_links_are_continuation_edges,false) ...
            &&isequal(g.qualified_aliases_are_exact_record_equalities,false)&&isequal(g.qualified_aliases_are_continuation_edges,false), ...
            'C1EssentialComplete:GraphSource','Preserve the three literal nonphysical relation flags from either known producer.');
        assert(isnumeric(g.nodes)&&isreal(g.nodes)&&isscalar(g.nodes)&&isfinite(g.nodes)&&g.nodes==fix(g.nodes)&&g.nodes>=1&&g.nodes<=numel(records), ...
            'C1EssentialComplete:GraphSnapshot','The literal consolidation snapshot is bounded by the current store; later physical appends remain authoritative in the current index.');
        snapshot=g.original_explicit_edges;
        assert(isnumeric(snapshot)&&isreal(snapshot)&&ismatrix(snapshot)&&size(snapshot,2)==2&&all(isfinite(snapshot(:))) ...
            &&all(snapshot(:)==fix(snapshot(:)))&&all(snapshot(:)>=1)&&all(snapshot(:)<=g.nodes)&&all(snapshot(:,1)~=snapshot(:,2)), ...
            'C1EssentialComplete:GraphSnapshot','Preserve bounded literal physical snapshot edges without replacing the current public index edges.');
        for kind=1:relationCount,snapshot=[snapshot;g.(oldNames{kind})];end %#ok<AGROW>
        assert(isequal(g.effective_edges,snapshot),'C1EssentialComplete:GraphSnapshot','The exact producer effective snapshot is the ordered physical/equality/alias and, only for modern19, numerical concatenation.');
        for kind=1:relationCount
            assert(isfield(g,oldNames{kind})&&isfield(g,evidenceNames{kind}),'C1EssentialComplete:GraphEvidence','Every known relation table needs its literal complete evidence table.');
            pairs=g.(oldNames{kind});evidence=g.(evidenceNames{kind});assert(isnumeric(pairs)&&isreal(pairs)&&size(pairs,2)==2&&iscell(evidence)&&numel(evidence)==size(pairs,1), ...
                'C1EssentialComplete:GraphEvidence','All actual pair/evidence rows must correspond in exact source order.');rows=cell(size(pairs,1),1);
            for j=1:size(pairs,1)
                a=pairs(j,1);b=pairs(j,2);assert(all(isfinite([a,b]))&&all([a,b]==fix([a,b]))&&all([a,b]>=1)&&all([a,b]<=g.nodes)&&all([a,b]<=numel(records))&&a~=b, ...
                    'C1EssentialComplete:RelationBounds','Every relation endpoint must be an actual distinct occurrence.');
                [scalars,fines,schema]=relationEvidence(kind,evidence{j},records{a},records{b},a,ix,records);
                rows{j}=struct('from',a,'to',b,'from_native_id',records{a}.native_id,'to_native_id',records{b}.native_id, ...
                    'receipt_reference',source,'evidence',struct('schema',schema,'scalars',scalars,'original_fines',{fines}));
            end
            relations.(names{kind})=rows;
        end
    end
    branch=struct('schema','C1-essential-branch-graph-v1','role','unpublished-complete-store-measurement','displayname',[label,' complete literal source store'], ...
        'physical_edges',{physical},'record_equalities',{relations.record_equalities},'qualified_aliases',{relations.qualified_aliases}, ...
        'numerical_seams',{relations.numerical_seams},'source_versions',{cellfun(@ref2,code(:),'UniformOutput',false)});
    counts=struct('physical_edges',numel(physical),'record_equalities',numel(relations.record_equalities),'qualified_aliases',numel(relations.qualified_aliases),'numerical_seams',numel(relations.numerical_seams));
end

function [s,fines,schema]=relationEvidence(kind,e,left,right,leftIndex,ix,records)
    fines=cell(0,1);assert(~isempty(left.native_id)&&~isempty(right.native_id),'C1EssentialComplete:RelationID','Nonphysical relations require literal complete endpoint IDs.');
    if kind==1
        exactFields(e,{'native_ID','exact_state_mode_parameter_period_stride','translation_gauge_normalized','matching_return_section','new_continuation_edge_created'},'exact equality evidence');
        assert(isequal(e.exact_state_mode_parameter_period_stride,true)&&isequal(e.translation_gauge_normalized,true)&&isequal(e.new_continuation_edge_created,false) ...
            &&strcmp(e.native_ID,left.native_id)&&strcmp(e.native_ID,right.native_id),'C1EssentialComplete:Equality','Literal original exact-identity evidence must bind both actual NativeIDs.');
        a=identityRecord(left);b=identityRecord(right);a.initial_state(1)=0;b.initial_state(1)=0;rawEqual3(a,b,b,'actual normalized exact equality');checkMatching(e.matching_return_section,left,right);
        s=struct('exact_state_mode_parameter_period_stride',e.exact_state_mode_parameter_period_stride,'translation_gauge_normalized',e.translation_gauge_normalized,'new_continuation_edge_created',e.new_continuation_edge_created);
        s=mergeScalars(s,matchingScalars(e.matching_return_section));schema='ConsolidateC1ConnectedComponents_v3:exact-record-equality-v1';
    elseif kind==2
        fields={'schema','qualified','scope','left_native_ID','right_native_ID','exact_full_initial_state_mode_parameter','physical_parameters_schema_valid','canonical_point_label','left_admission','right_admission','matching_return_section','relative_absolute_tolerance','scale_formula','period_difference','period_scale','scaled_period_difference','stride_difference','stride_scale','scaled_stride_difference_inf','exact_record_equality_claimed','new_continuation_edge_created','original_orbits_reports_and_native_IDs_must_be_retained','request','qualification_source'};
        exactFields(e,fields,'qualified alias evidence');assert(strcmp(e.schema,'C1-qualified-record-alias-v1')&&isequal(e.qualified,true)&&isequal(e.exact_full_initial_state_mode_parameter,true)&&isequal(e.new_continuation_edge_created,false) ...
            &&e.relative_absolute_tolerance==1e-10&&e.scaled_period_difference<=1e-10&&e.scaled_stride_difference_inf<=1e-10, ...
            'C1EssentialComplete:Alias','Copy only the known original qualified-alias contract and fixed stored tolerances.');
        bindIDs(e,left,right);for key={'initial_state','initial_mode','parameter'},rawEqual3(left.orbit.(key{1}),right.orbit.(key{1}),right.orbit.(key{1}),'literal alias raw identity');end
        checkMatching(e.matching_return_section,left,right);checkAdmission(e.left_admission,left,false);checkAdmission(e.right_admission,right,false);
        s=pickScalars(e,{'qualified','exact_full_initial_state_mode_parameter','physical_parameters_schema_valid','canonical_point_label','relative_absolute_tolerance','period_difference','period_scale','scaled_period_difference','stride_difference','stride_scale','scaled_stride_difference_inf','exact_record_equality_claimed','new_continuation_edge_created'});
        s.original_full_runtime_required_at_qualification=e.original_orbits_reports_and_native_IDs_must_be_retained;s=mergeScalars(s,matchingScalars(e.matching_return_section));s=mergeScalars(s,aliasTransport(e));schema=e.schema;
    else
        fields={'schema','qualified','full_native_proof_validated','audit_reference','proof_identity','execution_witness','raw_reference','trial_reference','checkpoint_reference','literal_control_reference','literal_control_raw_reference','left_selector','right_selector','left_native_ID','right_native_ID','left_record','right_record','left_admission','right_admission','comparison','left_original_fines','right_original_fines','earned_physical_edge','validation_source_references','all_source_references_posthash_verified','identity_claimed','quotient_identification','new_continuation_edge_created','classification_or_admission_flags_changed','original_orbits_reports_and_native_IDs_retained','scope','cohort_scope','energy_scope','runtime_comparison_scope'};
        exactFields(e,fields,'qualified numerical evidence');assert(strcmp(e.schema,'C1-qualified-PK-numerical-overlap-v1')&&isequal(e.qualified,true)&&isequal(e.full_native_proof_validated,true) ...
            &&isequal(e.all_source_references_posthash_verified,true)&&isequal(e.identity_claimed,false)&&isequal(e.quotient_identification,false)&&isequal(e.new_continuation_edge_created,false)&&isequal(e.classification_or_admission_flags_changed,false) ...
            &&strcmp(e.proof_identity,'43b7037ec366d628018b40205545194a17f5291c45c3775ef4ddec290900d43c') ...
            &&strcmp(e.proof_identity,e.audit_reference.sha256)&&isequal(e.original_orbits_reports_and_native_IDs_retained,true),'C1EssentialComplete:Seam','Only the distinct complete original numerical-qualification schema is projected.');
        bindIDs(e,left,right);rawEqual3(e.left_record,identityRecord(left),identityRecord(left),'numerical left original raw record');rawEqual3(e.right_record,identityRecord(right),identityRecord(right),'numerical right original raw record');
        checkAdmission(e.left_admission,left,true);checkAdmission(e.right_admission,right,true);c=e.comparison;assert(isequal(c.conditions_met,true),'C1EssentialComplete:Seam','Do not promote an originally false finite comparison.');checkMatching(c.matching_section,left,right);
        incoming=find(cellfun(@(edge)edge.to==leftIndex,ix.edges));assert(isscalar(incoming),'C1EssentialComplete:SeamParent','The earned seam endpoint must have one actual incoming physical edge.');edge=ix.edges{incoming};parent=records{edge.from};
        rawEqual3(e.earned_physical_edge.from_record,identityRecord(parent),identityRecord(parent),'literal earned-parent raw record');
        assert(strcmp(e.earned_physical_edge.from_native_ID,parent.native_id)&&e.earned_physical_edge.from==2&&e.earned_physical_edge.to==3 ...
            &&isequal(e.earned_physical_edge.actual_new_points,1)&&isequal(e.earned_physical_edge.actual_new_edges,1) ...
            &&strcmp(parent.metadata.component_identity,left.metadata.component_identity)&&strcmp(edge.component_identity,left.metadata.component_identity), ...
            'C1EssentialComplete:SeamParent','Only after raw parent identity/actual same-owner edge binding may its NativeID be retained.');
        ownerRows=ix.metadata.source_owner_map;owners=find(cellfun(@(r)strcmp(r.output_component_identity,left.metadata.component_identity),ownerRows));
        assert(isscalar(owners)&&strcmp(ownerRows{owners}.source_component_identity,e.earned_physical_edge.owner),'C1EssentialComplete:SeamOwner','The explicit Consolidate owner map must preserve original earned ownership.');
        s=pickScalars(e,{'qualified','full_native_proof_validated','all_source_references_posthash_verified','identity_claimed','quotient_identification','new_continuation_edge_created','classification_or_admission_flags_changed'});
        s.original_full_runtime_retained_at_qualification=e.original_orbits_reports_and_native_IDs_retained;
        s=mergeScalars(s,pickScalars(c,{'raw_full13_delta','raw_full13_scaled_inf','period_delta','period_tolerance','full_stride_delta','full_stride_tolerance','native_energy_delta','exact_state_equal','exact_p_q_equal','exact_complete_policy_equal','same_section_event_signature','conditions_met'}));
        s=mergeScalars(s,matchingScalars(c.matching_section));s.earned_parent_native_id=parent.native_id;s.actual_new_points=e.earned_physical_edge.actual_new_points;s.actual_new_edges=e.earned_physical_edge.actual_new_edges;
        w=e.execution_witness;assert(strcmp(w.schema,'C1-external-GateB-process-exit-witness-v1')&&w.process_session_id==39141&&isequal(w.actual_process_exit_observed,true)&&w.exit_code==0 ...
            &&strcmp(w.run_name,'GateBOwned01')&&strcmp(w.audit_reference.sha256,e.proof_identity),'C1EssentialComplete:SeamExecution','Retain the original separately observed native process closure.');
        s.execution_witness_schema=w.schema;s.execution_session_id=w.process_session_id;s.execution_exit_observed=w.actual_process_exit_observed;s.execution_exit_code=w.exit_code;s.execution_run_name=w.run_name;
        s=mergeScalars(s,fineScalars(e.left_original_fines,'left'));s=mergeScalars(s,fineScalars(e.right_original_fines,'right'));
        fines=[fineProjection(e.left_original_fines,e.audit_reference);fineProjection(e.right_original_fines,e.audit_reference)];schema=e.schema;
    end
end

function out=fineProjection(rows,source)
    assert(iscell(rows)&&numel(rows)==2,'C1EssentialComplete:Fines','Each original endpoint retains exactly two ordered original-state fine observations.');out=cell(2,1);steps=[.0005,.00025];
    for k=1:2
        f=rows{k};requiredFields(f,{'observation','raw_custody','passed','MaxStep','full13_norm','initial_trajectory_row_exact','matching_saved_section','primitive','saved_period_scaled_error','saved_stride_scaled_error'},'original fine');
        assert(f.MaxStep==steps(k)&&isequal(f.passed,true)&&isequal(f.initial_trajectory_row_exact,true)&&isequal(f.matching_saved_section.compatible,true) ...
            &&f.primitive.cover_count==1&&strcmp(f.primitive.status,'primitive_within_checked_bound')&&f.full13_norm<=1e-8&&f.saved_period_scaled_error<=1e-8&&f.saved_stride_scaled_error<=1e-8 ...
            &&f.observation.invoked&&f.observation.returned&&f.observation.return_timely ...
            &&f.raw_custody.storage_completed&&f.raw_custody.storage_timely&&f.raw_custody.readback_completed&&f.raw_custody.readback_timely, ...
            'C1EssentialComplete:Fines','Preserve actual fine/primitive/original-state/timing/custody flags; no absent gate is manufactured.');
        out{k}=struct('source_reference',ref2(source),'MaxStep',f.MaxStep,'full_closure',f.full13_norm, ...
            'period_scaled_error',f.saved_period_scaled_error,'stride_scaled_error',f.saved_stride_scaled_error, ...
            'primitive',{{f.primitive.status;f.primitive.cover_count}},'invoked',f.observation.invoked,'returned',f.observation.returned,'return_timely',f.observation.return_timely, ...
            'storage_completed',f.raw_custody.storage_completed,'storage_timely',f.raw_custody.storage_timely,'readback_completed',f.raw_custody.readback_completed,'readback_timely',f.raw_custody.readback_timely,'passed',f.passed);
    end
end

function out=fineScalars(rows,side)
    out=struct();for k=1:2
        out.(sprintf('%s_fine%d_initial_trajectory_row_exact',side,k))=rows{k}.initial_trajectory_row_exact;
        out.(sprintf('%s_fine%d_matching_section_compatible',side,k))=rows{k}.matching_saved_section.compatible;
    end
end

function out=aliasTransport(e)
    historicalReference(e.qualification_source);r=e.request;exactFields(r,{'left_node','right_node','kind','input_request'},'Consolidate alias request');
    validateattributes(r.left_node,{'numeric'},{'real','scalar','finite','integer','positive'});validateattributes(r.right_node,{'numeric'},{'real','scalar','finite','integer','positive'});
    out=struct('alias_qualification_source_file',e.qualification_source.file,'alias_qualification_source_sha256',e.qualification_source.sha256, ...
        'alias_request_kind',r.kind,'alias_historical_left_node',r.left_node,'alias_historical_right_node',r.right_node);
    if strcmp(r.kind,'explicit_requested_numeric_alias')
        exactFields(r.input_request,{'left_file','left_index','right_file','right_index'},'explicit alias selector');
        for key={'left_file','right_file'},path=r.input_request.(key{1});assert((ischar(path)&&isrow(path)&&~isempty(path))||(isstring(path)&&isscalar(path)&&~ismissing(path)&&strlength(path)>0), ...
                'C1EssentialComplete:AliasLocator','Retain literal historical selector paths without reopening retired inputs.');end
        for key={'left_index','right_index'},validateattributes(r.input_request.(key{1}),{'numeric'},{'real','scalar','finite','integer','positive'});end
        out.alias_request_left_file=r.input_request.left_file;out.alias_request_left_index=r.input_request.left_index;out.alias_request_right_file=r.input_request.right_file;out.alias_request_right_index=r.input_request.right_index;
    else
        assert(strcmp(r.kind,'inherited_qualified_record_alias'),'C1EssentialComplete:AliasTransport','Unknown claimed alias-transport kinds require review.');
        exactFields(r.input_request,{'source_file','source_sha256','source_alias_row'},'inherited alias locator');
        historicalReference(struct('file',r.input_request.source_file,'sha256',r.input_request.source_sha256));validateattributes(r.input_request.source_alias_row,{'numeric'},{'real','scalar','finite','integer','positive'});
        out.alias_request_source_file=r.input_request.source_file;out.alias_request_source_sha256=r.input_request.source_sha256;out.alias_request_source_row=r.input_request.source_alias_row;
    end
end

function historicalReference(r)
    exactFields(r,{'file','sha256'},'historical file/SHA locator');
    assert(((ischar(r.file)&&isrow(r.file)&&~isempty(r.file))||(isstring(r.file)&&isscalar(r.file)&&~ismissing(r.file)&&strlength(r.file)>0)) ...
        &&ischar(r.sha256)&&isrow(r.sha256)&&~isempty(regexp(r.sha256,'^[0-9a-f]{64}$','once')), ...
        'C1EssentialComplete:HistoricalReference','A historical locator requires literal scalar path text and lowercase SHA256; availability is not inferred.');
end

function classifierProjectionEqual(historical,retained)
    % Exact9f classifier contract: compare selected presence/order/leaves only.
    % Unselected original contact/display/sample trees are never copied.
    names={'contract_version','synchrony_predicate_version','label','alias','abbreviation','status','reason','validated_gait_type','canonical_point_label','canonical_label_qualified','suspension_reference_posture','primitive_flight_count','flight_count_certain','descriptive_only','isotropy_proved','period_used','flight_count','raw_positive_flight_count','flight_count_over_recorded_period','hind_pair_asymmetry','fore_pair_asymmetry','hind_pair_synchronized','front_pair_synchronized','fore_pair_synchronized','legacy_original_suffix_verified_flight_count','v3_abbreviation_suffix2_measured','displaylabel'};
    assert(isstruct(historical)&&isscalar(historical)&&isstruct(retained)&&isscalar(retained),'C1EssentialComplete:HistoricalClassifier','Both classifier projections must preserve scalar structure.');
    keys=fieldnames(historical);expected=keys(ismember(keys,names));
    for key={'contact_reconstruction','tolerances','borderline'},if isfield(historical,key{1}),expected{end+1,1}=key{1};end,end
    assert(isequal(fieldnames(retained),expected),'C1EssentialComplete:HistoricalClassifier','Retained classifier field presence and projection order must match the historical contract.');
    for k=1:numel(expected)
        key=expected{k};
        if strcmp(key,'contact_reconstruction')
            retainedSubsetEqual(historical.(key),retained.(key),{'complete','reason','initial_mode','final_mode','cohorts','event_time_tolerance','atomic_cohorts'},{},'historical contact projection');
        elseif strcmp(key,'tolerances')
            retainedSubsetEqual(historical.(key),retained.(key),{'ContactTolerance','MotionTolerance','AngleTolerance','RateTolerance','StanceRateTolerance','SyncFlowTolerance','ParameterTolerance','ApexTolerance','EventTimeTolerance','FlightDurationTolerance','ObservationRelTol','ObservationAbsTol','ObservationMaxStep','ObservationSafetyFactor','GeometryTolerance','SampleCount'},{'PrimitiveOptions'},'historical tolerance projection');
        else,rawEqual3(historical.(key),retained.(key),retained.(key),'historical retained classifier value');end
    end
end

function retainedSubsetEqual(historical,retained,names,tail,label)
    assert(isstruct(historical)&&isscalar(historical)&&isstruct(retained)&&isscalar(retained),'C1EssentialComplete:HistoricalClassifier','The %s must preserve scalar structure.',label);
    keys=fieldnames(historical);expected=keys(ismember(keys,names));for k=1:numel(tail),if isfield(historical,tail{k}),expected{end+1,1}=tail{k};end,end
    assert(isequal(fieldnames(retained),expected),'C1EssentialComplete:HistoricalClassifier','The %s must preserve every retained field and its literal missingness/order.',label);
    for k=1:numel(expected),key=expected{k};rawEqual3(historical.(key),retained.(key),retained.(key),label);end
end

function bindIDs(e,left,right)
    assert(strcmp(e.left_native_ID,left.native_id)&&strcmp(e.right_native_ID,right.native_id),'C1EssentialComplete:HistoricalID','Original qualifier IDs must match both literal actual endpoints.');
end

function out=identityRecord(r)
    o=r.orbit;out=struct('initial_state',o.initial_state,'initial_mode',o.initial_mode,'parameter',o.parameter,'period',o.period,'stride_displacement',o.stride_displacement,'return_policy_name',o.return_policy_name);
end

function checkAdmission(a,r,numerical)
    assert(isequal(a.all_nine_literal_true,true)&&isequal(a.accepted,true),'C1EssentialComplete:HistoricalAdmission','Original historical all-nine/accepted flags must remain true.');
    names={'full_closure','mode_closure','target_energy','trajectory_energy_variation','unscaled_family_equations','family_constraint','physical_inequalities','primitive_identity','replay_determinism'};
    assert(isfield(r.report,'acceptance_gates')&&all(cellfun(@(n)isfield(r.report.acceptance_gates,n)&&isequal(r.report.acceptance_gates.(n),true),names)), ...
        'C1EssentialComplete:HistoricalAdmission','Every literal retained root gate must agree with the existing historical qualification.');
    status='';if isfield(r.report,'status'),status=r.report.status;elseif isfield(r.report,'native_status'),status=r.report.native_status;end
    assert(isequaln(a.stored_status,status),'C1EssentialComplete:HistoricalAdmission','Original stored admission status must bind the actual retained report.');
    if numerical
        assert(r.policy.complete,'C1EssentialComplete:HistoricalPolicy','Numerical qualification requires the actual complete retained policy.');rawEqual3(a.policy_configuration,r.policy.configuration,r.policy.configuration,'numerical admission policy');
        classifierProjectionEqual(a.classification,r.report.classification);
    else
        g=r.report.classification;assert(strcmp(a.classification_contract,g.contract_version)&&strcmp(a.canonical_point_label,g.canonical_point_label)&&strcmp(a.validated_gait_type,g.validated_gait_type) ...
            &&isequaln(a.flight_count_certain,g.flight_count_certain)&&isequaln(a.flight_count,g.flight_count),'C1EssentialComplete:HistoricalClassifier','Alias scalar admission/classification facts must bind the actual retained classifier.');
    end
end

function checkMatching(m,left,right)
    assert(isequal(m.compatible,true)&&isequal(m.actual_policy_configuration_checked,true)&&isequal(m.policy_configuration_matches_declared_identity,true)&&isequal(m.rephase_or_chart_transition_inferred,false) ...
        &&isempty(m.left_missing_fields)&&isempty(m.right_missing_fields),'C1EssentialComplete:HistoricalSection','The known original MatchingReturnSection evidence must be complete and unchanged.');
    rawEqual3(m.left_identity,sectionIdentity(left),sectionIdentity(left),'historical left section');rawEqual3(m.right_identity,sectionIdentity(right),sectionIdentity(right),'historical right section');
    assert(left.policy.complete&&right.policy.complete,'C1EssentialComplete:HistoricalPolicy','Both actual retained policies must remain complete.');
    rawEqual3(m.left_policy_configuration,left.policy.configuration,left.policy.configuration,'historical left policy');rawEqual3(m.right_policy_configuration,right.policy.configuration,right.policy.configuration,'historical right policy');
end

function out=sectionIdentity(r)
    o=r.orbit;name=char(o.return_policy_name);assert(~isempty(name),'C1EssentialComplete:SectionName','A qualified known section cannot acquire a missing/fallback policy name.');
    out=struct('return_policy_name',name,'initial_mode',logical(o.initial_mode(:)),'section',struct(),'return_occurrence',1);
    keys={'id','geometry','crossing_orientation','boundary_ownership','translational_gauge'};
    for k=1:numel(keys),assert(isfield(o.section_chart,keys{k}),'C1EssentialComplete:Section','A known qualified section field is missing.');out.section.(keys{k})=o.section_chart.(keys{k});end
    if ismember(name,{'BL-marked-apex-return','BLMarkedApexReturnPolicy_v3'}),out.return_occurrence=o.section_chart.BL_touchdowns_per_return;
    elseif ismember(name,{'iterated-section-return','IteratedReturnPolicy_v3'}),out.return_occurrence=o.return_multiplicity;end
end

function out=matchingScalars(m)
    out=struct('matching_section_compatible',m.compatible,'actual_policy_configuration_checked',m.actual_policy_configuration_checked, ...
        'policy_configuration_matches_declared_identity',m.policy_configuration_matches_declared_identity,'rephase_or_chart_transition_inferred',m.rephase_or_chart_transition_inferred);
end

function out=pickScalars(value,names)
    requiredFields(value,names,'known scalar evidence');out=struct();for k=1:numel(names),out.(names{k})=value.(names{k});end
end

function out=mergeScalars(out,extra)
    for key=fieldnames(extra).',assert(~isfield(out,key{1}),'C1EssentialComplete:EvidenceCollision','Essential scalar evidence fields must be distinct.');out.(key{1})=extra.(key{1});end
end

function exactFields(value,names,label)
    assert(isstruct(value)&&isscalar(value)&&isequal(sort(fieldnames(value)),sort(names(:))),'C1EssentialComplete:KnownSchema','Use the exact source-backed %s fieldset; unknown qualifications refuse.',label);
end

function requiredFields(value,names,label)
    assert(isstruct(value)&&isscalar(value)&&all(isfield(value,names)),'C1EssentialComplete:RequiredEvidence','The known %s is missing required actual fields.',label);
end

function counts=countRoles(roles)
    names=EssentialBranchSolutionFile_v3.contract();names=names.roles;counts=struct();for k=1:numel(names),counts.(strrep(names{k},'-','_'))=sum(strcmp(roles,names{k}));end
end

function verifyCandidatePass(file,expected)
    [objects,reports,metadata]=EssentialBranchSolutionFile_v3.loadSolutions(file,(1:numel(expected)).');
    for k=1:numel(expected)
        marker=expectedMarker(expected{k});rawEqual3(marker,objects{k}.schema_metadata.essential_storage,reports{k}.essential_storage,'actual complete public marker/context');
        r=EssentialBranchSolutionFile_v3.project(objects{k},reports{k},metadata{k},expected{k}.context);rawEqual3(expected{k},r,r,'original vs actual complete public projection');
    end
end

function out=returnSummary(value)
    out=struct();if isempty(value),return;end
    assert(isstruct(value)&&isscalar(value)&&isfield(value,'points')&&isfield(value,'edges'),'C1EssentialComplete:Return','The actual storage return must be a plain public index.');
    out=struct('scientific_digest',C1ScientificDigest_v3(value),'point_count',numel(value.points),'physical_edge_count',numel(value.edges),'storage_version',value.storage_version);
end

function verifyPrivateRetirement(r,workspace)
    assert(strcmp(fileparts(r.file),workspace),'C1EssentialComplete:Cleanup','Only exact generated private derivative paths may be retired.');verify({r});
end

function marker=expectedMarker(r)
    c=EssentialBranchSolutionFile_v3.contract();marker=struct('schema',c.schema,'historical_evidence_only',true, ...
        'trajectory_available',false,'event_state_tapes_available',false,'solver_tapes_available',false, ...
        'requires_fresh_replay',true,'whole_runtime_equality_claimed',false,'omissions',c.omissions, ...
        'receipt_reference_availability',c.receipt_reference_availability,'cluster_membership_domain',c.cluster_membership_domain);
    marker.native_id=r.native_id;marker.context=r.context;marker.recorded_policy_evidence=r.policy;
    marker.retained_orbit_fields=fieldnames(r.orbit);marker.retained_report_fields=fieldnames(r.report);marker.retained_method_fields=fieldnames(r.method);marker.native_id_available=~isempty(r.native_id);
end

function saveReturns(file,observations)
    stage=[file,'.pending.mat'];fresh({stage});save(stage,'observations','-v7');a=load(stage,'observations');b=load(stage,'observations');rawEqual3(observations,a.observations,b.observations,'actual kernel returns');move(stage,file,isfile(file));a=load(file,'observations');b=load(file,'observations');rawEqual3(observations,a.observations,b.observations,'installed kernel returns');
end

function out=stageNames(folder)
    d=dir(fullfile(folder,'*.essential_stage.mat'));out=sort(cellfun(@(n)canonical(fullfile(folder,n)),{d.name}.','UniformOutput',false));
end

function out=ref2(r),out=struct('file',canonical(r.file),'sha256',r.sha256);end

function rawEqual3(expected,a,b,where)
    assert(strcmp(class(expected),class(a))&&strcmp(class(expected),class(b))&&isequal(size(expected),size(a),size(b)),'C1PackedPilot:ExactType','Type/shape changed at %s.',where);
    if isnumeric(expected)
        assert(isequal(isreal(expected),isreal(a),isreal(b)),'C1PackedPilot:ExactRealness','Numeric realness changed at %s.',where);
        assert(isequal(typecast(real(expected(:)),'uint8'),typecast(real(a(:)),'uint8'),typecast(real(b(:)),'uint8')),'C1PackedPilot:ExactBytes','Real numeric raw bytes changed at %s.',where);
        if ~isreal(expected),assert(isequal(typecast(imag(expected(:)),'uint8'),typecast(imag(a(:)),'uint8'),typecast(imag(b(:)),'uint8')),'C1PackedPilot:ExactBytes','Imaginary raw bytes changed at %s.',where);end
    elseif islogical(expected)||ischar(expected)
        assert(isequal(expected,a,b),'C1PackedPilot:ExactValue','Literal values changed at %s.',where);
    elseif isstring(expected)
        assert(isequaln(expected,a,b),'C1PackedPilot:ExactString','Literal strings/missingness changed at %s.',where);
    elseif iscell(expected)
        for k=1:numel(expected),rawEqual3(expected{k},a{k},b{k},sprintf('%s{%d}',where,k));end
    elseif isstruct(expected)
        f=fieldnames(expected);assert(isequal(f,fieldnames(a),fieldnames(b)),'C1PackedPilot:ExactFields','Field names/order changed at %s.',where);
        for k=1:numel(expected),for j=1:numel(f),rawEqual3(expected(k).(f{j}),a(k).(f{j}),b(k).(f{j}),[where,'.',f{j}]);end,end
    else
        error('C1PackedPilot:ExactClass','Unsupported projection class %s at %s.',class(expected),where);
    end
end

function r=checked(r),assert(isstruct(r)&&isscalar(r)&&all(isfield(r,{'file','sha256'})),'C1MergedB:Reference','Supply one exact immutable file/SHA reference.');verify({r});r.file=canonical(r.file);end

function closed(w,r)
    fields={'schema','actual_process_exit_observed','all_owned_native_workers_exit_observed','process_session_id','exit_code','source_sha256','custody_complete','pending_boundary_reviewed'};
    assert(isstruct(w)&&isscalar(w)&&all(isfield(w,fields))&&strcmp(w.schema,'C1-closed-owned-native-worker-v1')&&isequal(w.actual_process_exit_observed,true)&&isequal(w.all_owned_native_workers_exit_observed,true) ...
        &&isnumeric(w.process_session_id)&&isscalar(w.process_session_id)&&isfinite(w.process_session_id)&&w.process_session_id>0&&w.process_session_id==fix(w.process_session_id)&&isequal(w.exit_code,0) ...
        &&strcmp(w.source_sha256,r.sha256)&&isequal(w.custody_complete,true)&&isequal(w.pending_boundary_reviewed,true), ...
        'C1MergedB:WorkerClosure','Require actual previous owned-worker exit0 and completed custody/pending review; marker/current empty active fields alone do not prove process closure.');
    [~,name,ext]=fileparts(r.file);assert(strcmp(ext,'.m')&&strcmp(canonical(which(name)),r.file),'C1MergedB:WorkerSource','The actually closed helper source must match its retained current resolver.');
end

function paths=coreRoster(root,merged)
    d=dir(fullfile(root,'Components'));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==43&&~any([d.isdir])&&all(endsWith(lower(string({d.name})),'.mat'))&&~any(contains(lower(string({d.name})),'pending')),'C1MergedB:OriginalCores','Keep exact43 untouched core MATs and no unknown stage.');paths=cellfun(@(n)canonical(fullfile(root,'Components',n)),{d.name}.','UniformOutput',false);
    d=dir(fileparts(merged));d=d(~ismember({d.name},{'.','..'}));assert(numel(d)==1&&~d.isdir&&strcmp(canonical(fullfile(d.folder,d.name)),merged),'C1MergedB:MergedDirectory','The permanent merged directory contains exactly its current one MAT with no random/stage file.');paths=sort([paths;{merged}]);
end

function names=resultsRoster(root)
    d=dir(fullfile(root,'Results','*.mat'));assert(~any([d.isdir]),'C1MergedB:ResultsDirectory','A Results MAT entry cannot be a directory.');names=sort(cellfun(@(n)canonical(fullfile(root,'Results',n)),{d.name}.','UniformOutput',false));
end

function l=finalStorageLimit(b),l=struct('utc',b.deadline_unix_seconds,'mono',b.deadline_monotonic_ns);end

function l=minLimit(a,b),l=struct('utc',min(a.utc,b.utc),'mono',min(a.mono,b.mono));end

function publish(file,json,audit,l)
check(l);stage=[file,'.pending.mat'];fresh({stage});save(stage,'audit','-v7');a=load(stage,'-mat','audit');b=load(stage,'-mat','audit');assert(isequaln(a.audit,audit)&&isequaln(b.audit,audit),'C1Pilot:Audit','Both complete plain audit reads must agree.');move(stage,file,isfile(file));stage=[json,'.pending.json'];fresh({stage});jsonProjection=audit;
if isstruct(jsonProjection.digest_fixtures)&&isscalar(jsonProjection.digest_fixtures)&&isfield(jsonProjection.digest_fixtures,'payload')
    % Complex values, raw NaN payloads, signed zero, uint64 and missing-string
    % fixtures are native MAT evidence. JSON cannot represent them faithfully.
    % Never alter the native audit, fixture inputs, digests or pass/fail flags.
    jsonProjection.digest_fixtures=rmfield(jsonProjection.digest_fixtures,'payload');
    jsonProjection.digest_fixtures.payload_available_in_JSON=false;
    jsonProjection.digest_fixtures.payload_storage_scope='Full literal fixture payload is retained and read twice in the audit MAT; this JSON projection omits only that payload. Digests, distinct pairs and actual flags remain literal. JSON is not the native scientific equality authority.';
end
text=jsonencode(jsonProjection,PrettyPrint=true);h=fopen(stage,'w');assert(h>=0,'C1Pilot:JSON','Cannot open fresh JSON stage.');c=onCleanup(@()fclose(h));bytes=unicode2native(text,'UTF-8');assert(fwrite(h,bytes,'uint8')==numel(bytes),'C1Pilot:JSON','Write every projected byte.');clear c;assert(isequaln(jsondecode(fileread(stage)),jsondecode(text)),'C1Pilot:JSON','Projected JSON differs.');move(stage,json,isfile(json));a=load(file,'-mat','audit');b=load(file,'-mat','audit');assert(isequaln(a.audit,audit)&&isequaln(b.audit,audit),'C1Pilot:Installed','Both whole installed audit reads must agree.');check(l);
end

function verifyCode(refs),verify(refs);for k=1:numel(refs),r=refs{k};[~,name]=fileparts(r.file);assert(strcmp(canonical(which(name)),canonical(r.file)),'C1Pilot:Resolver','A guarded implementation resolves elsewhere.');end,end

function verify(refs),for k=1:numel(refs),r=refs{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Pilot:Changed','A guarded authority/source/core changed.');end,end

function r=reference(f),assert(isfile(f),'C1Pilot:Missing','A required authority/source is missing.');r=struct('file',canonical(f),'sha256',RoundSHA256_v3(f));end

function move(a,b,replace),if replace,v=javaArray('java.nio.file.CopyOption',2);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');v(2)=javaMethod('valueOf','java.nio.file.StandardCopyOption','REPLACE_EXISTING');else,fresh({b});v=javaArray('java.nio.file.CopyOption',1);v(1)=javaMethod('valueOf','java.nio.file.StandardCopyOption','ATOMIC_MOVE');end;javaMethod('move','java.nio.file.Files',java.io.File(a).toPath(),java.io.File(b).toPath(),v);end

function fresh(files),for k=1:numel(files),assert(~isfile(files{k})&&~isfolder(files{k}),'C1Pilot:Fresh','Retain an existing authority or uncertain stage.');end,end

function e=exceptionData(x),causes=cell(size(x.cause));for k=1:numel(causes),causes{k}=exceptionData(x.cause{k});end;e=struct('identifier',x.identifier,'message',x.message,'stack',x.stack,'causes',{causes});end

function p=canonical(p),p=char(java.io.File(char(p)).getCanonicalPath());end

function t=pairClock(),t=struct('utc',posixtime(datetime('now','TimeZone','UTC')),'mono',double(java.lang.System.nanoTime));end

function t=shift(t,s),t.utc=t.utc+s;t.mono=t.mono+s*1e9;end

function v=left(t),v=min(t.utc-posixtime(datetime('now','TimeZone','UTC')),(t.mono-double(java.lang.System.nanoTime))/1e9);end

function check(t),assert(left(t)>0,'C1Pilot:Clock','The fixed whole/local/science clock expired.');end

function s=stamp(),s=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));end

function guard=acquireWriterLock(file)
    % Stable inode: never delete, rename or truncate this zero-byte file.
    % The OS releases its exclusive lock if the MATLAB process exits.
    % Claim in this JVM BEFORE opening a second descriptor: on POSIX, closing
    % that descriptor could otherwise release an existing same-JVM OS lock.
    registry=java.lang.System.getProperties();
    key=java.lang.String(['org.SLIP_Model_Zoo.C1PersistentWriterLock.v1:',char(java.io.File(file).getCanonicalPath())]);
    claim=java.lang.String(char(java.util.UUID.randomUUID));previous=registry.putIfAbsent(key,claim);
    assert(isempty(previous),'C1Persistent:WriterBusy','This JVM already has a cooperating persistent ledger writer.');
    raf=[];channel=[];token=[];
    try
        raf=java.io.RandomAccessFile(file,'rw');channel=raf.getChannel();
        assert(raf.length()==0,'C1Persistent:WriterLock','The stable writer-lock file must remain zero bytes.');
        token=channel.tryLock();
        assert(~isempty(token),'C1Persistent:WriterBusy','The persistent ledger already has a live writer.');
    catch problem
        releaseWriterLock(token,channel,raf,registry,key,claim);
        if strcmp(problem.identifier,'C1Persistent:WriterBusy'),rethrow(problem);end
        error('C1Persistent:WriterBusy','Exclusive persistent writer lock was refused: %s',problem.message);
    end
    guard=onCleanup(@()releaseWriterLock(token,channel,raf,registry,key,claim));
end

function releaseWriterLock(token,channel,raf,registry,key,claim)
    closed=true;
    if ~isempty(token),try,if token.isValid(),token.release();end,catch,closed=false;end,end
    if ~isempty(channel),try,channel.close();catch,closed=false;end,end
    if ~isempty(raf),try,raf.close();catch,closed=false;end,end
    if closed,try,registry.remove(key,claim);catch,end,end
end

function sourceValidateValue(value, allowNative, depth)
    assert(depth <= 128, 'BranchSolutionFile_v3:Depth', ...
        'Cyclic or excessively nested data is unsupported.');
    if isnumeric(value) || islogical(value) || ischar(value) || isstring(value)
        return
    elseif iscell(value)
        for k = 1:numel(value)
            sourceValidateValue(value{k}, allowNative, depth + 1);
        end
    elseif isstruct(value)
        names = fieldnames(value);
        for k = 1:numel(value)
            for j = 1:numel(names)
                sourceValidateValue(value(k).(names{j}), allowNative, depth + 1);
            end
        end
    elseif allowNative && any(strcmp(class(value), {'HybridOrbit_v3', 'Trajectory_v3'}))
        names = properties(value);
        for k = 1:numel(value)
            for j = 1:numel(names)
                sourceValidateValue(value(k).(names{j}), true, depth + 1);
            end
        end
    else
        error('BranchSolutionFile_v3:ValueClass', ...
            'Unsupported data class %s; reports and metadata must contain plain data.', class(value));
    end
end

