function audit=InspectC1RecentAcquisitions_v3(confirmedIdle)
%INSPECTC1RECENTACQUISITIONS_V3 Selected CLOSED report facts; no model calls.
    assert(nargin==1&&isequal(confirmedIdle,true),'C1Recent:Closed','Root must confirm both writers exited.');
    root=fileparts(which('C1RunBudget_v3'));budget=C1RunBudget_v3();
    finish=struct('utc',min(budget.research_deadline_unix_seconds,utc()+180), ...
        'mono',min(budget.research_deadline_monotonic_ns,nano()+180e9));
    work=struct('utc',finish.utc-10,'mono',finish.mono-10e9);check(work);
    output=fullfile(root,'Audits','Recent_Acquisition_Diagnostics.json');
    assert(~isfile(output)&&~isfolder(output),'C1Recent:Fresh');
    files={fullfile(root,'Audits','Velocity_Reversed_FG_fg19_velocity_reversed.mat'), ...
        fullfile(root,'Audits','G_Pitch_Acquisition.mat')};
    audit=struct('schema','C1-closed-recent-acquisition-report-diagnostic-v1','source_references',{{}}, ...
        'helper_reference',ref([mfilename('fullpath'),'.m']),'datasets',{{}},'complete',false, ...
        'source_posthash',false,'failure',struct(),'new_maps',0,'new_corrections',0,'new_classifications',0, ...
        'admission_flags_modified',false,'deadline_outcomes_upgraded',false, ...
        'scope','Literal saved report views; Root invalid-map causes are not attributed one-to-one to the last Jacobian.');
    storeFile=fullfile(root,'Results','C1_G_pitch_acquisition.mat');storeIndex=[];
    try
        for k=1:2
            check(work);audit.source_references{end+1,1}=ref(files{k});check(work);
            loaded=load(files{k},'summary');assert(isfield(loaded,'summary')&&isstruct(loaded.summary)&&isscalar(loaded.summary),'C1Recent:Summary');s=loaded.summary;
            d=struct('source_file',files{k},'literal_summary_flags',pick(s,{'status','completed','complete','failure', ...
                'positive_FG_supported','source_code_posthash','publication_timely','source_unchanged','code_unchanged', ...
                'confirmed_stored_count','started_utc','updated_utc'}),'report_views',{{}});
            if k==1
                assert(strcmp(s.configuration.schema,'C1-native-velocity-reversed-FG-acquisition-v1'),'C1Recent:VelocitySchema');
                for name={'control','acquisition'}
                    item=get(s,name{1},struct());if strcmp(name{1},'acquisition'),item=get(item,'service',struct());end
                    d.report_views{end+1,1}=view([name{1},'.report'],item,get(item,'report',[]));
                end
            else
                assert(strcmp(s.schema,'C1-G-pitch-selector-acquisition-v1')&&iscell(s.attempts)&&numel(s.attempts)<=5,'C1Recent:PitchSchema');
                for j=1:numel(s.attempts)
                    row=s.attempts{j};r=get(row,'failed_report',[]);location=sprintf('attempts{%d}.failed_report',j);
                    if isempty(r)&&isequal(get(row,'storage_returned',false),true)
                        if isempty(storeIndex)
                            check(work);audit.source_references{end+1,1}=ref(storeFile);storeIndex=BranchSolutionFile_v3.index(storeFile);
                            assert(isequaln(storeIndex.metadata,s.configuration),'C1Recent:StoreOwner');
                        end
                        n=row.stored_point;assert(isnumeric(n)&&isscalar(n)&&isfinite(n)&&n==fix(n)&&n>=1&&n<=numel(storeIndex.points),'C1Recent:StoredPoint');
                        point=storeIndex.points{n};p=point.provenance;
                        assert(isequal(p.attempt,row.attempt)&&isequal(p.kind,row.kind)&& ...
                            isequaln(p.source,s.source)&&isequal(p.source_index,9),'C1Recent:StoredReportOwner');
                        check(work);v=load(storeFile,point.report_variable);r=v.(point.report_variable);
                        location=[storeFile,'::',point.report_variable];
                    end
                    d.report_views{end+1,1}=view(location,row,r);check(work);
                end
                active=get(s,'active_attempt',struct());
                if ~isempty(fieldnames(active)),d.active_attempt_literal=pick(active,rowFields());end
            end
            pending=get(s,'pending_admission',struct());d.pending_native_present=~isempty(fieldnames(pending));
            if d.pending_native_present
                d.report_views{end+1,1}=view('pending_admission.raw_report',pending,get(pending,'raw_report',[]));
            end
            audit.datasets{end+1,1}=d;check(work);
        end
        for k=1:numel(audit.source_references),r=audit.source_references{k};assert(strcmp(RoundSHA256_v3(r.file),r.sha256),'C1Recent:SourceChanged');check(work);end
        assert(strcmp(RoundSHA256_v3(audit.helper_reference.file),audit.helper_reference.sha256),'C1Recent:HelperChanged');
        audit.source_posthash=true;audit.complete=true;
    catch problem,audit.failure=struct('identifier',problem.identifier,'message',problem.message,'stack',problem.stack);end
    audit.generated_utc=char(datetime('now','TimeZone','UTC','Format',"yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"));encoded=plain(audit,0);
    stage=[tempname(fileparts(output)),'.json'];cleanup=onCleanup(@()remove(stage));check(finish);
    fid=fopen(stage,'w');assert(fid>=0,'C1Recent:JSON');closer=onCleanup(@()fclose(fid));fprintf(fid,'%s\n',jsonencode(encoded,PrettyPrint=true));clear closer
    assert(isequaln(jsondecode(fileread(stage)),jsondecode(jsonencode(encoded))),'C1Recent:Readback');check(finish);
    [ok,msg]=movefile(stage,output);assert(ok,'C1Recent:Publish','%s',msg);clear cleanup;check(finish);
end
function out=view(location,row,r)
    out=struct('report_location',location,'literal_row',pick(row,rowFields()),'report_present',~isempty(r),'report',struct());
    if isempty(r),return;end
    assert(isstruct(r)&&isscalar(r),'C1Recent:Report');out.report=projectReport(r);
end
function names=rowFields()
    names={'attempt','kind','target_pitch','status','native_accepted','all_nine','native_all_nine','timely','native_return_timely', ...
        'timely_at_return','storage_attempted','storage_returned','storage_timely','saved_point','stored_point', ...
        'committed','stage','failure','capture','source_capture','definition'};
end
function out=projectReport(r)
    out=pick(r,{'status','native_status','accepted','elapsed_seconds','failure_stage','acceptance_gates','acceptance', ...
        'full_closure','initial_scaled_norm','final_scaled_norm','initial_physical_norm','final_physical_norm', ...
        'primary_failure','finalization_failure','replay_failure','within_original_clock','acquisition_deadlines', ...
        'effective_correction_ode','effective_replay_ode','delegated_residual_definition'});
    out.classification=pick(get(r,'classification',struct()),{'contract_version','validated_gait_type','canonical_point_label', ...
        'canonical_label_qualified','flight_count','flight_count_certain','status','reason'});
    solver=get(r,'solver',struct());initial=get(r,'initial_evaluation',struct());final=get(solver,'evaluationInfo',struct());
    out.initial_physical_residual=vectorFact(get(initial,'physical_residual',[]),'initial_evaluation.physical_residual');
    out.initial_full13_closure=vectorFact(get(initial,'full_physical_closure_residual',[]),'initial_evaluation.full_physical_closure_residual');
    family=get(r,'family_conditions',struct());
    if isfield(family,'unscaled_family_equations'),residual=family.unscaled_family_equations;where='family_conditions.unscaled_family_equations';
    else,residual=get(final,'physical_residual',[]);where='solver.evaluationInfo.physical_residual';end
    out.final_physical_residual=vectorFact(residual,where);
    if isfield(r,'full_closure_residual')&&~isempty(r.full_closure_residual)
        v=r.full_closure_residual;assert(isnumeric(v)&&isvector(v)&&numel(v)==14,'C1Recent:Closure');
        out.full13_closure=vectorFact(v(2:14),'full_closure_residual(2:14), first independent replay');
    else,out.full13_closure=vectorFact(get(final,'full_physical_closure_residual',[]),'solver.evaluationInfo.full_physical_closure_residual, root evaluation only');end
    out.closure_scope='Literal full_closure can include a second tighter replay and need not equal the displayed vector norm.';
    out.root=pick(solver,{'status','converged','primaryConverged','primaryMessage','primaryErrorIdentifier', ...
        'residualNorm','mapEvaluationCount','functionEvaluationCount','acceptedNewtonIterations','invalidTrialCount', ...
        'invalidEvaluationCount','jacobianEvaluationCount'});
    out.root.last_accepted_iterate=pick(get(solver,'lastAcceptedIterate',struct()),{'kind','phase','iteration','coordinates', ...
        'scaled_coordinates','state_scale','scaled_residual','unscaled_residual','residual_scale','residual_norm','valid', ...
        'native_energy','free_energy','energy_is_free','full13_closure','full13_closure_norm','damping', ...
        'line_search_fraction','function_evaluation_index','map_evaluation_count','elapsed_seconds'});
    out.root.native_output=pick(get(solver,'output',struct()),{'initialJacobianUsed','acceptedIterations','invalidTrialCount'});
    out.root.derivative=derivativeFacts(solver);
    options=get(r,'options',struct());out.requested_options=pick(options,{'MaxWallSeconds','Symmetry','FamilyConstraint','Energy','Acceptance'});
    so=get(options,'SolverOptions',struct());out.requested_options.SolverOptions=pick(so,{'Algorithm','MaxIterations','MaxFunctionEvaluations', ...
        'InitialDamping','FunctionTolerance','ResidualAcceptanceTolerance','StepTolerance','OptimalityTolerance', ...
        'UseBroyden','JacobianRefreshInterval','ReuseJacobian','ProvideJacobianToFsolve','MaxWallSeconds','StateScale','ParameterScale'});
    if isfield(so,'Jacobian'),out.requested_options.SolverOptions.Jacobian=jacobianDescriptor(so.Jacobian);end
    [~,policy]=RecordedReturnPolicy_v3(r);out.actual_policy=policy;
end
function out=derivativeFacts(solver)
    d=get(solver,'jacobianDiagnostics',struct());assert(isstruct(d)&&isscalar(d),'C1Recent:Derivative');
    out=pick(d,{'method','relativeStep','evaluations','maximumFunctionCalls','selectedSteps','failedColumns','unattemptedColumns', ...
        'perColumnNumericalAvailability','perColumnReliability','allReliable','success','classicalDerivative','failure','finalDeadlineFailure'});
    out.first_failed_probe=struct();p=rows(get(d,'probes',{}));
    for k=1:numel(p)
        if ~isequal(get(p{k},'valid',false),true)||~isempty(fieldnames(get(p{k},'failure',struct())))
            out.first_failed_probe=pick(p{k},{'probe_index','evaluation_index','column','direction','halving','actualSignedStep','invoked','returned','valid','failure'});break
        end
    end
    invalid=rows(get(solver,'invalidEvaluationDiagnostics',{}));out.first_invalid_evaluation=struct();out.first_retained_physical_domain_failure=struct();
    names={'stage','identifier','message','original_exception_stack','function_evaluation_index','map_evaluation_count','map_started','from_cache','context_override_present'};
    physical={'ContinuousDynamics_v3:TensileStance','ContinuousDynamics_v3:PhysicallyInadmissible','HybridSimulator_v3:InadmissibleState', ...
        'PoincareMap_v3:InvalidInitialSection','PoincareMap_v3:InvalidReturnCrossing','QuadrupedPhysicalChart_v3:OffManifold'};
    if ~isempty(invalid),out.first_invalid_evaluation=pick(invalid{1},names);end
    for k=1:numel(invalid)
        if any(strcmp(get(invalid{k},'identifier',''),physical)),out.first_retained_physical_domain_failure=pick(invalid{k},names);break;end
    end
    out.physical_identifier_search=physical;
    out.cause_scope='First retained matching native domain error, not proof of the first continuous-time obstruction or attribution to the last Jacobian.';
end
function out=jacobianDescriptor(value)
    if ~isobject(value),assert(isempty(value)||isstruct(value),'C1Recent:Jacobian');out=value;return;end
    name=class(value);keys={'Method';'RelativeStep';'MinimumStep';'MaximumStep';'CheckFinite';'FailurePolicy'};
    assert(isscalar(value)&&any(strcmp(name,{'FiniteDifferenceJacobian_v3','ValidSidedFiniteDifferenceJacobian_v3'})),'C1Recent:Jacobian');
    if strcmp(name,'ValidSidedFiniteDifferenceJacobian_v3'),keys=[keys;{'DeadlineUnixSeconds';'DeadlineMonotonicNs';'MaximumHalvings'}];end
    assert(isequal(sort(properties(value)),sort(keys)),'C1Recent:JacobianSettings');settings=struct();
    for k=1:numel(keys),settings.(keys{k})=value.(keys{k});end
    out=struct('diagnostic_kind','runtime-object-descriptor','source_class',name,'settings',settings);
end
function out=vectorFact(value,source)
    assert(isnumeric(value)&&(isempty(value)||isvector(value))&&numel(value)<=64,'C1Recent:Vector');
    out=struct('source_field',source,'present',~isempty(value),'components',value,'norm_inf',[]);
    if ~isempty(value),out.norm_inf=norm(value,Inf);end
end
function out=rows(value)
    if iscell(value),out=value(:);elseif isstruct(value),out=num2cell(value(:));else,error('C1Recent:Rows','Expected saved diagnostic structs or cells.');end
    assert(all(cellfun(@(x)isstruct(x)&&isscalar(x),out)),'C1Recent:Rows');
end
function out=pick(value,names)
    out=struct();assert(isstruct(value)&&isscalar(value),'C1Recent:Struct');
    for k=1:numel(names),if isfield(value,names{k}),out.(names{k})=value.(names{k});end,end
end
function out=get(value,key,fallback),out=fallback;if isstruct(value)&&isscalar(value)&&isfield(value,key),out=value.(key);end,end
function out=plain(value,depth)
    assert(depth<=64,'C1Recent:Depth');
    if isstruct(value),out=value;for i=1:numel(value),for key=fieldnames(value).',out(i).(key{1})=plain(value(i).(key{1}),depth+1);end,end
    elseif iscell(value),out=value;for k=1:numel(value),out{k}=plain(value{k},depth+1);end
    elseif isnumeric(value)&&~isreal(value),out=struct('real',plain(real(value),depth+1),'imaginary',plain(imag(value),depth+1));
    elseif isnumeric(value)&&any(~isfinite(value(:))),out=cell(size(value));for k=1:numel(value),out{k}=sprintf('%.17g',value(k));end
    else,assert(isnumeric(value)||islogical(value)||ischar(value)||isstring(value),'C1Recent:Nonplain');out=value;end
end
function r=ref(file),r=struct('file',file,'sha256',RoundSHA256_v3(file));end
function value=utc(),value=posixtime(datetime('now','TimeZone','UTC'));end
function value=nano(),value=double(java.lang.System.nanoTime);end
function check(limit),assert(utc()<limit.utc&&nano()<limit.mono,'C1Recent:Budget');end
function remove(file),if isfile(file),delete(file);end,end
